/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * 会社情報を表現します.<br>
 * 
 * 通常、{@link GCompany}はログイン時に生成され、{@link GUser}にセットされます。<br>
 * そして、ログアウト時に{@link GUser}と共に解放されます。
 * 
 * @create 2007/03/24
 * @author kitamura
 * @since 3.0.0
 */
public interface GCompany extends Serializable{

	/**
	 * 会社情報を一意に識別するためのコードを取得します.
	 * 
	 * @create 2007/03/24
	 * @return 会社コード
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getCode();
	
	/**
	 * 会社を識別するための一意なコードを設定します.
	 * 
	 * @create 2007/03/24
	 * @param code 会社コード
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setCode(String code);
	
	/**
	 * 会社名を取得します.
	 * 
	 * @return 会社名
	 * @create 2011/07/29
	 * @author kitamura
	 * @since 3.9.0
	 */
	String getName();
	
	/**
	 * ロケールに対応した会社名を取得します.
	 * 
	 * @param locale ロケール情報
	 * @return 会社名
	 * @create 2011/07/29
	 * @author kitamura
	 * @since 3.9.0
	 */
	String getName(Locale locale);
	
	/**
	 * 会社名を取得します.
	 * 
	 * @param name 会社名
	 * @create 2011/07/29
	 * @author kitamura
	 * @since 3.9.0
	 */
	void setName(String name);
	
	/**
	 * 会社名の{@link Map}を取得します.
	 * 
	 * @return 会社名の{@link Map}
	 * @create 2011/07/29
	 * @author kitamura
	 * @since 3.9.0
	 */
	Map<Locale, String> getLocaleNameMap();
	
	/**
	 * 会社名の{@link Map}を設定します.
	 * 
	 * @param map 会社名の{@link Map}
	 * @create 2011/07/29
	 * @author kitamura
	 * @since 3.9.0
	 */
	void setLocaleNameMap(Map<Locale, String> map);

	/**
	 * 親会社を取得します.
	 * 
	 * @create 2007/04/02
	 * @return 親会社
	 * @author kitamura
	 * @since 3.0.0
	 */
	GCompany getParent();
	
	/**
	 * 親会社を設定します.
	 * 
	 * @create 2007/04/02
	 * @param company 親会社
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setParent(GCompany company);

	/**
	 * 指定された名前でこの会社にバインドされたオブジェクトを返します.<br>
	 * その名前でバインドされたオブジェクトがない場合は、<code>null</code>を返します。
	 * 
	 * @create 2007/03/24
	 * @param name オブジェクトの名前を指定する文字列
	 * @return 指定された名前のオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	Object getValue(String name);
	
	/**
	 * 指定されたキーを使用して、オブジェクトをこの会社にバインドします.<br>
	 * 同じキーのオブジェクトがすでに会社にバインドされている場合は、オブジェクトが置き換えられます。 
	 * 
	 * @create 2007/03/24
	 * @param key オブジェクトがバインドされるキー。<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setValue(String key, Object value);

	/**
	 * この会社にバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの{@link Iterator}を返します.
	 * 
	 * @create 2007/01/06
	 * @return この会社にバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの{@link Iterator}
	 * @author kitamura
	 * @since 3.0.0
	 */
	Iterator<String> getValueKeys();

	/**
	 * この会社が停止状態であれば<code>true</code>を返します.
	 * 
	 * @create 2007/03/31
	 * @return 停止状態なら<code>true</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean isInvalid();
	
	/**
	 * 状態を取得します.
	 * 
	 * @return 状態
	 * @create 2011/07/29
	 * @author kitamura
	 * @since 3.9.0
	 */
	GStatus getStatus();
	
	/**
	 * 状態を設定します.
	 * 
	 * @param status 状態
	 * @create 2011/07/29
	 * @author kitamura
	 * @since 3.9.0
	 */
	void setStatus(GStatus status);

	/**
	 * 指定されたキーでバインドされたオブジェクトをこの会社から削除します.<br>
	 * 会社に指定されたキーでバインドされたオブジェクトがない場合、このメソッドは何も実行しません。 
	 * 
	 * @create 2007/03/24
	 * @param key この会社から削除されるオブジェクトのキー
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeValue(String key);
}
