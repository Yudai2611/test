/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/** 
 * 会社情報取得用のデータアクセスオブジェクトを表現します.<br>
 * 
 * @create 2010/10/28
 * @author kyo
 * @since 3.9.0
 */
public interface GCompanyDao {

	/**
	 * 会社コードを基に、会社情報を取得します.<br>
	 * 
	 * @create 2010/10/28
	 * @param companyCode 会社コード
	 * @return 会社情報
	 * @author kyo
	 * @throws GResourceProcessingException リソースアクセスに失敗した場合
	 * @since 3.9.0
	 */
	GCompany findCompany(String companyCode) throws GResourceProcessingException;
}