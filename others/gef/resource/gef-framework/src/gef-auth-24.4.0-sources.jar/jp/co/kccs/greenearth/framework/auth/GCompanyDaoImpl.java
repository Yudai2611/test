/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * 会社情報アクセス用のデータアクセスオブジェクトです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class GCompanyDaoImpl implements GCompanyDao {

	/** 会社マスタ */
	protected static final String COMPANY_MASTER = "CompanyMaster";

	/** 会社コード */
	protected static final String COMPANYCD = "CompanyCD";

	/** 親会社コード */
	protected static final String COMPANY_PARENTCD = "ParentCD";

	/** 会社名 */
	protected static final String COMPANY_NAME = "Name";

	/** 状態 */
	protected static final String STATUS = "Status";

	private Map<String, GCompany> _companyMap = new HashMap<String, GCompany>();


	/**
	 * {@link GCompanyDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GCompanyDaoImpl() {
	}

	/**
	 * {@link GCompany}を生成します。
	 *
	 * @create 2020/6/23
	 * @return GCompany
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GCompany createCompany() {
		return new GCompanyImpl();
	}

	/**
	 * 会社コードに一致する{@link GCompany}を返します。
	 *
	 * @create 2020/6/23
	 * @return GCompany
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public GCompany findCompany(String companyCD) throws GResourceProcessingException {
		if (companyCD == null) {
			return null;
		}

		if (_companyMap.containsKey(companyCD)) {
			return _companyMap.get(companyCD);
		}

		GCompany company = null;

		// ユーザ情報の取得
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("companyCD", companyCD);

			List<GRecord> list = select(COMPANY_MASTER).where(expMap($("#" + COMPANYCD + " = :companyCD"), params)).findList();

			if (list.size() != 0) {
				GRecord record = list.get(0);
				company = createCompany();
				company.setCode(companyCD);
				company.setName(record.getString(COMPANY_NAME));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					company.setStatus(GStatus.Active);
				} else {
					company.setStatus(GStatus.Stop);
				}

				// 会社情報の取得
				String parentCD = record.getString(COMPANY_PARENTCD);
				if (parentCD != null) {
					GCompany parent = findCompany(parentCD);
					company.setParent(parent);
				}

				_companyMap.put(companyCD, company);
			}
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
		return company;
	}

}
