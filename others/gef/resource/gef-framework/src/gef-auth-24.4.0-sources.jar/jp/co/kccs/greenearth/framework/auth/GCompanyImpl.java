/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.collection.GEmptyIterator;

/**
 * 会社情報を表すクラスです.
 * 
 * @create 2011/07/29
 * @author KCCS nishimura
 * @since 3.9.0
 */
public class GCompanyImpl implements GCompany {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 2556581805279870752L;

	/** 値がバインドされていない場合に返す{@link Iterator}. */
	private static final Iterator<String> EMPTY_ITERATOR = new GEmptyIterator<String>();

	/** 会社コード. */
	private String _code = null;
	/** 状態 */
	private GStatus _status = GStatus.Active;

	/** 親会社. */
	private GCompany _parent = null;
	/** 追加情報. */
	private Map<String, Object> _values = null;

	/** ロケール毎の会社名を保持するMap */
	private Map<Locale, String> _localeNameMap = new HashMap<Locale, String>();

	/**
	 * デフォルトコンストラクタ
	 * 
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GCompanyImpl() {
	}

	/**
	 * 会社コードを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getCode()
	 * @return 会社コード
	 * @create 2011/09/16
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public String getCode() {
		return _code;
	}

	/**
	 * 会社を識別するための一意なコードを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#setCode(java.lang.String)
	 * @param code 会社コード
	 * @create 2011/09/16
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void setCode(String code) {
		_code = code;
	}

	/**
	 * 会社名を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getName()
	 * @return 会社名
	 * @create 2011/09/16
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public String getName() {
		return _localeNameMap.get(GFrameworkUtils.getDefaultLocale());
	}

	/**
	 * 会社名を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#setName(java.lang.String)
	 * @param name 会社名
	 * @create 2011/09/16
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void setName(String name) {
		_localeNameMap.put(GFrameworkUtils.getDefaultLocale(), name);
	}

	/**
	 * 会社名を保持する{@link Map}を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getLocaleNameMap()
	 * @return 会社名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public Map<Locale, String> getLocaleNameMap() {
		return _localeNameMap;
	}

	/**
	 * ロケールを指定して会社名を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getName(java.util.Locale)
	 * @param locale ロケール
	 * @return 会社名
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getName(Locale locale) {
		return _localeNameMap.get(locale);
	}

	/**
	 * 会社名を保持する{@link Map}を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#setLocaleNameMap(java.util.Map)
	 * @param map 会社名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setLocaleNameMap(Map<Locale, String> map) {
		_localeNameMap = map;
	}

	/**
	 * 親会社を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getParent()
	 * @return 親会社
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public GCompany getParent() {
		return _parent;
	}

	/**
	 * 親会社を設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#setParent(jp.co.kccs.greenearth.framework.auth.GCompany)
	 * @param company 親会社
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public void setParent(GCompany company) {
		_parent = company;
	}
	/**
	 * 状態を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getStatus()
	 * @return 状態
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GStatus getStatus() {
		return _status;
	}

	/**
	 * 状態を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#setStatus(jp.co.kccs.greenearth.framework.auth.GStatus)
	 * @param status 状態
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setStatus(GStatus status) {
		_status = status;
	}

	/**
	 * 停止フラグを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#isInvalid()
	 * @return 停止フラグ
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public boolean isInvalid() {
		if (GStatus.Stop == getStatus()) {
			return true;
		}

		GCompany parent = getParent();
		if (parent != null) {
			return parent.isInvalid();
		}

		return false;
	}

	/**
	 * 指定された名前でこの会社にバインドされたオブジェクトを返します.<br>
	 * その名前でバインドされたオブジェクトがない場合は、<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getValue(java.lang.String)
	 * @param name オブジェクトの名前を指定する文字列
	 * @return 指定された名前のオブジェクト
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public Object getValue(String name) {
		Object value = null;
		if (_values != null) {
			value = _values.get(name);
		}
		return value;
	}

	/**
	 * この会社に結びつけられている全てのオブジェクトの名前を表す <code>String</code>オブジェクトの{@link Iterator}
	 * オブジェクトを返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#getValueKeys()
	 * @return この会社に結びつけられている全てのオブジェクトの名前を表す{@link String}オブジェクトの
	 *         {@link Iterator}
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public Iterator<String> getValueKeys() {
		if (_values != null) {
			return _values.keySet().iterator();
		} else {
			return EMPTY_ITERATOR;
		}
	}

	/**
	 * 指定された名前でバインドされたオブジェクトをこの会社から削除します.<br>
	 * 会社に指定された名前でバインドされたオブジェクトがない場合、このメソッドは何も実行しません。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#removeValue(java.lang.String)
	 * @param key この会社から削除されるオブジェクトの名前
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public void removeValue(String key) {
		if (_values != null) {
			_values.remove(key);

			if (_values.size() == 0) {
				_values = null;
			}
		}
	}

	/**
	 * 指定された名前を使用して、オブジェクトをこの会社にバインドします.<br>
	 * 同じ名前のオブジェクトがすでに会社にバインドされている場合は、オブジェクトが置き換えられます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GCompany#setValue(java.lang.String,
	 *      java.lang.Object)
	 * @param key オブジェクトがバインドされる名前。<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public void setValue(String key, Object value) {
		// nullの場合は削除
		if (value == null) {
			removeValue(key);
		}

		if (_values == null) {
			_values = new HashMap<String, Object>();
		}
		_values.put(key, value);
	}
}
