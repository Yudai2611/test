/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.catchConnection;
import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.releaseConnection;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * 職位情報アクセス用のデータアクセスオブジェクトです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class GEmploymentRankDaoImpl implements GGroupDao {

	/** 職位マスタ */
	protected static final String EMPLOYMENT_RANK_MASTER = "EmploymentRankMaster";

	/** 会社コード */
	protected static final String COMPANYCD = "CompanyCD";

	/** 職位ID */
	protected static final String RANK_ID = "ID";

	/** 職位名 */
	protected static final String RANK_NAME = "Name";

	/** 状態 */
	protected static final String STATUS = "Status";


	/** グループ定義名 */
	protected static final String GROUP_CATEGORY_RESOURCE_ID = "RANK";

	private Map<String, GGroup> _groupMap = new HashMap<String, GGroup>();
	private GCompanyDao _companyDao = null;

	/**
	 * 会社DAOを指定して{@link GEmploymentRankDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @param companyDao
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GEmploymentRankDaoImpl(GCompanyDao companyDao) {
		_companyDao = companyDao;
	}


	/**
	 * {@link GGroup}を生成します。
	 *
	 * @create 2020/6/23
	 * @return GGroup
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GGroup createGroup() {
		return 	new GGroupImpl();
	}

	/**
	 * グループを検索します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param id グループID
	 * @return グループ情報
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public GGroup findGroup(String companyCD, String id) throws GResourceProcessingException {
		if (companyCD == null || id == null) {
			return null;
		}

		String key = companyCD + "_" + id;
		if (_groupMap.containsKey(key)) {
			return _groupMap.get(key);
		}

		GGroup rank = null;
		Connection conn = catchConnection();

		// ユーザ情報の取得
		try {
			List<GRecord> list = select(EMPLOYMENT_RANK_MASTER).wherePK(companyCD, id).findList();

			if (list.size() != 0) {
				GRecord record = list.get(0);

				rank = createGroup();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				rank.setLocaleNameMap(nameMap);
				GCompany company = _companyDao.findCompany(companyCD);
				rank.setCompany(company);
				rank.setId(record.getString(RANK_ID));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					rank.setStatus(GStatus.Active);
				} else {
					rank.setStatus(GStatus.Stop);
				}
				rank.setName(record.getString(RANK_NAME));

				_groupMap.put(key, rank);
			}
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(conn);
		}

		return rank;
	}

}
