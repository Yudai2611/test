/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * グループ情報を表現します.<br>
 * 
 * 通常、{@link GGroup}はログイン時に生成され、{@link GUser}にセットされます。<br>
 * そして、ログアウト時に{@link GUser}と共に解放されます。<br>
 * <br>
 * <b>【グループの構成】</b><br>
 * グループは、ツリー構造で管理されています。<br>
 * そのため、１つのグループは１つの親グループと、複数の子グループを参照しています。<br>
 * 各子グループは、IDによって識別することができます。
 * 
 * @create 2007/03/24
 * @author kitamura
 * @since 3.0.0
 */
public interface GGroup extends Serializable{

	/**
	 * このグループが所属する会社を取得します.
	 * 
	 * @create 2007/03/24
	 * @return 会社
	 * @author kitamura
	 * @since 3.0.0
	 */
	GCompany getCompany();
	
	/**
	 * このグループが所属する会社を設定します.
	 * 
	 * @create 2007/03/24
	 * @param company 会社
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setCompany(GCompany company);

	/**
	 * グループ情報を一意に識別するためのIDを取得します.
	 * 
	 * @create 2007/03/24
	 * @return グループID
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getId();
	
	/**
	 * グループを識別するための一意なIDを設定します.
	 * 
	 * @create 2007/03/24
	 * @param id グループID
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setId(String id);
	
	/**
	 * グループ名を取得します.
	 * 
	 * @return グループ名
	 * @create 2011/07/29
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	String getName();
	
	/**
	 * ロケールを指定して、グループ名を取得します.
	 * 
	 * @param locale ロケール
	 * @return グループ名
	 * @create 2011/07/29
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	String getName(Locale locale);
	
	/**
	 * グループ名を設定します.
	 * 
	 * @param name グループ名
	 * @create 2011/07/29
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setName(String name);
	
	/**
	 * グループ名を保持する{@link Map]を取得します.
	 * 
	 * @return グループ名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	Map<Locale, String> getLocaleNameMap();
	
	/**
	 * グループ名を保持する{@link Map]を設定します.
	 * 
	 * @param map グループ名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setLocaleNameMap(Map<Locale, String> map);

	/**
	 * このグループが所属する親グループを取得します.
	 * 
	 * @create 2007/04/02
	 * @return グループ
	 * @author kitamura
	 * @since 3.0.0
	 */
	GGroup getParent();
	
	/**
	 * 指このグループが所属する親グループを設定します.
	 * 
	 * @create 2007/04/02
	 * @param group 親グループ
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setParent(GGroup group);

	/**
	 * このグループが停止状態であれば<code>true</code>を返します.
	 * 
	 * @create 2007/03/31
	 * @return 停止状態なら<code>true</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean isInvalid();
	
	/**
	 * 状態を取得します.
	 * 
	 * @return 状態
	 * @create 2011/07/29
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	GStatus getStatus();
	
	/**
	 * 状態を設定します.
	 * 
	 * @param status 状態
	 * @create 2011/07/29
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setStatus(GStatus status);

	/**
	 * 指定されたキーでこのグループにバインドされたオブジェクトを返します.<br>
	 * そのキーでバインドされたオブジェクトがない場合は、<code>null</code>を返します。
	 * 
	 * @create 2007/03/24
	 * @param key オブジェクトのキーを指定する文字列
	 * @return 指定された名前のオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	Object getValue(String key);
	
	/**
	 * 指定されたキーを使用して、オブジェクトをこのグループにバインドします.<br>
	 * 同じキーのオブジェクトがすでにグループにバインドされている場合は、オブジェクトが置き換えられます。 
	 * 
	 * @create 2007/03/24
	 * @param key オブジェクトがバインドされるキー。<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setValue(String key, Object value);

	/**
	 * このグループにバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの{@link Iterator}を返します.
	 * 
	 * @create 2007/01/06
	 * @return このグループにバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの{@link Iterator}
	 * @author kitamura
	 * @since 3.0.0
	 */
	Iterator<String> getValueKeys();

	/**
	 * 指定されたキーでバインドされたオブジェクトをこのグループから削除します.<br>
	 * グループに指定されたキーでバインドされたオブジェクトがない場合、このメソッドは何も実行しません。 
	 * 
	 * @create 2007/03/24
	 * @param key このグループから削除されるオブジェクトのキー
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeValue(String key);
}
