/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * グループ情報取得用のデータアクセスオブジェクトを表現します.<br>
 * 
 * @create 2011/07/29
 * @author KCCS nishimura
 * @since 3.9.0
 */
public interface GGroupDao {

	/**
	 * 会社コード、グループを識別する為のIDを基に、グループ情報を取得します.
	 * 
	 * @param companyCode 会社コード
	 * @param id グループを識別する為のID
	 * @return グループ情報
	 * @throws GResourceProcessingException リソース処理に失敗した場合
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GGroup findGroup(String companyCode, String id) throws GResourceProcessingException;
}
