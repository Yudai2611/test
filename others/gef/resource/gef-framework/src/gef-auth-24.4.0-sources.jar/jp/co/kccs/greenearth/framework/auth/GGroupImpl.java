/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.collection.GEmptyIterator;

/**
 * {@link GGroup}のデフォルト実装です。
 * 
 * @see jp.co.kccs.greenearth.framework.auth.GGroup
 * @create 2007/03/24
 * @author kyo
 * @since 3.9.0
 */
public class GGroupImpl implements GGroup {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 3866035241854960003L;

	/** 値がバインドされていない場合に返す{@link Iterator}. */
	protected static final Iterator<String> EMPTY_ITERATOR = new GEmptyIterator<String>();

	/** 会社. */
	private GCompany _company = null;
	/** グループID. */
	private String _id = null;
	/** 状態 */
	private GStatus _status = GStatus.Active;
	/** 親グループ. */
	private GGroup _parent = null;
	/** 追加情報. */
	private Map<String, Object> _values = null;
	/** ロケール毎のグループ名を保持するMap */
	private Map<Locale, String> _localeNameMap = new HashMap<Locale, String>();

	/**
	 * {@link GGroupImpl}インスタンスを初期化します.
	 * 
	 * @create 2007/03/24
	 * @author kyo
	 * @since 3.9.0
	 */
	public GGroupImpl() {
	}

	/**
	 * このグループが所属する会社を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GGroup#getCompany()
	 * @create 2007/03/24
	 * @return 会社コード
	 * @author kyo
	 * @since 3.9.0
	 */
	public GCompany getCompany() {
		return _company;
	}

	/**
	 * グループIDを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#getId()
	 * @create 2007/03/24
	 * @return グループID
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getId() {
		return _id;
	}

	/**
	 * グループ名を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#getName()
	 * @create 2007/03/24
	 * @return グループ名
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getName() {
		return _localeNameMap.get(GFrameworkUtils.getDefaultLocale());
	}

	/**
	 * 親グループをします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GGroup#getParent()
	 * @create 2007/04/04
	 * @return 親グループ
	 * @author kyo
	 * @since 3.9.0
	 */
	public GGroup getParent() {
		return _parent;
	}

	/**
	 * 指定された名前でこのグループに結びつけられているオブジェクトを返します. 指定された名前に結びつけられているオブジェクトが存在しない場合は
	 * <code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#getValue(java.lang.String)
	 * @create 2007/03/24
	 * @param name オブジェクトの名前を表す文字列
	 * @return 指定された名前を持つオブジェクト
	 * @author kyo
	 * @since 3.9.0
	 */
	public Object getValue(String name) {
		Object value = null;
		if (_values != null) {
			value = _values.get(name);
		}
		return value;
	}

	/**
	 * このグループに結びつけられている全てのオブジェクトのキーを表す {@link String}オブジェクトの{@link Iterator}
	 * オブジェクトを返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#getValueKeys()
	 * @create 2007/03/24
	 * @return このグループに結びつけられている全てのオブジェクトのキーを表す{@link String}オブジェクトの
	 *         {@link Iterator}
	 * @author kyo
	 * @since 3.9.0
	 */
	public Iterator<String> getValueKeys() {
		if (_values != null) {
			return _values.keySet().iterator();
		} else {
			return EMPTY_ITERATOR;
		}
	}

	/**
	 * このグループが停止状態であれば<code>true</code>を返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#isInvalid()
	 * @create 2007/04/02
	 * @return 停止状態なら<code>true</code>
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean isInvalid() {
		if (GStatus.Stop == getStatus()) {
			return true;
		}
		
		GCompany company = getCompany();
		if (company != null && company.isInvalid()) {
			return true;
		}
		
		GGroup parent = getParent();
		if (parent != null) {
			return parent.isInvalid();
		}
		
		return false;
	}

	/**
	 * 指定された名前でグループに結びつけられているオブジェクトをセッションから 削除します.<br>
	 * 指定された名前で結びつけられているオブジェクトがグループに存在しない場 合は何もしません。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#removeValue(java.lang.String)
	 * @create 2007/03/24
	 * @param name グループから削除されるオブジェクトの名前
	 * @author kyo
	 * @since 3.9.0
	 */
	public void removeValue(String name) {
		if (_values != null) {
			_values.remove(name);

			if (_values.size() == 0) {
				_values = null;
			}
		}
	}

	/**
	 * このグループが所属する会社を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GGroup#setCompany(GCompany)
	 * @create 2007/03/24
	 * @param company 会社
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setCompany(GCompany company) {
		_company = company;
	}

	/**
	 * グループIDを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#setId(java.lang.String)
	 * @create 2007/03/24
	 * @param id グループID
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setId(String id) {
		_id = id;
	}

	/**
	 * グループ名を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#setName(java.lang.String)
	 * @create 2007/03/24
	 * @param name グループ名
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setName(String name) {
		_localeNameMap.put(GFrameworkUtils.getDefaultLocale(), name);
	}

	/**
	 * 親グループを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GGroup#setParent(jp.co.kccs.greenearth.framework.session.GGroup)
	 * @create 2007/04/04
	 * @param parent 親グループ
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setParent(GGroup parent) {
		_parent = parent;
	}

	/**
	 * 指定された名前でこのグループにオブジェクトを結びつけます. 同じ名前を持つオブジェクトが既にこのグループに結びつけられている場合、
	 * そのオブジェクトを置き換えます。
	 * 
	 * オブジェクトとして<code>null</code>が指定された場合は {@link #removeValue(String)}
	 * が呼び出されたのと同じ動作をします。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#setValue(java.lang.String,
	 *      java.lang.Object)
	 * @create 2007/03/24
	 * @param name オブジェクトがバインドされる名前。<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setValue(String name, Object value) {
		// nullの場合は削除
		if (value == null) {
			removeValue(name);
		}

		if (_values == null) {
			_values = new HashMap<String, Object>();
		}
		_values.put(name, value);
	}
	
	/**
	 * グループ名を保持する{@link Map}を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#getLocaleNameMap()
	 * @return グループ名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public Map<Locale, String> getLocaleNameMap() {
		return _localeNameMap;
	}
	
	/**
	 * ロケールを指定してグループ名を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#getName(java.util.Locale)
	 * @param locale ロケール
	 * @return グループ名
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getName(Locale locale) {
		return _localeNameMap.get(locale);
	}
	
	/**
	 * グループ名を保持する{@link Map}
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#setLocaleNameMap(java.util.Map)
	 * @param map グループ名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setLocaleNameMap(Map<Locale, String> map) {
		_localeNameMap = map;
	}

	/**
	 * 状態を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#getStatus()
	 * @return 状態
	 * @create 2011/05/24
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public GStatus getStatus() {
		return _status;
	}
	
	/**
	 * 状態を設定します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GGroup#setStatus(jp.co.kccs.greenearth.framework.auth.GStatus)
	 * @param status 状態
	 * @create 2011/05/24
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void setStatus(GStatus status) {
		_status = status;
	}
}
