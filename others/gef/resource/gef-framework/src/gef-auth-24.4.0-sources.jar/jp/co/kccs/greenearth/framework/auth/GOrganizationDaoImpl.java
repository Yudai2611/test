/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.catchConnection;
import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.releaseConnection;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * 組織情報アクセス用のデータアクセスオブジェクトです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class GOrganizationDaoImpl implements GGroupDao {

	/** 組織マスタ */
	protected static final String ORGANIZATION_MASTER = "OrganizationMaster";

	/** 会社コード */
	protected static final String COMPANYCD = "CompanyCD";

	/** 組織ID */
	protected static final String ORG_ID = "ID";

	/** 親組織ID */
	protected static final String ORG_PARENTID = "ParentID";

	/** 組織名 */
	protected static final String ORG_NAME = "Name";

	/** 状態 */
	protected static final String STATUS = "Status";

	/** グループ定義名 */
	protected static final String GROUP_CATEGORY_RESOURCE_ID = "ORGANIZATION";

	private Map<String, GGroup> _groupMap = new HashMap<String, GGroup>();

	private GCompanyDao _companyDao = null;

	/**
	 * 会社DAOを指定して{@link GOrganizationDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @param companyDao
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GOrganizationDaoImpl(GCompanyDao companyDao) {
		_companyDao = companyDao;
	}

	/**
	 * {@link GGroup}を生成します。
	 *
	 * @create 2020/6/23
	 * @return GGroup
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GGroup createGroup() {
		return 	new GGroupImpl();
	}


	/**
	 * グループを検索します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param id グループID
	 * @return グループ情報
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public GGroup findGroup(String companyCD, String id) throws GResourceProcessingException {
		if (companyCD == null || id == null) {
			return null;
		}

		String key = companyCD + "_" + id;
		if (_groupMap.containsKey(key)) {
			return _groupMap.get(key);
		}

		GGroup organization = null;
		Connection conn = catchConnection();

		// グループ情報の取得
		try {
			List<GRecord> list = select(ORGANIZATION_MASTER).wherePK(companyCD, id).orderBy(asc(col(exp("#" + ORG_ID)))).findList();

			if (list.size() != 0) {
				GRecord record = list.get(0);

				organization = createGroup();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				organization.setLocaleNameMap(nameMap);
				GCompany company = _companyDao.findCompany(companyCD);
				organization.setCompany(company);
				organization.setId(record.getString(ORG_ID));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					organization.setStatus(GStatus.Active);
				} else {
					organization.setStatus(GStatus.Stop);
				}
				organization.setName(record.getString(ORG_NAME));

				// 親グループの取得
				String parentCode = record.getString(ORG_PARENTID);
				if (parentCode != null) {
					GGroup parent = findGroup(companyCD, parentCode);
					organization.setParent(parent);
				}

				_groupMap.put(key, organization);
			}
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(conn);
		}

		return organization;
	}

}
