/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

/**
 * 状態を表す列挙値
 * 
 * @create 2011/07/29
 * @author KCCS nishimura
 * @since 
 */
public enum GStatus {
	/** 
	 * Active:実行可能状態
	 * Stop:停止状態
	 * */
	Active(1), Stop(0);
	
	private int _value;
	
	private GStatus(int value) {
		_value = value;
	}
	
	public static GStatus convert(boolean value) {
		return value ? Active : Stop;
	}
	
	public static GStatus convert(int value) {
		if (Active._value == value) {
			return Active;
		}
		else if (Stop._value == value) {
			return Stop;
		}
		else {
			return null;
		}
	}
	
	public int toInt() {
		return _value;
	}
}
