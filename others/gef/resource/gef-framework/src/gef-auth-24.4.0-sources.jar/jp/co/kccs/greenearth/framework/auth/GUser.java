/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.io.Serializable;
import java.security.Principal;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * ユーザ情報を表現します.<br>
 * 
 * <b>【会社情報】</b></br> ユーザに紐付けられた会社情報を格納する事ができます。<br>
 * ユーザ情報内では、会社情報を権限管理に使用します。<br>
 * 会社情報は、{@link jp.co.kccs.greenearth.framework.auth.GCompany}の実装クラスである必要があります。<br>
 * <br>
 * <b>【グループ情報】</b></br> ユーザに紐付けられた複数のグループ情報を格納する事ができます。<br>
 * ユーザ情報には、複数のカテゴリーのグループ情報を格納する事ができます。<br>
 * また、1つのカテゴリーには複数のグループを格納する事ができます。<br>
 * グループ情報は、{@link jp.co.kccs.greenearth.framework.auth.GGroup}の実装クラスである必要があります。<br>
 * <br>
 * 
 * [所属階層イメージ]
 * 
 * <pre>
 * ユーザ
 * ├─会社
 * ├─グループカテゴリA
 * │  ├─グループ1
 * │  ├─グループ2
 * │  ├─グループ3
 * │　    …
 * ├─グループカテゴリB
 * ├─グループカテゴリC
 *     …
 * </pre>
 * 
 * @create 2007/01/06
 * @author kitamura
 * @since 3.0.0
 */
public interface GUser extends Principal, Serializable {
	
	/**
	 * このユーザが所属する会社を取得します.
	 * 
	 * @create 2007/01/06
	 * @return 会社
	 * @author kitamura
	 * @since 3.0.0
	 */
	GCompany getCompany();
	
	/**
	 * このユーザが所属する会社を設定します.
	 * 
	 * @create 2007/01/06
	 * @param company 会社
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setCompany(GCompany company);
	
	/**
	 * ユーザ情報を一意に識別するためのIDを取得します.
	 * 
	 * @create 2007/01/06
	 * @return ユーザID
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getId();

	/**
	 * ユーザを識別するための一意なIDを設定します.
	 * 
	 * @create 2007/01/06
	 * @param id ユーザID
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setId(String id);	
	
	/**
	 * ユーザ名を取得します.
	 * 
	 * @return ユーザ名
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getName();
	
	/**
	 * ロケールを指定してユーザ名を取得します.
	 * 
	 * @param locale ロケール
	 * @return ユーザ名
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getName(Locale locale);
	
	/**
	 * ユーザ名を設定します.
	 * 
	 * @param name ユーザ名
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setName(String name);
	
	/**
	 * ユーザ名を保持する{@link Map}を取得します.
	 * 
	 * @return ユーザ名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<Locale, String> getLocaleNameMap();
	
	/**
	 * ユーザ名を保持する{@link Map}を設定します.
	 * 
	 * @param map ユーザ名の{@link Map}
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setLocaleNameMap(Map<Locale, String> map);
	
	
	/**
	 * パスワードを取得します.
	 * 
	 * @create 2007/02/15
	 * @return パスワード
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getPassword();
	
	/**
	 * パスワードを設定します.
	 * 
	 * @create 2007/02/15
	 * @param password パスワード
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setPassword(String password);

	/**
	 * このユーザが停止状態であれば<code>true</code>を返します.
	 * 
	 * @create 2007/03/31
	 * @return 停止状態なら<code>true</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean isInvalid();
	
	/**
	 * このユーザーの状態を取得します。
	 * 
	 * @return 状態
	 * @create 2011/05/24
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	GStatus getStatus();
	
	/**
	 * このユーザーの状態を設定します。
	 * 
	 * @param status 状態
	 * @create 2011/05/24
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	void setStatus(GStatus status);
	
	/**
	 * 指定されたキーでこのユーザにバインドされたオブジェクトを返します.<br>
	 * その名前でバインドされたオブジェクトがない場合は、<code>null</code>を返します。
	 * 
	 * @create 2007/01/06
	 * @param key オブジェクトのキーを指定する文字列
	 * @return 指定された名前のオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	Object getValue(String key);

	/**
	 * 指定された名前を使用して、オブジェクトをこのユーザにバインドします.<br>
	 * 同じ名前のオブジェクトがすでにユーザにバインドされている場合は、オブジェクトが置き換えられます。
	 * 
	 * @create 2007/01/06
	 * @param name オブジェクトがバインドされる名前。<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setValue(String name, Object value);

	/**
	 * 指定されたキーでバインドされたオブジェクトをこのユーザから削除します.<br>
	 * ユーザに指定されたキーでバインドされたオブジェクトがない場合、このメソッドは何も実行しません。
	 * 
	 * @create 2007/01/06
	 * @param key このユーザから削除されるオブジェクトのキー
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeValue(String key);

	/**
	 * このユーザにバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの{@link Iterator}
	 * を返します.
	 * 
	 * @create 2007/01/06
	 * @return このユーザにバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの
	 *         {@link Iterator}
	 * @author kitamura
	 * @since 3.0.0
	 */
	Iterator<String> getValueKeys();

	/**
	 * ユーザー所属の全情報を取得します.
	 * 
	 * @return Map
	 * @author KCCS kyo
	 * @since 2010/10/10
	 * @since 3.9.0
	 */
	Map<String, List<GGroup>> getGroupMatrix();

	/**
	 * 指定したグループのグループ情報(兼務)を取得します.
	 * 
	 * @param categoryKey キー
	 * @return List　グループ情報(兼務)
	 * @author KCCS kyo
	 * @since 2010/10/10
	 * @since 3.9.0
	 */
	List<GGroup> getGroup(String categoryKey);

	/**
	 * 指定したキーで、ユーザーが所属するグループを複数追加します.
	 * 
	 * @param categoryKey キー
	 * @param grouplist グループ情報(複数)
	 * @author KCCS kyo
	 * @since 2010/10/10
	 * @since 3.9.0
	 */
	void addGroup(String categoryKey, List<GGroup> grouplist);

	/**
	 * 指定したキーで、ユーザーが所属するグループを追加します.
	 * 
	 * @param categoryKey キー
	 * @param group グループ情報
	 * @author KCCS kyo
	 * @since 2010/10/10
	 * @since 3.9.0
	 */
	void addGroup(String categoryKey, GGroup group);
	
	/**
	 * 指定したインデックスのグループマップに、グループ情報を追加します.
	 * 
	 * @create 2007/05/01
	 * @param index グループインデックス
	 * @param group グループ情報
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	void addGroup(int index, GGroup group);
	
	/**
	 * 指定したインデックスのグループマップに、複数のグループ情報を追加します.
	 * 
	 * @create 2007/05/01
	 * @param index グループインデックス
	 * @param groupMap グループマップ
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	void addGroupMap(int index, Map<String, GGroup> groupMap);
	
	/**
	 * グループ情報を全てクリアします.
	 * 
	 * @create 2007/05/01
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	void clearGroupAll();
	
	/**
	 * 指定されたインデックスのグループマップを削除します.
	 * 
	 * @create 2007/05/01
	 * @param index グループインデックス
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	void clearGroupMap(int index);
	
	/**
	 * グループの区分番号、グループIDの組合せが登録されているかどうかを返します.<br>
	 * 
	 * @create 2007/05/01
	 * @param index グループの区分番号
	 * @param key グループID
	 * @return <code>true</code>/<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	boolean containsGroupKey(int index, String key);
	
	/**
	 * 指定したインデックスのグループマップから、指定したIDのグループを取得します.
	 * 
	 * @create 2007/05/01
	 * @param index グループインデックス
	 * @param groupId グループID
	 * @return グループ情報
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	GGroup getGroup(int index, String groupId);
	
	/**
	 * 登録されているグループの種別数を取得します.
	 * 
	 * @create 2007/05/01
	 * @return グループの種別数
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	int getGroupCount();
	
	/**
	 * 指定したインデックスのグループマップを取得します.
	 * 
	 * @create 2007/05/01
	 * @param index グループインデックス
	 * @return グループマップ
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	Map<String, GGroup> getGroupMap(int index);
	
	/**
	 * 指定されたインデックスのグループマップの中から、指定されたIDのグループを削除します.
	 * 
	 * @create 2007/05/01
	 * @param index グループインデックス
	 * @param groupId グループID
	 * @author kitamura
	 * @since 3.0.0
	 * @deprecated
	 */
	void removeGroup(int index, String groupId);
	
	/**
	 * ロケールを取得します.
	 * 
	 * @return ロケール
	 * @create 2011/07/29
	 * @author KCCS nisimura
	 * @since 3.9.0
	 */
	Locale getLocale();
	
	/**
	 * ロケールを設定します.
	 * 
	 * @param locale ロケール
	 * @create 2011/07/29
	 * @author KCCS nisimura
	 * @since 3.9.0
	 */
	void setLocale(Locale locale);
	
	
}