/*
 * Copyright 2007-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * 会社情報取得用のデータアクセスオブジェクトを表現します.<br>
 * 
 * @create 2007/01/21
 * @author kitamura
 * @since 3.0.0
 */
public interface GUserDao {

//	/**
//	 * ユーザオブジェクトを生成します.<br>
//	 * 
//	 * @create 2007/04/04
//	 * @return ユーザオブジェクト
//	 * @author kitamura
//	 * @since 3.0.0
//	 */
//	GUser createUser();

	/**
	 * 会社情報を検索します.<br>
	 * 
	 * @create 2007/02/06
	 * @param companyCode 会社コード
	 * @param id ユーザID
	 * @return ユーザ情報
	 * @author kitamura
	 * @throws GResourceProcessingException DBアクセスに失敗した場合
	 * @since 3.0.0
	 */
	GUser findUser(String companyCode, String id) throws  GResourceProcessingException;
}
