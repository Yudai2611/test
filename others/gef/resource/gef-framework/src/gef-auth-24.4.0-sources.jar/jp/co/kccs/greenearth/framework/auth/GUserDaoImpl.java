/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;
import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.catchConnection;
import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.releaseConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.utils.GJdbcUtil;

/**
 * ユーザー情報アクセス用のデータアクセスオブジェクトです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class GUserDaoImpl implements GUserDao {

	/** ユーザーマスタ */
	protected static final String USER_MASTER = "UserMaster";

	/** 会社コード */
	protected static final String COMPANYCD = "CompanyCD";

	/** ユーザーID */
	protected static final String USER_ID = "ID";

	/** ユーザー名 */
	protected static final String USER_NAME = "Name";

	/** パスワード */
	protected static final String PASSWORD = "Password";

	/** 状態 */
	protected static final String STATUS = "Status";

	/** 外部キー（ユーザー組織マップ） */
	protected static final String ORGANIZATION_KEY = "OrganizationKey";

	/** 外部キー（ユーザー職位マップ） */
	protected static final String RANK_KEY = "RankKey";

	/** 組織ID（ユーザー組織マップ） */
	protected static final String ORGANIZATION_ID = "OrganizationID";

	/** 職位ID（ユーザー職位マップ） */
	protected static final String RANKID = "RankID";

	/** 会社DAO. */
	private GCompanyDao _companyDao = null;

	/** グループDAOマップ. */
	private Map<String, GGroupDao> _groupDaoMap = null;

	private Map<String, GUser> _userMap = new HashMap<String, GUser>();

	/**
	 * 会社DAOを指定して{@link GUserDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @param companyDao
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GUserDaoImpl(GCompanyDao companyDao) {
		_companyDao = companyDao;
	}

	/**
	 * 会社DAOとグループDAOリストを指定して{@link GUserDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @param companyDao
	 * @param groupDaoMap
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GUserDaoImpl(GCompanyDao companyDao, Map<String, GGroupDao> groupDaoMap) {
		_companyDao = companyDao;
		_groupDaoMap = groupDaoMap;
	}

	/**
	 * {@link GUser}を生成します。
	 *
	 * @create 2020/6/23
	 * @return GUser
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GUser createUser() {
		return new GUserImpl();
	}

	/**
	 * 組織情報を含めてユーザ情報を検索します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param id ユーザID
	 * @return ユーザ情報(組織情報含む)
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public GUser findUser(String companyCD, String id) throws GResourceProcessingException {

		String key = companyCD + "_" + id;
		if (_userMap.containsKey(key)) {
			return _userMap.get(key);
		}

		GUser user = null;
		Connection conn = null;

		try {
			conn = catchConnection();
			// ユーザ情報の取得
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("companyCD", companyCD);
			params.put("id", id);

			List<GRecord> list = select(USER_MASTER)
					.leftOuterJoinFK(ORGANIZATION_KEY)
					.leftOuterJoinFK(RANK_KEY)
					.where(expMap($("#" + COMPANYCD + " = :companyCD AND #" + USER_ID + " = :id"), params))
					.findList();
			if (list.size() == 0) {
				return null;
			} else {
				GRecord record = list.get(0);
				user = createUser();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				user.setLocaleNameMap(nameMap);
				user.setId(id);
				user.setName(record.getString(USER_NAME));
				user.setPassword(record.getString(PASSWORD));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					user.setStatus(GStatus.Active);
				} else {
					user.setStatus(GStatus.Stop);
				}
				// 会社情報の取得
				GCompany company = null;
				if (_companyDao != null) {
					company = _companyDao.findCompany(companyCD);
					// 会社がnull、または停止状態の場合は、どの会社にも所属していないと見なす
					// 会社に所属していないユーザーは停止状態と見なしnullを返す
					if (company == null || company.isInvalid()) {
						return null;
					}
					user.setCompany(company);
				}

				for (GRecord groupRecord : list) {

					// 組織情報の取得
					String organizationID = groupRecord.getString(ORGANIZATION_ID);
					if (organizationID != null) {
						GGroupDao dao = _groupDaoMap.get("Organization");
						GGroup organization = dao.findGroup(companyCD, organizationID);

						// 組織が停止状態のものは設定しない
						if (organization != null && !organization.isInvalid()) {
							user.addGroup("Organization", organization);
						}
					}

					// 職位情報の取得
					String rankID = groupRecord.getString(RANKID);
					if (rankID != null) {
						GGroupDao dao = _groupDaoMap.get("Rank");
						GGroup rank = dao.findGroup(companyCD, rankID);

						// 職位が停止状態のものは設定しない
						if (rank != null && !rank.isInvalid()) {
							user.addGroup("Rank", rank);
						}
					}
				}

				// 組織に所属していないユーザーは停止状態と見なしnullを返す
				List<GGroup> groupList = user.getGroup("Organization");
				if(groupList==null || groupList.isEmpty()){
					return null;
				}
				// ランクに所属していないユーザーは停止状態と見なしnullを返す
				List<GGroup> rankList = user.getGroup("Rank");
				if(rankList==null || rankList.isEmpty()){
					return null;
				}
//				if (user.getGroup("Organization").isEmpty()) {
//					return null;
//				}
			}

			_userMap.put(key, user);

			return user;
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(conn);
		}
	}

}
