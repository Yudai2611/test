/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.collection.GEmptyIterator;

/**
 * {@link GUser}インターフェースの実装クラスです.
 * 
 * @author fujimura
 * @since 2010/09/22
 */
public class GUserImpl implements GUser {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = -7969657744058504027L;

	/** 値がバインドされていない場合に返す{@link Iterator}. */
	protected static final Iterator<String> EMPTY_ITERATOR = new GEmptyIterator<String>();

	/** 会社情報を表すオブジェクト. */
	private GCompany _company = null;
	/** ユーザID. */
	private String _id = null;
	/** ユーザ名を保持するMap */
	private Map<Locale, String> _localeNameMap = new HashMap<Locale, String>();
	/** パスワード. */
	private String _password = null;
	/** 状態 */
	private GStatus _status = GStatus.Active;
	/** 追加情報. */
	private Map<String, Object> _values = null;
	/** ユーザが所属するグループ */
	private Map<String, List<GGroup>> _groupMatrix = new HashMap<String, List<GGroup>>();
	/** ロケール */
	private Locale _locale = null;

	/**
	 * {@link GUserImpl}クラスの新しいインスタンスを初期化します.
	 * 
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public GUserImpl() {
	}

	/**
	 * 会社情報オブジェクトを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getCompany()
	 * @return 会社情報オブジェクト
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public GCompany getCompany() {
		return _company;
	}

	/**
	 * 会社情報オブジェクトを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setCompany(jp.co.kccs.greenearth.framework.auth.GCompany)
	 * @param company 会社情報
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public void setCompany(GCompany company) {
		_company = company;
	}

	/**
	 * ユーザIDを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getId()
	 * @return ユーザID
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public String getId() {
		return _id;
	}

	/**
	 * ユーザIDを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setId(java.lang.String)
	 * @param id ユーザID
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public void setId(String id) {
		_id = id;
	}

	/**
	 * ユーザ名を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getName()
	 * @return ユーザ名
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public String getName() {
		return _localeNameMap.get(GFrameworkUtils.getDefaultLocale());
	}

	/**
	 * ユーザ名を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setName(java.lang.String)
	 * @param name ユーザ名
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public void setName(String name) {
		_localeNameMap.put(GFrameworkUtils.getDefaultLocale(), name);
	}

	/**
	 * ロケールを指定してユーザ名を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getName(java.util.Locale)
	 * @param locale ロケール
	 * @return ユーザ名
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public String getName(Locale locale) {
		return _localeNameMap.get(locale);
	}

	/**
	 * ユーザ名を保持する{@link Map}を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getLocaleNameMap()
	 * @return ユーザ名の{@link Map}
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public Map<Locale, String> getLocaleNameMap() {
		return _localeNameMap;
	}

	/**
	 * ユーザ名を保持する{@link Map}を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setLocaleNameMap(java.util.Map)
	 * @param map ユーザ名の{@link Map}
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public void setLocaleNameMap(Map<Locale, String> map) {
		_localeNameMap = map;
	}

	/**
	 * パスワードを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getPassword()
	 * @return パスワード
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public String getPassword() {
		return _password;
	}

	/**
	 * パスワードを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setPassword(java.lang.String)
	 * @param password パスワード
	 * @author fujimura
	 * @since 2010/09/16
	 * @since 3.9.0
	 */
	public void setPassword(String password) {
		_password = password;
	}

	/**
	 * このユーザの停止状態を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#isInvalid()
	 * @return 停止フラグ
	 * @author fujimura
	 * @since 2010/09/16
	 */
	public boolean isInvalid() {
		// ユーザ
		if (GStatus.Stop == getStatus()) {
			return true;
		}

		// 会社
		GCompany company = getCompany();
		if (company != null && company.isInvalid()) {
			return true;
		}

		// グループ
		for (String categoryKey : getGroupMatrix().keySet()) {
			List<GGroup> groups = getGroup(categoryKey);
			if (groups == null) {
				continue;
			}
			for (GGroup group : groups) {
				if (group.isInvalid()) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * このユーザの状態を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setStatus(jp.co.kccs.greenearth.framework.auth.GStatus)
	 * @param status 状態
	 * @create 2011/05/24
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void setStatus(GStatus status) {
		_status = status;
	}

	/**
	 * このユーザの状態を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getStatus()
	 * @return 状態
	 * @create 2011/05/24
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public GStatus getStatus() {
		return _status;
	}

	/**
	 * 指定されたキーでこのユーザにバインドされたオブジェクトを返します.<br>
	 * その名前でバインドされたオブジェクトがない場合は、<code>null</code>を返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getValue(java.lang.String)
	 * @create 2010/09/24
	 * @param key キー
	 * @return オブジェクト
	 * @author fujimura
	 * @since 3.9.0
	 */
	public Object getValue(String key) {
		if (_values == null) {
			return null;
		}
		return _values.get(key);
	}

	/**
	 * このユーザにバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの{@link Iterator}
	 * を返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getValueKeys()
	 * @create 2010/09/24
	 * @return このユーザにバインドされたすべてのオブジェクトのキーが格納された、{@link String}オブジェクトの
	 *         {@link Iterator}
	 * @author fujimura
	 * @since 3.9.0
	 */
	public Iterator<String> getValueKeys() {
		if (_values != null) {
			return _values.keySet().iterator();
		} else {
			return EMPTY_ITERATOR;
		}
	}

	/**
	 * 指定されたキーでバインドされたオブジェクトをこのユーザから削除します.<br>
	 * ユーザに指定されたキーでバインドされたオブジェクトがない場合、このメソッドは何も実行しません.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#removeValue(java.lang.String)
	 * @param key このユーザから削除されるオブジェクトのキー
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public void removeValue(String key) {
		if (_values != null) {
			_values.remove(key);

			if (_values.size() == 0) {
				_values = null;
			}
		}
	}

	/**
	 * 指定された名前を使用して、オブジェクトをこのユーザにバインドします.<br>
	 * 同じ名前のオブジェクトがすでにユーザにバインドされている場合は、オブジェクトが置き換えられます.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setValue(java.lang.String,
	 *      java.lang.Object)
	 * @create 2010/09/24
	 * @param name オブジェクトがバインドされる名前：<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public void setValue(String name, Object value) {
		// nullの場合は削除
		if (value == null) {
			removeValue(name);
		}

		if (_values == null) {
			_values = new HashMap<String, Object>();
		}
		_values.put(name, value);
	}

	/**
	 * 指定したキーで、ユーザーが所属するグループを複数追加します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#addGroup(java.lang.String,
	 *      java.util.List)
	 * @param categoryKey キー
	 * @param grouplist グループ情報(複数)
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0ce
	 */
	public void addGroup(String categoryKey, List<GGroup> grouplist) {
		if (!_groupMatrix.containsKey(categoryKey) || _groupMatrix.get(categoryKey) == null) {
			_groupMatrix.put(categoryKey, new ArrayList<GGroup>());
		}
		_groupMatrix.get(categoryKey).addAll(grouplist);

	}

	/**
	 * 指定したキーで、ユーザーが所属するグループを追加します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#addGroup(java.lang.String,
	 *      jp.co.kccs.greenearth.framework.auth.GGroup)
	 * @param categoryKey キー
	 * @param group グループ
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public void addGroup(String categoryKey, GGroup group) {
		if (!_groupMatrix.containsKey(categoryKey) || _groupMatrix.get(categoryKey) == null) {
			_groupMatrix.put(categoryKey, new ArrayList<GGroup>());
		}
		_groupMatrix.get(categoryKey).add(group);
	}

	/**
	 * キーを指定して、所属するグループを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getGroup(java.lang.String)
	 * @param categoryKey キー
	 * @return グループ
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public List<GGroup> getGroup(String categoryKey) {
		return _groupMatrix.get(categoryKey);
	}

	/**
	 * 所属する全グループを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getGroupMatrix()
	 * @return 所属する全グループ
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public Map<String, List<GGroup>> getGroupMatrix() {
		return _groupMatrix;
	}

	/**
	 * ロケールを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getLocale()
	 * @return ロケール
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public Locale getLocale() {
		return _locale;
	}

	/**
	 * ロケールを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#setLocale(java.util.Locale)
	 * @param locale ロケール
	 * @create 2010/09/24
	 * @author fujimura
	 * @since 3.9.0
	 */
	public void setLocale(Locale locale) {
		_locale = locale;
	}
	
	/**
	 * 指定したインデックス番号でユーザを登録します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#addGroup(int, jp.co.kccs.greenearth.framework.auth.GGroup)
	 * @create 2007/06/08
	 * @param index インデックス
	 * @param group グループ
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public void addGroup(int index, GGroup group) {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * 指定したインデックス番号でグループマップを登録します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#addGroupMap(int, java.util.Map)
	 * @create 2007/06/08
	 * @param index インデックス
	 * @param groupMap グループマップ
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public void addGroupMap(int index, Map<String, GGroup> groupMap) {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * グループを全て登録解除します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#clearGroupAll()
	 * @create 2007/06/08
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public void clearGroupAll() {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * 指定されたインデックス番号で登録されているグループの登録を解除します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#clearGroupMap(int)
	 * @create 2007/06/08
	 * @param index インデックス
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public void clearGroupMap(int index) {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * 指定されたインデックス番号のグループマップに、指定されたキー名のグループが登録されているか確認します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#containsGroupKey(int, java.lang.String)
	 * @create 2007/06/08
	 * @param index インデックス
	 * @param key グループキー
	 * @return <core>true</core>/<core>false</core>
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public boolean containsGroupKey(int index, String key) {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * ユーザに登録されたグループ情報を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getGroup(int, java.lang.String)
	 * @create 2007/06/08
	 * @param index インデックス
	 * @param groupId グループID
	 * @return グループ情報
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public GGroup getGroup(int index, String groupId) {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * ユーザに登録されたグループマップの個数を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getGroupCount()
	 * @create 2007/06/08
	 * @return グループマップ数
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public int getGroupCount() {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * 指定したインデックス番号で登録されているグループマップを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#getGroupMap(int)
	 * @create 2007/06/08
	 * @param index インデックス番号
	 * @return グループマップ
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public Map<String, GGroup> getGroupMap(int index) {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}

	/**
	 * 指定されたインデックスのグループマップの中から、指定されたIDのグループを削除します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GUser#removeGroup(int, java.lang.String)
	 * @create 2007/06/08
	 * @param index グループインデックス
	 * @param groupId グループID
	 * @author kitamura
	 * @since 3.1.0
	 */
	@Deprecated
	public void removeGroup(int index, String groupId) {
		throw new UnsupportedOperationException(
			"Mounting the group management that makes the category a key is not supported.");
	}
}
