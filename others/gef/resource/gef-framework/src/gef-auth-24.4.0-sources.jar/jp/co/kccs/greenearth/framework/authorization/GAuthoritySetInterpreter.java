/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.auth.GGroup;
import jp.co.kccs.greenearth.framework.auth.GUser;
import bsh.EvalError;
import bsh.Interpreter;


public class GAuthoritySetInterpreter {
	
	/** ユーザ */
	protected static final String USER_PREFIX = "User";
	protected static final String USER_DOT_PREFIX = USER_PREFIX + ".";
	/** グループ */
	protected static final String GROUP_PREFIX = "Group";
	protected static final String GROUP_DOT_PREFIX = GROUP_PREFIX + ".";
	/** ロール */
	protected static final String ROLE_PREFIX = "Role";
	protected static final String ROLE_DOT_PREFIX = ROLE_PREFIX + ".";
	/** AND　 */
	protected static final String OP_AND = "&&";
	/** OR */
	protected static final String OP_OR = "||";
	/** 右括弧　 */
	protected static final String PARENTHESIS_RIGHT = ")";	
	/** 二重右括弧　 */
	protected static final String DOUBLE_PARENTHESIS_RIGHT = "))";
	/** TRUE */
	protected static final String TRUE = "true";
	/** FALSE */
	protected static final String FALSE = "false";
	// TODO [2012/06/05][harada]EM課題対応 Edit Start
	protected static final String REGULAR = "(" + USER_PREFIX + "|" + GROUP_PREFIX + "|" + ROLE_PREFIX + ")\\.[^&)|]+?((&&)|\\)|(\\|\\|)|$)";
//	protected static final String REGULAR = "(" + USER_PREFIX + "|" + GROUP_PREFIX + "|" + ROLE_PREFIX + ")\\..*?((&&)|\\)|(\\|\\|)|$)";
	// TODO [2012/06/05][harada]EM課題対応 Edit End
	protected static final Pattern PATTERN = Pattern.compile(REGULAR);
	
	public GAuthoritySetInterpreter() {
	}
	
	/**
	 * 与えられた権限集合より、ユーザーのアクセス権限の有無を判断します.<br>
	 * 
	 * @param authoritySet
	 * @param user
	 * @return 真偽値
	 * @create 2011/06/12
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	public boolean hasAuthority(String authoritySet, GUser user) {
		if (authoritySet == null) {
			return false;
		}

		GRoleFinder manager = GRoleFinder.Factory.getInstance();	
		Set<String> groupCategorys = user.getGroupMatrix().keySet();
		
		// 空白文字を取り除く
		String authority = authoritySet.replaceAll("\\s", "");
		//ロールに設定ない場合は、権限がないとみなす
		if ("".equals(authority)) {
			return false;
		}
		
		// 正規表現で、ユーザ/グループ/ロールを抽出する。
		// 例：ユーザーフォーマット　User.AAA → AAA;
		// 　 グループフォーマット Group.organization.BBB → BBB;
		// ロールフォーマット　 Role.CCC → CCC;
		Matcher matcher = PATTERN.matcher(authority);
		while (matcher.find()) {
			String exp = matcher.group();
			// ユーザの権限(真偽値)を判断
			if (exp.startsWith(USER_DOT_PREFIX)) {
				String userID = extractID(exp, USER_DOT_PREFIX);
				boolean hasAuthority = user.getId().equals(userID);
				authority = replaceOperand(authority, USER_DOT_PREFIX, userID, hasAuthority);
			}
			// グループの権限(真偽値)を判断
			else if (exp.startsWith(GROUP_DOT_PREFIX)) {
				for (String groupCategory : groupCategorys) {
					int pos = exp.indexOf(groupCategory);
					if (pos == exp.indexOf(".") + 1) {
						String prefix = GROUP_DOT_PREFIX + groupCategory + ".";
						String groupID = extractID(exp, prefix);
						boolean hasAuthority = isGroupExistsInUser(groupID, groupCategory, user);
						authority = replaceOperand(authority, prefix, groupID, hasAuthority);
						if (hasAuthority) {
							break;
						}
					}
				}
			}
			// ロールの権限(真偽値)を判断
			else if (exp.startsWith(ROLE_DOT_PREFIX)) {
				String roleObjectID = extractID(exp, ROLE_DOT_PREFIX);

				// DBに存在するかどうかのチェックを行う場合、存在しない場合はfalseに置き換える
				GRole role = manager.getRole(roleObjectID); 
				boolean hasAuthority = role != null ? role.hasAuthority(user) : false;
				authority = replaceOperand(authority, ROLE_DOT_PREFIX, roleObjectID, hasAuthority);
			}
		}

		return operateAuthority(authority);
	}
	
	/**
	 * 権限集合にある単項目（ユーザー/グループ/ロール）のフォーマットの妥当性を判断します<br>
	 * 
	 * @param authoritySet
	 * @param groupCategorys
	 * @return 真偽値
	 * @create 2011/06/12
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	public boolean validateSyntax(String authoritySet, Set<String> groupCategorys) {
		if (GStringUtils.isEmpty(authoritySet)) {
			return true;
		}

		// 空白文字を取り除く
		String authority = authoritySet.replaceAll("\\s", "");
		
		
		Matcher matcher = PATTERN.matcher(authority);
		while (matcher.find()) {
			String exp = matcher.group();
			// ユーザの権限(真偽値)を判断
			if (exp.startsWith(USER_DOT_PREFIX)) {
				String userID = extractID(exp, USER_DOT_PREFIX);
				authority = replaceOperand(authority, USER_DOT_PREFIX, userID, true);
			}
			// グループの権限(真偽値)を判断
			else if (exp.startsWith(GROUP_DOT_PREFIX)) {
				for (String groupCategory : groupCategorys) {
					int pos = exp.indexOf(groupCategory);
					if (pos == exp.indexOf(".") + 1) {
						String prefix = GROUP_DOT_PREFIX + groupCategory + ".";
						// TODO [2012/06/05][harada]EM課題対応 ADD Start
						if (prefix.length() >= exp.length()) 
						{
							return false;
						}
						// TODO [2012/06/05][harada]EM課題対応 ADD End
						String groupID = extractID(exp, prefix);
						authority = replaceOperand(authority, prefix, groupID, true);
					}
				}
			}
			// ロールの権限(真偽値)を判断
			else if (exp.startsWith(ROLE_DOT_PREFIX)) {
				String roleID = extractID(exp, ROLE_DOT_PREFIX);
				authority = replaceOperand(authority, ROLE_DOT_PREFIX, roleID, true);
			}
		}

		return validateAuthoritySet(authority);
	}

	public List<String> extractRoleIDs(String authoritySet) {

		List<String> roleIDlist = new ArrayList<String>();
		if (authoritySet == null) {
			return roleIDlist;
		}
		
		authoritySet = authoritySet.replaceAll("\\s", "");

		// 正規表現で、ロールを抽出する。
		// 例：ロールフォーマット　 Role.CCC → CCC;
		String r = "(" + ROLE_PREFIX + ")\\..*?((&&)|\\)|(\\|\\|)|$)";
		Pattern pattern = Pattern.compile(r);
		Matcher matcher = pattern.matcher(authoritySet);
		String rolePrefix = ROLE_PREFIX + ".";

		while (matcher.find()) {
			String tempStr = matcher.group();
			// ロール名の抽出
			String roleIDTemp = extractID(tempStr, rolePrefix);
			roleIDlist.add(roleIDTemp);
		}

		return roleIDlist;

	}
	
	/**
	 * ユーザID/グループID/ロールIDを抽出します.
	 * 
	 * @param tempStr
	 * @param prefix
	 * @return ユーザID/グループID/ロールID
	 * @author KCCS kyo
	 * @since 2010/10/15
	 */
	private String extractID(String tempStr, String prefix) {
		String nameTemp = null;
		if (tempStr.endsWith(DOUBLE_PARENTHESIS_RIGHT)) {
			nameTemp = tempStr.substring(prefix.length(), tempStr.length() - 2);
		} else if (tempStr.endsWith(PARENTHESIS_RIGHT)) {
			nameTemp = tempStr.substring(prefix.length(), tempStr.length() - 1);
		} else if (tempStr.endsWith(OP_AND) || tempStr.endsWith(OP_OR)) {
			nameTemp = tempStr.substring(prefix.length(), tempStr.length() - 2);
		} else {
			nameTemp = tempStr.substring(prefix.length(), tempStr.length());
		}
		return nameTemp;
	}

	/**
	 * ユーザが所属するグループに権限セットに指定されるかのチェック
	 * 
	 * @param user
	 * @param searchID
	 * @return 真偽値 true:権限あり/false:権限なし
	 * @create 2010/11/05
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	private boolean isGroupExistsInUser(String searchID, String groupCategory, GUser user) {

		boolean flag = false;

		// ユーザーが設定したグループ名を取得
		List<GGroup> grouplist = user.getGroup(groupCategory);
		if (grouplist != null) {
			for (GGroup group : grouplist) {
				flag = isGroupExistsInGroup(searchID, group);
				// 指定したグループがあればbreakする
				if (flag) {
					break;
				}
			}
		}
		return flag;
	}

	/**
	 * グループに指定されたグループの存在の確認.
	 * 
	 * @param group グループ
	 * @param groupName　グループ名
	 * @return　true/false
	 * @author KCCS kyo
	 * @since 2010/10/15
	 */
	private boolean isGroupExistsInGroup(String searchID, GGroup group) {
		if (group == null) {
			return false;
		}
		if (group.getId().equals(searchID)) {
			return true;
		}
		if (isGroupExistsInGroup(searchID, group.getParent())) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * 権限セットを適切な値(true/false)に置き換える.
	 * 
	 * @param authoritySet
	 * @param prefix
	 * @param id
	 * @param hasAuthority
	 * @create 2010/11/05
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	private String replaceOperand(String authoritySet, String prefix, String id, boolean hasAuthority) {
		if (hasAuthority) {
			return authoritySet.replaceFirst(prefix + id, TRUE);
		} else {
			return authoritySet.replaceFirst(prefix + id, FALSE);
		}
	}
	
	/**
	 * 権限詳細のチェックを行います.<br>
	 * 
	 * @param authoritySet
	 * @param flag
	 * @return true/false
	 * @create 2010/11/05
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	private boolean operateAuthority(String authoritySet) {
		Interpreter interpreter = new Interpreter();

		try {
			return Boolean.valueOf(interpreter.eval(authoritySet).toString());
		} catch (EvalError e) {
			throw new IllegalStateException(e);
		}
	}
	
	/**
	 * 権限集合の式をチェックします.<br>
	 * 
	 * @param authority
	 * @return
	 * @create 2010/11/29
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	private boolean validateAuthoritySet(String authority) {
		Interpreter interpreter = new Interpreter();
		try {
			// TODO [2012/06/05][harada]EM課題対応 Edit Start
//			interpreter.eval(authority);
			if (interpreter.eval(authority) == null)
			{
				return false;
			}
			// TODO [2012/06/05][harada]EM課題対応 Edit End
		} catch (EvalError e) {
			return false;
		}
		return true;
	}
}
