/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import jp.co.kccs.greenearth.commons.GApplicationException;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;


/**
 * 権限がない時、発生する例外です.<br>
 * 
 * @create 2010/10/28
 * @author KCCS kyo
 * @since v3.9.0
 */
public class GAuthorizationException extends GApplicationException {

	/** シリアルバージョンUID  */
	private static final long serialVersionUID = 3141773216656457048L;
	
	
	public GAuthorizationException(GErrorMessage message) {
		super(message);
	}

	public GAuthorizationException(String errorCode, String message) {
		super(errorCode,message);
	}

	public GAuthorizationException(String errorCode, String message, GErrorType type){
		super(errorCode,message,type);
	}
	
	public GAuthorizationException(String errorCode, String message, GErrorType type, String description) {
		super(errorCode,message,type,description);
	}
	
	public GAuthorizationException(String errorCode, String message, Throwable cause) {
		super(errorCode,message,cause);
	}
	public GAuthorizationException(String errorCode, String message, GErrorType type, Throwable cause) {
		super(errorCode,message,type,cause);
	}
	
	public GAuthorizationException(String errorCode, String message, GErrorType type, String description, Throwable cause) {
		super(errorCode,message,type,description,cause);
	}
	
	public GAuthorizationException(GErrorMessage message, Throwable cause) {
		super(message,cause);
	}
	
	public GAuthorizationException(GErrorMessage message, String description, Throwable cause) {
		super(message,description,cause);
	}
	
}
