/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.util.Date;

/**
 * EnterpriseManagerV3用に{@link GRole}を拡張したインタフェースです。
 * 
 * @create 2011/05/11
 * @author KCCS kitamura
 * @since 3.9.0
 */
public interface GEditableRole extends GRole {
	
	/**
	 * オブジェクトIDを設定します.
	 * 
	 * @param objectID オブジェクトID
	 * @author KCCS kyo
	 * @since 2010/10/10
	 */
	void setObjectID(String objectID);

	/**
	 * 備考を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 備考
	 * @author kyo
	 * @since 3.9.0
	 */
	String getDescription();
	
	/**
	 * 備考を設定します.
	 * 
	 * @param description 備考
	 * @create 2010/09/08
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void setDescription(String description);

	/**
	 * 更新日を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 更新日
	 * @author kyo
	 * @since 3.9.0
	 */
	Date getUpdatedDate();
	
	/**
	 * 更新日を設定します.	 
	 * 
	 * @param updateDate 更新日
	 * @create 2010/09/08 
	 * @author kyo
	 * @since 3.9.0
	 */
	void setUpdatedDate(Date updateDate);


	/**
	 * 更新者を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 更新者
	 * @author kyo
	 * @since 3.9.0
	 */
	String getUpdatedPerson();

	/**
	 * 更新者を設定します.
	 * 
	 * @param updatePerson 更新者
	 * @create 2010/09/08 
	 * @author kyo
	 * @since 3.9.0
	 */
	void setUpdatedPerson(String updatePerson);

	/**
	 * 排他キーを取得します.
	 * 
	 * @return ハイ他キー
	 * @since 2010/10/10
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	String getExclusiveKey();
	
	/**
	 * 排他キーを設定します.
	 * @param exclusiveKey 排他キー
	 * @create 2010/10/25
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void setExclusiveKey(String exclusiveKey);

	/**
	 * リソースIDを取得します.
	 * 
	 * @return リソースID
	 * @author KCCS kyo
	 * @create 2010/10/10
	 * @since 3.9.0
	 */
	String getDisplayNameResourceID();

	/**
	 * 表示名のリソースIDを設定します.
	 * 
	 * @param displayNameResourceID 表示名リソースID
	 * @create 2010/10/25
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void setDisplayNameResourceID(String displayNameResourceID);
}
