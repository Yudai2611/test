/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GExternalDataSet;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * {@link GRoleDao}を拡張し、EnterpriseManagerV3用に機能を追加したインターフェースです。
 * 
 * @create 2011/05/28
 * @author KCCS kitamura
 * @since 3.9.0
 */
public interface GEditableRoleDao extends GRoleDao {

	/**
	 * 引数に指定した条件のロールの件数を取得します.
	 * 
	 * @param companyCode 会社コード
	 * @param likeRoleID 曖昧検索用ロールID
	 * @param likeRoleName 曖昧検索用ロール名
	 * @return 件数
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @create 2011/05/28
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	int countRole(String companyCode, String likeRoleID, String likeRoleName) throws GResourceProcessingException;

	/**
	 * 引数に指定した条件のロールリストを取得します.
	 * 
	 * @param companyCode 会社コード
	 * @param likeRoleID 曖昧検索用ロールID
	 * @param likeRoleName 曖昧検索用ロール名
	 * @param startIndex 開始番号
	 * @param listSize リストのサイズ
	 * @return ロールリスト
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @create 2011/05/28
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	List<GEditableRole> findRoleList(String companyCode, String likeRoleID, String likeRoleName, int startIndex, int listSize) throws GResourceProcessingException;
	
	/**
	 * 引数に指定した条件のロールセットを取得します。
	 * 
	 * @param companyCode 会社コード
	 * @param likeRoleID 曖昧検索用ロールID
	 * @param likeRoleName 曖昧検索用ロール名
	 * @return ロールセット
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @create 2011/05/28
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	GExternalDataSet<GEditableRole> findRoleSet(String companyCode, String likeRoleID, String likeRoleName) throws GResourceProcessingException;

	/**
	 * ロールを登録します.
	 * 
	 * @param role ロール
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @throws GOptimisticLockException 楽観的排他エラー
	 * @create 2011/05/28
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void insertRole(GEditableRole role) throws GResourceProcessingException, GOptimisticLockException;

	/**
	 * ロールを更新します.
	 * 
	 * @param role ロール
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @throws GOptimisticLockException 楽観的排他エラー
	 * @create 2011/05/28
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void updateRole(GEditableRole role) throws GResourceProcessingException, GOptimisticLockException;

	/**
	 * リスト内のロールを削除します.
	 * 
	 * @param roleList ロールリスト
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @throws GOptimisticLockException 楽観的排他エラー
	 * @create 2011/05/28
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void deleteRoleList(List<GEditableRole> roleList) throws GResourceProcessingException, GOptimisticLockException;

	/**
	 * 引数で指定した会社コードのロールを全件削除します.
	 * 
	 * @param companyCode 会社コード
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @create 2010/11/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	void deleteRoleAll(String companyCode) throws GResourceProcessingException;

	/**
	 * ロールを生成します
	 * 
	 * @return ロール
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableRole createRole();

	/**
	 * {@link GEditableRoleDao}クラスの実態を生成するファクトリクラスです.
	 * 
	 * @create 2011/05/28
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public static class Factory {
		
		/**
		 * デフォルトコンストラクタ.
		 * 
		 * @create 2011/09/08
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public Factory() {
		}
		
		/**
		 * {@link GEditableRoleDao}の実態を生成します.
		 * 
		 * @return ロールDao
		 * @create 2011/05/28
		 * @author KCCS kitamura
		 * @since 3.9.0
		 */
		public static GEditableRoleDao getInstance() {
			return (GEditableRoleDao) GFrameworkUtils.getComponent(GRoleDao.class.getName());
		}
	}
}
