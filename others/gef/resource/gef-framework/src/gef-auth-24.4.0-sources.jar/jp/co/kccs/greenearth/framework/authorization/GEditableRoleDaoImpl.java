/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.commons.exception.GAlreadyUpdatedException;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * {@link GEditableRoleDao}をGjdbcで実装したクラスです。<br>
 *
 * @author KCCS K.Fujita
 * @create 2013/07/20
 * @since 3.12.0
 */
public class GEditableRoleDaoImpl extends GEditableRoleNoTxDaoImpl {

	/**
	 * GERoleテーブルにレコードを新規登録します.<br>
	 *
	 * @param role 登録するロール
	 * @throws GResourceProcessingException 登録処理で例外が発生した場合
	 * @throws GOptimisticLockException 登録処理が一意制約違反に反する場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	@Override
	public void insertRole(GEditableRole role) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			insertRole(role, connection);

			commitTransaction(connection);
		} catch (GOptimisticLockException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * GERoleテーブルから複数件のレコードを削除します.<br>
	 *
	 * @param roleList 削除するロールのリスト
	 * @throws GResourceProcessingException 削除処理で例外が発生した場合
	 * @throws GOptimisticLockException 楽観的排他制御により削除が行えなかった場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	@Override
	public void deleteRoleList(List<GEditableRole> roleList) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			for (GEditableRole role : roleList) {
				deleteRole(role, connection);
			}
			commitTransaction(connection);
		} catch (GOptimisticLockException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * GERoleテーブルのレコードを更新します.<br>
	 *
	 * @param role 更新するロール
	 * @throws GResourceProcessingException 更新処理で例外が発生した場合
	 * @throws GOptimisticLockException 楽観的排他制御により更新が行えなかった場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	@Override
	public void updateRole(GEditableRole role) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			updateRole(role, connection);

			commitTransaction(connection);
		} catch (GAlreadyUpdatedException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * ロール情報を全件削除するメソッドです。<br>
	 * 引数に会社コードが指定された場合、該当の会社コードに紐づくロール情報とリソース情報を削除します。<br>
	 *
	 * @param companyCode 会社コード
	 * @throws GResourceProcessingException 削除処理中に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	@Override
	public void deleteRoleAll(String companyCode) throws GResourceProcessingException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			// GERoleテーブルの削除
			delete(GEROLE)
			.where(exp($("#CompanyCode = [?]"), new Object[]{companyCode}))
			.execute(connection);

			// GERoleLocalizationResourceテーブルの削除
			delete(GERoleLocalizationResource)
			.where(exp($("#CompanyCode = ?"), new Object[]{companyCode}))
			.execute(connection);

			commitTransaction(connection);

		} catch (SQLException e) {
			rollbackTransaction(connection);
			throw new GResourceProcessingException(e);
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * 指定された接続に対してトランザクションを開始します.<br>
	 *
	 * @param connection コネクション
	 * @throws GResourceProcessingException トランザクション処理中の例外
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	protected void beginTransaction(Connection connection) throws GResourceProcessingException {
		try {
			GConnectionManager connManager = GConnectionManager.getInstance();
			connManager.beginTransaction(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 指定された接続のトランザクションをロールバックします.<br>
	 *
	 * @param connection コネクション
	 * @throws GResourceProcessingException トランザクション処理中の例外
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	protected void rollbackTransaction(Connection connection) throws GResourceProcessingException {
		try {
			GConnectionManager connManager = GConnectionManager.getInstance();
			connManager.rollbackTransaction(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 指定された接続のトランザクションをコミットします.<br>
	 *
	 * @param connection コネクション
	 * @throws GResourceProcessingException トランザクション処理中の例外
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	protected void commitTransaction(Connection connection) throws GResourceProcessingException {
		try {
			GConnectionManager connManager = GConnectionManager.getInstance();
			connManager.commitTransaction(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

}
