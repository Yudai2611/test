/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.util.Date;


public class GEditableRoleImpl extends GRoleImpl implements GEditableRole {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = -6945724817712938003L;
	/** 備考. */
	private String _description = null;
	/** 更新日. */
	private Date _updateDate = null;
	/** 更新者. */
	private String _updatedPerson = null;
	/** 排他キー. */
	private String _exclusiveKey = null;
	/** 表示名リソースキー. */
	private String _displayNameResourceID = null;
	
	public GEditableRoleImpl() {
	}

	/**
	 * 備考を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 備考
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getDescription() {
		return _description;
	}
	
	/**
	 * 備考をセットします.
	 * 
	 * @create 2010/09/08
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setDescription(String description) {	
		_description = description;
	}

	/**
	 * 更新日を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 更新日
	 * @author kyo
	 * @since 3.9.0
	 */
	public Date getUpdatedDate() {	
		return _updateDate;
	}
	
	/**
	 * 更新日をセットします.
	 * 
	 * @create 2010/09/08
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setUpdatedDate(Date updateDate) {
		_updateDate = updateDate;
	}

	/**
	 * 更新者を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 更新者
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getUpdatedPerson() {
		return _updatedPerson;
	}
	
	/**
	 * 更新者をセットします.
	 * 
	 * @create 2010/09/08
	 * @return 更新者
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setUpdatedPerson(String updatedPerson) {
		_updatedPerson = updatedPerson;
	}

	/**
	 * 排他キーを取得します.
	 * 
	 * @create 2010/09/08
	 * @return 更新者
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getExclusiveKey() {
		return _exclusiveKey;
	}
	
	/**
	 * 排他フラグをセットします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRole#setExclusiveKey(java.lang.String)
	 * @param exclusiveKey
	 * @author KCCS kyo
	 * @since 2010/10/06
	 */
	public void setExclusiveKey(String exclusiveKey) {	
		_exclusiveKey = exclusiveKey;
	}

	/**
	 * リソースIDを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRole#getDisplayNameResourceID()
	 * @return
	 * @author KCCS kyo
	 * @since 2010/10/10
	 */
	public String getDisplayNameResourceID() {
		return _displayNameResourceID;
	}

	/**
	 * リソースIDをセットします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRole#setDisplayNameResourceID(java.lang.String)
	 * @param displayNameResourceID
	 * @author KCCS kyo
	 * @since 2010/10/10
	 */
	public void setDisplayNameResourceID(String displayNameResourceID) {
		_displayNameResourceID = displayNameResourceID;
	}
}
