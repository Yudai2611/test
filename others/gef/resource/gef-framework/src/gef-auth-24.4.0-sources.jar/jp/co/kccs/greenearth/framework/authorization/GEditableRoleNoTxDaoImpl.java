/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.data.GExternalDataSet;
import jp.co.kccs.greenearth.commons.exception.GAlreadyInsertedException;
import jp.co.kccs.greenearth.commons.exception.GAlreadyUpdatedException;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordImpl;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.sql.GUniqueConstraintException;

/**
 * {@link GEditableRoleDao}の実装クラスです。<br>
 * 
 * @author KCCS K.Fujita
 * @create 2013/07/20
 * @since 3.12.0
 */
public class GEditableRoleNoTxDaoImpl extends GRoleDaoImpl implements GEditableRoleDao {
	
	/** GERoleLocalizationResourceテーブルの名前 */
	protected static final String GERoleLocalizationResource = "GERoleLocalizationResource";
	
	/* GERoleテーブルの項目 */
	/** オブジェクトIDを表す項目 */
	protected static final String OBJECTID = "ObjectID";
	/** 説明を表す項目 */
	protected static final String DESCRIPTION = "Description";
	/** 更新日を表す項目 */
	protected static final String UPDATED_DT = "UpdatedDate";
	/** 更新者を表す項目 */
	protected static final String UPDATED_PERSON = "UpdatedPerson";
	/** 排他キーを表す項目 */
	protected static final String EXCLUSIVE_FG = "ExclusiveFG";
	
	/**
	 * 検索条件にヒットするロールの数を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GEditableRoleDao#countRole(java.lang.String,
	 *      java.lang.String, java.lang.String, java.util.Locale)
	 * @param companyCode 会社コード（完全一致）
	 * @param likeRoleID ロールID（前方一致）
	 * @param likeResourceValue リソースの値（部分一致）
	 * @return 検索条件にヒットするロールの数
	 * @throws GResourceProcessingException 件数取得時に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public int countRole(String companyCode, String likeRoleID, String likeResourceValue) 
			throws GResourceProcessingException {
		Connection connection = null;
		try {
			connection = catchConnection();
			
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("comp", companyCode);
			paramMap.put("role", likeRoleID);
			paramMap.put("value", likeResourceValue);
			if (likeResourceValue != null) {
				Locale locale = GFrameworkContext.getInstance().getLocale();
				paramMap.put("locale", locale.toString());
			}

			return select(GEROLE, "role")
					.leftOuterJoinFK("ResourceFK", "resource")
					.where(expMap(
								$("#role.CompanyCode = :[comp]")
								.AND("#role.RoleID LIKE :[role%]")
								.AND("#resource.Value LIKE :[%value%]")
								.AND("#resource.Locale = :[locale]"), 
							paramMap))
					.groupBy(col("role.RoleID"))
					.count(connection);
			
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * 検索条件にヒットする{@link GEditableRole}のリストを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GEditableRoleDao#findRoleList(java.lang.String,
	 *      java.lang.String, java.lang.String, int, int)
	 * @param companyCode 会社コード（完全一致）
	 * @param likeRoleID ロールID（前方一致）
	 * @param likeResourceValue リソースの値（部分一致）
	 * @param startIndex 検索結果の開始インデックス
	 * @param listSize 取得する検索結果の件数
	 * @return 検索結果
	 * @throws GResourceProcessingException 検索処理中に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public List<GEditableRole> findRoleList(String companyCode, String likeRoleID, String likeResourceValue, int startIndex, int listSize) throws GResourceProcessingException {
		Connection connection = catchConnection();
		GExternalDataSet<GEditableRole> roleSet = null;
		try {
			List<GEditableRole> roleList = new ArrayList<GEditableRole>();

			roleSet = findRoleSet(companyCode, likeRoleID, likeResourceValue);
			int i = 0;
			while (roleSet.next()) {
				i++;
				// ページングの表示範囲
				if (startIndex <= i && i < startIndex + listSize) {
					roleList.add(roleSet.get());
				}
			}
			return roleList;
		} finally {
			if (roleSet != null) {
				roleSet.close();
			}
			releaseConnection(connection);
		}
	}

	/**
	 * 検索条件にヒットするレコードを{@link GEditableRole}の{@link GExternalDataSet}型で返却します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRoleDao#findRoleSet(java.lang.String)
	 * @param companyCode 会社コード（完全一致）
	 * @param likeRoleID ロールID（前方一致）
	 * @param likeRoleName リソースの値（部分一致）
	 * @return GExternalDataSet 検索結果
	 * @throws GResourceProcessingException 検索処理中に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	@Override
	public GExternalDataSet<GEditableRole> findRoleSet(String companyCode, String likeRoleID, String likeRoleName)
		throws GResourceProcessingException {
		Connection connection = catchConnection();
		GRecordSet recordSet = null;
		try {
			Map<String, Object> subMap = new HashMap<String, Object>();
			subMap.put("comp", companyCode);
			subMap.put("role", likeRoleID);
			if (likeRoleName != null) {
				subMap.put("value", likeRoleName);
				subMap.put("locale", GFrameworkContext.getInstance().getLocale().toString());
			}
			
			recordSet = select(GEROLE, "role")
							.leftOuterJoinFK("ResourceFK", "resource")
							.where(expMap(
										$("#role.CompanyCode = :comp")
										.AND("#role.RoleID LIKE :[role%]")
										.AND("#resource.Value LIKE :[%value%]")
										.AND("#resource.Locale = :[locale]"), 
									subMap))
							.orderBy(asc("role.RoleID"))
							.findRecordSet(connection);
			
			return createRoleSet(connection, recordSet);
			
		} catch (Exception e) {
			try {
				if (recordSet != null) {
					recordSet.close();
				}
			} catch (SQLException ex) {
				throw new GResourceProcessingException(ex);
			} finally {
				releaseConnection(connection);
			}
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * GERoleテーブルにレコードを新規登録します.<br>
	 * 
	 * @param role 登録するロール
	 * @throws GResourceProcessingException 登録処理で例外が発生した場合
	 * @throws GOptimisticLockException 登録処理が一意制約違反に反する場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public void insertRole(GEditableRole role) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			insertRole(role, connection);
		} catch (GOptimisticLockException e) {
			throw e;
		} catch (GResourceProcessingException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * GERoleテーブルにレコードを新規登録します.<br>
	 * 
	 * @param role 登録するロール
	 * @param connection 登録処理で使用するコネクション
	 * @throws GResourceProcessingException 登録処理で例外が発生した場合
	 * @throws GOptimisticLockException 登録処理が一意制約違反に反した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	protected void insertRole(GEditableRole role, Connection connection) throws GResourceProcessingException, GOptimisticLockException {
		// GERoleテーブル
		GRecord record = createRoleRecord(role);
		try {
			insert(GEROLE).values(record).execute(connection);
		} catch (GUniqueConstraintException e) {
			throw new GAlreadyInsertedException(e);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
		// GERoleLocalizationResourceテーブル
		insertResources(role, connection);
	}


	/**
	 * GERoleテーブルから複数件のレコードを削除します.<br>
	 * 
	 * @param roleList 削除するロールのリスト
	 * @throws GResourceProcessingException 削除処理で例外が発生した場合
	 * @throws GOptimisticLockException 楽観的排他制御により削除が行えなかった場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	@Override
	public void deleteRoleList(List<GEditableRole> roleList) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			for (GEditableRole role : roleList) {
				deleteRole(role, connection);
			}
		} catch (GOptimisticLockException e) {
			throw e;
		} catch (GResourceProcessingException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * GERoleテーブル、GERoleLocalizationResourceテーブルからレコードを削除します.<br>
	 * 
	 * @param role 削除するロール
	 * @param connection 削除処理で使用するコネクション
	 * @throws GResourceProcessingException 削除処理で例外が発生した場合
	 * @throws GOptimisticLockException 楽観的排他制御により削除が行えなかった場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	protected void deleteRole(GEditableRole role, Connection connection) throws GResourceProcessingException, GOptimisticLockException {

		// GERoleテーブル
		GRecord record = new GRecordImpl();
		record.setObject(OBJECTID, GStringUtils.blankToNull(role.getObjectID()));
		record.setObject(EXCLUSIVE_FG, GStringUtils.blankToNull(role.getExclusiveKey()));
		
		try {
			delete(GEROLE).wherePK(record).execute(connection);
		} catch (jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException e) {
			throw new GAlreadyUpdatedException(e);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}

		// GERoleLocalizationResourceテーブル
		deleteResources(role, connection);
	}

	/**
	 * GERoleテーブルのレコードを更新します.<br>
	 * 
	 * @param role 更新するロール
	 * @throws GResourceProcessingException 更新処理で例外が発生した場合
	 * @throws GOptimisticLockException 楽観的排他制御により更新が行えなかった場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public void updateRole(GEditableRole role) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			updateRole(role, connection);
		} catch (GAlreadyUpdatedException e) {
			throw e;
		} catch (GResourceProcessingException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * GERoleテーブル、GERoleLocalizationResourceテーブルの値を更新します.<br>
	 * 
	 * @param role 更新するロール
	 * @param connection 更新処理で使用するコネクション
	 * @throws GOptimisticLockException 楽観的排他制御のためGERoleテーブルの更新が行えなかった場合
	 * @throws GResourceProcessingException 更新処理で例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	protected void updateRole(GEditableRole role, Connection connection) throws GResourceProcessingException, GOptimisticLockException {
		// GERoleテーブル
		GRecord record = createRoleRecord(role);
		GEditableRole oldRole = (GEditableRole) findRole(role.getObjectID());
		try {
			update(GEROLE).excludes("ObjectID").set(record).wherePK().execute(connection);
			
		} catch (jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException e) {
			throw new GAlreadyUpdatedException(e);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}

		// GERoleLocalizationResourceテーブル
		deleteResources(oldRole, connection);
		insertResources(role, connection);
	}

	/**
	 * ロールからレコードを生成します.<br>
	 * 
	 * @param role ロール
	 * @return 生成されたレコード
	 * 	@author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	private GRecord createRoleRecord(GEditableRole role) {
		GRecord record = new GRecordImpl();
		record.setObject(OBJECTID, GStringUtils.blankToNull(role.getObjectID()));
		record.setObject(VC_COMPANY_CODE, role.getCompanyCode());
		record.setObject(VC_ROLE_ID, role.getRoleID());
		record.setObject(VC_AUTHORITY_SET, GStringUtils.blankToNull(role.getAuthoritySet()));
		record.setObject(DESCRIPTION, GStringUtils.blankToNull(role.getDescription()));
		record.setObject(UPDATED_PERSON, role.getUpdatedPerson());
		if (role.getUpdatedDate() != null) {
			record.setObject(UPDATED_DT, role.getUpdatedDate());
		}
		record.setObject(VC_DISPLAY_NAME_RESOURCE_ID, GStringUtils.blankToNull(role.getDisplayNameResourceID()));
		record.setObject(EXCLUSIVE_FG, GStringUtils.blankToNull(role.getExclusiveKey()));
		return record;
	}

	/**
	 * GERoleLocalizationResourceテーブルへレコードを登録します.<br>
	 * 
	 * @param role ロール
	 * @param connection コネクション
	 * @throws GResourceProcessingException 登録処理で例外が発生した場合
	 * 	@author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	private void insertResources(GEditableRole role, Connection connection) throws GResourceProcessingException {
		GRecord record = new GRecordImpl();
		Map<Locale, String> map = role.getDisplayNameMap();
		for (Entry<Locale, String> resource : map.entrySet()) {
			record.setObject(VC_COMPANY_CODE, role.getCompanyCode());
			record.setObject(VC_RES_ID, GStringUtils.blankToNull(role.getDisplayNameResourceID()));
			record.setObject(VC_RES_LOCAL, resource.getKey().toString());
			record.setObject(VC_RES_VALUE, GStringUtils.blankToNull(resource.getValue()));
			try {
				insert(GERoleLocalizationResource).values(record).execute(connection);
			} catch (SQLException e) {
				throw new GResourceProcessingException(e);
			}
		}
	}

	/**
	 * GERoleLocalizationResourceテーブルからレコードを削除します.<br>
	 * 
	 * @param role ロール
	 * @param connection コネクション
	 * @throws GResourceProcessingException 削除処理で例外が発生した場合
	 * 	@author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	private void deleteResources(GEditableRole role, Connection connection) throws GResourceProcessingException {
		try {
			delete(GERoleLocalizationResource)
				.where(exp($("#ResourceID = [?]")
								.AND("#CompanyCode = ?"), 
							new Object[]{role.getDisplayNameResourceID(), role.getCompanyCode()})
				)
				.execute(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * ロール情報を全件削除するメソッドです。<br>
	 * 引数に会社コードが指定された場合、該当の会社コードに紐づくロール情報とリソース情報を削除します。<br>
	 * 
	 * @param companyCode 会社コード
	 * @throws GResourceProcessingException 削除処理中に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public void deleteRoleAll(String companyCode) throws GResourceProcessingException {
		Connection connection = catchConnection();
		try {
			// GERoleテーブルの削除
			delete(GEROLE)
				.where(exp($("#CompanyCode = [?]"), new Object[]{companyCode}))
				.execute(connection);
			
			// GERoleLocalizationResourceテーブルの削除
			delete(GERoleLocalizationResource)
				.where(exp($("#CompanyCode = ?"), new Object[]{companyCode}))
				.execute(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public GEditableRole createRole() {
		return new GEditableRoleImpl();
	}

	@Override
	public GEditableRole createRole(List<GRecord> recordlist) {
		GEditableRole role = null;
		if (recordlist.size() > 0) {
			role = (GEditableRole) super.createRole(recordlist);
			GRecord record = recordlist.get(0);

			role.setObjectID(record.getString(OBJECTID));
			role.setDescription(record.getString(DESCRIPTION));
			role.setDisplayNameResourceID(record.getString(VC_DISPLAY_NAME_RESOURCE_ID));
			role.setExclusiveKey(record.getString(EXCLUSIVE_FG));
			role.setUpdatedDate(record.getDate(UPDATED_DT));
			role.setUpdatedPerson(record.getString(UPDATED_PERSON));
		}
		return role;
	}

	/**
	 * 引数に与えられたGDBRecordSetから、GExternalDataSet<GEditableRole>型のロールセットを返却します。<br>
	 * 
	 * @param connection コネクション
	 * @param recordSet レコードセット
	 * @return ロールセット
	 * @throws GResourceProcessingException 生成処理中の例外
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	protected GExternalDataSet<GEditableRole> createRoleSet(Connection connection, GRecordSet recordSet)
		throws GResourceProcessingException {
		return new GEditableRoleSetImpl(connection, recordSet, this);
	}

}
