/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.data.GExternalDataSet;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;

/**
 * {@link GExternalDataSet}インターフェースの実装クラスです.<br>
 * 
 * @author KCCS K.Fujita
 * @create 2013/07/20
 * @since 3.12.0
 */
public class GEditableRoleSetImpl implements GExternalDataSet<GEditableRole>{

	/** 次ロールがあるか */
	private boolean _hasNextRole;
	/** 最初の呼び出しか */
	private boolean _isFirstCall;
	/** GRoleSetを作成するためのGDBRecordSet */
	private GRecordSet _gDBRecordSet;
	/** 現在のロール情報 */
	private GEditableRole _currentRole;
	/** ロール情報と接続するためのクラス */
	private GEditableRoleNoTxDaoImpl _roleDao ;
	
	/** オブジェクトID */
	protected final String OBJECTID = "ObjectID";
	/** GERoleLocalizationResource項目：地域コード */
	protected final String LOCALE = "Locale";
	/** GERoleLocalizationResource項目：値 */
	protected final String VALUE = "Value";
	/** GELocalizationResource項目：キー */
	//private final String RESOURCEID = "DisplayNameResourceID";

	private Connection _connection = null;
	
	
	public GEditableRoleSetImpl(Connection connection, GRecordSet recordSet, GEditableRoleNoTxDaoImpl roleDao){
		_connection = connection;
		_gDBRecordSet = recordSet;
		
		_roleDao = roleDao;
		_hasNextRole = true;
		_isFirstCall = true;
	}
	
	/**
	 * GDBRecordSetをクローズします。<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.data.GExternalDataSet#close()
	 * @throws GResourceProcessingException
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public void close() throws GResourceProcessingException {
		try{
			if (_gDBRecordSet != null) {
				_gDBRecordSet.close();
			}
		}catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
		finally {
			try {
				if (_connection != null) {
					GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
					ds.close(_connection);
				}
			} catch (SQLException e) {
				throw new GResourceProcessingException(e);
			}
		}
		_hasNextRole = false;
		_currentRole = null;
	}

	/**
	 * カレント行のロールを取得します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.data.GExternalDataSet#get()
	 * @return
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public GEditableRole get() {
		return _currentRole;
	}

	/**
	 * ロールセットのカーソルを一つ進めます。<br>
	 * ロールが存在する場合は、<code>true</code>を返却します。<br>
	 * ロールが存在しない場合は、<code>false</code>を返却します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.data.GExternalDataSet#next()
	 * @return
	 * @throws GResourceProcessingException
	 * @author KCCS K.Fujita
	 * @create 2013/07/20
	 * @since 3.12.0
	 */
	public boolean next() throws GResourceProcessingException {
		try{
			//最初の呼び出しのみ、カーソルを１つ進める
			if(_isFirstCall){
				_hasNextRole = _gDBRecordSet.next();
				_isFirstCall = false;
			}
			
			//次のロールが存在しなければ、リターン
			if(!_hasNextRole){
				_currentRole = null;
				return false;
			}
			
			Map<Locale, String> roleDisplayNames = new HashMap<Locale, String>();
			
			String pastObjectID = _gDBRecordSet.getRecord().getString(OBJECTID);
			String objectID = null;
			GRecord currentRecord = null;
			List<GRecord> recordlist = new ArrayList<GRecord>();
			
			
			do {
				currentRecord = _gDBRecordSet.getRecord();
				objectID = currentRecord.getString(OBJECTID);
				recordlist.add(currentRecord);

				if (!objectID.equals(pastObjectID)) {
					// IDが変わった場合
					GEditableRole role = _roleDao.createRole(recordlist);
					role.setDisplayNameMap(roleDisplayNames);
					_currentRole = role;
					return true;
				}

				// 表示名の作成
				roleDisplayNames
						.put(GLocaleUtils.getLocale(currentRecord.getString(LOCALE)), currentRecord.getString(VALUE));

			} while (_gDBRecordSet.next());
	
			GEditableRole role = _roleDao.createRole(recordlist);
			role.setDisplayNameMap(roleDisplayNames);
			_currentRole = role;
			_hasNextRole = false;
			return true;
		}catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}
}
