/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.framework.auth.GUser;

/**
 * ロールを表すインターフェースです.
 * 
 * ロールとは、システムを利用するユーザーやそのユーザーが所属するグループに
 * 関連づけられた、システムを利用する上での役割の事です。<br>
 * 
 * @create 2011/04/13
 * @author KCCS kyo
 * @since 3.9.0
 */
public interface GRole extends Serializable{
	
	/**
	 * 
	 * オブジェクトIDを取得します.
	 * 
	 * @return オブジェクトID
	 * @create 2010/11/01
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	String getObjectID();
	
	/**
	 * 会社コードを取得します.
	 * 
	 * @create 2010/09/08
	 * @return 会社コード
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	String getCompanyCode();	
	
	/**
	 * ロールIDを取得します.
	 * 
	 * @create 2010/09/08
	 * @return ロールID
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	String getRoleID();	
	
	/**
	 * 表示名のMapを取得します.
	 * 
	 * @create 2010/09/08
	 * @return 表示名
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	Map<Locale, String> getDisplayNameMap();
	
	/**
	 * 指定したロケールの表示名を取得します.
	 * 
	 * @create 2010/09/08
	 * @param locale ロケール
	 * @return 表示名
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	String getDisplayName(Locale locale);
	
	/**
	 * 権限集合の詳細を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 権限詳細
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	String getAuthoritySet();
	
	/**
	 * 会社コードをセットします.
	 * 
	 * @create 2010/09/08
	 * @param companyCode 会社コード
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void setCompanyCode(String companyCode);
	
	/**
	 * オブジェクトIDをセットします。
	 * 
	 * @param objectID オブジェクトID
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setObjectID(String objectID);

	/**
	 * ロールIDをセットします.
	 * 
	 * @create 2010/09/08
	 * @param roleID ロールID
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void setRoleID(String roleID);

	/**
	 * 全てのロケールの表示名のマップをセットします.
	 * 
	 * @create 2010/09/08
	 * @param displayNameMap 全てのロケールの表示名のマップ
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void setDisplayNameMap(Map<Locale, String> displayNameMap);
	
	/**
	 * 権限セットをセットします.
	 * 
	 * @create 2010/09/08
	 * @param authoritySet 権限セット
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void setAuthoritySet(String authoritySet);
	
	/**
	 * ユーザーに権限のチェックを行います.
	 * 
	 * @param user ユーザー
	 * @return true: 権限あり / false: 権限なし
	 * @create 2010/10/25
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	boolean hasAuthority(GUser user);
}
