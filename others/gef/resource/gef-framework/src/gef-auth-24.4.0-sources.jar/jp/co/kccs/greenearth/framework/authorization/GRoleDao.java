/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * 永続化層にアクセスしてロール情報を操作するインターフェースです.<br>
 * 
 * @create 2011/04/13
 * @author KCCS kyo
 * @since 3.9.0
 */
public interface GRoleDao {

	/**
	 * 会社コード、ロールIDを基に、ロール情報を取得します.<br>
	 * 
	 * @param companyCode 会社コード
	 * @param roleID ロールID
	 * @return ロール情報
	 * @throws GResourceProcessingException リソースアクセスに失敗した場合
	 * @create 2010/09/08
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	GRole findRole(String companyCode, String roleID) throws GResourceProcessingException;

	/**
	 * オブジェクトIDを基に、ロール情報を取得します.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @return ロール情報
	 * @throws GResourceProcessingException リソースアクセスに失敗した場合
	 * @create 2010/09/08
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	GRole findRole(String objectID) throws GResourceProcessingException;

	/**
	 * {@link GRoleDao}インスタンスのファクトリークラスです.<br>
	 * 
	 * @create 2011/04/13
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public static class Factory {

		/**
		 * デフォルトコンストラクタ.<br>
		 * 
		 * @create 2011/04/13
		 * @author KCCS kyo
		 * @since 3.9.0
		 */
		public Factory() {		
		}
		
		/**
		 * DIに定義された{@link GRoleDao}のインスタンスを取得します.<br>
		 * 
		 * @return {@link GRoleDao}インスタンス
		 * @create 2011/04/13
		 * @author KCCS kyo
		 * @since 3.9.0
		 */
		public static GRoleDao getInstance() {
			return (GRoleDao) GFrameworkUtils.getComponent(GRoleDao.class.getName());
		}
	}
}
