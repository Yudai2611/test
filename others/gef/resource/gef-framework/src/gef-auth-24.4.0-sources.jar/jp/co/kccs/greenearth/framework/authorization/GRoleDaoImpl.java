/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * {@link GRoleDao}をGjdbcで実装したクラスです.<br>
 *
 * @author KCCS K.Fujita
 * @create 2013/07/19
 * @since 3.12.0
 */
public class GRoleDaoImpl implements GRoleDao {

	/** GERoleテーブルのテーブル名 */
	protected static final String GEROLE = "GERole";

	/* GERoleLocalizationResourceテーブルの項目 */
	/** GERoleLocalizationResource項目 ： リソースID */
	protected static final String VC_RES_ID = "ResourceID";
	/** GERoleLocalizationResource項目 ： ロケール */
	protected static final String VC_RES_LOCAL = "Locale";
	/** GERoleLocalizationResource項目 ： リソースの値 */
	protected static final String VC_RES_VALUE = "Value";
	/** GERoleLocalizationResource項目 ： 会社コード */
	protected static final String VC_RES_COMPANY_CODE = "CompanyCode";

	/* GERoleテーブルの項目 */
//	/** GERole項目 ： オブジェクトID */
//	protected static final String VC_ROLE_OBJECTID = "RoleObjectID";
	/** GERole項目 ： 会社コード */
	protected static final String VC_COMPANY_CODE = "CompanyCode";
	/** GERole項目 ： ロールID */
	protected static final String VC_ROLE_ID = "RoleID";
	/** GERole項目 ： 権限セット */
	protected static final String VC_AUTHORITY_SET = "AuthoritySet";
	/** GERole項目 ： 表示名のリソースID */
	protected static final String VC_DISPLAY_NAME_RESOURCE_ID = "DisplayNameResourceID";
	/** GERole項目 ： 表示名 */
	protected static final String VC_DISPLAY_NAME = VC_RES_VALUE;
	/** GERole項目 ： 表示ロケール */
	protected static final String VC_DISPLAY_LOCALE = VC_RES_LOCAL;

	/** {@link GRole}のプール */
	private Map<String, GRole> _pool = new ConcurrentHashMap<String, GRole>();

	/**
	 * {@link GRoleDaoImpl}インスタンスを初期化します.
	 *
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	public GRoleDaoImpl() {
	}

	/**
	 * ロールを作成します.<br>
	 *
	 * @return GRole ロール
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	public GRole createRole() {
		return new GRoleImpl();
	}

	/**
	 * 指定された条件でロールを検索します.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.authorization.GRoleDao#findRole(java.lang.String,
	 *      java.lang.String)
	 * @param companyCode 会社コード
	 * @param roleID ロールID
	 * @return GRole ロール
	 * @throws GResourceProcessingException SQL実行時に例外が発生する場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	public GRole findRole(String companyCode, String roleID) throws GResourceProcessingException {

		String key = companyCode + "_" + roleID;
		if (_pool.containsKey(key)) {
			return _pool.get(key);
		}

		Connection connection = null;

		try {
			connection = catchConnection();
			List<GRecord> recordList = select(GEROLE, "role")
													.leftOuterJoinFK("ResourceFK", "resource")
													.where(exp("#role.CompanyCode = ? AND #role.RoleID = ?", companyCode, roleID))
													.findList(connection);

			GRole role = null;
			if (recordList.size() == 0) {
				return null;
			} else {
				role = createRole(recordList);
				_pool.put(key, role);
			}

			return role;

		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * 指定された条件でロールを検索します.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.authorization.GRoleDao#findRole(java.lang.String,
	 *      java.lang.String)
	 * @param objectID オブジェクトID
	 * @return GRole ロール
	 * @throws GResourceProcessingException SQL実行時に例外が発生する場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	public GRole findRole(String objectID) throws GResourceProcessingException {
		Connection connection = null;
		try {
			connection = catchConnection();
			List<GRecord> recordList = select(GEROLE, "role")
											.leftOuterJoinFK("ResourceFK", "resource")
											.where(exp("#role.ObjectID = ?", objectID))
											.findList(connection);

			GRole role = null;
			if (recordList.size() == 0) {
				return null;
			} else {
				role = createRole(recordList);
			}
			return role;

		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * {@link GRecord}のリストより{@link GRole}を作成します.<br>
	 *
	 * @param recordlist ロールの生成元となるレコードのリスト
	 * @return GRole 生成されたロール
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	public GRole createRole(List<GRecord> recordlist) {
		GRole role = null;
		Map<Locale, String> displayNameMap = null;
		if (recordlist.size() > 0) {
			GRecord record = recordlist.get(0);
			role = createRole();
			role.setCompanyCode(record.getString(VC_COMPANY_CODE));
			role.setRoleID(record.getString(VC_ROLE_ID));
			role.setAuthoritySet(record.getString(VC_AUTHORITY_SET));

			displayNameMap = new HashMap<Locale, String>();
			for (GRecord recordTemp : recordlist) {
				Locale locale = GLocaleUtils.getLocale(recordTemp.getString(VC_DISPLAY_LOCALE));
				String value = recordTemp.getString(VC_DISPLAY_NAME);
				displayNameMap.put(locale, value);
			}
			role.setDisplayNameMap(displayNameMap);
		}
		return role;
	}

	/**
	 * "GERole"エンティティの定義からデータソース名を取得します。<br>
	 *
	 * @return エンティティに定義されたデータソース名
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	protected String getDataSource() {
		return entity(GEROLE).getDatabase().getDataSource();
	}

	/**
	 * コネクションを取得します。<br>
	 *
	 * @return 取得されたコネクション
	 * @throws GResourceProcessingException コネクションの取得時に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	protected Connection catchConnection() throws GResourceProcessingException {
		try {
			GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
			return ds.open(getDataSource());
		}
		catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 指定されたコネクションを解放します。<br>
	 *
	 * @param conn 開放するコネクション
	 * @throws GResourceProcessingException コネクションの解放時に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/19
	 * @since 3.12.0
	 */
	protected void releaseConnection(Connection conn) throws GResourceProcessingException {
		try {
			GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
			ds.close(conn);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}
}
