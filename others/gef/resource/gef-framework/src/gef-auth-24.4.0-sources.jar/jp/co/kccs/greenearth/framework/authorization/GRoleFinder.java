/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * ロールを管理するインターフェースです.<br>
 * 
 * 
 * @create 2011/04/13
 * @author KCCS kyo
 * @since 3.9.0
 */
public interface GRoleFinder {

	/**
	 * 指定した会社コード、ロールIDに基づき、ロールを取得します.
	 * 
	 * @param companyCode 会社コード
	 * @param roleID ロールID
	 * @return ロール
	 * @author KCCS kyo
	 * @since 2010/09/30
	 */
	GRole getRole(String companyCode, String roleID);
	
	/**
	 * 指定したオブジェクトIDに基づき、ロールを取得します。
	 * 
	 * @param objectID オブジェクトID
	 * @return ロール
	 * @create 2011/07/30
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	GRole getRole(String objectID);

	/**
	 * {@link GRoleFinder}を生成するファクトリークラスです.
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRoleFinder
	 * @create 2010/09/09
	 * @author kyo
	 * @since 3.9.0
	 */
	public static class Factory {
		
		/**
		 * インスタンス化させません
		 * 
		 * @create 2011/07/30
		 * @author KCCS kitamura
		 * @since 3.9.0
		 */
		private Factory() {
		}

		/**
		 * ロールマネージャーを取得します.
		 *
		 * @create 2010/09/09
		 * @author kyo
		 * @return ロールネージャー
		 * @since 3.9.0
		 */
		public static GRoleFinder getInstance() {
			return (GRoleFinder) GFrameworkUtils.getComponent(GRoleFinder.class.getName());
		}
	}
}
