/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;

/**
 * ロールを管理するクラスです.<br>
 * 
 * 
 * @create 2011/04/13
 * @author KCCS kyo
 * @since 3.9.0
 */
public class GRoleFinderImpl implements GRoleFinder {
	
	/**
	 * コンストラクタ.<br>
	 * 
	 * @create 2011/04/13
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GRoleFinderImpl() {
	}

	/**
	 * 会社コードとロールIDを指定して、{@link GRole}を取得します.<br>
	 * 
	 * @param companyCode 会社コード
	 * @param roleID ロールID
	 * @return ロール
	 * @create 2011/04/13
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GRole getRole(String companyCode, String roleID) {
		try {
			return getRoleDao().findRole(companyCode, roleID);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * オブジェクトIDを指定して、{@link GRole}を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRoleFinder#getRole(java.lang.String)
	 * @param objectID オブジェクトID
	 * @return ロール
	 * @create 2011/07/30
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GRole getRole(String objectID) {
		try {
			return getRoleDao().findRole(objectID);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * 内部で利用している{@link GRoleDao}を取得します。
	 * 
	 * @return {@link GRoleDao}
	 * @create 2011/07/30
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GRoleDao getRoleDao() {
		return GRoleDao.Factory.getInstance();
	}
}

