/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.framework.auth.GUser;

/**
 * {@link GRole}インターフェースのデフォルト実装です。
 * 
 * @create 2010/11/05
 * @author KCCS kyo
 * @since 3.9.0
 */
public class GRoleImpl implements GRole {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 670940604206063260L;
	/** オブジェクトID */
	private String _objectID = null;
	/** 会社コード. */
	private String _companyCode = null;
	/** ロールID. */
	private String _roleID = null;
	/** 表示名. */
	private Map<Locale, String> _displayNameMap = null;
	/** 権限詳細. */
	private String _authoritySet = null;
	
	/**
	 * {@link GRoleImpl}インスタンスを初期化します。
	 * 
	 * @create 2011/07/30
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GRoleImpl() {
	}
	
	/**
	 * オブジェクトIDを取得します.
	 * 
	 * @return オブジェクトID
	 * @author KCCS kyo
	 * @since 2010/10/10
	 */
	public String getObjectID() {
		return _objectID;
	}
	
	/**
	 * オブジェクトIDをセットします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRole#setObjectID(java.lang.String)
	 * @param objectID オブジェクトID
	 * @author KCCS kyo
	 * @since 2010/10/10
	 */
	public void setObjectID(String objectID) {	
		_objectID = objectID;
	}

	/**
	 * 会社コードを取得します.
	 * 
	 * @create 2010/09/08
	 * @return 会社コード
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getCompanyCode() {
		return _companyCode;
	}
	
	/**
	 * ロールIDを取得します.
	 * 
	 * @create 2010/09/08
	 * @return ロールID
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getRoleID() {
		return _roleID;
	}

	/**
	 * 表示名のMapを取得します.
	 * 
	 * @create 2010/09/08
	 * @return 表示名
	 * @author kyo
	 * @since 3.9.0
	 */
	public Map<Locale, String> getDisplayNameMap() {
		return _displayNameMap;
		
	}

	/**
	 * 指定したロケールの表示名を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRole#getDisplayName(java.util.Locale)
	 * @param locale ロケール
	 * @return 表示名
	 * @create 2010/11/25
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	public String getDisplayName(Locale locale) {
		return _displayNameMap == null ? null : _displayNameMap.get(locale);
	}

	/**
	 * 権限詳細を取得します.
	 * 
	 * @create 2010/09/08
	 * @return 権限詳細
	 * @author kyo
	 * @since 3.9.0
	 */
	public String getAuthoritySet() {
		return _authoritySet;
	}
	
	/**
	 * 会社コードをセットします.
	 * 
	 * @create 2010/09/08
	 * @param companyCode 会社コード
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setCompanyCode(String companyCode) {
		_companyCode = companyCode;
	}

	/**
	 * ロールIDをセットします.
	 * 
	 * @create 2010/09/08
	 * @param roleID ロールID
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setRoleID(String roleID) {
		_roleID = roleID;
	}

	/**
	 * 全てのロケールの表示名のマップをセットします。
	 * 
	 * @create 2010/09/08
	 * @param displayNameMap 全てのロケールの表示名のマップ
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setDisplayNameMap(Map<Locale, String> displayNameMap) {
		_displayNameMap = displayNameMap;
	}

	/**
	 * 権限詳細をセットします.
	 * 
	 * @create 2010/09/08
	 * @param authoritySet 権限セット
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setAuthoritySet(String authoritySet) {
		_authoritySet = authoritySet;
	}
	
	/**
	 * ユーザの権限を確認します.<br>
	 * true: 権限あり<br>
	 * false:権限なし<br>
	 * ※ユーザー/グループ/ロールはDBに登録されていることが前提条件となる<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.authorization.GRole#hasAuthority(jp.co.kccs.greenearth.framework.auth.GUser)
	 * @param user ユーザー
	 * @return true/false
	 * @author KCCS kyo
	 * @since 2010/10/01
	 */
	public boolean hasAuthority(GUser user) {
		GAuthoritySetInterpreter interpreter = new GAuthoritySetInterpreter();
		return interpreter.hasAuthority(getAuthoritySet(), user);
	}
}
