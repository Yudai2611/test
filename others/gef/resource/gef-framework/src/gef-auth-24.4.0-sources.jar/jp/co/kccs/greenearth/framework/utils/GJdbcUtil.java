/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import java.sql.Connection;
import java.sql.SQLException;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;

/**
 * アカウント情報取得用の基底クラスを定義します。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class GJdbcUtil {

	/**
	 * 接続を確立します。
	 *
	 * @create 2020/6/23
	 * @return 接続
	 * @throws GResourceProcessingException リソース処理中例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public static Connection catchConnection() throws GResourceProcessingException {
		try {
			GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
			return ds.open();
		}
		catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}


	/**
	 * 接続を解放します。
	 *
	 * @create 2020/6/23
	 * @param connection 接続
	 * @throws GResourceProcessingException リソース処理中例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public static void releaseConnection(Connection connection) throws GResourceProcessingException {
		try {
			GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
			ds.close(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

}
