/*
 * Copyright 2007-2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons;

import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;

/**
 * アプリケーションの処理中に発生した例外を通知する為の例外クラスです.
 *
 * @create 2007/04/13
 * @author aono
 * @since 3.0.0
 */
public class GApplicationException extends RuntimeException {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = -4536748646423368840L;

	/** エラーコード. */
	private String _code = null;
	/** エラータイプ. */
	private GErrorType _type = GErrorType.ERROR;
	/** 詳細 */
	private String _description = null;

	/**
	 * {@link GErrorMessage}インスタンスを初期化します.
	 *
	 * @create 2007/04/13
	 * @author aono
	 * @since 3.0.0
	 */
	public GApplicationException() {
	}

	/**
	 * エラーコード、メッセージを指定して{@link GApplicationException}インスタンスを初期化します.
	 *
	 * @create 2007/04/13
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @author aono
	 * @since 3.0.0
	 */
	public GApplicationException(String errorCode, String message) {
		super(message);
		_code = errorCode;
	}

	/**
	 * エラーコード、メッセージ、エラータイプを指定して{@link GApplicationException}インスタンスを初期化します.
	 *
	 * @create 2007/04/13
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @author aono
	 * @since 3.0.0
	 */
	public GApplicationException(String errorCode, String message, GErrorType type) {
		super(message);
		_code = errorCode;
		_type = type;
	}

	/**
	 * エラーコード、メッセージ、エラータイプ、詳細情報を指定して{@link GApplicationException}インスタンスを初期化します.
	 *
	 * @create 2009/06/05
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @param description 詳細情報
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GApplicationException(String errorCode, String message, GErrorType type, String description) {
		super(message);
		_code = errorCode;
		_type = type;
		_description = description;
	}

	/**
	 * エラーコード、メッセージ、原因となった例外を指定して{@link GApplicationException}インスタンスを初期化します.
	 *
	 * @create 2009/06/05
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param cause 原因となった例外
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GApplicationException(String errorCode, String message, Throwable cause) {
		super(message, cause);
		_code = errorCode;
	}

	/**
	 * エラーコード、メッセージ、エラータイプ、原因となった例外を指定して{@link GApplicationException}インスタンスを初期化します.
	 *
	 * @create 2009/06/05
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @param cause 原因となった例外
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GApplicationException(String errorCode, String message, GErrorType type, Throwable cause) {
		super(message, cause);
		_code = errorCode;
		_type = type;
	}

	/**
	 * エラーコード、メッセージ、エラータイプ、詳細情報、原因となった例外を指定して{@link GApplicationException}インスタンスを初期化します.
	 *
	 * @create 2009/06/05
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @param description 詳細情報
	 * @param cause 原因となった例外
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GApplicationException(String errorCode, String message, GErrorType type, String description, Throwable cause) {
		super(message, cause);
		_code = errorCode;
		_type = type;
		_description = description;
	}

	/**
	 * エラーメッセージリソースを指定し、{@link GApplicationException}のインスタンスを初期化します.
	 *
	 * @create 2007/04/13
	 * @param message エラーメッセージリソース
	 * @author aono
	 * @since 3.0.0
	 */
	public GApplicationException(GErrorMessage message) {
		this(message.getCode(), message.getMessage(), message.getType());
	}

	/**
	 * エラーメッセージリソース、詳細情報を指定し、{@link GApplicationException}のインスタンスを初期化します.
	 *
	 * @create 2009/06/05
	 * @param message エラーメッセージリソース
	 * @param description 詳細情報
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GApplicationException(GErrorMessage message, String description) {
		this(message.getCode(), message.getMessage(), message.getType(), description);
	}

	/**
	 * エラーメッセージリソース、原因となった例外を指定し、{@link GApplicationException}のインスタンスを初期化します.
	 *
	 * @create 2009/06/05
	 * @param message エラーメッセージリソース
	 * @param cause 原因となった例外
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GApplicationException(GErrorMessage message, Throwable cause) {
		this(message.getCode(), message.getMessage(), message.getType(), cause);
	}

	/**
	 * エラーメッセージリソース、詳細情報、原因となった例外を指定し、{@link GApplicationException}のインスタンスを初期化します.
	 *
	 * @create 2009/06/05
	 * @param message エラーメッセージリソース
	 * @param description 詳細情報
	 * @param cause 原因となった例外
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GApplicationException(GErrorMessage message, String description, Throwable cause) {
		this(message.getCode(), message.getMessage(), message.getType(), description, cause);
	}

	/**
	 * 原因となる例外を指定して{@link GApplicationException}インスタンスを初期化します.
	 *
	 * @create 2007/06/19
	 * @param cause 原因となる例外情報
	 * @author aono
	 * @since 3.1.0
	 * @deprecated 必ずエラーコードとエラーメッセージを指定するようにしてください
	 */
	@Deprecated
	public GApplicationException(Throwable cause) {
		super(cause);
	}

	/**
	 * エラーコードを取得します.
	 *
	 * @create 2007/04/13
	 * @return エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	public String getCode() {
		return _code;
	}

	/**
	 * 詳細情報を取得します。
	 *
	 * @create 2009/06/05
	 * @return 詳細情報
	 * @author kitamura
	 * @since 3.6.0
	 */
	public String getDescription() {
		return _description;
	}

	/**
	 * エラータイプを取得します.
	 *
	 * @create 2007/04/13
	 * @return エラータイプ
	 * @author aono
	 * @since 3.0.0
	 */
	public GErrorType getType() {
		return _type;
	}

	/**
	 * エラーコードを設定します.
	 *
	 * @create 2007/04/13
	 * @param code エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	public void setCode(String code) {
		_code = code;
	}

	/**
	 * 詳細情報を設定します。
	 *
	 * @create 2009/06/05
	 * @param description 詳細情報
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void setDescription(String description) {
		_description = description;
	}

	/**
	 * エラータイプを設定します.
	 *
	 * @create 2007/04/13
	 * @param type エラータイプ
	 * @author aono
	 * @since 3.0.0
	 */
	public void setType(GErrorType type) {
		_type = type;
	}
}
