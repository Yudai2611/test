/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons;

import java.util.Locale;

/**
 * フレームワークがライフサイクルを管理する処理単位に共通するコンテキストをあらわします。<br>
 * ライフサイクルはフレームワークが管理しているため、利用しているフレームワークによって異なります。<br>
 * インスタンスは以下の方法で取得します。<br>
 * 
 * <pre>
 * 
 * GFrameworkContext context = GFrameworkContext.getInstance();
 * </pre>
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GFrameworkContext {

	/** 処理に紐付けられたロケール */
	private Locale locale = GFrameworkUtils.getDefaultLocale();

	/**
	 * {@link GFrameworkContext}のインスタンスを取得します.<br>
	 * 
	 * @return インスタンス
	 * @create 2011/04/12
	 * @author kyo
	 * @since 3.9.0
	 */
	public static GFrameworkContext getInstance() {
		return GFrameworkUtils.getComponent(GFrameworkContext.class.getName());

	}

	/**
	 * コンテキスト情報を破棄します。<br>
	 * 
	 * @create 2011/04/12
	 * @author kyo
	 * @since 3.9.0
	 */
	public void destroy() {
		// ロケールをデフォルト値に戻します。
		locale = Locale.getDefault();
	}

	/**
	 * ロケール情報を取得します.<br>
	 * 
	 * @create 2011/04/12
	 * @return ロケール
	 * @author kyo
	 * @since 3.9.0
	 */
	public Locale getLocale() {
		return locale;
	}

	/**
	 * ロケール情報をセットします.<br>
	 * 
	 * @create 2011/04/12
	 * @param locale ロケール
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setLocale(final Locale locale) {
		this.locale = locale;
	}

}
