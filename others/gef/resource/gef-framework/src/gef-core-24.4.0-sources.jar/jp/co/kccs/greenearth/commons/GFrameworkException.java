/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons;

/**
 * フレームワークの処理中に発生した例外を表します.
 * 
 * @create 2007/02/12
 * @author kitamura
 * @since 3.0.0
 */
public class GFrameworkException extends RuntimeException {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = 6827738492736446787L;

	/**
	 * {@link GFrameworkException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GFrameworkException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GFrameworkException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GFrameworkException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GFrameworkException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GFrameworkException(Throwable cause) {
		super(cause);
	}

	/**
	 * 例外メッセージとこの例外の発生原因を指定し、{@link GFrameworkException}のインスタンスを初期化します.
	 * 
	 * @param message メッセージ
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GFrameworkException(String message, Throwable cause) {
		super(message, cause);
	}
}
