/*
 * Copyright 2012-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.Set;

/**
 * GFrameworkProperties.
 * 
 * @author KCCS Shigeki Shoji
 * @since 3.12.0
 */
public class GFrameworkProperties {

	/** インスタンス。*/
	static GFrameworkProperties instance = new GFrameworkProperties();

	/** GFrameworkPropertiesがリソースを取得するときに使用するクラスローダ。 */
	private ClassLoader classLoader;
	
	/** デフォルトのプロパティファイル名。 */
	private static final String DEFAULT_PROPERTIES_FILENAME = "ge-framework";
	
	/** importプロパティファイルキー名 */
	private static final String IMPORT_FILE_KEY = "@import.File";
	
	/** プロパティファイル名. **/
	static String propertiesFileName = DEFAULT_PROPERTIES_FILENAME;

	/** プロパティ。*/
	Properties properties = null;
	
	/**
	 * コンストラクタ。
	 */
	protected GFrameworkProperties() {
		classLoader = Thread.currentThread().getContextClassLoader();
		if (null == classLoader) {
			classLoader = GFrameworkProperties.class.getClassLoader();
		}
	}

	/**
	 * 指定されたキーが含まれるかを判定します.
	 * 
	 * @create 2007/01/24
	 * @param key キー
	 * @return キーが存在する:<code>true</code>、存在しない:<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static boolean containsProperty(String key) {
		if (instance.properties == null) {
			loadProperty();
		}
		return instance.properties.containsKey(key);
	}
	
	/**
	 * フレームワークが利用している、プロパティファイル名を取得します.
	 * 
	 * @create 2007/01/24
	 * @return プロパティファイル名
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String getPropertiesResourceName() {
		return propertiesFileName.replace('.', '/') + ".properties";
	}
	
	/**
	 * ge-framework.propertiesファイルより、指定したキーの値を取得します.
	 * 
	 * @create 2006/02/08
	 * @param key キー
	 * @return 値
	 * @throws MissingResourceException プロパティファイル内に指定したキーが存在しない場合
	 * @since 3.0.0
	 */
	public static String getProperty(String key) throws MissingResourceException {
		if (instance.properties == null) {
			loadProperty();
		}

		if (instance.properties.containsKey(key)) {
			return instance.properties.getProperty(key);
		} else {
			throw new MissingResourceException("Can't find property. key " + key, propertiesFileName, key);
		}
	}
	
	/**
	 * ge-framework.propertiesファイルより、指定したキーの値を取得します.<br>
	 * そのキーがプロパティファイル内に存在しない場合は、デフォルト値の引数が返されます。
	 * 
	 * @create 2006/03/14
	 * @param propertyKey キー
	 * @param defaultValue デフォルト値
	 * @return 指定されたキー値を持つプロパティ値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String getProperty(String propertyKey, String defaultValue) {
		try {
			return getProperty(propertyKey);
		} catch (MissingResourceException e) {
			return defaultValue;
		}
	}
	
	/**
	 * ge-framework.prpoerteisファイルより、指定したキーの値をint型の値として取得します。
	 * 
	 * @create 2009/08/19
	 * @param propertyKey キー
	 * @return 指定されたキー値を持つint型のプロパティ値
	 * @throws MissingResourceException プロパティファイル内に指定したキーが存在しない場合、
	 *                                  該当する値が、int値として解決できない場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static int getIntProperty(String propertyKey) throws MissingResourceException {
		String value = getProperty(propertyKey);
	    try {
	        return Integer.parseInt(value);
	        // CHECKSTYLE:OFF
	    } catch (Exception e) {
	    	// CHECKSTYLE:ON
	        throw new MissingResourceException(propertyKey + " property should be an Integer value.", propertiesFileName, propertyKey);
	    }
	}

	/**
	 * ge-framework.prpoerteisファイルより、指定したキーの値をint型の値として取得します。
	 * そのキーがプロパティファイル内に存在しない場合は、デフォルト値の引数が返されます。
	 * 
	 * @create 2009/08/19
	 * @param propertyKey キー
	 * @param defaultValue デフォルト値
	 * @return 指定されたキー値を持つint型のプロパティ値
	 * @throws MissingResourceException 該当する値が、int値として解決できない場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static int getIntProperty(String propertyKey, int defaultValue) throws MissingResourceException {
		String value = null;
		try {
			value = getProperty(propertyKey);
		}
		catch (MissingResourceException e) {
			return defaultValue;
		}

	    try {
	        return Integer.parseInt(value);
	    }
	    // CHECKSTYLE:OFF
	    catch (Exception e) {
	    	// CHECKSTYLE:ON
	        throw new MissingResourceException(propertyKey + " property should be an Integer value.", propertiesFileName, propertyKey);
	    }
	}

	/**
	 * プロパティとして定義されているキーのセットビューを返します.
	 * 
	 * @create 2009/07/01
	 * @return プロパティとして定義されているキーのセットビュー
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static Set<String> getPropertyKeySet() {
		if (instance.properties == null) {
			loadProperty();
		}
		return instance.properties.stringPropertyNames();
	}

	/**
	 * プロパティファイルの内容を読み直します.
	 * 
	 * @create 2007/01/24
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void refleshProperty() {
		loadProperty();
	}

	/**
	 * 指定されたキーをプロパティファイルの内容のキャッシュから削除します.
	 * 
	 * @create 2007/02/15
	 * @param key 削除するキー名
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void removeProperty(String key) {
		if (instance.properties == null) {
			loadProperty();
		}
		instance.properties.remove(key);
	}
	
	/**
	 * 指定されたキーと値のセットをプロパティとして追加します.
	 * 
	 * @create 2007/01/24
	 * @param key キー
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void setProperty(String key, String value) {
		if (instance.properties == null) {
			loadProperty();
		}
		instance.properties.put(key, value);
	}

	/**
	 * プロパティファイル情報を読み込みます.
	 * 
	 * @create 2007/01/24
	 * @throws MissingResourceException プロパティファイルが見つからない場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected static void loadProperty() throws MissingResourceException {
		instance.loadProperties();
	}
	
	/**
	 * プロパティファイル情報を読み込みます.
	 * 
	 * @create 2007/01/24
	 * @throws MissingResourceException プロパティファイルが見つからない場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected synchronized void loadProperties() throws MissingResourceException {
		String path = getPropertiesResourceName();
		URL url = classLoader.getResource(path);
		if (url == null) {
			throw new MissingResourceException("property file is not found. : " + propertiesFileName, propertiesFileName, "");
		}

		Properties properties = new Properties();
		InputStream stream = null;
		try {
			stream = url.openStream();
			properties.load(stream);
		} catch (IOException e) {
			throw new MissingResourceException(e.getMessage(), propertiesFileName, "");
		} finally {
			if (null != stream) {
				try {
					stream.close();
				} catch (IOException e) {
					throw new MissingResourceException(e.getMessage(), propertiesFileName, "");
				}
			}
		}
		// 追加プロパティファイル読込
		loadImportProperty(properties);

		this.properties = properties;
	}

	/**
	 * 追加プロパティファイル情報を読み込みます。
	 * 
	 * @create 2013/04/17
	 * @param properties プロパティ
	 * @throws MissingResourceException プロパティファイルが見つからない場合
	 * @author Saiga
	 * @since 3.0.0
	 */
	private void loadImportProperty(Properties properties) throws MissingResourceException {

		List<String> importKeys = new ArrayList<String>();
		for (String key : properties.stringPropertyNames()) {
			if (!key.startsWith(IMPORT_FILE_KEY)) {
				continue;
			}
			importKeys.add(key);
		}
		Collections.sort(importKeys, new Comparator<String>() {
			@Override	
			public int compare(String val1, String val2) {
				int num1 = Integer.parseInt(val1.replace(IMPORT_FILE_KEY, ""));
				int num2 = Integer.parseInt(val2.replace(IMPORT_FILE_KEY, ""));
				return num1 - num2;
			}
		});

		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		if (null == classLoader) {
			classLoader = GFrameworkProperties.class.getClassLoader();
		}

		Properties branchProperties = new Properties();
		for (String importKey : importKeys) {
			String path = properties.getProperty(importKey);
			
			URL url = classLoader.getResource(path);
			if (url == null) {
				throw new MissingResourceException("property file is not found. : " + path, path, "");
			}

			Properties leafProperties = new Properties();
			InputStream stream = null;
			try {
				stream = url.openStream();
				leafProperties.load(stream);
			} catch (IOException e) {
				throw new MissingResourceException(e.getMessage(), path, "");
			} finally {
				if (null != stream) {
					try {
						stream.close();
					} catch (IOException e) {
						throw new MissingResourceException(e.getMessage(), path, "");
					}
				}
			}
			loadImportProperty(leafProperties);
			branchProperties.putAll(leafProperties);
		}
		properties.putAll(branchProperties);
	}

	/**
	 * プロパティファイル名を設定します。
	 * 
	 * @param propertiesFileName プロパティファイル名
	 */
	protected static void setPropertiesFileName(String propertiesFileName) {
		GFrameworkProperties.propertiesFileName = propertiesFileName;
	}

	/**
	 * プロパティファイル名を返します。
	 * 
	 * @return プロパティファイル名
	 */
	protected static String getPropertiesFileName() {
		return propertiesFileName;
	}
	
	/**
	 * インスタンスを設定します。
	 * 
	 * @param instance インスタンス
	 */
	protected static void setInstance(GFrameworkProperties instance) {
		GFrameworkProperties.instance = instance;
	}
	
	/**
	 * インスタンスを返します。
	 * 
	 * @return インスタンス
	 */
	protected static GFrameworkProperties getInstance() {
		return instance;
	}

	/**
	 * プロパティを設定します。
	 * 
	 * @param properties プロパティ
	 */
	protected void setProperties(Properties properties) {
		this.properties = properties;
	}
	
	/**
	 * プロパティを返します。
	 * 
	 * @return プロパティ
	 */
	protected Properties getProperties() {
		return properties;
	}
}
