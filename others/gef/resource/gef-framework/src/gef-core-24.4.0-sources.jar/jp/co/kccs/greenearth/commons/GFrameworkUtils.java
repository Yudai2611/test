/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Set;

import jp.co.kccs.greenearth.commons.di.GDIContainerConfigurationException;
import jp.co.kccs.greenearth.commons.di.GDIContainerFactory;
import jp.co.kccs.greenearth.commons.di.GDIRootContainerRegistry;
import jp.co.kccs.greenearth.commons.di.GDIContainer;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;

/**
 * GreenEARTH Framework全般で利用するユーティリティ群を集めたライブラリです.<br>
 * 主に
 * <li><code>ge-framework.properties</code>からのプロパティの取得
 * <li>DIContainerからのコンポーネントの生成<br>
 * <br>
 * 関連のAPIを用意しています。
 * 
 * @create 2007/01/24
 * @author kitamura
 * @since 3.0.0
 */
public final class GFrameworkUtils {

	/** デフォルトロケールを指定するキー名. */
	public static final String DEFAULT_LOCALE_PROPERTY = "geframe.commons.Locale.DefaultLocale";

	/** Containerクラスを指定するキー名. */
	public static final String CONTAINER_FILE_PROPERTY = "geframe.commons.Di.ContainerFile";

	/** GContainerクラスを指定するキー名. */
	public static final String CONTAINER_FACTORY_PROPERTY = "geframe.commons.Di.ContainerFactory";

	/** 指定がない場合に使用するコンテナファクトリー名. */
	public static final String DEFAULT_CONTAINER_FACTORY = "jp.co.kccs.greenearth.commons.di.spring.GSpringContainerFactory";

	/**
	 * DIコンテナを初期化します。
	 * 
	 * @param context DIコンテナの初期化に利用するコンテキスト。
	 * @return DIコンテナ
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public static GDIContainer initDIContainer(final Object context) {
		String className = GFrameworkProperties.getProperty(CONTAINER_FACTORY_PROPERTY, DEFAULT_CONTAINER_FACTORY);
		String configPath = GFrameworkProperties.getProperty(CONTAINER_FILE_PROPERTY);
		GDIContainer container = null;
		try {
			GDIContainerFactory factory = (GDIContainerFactory) Class.forName(className).newInstance();
			container = factory.getDIContainer(context, configPath);
			GDIRootContainerRegistry.getInstance().registerDIContainer(container);
		} catch (InstantiationException e) {
			throw new GDIContainerConfigurationException(e);
		} catch (IllegalAccessException e) {
			throw new GDIContainerConfigurationException(e);
		} catch (ClassNotFoundException e) {
			throw new GDIContainerConfigurationException(e);
		}
		return container;
	}

	/**
	 * DIコンテナを状態を破棄します。
	 * 
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public static void destroyDIContainer() {
		GDIContainer container = GDIRootContainerRegistry.getInstance().getDIContainer();
		try {
			if (null != container) {
				GDIRootContainerRegistry.getInstance().getDIContainer().destroy();
			}
		} finally {
			GDIRootContainerRegistry.getInstance().removeDIContainer();
		}
	}

	/**
	 * 指定されたキーが含まれるかを判定します.
	 * 
	 * @create 2007/01/24
	 * @param key キー
	 * @return キーが存在する:<code>true</code>、存在しない:<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static boolean containsProperty(final String key) {
		return GFrameworkProperties.containsProperty(key);
	}

	/**
	 * DIコンテナより、コンポーネントを取得します.
	 * 
	 * @create 2006/02/08
	 * @param <T> コンポーネントのクラス
	 * @param key 定義名
	 * @return コンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getComponent(final String key) {
		GDIContainer container = getDIContainer();
		return (T) container.getComponent(key);
	}

	/**
	 * DIコンテナより、コンポーネントを取得します.
	 * 
	 * @create 2006/02/08
	 * @param <T> コンポーネントのクラス
	 * @param key キー
	 * @return コンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getComponent(final Class<T> key) {
		GDIContainer container = getDIContainer();
		return (T) container.getComponent(key);
	}
	
	/**
	 * フレームワークのデフォルトロケールを取得します.<br>
	 * プロパティファイルにデフォルトロケールが定義されていない場合は、
	 * {@link MissingResourceException}例外が発生します。<br>
	 * 
	 * @create 2007/07/25
	 * @return デフォルトロケール
	 * @author aono
	 * @since 3.3.0
	 */
	public static Locale getDefaultLocale() {
		String localeString = getProperty(DEFAULT_LOCALE_PROPERTY).trim();
		Locale locale = GLocaleUtils.getLocale(localeString);
		return locale;
	}
	
	/**
	 * システムが取り扱い対象としているロケールのリストを取得します。<br>
	 * 一覧はフレームワークプロパティに"geframe.commons.Locale"という値を基とした連番のキーで指定されます。
	 * 例：
	 * <pre>
	 * geframe.commons.Locale1=en
	 * geframe.commons.Locale2=ja_JP
	 * geframe.commons.Locale3=zh
	 * </pre>
	 * 
	 * 
	 * @create 2011/07/30
	 * @return 　システムが取り扱い対象としているロケールのリスト
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public static List<Locale> getTargetLocaleList() {
		String key = "geframe.commons.Locale";
		int index = 0;
		List<Locale> localeList = new ArrayList<Locale>();
		while (containsProperty(key + ++index)) {
			String value = getProperty(key + index);
			localeList.add(GLocaleUtils.getLocale(value));
		}
		return localeList;
	}

	/**
	 * フレームワークが利用している{@link GDIContainer}を取得します.
	 * 
	 * @create 2009/07/01
	 * @return フレームワークが利用している{@link GDIContainer}
	 * @author kitamura
	 * @since 3.6.0
	 */
	public synchronized static GDIContainer getDIContainer() {
		GDIContainer container = GDIRootContainerRegistry.getInstance().getDIContainer();
		if (null == container) {
			container = initDIContainer(null);
		}
		return container;
	}

	/**
	 * フレームワークが利用している、プロパティファイル名を取得します.
	 * 
	 * @create 2007/01/24
	 * @return プロパティファイル名
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String getPropertiesResourceName() {
		return GFrameworkProperties.getPropertiesResourceName();
	}

	/**
	 * ge-framework.propertiesファイルより、指定したキーの値を取得します.
	 * 
	 * @create 2006/02/08
	 * @param key キー
	 * @return 値
	 * @throws MissingResourceException プロパティファイル内に指定したキーが存在しない場合
	 * @since 3.0.0
	 */
	public static String getProperty(final String key) throws MissingResourceException {
		return GFrameworkProperties.getProperty(key);
	}

	/**
	 * ge-framework.propertiesファイルより、指定したキーの値を取得します.<br>
	 * そのキーがプロパティファイル内に存在しない場合は、デフォルト値の引数が返されます。
	 * 
	 * @create 2006/03/14
	 * @param propertyKey キー
	 * @param defaultValue デフォルト値
	 * @return 指定されたキー値を持つプロパティ値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String getProperty(final String propertyKey, final String defaultValue) {
		try {
			return getProperty(propertyKey);
		} catch (MissingResourceException e) {
			return defaultValue;
		}
	}

	/**
	 * ge-framework.prpoerteisファイルより、指定したキーの値をint型の値として取得します。
	 * 
	 * @create 2009/08/19
	 * @param propertyKey キー
	 * @return 指定されたキー値を持つint型のプロパティ値
	 * @throws MissingResourceException プロパティファイル内に指定したキーが存在しない場合、
	 *                                  該当する値が、int値として解決できない場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static int getIntProperty(final String propertyKey) throws MissingResourceException {
		return GFrameworkProperties.getIntProperty(propertyKey);
	}

	/**
	 * ge-framework.prpoerteisファイルより、指定したキーの値をint型の値として取得します。
	 * そのキーがプロパティファイル内に存在しない場合は、デフォルト値の引数が返されます。
	 * 
	 * @create 2009/08/19
	 * @param propertyKey キー
	 * @param defaultValue デフォルト値
	 * @return 指定されたキー値を持つint型のプロパティ値
	 * @throws MissingResourceException 該当する値が、int値として解決できない場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static int getIntProperty(final String propertyKey, final int defaultValue) throws MissingResourceException {
		return GFrameworkProperties.getIntProperty(propertyKey, defaultValue);
	}

	/**
	 * プロパティとして定義されているキーのセットビューを返します.
	 * 
	 * @create 2009/07/01
	 * @return プロパティとして定義されているキーのセットビュー
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static Set<String> getPropertyKeySet() {
		return GFrameworkProperties.getPropertyKeySet();
	}

	/**
	 * プロパティファイルの内容を読み直します.
	 * 
	 * @create 2007/01/24
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void refleshProperty() {
		GFrameworkProperties.loadProperty();
	}

	/**
	 * 指定されたキーをプロパティファイルの内容のキャッシュから削除します.
	 * 
	 * @create 2007/02/15
	 * @param key 削除するキー名
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void removeProperty(final String key) {
		GFrameworkProperties.removeProperty(key);
	}

	/**
	 * フレームワークが使用する{@link GDIContainer}を設定します.
	 * 
	 * @create 2009/07/01
	 * @param diContainer フレームワークが使用する{@link GDIContainer}
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static void registerDIContainer(final GDIContainer diContainer) {
		GDIRootContainerRegistry.getInstance().registerDIContainer(diContainer);
	}

	/**
	 * 指定されたキーと値のセットをプロパティとして追加します.
	 * 
	 * @create 2007/01/24
	 * @param key キー
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void setProperty(final String key, final String value) {
		GFrameworkProperties.setProperty(key, value);
	}

	/**
	 * プロパティファイル情報を読み込みます.
	 * 
	 * @create 2007/01/24
	 * @throws MissingResourceException プロパティファイルが見つからない場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected static synchronized void loadProperty() throws MissingResourceException {
		GFrameworkProperties.loadProperty();
	}

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2006/02/08
	 * @since 3.0.0
	 */
	private GFrameworkUtils() {
	}
	
}
