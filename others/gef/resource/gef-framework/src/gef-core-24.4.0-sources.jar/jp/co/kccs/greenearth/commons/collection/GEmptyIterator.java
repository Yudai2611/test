/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 空の{@link Iterator}を表現します.
 * 
 * @create 2007/03/20
 * @param <T>任意の型
 * @author kitamura
 * @since 3.0.0
 */
public class GEmptyIterator<T> implements Iterator<T> {

	/**
	 * {@link GEmptyIterator}インスタンスを初期化します.
	 * 
	 * @create 2007/01/06
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GEmptyIterator() {
	}

	/**
	 * <code>false</code>を返します.
	 * 
	 * @see java.util.Iterator#hasNext()
	 * @create 2007/01/06
	 * @return false
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean hasNext() {
		return false;
	}

	/**
	 * {@link NoSuchElementException}をスローします.
	 * 
	 * @see java.util.Iterator#next()
	 * @create 2007/01/06
	 * @return なし
	 * @author kitamura
	 * @since 3.0.0
	 */
	public T next() {
		throw new NoSuchElementException("Values is empty.");
	}

	/**
	 * {@link NoSuchElementException}をスローします.
	 * 
	 * @see java.util.Iterator#remove()
	 * @create 2007/01/06
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void remove() {
		throw new IllegalStateException("Values is empty.");
	}
}
