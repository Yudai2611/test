/*
 * Copyright 2008-2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.util.Enumeration;
import java.util.Iterator;

/**
 * {@link Iterator}を{@link Enumeration}インターフェースの実装に変換するアダプターです。
 * 
 * @create 2009/11/19
 * @param <E> コレクション要素
 * @author kitamura
 * @since 3.6.0
 */
public class GIteratorEnumeration<E> implements Enumeration<E> {

	/** 内包する{@link Iterator} */
	private Iterator<E> _iterator;

	/**
	 * {@link GIteratorEnumeration}インスタンスを初期化します。
	 * 
	 * @create 2009/11/19
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GIteratorEnumeration() {
		super();
	}

	/**
	 * 変換する{@link Iterator}を指定して、{@link GIteratorEnumeration}インスタンスを初期化します。
	 * 
	 * @create 2009/11/19
	 * @param iterator 変換する{@link Iterator}
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GIteratorEnumeration(Iterator<E> iterator) {
		super();
		_iterator = iterator;
	}

	/**
	 * 列挙にさらに要素があるかどうかを判定します。
	 * 
	 * @create 2009/11/19
	 * @see java.util.Enumeration#hasMoreElements()
	 * @return 列挙の次の要素
	 * @author kitamura
	 * @since 3.6.0
	 */
	public boolean hasMoreElements() {
		return _iterator.hasNext();
	}

	/**
	 * 列挙に 1 つ以上の要素が残っている場合は、次の要素を返します。
	 * 
	 * @create 2009/11/19
	 * @see java.util.Enumeration#nextElement()
	 * @return 列挙の次の要素
	 * @author kitamura
	 * @since 3.6.0
	 */
	public E nextElement() {
		return _iterator.next();
	}

	/**
	 * 変換対象の{@link Iterator}を取得します。
	 * 
	 * @create 2009/11/19
	 * @return 変換対象の{@link Iterator}
	 * @author kitamura
	 * @since 3.6.0
	 */
	public Iterator<E> getIterator() {
		return _iterator;
	}
}
