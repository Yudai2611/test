/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * List内の値をレイジーロードする場合に使うListクラス。<br/>
 * 値をロードする{@link Loader}を指定する事で、初回アクセス時に値をロードします。<br/>
 * 
 * @param <E> リスト内の要素の型
 * @create 2011/04/13
 * @author KCCS kyo
 * @since 3.9.0
 */
public class GLazyLoadList<E> implements List<E>,Serializable {
	
	/**
	 * ローダーのインターフェース.<br>
	 * 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public interface Loader<E> extends Serializable {
		/**
		 * {@link GLazyLoadList}のコンテンツを取得します。
		 * 
		 * @return ロード済みコンテンツ
		 * @create 2011/07/30
		 * @author KCCS kyo
		 * @since 3.9.0
		 */
		List<E> load();
	}

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 848559604177775446L;
	
	/** ローダー */
	private Loader<E> _loader = null;
	
	/** ロード済みかどうかのフラグ */
	private boolean _isLoaded = false;
	
	/** コンテンツ */
	private List<E> _contents = null;

	/**
	 * コンストラクタ.<br>
	 * 
	 * @param loader ローダー情報 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public GLazyLoadList(Loader<E> loader) {
		_loader = loader;
	}
	
	/**
	 * {@link GLazyLoadList}クラスの新しいインスタンスを初期化します。<br>
	 * 
	 * @param loader ローダー情報
	 * @param contents コンテンツ情報
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public GLazyLoadList(Loader<E> loader, List<E> contents) {
		this(loader);
		_contents = contents;
	}

	/**
	 * コンテンツを取得します.<br>
	 * ロード済みの場合、既存のコンテンツを返します。<br>
	 * ロード済みでない場合、最新の情報をロードしコンテンツに追加して返します。<br>
	 * 
	 * @return ロード済みコンテンツ
	 * @create 2011/04/13
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public List<E> getContents() {
		if (!_isLoaded) {
			if (_contents == null) {
				_contents = _loader.load(); 
			}
			else {
				_contents.addAll(_loader.load());
			}
			_isLoaded = true;
		}
		return _contents;
	}

	/**
	 * 指定された要素を最後に追加します.<br>
	 * 
	 * @param o 追加対象要素
	 * @return boolean 真偽値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean add(E o) {
		return getContents().add(o);
	}

	/**
	 * 指定された位置に、指定された要素を挿入します.<br>
	 * 
	 * @param index インディクス
	 * @param element 追加対象要素
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public void add(int index, E element) {
		getContents().add(index, element);
	}

	/**
	 * 指定されたコレクション内のすべての要素を、
	 * 指定されたコレクションの反復子によって返される順序でコンテンツの最後に追加します.<br>
	 * 
	 * @see java.util.List#addAll(java.util.Collection)
	 * @param c コレクション 
	 * @return この呼び出しの結果、このリストが変更された場合は true
	 * @create 2011/04/13
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public boolean addAll(Collection< ? extends E> c) {
		return getContents().addAll(c);
	}

	/**
	 * 指定されたコレクション内のすべての要素を指定された位置に挿入します.<br>
	 * 
	 * @param index インディクス
	 * @param c コレクション
	 * @return boolean 真偽値<br>
	 * 			この呼び出しの結果、このリストが変更された場合は true <br>
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean addAll(int index, Collection< ? extends E> c) {
		return getContents().addAll(index, c);
	}

	/**
	 * 全ての要素を削除します.<br>
	 * 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public void clear() {
		getContents().clear();
	}

	/**
	 * コンテンツに指定されたオブジェクトの存在をチェックします.<br>
	 * 
	 * @param o 指定されたオブジェクト
	 * @return boolean 真偽値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean contains(Object o) {
		return getContents().contains(o);
	}

	/**
	 * コンテンツに指定されたコレクションの存在をチェックします.<br>
	 * 指定されたコレクションのすべての要素が含まれている場合のみtrueを返します。<br>
	 * 
	 * @param c 指定されたコレクション
	 * @return boolean 真偽値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean containsAll(Collection< ? > c) {
		return getContents().containsAll(c);
	}

	/**
	 * 指定したインディクスにある要素を取得します.<br>
	 * 
	 * @see java.util.List#get(int)
	 * @param index インディクス
	 * @return 要素
	 * @create 2011/04/13
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public E get(int index) {
		return getContents().get(index);
	}

	/**
	 * 指定されたオブジェクトが最初に検出された位置のインデックスを取得します.<br>
	 * 
	 * @param o オブジェクト
	 * @return int インディクス
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public int indexOf(Object o) {
		return getContents().indexOf(o);
	}

	/**
	 * コンテンツの存在チェックをします.<br>
	 *  true: 要素がない<br>
	 *  false: 要素がある<br>
	 * 
	 * @return boolean 真偽値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean isEmpty() {
		return getContents().isEmpty();
	}

	/**
	 * コンテンツのイテレータを取得します.<br>
	 * 
	 * @return Iterator コンテンツのイテレータ
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public Iterator<E> iterator() {
		return getContents().iterator();
	}

	/**
	 * 指定されたオブジェクトが最後に検出された位置のインデックスを取得します.<br>
	 * 
	 * @param o オブジェクト
	 * @return int インディクス
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public int lastIndexOf(Object o) {
		return getContents().lastIndexOf(o);
	}

	/**
	 * コンテンツのリストイテレータを取得します.<br>
	 * 
	 * @return ListIterator リストイテレータ
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public ListIterator<E> listIterator() {
		return getContents().listIterator();
	}

	/**
	 * 指定したインディクスでコンテンツのリストイテレータを取得します.<br>
	 * 
	 * @param index インディクス
	 * @return ListIterator リストイテレータ
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public ListIterator<E> listIterator(int index) {
		return getContents().listIterator(index);
	}

	/**
	 * 指定された要素が最初に検出されたとき、その要素を削除します.<br>
	 * 
	 * @return boolean 真偽値<br>
	 * 			指定された要素を保持している場合は true<br>
	 * @create 2011/04/13
	 * @param o 削除対象要素
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean remove(Object o) {
		return getContents().remove(o);
	}

	/**
	 * 指定された位置にある要素を削除します .<br>
	 * 
	 * @return 要素
	 * @param index インデックス
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public E remove(int index) {
		return getContents().remove(index);
	}

	/**
	 * 指定されたコレクションに格納されているすべての要素を削除します.<br>
	 * 
	 * @return boolean 真偽値
	 * @param c 削除対象コレクション
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean removeAll(Collection< ? > c) {
		return getContents().removeAll(c);
	}

	/**
	 * 指定されたコレクションに格納されている要素だけが含まれるようにします.<br>
	 * つまり、指定されたコレクションに含まれていない要素をすべて削除します。<br>
	 * 
	 * @return boolean 真偽値<br>
	 * 			この呼び出しの結果、このリストが変更された場合は true<br>
	 * @param c 削除対象要素
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean retainAll(Collection< ? > c) {
		return retainAll(c);
	}

	/**
	 * 指定された位置にある要素を指定された要素に置き換えます.<br>
	 * 
	 * @param index 置換される要素のインデックス
	 * @param element 指定された位置に格納される要素
	 * @return 指定された位置に以前あった要素 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public E set(int index, E element) {
		return getContents().set(index, element);
	}

	/**
	 * リスト内の要素数を返します.<br>
	 * 
	 * @return int 要素数 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public int size() {
		return getContents().size();
	}

	/**
	 * fromIndex (これを含む) から toIndex (これを含まない) の範囲の部分のビューを返します.<br>
	 * 
	 * @param fromIndex  subList の下端点 (これを含む)
	 * @param toIndex  subList の上端点 (これを含まない) 
	 * @return List<E> 指定された範囲のビュー 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public List<E> subList(int fromIndex, int toIndex) {
		return getContents().subList(fromIndex, toIndex);
	}

	/**
	 * すべて要素を適切な順序で格納している配列を返します.<br>
	 *  
	 * @return Object[] すべて要素を適切な順序で格納している配列
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public Object[] toArray() {
		return getContents().toArray();
	}

	/**
	 * すべて要素を適切な順序で格納している配列を返します.<br>
	 * 
	 * @see java.util.List#toArray(T[])
	 * @param <T> 配列の型 
	 * @param a リストの要素の格納先の配列。配列のサイズが十分でない場合は、同じ実行時の型で新しい配列が格納用として割り当てられる
	 * @return 要素が格納されている配列 
	 * @create 2011/04/13
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public <T> T[] toArray(T[] a) {
		return getContents().toArray(a);
	}
}
