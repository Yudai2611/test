/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

/**
 * {@link Map}内の値をレイジーロードする場合に使う{@link Map}クラス。<br/>
 * 値をロードする{@link Loader}を指定する事で、初回アクセス時に値をロードします。<br/>
 * 
 * @param <K> {@link Map}内のキーの型
 * @param <V> {@link Map}内の値の型
 * @create 2011/04/13
 * @author KCCS kyo
 * @since 3.9.0
 */
public class GLazyLoadMap<K, V> implements Map<K, V>, Serializable {
	
	/**
	 * ローダーのインターフェース.<br>
	 * 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public interface Loader<K, V> extends Serializable {
		/**
		 * {@link GLazyLoadMap}のコンテンツを取得します。
		 * 
		 * @return ロード済みコンテンツ
		 * @create 2011/07/30
		 * @author KCCS kyo
		 * @since 3.9.0
		 */
		Map<K, V> load();
	}

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 32279084512441573L;
	/** ローダー */
	private Loader<K, V> _loader = null;
	
	/** ロード済みかどうかのフラグ */
	private boolean _isLoaded = false;
	
	/** コンテンツ */
	private Map<K, V> _contents = null;

	/**
	 * コンストラクタ.<br>
	 * 
	 * @param loader ローダー情報 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public GLazyLoadMap(Loader<K, V> loader) {
		_loader = loader;
	}
	
	/**
	 * コンストラクタ.<br>
	 * 
	 * @param loader ローダー情報
	 * @param contents コンテンツ情報
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public GLazyLoadMap(Loader<K, V> loader, Map<K, V> contents) {
		this(loader);
		_contents = contents;
	}
	
	/**
	 * コンテンツを取得します.<br>
	 * 
	 * @return コンテンツ情報
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public Map<K, V> getContents() {
		return _contents;
	}
	
	/**
	 * コンテンツをセットします.<br>
	 * 
	 * @param contents コンテンツ情報
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setContents(Map<K, V> contents) {
		_contents = contents;
	}

	/**
	 * コンテンツを取得します.<br>
	 * ロード済みの場合、既存のコンテンツを返します。<br>
	 * ロード済みでない場合、最新の情報をロードしてコンテンツにコピーします。<br>
	 * 
	 * @return ロード済みコンテンツ
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public Map<K, V> getLoadedContents() {
		if (!_isLoaded) {
			if (_contents == null) {
				_contents = _loader.load(); 
			}
			else {
				_contents.putAll(_loader.load());
			}
			_isLoaded = true;
		}
		return _contents;
	}

	/**
	 * コンテンツの全ての要素を削除を削除します.<br>
	 * 
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public void clear() {
		getLoadedContents().clear();
	}

	/**
	 * 指定されたオブジェクトはマップのキーに含まれているかどうかをチェックします.<br>
	 * 	true: 含まれている<br>
	 * 	false: 含まれていない<br>
	 * 
	 * @param key オブジェクト
	 * @return boolean 真偽値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean containsKey(Object key) {
		return getLoadedContents().containsKey(key);
	}

	/**
	 * 指定されたオブジェクトはマップの値に含まれているかどうかをチェックします.<br>
	 * 	true: 含まれている<br>
	 * 	false: 含まれていない<br>
	 * 
	 * @param value オブジェクト
	 * @return boolean 真偽値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean containsValue(Object value) {
		return getLoadedContents().containsValue(value);
	}

	/**
	 * 含まれているマッピングのセットビューを返します.<br>
	 * 
	 * @return Set<Entry<K,V>> セット
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public Set<Entry<K, V>> entrySet() {
		return getLoadedContents().entrySet();
	}

	
	/**
	 * 指定されたキーをマップする値を返します.<br>
	 * 
	 * @param key オブジェクト
	 * @return V 指定されたキーにマッピングしている値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public V get(Object key) {
		return getLoadedContents().get(key);
	}

	/**
	 * コンテンツの存在チェックをします.<br>
	 *  true: 要素がない<br>
	 *  false: 要素がある<br>
	 * 
	 * @return boolean 真偽値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean isEmpty() {
		return getLoadedContents().isEmpty();
	}

	/**
	 * マップに格納されているキーのセットビューを返します.<br>
	 * 
	 * @return Set<K> セットビュー
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public Set<K> keySet() {
		return getLoadedContents().keySet();
	}

	/**
	 * 指定された値と指定されたキーを関連付けます.<br>
	 * 
	 * @param key キー
	 * @param value 値
	 * @return V 指定されたキーに関連した以前の値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public V put(K key, V value) {
		return getLoadedContents().put(key, value);
	}

	/**
	 * 指定されたマップのすべてのマッピングをコピーします .<br>
	 * 
	 * @param t 追加する{@link Map}
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public void putAll(Map< ? extends K, ? extends V> t) {
		getLoadedContents().putAll(t);
	}

	/**
	 * 指定したキーがある場合、そのキーと関連するマッピングを削除します .<br>
	 * 
	 * @param key オブジェクト
	 * @return V 指定されたキーと関連付けられていた以前の値
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public V remove(Object key) {
		return getLoadedContents().remove(key);
	}

	/**
	 * キーと値のマッピングの数を返します.<br>
	 * 
	 * @return int マッピングの数
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public int size() {
		return getLoadedContents().size();
	}

	/**
	 * 格納されている値のコレクションビューを返します.<br>
	 * 
	 * @return Collection<V> コレクションビュー
	 * @create 2011/04/13
	 * @author kyo
	 * @since 3.9.0
	 */
	public Collection<V> values() {
		return getLoadedContents().values();
	}
}
