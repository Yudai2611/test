/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 順序を持つ{@link java.util.Map}を表現します.<br>
 * 
 * @param <K> マッピングキー
 * @param <V> マッピングする値
 * @create 2007/04/30
 * @author ueda
 * @since 3.0.0
 */
public interface GListMap<K, V> extends Map<K, V>, Serializable {

	/**
	 * すべてのマッピングを削除します.<br>
	 * 
	 * @see java.util.Map#clear()
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	void clear();

	/**
	 * 指定したKeyのマッピングが存在する場合 <tt>true</tt> を返します.<br>
	 * 
	 * @see java.util.Map#containsKey(java.lang.Object)
	 * @param key マッピング存在するか確認するKey
	 * @return <tt>true</tt> 指定したKeyのマッピングが存在する場合.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	boolean containsKey(Object key);

	/**
	 * 指定した値が1つ以上マッピングされてる場合 <tt>true</tt> を返します.<br>
	 * 
	 * @see java.util.Map#containsValue(java.lang.Object)
	 * @param value 1つ以上マッピングされてるか確認する値
	 * @return <tt>true</tt> 指定した値が1つ以上マッピングされてる場合.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	boolean containsValue(Object value);

	/**
	 * マップに含まれているマッピングのセットビューを返します.<br>
	 * 
	 * @see java.util.Map#entrySet()
	 * @return マップに含まれているマッピングのセットビュー.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	Set<Entry<K, V>> entrySet();

	/**
	 * マップが指定されたインデックスをマップする値を返します.<br>
	 * 
	 * @param index 関連付けられた値が返されるインデックス.
	 * @return マップが、指定されたインデックスにマッピングしている値.
	 * @throws IndexOutOfBoundsException if the index is out of range
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	V get(int index) throws IndexOutOfBoundsException;

	/**
	 * マップが指定されたキーをマップする値を返します。.<br>
	 * 
	 * @see java.util.Map#get(java.lang.Object)
	 * @param key 関連付けられた値が返されるキー .
	 * @return マップが、指定されたキーにマッピングしている値。
	 * 			このキーに対するマッピングがマップにない場合は null.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	V get(Object key);

	/**
	 * 指定された要素がリスト内で最初に検出された位置のインデックスを返します.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @param o 検索する要素.
	 * @return 指定された要素がリスト内で最初に検出された位置のインデックス。
	 * 			リストにこの要素がない場合は -1.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	int indexOf(V o);

	/**
	 * なにもマッピングされていない場合 <tt>true</tt> を返します.<br>
	 * 
	 * @see java.util.Map#isEmpty()
	 * @return <tt>true</tt> なにもマッピングされていない場合.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	boolean isEmpty();

	/**
	 * このリスト内の要素を適切な順序で繰り返し処理する反復子を返します.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @return リスト内の要素を適切な順序で繰り返し処理する反復子.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	Iterator<V> iterator();

	/**
	 * マップが保持してるKeyのセットビューを返します.<br>
	 * 
	 * @see java.util.Map#keySet()
	 * @return マップが保持してるKeyのセットビュー.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	Set<K> keySet();

	/**
	 * 指定された要素がリスト内で最後に検出された位置のインデックスを返します.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持するMapの値のリスト<br>
	 * 
	 * @param o 検索する要素.
	 * @return 定された要素がリスト内で最後に検出された位置の要素のインデックス。
	 * 			リストにこの要素がない場合は -1
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	int lastIndexOf(V o);

	/**
	 * 指定された値と指定されたキーをこのマップに関連付けます.<br>
	 * マップにすでにこのキーに対するマッピングがある場合<br>
	 * <ul>
	 *  <li> マップの古い値は指定された値に置き換えられます。</li>
	 *  <li> リストからは削除され、改めて追加されます。</li>
	 * </ul>
	 * 
	 * @see java.util.Map#put(K, V)
	 * @param key 指定される値が関連付けられるキー
	 * @param value 指定されるキーに関連付けられる値
	 * @return 指定されたキーに関連した以前の値
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	V put(K key, V value);

	/**
	 * 指定された値と指定されたキーを指定されたインデックスでマップに関連付けます.<br>
	 * マップに既にこのキーに対するマッピングがある場合<br>
	 * <ul>
	 *  <li>マップの古い値は指定された値に置き換えられます。
	 *  <li>リストからは削除され、改めて追加されます。
	 * </ul>
	 * 
	 * @create 2007/04/06
	 * @param key 指定される値が関連付けられるキー
	 * @param value 指定されるキーに関連付けられる値
	 * @param index 指定された値を追加するインデックス
	 * @return 指定されたキーに関連した以前の値
	 * @author ueda
	 * @since 3.0.0
	 */
	V put(K key, V value, int index);

	/**
	 * 指定されたマップのすべてのマッピングをこのマップにコピーします.<br>
	 * 指定されたマップのキー k から値 v までの各マッピングに関して、<br>
	 * この呼び出しの効果は、マップで put(k, v) を呼び出した場合と同じです。<br>
	 * 
	 * @see java.util.Map#putAll(java.util.Map)
	 * @param t マップに格納されるマッピング.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	void putAll(Map< ? extends K, ? extends V> t);

	/**
	 * このキーにマッピングがある場合に、そのマッピングをマップから削除します.<br>
	 * 
	 * @see java.util.Map#remove(java.lang.Object)
	 * @param key マッピングがマップから削除されるキー .
	 * @return 指定されたキーと関連付けられていた以前の値。キーのマッピングがなかった場合は null.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	V remove(Object key);

	/**
	 * マッピングの数を返します.<br>
	 * 
	 * @see java.util.Map#size()
	 * @return マッピングの数.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	int size();

	/**
	 * リスト内のすべて要素を適切な順序で格納している配列を返します。.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @return リスト内のすべて要素を適切な順序で格納している配列.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	Object[] toArray();

	/**
	 * リスト内のすべて要素を適切な順序で格納している配列を返します。.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @param a リストの要素の格納先の配列。
	 * 			配列のサイズが十分でない場合は、同じ実行時の型で新しい配列が格納用として割り当てられる .
	 * @param <T> マップに格納されている値の型
	 * @return リストの要素が格納されている配列
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	<T> T[] toArray(T[] a);

	/**
	 * マップに格納されている値のコレクションビューを返します.<br>
	 * シーケンスアクセスする場合のコレクション内の値の順序は、内部で保持している値の順序が適用されます。
	 * 
	 * @see java.util.Map#values()
	 * @return マップ内に含まれている値のコレクションビュー.
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	Collection<V> values();

}
