/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * {@link java.util.List}と{@link java.util.Map}を機能を持ったコレクションクラスです.<br>
 * {@link jp.co.kccs.greenearth.commons.collection.GListMap}のデフォルト実装になります。
 * 設定した値を内部の{@link java.util.HashMap}で保持すると同時に、<br>
 * 設定した値を設置した順序で内部の{@link java.util.ArrayList}で保持することにより順序について保証します。<br>
 * <br>
 * この実装は同期化されません。<br>
 * 複数のスレッドが同時にこのマップにアクセスし、それらのスレッドの少なくとも 1 つが構造的にマップを変更する場合には、外部で同期をとる必要があります。<br>
 * 
 * @param <K> マッピングキー
 * @param <V> マッピングする値
 * @create 2007/02/06
 * @author ueda
 * @since 3.0.0
 */
public class GListMapImpl<K, V> implements Map<K, V>, GListMap<K, V> {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 4666015016287027858L;
	/** このオブジェクトが保持する{@link Map}の値のリスト. */
	protected List<V> _list = new ArrayList<V>();
	/** このオブジェクトが保持する{@link Map}. */
	protected Map<K, V> _map = new HashMap<K, V>();
	/** このオブジェクトが保持する{@link Map}のKeyのリスト. */
	protected List<K> _relation = new ArrayList<K>();
	/** このオブジェクトが保持するKeyのセットビュー. */
	protected transient volatile Set<K> _keySet = null;
	/** このオブジェクトが保持するEntryのセットビュー. */
	protected transient Set<Map.Entry<K, V>> _entrySet = null;

	/**
	 * {@link GListMapImpl}インスタンスを初期化します.
	 * 
	 * @create 2006/02/07
	 * @author ueda
	 * @since 3.0.0
	 */
	public GListMapImpl() {
	}

	/**
	 * すべてのマッピングを削除します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#clear()
	 * @create 2007/04/30
	 * @author ueda
	 * @since 3.0.0
	 */
	public void clear() {
		_map.clear();
		_list.clear();
		_relation.clear();
	}

	/**
	 * 指定したKeyのマッピングが存在する場合 <tt>true</tt> を返します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#containsKey(java.lang.Object)
	 * @create 2007/04/30
	 * @param key マッピング存在するか確認するKey
	 * @return <tt>true</tt> 指定したKeyのマッピングが存在する場合.
	 * @author ueda
	 * @since 3.0.0
	 */
	public boolean containsKey(Object key) {
		return _map.containsKey(key);
	}

	/**
	 * 指定した値が1つ以上マッピングされてる場合 <tt>true</tt> を返します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#containsValue(java.lang.Object)
	 * @create 2007/04/30
	 * @param value 1つ以上マッピングされてるか確認する値
	 * @return <tt>true</tt> 指定した値が1つ以上マッピングされてる場合.
	 * @author ueda
	 * @since 3.0.0
	 */
	public boolean containsValue(Object value) {
		return _map.containsValue(value);
	}

	/**
	 * マップに含まれているマッピングのセットビューを返します.<br>
	 * この操作によって取得された{@link Set}より取得した、{@link Iterator}、{@link Entry}に対する操作は、マップに対して反映されません
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#entrySet()
	 * @create 2007/04/30
	 * @return マップに含まれているマッピングのセットビュー.
	 * @author ueda
	 * @since 3.0.0
	 */
	public Set<Entry<K, V>> entrySet() {
		Set<Map.Entry<K, V>> es = _entrySet;
		return (es != null ? es : (_entrySet = new EntrySet()));
	}

	/**
	 * マップが指定されたインデックスをマップする値を返します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#get(int)
	 * @create 2007/04/30
	 * @param index 関連付けられた値が返されるインデックス.
	 * @return マップが、指定されたインデックスにマッピングしている値.
	 * @throws IndexOutOfBoundsException if the index is out of range
	 * @author ueda
	 * @since 3.0.0
	 */
	public V get(int index) throws IndexOutOfBoundsException {
		Object key = _relation.get(index);
		return _map.get(key);
	}

	/**
	 * マップが指定されたキーをマップする値を返します。.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#get(java.lang.Object)
	 * @create 2007/04/30
	 * @param key 関連付けられた値が返されるキー .
	 * @return マップが、指定されたキーにマッピングしている値。
	 * 			このキーに対するマッピングがマップにない場合は null.
	 * @author ueda
	 * @since 3.0.0
	 */
	public V get(Object key) {
		return _map.get(key);
	}

	/**
	 * 指定された要素がリスト内で最初に検出された位置のインデックスを返します.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#indexOf(V)
	 * @create 2007/04/30
	 * @param o 検索する要素.
	 * @return 指定された要素がリスト内で最初に検出された位置のインデックス。
	 * 			リストにこの要素がない場合は -1.
	 * @author ueda
	 * @since 3.0.0
	 */
	public int indexOf(V o) {
		return _list.indexOf(o);
	}

	/**
	 * なにもマッピングされていない場合 <tt>true</tt> を返します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#isEmpty()
	 * @create 2007/04/30
	 * @return <tt>true</tt> なにもマッピングされていない場合.
	 * @author ueda
	 * @since 3.0.0
	 */
	public boolean isEmpty() {
		return _map.isEmpty();
	}

	/**
	 * このリスト内の要素を適切な順序で繰り返し処理する反復子を返します.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#iterator()
	 * @create 2007/04/30
	 * @return リスト内の要素を適切な順序で繰り返し処理する反復子.
	 * @author ueda
	 * @since 3.0.0
	 */
	public Iterator<V> iterator() {
		return _list.iterator();
	}

	/**
	 * マップが保持してるKeyのセットビューを返します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#keySet()
	 * @create 2007/04/30
	 * @return マップが保持してるKeyのセットビュー.
	 * @author ueda
	 * @since 3.0.0
	 */
	public Set<K> keySet() {
		Set<K> ks = _keySet;
		return (ks != null ? ks : (_keySet = new KeySet()));
	}

	/**
	 * 指定された要素がリスト内で最後に検出された位置のインデックスを返します.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持するMapの値のリスト<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#lastIndexOf(V)
	 * @create 2007/04/30
	 * @param o 検索する要素.
	 * @return 定された要素がリスト内で最後に検出された位置の要素のインデックス。
	 * 			リストにこの要素がない場合は -1
	 * @author ueda
	 * @since 3.0.0
	 */
	public int lastIndexOf(V o) {
		return _list.lastIndexOf(o);
	}

	/**
	 * 指定された値と指定されたキーをこのマップに関連付けます.<br>
	 * マップにすでにこのキーに対するマッピングがある場合<br>
	 * <ul>
	 *  <li> マップの古い値は指定された値に置き換えられます。</li>
	 *  <li> リストからは削除され、改めて追加されます。</li>
	 * </ul>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#put(K, V)
	 * @create 2007/04/30
	 * @param key 指定される値が関連付けられるキー
	 * @param value 指定されるキーに関連付けられる値
	 * @return 指定されたキーに関連した以前の値
	 * @author ueda
	 * @since 3.0.0
	 */
	public V put(K key, V value) {
		if (containsKey(key)) {
			remove(key);
		}
		_relation.add(key);
		_list.add(value);
		return _map.put(key, value);
	}

	/**
	 * 指定された値と指定されたキーを指定されたインデックスでマップに関連付けます.<br>
	 * マップに既にこのキーに対するマッピングがある場合<br>
	 * <ul>
	 *  <li>マップの古い値は指定された値に置き換えられます。
	 *  <li>リストからは削除され、改めて追加されます。
	 * </ul>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#put(K, V, int)
	 * @create 2007/04/30
	 * @param key 指定される値が関連付けられるキー
	 * @param value 指定されるキーに関連付けられる値
	 * @param index 指定された値を追加するインデックス
	 * @return 指定されたキーに関連した以前の値
	 * @author ueda
	 * @since 3.0.0
	 */
	public V put(K key, V value, int index) {
		if (containsKey(key)) {
			remove(key);
		}
		_relation.add(index, key);
		_list.add(index, value);
		return _map.put(key, value);
	}

	/**
	 * 指定されたマップのすべてのマッピングをこのマップにコピーします.<br>
	 * 指定されたマップのキー k から値 v までの各マッピングに関して、<br>
	 * この呼び出しの効果は、マップで put(k, v) を呼び出した場合と同じです。<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#putAll(java.util.Map)
	 * @create 2007/04/30
	 * @param t マップに格納されるマッピング.
	 * @author ueda
	 * @since 3.0.0
	 */
	public void putAll(Map< ? extends K, ? extends V> t) {
		for (Iterator< ? extends Map.Entry< ? extends K, ? extends V>> i = t.entrySet().iterator(); i.hasNext();) {
			Map.Entry< ? extends K, ? extends V> e = i.next();
			if (containsKey(e.getKey())) {
				remove(e.getKey());
			}

			_relation.add(e.getKey());
			_list.add(e.getValue());
		}
		_map.putAll(t);
	}

	/**
	 * このキーにマッピングがある場合に、そのマッピングをマップから削除します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#remove(java.lang.Object)
	 * @create 2007/04/30
	 * @param key マッピングがマップから削除されるキー .
	 * @return 指定されたキーと関連付けられていた以前の値。キーのマッピングがなかった場合は null.
	 * @author ueda
	 * @since 3.0.0
	 */
	public V remove(Object key) {
		if (!containsKey(key)) {
			return null;

		}
		for (int i = 0; i < _relation.size(); i++) {
			K mapKey = _relation.get(i);
			if (key.equals(mapKey)) {
				_relation.remove(i);
				_list.remove(i);
			}
		}
		return _map.remove(key);
	}

	/**
	 * マッピングの数を返します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#size()
	 * @create 2007/04/30
	 * @return マッピングの数.
	 * @author ueda
	 * @since 3.0.0
	 */
	public int size() {
		return _map.size();
	}

	/**
	 * リスト内のすべて要素を適切な順序で格納している配列を返します。.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#toArray()
	 * @create 2007/04/30
	 * @return リスト内のすべて要素を適切な順序で格納している配列.
	 * @author ueda
	 * @since 3.0.0
	 */
	public Object[] toArray() {
		return _list.toArray();
	}

	/**
	 * リスト内のすべて要素を適切な順序で格納している配列を返します。.<br>
	 * ※ここでいうリストとは、このオブジェクトが保持する{@link Map}の値のリスト<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#toArray(T[])
	 * @create 2007/04/30
	 * @param <T> マップに格納されている値の型
	 * @param a リストの要素の格納先の配列。
	 * 			配列のサイズが十分でない場合は、同じ実行時の型で新しい配列が格納用として割り当てられる .
	 * @return リストの要素が格納されている配列
	 * @author ueda
	 * @since 3.0.0
	 */
	public <T> T[] toArray(T[] a) {
		return _list.toArray(a);
	}

	/**
	 * マップに格納されている値のコレクションビューを返します.<br>
	 * シーケンスアクセスする場合のコレクション内の値の順序は、内部で保持している値の順序が適用されます。
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GListMap#values()
	 * @create 2007/04/30
	 * @return マップ内に含まれている値のコレクションビュー.
	 * @author ueda
	 * @since 3.0.0
	 */
	public Collection<V> values() {
		return _list;
	}

	/**
	 * このオブジェクトが持つEntryのセットビューを表すクラスです.
	 * 
	 * @create 2009/05/06
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected class EntrySet extends AbstractSet<Map.Entry<K, V>> {

		/**
		 * {@link EntrySet}インスタンスを初期化します.
		 * 
		 * @create 2009/05/06
		 * @auther kitamura
		 * @since 3.6.0
		 */
		protected EntrySet() {
		}

		/**
		 * セットビューをクリアします。
		 * 
		 * @create 2009/05/06
		 * @see java.util.AbstractCollection#clear()
		 * @author kitamura
		 * @since 3.6.0
		 */
		public void clear() {
			GListMapImpl.this.clear();
		}

		/**
		 * 指定したEntryが存在する場合<code>true</code>を返します.
		 * 
		 * @create 2009/05/06
		 * @see java.util.AbstractCollection#contains(java.lang.Object)
		 * @param o Entry
		 * @return <tt>true</tt> 指定したEntryのマッピングが存在する場合.
		 * @author kitamura
		 * @since 3.6.0
		 */
		public boolean contains(Object o) {
			return _map.entrySet().contains(o);
		}

		/**
		 * Entryセットの反復子を取得します。
		 * 
		 * @create 2009/05/06
		 * @see java.util.AbstractCollection#iterator()
		 * @return 反復子
		 * @author kitamura
		 * @since 3.6.0
		 */
		public Iterator<Map.Entry<K, V>> iterator() {

			final Iterator<K> keyIterator = GListMapImpl.this.keySet().iterator();

			Iterator<Map.Entry<K, V>> itr = new Iterator<Entry<K, V>>() {

				public boolean hasNext() {
					return keyIterator.hasNext();
				}

				public java.util.Map.Entry<K, V> next() {

					if (keyIterator.hasNext()) {
						K key = keyIterator.next();
						V value = _map.get(key);
						return new ListMapEntry(key, value);
					} else {
						return null;
					}
				}

				public void remove() {
					throw new UnsupportedOperationException("This operation is not supported. : \"remove\"");
				}

			};

			return itr;
		}

		/**
		 * 指定したEntryをセットビューから削除します.
		 * 
		 * @create 2009/05/06
		 * @see java.util.AbstractCollection#remove(java.lang.Object)
		 * @param o Entry
		 * @return 削除に成功すれば<code>true</code>、指定したEntryが存在しなければ<code>false</code>
		 * @author kitamura
		 * @since 3.6.0
		 */
		public boolean remove(Object o) {
			if (_map.entrySet().contains(o)) {
				Map.Entry< ? , ? > entry = (Map.Entry < ? , ? >) o;
				GListMapImpl.this.remove(entry.getKey());
				return true;
			} else {
				return false;
			}
		}

		/**
		 * Entryセットのサイズを取得します.
		 * 
		 * @create 2009/05/06
		 * @see java.util.AbstractCollection#size()
		 * @return サイズ
		 * @author kitamura
		 * @since 3.6.0
		 */
		public int size() {
			return GListMapImpl.this.size();
		}
	}

	/**
	 * このオブジェクトが持つKeyのセットビューをあらわすクラスです。
	 * 
	 * @create 2008/10/31
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected class KeySet extends AbstractSet<K> {

		/**
		 * {@link KeySet}インスタンスを初期化します。
		 * 
		 * @create 2008/10/31
		 * @author kitamura
		 * @since 3.6.0
		 */
		protected KeySet() {
		}

		/**
		 * セットビューをクリアします。
		 * 
		 * @see java.util.AbstractCollection#clear()
		 * @create 2008/10/31
		 * @author kitamura
		 * @since 3.6.0
		 */
		public void clear() {
			GListMapImpl.this.clear();
		}

		/**
		 * 指定したKeyが存在する場合<code>true</code>を返します.
		 * 
		 * @see java.util.AbstractCollection#contains(java.lang.Object)
		 * @create 2008/10/31
		 * @param o キー
		 * @return <tt>true</tt> 指定したKeyのマッピングが存在する場合.
		 * @author kitamura
		 * @since 3.6.0
		 */
		public boolean contains(Object o) {
			return GListMapImpl.this.containsKey(o);
		}

		/**
		 * キーセットの反復子を取得します。
		 * 
		 * @see java.util.AbstractCollection#iterator()
		 * @create 2008/10/31
		 * @return 反復子
		 * @author kitamura
		 * @since 3.6.0
		 */
		public Iterator<K> iterator() {
			return _relation.iterator();
		}

		/**
		 * 指定したキーをセットビューから削除します.
		 * 
		 * @see java.util.AbstractCollection#remove(java.lang.Object)
		 * @create 2008/10/31
		 * @param o キー
		 * @return 削除に成功すれば<code>true</code>、指定したキーが存在しなければ<code>false</code>
		 * @author kitamura
		 * @since 3.6.0
		 */
		public boolean remove(Object o) {
			return GListMapImpl.this.remove(o) != null;
		}

		/**
		 * キーセットのサイズを取得します。
		 * 
		 * @see java.util.AbstractCollection#size()
		 * @create 2008/10/31
		 * @return サイズ
		 * @author kitamura
		 * @since 3.6.0
		 */
		public int size() {
			return GListMapImpl.this.size();
		}
	}

	/**
	 * {@link GListMapImpl}専用の{@link Entry}クラスです.
	 * 
	 * @create 2009/05/07
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected class ListMapEntry implements Map.Entry<K, V> {

		/** キー */
		private K _key = null;
		/** 値 */
		private V _value = null;

		/**
		 * キーと値を指定して{@link ListMapEntry}インスタンスを初期化します.
		 * 
		 * @create 2009/05/07
		 * @param key キー
		 * @param value 値
		 * @auther kitamura
		 * @since 3.6.0
		 */
		protected ListMapEntry(K key, V value) {
			_key = key;
			_value = value;
		}

		/**
		 * 指定されたオブジェクトがエントリと等しいかどうかを比較します.<br>
		 * 指定されたオブジェクトもマップエントリであり、2 つのエントリが同じマッピングを表す場合は<code>true</code>を返します。<br>
		 * つまり、2 つのエントリ e1 と e2 は、以下のようになる場合に同じマッピングを表します。<br>
		 * <br>
		 * <code>
		 * (e1.getKey()==null ?<br>
		 * e2.getKey()==null : e1.getKey().equals(e2.getKey()))  &&<br>
		 * (e1.getValue()==null ?<br>
		 * e2.getValue()==null : e1.getValue().equals(e2.getValue()))<br>
		 * </code>
		 * <br>
		 * これにより、{@link Map.Entry} インタフェースの実装が異なる場合でも、equals メソッドが正常に動作することが保証されます。<br>
		 * 
		 * @create 2009/05/07
		 * @see java.util.Map$Entry#equals(java.lang.Object)
		 * @param o マップエントリと等しいかどうかを比較するオブジェクト 
		 * @return 定されたオブジェクトがこのマップエントリと等しい場合は<code>true</code>
		 * @author kitamura
		 * @since 3.6.0
		 */
		@Override
		public boolean equals(Object o) {
			if (!(o instanceof Map.Entry)) {
				return false;
			}
			Map.Entry< ? , ? > e = (Map.Entry< ? , ? >) o;
			Object k1 = getKey();
			Object k2 = e.getKey();
			if (k1 == k2 || (k1 != null && k1.equals(k2))) {
				Object v1 = getValue();
				Object v2 = e.getValue();
				if (v1 == v2 || (v1 != null && v1.equals(v2))) {
					return true;
				}
			}
			return false;
		}

		/**
		 * エントリに対応するキーを返します.
		 * 
		 * @create 2009/05/07
		 * @see java.util.Map$Entry#getKey()
		 * @return エントリに対応するキー
		 * @author kitamura
		 * @since 3.6.0
		 */
		public K getKey() {
			return _key;
		}

		/**
		 * エントリに対応する値を返します.
		 * 
		 * @create 2009/05/07
		 * @see java.util.Map$Entry#getValue()
		 * @return エントリに対応する値
		 * @author kitamura
		 * @since 3.6.0
		 */
		public V getValue() {
			return _value;
		}

		/**
		 * マップエントリのハッシュコード値を返します.<br>
		 * マップエントリ e のハッシュコードは、次のように定義されます。<br>
		 * <br>
		 * <code>
		 * (e.getKey()==null   ? 0 : e.getKey().hashCode()) ^<br>
		 * (e.getValue()==null ? 0 : e.getValue().hashCode())<br>
		 * </code>
		 * <br>
		 * これにより、Object.hashCode の一般規約によって要求される、
		 * 任意の 2 つのエントリ e1 と e2 で、<code>e1.equals(e2)<code>であれば<code>e1.hashCode()==e2.hashCode()<code>
		 * となることが保証されます。 
		 * 
		 * @create 2009/05/07
		 * @see java.util.Map$Entry#hashCode()
		 * @return マップエントリのハッシュコード値
		 * @author kitamura
		 * @since 3.6.0
		 */
		@Override
		public int hashCode() {
			return (_key == null ? 0 : _key.hashCode()) ^ (_value == null ? 0 : _value.hashCode());
		}

		/**
		 * このオペレーションはサポートされていません。<br>
		 * このメソッドにアクセスした場合は、{@link UnsupportedOperationException}が発生します。
		 * 
		 * @create 2009/05/07
		 * @see java.util.Map$Entry#setValue(java.lang.Object)
		 * @param value エントリに格納されている新しい値
		 * @return エントリに対応する以前の値
		 * @throws UnsupportedOperationException 常に発生します
		 * @author kitamura
		 * @since 3.6.0
		 */
		public V setValue(V value) throws UnsupportedOperationException {
			throw new UnsupportedOperationException("This operation is not supported. : \"setValue(V)\"");
		}

	}
}
