/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.io.Serializable;
import java.util.Set;

/**
 * キーに対して値をリストで格納するコレクション.
 * 
 * @create 2007/04/30
 * @param <K> キー値
 * @param <V> 値
 * @author kitamura
 * @since 3.0.0
 */
public interface GMultiMap<K, V> extends Serializable {

	/**
	 * コレクションに要素を追加します.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	void add(K key, int index, V value);

	/**
	 * コレクションに要素を追加します.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	void add(K key, V value);

	/**
	 * コレクションに要素の配列を追加します.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @param values 要素の配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addArray(K key, int index, V[] values);

	/**
	 * コレクションに要素の配列を追加します.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param values 要素の配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addArray(K key, V[] values);

	/**
	 * コレクションからすべての要素を削除します.
	 * 
	 * @create 2007/04/30
	 * @author kitamura
	 * @since 3.0.0
	 */
	void clear();

	/**
	 * コレクションに指定したキーの要素がある場合に true を返します.
	 * 
	 * @create 2007/05/03
	 * @param key キー
	 * @return 指定されたキーの要素がある場合は true、そうでない場合は false
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean containsKey(K key);

	/**
	 * コレクションに指定したキーで登録されている要素を返します.
	 * 
	 * @create 2007/05/03
	 * @param key キー
	 * @return キーで指定された要素
	 * @author kitamura
	 * @since 3.0.0
	 */
	V get(K key);

	/**
	 * コレクションに指定したキーで登録されているリストからインデックスで指定した位置の要素を返します.
	 * 
	 * @create 2007/05/03
	 * @param key キー
	 * @param index インデックス
	 * @return 指定された要素
	 * @author kitamura
	 * @since 3.0.0
	 */
	V get(K key, int index);

	/**
	 * コレクションに指定したキーで登録されている要素配列を返します.
	 * 
	 * @create 2007/05/03
	 * @param key キー
	 * @return キーで指定された要素
	 * @author kitamura
	 * @since 3.0.0
	 */
	V[] getArray(K key);

	/**
	 * コレクションに要素がないかどうかを判定します.
	 * 
	 * @create 2007/04/30
	 * @return リストに要素がない場合は true、そうでない場合は false
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean isEmpty();

	/**
	 * コレクションに格納されているキーの Set ビューを返します.
	 * 
	 * @create 2007/04/30
	 * @return コレクションに含まれているキーのセットビュー
	 * @author kitamura
	 * @since 3.0.0
	 */
	Set<K> keySet();

	/**
	 * キーで指定されたリストに含まれる要素の数を返します.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @return リストに含まれる要素の数
	 * @author kitamura
	 * @since 3.0.0
	 */
	int length(K key);

	/**
	 * キー (およびそれに対応する値) をコレクションから削除します.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @author kitamura
	 * @since 3.0.0
	 */
	void remove(K key);

	/**
	 * キーおよびインデックスに対応する値 をコレクションから削除します.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @author kitamura
	 * @since 3.0.0
	 */
	void remove(K key, int index);

	/**
	 * 指定されたキーを、指定されたインデックスと値にマップします.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	void set(K key, int index, V value);

	/**
	 * 指定されたキーを、指定された値にマップします.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	void set(K key, V value);

	/**
	 * 指定されたキーを、指定された要素配列にマップします.
	 * 
	 * @create 2007/04/30
	 * @param key キー
	 * @param values 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setArray(K key, V[] values);

	/**
	 * コレクションにあるキーの数を返します.
	 * 
	 * @create 2007/04/30
	 * @return コレクションにあるキーの数
	 * @author kitamura
	 * @since 3.0.0
	 */
	int size();
}
