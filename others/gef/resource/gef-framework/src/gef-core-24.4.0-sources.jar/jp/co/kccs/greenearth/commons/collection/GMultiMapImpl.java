/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * キーに対して値をリストで格納するコレクション.<br>
 * この実装は同期化されません。<br>
 * 複数のスレッドが同時にこのマップにアクセスし、それらのスレッドの少なくとも 1 つが構造的にマップを変更する場合には、外部で同期をとる必要があります。<br>
 * 
 * @create 2007/05/01
 * @param <K> キー値
 * @param <V> 値
 * @author kitamura
 * @since 3.0.0
 */
public class GMultiMapImpl<K, V> implements GMultiMap<K, V> {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 8920048258924003702L;

	/** パラメータのマップ. */
	private Map<K, V[]> _values = new HashMap<K, V[]>();

	/**
	 * {@link GMultiMapImpl}インスタンスを初期化します.
	 * 
	 * @create 2007/04/29
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GMultiMapImpl() {
	}

	/**
	 * コレクションに要素を追加します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#add(K, int, V)
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void add(K key, int index, V value) {
		V[] values = _values.get(key);
		@SuppressWarnings("unchecked")
		V[] newValues = (V[]) new Object[values.length + 1];
		for (int i = 0; i < newValues.length; i++) {
			if (i < index) {
				newValues[i] = values[i];
			}
			else if (i == index) {
				newValues[i] = value;
			}
			else if (i > index) {
				newValues[i] = values[i - 1];
			}
		}
		_values.put(key, newValues);
	}

	/**
	 * コレクションに要素を追加します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#add(K, V)
	 * @create 2007/04/30
	 * @param key キー
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void add(K key, V value) {
		V[] oldValues = _values.get(key);
		if (oldValues == null) {
			@SuppressWarnings("unchecked")
			V[] newValues = (V[]) new Object[1];
			newValues[0] = value;
			_values.put(key, newValues);
		}
		else {
			@SuppressWarnings("unchecked")
			V[] newValues = (V[]) new Object[oldValues.length + 1];
			for (int i = 0; i < oldValues.length; i++) {
				newValues[i] = oldValues[i];
			}
			newValues[oldValues.length] = value;
			_values.put(key, newValues);
		}
	}

	/**
	 * コレクションに要素を追加します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#addArray(K, int,V[])
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @param values 要素の配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addArray(K key, int index, V[] values) {
		V[] oldValues = _values.get(key);
		@SuppressWarnings("unchecked")
		V[] newValues = (V[]) new Object[oldValues.length + values.length];

		for (int i = 0; i < index; i++) {
			newValues[i] = oldValues[i];
		}

		int j = 0;
		for (int i = index; i < index + values.length; i++) {
			newValues[i] = values[j];
			j++;
		}

		for (int i = index + values.length; i < newValues.length; i++) {
			newValues[i] = oldValues[i - values.length];
		}

		_values.put(key, newValues);
	}

	/**
	 * コレクションに要素の配列を追加します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#addArray(K, V[])
	 * @create 2007/04/30
	 * @param key キー
	 * @param values 要素の配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addArray(K key, V[] values) {
		V[] oldValues = _values.get(key);
		if (oldValues != null) {
			@SuppressWarnings("unchecked")
			V[] newValues = (V[]) new Object[oldValues.length + values.length];
			for (int i = 0; i < oldValues.length; i++) {
				newValues[i] = oldValues[i];
			}
			for (int i = 0; i < values.length; i++) {
				newValues[oldValues.length + i] = values[i];
			}
			_values.put(key, newValues);
		}
		else {
			_values.put(key, values);
		}
	}

	/**
	 * コレクションからすべての要素を削除します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#clear()
	 * @create 2007/04/30
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clear() {
		_values.clear();
	}

	/**
	 * コレクションに指定したキーの要素がある場合に true を返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#containsKey(K)
	 * @create 2007/04/30
	 * @param key キー
	 * @return 指定された要素がある場合は true、そうでない場合は false
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean containsKey(K key) {
		return _values.containsKey(key);
	}

	/**
	 * コレクションに指定したキーで登録されている要素を返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#get(K)
	 * @create 2007/04/30
	 * @param key キー
	 * @return キーで指定された要素
	 * @author kitamura
	 * @since 3.0.0
	 */
	public V get(K key) {
		V[] values = _values.get(key);
		if (values != null) {
			return values[0];
		}
		else {
			return null;
		}
	}

	/**
	 * コレクションに指定したキーで登録されているリストからインデックスで指定した位置の要素を返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#get(K, int)
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @return 指定された要素
	 * @author kitamura
	 * @since 3.0.0
	 */
	public V get(K key, int index) {
		V[] values = _values.get(key);
		if (values != null) {
			return values[index];
		}
		else {
			return null;
		}
	}

	/**
	 * コレクションに指定したキーで登録されている要素配列を返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#getArray(K)
	 * @create 2007/04/30
	 * @param key キー
	 * @return キーで指定された要素
	 * @author kitamura
	 * @since 3.0.0
	 */
	public V[] getArray(K key) {
		V[] array = _values.get(key);
		if (array == null) {
			@SuppressWarnings("unchecked")
			V[] empty = (V[]) new Object[0];
			return empty;
		}
		return array;
	}

	/**
	 * コレクションに要素がないかどうかを判定します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#isEmpty()
	 * @create 2007/04/30
	 * @return リストに要素がない場合は true、そうでない場合は false
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean isEmpty() {
		return _values.isEmpty();
	}

	/**
	 * コレクションに格納されているキーの Set ビューを返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#keySet()
	 * @create 2007/04/30
	 * @return コレクションに含まれているキーのセットビュー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Set<K> keySet() {
		return _values.keySet();
	}

	/**
	 * キーで指定されたリストに含まれる要素の数を返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#length(K)
	 * @create 2007/04/30
	 * @param key キー
	 * @return リストに含まれる要素の数
	 * @author kitamura
	 * @since 3.0.0
	 */
	public int length(K key) {
		V[] values = _values.get(key);
		if (values != null) {
			return values.length;
		}
		else {
			return 0;
		}
	}

	/**
	 * キー (およびそれに対応する値)をコレクションから削除します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#remove(K)
	 * @create 2007/04/30
	 * @param key キー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void remove(K key) {
		_values.remove(key);
	}

	/**
	 * キーおよびインデックスに対応する値をコレクションから削除します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#remove(K, int)
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void remove(K key, int index) {
		V[] values = _values.get(key);
		if (values != null) {
			@SuppressWarnings("unchecked")
			V[] newValues = (V[]) new Object[values.length - 1];
			int j = 0;
			for (int i = 0; i < values.length; i++) {
				if (i != index) {
					newValues[j] = values[i];
					j++;
				}
			}

			_values.put(key, newValues);
		}
	}

	/**
	 * 指定されたキーを、指定されたインデックスと値にマップします.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#set(K, int, V)
	 * @create 2007/04/30
	 * @param key キー
	 * @param index インデックス
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void set(K key, int index, V value) {
		V[] values = _values.get(key);
		values[index] = value;
		_values.put(key, values);
	}

	/**
	 * 指定されたキーを、指定された値にマップします.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#set(K, V)
	 * @create 2007/04/30
	 * @param key キー
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void set(K key, V value) {
		@SuppressWarnings("unchecked")
		V[] values = (V[]) new Object[1];
		values[0] = value;
		_values.put(key, values);
	}

	/**
	 * 指定されたキーを、指定された要素配列にマップします.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#setArray(K, V[])
	 * @create 2007/04/30
	 * @param key キー
	 * @param values 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setArray(K key, V[] values) {
		_values.put(key, values);
	}

	/**
	 * コレクションにあるキーの数を返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#size()
	 * @create 2007/04/30
	 * @return コレクションにあるキーの数
	 * @author kitamura
	 * @since 3.0.0
	 */
	public int size() {
		return _values.size();
	}

	/**
	 * オブジェクトの文字列表現を返します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.collection.GMultiMap#toString()
	 * @create 2007/04/30
	 * @return オブジェクトの文字列表現
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public String toString() {
		StringBuilder log = new StringBuilder();
		for (K key : keySet()) {
			V[] values = getArray(key);
			if (values.length == 1) {
				log.append(key + "=" + values[0] + ";");
			}
			else {
				for (int i = 0; i < values.length; i++) {
					log.append(key + "[" + i + "]" + "=" + values[i] + ";");
				}
			}
		}
		return log.toString();
	}

	// public boolean containsValue( Object value )
	// {
	// return false;
	// }
	//
	// public void putAll( Map<? extends K, ? extends V> t )
	// {
	//		
	// }
	//	
	// public Collection<V> values()
	// {
	// return null;
	// }
}
