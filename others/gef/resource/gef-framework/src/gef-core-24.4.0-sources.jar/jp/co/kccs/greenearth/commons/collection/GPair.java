package jp.co.kccs.greenearth.commons.collection;

public class GPair<T1, T2> {
	private T1 _first;
	private T2 _second;
	
	public GPair(T1 first, T2 second) {
		_first = first;
		_second = second;
	}
	
	public T1 getFirst() {
		return _first;
	}

	public void setFirst(T1 first) {
		_first = first;
	}

	public T2 getSecond() {
		return _second;
	}

	public void setSecond(T2 second) {
		_second = second;
	}
	
	public boolean equals(Object obj) {
	    if (!(obj instanceof GPair)) {
	    	return false ;
	    }

	    GPair<?, ?> other = (GPair<?, ?>)obj ;
	    return other._first == _first && other._second == _second ;
	}

	public int hashCode() {
	    return System.identityHashCode(_first) ^ System.identityHashCode(_second) ;
	}
}
