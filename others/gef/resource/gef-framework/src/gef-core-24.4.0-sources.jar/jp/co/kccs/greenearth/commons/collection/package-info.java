/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * コレクションを提供します。
 */
package jp.co.kccs.greenearth.commons.collection;

