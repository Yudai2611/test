/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.configuration;

import java.util.Map;

/**
 * コンフィグレーションを注入するための汎用的なインタフェースを表します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GConfigurator<K, V> {
	
	/**
	 * 指定されたコンフィグレーション({@link Map})に登録・更新・削除など、変更を加えます.<br/>
	 * 
	 * @create 2023/10/25
	 * @param configuration
	 * @author yamashita
	 * @since 23.10.0
	 */
	void configure(Map<K, V> configuration);
	
	/**
	 * 第1引数のコンフィグレーションに、第2引数のコンフィグレーションを反映します.<br/>
	 * 第2引数のコンフィグレーションに同一キーが存在する場合、第1引数のコンフィグレーションは更新しません(第1引数のコンフィグレーションが優先)。<br/>
	 * 
	 * @create 2023/10/25
	 * @param srcConfiguration 規定となるコンフィグレーション
	 * @param refConfiguration マージするコンフィグレーション
	 * @author yamashita
	 * @since 23.10.0
	 */
	default void mergeConfiguration(Map<K, V> srcConfiguration, Map<K, V> refConfiguration) {
		refConfiguration
		.forEach((k, v) -> {
			if (srcConfiguration.containsKey(k)) {
				return;
			}
			srcConfiguration.put(k, v);
		});
	}
}
