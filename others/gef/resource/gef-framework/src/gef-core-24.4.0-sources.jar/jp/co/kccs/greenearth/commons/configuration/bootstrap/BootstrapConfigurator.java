/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.configuration.bootstrap;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;

/**
 * フレームワーク起動時に初期化対象クラス({@link GBootstrapInitializable})の動作をカスタムしたい場合、
 * {@link GBootstrapConfigurator}の実装クラスにアノテーションを宣言します。<br/>
 * これにより、{@ink GBootstrapInitializable}の初期化実行前に、{@link GBootstrapConfigurator#configure(java.util.Map)}がコールバックされ、
 * 初期化対象クラスの取り扱いを{@link GBootstrapConfiguration}を通して変更することが可能となります。<br/>
 * {@link GBootstrapConfiguration}に設定できる項目は、<br/>
 * <br/>
 *・起動時に初期化を実行するかどうか({@link GBootstrapConfiguration#setBootOn(boolean)})<br/>
 * ・初期化対象クラスのインスタンス生成時に連携するパラメータの設定({@link GBootstrapConfiguration#setParameters(java.util.Map)})<br/>
 * となります。<br/>
 * 
 * @see GBootstrapConfigurator
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface BootstrapConfigurator {
}
