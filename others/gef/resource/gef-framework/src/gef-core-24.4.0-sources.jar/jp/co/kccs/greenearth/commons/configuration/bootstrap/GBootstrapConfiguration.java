/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.configuration.bootstrap;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;

/**
 * {@link GBootstrapInitializable}の動作をカスタムするためのコンフィグレーションを表現します.<br/>
 * {@link GBootstrapConfigurator#configure(Map)}を通して、{@link GBootstrapConfiguration}に変更を加えます。<br/>
 * {@link GBootstrapConfiguration}の生成には{@link GBootstrapConfiguration#builder()}を利用します。<br/>
 * 
 * @see GBootstrapInitializable
 * @see GBootstrapConfigurator
 * @see BootstrapConfigurator
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GBootstrapConfiguration {
	/**
	 * 起動時に初期化を行うかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return true: 初期化を実行する/ false: 初期化を実行しない
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean isBootOn();
	Map<String, Object> getParameters();
	void setBootOn(boolean bootOn);
	void setParameters(Map<String, Object> parameters);

	static Builder builder() {
		return new Builder();
	}
	
	class Builder {
		private boolean bootOn;
		private Map<String, Object> parameters = new HashMap<>();

		public Builder bootOn(boolean bootOn) {
			this.bootOn = bootOn;
			return this;
		}
		public Builder addParameter(String key, Object value) {
			this.parameters.put(key, value);
			return this;
		}
		public Builder addParameters(Map<String, Object> parameters) {
			this.parameters.putAll(parameters);
			return this;
		}
		public GBootstrapConfiguration build() {
			return new GBootstrapConfigurationImpl(
					bootOn,
					parameters
			);
		}
	}
}
