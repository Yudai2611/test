/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.configuration.bootstrap;

import java.util.Map;

/**
 *
 * {@link GBootstrapConfiguration}の実装クラス
 *
 * @create 2023/10/25
 * @author Dhiaz Chebastian
 * @since 23.10.0
 */
public class GBootstrapConfigurationImpl implements GBootstrapConfiguration {

	private boolean bootOn;
	private Map<String, Object> parameters;

	public GBootstrapConfigurationImpl(boolean bootOn, Map<String, Object> parameters) {
		this.bootOn = bootOn;
		this.parameters = parameters;
	}

	public boolean isBootOn() {
		return bootOn;
	}

	@Override
	public Map<String, Object> getParameters() {
		return parameters;
	}

	@Override
	public void setBootOn(boolean bootOn) {
		this.bootOn = bootOn;
	}

	@Override
	public void setParameters(Map<String, Object> parameters) {
		this.parameters = parameters;
	}
}
