/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.configuration.bootstrap;

import java.util.Map;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.configuration.GConfigurator;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializer;

/**
 * フレームワーク起動時に初期化対象クラス({@link GBootstrapInitializable})の動作をカスタムしたい場合、
 * {@link BootstrapConfigurator}をクラスアノテーションに付与します。<br/>
 * {@link BootstrapConfigurator}アノテーションが付与されたクラスは、初期化実行前に{@link GBootstrapInitializer}より{@link #configure(Map)}がコールバックされるようになります。<br/>
 * {@link #configure(Map)}では、カスタムしたい{@link GBootstrapInitializable}をキーに指定し、値を示す{@link GBootstrapConfiguration}を通して動作に変更を加えます。<br>
 * アプリケーションのクラスパス上に複数の{@link GBootstrapConfigurator}クラスが存在する場合、プライオリティ({@link Priority})の優劣に基づいて順次{@link #configure(Map)}を実行、全ての{@link GBootstrapConfiguration}の変更はマージ({@link GConfigurator#mergeConfiguration(Map, Map)})されます（先勝ち）。<br/>
 * <pre>
 * example.
 * {@code
 *      @BootstrapConfigurator
 *      public class GLog4jConfigurator implements GBootstrapConfigurator {
 *            &#064;Override
 *            public void configure(Map<Class<? extends GBootstrapInitializable>, GBootstrapConfiguration> config) {
 *                  config.put(GLog4JBootstrapInitializableAdapter.class,
 *                        GBootstrapConfiguration.builder()
 *                              .bootOn(false)
 *                              .addParameter("resource", null)
 *                              .build()
 *                        );
 *                  }
 *            }
 *      }
 * </pre>
 * 
 * @see GBootstrapInitializable
 * @see BootstrapConfigurator
 * @see GBootstrapConfiguration
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GBootstrapConfigurator extends GConfigurator<Class<? extends GBootstrapInitializable>, GBootstrapConfiguration> {
	
	@Override
	void configure(Map<Class<? extends GBootstrapInitializable>, GBootstrapConfiguration> config);
}
