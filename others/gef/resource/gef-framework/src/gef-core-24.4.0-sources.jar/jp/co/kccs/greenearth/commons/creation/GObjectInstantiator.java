/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.creation;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * インスタンス生成の役割を担います.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GObjectInstantiator {
	
	/**
	 * 指定したクラスのインスタンスを生成します.<br>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param clazz インスタンス化対象のクラス
	 * @return インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> Optional<T> newInstance(Class<?> clazz);
	/**
	 * 指定したクラスのインスタンスを生成します.<br>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param clazz インスタンス化対象のクラス
	 * @param parameterClazz パラメータの型
	 * @param parameters パラメータ
	 * @return インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> Optional<T> newInstance(Class<?> clazz, Class<?>[] parameterClazz, Object[] parameters);
	/**
	 * 指定したクラスのインスタンスを生成します.<br>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param clazz インスタンス化対象のクラス
	 * @return インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> Optional<T> newInstance(String clazz);
	/**
	 * 指定したクラスのインスタンスを生成します.<br>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param clazz インスタンス化対象のクラスの完全修飾名称
	 * @param parameterClazz パラメータの型
	 * @param parameters パラメータ
	 * @return
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> Optional<T> newInstance(String clazz, Class<?>[] parameterClazz, Object[] parameters);
	
	static GObjectInstantiator getInstance() {
		return GFrameworkUtils.getComponent(GObjectInstantiator.class.getName());
	}
}
