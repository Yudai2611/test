/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.data;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * 外部リソースの大量データを少量ずつフェッチして取り扱うインターフェースです。<br/>
 * フェッチした値は、型パラメータで指定された任意のインスタンスに格納され取得できます。
 * 
 * @param <T> フェッチした値を表現する型
 * @create 2011/05/26
 * @author KCCS nishimura
 * @since 3.9.0
 */
public interface GExternalDataSet<T> {

	/**
	 * フェッチ領域を次の領域へ移動します。
	 * 
	 * @return 次の領域が存在していればtrue。既に全てフェッチし終えている場合はfalse。
	 * @throws GResourceProcessingException リソースのフェッチに失敗した場合
	 * @create 2010/10/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	boolean next()throws GResourceProcessingException;

	/**
	 * 外部リソースとの接続を閉じます。
	 * 
	 * @throws GResourceProcessingException リソースのクローズに失敗した場合
	 * @create 2010/10/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void close() throws GResourceProcessingException;

	/**
	 * 現在フェッチしている値を取得しています。
	 * 
	 * @return 現在フェッチしている値
	 * @create 2010/10/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	T get();	
}
