/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.data;

/**
 * リストのサブリスト開始位置、終了位置を格納する。</br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GRange {

	/**
	 * 明細の開始位置を取得します.
	 * 
	 * @return 開始位置
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getBeginIndex();

	/**
	 * 明細の終了位置を取得します.
	 * 
	 * @return 終了位置
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getEndIndex();

	/**
	 * 明細の開始位置を設定します.
	 * 
	 * @param beginIndex 開始位置
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setBeginIndex(int beginIndex);

	/**
	 * 明細の終了位置を設定します.
	 * 
	 * @param endIndex 終了位置
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setEndIndex(int endIndex);
}
