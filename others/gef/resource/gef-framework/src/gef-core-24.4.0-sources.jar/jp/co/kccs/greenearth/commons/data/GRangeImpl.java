/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.data;

/**
 * {@inheritDoc}
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GRangeImpl implements GRange {

	/** 開始位置 */
	private int beginIndex;

	/** 終了位置 */
	private int endIndex;

	/**
	 * コンストラクターです.
	 * 
	 * @param beginIndex 開始位置
	 * @param endIndex 終了位置
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GRangeImpl(int beginIndex, int endIndex) {
		this.beginIndex = beginIndex;
		this.endIndex = endIndex;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GRange#getBeginIndex()
	 */
	@Override
	public int getBeginIndex() {
		return beginIndex;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GRange#getEndIndex()
	 */
	@Override
	public int getEndIndex() {
		return endIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRange#setBeginIndex(int)
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	@Override
	public void setBeginIndex(int beginIndex) {
		this.beginIndex = beginIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRange#setEndIndex(int)
	 */
	@Override
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	
}
