/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.data;

import java.util.List;

/**
 * リストのサブリストの情報を格納します。</br>
 * 
 * @param <T>
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GRangeResult<T> {
	
	/**
	 * 全件数を取得します.
	 * 
	 * @return 全件数
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	 int getOverallSize();
	
	/**
	 * {@link GRange}を取得します.
	 * 
	 * @return {@link GRange}
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
    GRange getRange();
    
    /**
     * データを取得します.
     * 
     * @return データ
     * @create 2023/10/25
     * @author KCCS dhiaz
     * @since 23.10.0
     */
    List<T> getResult();
    
    /**
	 * 全件数を設定します.
	 * 
	 * @param size 全件数
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	 void setOverallSize(int size);
	
	/**
	 * {@link GRange}を設定します.
	 * 
	 * @param range {@link GRange}
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
     void setRange(GRange range);
    
    /**
     * データを設定します.
     * 
     * @param list データ
     * @create 2023/10/25
     * @author KCCS dhiaz
     * @since 23.10.0
     */
     void setResult(List<T> list);
   

}
