/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.data;

import java.util.List;

/**
 * {@inheritDoc}
 * 
 * @param <T>
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GRangeResultImpl<T> implements GRangeResult<T> {

	/** データ */
	private List<T> result;

	/** データ取得範囲{@link GRange} */
	private GRange range;

	/** データ全件数 */
	private int overallSize;

	/**
	 * コンストラクターです.
	 * 
	 * @param result データ
	 * @param range データ取得範囲{@link GRange}
	 * @param overallSize データ全件数
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GRangeResultImpl(List<T> result, GRange range, int overallSize) {
		this.result = result;
		this.range = range;
		this.overallSize = overallSize;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRangeResult#getOverallSize()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public int getOverallSize() {
		return overallSize;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRangeResult#getRange()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GRange getRange() {
		return range;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRangeResult#getResult()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<T> getResult() {
		return result;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRangeResult#setOverallSize(int)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setOverallSize(int size) {
		this.overallSize = size;

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRangeResult#setRange(GRange)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setRange(GRange range) {
		this.range = range;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GRangeResult#setResult(List)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setResult(List<T> list) {
		this.result = list;
	}
}
