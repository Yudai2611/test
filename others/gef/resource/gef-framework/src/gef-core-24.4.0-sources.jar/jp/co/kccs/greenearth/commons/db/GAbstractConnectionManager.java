/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.tools.GCounter;

/**
 * {@link GConnectionManager}の基本機能を実装した抽象クラスです. <br>
 * コネクションカウンタ、トランザクションカウンタの機能を実装しています。<br><br>
 * 
 * <b>【ライフサイクル】</b><br>
 * {@link GAbstractConnectionManager}を継承したクラスはスレッドセーフではないため、インスタンス化する場合は、threadを指定してください。
 * newの場合には、毎回インスタンス化されるため、このクラスを継承したプールが機能しません。
 * singletonの場合には、別スレッドから割り込まれる場合があるため、プールの管理が正しく機能しません。
 * 
 * <b>【DefaultAutoCommit】</b><br>
 * DefaultAutoCommitを<code>false<code>に設定すると、トランザクションの開始、コミット、ロールバックに関係なく、
 * コネクション確立時から解放時まで、常時AutoCommit設定を<code>false</code>のまま処理を実行します。<br>
 * DefaultAutoCommitの設定は、DI定義ファイル内のセッターインジェクションで定義してください。<br>
 * <br>
 * [設定例(Spring Frameworkの場合)]<br>
 * <pre>
 *  &lt;bean name=&quot;jp.co.kccs.greenearth.commons.db.GConnectionManager&quot; class=&quot;jp.co.kccs.greenearth.commons.db.GDataSourceConnectionManager&quot; singleton=&quot;false&quot;&gt; 
 *     &lt;property name=&quot;lifecycle&quot;&gt;&lt;value&gt;thread&lt;/value&gt;&lt;/property&gt;
 *     &lt;b&gt;&lt;property name=&quot;defaultAutoCommit&quot;&gt;&lt;value&gt;false&lt;/value&gt;&lt;/property&gt;&lt;/b&gt;
 *  &lt;/bean&gt;
 * </pre>
 * 
 * @see jp.co.kccs.greenearth.commons.db.GConnectionManager
 * @create 2006/12/30
 * @author kitamura
 * @since 3.0.0
 */
public abstract class GAbstractConnectionManager extends GConnectionManager {

	/** ロガー. */
	protected static final Log LOGGER = LogFactory.getLog(GConnectionManager.class);

	/** コネクションカウンタプール. */
	protected Map<Connection, GCounter> connectionCounterPool = new HashMap<Connection, GCounter>();
	/** コネクションプール. */
	protected Map<String, Connection> connectionPool = new HashMap<String, Connection>();
	/** トランザクションカウンタプール. */
	protected Map<Connection, GCounter> transactionCounterPool = new HashMap<Connection, GCounter>();

	/** デフォルトオートコミットフラグ. */
	private boolean defaultAutoCommit = true;

	// -----パブリックメソッド--------------------------------------------------------------------

	/**
	 * 指定された接続に対してトランザクションを開始します. <br>
	 * トランザクションが開始していない場合は、指定されたコネクションに対してオートコミットフラグをOFFにします。
	 * <pre>Connection.setAutoCommint(false);</pre>
	 * 
	 * @see GConnectionManager#beginTransaction(Connection)
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException トランザクションの開始に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public void beginTransaction(Connection connection) throws SQLException {
		GCounter counter = null;
		int hashcode = connection.hashCode();
		if (transactionCounterPool.containsKey(connection)) {
			// 既に開始済み
			counter = transactionCounterPool.get(connection);
		}
		else {
			// 開始
			if (isDefaultAutoCommit()) {
				setAutoCommit(connection, false);
			}
			LOGGER.debug("Begin Transaction : hashcode=" + hashcode);
			counter = new GCounter();
			transactionCounterPool.put(connection, counter);
		}
		int count = counter.countUp();

		LOGGER.debug("Transaction Counter Up : hashcode=" + hashcode + " count=" + count);
	}

	/**
	 * メインデータソースに対する接続を確立します.
	 * 
	 * @see GAbstractConnectionManager#catchConnection(String)
	 * @see GConnectionManager#catchConnection()
	 * @create 2006/12/31
	 * @return 接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public Connection catchConnection() throws SQLException {
		return catchConnection(getMainDataSourceName());
	}

	/**
	 * 指定した名前に該当するデータソースの接続を確立します.
	 * 
	 * @create 2006/12/31
	 * @param dataSourceName データソース名
	 * @return 該当データソースへの接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @see GConnectionManager#catchConnection(String)
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public Connection catchConnection(String dataSourceName) throws SQLException {
		Connection connection = null;
		GCounter counter = null;
		if (connectionPool.containsKey(dataSourceName)) {
			// 接続確立済み
			connection = connectionPool.get(dataSourceName);
			counter = connectionCounterPool.get(connection);
		}
		else {
			// 接続確立
			connection = catchNewConnection(dataSourceName);
			if (connection == null) {
				throw new NullPointerException("Can not catch a connection.");
			}
			connectionPool.put(dataSourceName, connection);
			counter = new GCounter();
			connectionCounterPool.put(connection, counter);
		}
		int count = counter.countUp();
		LOGGER.debug("Connection Counter Up : hashcode=" + connection.hashCode() + " datasource=" + dataSourceName + " count=" + count);
		return connection;
	}

	/**
	 * メインデータソースに対する新規接続を確立します.
	 * 
	 * @create 2006/12/31
	 * @return 新規接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @see GAbstractConnectionManager#catchNewConnection(String)
	 * @see GConnectionManager#catchNewConnection()
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public Connection catchNewConnection() throws SQLException {
		return catchNewConnection(getMainDataSourceName());
	}

	/**
	 * 指定された接続のトランザクションをコミットします.
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException トランザクションのコミットに失敗した場合
	 * @see GConnectionManager#commitTransaction(Connection)
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public void commitTransaction(Connection connection) throws SQLException {
		if (transactionCounterPool.containsKey(connection)) {
			GCounter counter = transactionCounterPool.get(connection);
			int count = counter.countDown();
			LOGGER.debug("Transaction Counter Down <Commit> : hashcode=" + connection.hashCode() + " count=" + count);

			if (counter.getCount() == 0) {
				// コミット
				transactionCounterPool.remove(connection);
				commit(connection);
			}
		}
		else {
			commit(connection);
		}
	}

	/**
	 * メインデータソースに対して確立されている接続を取得します.
	 * 
	 * @create 2006/12/31
	 * @return 接続
	 * @see GConnectionManager#getConnection()
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	@Deprecated
	public Connection getConnection() {
		return connectionPool.get(getMainDataSourceName());
	}

	/**
	 * 指定したデータソースに対して確立されている接続を取得します.
	 * 
	 * @create 2006/12/31
	 * @param dataSourceName データソース名
	 * @return 接続
	 * @see GConnectionManager#getConnection(String)
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	@Deprecated
	public Connection getConnection(String dataSourceName) {
		return connectionPool.get(dataSourceName);
	}

	/**
	 * コネクションキャッチ時に適用のオートコミットの状態を取得します.
	 * 
	 * @create 2007/07/19
	 * @return コネクションキャッチ時に適用するオートコミットの状態
	 * @author wang chenjun
	 * @since 3.2.0
	 */
	public boolean isDefaultAutoCommit() {
		return defaultAutoCommit;
	}

	/**
	 * 指定された接続を解放します.
	 * 
	 * @create 2006/12/31
	 * @param connection 接続
	 * @throws SQLException コネクションの解放に失敗した場合
	 * @see GConnectionManager#releaseConnection(Connection)
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public void releaseConnection(Connection connection) throws SQLException {
		if (connectionCounterPool.containsKey(connection)) {
			GCounter counter = connectionCounterPool.get(connection);
			String dataSourceName = getDataSourceName(connection);
			int count = counter.countDown();
			LOGGER.debug("Connection Counter Down : hashcode=" + connection.hashCode() + " count=" + count);

			if (counter.getCount() == 0) {
				// 接続解放
				connectionCounterPool.remove(connection);
				connectionPool.remove(dataSourceName);
				close(connection);
			}
		}
		else if (connection != null) {
			close(connection);
		}
	}

	/**
	 * 指定された接続のトランザクションをロールバックします.
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException トランザクションのロールバックに失敗した場合
	 * @see GConnectionManager#rollbackTransaction(Connection)
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public void rollbackTransaction(Connection connection) throws SQLException {
		if (transactionCounterPool.containsKey(connection)) {
			GCounter counter = transactionCounterPool.get(connection);
			int count = counter.countDown();
			LOGGER.debug("Transaction Counter Down <Rollback> : hashcode=" + connection.hashCode() + " count=" + count);

			if (counter.getCount() == 0) {
				// ロールバック
				transactionCounterPool.remove(connection);
				rollback(connection);
			}
		}
		else if (connection != null) {
			rollback(connection);
		}
	}

	/**
	 * コネクションキャッチ時に適用のオートコミットの状態を設定します.
	 * 
	 * @create 2007/07/19
	 * @param defaultAutoCommit コネクションキャッチ時に適用するオートコミットの状態
	 * @author wang chenjun
	 * @since 3.2.0
	 */
	public void setDefaultAutoCommit(boolean defaultAutoCommit) {
		this.defaultAutoCommit = defaultAutoCommit;
	}

	/**
	 * 指定されたコネクションの接続を解放します.
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException コネクションの解放に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected void close(Connection connection) throws SQLException {
		int hashcode = connection.hashCode();
		if (connection.isClosed()) {
			LOGGER.warn("This connection has already been close. : hashcode=" + hashcode);
		}
		else {
			connection.close();
		}
		LOGGER.debug("Release Connection : hashcode=" + hashcode);
	}

	/**
	 * 指定されたコネクションのトランザクションをコミットします.
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException コミットに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected void commit(Connection connection) throws SQLException {
		connection.commit();
		if (isDefaultAutoCommit()) {
			setAutoCommit(connection, true);
		}
		LOGGER.debug("Commint Transaction : hashcode=" + connection.hashCode());
	}

	/**
	 * メインデータソース名を取得します.
	 * 
	 * @create 2007/01/01
	 * @return メインデータソース名
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected abstract String getMainDataSourceName();

	/**
	 * 指定されたコネクションのトランザクションをロールバックします.
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException ロールバックに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected void rollback(Connection connection) throws SQLException {
		connection.rollback();
		if (isDefaultAutoCommit()) {
			setAutoCommit(connection, true);
		}
		LOGGER.debug("Rollback Transaction : hashcode=" + connection.hashCode());
	}

	/**
	 * 指定されたコネクションに指定されたAutoCommitフラグをセットします.
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @param isAutoCommit AutoCommitフラグ
	 * @throws SQLException フラグセット時の処理に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected void setAutoCommit(Connection connection, boolean isAutoCommit) throws SQLException {
		if (connection.getAutoCommit() == isAutoCommit) {
			LOGGER.warn("This connection is already AutoCommit=" + isAutoCommit + ". ");
		}
		else {
			connection.setAutoCommit(isAutoCommit);
		}
	}

	/**
	 * 指定されたコネクションに関連づくデータソース名を取得します. <br>
	 * コネクションプール内から該当するデータソースを逆引きしています。
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @return データソース名
	 * @author kitamura
	 * @since 3.0.0
	 */
	private String getDataSourceName(Connection connection) {
		for (String dataSourceName : connectionPool.keySet()) {
			Connection poolingConnection = connectionPool.get(dataSourceName);
			if (connection == poolingConnection) {
				return dataSourceName;
			}
		}
		// 該当するデータソースが存在しない場合はnullを返す
		return null;
	}

	/**
	 * poolしているコネクションをcloseします。
	 */
	@Override
	public void removeConnections() {
		/** コネクションカウンタプール. */
		for (Connection connection : connectionCounterPool.keySet()) {
			try {
				if (!connection.isClosed()) {
					connection.close();
				}
			} catch (SQLException e) {
				// ignore
			}
		}
		connectionCounterPool.clear();
		connectionPool.clear();
		transactionCounterPool.clear();
	}
	
}
