/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.db;

import java.sql.Connection;
import java.sql.SQLException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * データベースへの接続（コネクション）を管理します.<br><br>
 * 
 * 【インスタンスの生成】<br>
 * {@link GConnectionManager}は、設定によりインスタンスのライフサイクルを変更することができます。<br>
 * 設定できるライフサイクルは、以下の4パターンです。
 * <table border="1" cellpadding="3" cellspacing="0">
 *  <tr bgcolor="#CCCCFF"><td>ライフサイクル</td><td>説明</td></tr>
 * 	<tr><td>prototype</td><td>毎回新しいインスタンスを生成します</td></tr>
 * 	<tr><td>request</td><td>Web環境のリクエスト単位でインスタンスを生成します</td></tr>
 * 	<tr><td>thread</td><td>スレッド単位でインスタンスを生成します</td></tr>
 * 	<tr><td>singleton</td><td>常に同じインスタンスを返します</td></tr>
 * </table>
 * <br>
 * ■ライフサイクルの設定方法はDIコンテナの設定にて行います。<br>
 * Spring Frameworkを利用した場合の例<br>
 * 
 * 1. 毎回新しいインスタンスを生成する場合(prototype)<br>
 * 毎回新しいインスタンスで生成した場合DIコンテナで自動的に解放処理(removeConnections)が実行されないため解放漏れが発生しないよう注意してください。<br>
 * <br>
 * <pre>
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     class="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"&gt;
 *     &lt;constructor-arg value="jp.co.kccs.greenearth.commons.db.GThinDriverConnectionManager" /&gt;
 * &lt;/bean&gt;
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManager"
 *     factory-bean="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     factory-method="getInstance"
 *     scope="prototype"&gt;
 *     &lt;property name="defaultAutoCommit" value="false" /&gt;
 * &lt;/bean&gt;
 * </pre>
 * 
 * 2. Web環境のリクエスト単位(スレッド単位とほぼ同等ですがリクエストの終了時にremoveConnectionsを実行します)でインスタンスを生成する場合(request)<br>
 * <br>
 * <pre>
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     class="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"&gt;
 *     &lt;constructor-arg value="jp.co.kccs.greenearth.commons.db.GThinDriverConnectionManager" /&gt;
 * &lt;/bean&gt;
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManager"
 *     factory-bean="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     factory-method="getInstance"
 *     destroy-method="removeConnections"
 *     scope="request"&gt;
 *     &lt;property name="defaultAutoCommit" value="false" /&gt;
 * &lt;/bean&gt;
 * </pre>
 * 
 * 3. スレッド単位でインスタンスを生成する場合(thread)<br>
 *　スレッド単位で生成した場合、DIコンテナで自動的に解放処理(removeConnections)が実行されないため解放漏れが発生しないように注意してください。<br>
 * <br>
 * <pre>
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     class="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"&gt;
 *     &lt;constructor-arg value="jp.co.kccs.greenearth.commons.db.GThinDriverConnectionManager" /&gt;
 *     &lt;constructor-arg value="thread" /&gt;
 * &lt;/bean&gt;
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManager"
 *     factory-bean="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     factory-method="getInstance"
 *     scope="prototype"&gt;
 *     &lt;property name="defaultAutoCommit" value="false" /&gt;
 * &lt;/bean&gt;
 * </pre>
 * 
 * 4. 常に同じインスタンスを返します(singleton)<br>
 * <br>
 * <pre>
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     class="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"&gt;
 *     &lt;constructor-arg value="jp.co.kccs.greenearth.commons.db.GThinDriverConnectionManager" /&gt;
 * &lt;/bean&gt;
 * &lt;bean id="jp.co.kccs.greenearth.commons.db.GConnectionManager"
 *     class="jp.co.kccs.greenearth.commons.db.GAbstractConnectionManager"
 *     factory-bean="jp.co.kccs.greenearth.commons.db.GConnectionManagerFactory"
 *     factory-method="getInstance"
 *     destroy-method="removeConnections"&gt;
 *     &lt;property name="defaultAutoCommit" value="false" /&gt;
 * &lt;/bean&gt;
 * </pre>
 * 
 * ■インスタンスの生成方法<br>
 * {@link GConnectionManager}のインスタンスは、<code>new</code>するのではなく、{@link #getInstance()}メソッドを利用します。
 * <pre>
 * GConnectionManager manager = GConnectionManager.getInstance();
 * </pre>
 * 
 * 【メインデータソース】<br>
 * {@link GConnectionManager}の扱うデータソースには、<b>メインデータソース</b>と<b>サブデータソース</b>が存在します。<br><br>
 * ■<b>メインデータソース</b>
 * メインデータソースはそのデータソース名を<code>ge-framework.properties</code>に設定します。<br>
 * {@link jp.co.kccs.greenearth.commons.db.GDataSourceConnectionManager}を利用した場合の設定例
 * <pre>
 * #アプリケーションサーバに設定されているデータソース名を指定
 * geframe.commons.Db.MainDataSource=jdbc/JavaKitDataSource
 * </pre>
 * コネクションの取得方法
 * <pre>
 * GConnectionManager manager = GConnectionManager.getInstance();
 * Connection connection = manager.getConnection();
 * </pre>
 * 
 * ■<b>サブデータソース</b><br>
 * サブデータソースはそのデータソース名をAPI中に直接指定する必要があります。<br>
 * コネクションの取得方法
 * <pre>
 * GConnectionManager manager = GConnectionManager.getInstance();
 * Connection connection = manager.getConnection( "データソース名" );
 * </pre>
 * 
 * 【コネクションカウンタ】<br>
 * {@link GConnectionManager}はコネクションの管理にコネクションカウンタを用います。<br>
 * データソース毎にカウンタを用意し、{@link #catchConnection()}メソッドが呼ばれる度にカウンタを1アップします。
 * また、{@link #releaseConnection(Connection)}メソッドが呼ばれる度にカウンタを1ダウンします。<br>
 * {@link #catchConnection()}では、カウンタが０の時のみ実際にデータソースに対する接続を確立します。<br>
 * {@link #releaseConnection(Connection)}では、カウンタが0の時のみ実際にデータソースに対する接続を解放します。<br><br>
 * 
 * 【トランザクションカウンタ】<br>
 * <code>GConnectionManager</code>はトランザクションの管理にトランザクションカウンタを用います。<br>
 * コネクション毎にカウンタを用意し、{@link #beginTransaction(Connection)}メソッドが呼ばれる度にカウンタを1アップします。
 * また、{@link #commitTransaction(Connection)}メソッド、または、{@link #rollbackTransaction(Connection)}メソッドが
 * 呼ばれる度にカウンタを1ダウンします。<br>
 * {@link #beginTransaction(Connection)}では、カウンタが０の時のみ実際にコネクションに対するトランザクションを開始します。<br>
 * {@link #commitTransaction(Connection)}では、カウンタが０の時のみ実際にコネクションに対するトランザクションをコミットします。<br>
 * {@link #rollbackTransaction(Connection)}では、カウンタが０の時のみ実際にコネクションに対するトランザクションをロールバックします。<br>
 * 
 * @create 2006/12/31
 * @author kitamura
 * @since 3.0.0
 */
// NOTE: GConnectionManagerは、データベース接続以外にコネクションプールやトランザクション制御機能を有しています。
// そのためこのクラスはデータベース接続のみを切り出したGDBConnectionManagerインターフェースの実装とはしていません。
public abstract class GConnectionManager {

	/** メインデータソース名. */
	public static final String MAIN_DATA_SOURCE_PROPERTY = "geframe.commons.Db.MainDataSource";

	/**
	 * {@link GConnectionManager}インスタンスを取得します.<br>
	 * 
	 * 生成されたインスタンスのライフサイクルは、{@link #getLifecycle()}で取得される値によって決定されます。<br>
	 * <table border="1" cellpadding="3" cellspacing="0">
	 * <tr bgcolor="#CCCCFF"><td>値</td><td>ライクサイクル</td></tr>
	 *  <tr><td>new</td><td>毎回新規インスタンスを生成</td></tr>
	 *  <tr><td>singleton</td><td>初回アクセス時のみ生成し以降常に同じインスタンスを共有する</td></tr>
	 *  <tr><td>thread</td><td>同一スレッド上では同じインスタンスを共有する</td></tr>
	 * </table> 
	 * <br>
	 * 
	 * @create 2006/12/31
	 * @return インスタンス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GConnectionManager getInstance() {
		return GFrameworkUtils.getComponent(GConnectionManager.class.getName());
	}

	/**
	 * 指定された接続に対してトランザクションを開始します. <br>
	 * 既にトランザクションが開始している場合は、トランザクションカウンタをアップします。
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException トランザクションの開始に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract void beginTransaction(Connection connection) throws SQLException;

	/**
	 * メインデータソースに対する接続を確立します.<br>
	 * 既に接続が確立している場合は、コネクションカウンタをカウントアップします。
	 * 接続方法の詳細は、{@link #catchConnection(String)}の説明をご覧ください。
	 * 
	 * @create 2006/12/31
	 * @return 接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @see #catchConnection(String)
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract Connection catchConnection() throws SQLException;

	/**
	 * 指定した名前に該当するデータソースの接続を確立します. <br>
	 * 該当するデータソースへの接続が既に確立済みの場合は、新規接続を行わず、既に確立済みに接続を返します。
	 * 既に接続が確立している場合は、コネクションカウンタをカウントアップします。
	 * 
	 * @create 2006/12/31
	 * @param dataSourceName データソース名
	 * @return 該当データソースへの接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract Connection catchConnection(String dataSourceName) throws SQLException;

	/**
	 * メインデータソースに対する新規接続を確立します. <br>
	 * メインデータソースへの接続が既に確立している場合でも、新たに新規接続を確立します。
	 * 
	 * @create 2006/12/31
	 * @return 新規接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @see #catchNewConnection(String)
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract Connection catchNewConnection() throws SQLException;

	/**
	 * 指定したデータソースに対する新規接続を確立します. <br>
	 * 指定したデータソースへの接続が既に確立している場合でも、新たに新規接続を確立します。<br>
	 * このメソッドは、既に確立している接続とは別に新たに接続を確立し、作業したい場合に利用します。
	 * 未接続の場合は新規接続を、既に接続済みの場合は接続済みのコネクションを利用して作業し対場合は、
	 * {@link #catchConnection()}メソッドを利用して接続の確立を行ってください。<br>
	 * <br>
	 * 注意:このメソッドを利用して取得した{@link Connection}オブジェクトに関しては、
	 * {@link #releaseConnection(Connection)}メソッドによるコネクションの解放は行えず、
	 * 取得された<code>Connection</code>オブジェクトに対して、{@link Connection#close()}メソッドをコール必要がありますのでご注意ください。
	 * 
	 * @create 2006/12/31
	 * @param dataSourceName データソース名
	 * @return 新規接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract Connection catchNewConnection(String dataSourceName) throws SQLException;

	/**
	 * 指定された接続のトランザクションをコミットします.<br>
	 * コネクションに関連づくトランザクションカウンタをカウントダウンし、
	 * カウンタが0になって初めて、実際にトランザクションをコミットします。
	 * カウンタが0以外の場合は何も行いません。
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException トランザクションのコミットに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract void commitTransaction(Connection connection) throws SQLException;

	/**
	 * メインデータソースに対して確立されている接続を取得します. <br>
	 * まだ接続が確立していない場合はnullを返します。<br>
	 * 接続を確立する場合は{@link #catchConnection()}を呼び出してください。
	 * 
	 * @create 2006/12/31
	 * @return 接続
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Deprecated
	public abstract Connection getConnection();

	/**
	 * 指定したデータソースに対して確立されている接続を取得します. <br>
	 * まだ接続が確立していない場合はnullを返します。<br>
	 * 接続を確立する場合は{@link #catchConnection(String)}を呼び出してください。
	 * 
	 * @create 2006/12/31
	 * @param dataSourceName データソース名
	 * @return 接続
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Deprecated
	public abstract Connection getConnection(String dataSourceName);

	/**
	 * 指定された接続を解放します.<br>
	 *
	 * コネクションに関連づくコネクションカウンタをカウントダウンし、
	 * カウンタが0になって初めて、実際に接続を解放します。
	 * カウンタが0以外の場合は何も行いません。<br>
	 *
	 * 注意:解放対象は、{@link #catchConnection()}または{@link #catchConnection(String)}メソッドで
	 * 取得した{@link Connection}オブジェクトのみです。<br>
	 * これ以外の方法で取得した{@link Connection}の解放は行えません。
	 * 
	 * @create 2006/12/31
	 * @param connection 接続
	 * @throws SQLException コネクションの解放に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract void releaseConnection(Connection connection) throws SQLException;

	/**
	 * 指定された接続のトランザクションをロールバックします.
	 * <br>
	 * コネクションに関連づくトランザクションカウンタをカウントダウンし、
	 * カウンタが0になって初めて、実際にトランザクションをロールバックします。
	 * カウンタが0以外の場合は何も行いません。
	 * 
	 * @create 2006/12/31
	 * @param connection コネクション
	 * @throws SQLException トランザクションのロールバックに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract void rollbackTransaction(Connection connection) throws SQLException;

	/**
	 * マップに保持した接続をすべて閉じてcloseします。
	 * <br />
	 * DI定義のdestroy-method(Spring Framework)、destroyMethod(Seaser2)に設定するメソッドです。
	 */
	public abstract void removeConnections();

}
