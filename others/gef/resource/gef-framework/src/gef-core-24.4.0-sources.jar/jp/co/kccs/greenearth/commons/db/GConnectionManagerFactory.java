/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.db;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * {@link GConnectionManager}のインスタンスを生成するファクトリーです。
 * 
 * @author KCCS Shigeki Shoji
 */
public class GConnectionManagerFactory {

	/** スレッドローカルライフサイクル指定文字列. */
	private static final String THREAD = "thread";
	
	/**
	 * インスタンス化する{@link GConnectionManager}のクラス。
	 */
	private Class<? extends GConnectionManager> clazz;

	/**
	 * ライフサイクル。
	 * <br />
	 * 指定可能な値は"thread"のみですが、request等で代用できる場合はそちらを推奨します。
	 * "thread"にした場合、removeConnectionsをスレッド終了時に実行することができません。
	 */
	private String lifecycle;

	/** ライフサイクルがthreadの場合のインスタンスを保持します(seaser2の場合に使用します). */
	private ThreadLocal<GConnectionManager> connectionManager = new ThreadLocal<GConnectionManager>();
	
	/**
	 * コンストラクタ。
	 * 
	 * @param clazz インスタンス化する{@link GConnectionManager}のクラス
	 */
	public GConnectionManagerFactory(Class<? extends GConnectionManager> clazz) {
		this(clazz, null);
	}

	/**
	 * コンストラクタ。
	 * 
	 * @param clazz インスタンス化する{@link GConnectionManager}のクラス
	 * @param lifecycle ライフサイクル(thread)
	 */
	public GConnectionManagerFactory(Class<? extends GConnectionManager> clazz, String lifecycle) {
		this.clazz = clazz;
		this.lifecycle = lifecycle;
	}
	
	/**
	 * {@link GConnectionManager}のインスタンスを返します。
	 * 
	 * @return {@link GConnectionManager}のインスタンス
	 * 
	 * @throws InstantiationException インスタンス化の例外
	 * @throws IllegalAccessException アクセス例外
	 * @throws InvocationTargetException 実行例外
	 * @throws NoSuchMethodException コンストラクタが見つからない場合の例外
	 * @throws IllegalArgumentException 引数例外
	 * @throws SecurityException セキュリティ例外
	 */
	public GConnectionManager getInstance() throws InstantiationException, IllegalAccessException, SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
		// NOTE:
		// このメソッドは、GConnectionManagerを返すため、
		// GDBConnectionManagerとGConnectionManagerとで異なるオブジェクトをインスタンス化させることができます。
		GConnectionManager instance = null;
		if (THREAD.equals(lifecycle)) {
			synchronized (connectionManager) {
				instance = connectionManager.get();
				if (null == instance) {
					Constructor<? extends GConnectionManager> constructor = clazz.getDeclaredConstructor();
					constructor.setAccessible(true);
					instance = constructor.newInstance();
					connectionManager.set(instance);
				}
			}
		} else {
			Constructor<? extends GConnectionManager> constructor = clazz.getDeclaredConstructor();
			constructor.setAccessible(true);
			instance = constructor.newInstance();
		}
		return instance;
	}

}
