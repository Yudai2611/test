/*
 * Copyright 2007-2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * アプリケーションサーバーのコネクション管理機能（{@link DataSource}）
 * を利用したデータベースへの接続（コネクション）を管理します.
 * <br>
 * <pre>
 * InitialContext ic = new InitialContext();
 * DataSource dataSource = (DataSource)ic.lookup( dataSourceName );
 * Connection connection = dataSource.getConnection();
 * </pre>
 * 
 * データソース名には、アプリケーションサーバに設定されているデータソース名を指定して下さい。<br><br>
 * 
 * <b>【DefaultAutoCommit】</b><br>
 * DefaultAutoCommitを<code>false<code>に設定すると、トランザクションの開始、コミット、ロールバックに関係なく、
 * コネクション確立時から解放時まで、常時AutoCommit設定を<code>false</code>のまま処理を実行します。<br>
 * DefaultAutoCommitの設定は、DI定義ファイル内のセッターインジェクションで定義してください。<br>
 * <br>
 * [設定例(Spring Frameworkの場合)]<br>
 * <pre>
 * &lt;bean name="jp.co.kccs.greenearth.commons.db.GConnectionManager" class="jp.co.kccs.greenearth.commons.db.GDataSourceConnectionManager" singleton="false"> 
 *    &lt;property name="lifecycle">&lt;value>thread&lt;/value>&lt;/property>
 *    <b>&lt;property name="defaultAutoCommit">&lt;value>false&lt;/value>&lt;/property></b>
 * &lt;/bean>
 * </pre>
 * 
 * @see javax.sql.DataSource
 * @see jp.co.kccs.greenearth.framework.db.GAbstractConnectionManager
 * @see jp.co.kccs.greenearth.framework.db.GConnectionManager
 * @create 2006/12/30
 * @author kitamura
 * @since 3.0.0
 */
public class GDataSourceConnectionManager extends GAbstractConnectionManager {

	/** プロパティヘッダ. */
	private static final String	PROPERTY_HEADER	= "java:comp/env/";

	/**
	 * {@link GDataSourceConnectionManager*インスタンスを初期化します.
	 * 
	 * @create 2006/12/31
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GDataSourceConnectionManager() {
	}

	// -----パブリックメソッド--------------------------------------------------------------------

	/**
	 * 指定したデータソースに対する新規接続を確立します.
	 * 
	 * @create 2006/12/31
	 * @param dataSourceName データソース名
	 * @return 新規接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @throws GFrameworkException データソースルックアップ時にネーミング例外が発生した場合
	 * @see GConnectionManager#catchNewConnection(String)
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public Connection catchNewConnection(String dataSourceName) throws SQLException, GFrameworkException {
		try {
			InitialContext ic = new InitialContext();
			DataSource dataSource = (DataSource) ic.lookup(PROPERTY_HEADER + dataSourceName);
			Connection connection = dataSource.getConnection();

			// DefaultAutoCommitの設定
			if (connection.getAutoCommit() != isDefaultAutoCommit()) {
				setAutoCommit(connection, isDefaultAutoCommit());
			}

			LOGGER.debug("Catch Connection : hashcode=" + connection.hashCode() + " datasource=" + dataSourceName);
			return connection;
		}
		catch (NamingException e) {
			throw new GFrameworkException(e);
		}
	}

	// -----プロテクテッドメソッド--------------------------------------------------------------------

	/**
	 * メインのデータソース名を取得します.
	 * 
	 * @create 2006/12/31
	 * @return データソース名
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	protected String getMainDataSourceName() {
		return GFrameworkUtils.getProperty(MAIN_DATA_SOURCE_PROPERTY);
	}
}
