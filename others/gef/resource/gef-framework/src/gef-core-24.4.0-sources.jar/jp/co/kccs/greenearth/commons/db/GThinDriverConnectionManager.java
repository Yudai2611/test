/*
 * Copyright 2007-2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.db;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Stack;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Thin Driverのコネクション管理機能（{@link DriverManager}）
 * を利用したデータベースへの接続（コネクション）を管理します.
 * <br>
 * <pre>
 * Class.forName( "ドライバクラス名" );
 * Connection connection = DriverManager.getConnection( "url", "userID", "password" );
 * </pre>
 * 
 * <b>【接続情報の設定】</b><br>
 * Thin Driverのコネクションの接続情報は、<code>ge-dbconnect.xml</code>に記述します。<br>
 * データソース名には、<code>ge-dbconnect.xml</code>に設定されている&lt;name/&gtタグに設定した値を指定して下さい。<br>
 * 設定内容は以下のように記述します。<br>
 * <pre>
 * &lt;?xml version="1.0" encoding="UTF-8"?&gt;
 * &lt;connections&gt;
 * 	&lt;database&gt;
 * 		&lt;name&gt;jdbc/JavaKitDataSource&lt;/name&gt;
 * 		&lt;jdbcDriver&gt;oracle.jdbc.driver.OracleDriver&lt;/jdbcDriver&gt;
 * 		&lt;url&gt;jdbc:oracle:thin:@172.26.4.161:1521:geframe&lt;/url&gt;
 * 		&lt;userID&gt;geframe&lt;/userID&gt;
 * 		&lt;password&gt;geframe&lt;/password&gt;
 * 	&lt;/database&gt;
 * 	&lt;database&gt;
 * 		&lt;name&gt;jdbc/AmoebaDataSource&lt;/name&gt;
 * 		&lt;jdbcDriver&gt;oracle.jdbc.driver.OracleDriver&lt;/jdbcDriver&gt;
 * 		&lt;url&gt;jdbc:oracle:thin:@172.26.4.163:1521:geframe2&lt;/url&gt;
 * 		&lt;userID&gt;amoeba&lt;/userID&gt;
 * 		&lt;password&gt;amoeba&lt;/password&gt;
 * 	&lt;/database&gt;
 * &lt;/connections&gt;
 * </pre>
 * 
 * <b>【ge-dbconnect.xmlの妥当性検証】</b><br>
 * ge-dbconnect.xmlの妥当性検証のために、同XMLファイルに対応するXML Schemaを定義しています。<br>
 * XML Schemaは/jp/co/kccs/greenearth/commons/dbパッケージ化のge-connect.xsdファイルとして定義されています。
 * <br><br>
 *
 * <b>【DefaultAutoCommit】</b><br>
 * DefaultAutoCommitを<code>false<code>に設定すると、トランザクションの開始、コミット、ロールバックに関係なく、
 * コネクション確立時から解放時まで、常時AutoCommit設定を<code>false</code>のまま処理を実行します。<br>
 * DefaultAutoCommitの設定は、DI定義ファイル内のセッターインジェクションで定義してください。<br>
 * <br>
 * [設定例(Spring Frameworkの場合)]<br>
 * <pre>
 * &lt;bean name="jp.co.kccs.greenearth.commons.db.GConnectionManager" class="jp.co.kccs.greenearth.commons.db.GDataSourceConnectionManager" singleton="false"> 
 *    &lt;property name="lifecycle">&lt;value>thread&lt;/value>&lt;/property>
 *    <b>&lt;property name="defaultAutoCommit">&lt;value>false&lt;/value>&lt;/property></b>
 * &lt;/bean>
 * </pre>
 * 
 * @see java.sql.DriverManager
 * @see jp.co.kccs.greenearth.framework.db.GAbstractConnectionManager
 * @see jp.co.kccs.greenearth.framework.db.GConnectionManager
 * @create 2006/12/30
 * @author ueda
 * @since 3.0.0
 */
public class GThinDriverConnectionManager extends GAbstractConnectionManager {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GConnectionManager.class);

	/** DB接続設定ファイルのXML Schemaファイル名. */
	private static final String DB_CONNECT_CONFIG_FILE_SCHEMA = "ge-dbconnect.xsd";

	/** DB接続設定ファイル名. */
	private static final String DB_CONNECT_CONFIG_FILE = "ge-dbconnect.xml";

	// -----パブリックメソッド--------------------------------------------------------------------

	/**
	 * {@link GThinDriverConnectionManager}インスタンスを初期化します.
	 * 
	 * @create 2006/12/31
	 * @author ueda
	 * @throws GFrameworkException XMLSchemaによる妥当性検証に失敗した場合
	 * @since 3.0.0
	 */
	public GThinDriverConnectionManager() throws GFrameworkException {
		super();
		try {
			validate();
		}
		catch (SAXException e) {
			throw new GFrameworkException(e);
		}
		catch (IOException e) {
			throw new GFrameworkException(e);
		}
		catch (URISyntaxException e) {
			throw new GFrameworkException(e);
		}
	}

	/**
	 * 指定したデータソースに対する新規接続を確立します.
	 * 
	 * @create 2006/12/31
	 * @param dataSourceName データソース名
	 * @return 新規接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @throws GFrameworkException DB接続設定ファイルの読込に失敗した場合、ドライバクラスが見つからない場合
	 * @see GConnectionManager#catchNewConnection(String)
	 * @author ueda
	 * @since 3.0.0
	 */
	@Override
	public Connection catchNewConnection(String dataSourceName) throws SQLException, GFrameworkException {
		try {
			// TODO [kitamura][2007/08/02]一度読み込んだ接続定義ファイルの情報はキャッシュするべき
			// 接続情報取得
			DBConnectConfigHandler handler = new DBConnectConfigHandler();
			DBConnectConfigItem configItem = handler.lookup(dataSourceName);
			if (configItem == null) {
				throw new GFrameworkException(new ParserConfigurationException("DataSource is not found. [" + dataSourceName + "]"));
			}
			String jdbcDriver = configItem.getJdbcDriver();
			String jdbcUrl = configItem.getUrl();
			String userID = configItem.getUserID();
			String password = configItem.getPassword();

			Class.forName(jdbcDriver);
			Connection connection = DriverManager.getConnection(jdbcUrl, userID, password);

			// DefaultAutoCommitの設定
			if (connection.getAutoCommit() != isDefaultAutoCommit()) {
				setAutoCommit(connection, isDefaultAutoCommit());
			}

			LOGGER.debug("Catch Connection : hashcode=" + connection.hashCode() + " datasource=" + dataSourceName);
			return connection;
		}
		catch (ParserConfigurationException e) {
			throw new GFrameworkException(e);
		}
		catch (SAXException e) {
			throw new GFrameworkException(e);
		}
		catch (IOException e) {
			throw new GFrameworkException(e);
		}
		catch (ClassNotFoundException e) {
			throw new GFrameworkException(e);
		}
	}

	// -----プロテクテッドメソッド--------------------------------------------------------------------

	/**
	 * メインのデータソース名を取得します.
	 * 
	 * @create 2007/02/01
	 * @return データソース名
	 * @author ueda
	 * @since 3.0.0
	 */
	@Override
	protected String getMainDataSourceName() {
		return GFrameworkUtils.getProperty(MAIN_DATA_SOURCE_PROPERTY);
	}

	/**
	 * XMLファイルがXML Schemaファイルを使って、検証します。
	 * 
	 * @throws SAXException XML構文解析に失敗した場合
	 * @throws IOException コネクトファイル、スキーマファイルが存在しない場合
	 *                      またはコネクトファイルに検証エラーがあった場合
	 * @throws URISyntaxException スキーマファイルのパスがURIとして認識できない場合
	 * @create 2007/07/19
	 * @author wang chenjun
	 * @since 3.2.0
	 */
	private void validate() throws SAXException, IOException, URISyntaxException {
		String xmlFile = GFileUtils.getResource(getDbConnectConfigFileName()).toString();
		InputStream in = GConnectionManager.class.getResourceAsStream(DB_CONNECT_CONFIG_FILE_SCHEMA);
		if (xmlFile == null || "".equals(xmlFile)) {
			throw new FileNotFoundException(getDbConnectConfigFileName() + " is not found.");
		}
		if (in == null) {
			throw new FileNotFoundException(DB_CONNECT_CONFIG_FILE_SCHEMA + " is not found.");
		}
		// Get Document Builder Factory
		SAXParserFactory factory = SAXParserFactory.newInstance();

		// Leave off validation, and turn off namespaces
		factory.setValidating(false);
		factory.setNamespaceAware(false);

		// Handle validation
		SchemaFactory constraintFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Source constraints = new StreamSource(in);
		Schema schema = constraintFactory.newSchema(constraints);
		Validator validator = schema.newValidator();

		// Validate
		try {
			validator.validate(new SAXSource(new InputSource(xmlFile)));
		}
		catch (SAXException e) {
			LOGGER.error(getDbConnectConfigFileName() + "has validate errors.");
			throw e;
		}
	}

	/**
	 * DB接続設定ファイル名を取得します.<br>
	 * 
	 * @create 2007/08/02
	 * @return DB接続設定ファイル名
	 * @author kitamura
	 * @since 3.2.0
	 */
	protected String getDbConnectConfigFileName() {
		return DB_CONNECT_CONFIG_FILE;
	}

	// -----インナークラス--------------------------------------------------------------------

	/**
	 * SAX 用 イベントハンドラ.<br>
	 * DB接続設定XMLを解析し、接続情報{@link DBConnectConfigItem}を構築します。<br>
	 * 
	 * @create 2007/01/26
	 * @author ueda
	 * @since 3.0.0
	 */
	private final class DBConnectConfigHandler extends DefaultHandler {

		/** 現在のデータベース接続情報. */
		private DBConnectConfigItem configItem = new DBConnectConfigItem();

		/** データベース接続情報. */
		private DBConnectConfigItem dataSourceConfigItem;

		/** データソース名. */
		private String dataSourceName;

		/** 現在のタグを格納するスタック. */
		private Stack<String> tagStack = new Stack<String>();

		/**
		 * コンストラクタです.<br>
		 * 
		 * @create 2007/01/26
		 * @author ueda
		 * @since 3.0.0
		 */
		private DBConnectConfigHandler() {
		}

		/**
		 * 内容を読み取ったときに呼ばれます.<br>
		 * 接続情報インスタンスに設定内容を格納します。<br>
		 * 
		 * @param ch 文字データ
		 * @param start 文字配列内の開始位置
		 * @param length 文字配列から使用される文字数
		 * @throws SAXException SAX 例外。ほかの例外をラップしている可能性がある
		 * @create 2007/01/26
		 * @author ueda
		 * @since 3.0.0
		 */
		public void characters(char[] ch, int start, int length) throws SAXException {
			// 設定内容
			String text = new String(ch, start, length).trim();
			if (text.length() == 0) {
				return;
			}
			// 接続情報インスタンスに設定内容を格納します。
			if (getCurrentTag().equals("name")) {
				configItem.setDatabaseName(text);
			}
			else if (getCurrentTag().equals("jdbcDriver")) {
				configItem.setJdbcDriver(text);
			}
			else if (getCurrentTag().equals("url")) {
				configItem.setUrl(text);
			}
			else if (getCurrentTag().equals("userID")) {
				configItem.setUserID(text);
			}
			else if (getCurrentTag().equals("password")) {
				configItem.setPassword(text);
			}
		}

		/**
		 * 終了タグに来たら呼ばれます.<br>
		 * 接続情報インスタンスに設定内容を格納します。<br>
		 * 
		 * @param namespaceURI 名前空間 URI
		 * @param localName 接頭辞を含まないローカル名
		 * @param qName 接頭辞を持つ修飾名
		 * @throws SAXException SAX 例外。ほかの例外をラップしている可能性がある
		 * @create 2007/01/26
		 * @author ueda
		 * @since 3.0.0
		 */
		public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
			if (getCurrentTag().equals("database")) {
				if (dataSourceName.equals(configItem.getDatabaseName())) {
					dataSourceConfigItem = configItem;
				}
				configItem = new DBConnectConfigItem();
			}
			// 現在のタグ名を解放
			tagStack.pop();
		}

		/**
		 * タグの開始位置に来ると呼ばれます.<br>
		 * 　・タグが<code>database</code>の時、接続情報をインスタンスを初期化します。<br>
		 * 　・現在のタグ名を保存します。<br>
		 * 
		 * @param namespaceURI 名前空間 URI
		 * @param localName 接頭辞を含まないローカル名
		 * @param qName 接頭辞を持つ修飾名
		 * @param atts 要素に付加された属性
		 * @create 2007/01/26
		 * @author ueda
		 * @since 3.0.0
		 */
		public void startElement(String namespaceURI, String localName, String qName, Attributes atts) {
			if (qName.equals("database")) {
				// 接続情報インスタンス初期化
				configItem = new DBConnectConfigItem();
			}
			// 現在のタグ名を保存
			tagStack.push(qName);

		}

		/**
		 * 現在のタグを取得します.<br>
		 * 
		 * @return 現在のタグ
		 * @create 2007/01/26
		 * @author ueda
		 * @since 3.0.0
		 */
		private String getCurrentTag() {
			return (String) tagStack.peek();
		}

		/**
		 * DB接続設定ファイルから指定されたデータソース名の接続情報を取得します.<br>
		 * 
		 * @param dataSourceName データソース名
		 * @return 指定されたデータソース名のDB接続設定情報
		 * @throws SAXException SAX例外
		 * @throws ParserConfigurationException パーサ生成例外
		 * @throws IOException IO例外
		 * @create 2007/01/26
		 * @author ueda
		 * @since 3.0.0
		 */
		private DBConnectConfigItem lookup(String dataSourceName) throws ParserConfigurationException, SAXException, IOException {
			if (dataSourceName == null || dataSourceName.equals("")) {
				throw new IllegalArgumentException();
			}
			this.dataSourceName = dataSourceName;
			// パーサの生成
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			// XML構文解析
			URL url = GFileUtils.getResource(getDbConnectConfigFileName());
			parser.parse(url.toString(), this);

			return dataSourceConfigItem;
		}

	}

	/**
	 * 接続情報を表します.
	 * 
	 * @create 2007/01/26
	 * @author ueda
	 * @since 3.0.0
	 */
	private final class DBConnectConfigItem {

		/** データベース名. */
		private String databaseName;
		/** JDBCドライバ. */
		private String jdbcDriver;
		/** DB接続パスワード. */
		private String password;
		/** 接続先URL. */
		private String url;
		/** DB接続ユーザID. */
		private String userID;

		/**
		 * コンストラクタです.<br>
		 * 
		 * @create 2007/01/26
		 * @author ueda
		 * @since 3.0.0
		 */
		private DBConnectConfigItem() {
		}

		/**
		 * データベース名を取得します.
		 * 
		 * @create 2007/01/26
		 * @return データベース名。
		 * @author ueda
		 * @since 3.0.0
		 */
		protected String getDatabaseName() {
			return databaseName;
		}

		/**
		 * データベース名を設定します.<br>
		 * 
		 * @create 2007/01/26
		 * @param name データベース名
		 * @author ueda
		 * @since 3.0.0
		 */
		protected void setDatabaseName(String name) {
			if (this.databaseName != null) {
				databaseName += name;
			} else {
				databaseName = name;
			}
		}

		/**
		 * JDBCドライバを設定します.<br>
		 * 
		 * @create 2007/01/26
		 * @param driver JDBCドライバ。
		 * @author ueda
		 * @since 3.0.0
		 */
		protected void setJdbcDriver(String driver) {
			if (this.jdbcDriver != null) {
				jdbcDriver += driver;
			} else {
				jdbcDriver = driver;
			}
		}

		/**
		 * DB接続パスワードを設定します.<br>
		 * 
		 * @create 2007/01/26
		 * @param password DB接続パスワード。
		 * @author ueda
		 * @since 3.0.0
		 */
		protected void setPassword(String password) {
			if (this.password != null) {
				this.password += password;
			} else {
				this.password = password;
			}
		}

		/**
		 * 接続先URLを設定します.<br>
		 * 
		 * @create 2007/01/26
		 * @param url 接続先URL。
		 * @author ueda
		 * @since 3.0.0
		 */
		protected void setUrl(String url) {
			if (this.url != null) {
				this.url += url;
			} else {
				this.url = url;
			}
		}

		/**
		 * DB接続ユーザIDを設定します.<br>
		 * 
		 * @create 2007/01/26
		 * @param userid DB接続ユーザID。
		 * @author ueda
		 * @since 3.0.0
		 */
		protected void setUserID(String userid) {
			if (this.userID != null) {
				userID += userid;
			} else {
				userID = userid;
			}
		}

		/**
		 * JDBCドライバを取得します.
		 * 
		 * @create 2007/01/26
		 * @return JDBCドライバ
		 * @author ueda
		 * @since 3.0.0
		 */
		private String getJdbcDriver() {
			return jdbcDriver;
		}

		/**
		 * DB接続パスワードを取得します.
		 * 
		 * @create 2007/01/26
		 * @return DB接続パスワード
		 * @author ueda
		 * @since 3.0.0
		 */
		private String getPassword() {
			return password;
		}

		/**
		 * 接続先URLを取得します.
		 * 
		 * @create 2007/01/26
		 * @return 接続先URL
		 * @author ueda
		 * @since 3.0.0
		 */
		private String getUrl() {
			return url;
		}

		/**
		 * DB接続ユーザIDを取得します.
		 * 
		 * @create 2007/01/26
		 * @return DB接続ユーザID
		 * @author ueda
		 * @since 3.0.0
		 */
		private String getUserID() {
			return userID;
		}
	}
}
