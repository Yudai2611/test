/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di;

import java.util.Map;

/**
 * DI Containerです.
 *
 * @create 2005/03/22
 * @author kusakari
 * @since 3.0.0
 */
public interface GDIContainer {

	/** コンテナの破棄。 */
	void destroy();

	/**
	 * 親コンテナを返します。
	 *
	 * @return 親コンテナ
	 */
	GDIContainer getParent();

	/**
	 * コンテナより指定したキーに紐づくクラスのインスタンスを取得します.
	 * <ul>
	 * <li>キーがクラスの場合は、そのクラスのインスタンスを返します。</li>
	 * <li>キーが文字列の場合は、その定義名のインスタンスを返します。</li>
	 * </ul>
	 *
	 * @see org.springframework.beans.factory.BeanFactory#getBean(Class)
	 * @see org.springframework.beans.factory.BeanFactory#getBean(String)
	 *
	 * @create 2005/03/31
	 * @param key キー
	 * @return インスタンス
	 * @author kitamura
	 * @since 3.0.0
	 */
	Object getComponent(Object key);

	/**
	 * Typeに一致するコンポーネントをマップで返します。
	 *
	 * @see org.springframework.beans.factory.ListableBeanFactory#getBeansOfType(Class)
	 *
	 * @param type Type
	 * @return コンポーネント名とコンポーネントのマップ。
	 */
	<T> Map<String, T> findComponents(Class<T> type);

	/**
	 * コンポーネント名に一致するDI定義の内容でインスタンス化されたコンポーネントの設定を実行します。
	 *
	 * @see org.springframework.beans.factory.config.AutowireCapableBeanFactory#configureBean(Object, String)
	 *
	 * @param component コンポーネント
	 * @param name コンポーネント名
	 */
	Object configureComponent(Object component, String name);

}
