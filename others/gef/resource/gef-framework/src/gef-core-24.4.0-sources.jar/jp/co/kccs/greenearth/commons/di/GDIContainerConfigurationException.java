/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di;

/**
 * ContainerFactoryの構成に問題が存在する場合にスローされます.<br>
 * 通常、このエラーは、指定されたファクトリのクラスが見つからないか、インスタンス化できない場合にスローされます。
 * 
 * @create 2005/03/30
 * @author kitamura
 * @since 3.0.0
 */
public class GDIContainerConfigurationException extends RuntimeException {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = -6877610128474196223L;

	/**
	 * 詳細メッセージに <code>null</code> を使用して、新しい実行時例外を構築します.
	 * 
	 * @create 2005/03/30
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GDIContainerConfigurationException() {
		super();
	}

	/**
	 * 指定された詳細メッセージを使用して、新しい実行時例外を構築します.
	 * 
	 * @create 2005/03/30
	 * @param message 詳細メッセージ。
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GDIContainerConfigurationException(final String message) {
		super(message);
	}

	/**
	 * 指定された詳細メッセージおよび原因を使用して新しい実行時例外を構築します.
	 * 
	 * @create 2005/03/30
	 * @param message 詳細メッセージ
	 * @param cause 原因
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GDIContainerConfigurationException(final String message, final Throwable cause) {
		super(message, cause);
	}

	/**
	 * 指定された原因および詳細メッセージを使用して新しい実行時例外を構築します。
	 * 
	 * @create 2005/03/30
	 * @param cause 原因
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GDIContainerConfigurationException(final Throwable cause) {
		super(cause);
	}
}
