/*
 * Copyright 2012-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di;

/**
 * DIコンテナの生成するファクトリのインターフェースです。
 * 
 * @author KCCS Shigeki Shoji
 */
public interface GDIContainerFactory {

	/**
	 * DIコンテナを取得します。
	 * 
	 * @param context コンテキスト
	 * @param configPath 定義ファイル
	 */
	GDIContainer getDIContainer(Object context, String configPath);

}
