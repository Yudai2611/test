/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di;

/**
 * コンテナスコープに対応するコンテナを登録、取得するインターフェース.
 * 
 * @author KCCS Shigeki Shoji
 */
public interface GDIContainerRegistry {

	/**
	 * コンテナをコンテナスコープに関連付けて登録します。
	 * 
	 * @param container コンテナ
	 */
	void registerDIContainer(GDIContainer container);

	/**
	 * コンテナスコープに関連付けられたコンテナを返します。
	 * 
	 * @return 関連付けられたコンテナまたはnull
	 */
	GDIContainer getDIContainer();

	/**
	 * コンテナスコープに関連付けられたコンテナを削除します。
	 */
	void removeDIContainer();
	
}
