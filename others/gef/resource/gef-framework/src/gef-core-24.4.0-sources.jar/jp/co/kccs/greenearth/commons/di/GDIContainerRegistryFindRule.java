/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di;

/**
 * Registryを取得するルール.
 * 
 * @author KCCS Shigeki Shoji
 */
public interface GDIContainerRegistryFindRule {

	/**
	 * {@link GDIContainerRegistry}を返します。
	 * 
	 * @return {@link GDIContainerRegistry}
	 */
	GDIContainerRegistry getRegistry();
	
}
