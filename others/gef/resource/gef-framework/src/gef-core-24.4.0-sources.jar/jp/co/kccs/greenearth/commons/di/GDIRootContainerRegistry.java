/*
 * Copyright 2012-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di;

import java.util.List;

/**
 * DIコンテナ管理。
 * 
 * @author KCCS Shigeki Shoji
 */
public class GDIRootContainerRegistry {

	/** インスタンス。*/
	private static GDIRootContainerRegistry instance = new GDIRootContainerRegistry();

	/** DIコンテナ。 */
	private GDIContainer container = null;

	/**
	 * {@link GDIContainerRegistryFindRule}のリスト.
	 */
	private List<GDIContainerRegistryFindRule> rules = null;
	
	/**
	 * コンストラクタ。
	 */
	private GDIRootContainerRegistry() {
	}

	/**
	 * インスタンスを返します。
	 * 
	 * @return インスタンス
	 */
	public static GDIRootContainerRegistry getInstance() {
		return instance;
	}

	/**
	 * {@link GDIContainerRegistryFindRule}のリストを設定します。
	 * 
	 * @param rules {@link GDIContainerRegistryFindRule}のリスト
	 */
	public void setRules(List<GDIContainerRegistryFindRule> rules) {
		this.rules = rules;
	}

	/**
	 * {@link GDIContainerRegistry}を返します。
	 * 
	 * @return {@link GDIContainerRegistry}
	 */
	private GDIContainerRegistry getRegistry() {
		GDIContainerRegistry registry = null;
		for (GDIContainerRegistryFindRule rule : rules) {
			registry = rule.getRegistry();
			if (null != registry) {
				break;
			}
		}
		return registry;
	}
	
	/**
	 * DIコンテナを設定します。
	 * 
	 * @param container DIコンテナ
	 */
	public void registerDIContainer(GDIContainer container) {
		if (null != rules) {
			GDIContainerRegistry registry = getRegistry();
			if (null != registry) {
				registry.registerDIContainer(container);
				return;
			}
		}
		this.container = container;
	}

	/**
	 * DIコンテナを返します。
	 * 
	 * @return DIコンテナ
	 */
	public GDIContainer getDIContainer() {
		GDIContainer container = this.container;
		if (null != rules) {
			GDIContainerRegistry registry = getRegistry();
			if (null != registry) {
				return registry.getDIContainer();
			}
		}
		return container;
	}

	/**
	 * 登録されたコンテナを削除します。
	 */
	public void removeDIContainer() {
		if (null != rules) {
			GDIContainerRegistry registry = getRegistry();
			if (null != registry) {
				registry.removeDIContainer();
				return;
			}
		}
		this.container = null;
	}
	
}
