/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di.creation;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;

/**
 * {@link GFrameworkUtils#getComponent(Class)}を利用しインスタンス化を行います.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GDIComponentInstantiator implements GObjectInstantiator {

	/**
	 * {@inheritDoc}
	 * {@link GFrameworkUtils#getComponent(String)}および{@link GFrameworkUtils#getComponent(Class)}を利用します。<br/>
	 * インスタンス化できない場合、デフォルトコンストラクタを利用します。<br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> Optional<T> newInstance(Class<?> clazz) {
		Optional<T> instance = newInstanceWithDI(clazz);
		if (instance.isPresent()) {
			return instance;
		}
		try {
			return Optional.of((T) clazz.getConstructor().newInstance());
		} catch (NoSuchMethodException | InvocationTargetException | InstantiationException | IllegalAccessException e) {
			;	// インスタンス化できない場合、Optional#emptyを返却するため
		}
		return Optional.empty();
	}

	/**
	 * {@inheritDoc}
	 * {@link GFrameworkUtils#getComponent(String)}および{@link GFrameworkUtils#getComponent(Class)}を利用します。<br/>
	 * インスタンス化できない場合、パラメータ付きコンストラクタを利用します。<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> Optional<T> newInstance(Class<?> clazz, Class<?>[] parameterClasses, Object[] parameters) {
		Optional<T> instance = newInstanceWithDI(clazz);
		if (instance.isPresent()) {
			return instance;
		}
		try {
			return Optional.of((T) constructComponent(clazz, parameters, parameterClasses));
		} catch (NoSuchMethodException | InvocationTargetException | InstantiationException | IllegalAccessException e) {
			;	// インスタンス化できない場合、Optional#emptyを返却するため
		}
		return Optional.empty();
	}

	/**
	 * {@inheritDoc}
	 * {@link GFrameworkUtils#getComponent(String)}および{@link GFrameworkUtils#getComponent(Class)}を利用します。<br/>
	 * インスタンス化できない場合、デフォルトコンストラクタを利用します。<br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> Optional<T> newInstance(String clazz) {
		Optional<Class<?>> clazzTempOptional = GReflectionHelper.classForName(clazz);
		if (clazzTempOptional.isEmpty()) {
			return Optional.empty();
		}
		return newInstance(clazzTempOptional.get());
	}

	/**
	 * {@inheritDoc}
	 * {@link GFrameworkUtils#getComponent(String)}および{@link GFrameworkUtils#getComponent(Class)}を利用します。<br/>
	 * インスタンス化できない場合、パラメータ付きコンストラクタを利用します。<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> Optional<T> newInstance(String clazz, Class<?>[] parameterClazz, Object[] parameters) {
		Optional<Class<?>> clazzTempOptional = GReflectionHelper.classForName(clazz);
		if (clazzTempOptional.isEmpty()) {
			return Optional.empty();
		}
		return newInstance(clazzTempOptional.get(), parameterClazz, parameters);
	}

	@SuppressWarnings("unchecked")
	private <T> Optional<T> newInstanceWithDI(Class<?> clazz) {
		try {
			T instance = (T) GFrameworkUtils.getComponent(clazz.getName());
			if (Objects.nonNull(instance)) {
				return Optional.of(instance);
			}
		} catch(NoSuchBeanDefinitionException e) {
			;	// インスタンス化できない場合、Optional#emptyを返却するため
		}
		try {
			T instance = (T) GFrameworkUtils.getComponent(clazz);
			if (Objects.nonNull(instance)) {
				return Optional.of(instance);
			}
		} catch(NoSuchBeanDefinitionException e) {
			;	// インスタンス化できない場合、Optional#emptyを返却するため
		}
		return Optional.empty();
	}

	private <T> T constructComponent(Class<T> clazz, Object[] parameters, Class<?>[] parameterClasses)
		throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
		Constructor<T> constructor = clazz.getConstructor(parameterClasses);
		return constructor.newInstance(parameters);
	}
}
