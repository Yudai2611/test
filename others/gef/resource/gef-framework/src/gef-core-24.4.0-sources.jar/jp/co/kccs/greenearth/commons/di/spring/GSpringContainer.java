/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di.spring;

import java.util.Map;

import jp.co.kccs.greenearth.commons.di.GDIContainer;

import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * SpringFramework用コンテナです.
 * 
 * @create 2005/03/26
 * @author kitamura
 * @since 3.0.0
 */
public class GSpringContainer implements GDIContainer, ApplicationContextAware {

	/** ファクトリー. */
	private GSpringContainerFactory factory = null;

	/**
	 * コンストラクタ.
	 * 
	 * @param factory ファクトリー
	 */
	public GSpringContainer(GSpringContainerFactory factory) {
		this.factory = factory;
	}
	
	/** 親コンテナ。 */
	private GDIContainer parent = null;
	
	/**
	 * 親コンテナを返します。
	 * 
	 * @return 親コンテナ
	 */
	@Override
	public GDIContainer getParent() {
		return parent;
	}

	/**
	 * 親コンテナを設定します。
	 * 
	 * @param applicationContext 親コンテナ
	 */
	public void setParent(GDIContainer parent) {
		this.parent = parent;
	}
	
	/**
	 * ApplicationContextをラップしています。
	 * <br />
	 * Web環境では以下のコードでServletContextの取得が可能です。
	 * <pre>
	 * GSpringContainer container;
	 * ServletContext servletContext =
	 *   ((WebApplicationContext) container.getApplicationContext()).getServletContext();
	 * </pre>
	 */
	protected ApplicationContext applicationContext;

	/**
	 * ApplicationContextを設定します.
	 * 
	 * @param applicationContext ApplicationContext
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}
	
	/**
	 * コンテナより指定したキーに紐づくクラスのコンポーネントを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.GDIContainer.GContainer#getComponent(java.lang.Object)
	 * 
	 * @create 2005/03/22
	 * @param object キー
	 * @return コンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public Object getComponent(final Object object) {
		Object component;
		if (object == null) {
			component = null;
		} else if (object instanceof Class<?>) {
			component = applicationContext.getBean((Class<?>) object);
		} else if (object instanceof String) {
			component = applicationContext.getBean((String) object);
		} else {
			component = applicationContext.getBean(object.toString());
		}
		return component;
	}

	/**
	 * Typeに一致するコンポーネントをマップで返します。
	 * <br />
	 * Spring Framework, Seaser2とも実装可能です。
	 * 
	 * @see org.springframework.beans.factory.ListableBeanFactory#getBeansOfType(Class)
	 * 
	 * @param type Type
	 * @return コンポーネント名とコンポーネントのマップ。
	 */
	@Override
	public <T> Map<String, T> findComponents(Class<T> type) {
		ListableBeanFactory factory = (ListableBeanFactory) applicationContext.getAutowireCapableBeanFactory();
		return factory.getBeansOfType(type);
	}

	/**
	 * コンポーネント名に一致するDI定義の内容でインスタンス化されたコンポーネントの設定を実行します。
	 * 
	 * @see org.springframework.beans.factory.config.AutowireCapableBeanFactory#configureBean(Object, String)
	 * 
	 * @param component コンポーネント
	 * @param name コンポーネント名
	 */
	@Override
	public Object configureComponent(Object component, String name) {
		return applicationContext.getAutowireCapableBeanFactory().configureBean(component, name);
	}

	/**
	 * ApplicationContextを返します。
	 * 
	 * @create 2005/03/22
	 * @return ラップ対象
	 * @author kitamura
	 * @since 3.0.0
	 */
	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	/**
	 * コンテナを破棄します。
	 */
	@Override
	public void destroy() {
		factory.destroyDIContainer();
		applicationContext = null;
	}
	
}
