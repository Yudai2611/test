/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di.spring;

import jp.co.kccs.greenearth.commons.di.GDIContainer;
import jp.co.kccs.greenearth.commons.di.GDIContainerFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * SpringFramework用コンテナです.
 * 
 * @create 2005/03/26
 * @author kitamura
 * @since 3.0.0
 */
public class GSpringContainerFactory implements GDIContainerFactory {

	/** コンテナ. */
	private GSpringContainer springContainer = null;
	
	/**
	 * DIコンテナを破棄します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.di.GAbstractContainer#destroy(java.lang.Object)
	 * @param context 廃棄用コンテンツ。指定不要。
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	protected void destroyDIContainer() {
		if (null == springContainer) {
			return;
		}
		ApplicationContext container = springContainer.getApplicationContext();
		if (null != container &&
				container instanceof ConfigurableApplicationContext) {
			((ConfigurableApplicationContext) container).close();
		}
		springContainer = null;
	}

	/**
	 * DIコンテナを初期化します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.di.GAbstractContainer#init(java.lang.Object)
	 * @param context 初期化用コンテンツ。指定不要。
	 * @return コンテナ
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	@Override
	public GDIContainer getDIContainer(final Object context, final String configPath) {
		springContainer = new GSpringContainer(this);
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(configPath);
		((ClassPathXmlApplicationContext) applicationContext).registerShutdownHook();
		
		springContainer.setApplicationContext(applicationContext);
		
		return springContainer;
	}

}
