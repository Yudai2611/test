/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.di.spring;

import jakarta.servlet.ServletContext;

import jp.co.kccs.greenearth.commons.di.GDIContainer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.util.ResourceUtils;
import org.springframework.web.context.ConfigurableWebApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AbstractRefreshableWebApplicationContext;
import org.springframework.web.context.support.XmlWebApplicationContext;

/**
 *　Web環境のSpringFramework用コンテナです。
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GWebSpringContainerFactory extends GSpringContainerFactory {

	/** コンテナ. */
	private GSpringContainer springContainer = null;
	
	/**
	 * DIコンテナを破棄します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.di.GAbstractContainer#destroy(java.lang.Object)
	 * @param context 廃棄用コンテンツ。指定不要。
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	@Override
	protected void destroyDIContainer() {
		if (null == springContainer) {
			return;
		}
		ApplicationContext container = springContainer.getApplicationContext();
		if (null != container &&
			container instanceof ConfigurableApplicationContext &&
			container instanceof WebApplicationContext) {
			// DIコンテナをclose(dispose)します
			((ConfigurableApplicationContext) container).close();
			// ServletContextに設定したApplicationContextを削除します
			ServletContext servletContext = ((WebApplicationContext) container).getServletContext();
			if (null != servletContext) {
				servletContext.removeAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
			}
		}
		springContainer = null;
	}

	/**
	 * DIコンテナを初期化します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.di.GAbstractContainer#init(java.lang.Object)
	 * @param context 初期化時にServletContextを設定します。
	 */
	@Override
	public GDIContainer getDIContainer(Object context, String configPath) {
		springContainer = new GSpringContainer(this);
		
		ServletContext servletContext = null;
		if (null != context && context instanceof ServletContext) {
			servletContext = (ServletContext) context;
		}
		
		// Bean定義のリーダーを生成し、読み取り
		ApplicationContext applicationContext = new XmlWebApplicationContext();
		springContainer.setApplicationContext(applicationContext);
		configPath = 
				ResourceUtils.CLASSPATH_URL_PREFIX + 
				configPath;
		((ConfigurableWebApplicationContext) applicationContext).setServletContext(servletContext);
		((ConfigurableWebApplicationContext) applicationContext).setConfigLocation(configPath);
		((AbstractRefreshableWebApplicationContext) applicationContext).refresh();

		if (servletContext != null) {
			// 本来はSpringのContextLoaderListenerがやっている処理を代行
			servletContext.setAttribute(
					WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE,
					applicationContext);			
		}
		
		return springContainer;
	}

	/**
	 * ServletContextを返します。
	 * 
	 * @return ServletContext
	 */
	public ServletContext getServletContext() {
		if (null == springContainer) {
			return null;
		}
		return ((WebApplicationContext) springContainer.getApplicationContext()).getServletContext();
	}
	
}
