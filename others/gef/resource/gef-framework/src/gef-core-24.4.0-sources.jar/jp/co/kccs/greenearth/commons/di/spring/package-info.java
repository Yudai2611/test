/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * DIとしてSpring Frameworkを使用するパッケージです。
 */
package jp.co.kccs.greenearth.commons.di.spring;

