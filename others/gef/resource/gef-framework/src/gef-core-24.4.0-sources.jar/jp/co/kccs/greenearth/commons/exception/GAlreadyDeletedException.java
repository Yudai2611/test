/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

/**
 * 楽観的排他において、既にデータが削除されていた場合を表す例外です。<br/>
 * DBの更新系処理にて、データが既に削除されている場合などに利用します。
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GAlreadyDeletedException extends GOptimisticLockException {
	
	/** シリアルバージョンID. */
	private static final long serialVersionUID = 4874342938548473900L;

	/**
	 * {@link GAlreadyDeletedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GAlreadyDeletedException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GAlreadyDeletedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GAlreadyDeletedException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GAlreadyDeletedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GAlreadyDeletedException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GAlreadyDeletedException}のインスタンスを初期化します。
	 * 
	 * @create 2010/10/22
	 * @param message 例外メッセージ
	 * @param cause 発生原因となった例外
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GAlreadyDeletedException(String message, Throwable cause) {
		super(message, cause);
	}

}
