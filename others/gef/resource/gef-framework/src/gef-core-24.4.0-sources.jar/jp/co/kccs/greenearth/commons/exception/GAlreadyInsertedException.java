package jp.co.kccs.greenearth.commons.exception;

/**
 * 楽観的排他において、既に同様のデータが登録されている場合を表す例外です。<br/>
 * DBの登録系処理にて、キーの重複の場合などに利用します。
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GAlreadyInsertedException extends GOptimisticLockException {
	
	/** シリアルバージョンID. */
	private static final long serialVersionUID = 144500957688945305L;

	/**
	 * {@link GAlreadyInsertedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GAlreadyInsertedException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GAlreadyInsertedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GAlreadyInsertedException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GAlreadyInsertedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GAlreadyInsertedException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GAlreadyInsertedException}のインスタンスを初期化します。
	 * 
	 * @create 2010/10/22
	 * @param message 例外メッセージ
	 * @param cause 発生原因となった例外
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GAlreadyInsertedException(String message, Throwable cause) {
		super(message, cause);
	}

}
