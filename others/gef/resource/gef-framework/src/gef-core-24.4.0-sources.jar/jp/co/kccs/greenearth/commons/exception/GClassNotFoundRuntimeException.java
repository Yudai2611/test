package jp.co.kccs.greenearth.commons.exception;

public class GClassNotFoundRuntimeException extends RuntimeException {
	
	/** シリアルバージョンID */
	private static final long serialVersionUID = -8574856470049118745L;

	public GClassNotFoundRuntimeException() {
		super();
	}

	public GClassNotFoundRuntimeException(String message) {
		super(message);
	}

	public GClassNotFoundRuntimeException(Throwable cause) {
		super(cause);
	}

	public GClassNotFoundRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

}
