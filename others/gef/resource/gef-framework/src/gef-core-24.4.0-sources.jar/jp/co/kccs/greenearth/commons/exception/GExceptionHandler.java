/*
 * Copyright 2012 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

/**
 * 例外振舞ｸﾗｽ（例外を実処理するｸﾗｽ）が実装すべきｲﾝﾀｰﾌｪｰｽです。
 * 
 * @author KCCS Kouji Enami
 * @author KCCS Tomoyuki Higuchi
 * @version 1.2.0
 */
public interface GExceptionHandler {

	/**
	 * 指定された例外を処理したのち、必要に応じて新しい例外をﾘﾀｰﾝします。
	 * <p>
	 * 本ﾒｿｯﾄﾞの内部から例外をｽﾛｰしてはいけません。また、<code>Null</code>をﾘﾀｰﾝしてはいけません。
	 * 
	 * @param targetException 処理対象の例外
	 * @return 処理後の例外
	 */
	Throwable handleException(Throwable targetException);
}
