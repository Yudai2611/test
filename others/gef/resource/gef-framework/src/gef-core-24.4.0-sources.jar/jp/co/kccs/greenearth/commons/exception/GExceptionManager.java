/*
 * Copyright 2012 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

import java.util.Collections;
import java.util.List;

/**
 * 例外の振る舞い処理を決定する例外ﾊﾝﾄﾞﾗを管理・制御するｸﾗｽです。
 * 
 * @author KCCS Kouji Enami
 * @author KCCS Tomoyuki Higuchi
 * @since 1.2.0
 */
public final class GExceptionManager implements GExceptionHandler {

	/** 業務が実装する例外ﾊﾝﾄﾞﾗのﾘｽﾄ **/
	private List<GExceptionHandler> applicationHandlers = Collections.emptyList();

	/** 共通部品の各Layerで実装する例外ﾊﾝﾄﾞﾗのﾘｽﾄ **/
	private List<GExceptionHandler> frameworkHandlers = Collections.emptyList();

	/**
	 * 業務・共通部品の例外ﾊﾝﾄﾞﾗのﾘｽﾄを引数に持ったｺﾝｽﾄﾗｸﾀ
	 * 
	 * @param applicationHandlers 業務が用意する例外ﾊﾝﾄﾞﾗのﾘｽﾄ
	 * @param frameworkHandlers 共通部品が用意する例外ﾊﾝﾄﾞﾗのﾘｽﾄ
	 */
	public GExceptionManager(List<GExceptionHandler> applicationHandlers, List<GExceptionHandler> frameworkHandlers) {

		this.applicationHandlers = applicationHandlers;
		this.frameworkHandlers = frameworkHandlers;
	}

	/**
	 * 業務例外ﾊﾝﾄﾞﾗ、共通例外ﾊﾝﾄﾞﾗを実行して引数で指定された例外を処理します。
	 * 
	 * @param originalException 処理対象となる元の例外
	 * @return 例外ﾊﾝﾄﾞﾗの処理結果となる例外
	 * @throws GSystemException 業務例外ﾊﾝﾄﾞﾗの実行中に例外が発生した場合
	 */
	public Throwable handleException(Throwable originalException) throws GSystemException {

		if (originalException == null) {
			throw new IllegalArgumentException(originalException);
		}

		Throwable returnException = executeExceptionHandler(originalException);

		return returnException;
	}

	/**
	 * 業務と共通部品が設定した例外ﾊﾝﾄﾞﾗを実行します。
	 * 
	 * @param exception 処理対象の例外
	 * @return 業務例外ﾊﾝﾄﾞﾗ実行後に返却された例外
	 * @throws GSystemException 業務例外ﾊﾝﾄﾞﾗ実行中に発生した例外
	 */
	private Throwable executeExceptionHandler(Throwable exception) throws GSystemException {
		Throwable targetException = exception;

		for (GExceptionHandler handler : applicationHandlers) {
			targetException = handler.handleException(targetException);
			if (targetException == null) {
				throw new NullPointerException(handler.getClass().getSimpleName() + " should not return null.");
			}
		}

		for (GExceptionHandler handler : frameworkHandlers) {
			targetException = handler.handleException(targetException);
		}

		return targetException;
	}
}