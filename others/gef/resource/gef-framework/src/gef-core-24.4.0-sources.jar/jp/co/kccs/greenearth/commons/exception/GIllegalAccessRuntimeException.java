package jp.co.kccs.greenearth.commons.exception;

public class GIllegalAccessRuntimeException extends RuntimeException {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = -7546091570039667402L;

	public GIllegalAccessRuntimeException() {
		super();
	}

	public GIllegalAccessRuntimeException(String message) {
		super(message);
	}

	public GIllegalAccessRuntimeException(Throwable cause) {
		super(cause);
	}

	public GIllegalAccessRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

}
