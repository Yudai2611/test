/*
 * Copyright 2007-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

/**
 * 不正な型に対して処理を行った場合に発生する例外です.
 * 
 * @create 2007/12/10
 * @author kitamura
 * @since 3.2.1
 */
public class GIllegalTypeException extends RuntimeException {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = 6827738492736446787L;

	/**
	 * {@link GIllegalTypeException}のインスタンスを初期化します.
	 * 
	 * @create 2007/12/10
	 * @author kitamura
	 * @since 3.2.1
	 */
	public GIllegalTypeException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GIllegalTypeException}のインスタンスを初期化します.
	 * 
	 * @create 2007/12/10
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.2.1
	 */
	public GIllegalTypeException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GIllegalTypeException}のインスタンスを初期化します.
	 * 
	 * @create 2007/12/10
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.2.1
	 */
	public GIllegalTypeException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GIllegalTypeException}のインスタンスを初期化します。
	 * 
	 * @create 2010/10/22
	 * @param message 例外メッセージ
	 * @param cause 発生原因となった例外
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GIllegalTypeException(String message, Throwable cause) {
		super(message, cause);
	}
}
