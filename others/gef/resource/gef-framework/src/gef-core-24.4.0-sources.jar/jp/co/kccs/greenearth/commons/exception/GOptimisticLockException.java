/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

/**
 * 永続化層更新時の楽観的排他のエラーを表す例外です。
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GOptimisticLockException extends Exception {
	
	/** シリアルバージョンID. */
	private static final long serialVersionUID = -7501440463810891721L;

	/**
	 * {@link GOptimisticLockException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GOptimisticLockException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GOptimisticLockException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GOptimisticLockException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GOptimisticLockException}のインスタンスを初期化します.
	 * 
	 * @create 2011/03/18
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GOptimisticLockException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GOptimisticLockException}のインスタンスを初期化します。
	 * 
	 * @create 2010/10/22
	 * @param message 例外メッセージ
	 * @param cause 発生原因となった例外
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GOptimisticLockException(String message, Throwable cause) {
		super(message, cause);
	}

}
