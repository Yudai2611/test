/*
 * Copyright 2010-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

/**
 * リソースの処理中に発生した例外を表します。
 * 
 * @create 2010/02/03
 * @author okajima
 * @since 3.7.0
 */
public class GResourceProcessingException extends Exception {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = 8570300965671078173L;

	/**
	 * {@link GResourceProcessingException}のインスタンスを初期化します。
	 * 
	 * @create 2010/02/03
	 * @auther okajima
	 * @since 3.7.0
	 */
	public GResourceProcessingException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GResourceProcessingException}のインスタンスを初期化します。
	 * 
	 * @create 2010/02/03
	 * @param message 例外メッセージ
	 * @auther okajima
	 * @since 3.7.0
	 */
	public GResourceProcessingException(String message) {
		super(message);
	}
	
	/**
	 * この例外の発生原因を指定し、{@link GResourceProcessingException}のインスタンスを初期化します。
	 * 
	 * @create 2010/02/03
	 * @param cause 発生原因となった例外
	 * @auther okajima
	 * @since 3.7.0
	 */
	public GResourceProcessingException(Throwable cause) {
		super(cause);
	}

	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GResourceProcessingException}のインスタンスを初期化します。
	 * 
	 * @create 2010/10/22
	 * @param message 例外メッセージ
	 * @param cause 発生原因となった例外
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GResourceProcessingException(String message, Throwable cause) {
		super(message, cause);
	}
}
