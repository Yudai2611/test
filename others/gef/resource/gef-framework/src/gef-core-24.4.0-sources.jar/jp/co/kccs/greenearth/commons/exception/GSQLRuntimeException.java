package jp.co.kccs.greenearth.commons.exception;

/**
 * 
 * 
 * @author KCCS yamashita
 * @create 2012/12/09
 * @since
 */
public class GSQLRuntimeException extends RuntimeException {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = 6374489062373578468L;

	public GSQLRuntimeException() {
		super();
	}

	public GSQLRuntimeException(String message) {
		super(message);
	}

	public GSQLRuntimeException(Throwable cause) {
		super(cause);
	}

	public GSQLRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}
}
