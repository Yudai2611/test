/*
 * Copyright 2012-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

import jp.co.kccs.greenearth.commons.resource.error.GErrorType;

/**
 * 各種OSSなどが投げるﾗﾝﾀｲﾑ例外({@link RuntimeException}を継承する例外)の基底ｸﾗｽです。
 * <p>
 * ｴﾗｰﾀｲﾌﾟを指定しない場合、ｴﾗｰﾀｲﾌﾟは{@link GErrorType#DEFAULT}となります。
 * 
 * @create 2012/10/29
 * @author KCCS Kouji Enami
 * @author KCCS Tomoyuki Higuchi
 * @since 1.0.0
 * @see Exception
 */
public class GSystemException extends RuntimeException {

	/** ｼﾘｱﾙﾊﾞｰｼﾞｮﾝID **/
	private static final long serialVersionUID = 3230345460670701601L;

	/** ｴﾗｰﾀｲﾌﾟ **/
	private GErrorType type;

	/** ｴﾗｰｺｰﾄﾞ **/
	private String errorCode;

	/**
	 * ﾃﾞﾌｫﾙﾄｺﾝｽﾄﾗｸﾀ。
	 */
	public GSystemException() {
		this(null);
	}

	/**
	 * ｴﾗｰｺｰﾄﾞを設定します。
	 * 
	 * @param errorCode ｴﾗｰｺｰﾄﾞ
	 */
	public GSystemException(String errorCode) {
		this(errorCode, (String) null);
	}

	/**
	 * ｴﾗｰｺｰﾄﾞとｴﾗｰﾒｯｾｰｼﾞを設定します。
	 * 
	 * @param errorCode ｴﾗｰｺｰﾄﾞ
	 * @param message ｴﾗｰﾒｯｾｰｼﾞ
	 */
	public GSystemException(String errorCode, String message) {
		this(errorCode, message, GErrorType.DEFAULT);
	}

	/**
	 * ｴﾗｰｺｰﾄﾞとｴﾗｰﾒｯｾｰｼﾞとｴﾗｰﾀｲﾌﾟを設定します。
	 * 
	 * @param errorCode ｴﾗｰｺｰﾄﾞ
	 * @param message ｴﾗｰﾒｯｾｰｼﾞ
	 * @param type ｴﾗｰﾀｲﾌﾟ
	 * @throws NullPointerException ｴﾗｰﾀｲﾌﾟが<code>Null</code>の場合
	 */
	public GSystemException(String errorCode, String message, GErrorType type) throws NullPointerException {
		this(errorCode, message, type, null);
	}

	/**
	 * ｴﾗｰｺｰﾄﾞと原因となる例外を設定します。
	 * 
	 * @param errorCode ｴﾗｰｺｰﾄﾞ
	 * @param cause 原因となる例外情報
	 */
	public GSystemException(String errorCode, Throwable cause) {
		this(errorCode, null, cause);
	}

	/**
	 * ｴﾗｰｺｰﾄﾞとｴﾗｰﾒｯｾｰｼﾞと原因となる例外を設定します。
	 * 
	 * @param errorCode ｴﾗｰｺｰﾄﾞ
	 * @param message ｴﾗｰﾒｯｾｰｼﾞ
	 * @param cause 原因となる例外情報
	 */
	public GSystemException(String errorCode, String message, Throwable cause) {
		this(errorCode, message, GErrorType.DEFAULT, cause);
	}

	/**
	 * ｴﾗｰｺｰﾄﾞとｴﾗｰﾒｯｾｰｼﾞとｴﾗｰﾀｲﾌﾟと原因となる例外を設定します。
	 * 
	 * @param errorCode ｴﾗｰｺｰﾄﾞ
	 * @param message ｴﾗｰﾒｯｾｰｼﾞ
	 * @param type ｴﾗｰﾀｲﾌﾟ
	 * @param cause 原因となる例外情報
	 * @throws NullPointerException ｴﾗｰﾀｲﾌﾟが<code>Null</code>の場合
	 */
	public GSystemException(String errorCode, String message, GErrorType type, Throwable cause)
		throws NullPointerException {
		super(message, cause);
		if (type == null) {
			throw new NullPointerException("cant't assign null to error type.");
		}
		this.errorCode = errorCode;
		this.type = type;
	}

	/**
	 * ｴﾗｰｺｰﾄﾞを取得します。
	 * 
	 * @return ｴﾗｰｺｰﾄﾞ
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * ｴﾗｰｺｰﾄﾞを設定します。
	 * 
	 * @param errorCode ｴﾗｰｺｰﾄﾞ
	 */
	@Deprecated
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * ｴﾗｰﾀｲﾌﾟを取得します。
	 * 
	 * @return ｴﾗｰﾀｲﾌﾟ
	 */
	public GErrorType getType() {
		return type;
	}

	/**
	 * ｴﾗｰﾀｲﾌﾟを設定します。
	 * 
	 * @param type ｴﾗｰﾀｲﾌﾟ
	 */
	@Deprecated
	public void setType(GErrorType type) {
		this.type = type;
	}
}
