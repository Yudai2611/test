/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * 例外のパッケージです。
 */
package jp.co.kccs.greenearth.commons.exception;

