/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;


/**
 * {@link String}⇔{@link Boolean}をフォーマットするためのインターフェースです。
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public interface GBooleanFormatter extends GFormatter<Boolean> {
}
