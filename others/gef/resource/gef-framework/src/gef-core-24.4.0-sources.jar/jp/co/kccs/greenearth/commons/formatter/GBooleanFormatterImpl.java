/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.util.Locale;

/**
 * {@link GBooleanFormatter}のデフォルト実装です。<br>
 * "ture"/"false"という文字列と、"1"/"0"という文字列を{@link Boolean}に変換します。
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public class GBooleanFormatterImpl implements GBooleanFormatter {

	@Override
	public Boolean parse(String value, Locale locale) {
		return parse(value, locale, null);
	}

	@Override
	public Boolean parse(String value, Locale locale, String pattern) {
		if ("1".equals((String) value)) {
			//文字列の"1"はtrueとする
			return Boolean.TRUE;
		}
		else if ("0".equals((String) value)) {
			// 文字列の"0"はfalseとする
			return Boolean.FALSE;
		}
		else {
			return Boolean.parseBoolean((String) value);
		}
	}

	@Override
	public String format(Boolean value, Locale locale) {
		throw new UnsupportedOperationException("format is not supported. ");
	}

	@Override
	public String format(Boolean value, Locale locale, String pattern) {
		throw new UnsupportedOperationException("format is not supported. ");
	}
}
