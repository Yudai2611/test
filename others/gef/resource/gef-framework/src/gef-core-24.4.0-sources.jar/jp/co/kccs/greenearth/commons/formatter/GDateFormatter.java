/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.util.Date;

/**
 * {@link String}⇔{@link Date}をフォーマットするためのインターフェースです。
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public interface GDateFormatter extends GFormatter<Date> {
}
