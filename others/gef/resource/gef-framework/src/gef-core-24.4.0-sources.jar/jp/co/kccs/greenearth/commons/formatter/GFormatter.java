/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.text.ParseException;
import java.util.Locale;

/**
 * {@link String}⇔任意のオブジェクトをフォーマットするためのインターフェースです。
 * 
 * @param <T> フォーマット対象の型
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public interface GFormatter<T> {

	/**
	 * 指定された文字列を解析し、対象の型に変換します。
	 * 
	 * @param value 変換対象文字列
	 * @param locale ロケール
	 * @return 変換された値
	 * @throws ParseException 解析に失敗した場合
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	T parse(String value, Locale locale) throws ParseException;
	
	/**
	 * フォーマットパターンを指定して、指定された文字列を解析し、対象の型に変換します。
	 * 
	 * @param value 変換対象文字列
	 * @param locale ロケール
	 * @param pattern フォーマットパターン
	 * @return 変換された値
	 * @throws ParseException 解析に失敗した場合
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	T parse(String value, Locale locale, String pattern) throws ParseException;

	/**
	 * 指定された値を文字列にフォーマットします。
	 * 
	 * @param value 文字列にフォーマットする値
	 * @param locale ロケール
	 * @return フォーマットされた文字列
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	String format(T value, Locale locale);

	/**
	 * フォーマットパターンを指定して、指定された値を文字列にフォーマットします。
	 * @param value 文字列にフォーマットする値
	 * @param locale ロケール
	 * @param pattern フォーマットされた文字列
	 * @return フォーマットされた文字列
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	String format(T value, Locale locale, String pattern);
}
