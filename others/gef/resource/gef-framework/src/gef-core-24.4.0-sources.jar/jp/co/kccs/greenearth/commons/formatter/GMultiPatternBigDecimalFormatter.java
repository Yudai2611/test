/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Locale;

/**
 * フォーマットパターンを複数の候補から選択してフォーマット処理を行う{@link GBigDecimalFormatter}の実装クラスです。<br>
 * 詳細なアルゴリズムは{@link GMultiPatternNumberFormatterBase}を参照してください。
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public class GMultiPatternBigDecimalFormatter extends GMultiPatternNumberFormatterBase<BigDecimal> implements GBigDecimalFormatter {

	/**
	 * {@link GMultiPatternProvider}を指定して、インスタンスを初期化します。
	 * 
	 * @param patternProvider パターンプロバイダ
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	public GMultiPatternBigDecimalFormatter(GMultiPatternProvider patternProvider) {
		super(patternProvider);
	}

	@Override
	public BigDecimal parse(String value, Locale locale) throws ParseException {
		return toBigDecimal(value, locale);
	}
	
	@Override
	public BigDecimal parse(String value, Locale locale, String pattern) throws ParseException {
		return toBigDecimal(value, locale, pattern);
	}

	@Override
	public String format(BigDecimal value, Locale locale) {
		return toString(value, locale);
	}

	@Override
	public String format(BigDecimal value, Locale locale, String pattern) {
		return toString(value, locale, pattern);
	}

}
