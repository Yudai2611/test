/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GDateUtils;

/**
 * フォーマットパターンを複数の候補から選択してフォーマット処理を行う{@link GDateFormatter}の実装クラスです。<br>
 * 複数のフォーマットパターンに優先順位をつけ、順に解析/フォーマット処理を繰り返し、フォーマット対象の値に該当するパターンがあれば採用するというアルゴリズムになります。<br>
 * フォーマットパターンについては、コンストラクタにて指定される{@link GMultiPatternProvider}の実装クラスにより供給される仕組みとなっています。<br>
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public class GMultiPatternDateFormatter implements GDateFormatter {

	/** 日付解析を厳密に行うかどうかプロパティキー名. */
	public static final String DATE_LENIENT_KEY = "geframe.core.Convert.DateLenient";
	/** 日付解析を厳密に行うかどうかのデフォルト値. */
	protected static final String DATE_LENIENT_DEFAULT = "false";

	/** パターンプロバイダ */
	public GMultiPatternProvider patternProvider;

	/**
	 * {@link GMultiPatternProvider}を指定して、インスタンスを初期化します。
	 * 
	 * @param patternProvider パターンプロバイダ
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	public GMultiPatternDateFormatter(GMultiPatternProvider patternProvider) {
		this.patternProvider = patternProvider;
	}

	/**
	 * パターンプロバイダを取得します。
	 * 
	 * @return パターンプロバイダ
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	public GMultiPatternProvider getPatternProvider() {
		return this.patternProvider;
	}

	@Override
	public Date parse(String value, Locale locale) throws ParseException {
		if (value == null || value.length() == 0) {
			return null;
		}

		Iterable<String> patterns = getPatternProvider().getPatterns(locale);
		for (String pattern : patterns) {
			try {
				return parse(value, locale, pattern);
			}
			catch (ParseException pe) {
				continue;
			}
		}

		throw new ParseException("Can not parse value by the pattern of the specified properties. : \"" + value + "\"" , -1);
	}
	
	@Override
	public Date parse(String value, Locale locale, String pattern) throws ParseException {
		if (value == null || value.length() == 0) {
			return null;
		}
		boolean lenient = Boolean.parseBoolean(GFrameworkUtils.getProperty(DATE_LENIENT_KEY, DATE_LENIENT_DEFAULT));
		return GDateUtils.toDate(value, pattern, locale, lenient);
	}

	/**
	 * フォーマットパターンと厳密に解析するかどうかの真偽値を指定して、指定された文字列を解析し、対象の型に変換します。
	 * 
	 * @param value 変換対象文字列
	 * @param locale ロケール
	 * @param pattern フォーマットパターン
	 * @param lenient 日付/時刻の解析を厳密に行うかどうかを表す値(<code>true</code>の場合は厳密ではない解析)
	 * @return 変換された値
	 * @throws ParseException 解析に失敗した場合
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	public Date parse(String value, Locale locale, boolean lenient) throws ParseException {
		if (value == null || value.length() == 0) {
			return null;
		}
		
		Iterable<String> patterns = getPatternProvider().getPatterns(locale);
		for (String pattern : patterns) {
			try {
				return GDateUtils.toDate(value, pattern, locale, lenient);
			}
			catch (ParseException pe) {
				continue;
			}
		}

		throw new ParseException("Can not parse value by the pattern of the specified properties. : \"" + value + "\"" , -1);
	}

	@Override
	public String format(Date value, Locale locale) {
		if (value == null) {
			return null;
		}

		Iterable<String> patterns = getPatternProvider().getPatterns(locale);
		for (String pattern : patterns) {
			try {
				return format(value, locale, pattern);
			}
			catch (IllegalArgumentException pe) {
				continue;
			}
		}

		//プロパティに指定されたフォーマットが全て適用できなかった場合
		throw new IllegalArgumentException("Can not format value by the pattern of the specified properties. : \"" + value + "\"");
	}

	@Override
	public String format(Date value, Locale locale, String pattern) {
		if (value == null) {
			return null;
		}
		return GDateUtils.formatToString(value, pattern, locale);
	}

}
