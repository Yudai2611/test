/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Locale;

/**
 * フォーマットパターンを複数の候補から選択してフォーマット処理を行う{@link GIntegerFormatter}の実装クラスです。<br>
 * 詳細なアルゴリズムは{@link GMultiPatternNumberFormatterBase}を参照してください。
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public class GMultiPatternIntegerFormatter extends GMultiPatternNumberFormatterBase<Integer> implements GIntegerFormatter {

	/**
	 * {@link GMultiPatternProvider}を指定して、インスタンスを初期化します。
	 * 
	 * @param patternProvider パターンプロバイダ
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	public GMultiPatternIntegerFormatter(GMultiPatternProvider patternProvider) {
		super(patternProvider);
	}

	@Override
	public Integer parse(String value, Locale locale) throws ParseException {
		BigDecimal result = toBigDecimal(value, locale);
		return result != null ? result.intValue() : null;
	}

	@Override
	public Integer parse(String value, Locale locale, String pattern) throws ParseException {
		BigDecimal result = toBigDecimal(value, locale, pattern);
		return result != null ? result.intValue() : null;
	}

	@Override
	public String format(Integer value, Locale locale) {
		return toString(value, locale);
	}

	@Override
	public String format(Integer value, Locale locale, String pattern) {
		return toString(value, locale, pattern);
	}

}
