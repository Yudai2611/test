/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.utils.GNumberUtils;

/**
 * フォーマットパターンを複数の候補から選択してフォーマット処理を行う{@link Number}の派生型向けの{@link GFormatter}の抽象クラスです。<br>
 * 複数のフォーマットパターンに優先順位をつけ、順に解析/フォーマット処理を繰り返し、フォーマット対象の値に該当するパターンがあれば採用するというアルゴリズムになります。<br>
 * フォーマットパターンについては、コンストラクタにて指定される{@link GMultiPatternProvider}の実装ｸﾗｽにより供給される仕組みとなっています。<br>
 * <br>
 * ※注意事項<br>
 * 内部で利用している{@link java.text.DecimalFormat}クラスによるフォーマットの端数の丸め方は、主に米国で使用されている「銀行方式の丸め」
 * ({@link java.math.RoundingMode#HALF_EVEN})を使用しています。<br>
 * 日本の四捨五入({@link RoundingMode#HALF_UP)とはことなりますので、それ以外の方式で丸めたい場合は、
 * フォーマットで指定される有効桁数で事前に丸めておく必要があります。<br>
 * 
 * @param <T> フォーマット対象のNumber派生型
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public abstract class GMultiPatternNumberFormatterBase<T extends Number> implements GFormatter<T> {

	/** パターンプロバイダ */
	public GMultiPatternProvider patternProvider;

	/**
	 * {@link GMultiPatternProvider}を指定して、インスタンスを初期化します。
	 * 
	 * @param patternProvider パターンプロバイダ
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	public GMultiPatternNumberFormatterBase(GMultiPatternProvider patternProvider) {
		this.patternProvider = patternProvider;
	}

	/**
	 * パターンプロバイダを取得します。
	 * 
	 * @return パターンプロバイダ
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	public GMultiPatternProvider getPatternProvider() {
		return this.patternProvider;
	}

	/**
	 * 指定された文字列を解析し、{@link BigDecimal}型に変換します。
	 * 
	 * @param value 変換対象文字列
	 * @param locale ロケール
	 * @return 変換された{@link BigDecimal}
	 * @throws ParseException 解析に失敗した場合
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	protected BigDecimal toBigDecimal(String value, Locale locale) throws ParseException {
		if (value == null || value.length() == 0) {
			return null;
		}
		
		Iterable<String> patterns = getPatternProvider().getPatterns(locale);
		for (String pattern : patterns) {
			try {
				return toBigDecimal(value, locale, pattern);
			}
			catch (ParseException pe) {
				continue;
			}
		}

		throw new ParseException("Can not parse value by the pattern of the specified properties. : \"" + value + "\"" , -1);
	}

	/**
	 * フォーマットパターンを指定して、指定された文字列を解析し、{@link BigDecimal}型に変換します。
	 * 
	 * @param value 変換対象文字列
	 * @param locale ロケール
	 * @param pattern フォーマットパターン
	 * @return 変換された{@link BigDecimal}
	 * @throws ParseException 解析に失敗した場合
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	protected BigDecimal toBigDecimal(String value, Locale locale, String pattern) throws ParseException {
		if (value == null || value.length() == 0) {
			return null;
		}
		return GNumberUtils.toBigDecimal(value, pattern, locale);
	}

	/**
	 * 指定された{@link Number}値を文字列にフォーマットします。
	 * 
	 * @param value 文字列にフォーマットする{@link Number}値
	 * @param locale ロケール
	 * @return フォーマットされた文字列
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	protected String toString(Number value, Locale locale) {
		if (value == null) {
			return null;
		}

		Iterable<String> patterns = getPatternProvider().getPatterns(locale);
		for (String pattern : patterns) {
			try {
				return toString(value, locale, pattern);
			}
			catch (IllegalArgumentException pe) {
				continue;
			}
		}

		//プロパティに指定されたフォーマットが全て適用できなかった場合
		throw new IllegalArgumentException("Can not format value by the pattern of the specified properties. : \"" + value + "\"");
	}

	/**
	 * フォーマットパターンを指定して、指定された{@link Number}値を文字列にフォーマットします。
	 * 
	 * @param value 文字列にフォーマットする{@link Number}値
	 * @param locale ロケール
	 * @param pattern フォーマットされた文字列
	 * @return フォーマットされた文字列
	 * @author kitamura
	 * @create 2014/03/20
	 * @since 3.13.0
	 */
	protected String toString(Number value, Locale locale, String pattern) {
		if (value == null) {
			return null;
		}
		return GNumberUtils.formatToString(value, pattern, locale);
	}

}
