/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.util.Locale;

/**
 * {@link GFormatter}に、その処理で利用するフォーマットパターンを供給するインタフェースです。<br>
 * パターンは{@link Iterable}形式で複数提供され、いずれのパターンを利用するかは{@link GFormatter}に委譲されます。<br>
 * 基本的には、パターンの{@link Iterable}をforeachで回す過程でパターンを順番に適用し、解析に失敗しなければそのフォーマットが採用されます。<br>
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public interface GMultiPatternProvider {

	/**
	 * パターンの{@link Iterable}を返します。
	 * 
	 * @param locale ロケール
	 * @return パターンの{@link Iterable}
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	Iterable<String> getPatterns(Locale locale);

}
