/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.text.ParseException;
import java.util.Locale;
import java.util.Map;

/**
 * {@link GNumberFormatter}のデフォルト実装です。<br>
 * 指定された{@link Number}のサブクラスに応じて、対応する{@link Number}型の{@link GFormatter}を呼び出します。<br>
 * コンストラクタにて、各{@link Number}に対応する{@link GFormatter}実装の対応付けを行った{@link Map}を渡してください。<br>
 * {@link #parse(String, Locale)}、{@link #parse(String, Locale, String)}はサポートされていません。<br>
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public class GNumberFormatterImpl implements GNumberFormatter {

	/** フォーマットする{@link Number}のサブタイプと、その{@link GFormatter}実装の関連付けを行う{@link Map} */
	private Map<Class<? extends Number>, GFormatter<? extends Number>> map;

	/**
	 * フォーマットする{@link Number}のサブタイプと、その{@link GFormatter}実装の関連付けを行う{@link Map}を指定して、インスタンスを初期化します。
	 * 
	 * @param map フォーマットする{@link Number}のサブタイプと、その{@link GFormatter}実装の関連付けを行う{@link Map}
	 * @create 2014/03/20
	 * @author kitamura
	 * @since 3.13.0
	 */
	public GNumberFormatterImpl(Map<Class<? extends Number>, GFormatter<? extends Number>> map) {
		this.map = map;
	}

	@Override
	public Number parse(String value, Locale locale) throws ParseException {
		throw new UnsupportedOperationException("parse is not supported. ");
	}

	@Override
	public Number parse(String value, Locale locale, String pattern) throws ParseException {
		throw new UnsupportedOperationException("parse is not supported. ");
	}

	@Override
	public String format(Number value, Locale locale) {
		if (value == null) {
			return null;
		}
		return getFormatter(value.getClass()).format(value, locale);
	}

	@Override
	public String format(Number value, Locale locale, String pattern) {
		if (value == null) {
			return null;
		}
		return getFormatter(value.getClass()).format(value, locale, pattern);
	}
	
	@SuppressWarnings("unchecked")
	private GFormatter<Number> getFormatter(Class<? extends Number> targetType) {
		if (!map.containsKey(targetType)) {
			throw new IllegalArgumentException("This type formatter is not found. : " + targetType.getName());
		}
		return (GFormatter<Number>) map.get(targetType);
	}

}
