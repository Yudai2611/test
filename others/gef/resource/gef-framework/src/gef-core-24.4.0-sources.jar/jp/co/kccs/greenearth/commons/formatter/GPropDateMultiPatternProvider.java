/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.formatter;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link DateFormat}用のパターンを返す、{@link GMultiPatternProvider}の実装です。
 * 
 * @create 2014/03/20
 * @author kitamura
 * @since 3.13.0
 */
public class GPropDateMultiPatternProvider implements GMultiPatternProvider {

	/** 日付フォーマットを定義したプロパティのキー名. */
	public static final String DATE_FORMAT_PROPERTY = "geframe.core.Convert.DateFormat";

	@Override
	public Iterable<String> getPatterns(Locale locale) {
		List<String> patterns = new ArrayList<String>();
		int i = 1;
		// フォーマットを読み込み
		while (GFrameworkUtils.containsProperty(DATE_FORMAT_PROPERTY + i)) {
			String pattern = GFrameworkUtils.getProperty(DATE_FORMAT_PROPERTY + i);
			patterns.add(pattern);
			i++;
		}
		// キーが一件も無い場合はMissingResourceException例外を投げます
		if (i == 1) {
			throw new MissingResourceException("Can't find property. key=" + DATE_FORMAT_PROPERTY, GFrameworkUtils.getPropertiesResourceName(), DATE_FORMAT_PROPERTY);
		}
		return patterns;
	}

}
