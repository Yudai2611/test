/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

import jp.co.kccs.greenearth.commons.db.GConnectionManager;

/**
 * {@link GConnectionManager}を使用するアダプター。
 * 
 * @author KCCS Shigeki Shoji
 */
public class GConnectionManagerAdapter implements GJdbcConnectionManager {

	/**
	 * デフォルトの接続を返します。
	 * 
	 * @return 接続
	 * @throws SQLException SQL例外
	 */
	@Override
	public Connection open() throws SQLException {
		return GConnectionManager.getInstance().catchConnection();
	}

	/**
	 * 指定された接続名のデータベースの接続を返します。
	 * 
	 * @param name 接続名
	 * @return 接続
	 * @throws SQLException SQL例外
	 */
	@Override
	public Connection open(String name) throws SQLException {
		return GConnectionManager.getInstance().catchConnection(name);
	}

	/**
	 * 接続を閉じます。
	 * 
	 * @param connection 接続
	 * @throws SQLException SQL例外
	 */
	@Override
	public void close(Connection connection) throws SQLException {
		GConnectionManager.getInstance().releaseConnection(connection);
	}

}
