/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * JDBCの接続インターフェース。
 * 
 * @author KCCS Shigeki Shoji
 */
public interface GJdbcConnectionManager {

	/**
	 * デフォルトの接続を確立します.<br>
	 * 
	 * @create 2013/09/13
	 * @return 接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @see #g(String)
	 * @since 3.12.0
	 */
	Connection open() throws SQLException;
	
	/**
	 * 接続先名の接続を確立します. <br>
	 * 
	 * @create 2013/09/13
	 * @param name 接続先名
	 * @return 接続
	 * @throws SQLException コネクションの取得（接続の確立）に失敗した場合
	 * @since 3.12.0
	 */
	Connection open(String name) throws SQLException;
	
	/**
	 * 接続を解放します.<br>
	 * 
	 * @create 2013/09/13
	 * @param connection 接続
	 * @throws SQLException コネクションの解放に失敗した場合
	 * @since 3.12.0
	 */
	void close(Connection connection) throws SQLException;
	
}
