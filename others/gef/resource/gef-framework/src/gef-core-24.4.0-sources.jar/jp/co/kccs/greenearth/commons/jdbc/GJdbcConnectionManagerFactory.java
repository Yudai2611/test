/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.jdbc;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GJdbcConnectionManager}のインスタンスを生成するファクトリー。
 * 
 * @author KCCS Shigeki Shoji
 */
public class GJdbcConnectionManagerFactory {

	/**
	 * {@link GJdbcConnectionManager}のインスタンスを返します。
	 * 
	 * @return {@link GJdbcConnectionManager}
	 */
	public static GJdbcConnectionManager getInstance() {
		return GFrameworkUtils.getComponent(GJdbcConnectionManager.class.getName());
	}
	
}
