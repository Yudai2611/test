/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.listener;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * フレームワーク起動時に初期化可能かどうか表現します.<br/>
 * {@link BootstrapInitializable#bootOn()}がfalseの場合、対象除外となります。<br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface BootstrapInitializable {

	/**
	 * 起動時に初期化を行うかどうかを判定します.<br/>
	 * 属性が指定されない場合、デフォルト値はtrueを返却します。<br/>
	 * 
	 * @create 2023/10/25
	 * @return
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean bootOn() default true;
}

