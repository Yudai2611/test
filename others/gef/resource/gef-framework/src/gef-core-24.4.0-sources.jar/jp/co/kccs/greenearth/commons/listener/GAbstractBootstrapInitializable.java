/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.listener;

import java.util.Objects;

import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;
/**
 *
 * {@link GAbstractBootstrapInitializable}の抽象クラスです.<br/>
 *
 * @create 2023/10/25
 * @author Dhiaz Chebastian
 * @since 23.10.0
 */
public abstract class GAbstractBootstrapInitializable implements GBootstrapInitializable {
	protected GBootstrapConfiguration bootstrapConfiguration;
	protected GAbstractBootstrapInitializable() {

	}
	protected GAbstractBootstrapInitializable(GBootstrapConfiguration bootstrapConfiguration) {
		this.bootstrapConfiguration = bootstrapConfiguration;
	}
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public boolean isBootOn() {
		if (Objects.nonNull(bootstrapConfiguration)) {
			return bootstrapConfiguration.isBootOn();
		}
		return this.getClass().getAnnotation(BootstrapInitializable.class).bootOn();
	}
}
