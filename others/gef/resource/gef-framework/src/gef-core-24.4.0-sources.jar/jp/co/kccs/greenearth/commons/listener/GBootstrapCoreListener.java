/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.BootstrapConfigurator;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfigurationImpl;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfigurator;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.priority.GPrioritySorter;
import jp.co.kccs.greenearth.commons.priority.GPrioritySupplier;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;

/**
 *
 * {@link GBootstrapInitializer}の実装クラス
 *
 * @create 2023/10/25
 * @author Dhiaz Chebastian
 * @since 23.10.0
 */

@ScanConfiguration(
	modifiers = {
		@Modifier(
			isPublic = true
		)
	},
	scannedAnnotations = {BootstrapInitializable.class, BootstrapConfigurator.class}
)
public class GBootstrapCoreListener implements GBootstrapInitializer {
	private List<GBootstrapInitializable> initializables = new ArrayList<>();
	private List<Class<? extends GBootstrapInitializable>> bootstrapConfiguratorClasses;
	private final List<Class< ? >> initializableClasses = new ArrayList<>();
	private static final String OBJECT_CREATION_FAILED_ERROR_MESSAGE = "Initilizable object creation is failed due to ";

	private Map<Class< ? extends GBootstrapInitializable>, GBootstrapConfiguration> bootstrapConfigurationMap;
	public GBootstrapCoreListener() {
		initConfiguration();
		initBootstrapListener();
	}
	@Override
	public void initialize() {
		executeListener();
	}

	private void initBootstrapListener() {
		scanListeners();
		initializableClasses.forEach(listener-> initializables.add(createObject(listener)));
		filterBootOn();
	}
	private void filterBootOn() {
		List<GBootstrapInitializable> bootstrapInitializables = new ArrayList<>();
		for (GBootstrapInitializable bootstrapInitializable : initializables) {
			if (bootstrapInitializable.isBootOn()) {
				bootstrapInitializables.add(bootstrapInitializable);
			}
		}
		initializables = bootstrapInitializables;
	}
	private GBootstrapInitializable createObject(Class< ? > listenerClass) {
			GBootstrapConfiguration bootstrapConfiguration = findBootstrapConfiguration(listenerClass).orElse(createDefaultConfiguration(listenerClass));
			try {
				return (GBootstrapInitializable) GObjectInstantiator.getInstance().newInstance(
					listenerClass,
					new Class<?>[] {GBootstrapConfiguration.class},
					new Object[] {bootstrapConfiguration}
				).orElseThrow(()->new GFrameworkException(String.format("%s no constructor(GBootstrapConfigurator).", OBJECT_CREATION_FAILED_ERROR_MESSAGE)));
			} catch (GFrameworkException exception) {
				return (GBootstrapInitializable) GObjectInstantiator.getInstance().newInstance(listenerClass)
					.orElseThrow(()->new GFrameworkException(String.format("%s no default constructor.", OBJECT_CREATION_FAILED_ERROR_MESSAGE)));
			}
	}
	private GBootstrapConfiguration createDefaultConfiguration(Class< ? > bootstrapInitializableClass) {
		boolean bootOn = bootstrapInitializableClass.getAnnotation(BootstrapInitializable.class).bootOn();
		return new GBootstrapConfigurationImpl(bootOn, new HashMap<>());
	}
	private void executeListener() {
		sortInitializables();
		for (GBootstrapInitializable bootstrapInitializable: initializables) {
			if (bootstrapInitializable.isBootOn()) {
				bootstrapInitializable.initialize();
			}
		}
	}
	public void sortInitializables() {
		initializables = GPrioritySorter.sortBySupplier(
			initializables
				.stream()
				.map(GPrioritySupplier::new)
				.collect(Collectors.toList()));
	}

	private Optional<GBootstrapConfiguration> findBootstrapConfiguration(Class< ? > bootstrapListener) {
		if (Objects.nonNull(bootstrapConfigurationMap) && bootstrapConfigurationMap.containsKey(bootstrapListener)) {
			return Optional.of(bootstrapConfigurationMap.get(bootstrapListener));
		}
		return Optional.empty();
	}

	private void initConfiguration() {
		scanBootstrapConfiguration();
		if (Objects.nonNull(bootstrapConfiguratorClasses)) {
			bootstrapConfigurationMap = new ConcurrentHashMap<>();
			for (Class< ? extends GBootstrapInitializable > bootstrapConfigurator : bootstrapConfiguratorClasses) {
				Map<Class<? extends GBootstrapInitializable>, GBootstrapConfiguration> c = new ConcurrentHashMap<>();
				Optional<GBootstrapConfigurator> configurator = GFrameworkUtils.getComponent(GObjectInstantiator.class).newInstance(bootstrapConfigurator);
				if (configurator.isPresent()) {
					configurator.get().configure(c);
					configurator.get().mergeConfiguration(bootstrapConfigurationMap, c);
				} else {
					throw new GFrameworkException(String.format("%s no default constructor for class (%s).", OBJECT_CREATION_FAILED_ERROR_MESSAGE, bootstrapConfigurator.getName()));
				}
			}
		}
	}
	private void scanListeners() {
		initializableClasses.addAll(GScanComponentService.getInstance()
			.getScannedClasses(this.getClass())
			.stream()
			.filter(clazz->clazz.isAnnotationPresent(BootstrapInitializable.class))
			.filter(GBootstrapInitializable.class::isAssignableFrom)
			.collect(Collectors.toList()));
	}
	private void scanBootstrapConfiguration() {
		bootstrapConfiguratorClasses = new ArrayList<>();
		for (Class<?> object : GScanComponentService.getInstance().getScannedClasses(this.getClass())) {
			if (object.isAnnotationPresent(BootstrapConfigurator.class) && GBootstrapConfigurator.class.isAssignableFrom(object)) {
				bootstrapConfiguratorClasses.add((Class<? extends GBootstrapInitializable>) object);
			}
		}
	}

	@Override
	public void destroy() {
		initializables.forEach(GBootstrapInitializable::destroy);
		initializables.clear();
		initializableClasses.clear();
		bootstrapConfigurationMap = null;
		bootstrapConfiguratorClasses = null;
	}
}
