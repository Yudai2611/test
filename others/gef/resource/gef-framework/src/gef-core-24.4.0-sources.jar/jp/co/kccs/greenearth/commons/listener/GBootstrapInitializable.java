/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.listener;

import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfigurator;

/**
 * アプリケーション全体の開始と終了時に、それぞれ初期処理、後処理を実行したい場合に利用します.<br/>
 * 当該インタフェースの実装クラスは、{@link GBootstrapInitializer}により、初期化({@link #initialize()})および後処理({@link #destroy()})が実行されます。<br/>
 * 初期化のタイミングで実行させたくない場合、{@link GBootstrapConfigurator}を利用して、初期実行の可否を変更することができます。<br/>
 * 
 * @see GBootstrapInitializer
 * @see GBootstrapConfigurator
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GBootstrapInitializable {

	/**
	 * リソースを初期化します.<br/>
	 * アプリケーション起動時に呼び出します。<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void initialize();

	/**
	 * リソースを破棄します.<br/>
	 * アプリケーション終了時に呼び出します。<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void destroy();

	/**
	 * アプリケーション起動時、初期化を実行するかどうか判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return true: 実行する/ false: 実行しない
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean isBootOn();

}
