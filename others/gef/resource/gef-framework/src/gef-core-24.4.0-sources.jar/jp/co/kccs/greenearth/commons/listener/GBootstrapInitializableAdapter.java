/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.listener;

import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;

/**
 *
 * {@link GFrameworkListener}のアダプタークラスです<br/>
 *
 * @create 2023/10/25
 * @author Dhiaz Chebastian
 * @since 23.10.0
 */
public class GBootstrapInitializableAdapter extends GAbstractBootstrapInitializable {
	protected GFrameworkListener adaptee;

	public GBootstrapInitializableAdapter() {
		super();
	}
	public GBootstrapInitializableAdapter(GFrameworkListener adaptee) {
		this.adaptee = adaptee;
	}
	public GBootstrapInitializableAdapter(GBootstrapConfiguration configuration, GFrameworkListener adaptee) {
		super(configuration);
		this.adaptee = adaptee;
	}
	/**
	 * {@inheritDoc}
	 * 
	 */
	@Override
	public void initialize() {
		this.adaptee.frameworkInitialized();
	}

	/**
	 * {@inheritDoc}
	 * 
	 */
	@Override
	public void destroy() {
		this.adaptee.frameworkDestroyed();
	}


}
