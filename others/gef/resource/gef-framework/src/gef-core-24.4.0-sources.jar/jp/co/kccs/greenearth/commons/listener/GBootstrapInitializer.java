/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.listener;

/**
 * フレームワークの起動・停止のﾗｲﾌｻｲｸﾙに合わせて、それぞれ初期処理・後処理を実行するためのエントリポイントを担います.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GBootstrapInitializer {

	/**
	 * 初期化します.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void initialize();
	
	/**
	 * 後処理を実行します.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void destroy();
}
