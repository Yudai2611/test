/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.listener;

/**
 * このインターフェースをもとに、フレームワークの起動・停止に関する通知を受け取る処理を実装していきます。<br> 
 * 通知されたイベントを受け取るには、実装したクラスをDI定義ファイルに指定する必要があります。 <br>
 * 
 * @create 2009/07/13
 * @author kitamura
 * @since 3.6.0
 */
@Deprecated(forRemoval = true, since = "23.10.0")
public interface GFrameworkListener {
	
	/**
	 * フレームワークが停止した事を通知します。 
	 * 
	 * @create 2009/07/13
	 * @author kitamura
	 * @since 3.6.0
	 */
	void frameworkDestroyed();
	
	/**
	 * フレームワークが起動した事を通知します。
	 * 
	 * @create 2009/07/13
	 * @author kitamura
	 * @since 3.6.0
	 */
	void frameworkInitialized();
}
