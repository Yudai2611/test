/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.listener;

import java.util.List;

/**
 * 順序付けされた{@link GFrameworkListener}の一覧から、順序にあわせて{@link GFrameworkListener}の生成するイテレータです.<br>
 * 指定された{@link GFrameworkListener}のリストから、{@link #moveNext()}メソッドと{@link #movePrevious()}メソッドにて
 * リストの現在行を移動させて、対象の{@link GFrameworkListener}を取得します。
 * 
 * @create 2009/07/13
 * @author kitamura
 * @since 3.6.0
 */
@Deprecated(forRemoval = true, since = "23.10.0")
public class GFrameworkListenerIterator {

	/** DIキー. */
	public static final String DI_KEY = GFrameworkListenerIterator.class.getPackage().getName() + ".FrameworkListenerIterator";

	/** {@link GFrameworkListener}の一覧. */
	private List<GFrameworkListener> _listeners = null;
	/** 現在指定しているインデックス. */
	private int _currentIndex = 0;
	/** 現在指定されているインデックスにある{@link GFrameworkListener}. */
	private GFrameworkListener _currentListener = null;

	/**
	 * 対象とする{@link GFrameworkListener}の一覧を指定して、{@link GFrameworkListenerIterator}インスタンスを初期化します.
	 * 
	 * @create 2009/07/13
	 * @param listeners 対象とする{@link GFrameworkListener}
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GFrameworkListenerIterator(List<GFrameworkListener> listeners) {
		_listeners = listeners;
	}

	/**
	 * 現在行にある{@link GFrameworkListener}を取得します.
	 * 
	 * @create 2009/07/13
	 * @return 現在行にある{@link GFrameworkListener}
	 * @author kitamura
	 * @since 3.6.0
	 */
	public GFrameworkListener getListener() {
		return _currentListener;
	}

	/**
	 * 処理対象行を一行進めます.
	 * 
	 * @create 2009/07/13
	 * @return 進めた行に{@link GFrameworkListener}が存在するかを表す値。
	 * 	存在する場合は<code>true</code>、存在しない場合は<code>false</code>
	 * @author kitamura
	 * @since 3.6.0
	 */
	public boolean moveNext() {
		if (_currentIndex < _listeners.size()) {
			_currentListener = _listeners.get(_currentIndex);
			_currentIndex++;
			return true;
		} else {
			_currentListener = null;
			return false;
		}
	}

	/**
	 * 処理対象行を一行戻します.
	 * 
	 * @create 2009/07/13
	 * @return 戻した行に{@link GFrameworkListener}が存在するかを表す値。
	 * 	存在する場合は<code>true</code>、存在しない場合は<code>false</code>
	 * @author kitamura
	 * @since 3.6.0
	 */
	public boolean movePrevious() {
		if (0 < _currentIndex) {
			_currentIndex--;
			_currentListener = _listeners.get(_currentIndex);
			return true;
		} else {
			_currentListener = null;
			return false;
		}
	}

}
