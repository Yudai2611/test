/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * フレームワークの初期化時のリスナー関連のパッケージです。
 */
package jp.co.kccs.greenearth.commons.listener;

