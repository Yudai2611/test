/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.log.log4j;

import java.util.Objects;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;
import jp.co.kccs.greenearth.commons.listener.BootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializableAdapter;
import jp.co.kccs.greenearth.commons.priority.GPriority;

/**
 * {@link GLog4JInitializer}を{@link GBootstrapInitializable}にアダプトします.<br/>
 *
 * @create 2023/10/25
 * @author Dhiaz Chebastian
 * @since 23.10.0
 */
@BootstrapInitializable
@Priority(GPriority.HIGH)
public class GLog4JBootstrapInitializableAdapter extends GBootstrapInitializableAdapter {
    public GLog4JBootstrapInitializableAdapter() {
        super(new GLog4JInitializer());
        setResource();
    }
    public GLog4JBootstrapInitializableAdapter(GBootstrapConfiguration configuration) {
        super(configuration, new GLog4JInitializer());
        setResource();
    }
    private void setResource() {
        String resource = "gef-core-framework.properties";
        if (Objects.nonNull(bootstrapConfiguration) && bootstrapConfiguration.getParameters().containsKey("resource")) {
            Object resourceValue = bootstrapConfiguration.getParameters().get("resource");
            if (resourceValue instanceof String) {
                resource = resourceValue.toString();
            }
            if (resourceValue == null) {
                resource = null;
            }
        }
        ((GLog4JInitializer) adaptee).setResource(resource);
    }
}
