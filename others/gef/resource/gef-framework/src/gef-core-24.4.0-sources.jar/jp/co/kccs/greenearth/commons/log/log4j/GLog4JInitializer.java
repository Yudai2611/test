/*
 * Copyright 2009-2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.log.log4j;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.core.config.properties.PropertiesConfigurationBuilder;

import jp.co.kccs.greenearth.commons.listener.GFrameworkListener;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * Log4J設定の初期化と後処理を行う{@link GFrameworkListener}です.<br>
 * フレームワークのロギングにLog4Jを利用する場合は、このリスナーの適用をしてください.<br>
 * Log4Jの設定をフレームワークプロパティから読み込む場合は、DIの定義でresourceコンストラクタにge-framework.proeprtiesを指定します.<br>
 * <br>
 * <br>
 * ※ 再構築ではDIコンテナの初期化の前後でログ出力が必要な場合があるためこのクラスによる初期化は推奨されません.
 * 
 * @create 2009/07/14
 * @author kitamura
 * @since 3.6.0
 */
public class GLog4JInitializer implements GFrameworkListener {

	/** リソース名 */
	private String resource = null;

	/**
	 * {@link GLog4JInitializer}インスタンスを初期化します.
	 * 
	 * @create 2022/03/31
	 * @author oka
	 * @since 22.3.0
	 */
	public GLog4JInitializer() {
	}

	/**
	 * リソース名を設定します.
	 * 
	 * @create 2022/03/31
	 * @param resource リソースのpath
	 * @author oka
	 * @since 22.3.0
	 */
	public void setResource(String resource) {
		this.resource = resource;
	}

	/**
	 * リソース名を取得します.
	 * 
	 * @create 2022/03/31
	 * @param resource リソースのpath
	 * @author oka
	 * @since 22.3.0
	 * 
	 */
	String getResource() {
		return this.resource;
	}

	/**
	 * フレームワークの停止時に、{@link LogManager#shutdown()}を呼び出します.
	 * 
	 * @create 2022/03/31
	 * @see jp.co.kccs.greenearth.commons.listener.GFrameworkListener#frameworkDestroyed()
	 * @author oka
	 * @since 22.3.0
	 */
	public void frameworkDestroyed() {
		// NOTE: shutdown後のログがすべて出力されなくなる.shutdown後のログが必要な場合にはこのクラスの使用が不適当となります.
		LogManager.shutdown();
	}

	/**
	 * フレームワークの起動時に、設定情報を設定ファイルより読み込み初期化します. <br>
	 * Log4Jの設定をフレームワークプロパティから読み込む場合は、DIの定義でresourceプロパティにge-framework.proeprtiesを指定します.
	 * 
	 * @create 2022/03/31
	 * @see jp.co.kccs.greenearth.commons.listener.GFrameworkListener#frameworkInitialized()
	 * @author oka
	 * @since 22.3.0
	 */
	public void frameworkInitialized() {
		initializeLog4JConfiguration(resource);
	}

	/**
	 * 設定ファイルを用いて、Log4Jを再構成します.</br>
	 * 起動したlog4jは、シャッドダウン{@link LogManager#shutdown()}</br>
	 * または、初期化{@link Configurator#initialize(Configuration)}するまで有効です.
	 * 
	 * @create 2022/03/31
	 * @author oka
	 * @since 22.3.0
	 */
	protected void initializeLog4JConfiguration(String resource) {
		if (GStringUtils.isNullOrEmpty(resource)) {
			return;
		}
		configureLog4JSettings(createProperties(resource));
	}

	/**
	 * 読み込んだプロパティを基に、{@link LoggerContext}を再構成します.
	 * 
	 * @create 2022/03/31
	 * @author oka
	 * @since 22.3.0
	 */
	protected void configureLog4JSettings(Properties settings) {
		LoggerContext context = (LoggerContext) LogManager.getContext(false);
		Configuration config = (Configuration) new PropertiesConfigurationBuilder()
				.setConfigurationSource(ConfigurationSource.NULL_SOURCE)
				.setRootProperties(settings)
				.setLoggerContext(context).build();

		context.setConfiguration(config);
		Configurator.initialize(config);
	}

	/**
	 * Log4Jの設定ファイルを読み込みます.
	 * 
	 * @create 2022/03/31
	 * @param resource リソースのpath
	 * @author oka
	 * @since 22.3.0
	 */
	protected Properties createProperties(String resource) {
		Properties settings = new Properties();
		try (
				InputStream istream = Thread
					.currentThread()
					.getContextClassLoader()
					.getResourceAsStream(resource);
		) {
			settings.load(istream);
		} catch (IOException e) {
			throw new GResourceAccessException("Failed to load property settings.", e);
		}
		return settings;
	}
}
