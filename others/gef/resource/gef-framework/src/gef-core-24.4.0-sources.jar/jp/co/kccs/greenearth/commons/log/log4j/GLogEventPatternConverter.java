/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.log.log4j;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.pattern.ConverterKeys;
import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
import org.apache.logging.log4j.core.pattern.PatternConverter;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * GreenEARTH Frameworkで拡張したパターンコンバータクラスです.</br>
 * 指定された{@link GLogPatternFormatter}のkeyから、ログの出力文字列に変換します.
 * 
 * @create 2022/03/31
 * @author oka
 * @since 22.3.0
 */
@Plugin(name = "GLogEventPatternConverter", category = PatternConverter.CATEGORY)
@ConverterKeys({ "g", "G" })
public final class GLogEventPatternConverter extends LogEventPatternConverter {
	private String[] formatterKeys;

	/**
	 * コンストラクタ.
	 * 
	 * @create 2022/03/31
	 * @param formatterKeys {@link GLogPatternFormatter}を指定するkey配列
	 * @auther oka
	 * @since 22.3.0
	 */
	private GLogEventPatternConverter(final String[] formatterKeys) {

		/*
		 * このコンストラクタの引数はHtmlLayoutで使用するものです.
		 * 本クラスはPatternLayoutの使用を前提とするため、この引数の値は使用されることはありません.
		 * LogEventPatternConverterにて定義されている唯一のコンストラクタになるため、空文字を渡しています.
		 */
		super("", "");
		this.formatterKeys = formatterKeys;
	}

	/**
	 * PatternLayoutより呼び出されるメソッドで、インスタンスを生成します.
	 * 
	 * @create 2022/03/31
	 * @param formatterKeys {@link GLogPatternFormatter}を指定するkey配列
	 * @return 生成されたGLogEventPatternConverterインスタンス
	 * @author oka
	 * @since 22.3.0
	 */
	public static GLogEventPatternConverter newInstance(final String[] formatterKeys) {
		return new GLogEventPatternConverter(formatterKeys);
	}

	/**
	 * GreenEARTH Framework固有の情報をログ出力文字列に追加します.
	 * 
	 * @create 2022/03/31
	 * @param event ログイベント、toAppendTo ログ出力文字列
	 * @author oka
	 * @since 22.3.0
	 */
	@Override
	public void format(final LogEvent event, final StringBuilder toAppendTo) {
		GLogPatternFormatterProvider provider = GFrameworkUtils.getComponent(GLogPatternFormatterProvider.DI_KEY);
		for (String formatterKey : formatterKeys) {
			if (provider.isSupported(formatterKey)) {
				provider.getFormatter(formatterKey).format(event, toAppendTo);
			}
		}
	}
}