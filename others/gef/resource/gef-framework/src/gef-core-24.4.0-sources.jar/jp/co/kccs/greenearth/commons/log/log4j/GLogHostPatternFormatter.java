/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.log.log4j;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.logging.log4j.core.LogEvent;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * Log4Jのログパターンにホスト名を追加する{@link GPatternFormatter}クラスです.
 * 
 * @create 2022/03/31
 * @author oka
 * @since 22.3.0
 */
public class GLogHostPatternFormatter implements GLogPatternFormatter {

	private String pattern;

	/**
	 * {@link GLogHostPatternFormatter}インスタンスを初期化します.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	public GLogHostPatternFormatter(String pattern) {
		this.pattern = pattern;
	}

	/**
	 * ホスト名を取得します.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	protected String getHostName() {
		String hostName;
		try {
			hostName = GStringUtils.nullToBlank(InetAddress.getLocalHost().getHostName());
			if (hostName.isEmpty()) {
				hostName = "UnkouwnHost";
			}
		} catch (UnknownHostException e) {
			hostName = "UnkouwnHost";
		}
		return hostName;
	}

	/**
	 * ホスト名を返します.
	 * 
	 * @create 2022/03/31
	 * @param event ログイベント、toAppendTo ログ出力文字列
	 * @return 出力文字列
	 * @author oka
	 * @since 22.3.0
	 */
	public void format(final LogEvent event, final StringBuilder toAppendTo) {
		toAppendTo.append(getHostName());
	}

	/**
	 * patternを取得します.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	public String getPattern() {
		return this.pattern;
	}
}
