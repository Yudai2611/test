/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.log.log4j;

import org.apache.logging.log4j.core.LogEvent;

/**
 * GreenEARTH Framework固有の情報をログ出力文字列に追加します.
 *
 * @create 2022/03/31
 * @author oka
 * @since 22.3.0
 */
public interface GLogPatternFormatter {
	

	/**
	 * {@link GLogEventPatternConverter#format()}によって、呼び出されます.<br>
	 * ログ出力文字列に追加する情報は適宜、具象クラスによって変更します.
	 *
	 * @create 2022/03/31
	 * @author oka
	 * @see jp.co.kccs.greenearth.commons.log.log4j.GLogEventPatternConverter#format(LogEvent,StringBuilder)
	 * @param event:ログイベント、toAppendTo:ログ出力文字列
	 * @since 22.3.0
	 */
	public void format(final LogEvent event, final StringBuilder toAppendTo);

	/**
	 * patternを取得します.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	public String getPattern();
}
