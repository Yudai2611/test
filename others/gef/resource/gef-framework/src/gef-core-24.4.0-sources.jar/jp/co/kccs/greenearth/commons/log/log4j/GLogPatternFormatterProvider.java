/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.log.log4j;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * {@link GLogPatternFormatter}を格納するクラスです.
 * 
 * @create 2022/03/31
 * @author oka
 * @since 22.3.0
 */
public class GLogPatternFormatterProvider {

	/** DIキー. */
	public static final String DI_KEY = GLogPatternFormatterProvider.class.getName();
	/** {@link GLogPatternFormatter}を格納するコレクション. */
	protected Map<String, GLogPatternFormatter> formatterMap = new HashMap<String, GLogPatternFormatter>();

	/**
	 * {@link GLogPatternFormatter}の一覧を検索して、{@link GLogPatternFormatterProvider}インスタンスを初期化します.
	 * 
	 * @create 2022/03/31
	 * @param converterMap {@link GLogPatternFormatter}の一覧
	 * @author oka
	 * @since 22.3.0
	 */
	public GLogPatternFormatterProvider(List<GLogPatternFormatter> formatterList) {
		formatterList.forEach(formatter -> formatterMap.put(formatter.getPattern(), formatter));
	}

	/**
	 * 指定したkeyに該当する{@link GLogPatternFormatter}の存在の有無を確認します.
	 * 
	 * @create 2022/03/31
	 * @param formatterKey formatterのkey
	 * @return 存在する場合は<code>true</code>、存在しない場合は<code>false</code>を返します.
	 * @author oka
	 * @since 22.3.0
	 */
	public boolean isSupported(String formatterKey) {
		return formatterMap.containsKey(formatterKey);
	}

	/**
	 * 指定したpatternに該当する{@link GLogPatternFormatter}を取得します.
	 * 
	 * @create 2022/03/31
	 * @return {@link GLogPatternFormatter}
	 * @author oka
	 * @since 22.3.0
	 */
	public GLogPatternFormatter getFormatter(String pattern) {
		return formatterMap.get(pattern);
	}
}
