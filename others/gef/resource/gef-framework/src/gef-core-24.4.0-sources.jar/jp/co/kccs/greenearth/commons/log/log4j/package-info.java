/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * log4jに関連するパッケージです。
 */
package jp.co.kccs.greenearth.commons.log.log4j;

