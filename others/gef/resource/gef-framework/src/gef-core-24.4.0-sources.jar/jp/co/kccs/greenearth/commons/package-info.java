/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * GFrameworkContext, GFrameworkUtils等を提供します。
 */
package jp.co.kccs.greenearth.commons;

