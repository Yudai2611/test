/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.priority;

import jakarta.annotation.Priority;

/**
 * フレームワーク内で定めるプライオリティの基準値を表します.<br/>
 * 
 * @see Priority
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GPriority {
	/** 優先度:低 */
	public static final int LOW = 7000;
	/** 優先度:ノーマル */
	public static final int NORMAL = 5000;
	/** 優先度:高 */
	public static final int HIGH = 500;
	
	private GPriority() {
	}
}
