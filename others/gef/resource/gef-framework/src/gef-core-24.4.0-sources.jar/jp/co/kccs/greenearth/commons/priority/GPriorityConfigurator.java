/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.priority;

import java.util.Map;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.configuration.GConfigurator;

/**
 * {@link GPriorityRegistry}で管理されたクラスのプライオリティをカスタムしたい場合に利用します.<br/>
 * {@link PriorityConfigurator}をクラスアノテーションに付与することで、{@link GPriorityRegistry}より{@link #configure(Map)}がコールバックされるようになります。<br/>
 * {@link #configure(Map)}では、対象クラスをキー、カスタムされたプライオリティを値に設定します。これにより、{@link GPriorityRegistry#getPriority(Class)}利用時は、カスタムされた値が返却されるようになります。<br/>
 * アプリケーションのクラスパス上に{@link GPriorityConfigurator}クラスが複数存在する場合、プライオリティ({@link Priority})の優劣に基づいて順次{@link #configure(Map)}を実行、全ての変更はマージ({@link GConfigurator#mergeConfiguration(Map, Map)})されます（先勝ち）。<br/>
 * 
 * <pre>
 * example.
 * {@code
 *      @PriorityConfigurator
 *      public class HogePriorityConfigurator implements GPriorityConfigurator {
 *           &#064;Override
 *           public void configure(Map<Class<?>, Integer> configuration) {
 *                configuration.put(Hoge.class, GPriority.NORMAL);
 *                configuration.put(Fuga.class, GPriority.HIGH);
 *                configuration.put(Bar.class, GPriority.LOW);
 *           }
 *      }
 * </pre>
 * 
 * @see GPriorityRegistry
 * @see PriorityConfigurator
 * @see GPriority
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GPriorityConfigurator extends GConfigurator<Class<?>, Integer> {
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	void configure(Map<Class<?>, Integer> configuration);
}
