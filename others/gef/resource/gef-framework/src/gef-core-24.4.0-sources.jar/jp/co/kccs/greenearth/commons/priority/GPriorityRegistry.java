/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.priority;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * クラスとプライオリティの関連付けられたセットをフレームワーク内で一元的に管理します.<br/>
 * プライオリティをカスタムしたい場合、{@link GPriorityConfigurator}を利用します。<br/>
 * 
 * @see  GPriorityConfigurator
 * @see GPriority
 * @see Priority
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GPriorityRegistry {

	/**
	 * 指定したクラスのプライオリティを登録または更新します.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})が適用します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param clazz クラス
	 * @param priority プライオリティ
	 * @return 登録したプライオリティ
	 * @author yamashita
	 * @since 23.10.0
	 */
	int register(Class<?> clazz, int priority);
	
	/**
	 * 指定したクラスのプライオリティを取得します.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})を返却します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param supplier
	 * @return 登録したプライオリティ
	 * @author yamashita
	 * @since 23.10.0
	 */
	int getPriority(Class<?> supplier);

	/**
	 * 管理対象のプライオリティを全て解放します.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void release();

	/**
	 * {@link GPriorityRegistry}インスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GPriorityRegistry}インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GPriorityRegistry getInstance() {
		return GFrameworkUtils.getComponent(GPriorityRegistry.class.getName());
	}
}
