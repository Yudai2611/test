/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.priority;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import lombok.NoArgsConstructor;

/**
 * {@link GPriorityRegistry}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
		@Modifier(
			isPublic = true
		)
	},
	scannedAnnotations = PriorityConfigurator.class,
	scannedAssignableTypes = GPriorityConfigurator.class
)
@NoArgsConstructor
public class GPriorityRegistryImpl implements GPriorityRegistry {

	private Map<Class<?>, Integer> metadataPriorityWithClasses;
	private Map<Class<?>, Integer> configurationWithConfigurator;
	private List<GPriorityConfigurator> configurators;

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public int getPriority(Class<?> clazz) {
		if (getMetadataPriorityWithClasses().containsKey(clazz)) {
			return getMetadataPriorityWithClasses().get(clazz);
		}
		return register(clazz);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public synchronized void release() {
		if (Objects.nonNull(configurationWithConfigurator)) {
			configurationWithConfigurator.clear();
		}
		if (Objects.nonNull(metadataPriorityWithClasses)) {
			metadataPriorityWithClasses.clear();
		}
		metadataPriorityWithClasses = null;
		configurationWithConfigurator = null;
		configurators = null;
	}

	public synchronized int register(Class<?> clazz) {
		int priority = getPriority(clazz, getConfiguration());
		return register(clazz, priority);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public synchronized int register(Class<?> clazz, int priority) {
		getMetadataPriorityWithClasses().put(clazz, priority);
		return priority;
	}

	protected int getPriority(Class<?> clazz, Map<Class<?>, Integer> configuration) {
		if (configuration.containsKey(clazz)) {
			return configuration.get(clazz);
		}
		Optional<String> value = GReflectionHelper.getAnnotationValue(clazz.getDeclaredAnnotation(Priority.class));
		return value.isEmpty() ? GPriority.LOW : Integer.parseInt(value.get());
	}

	private void applyConfiguration() {
		if (Objects.isNull(configurationWithConfigurator)) {
			configurationWithConfigurator = new ConcurrentHashMap<Class<?>, Integer>();
			for (GPriorityConfigurator configurator : getPriorityConfigurators()) {
				Map<Class<?>, Integer> c = new ConcurrentHashMap<Class<?>, Integer>();
				configurator.configure(c);
				configurator.mergeConfiguration(configurationWithConfigurator, c);
			}
		}
	}
	
	List<GPriorityConfigurator> getPriorityConfigurators() {
		if (Objects.isNull(configurators)) {
			configurators = GScanComponentService.getInstance().getScannedInstances(this.getClass());
		}
		return configurators;
	}

	Map<Class<?>, Integer> getMetadataPriorityWithClasses() {
		if (Objects.isNull(metadataPriorityWithClasses)) {
			metadataPriorityWithClasses = new ConcurrentHashMap<Class<?>, Integer>();
		}
		return metadataPriorityWithClasses;
	}
	
	Map<Class<?>, Integer> getConfiguration() {
		if (Objects.isNull(configurationWithConfigurator)) {
			applyConfiguration();
		}
		return configurationWithConfigurator;
	}
}
