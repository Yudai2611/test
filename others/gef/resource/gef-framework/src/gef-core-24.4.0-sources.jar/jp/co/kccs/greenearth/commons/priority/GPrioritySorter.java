/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.priority;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.annotation.Priority;

/**
 * プライオリティ({@link Priority})に基づいて、ソート/リバース順に整列します．<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GPrioritySorter {
	
	/**
	 * 指定したクラスまたはインスタンスのリストをプライオリティに基づいて昇順ソートします.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})に基づきます。<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param providers クラスまたはインスタンスのリスト
	 * @return ソート済みリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static <T> List<T> sortByInstance(List<T> providers) {
		return sortBySupplier(providers
			.stream()
			.map(GPrioritySupplier::new)
			.collect(Collectors.toList()));
	}

	/**
	 * 指定したクラスまたはインスタンスのリストをプライオリティに基づいて降順ソートします.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})に基づきます。<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param providers クラスまたはインスタンスのリスト
	 * @return ソート済みリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static <T> List<T> reverseByInstance(List<T> providers) {
		providers = sortByInstance(providers);
		return reverseOrder(providers);
	}

	/**
	 * 指定したクラスのリストをプライオリティに基づいて昇順ソートします.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})に基づきます。<br/>
	 * 
	 * @create 2023/10/25
	 * @param providers クラスのリスト
	 * @return ソート済みリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static List<Class<?>> sortByClass(List<Class<?>> providers) {
		return sortBySupplier(providers
			.stream()
			.map(GPrioritySupplier<Class<?>>::new)
			.collect(Collectors.toList()));
	}
	
	/**
	 * 指定したクラスのリストをプライオリティに基づいて降順ソートします.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})に基づきます。<br/>
	 * 
	 * @create 2023/10/25
	 * @param providers クラスのリスト
	 * @return ソート済みリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static List<Class<?>> reverseByClass(List<Class<?>> providers) {
		providers = sortByClass(providers);
		return reverseOrder(providers);
	}

	/**
	 * 指定した{@link GPrioritySupplier}のリストをプライオリティに基づいて昇順ソートします.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})に基づきます。<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param providers {@link GPrioritySupplier}のリスト
	 * @return ソート済みリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static <T> List<T> sortBySupplier(List<GPrioritySupplier<T>> providers) {
		return providers
			.stream()
			.sorted(
				new GPriorityComparator<T>()
			)
			.map(GPrioritySupplier::getActualValue)
			.collect(Collectors.toList());

	}

	/**
	 * 指定した{@link GPrioritySupplier}のリストをプライオリティに基づいて降順ソートします.<br/>
	 * {@link Priority}アノテーションが付与されている場合、その値を、付与されていない場合、デフォルトのプライオリティ({@link GPriority#LOW})に基づきます。<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param providers {@link GPrioritySupplier}のリスト
	 * @return ソート済みリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static <T> List<T> reverseBySupplier(List<GPrioritySupplier<T>> providers) {
		List<T> result = sortBySupplier(providers);
		return reverseOrder(result);
	}

	private static <T> List<T> reverseOrder(List<T> providers) {
		Collections.reverse(providers);
		return providers;
	}
	
	private static class GPriorityComparator<T> implements Comparator<GPrioritySupplier<T>> {
		@Override
		public int compare(GPrioritySupplier<T> provider1, GPrioritySupplier<T> provider2) {
			if (provider1.getPriority() == provider2.getPriority()) {
				return 0;
			}
			return provider1.getPriority() > provider2.getPriority() ? 1 : -1;
		}
	}
}
