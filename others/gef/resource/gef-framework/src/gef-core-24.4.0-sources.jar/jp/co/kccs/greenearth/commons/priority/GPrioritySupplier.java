/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.priority;

import jakarta.annotation.Priority;

/**
 * クラスまたはインスタンスにプライオリティ({@link Priority})を付与するラッパーオブジェクトとなります.<br/>
 * 
 * @create 2023/10/25
 * @param <T>
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GPrioritySupplier<T> {
	private final T supplier;

	public GPrioritySupplier(T provider) {
		this.supplier = provider;
	}

	public GPrioritySupplier(T provider, int preferedPriority) {
		this.supplier = provider;
		GPriorityRegistry.getInstance().register(getClazz(provider), preferedPriority);
	}
	public T getActualValue() {
		return supplier;
	}
	public int getPriority() {
		return GPriorityRegistry.getInstance().getPriority(getClazz(getActualValue()));
	}

	private Class<?> getClazz(T provider) {
		if (provider instanceof Class) {
			return (Class<?>) provider;
		}
		return provider.getClass();
	}
}
