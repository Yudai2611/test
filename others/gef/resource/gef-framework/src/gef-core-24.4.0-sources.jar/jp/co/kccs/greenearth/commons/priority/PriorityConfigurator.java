/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.priority;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link GPriorityConfigurator}を表現するマーカーアノテーションです.<br>
 * {@link GPriorityConfigurator}の実装クラスに付与します。<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface PriorityConfigurator {
}
