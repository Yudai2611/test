/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.provider;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import lombok.NoArgsConstructor;

/**
 * {@link GTypeSupporterProvider}の基底クラスです.<br/>
 * {@link GTypeSupporter}を供給するプロバイダーの汎用的な機能を提供することで、{@link GTypeSupporterProvider}具象クラスの実装負担を軽減します。<br/>
 * 下記に、当該クラスの主な機能を記載します。<br/>
 * ・任意の関連付けられた型とサポーターのセットをキャッシュ<br/>
 * ・サポーターの検索キーとなる「任意の型のヒエラルキー※」によるマッチングおよびキャッシュ<br/>
 * ※任意の型にヒットしない場合、祖先のインタフェース・クラスを探索し、合致した祖先とサポーターのセットをキャッシュ＆返却します。<br/>
 * 
 * @create 2023/10/25
 * @param <SUPPORTER>
 * @author yamashita
 * @since 23.10.0
 */
@NoArgsConstructor
public abstract class GAbstractTypeSupporterProvider<SUPPORTER extends GTypeSupporter> implements GTypeSupporterProvider<SUPPORTER> {
	protected List<SUPPORTER> cacheInstancesOfMeta;
	protected Map<Class<?>, Map<Type, SUPPORTER>> cacheInstancesWithClass;

	/**
	 * {@inheritDoc}
	 * 指定した型に対応するサポーターが存在しない場合、祖先のインタフェース・クラスを深さ優先探索で検索し、合致するサポーターを返却します。<br/>
	 * ※祖先の探索アルゴリズムは{@link GReflectionHelper#extractClassHierarchies(Class)}に準拠します。<br/>
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.commons.provider.GTypeSupporterProvider#getTypeSupporter(java.lang.Class)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Optional<SUPPORTER> getTypeSupporter(Class<?> rawType) {
		return getTypeSupporter(rawType, rawType);
	}

	/**
	 * {@inheritDoc}
	 * 指定した型・総称型に対応するサポーターが存在しない場合、祖先のインタフェース・クラスを深さ優先探索で検索し、合致するサポーターを返却します。<br/>
	 * ※祖先の探索アルゴリズムは{@link GReflectionHelper#extractClassHierarchies(Class)}に準拠します。<br/>
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.commons.provider.GTypeSupporterProvider#getTypeSupporter(java.lang.Class, java.lang.reflect.Type)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public synchronized Optional<SUPPORTER> getTypeSupporter(Class<?> rawType, Type genericType) {
		if (Objects.isNull(rawType)) {
			rawType = GTypeSupporter.Null.class;
		}

		if (Objects.isNull(genericType)) {
			genericType = rawType;
		}

		if (isCached(rawType, genericType)) {
			return getCachedSupporter(rawType, genericType);
		}

		Optional<SUPPORTER> supporter = findSupporter(rawType, genericType);

		if (supporter.isPresent()) {
			setCacheSupporter(rawType, genericType, supporter.get());
		}

		return supporter;
	}

	/**
	 * {@inheritDoc}
	 * 指定したインスタンスはNullの場合、{@link GTypeSupporter.Null}サポートするサポーターを返します。それ以外はインスタンスのクラスサポートするサポーターを返します。<br/>
	 *
	 * @create 2024/04/30
	 * @see jp.co.kccs.greenearth.commons.provider.GTypeSupporterProvider#getTypeSupporter(Object)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public Optional<SUPPORTER> getTypeSupporter(Object instance) {
		Class<?> type = Objects.isNull(instance) ? GTypeSupporter.Null.class : instance.getClass();
		return getTypeSupporter(type);
	}



	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.commons.provider.GTypeSupporterProvider#clear()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void clear() {
		if (Objects.nonNull(cacheInstancesOfMeta)) {
			cacheInstancesOfMeta.clear();
		}
		if (Objects.nonNull(cacheInstancesWithClass)) {
			cacheInstancesWithClass.clear();
		}
		cacheInstancesOfMeta = null;
		cacheInstancesWithClass = null;
	}

	protected List<SUPPORTER> getCachInstances() {
		if (Objects.isNull(cacheInstancesOfMeta)) {
			cacheInstancesOfMeta = GScanComponentService.getInstance().getScannedInstances(getClass());
		}
		return cacheInstancesOfMeta;
	}

	protected Map<Class<?>, Map<Type, SUPPORTER>> getCacheInstancesWithClass() {
		if (Objects.isNull(cacheInstancesWithClass)) {
			cacheInstancesWithClass = new ConcurrentHashMap<>();
		}
		return cacheInstancesWithClass;
	}

	private boolean isCached(Class<?> rawType, Type genericType) {
		return isGenericTypeCached(rawType, genericType);
	}

	private boolean isRawTypeCached(Class<?> rawType) {
		return getCacheInstancesWithClass().containsKey(rawType);
	}

	private boolean isGenericTypeCached(Class<?> rawType, Type genericType) {
		if (!isRawTypeCached(rawType)) {
			return false; 
		}
		Map<Type, SUPPORTER> s = getCacheInstancesWithClass().get(rawType);
		return s.containsKey(genericType);
	}

	private Optional<SUPPORTER> getCachedSupporter(Class<?> rawType, Type genericType) {
		if (isGenericTypeCached(rawType, genericType)) {
			Map<Type, SUPPORTER> genericTypeCached = getCacheInstancesWithClass().get(rawType);
			return Optional.ofNullable(genericTypeCached.get(genericType));
		}
		return Optional.empty();
	}

	private void setCacheSupporter(Class<?> rawType, Type genericType, SUPPORTER supporter) {
		Map<Type, SUPPORTER> genericTypeCached = new ConcurrentHashMap<>();
		genericTypeCached.put(genericType, supporter);
		getCacheInstancesWithClass().put(rawType, genericTypeCached);
	}

	private Optional<SUPPORTER> findSupporter(Class<?> rawType, Type genericType) {
		List<SUPPORTER> supporters = findSupporters(GReflectionHelper.extractClassHierarchies(rawType));
		return getGenericTypeSupporter(supporters, rawType, genericType);
	}

	private List<SUPPORTER> findSupporters(GListMap<Class<?>, Class<?>> hierarchies) {
		return getCachInstances()
				.stream()
				.filter(v -> hierarchies.containsKey(v.getRawType()))
				.collect(Collectors.toList());
	}

	private Optional<SUPPORTER> getGenericTypeSupporter(List<SUPPORTER> supporters, Class<?> rawType, Type genericType) {
		Optional<SUPPORTER> supporter = supporters.stream().filter(v -> genericType == v.getGenericType()).findFirst();
		if (supporter.isEmpty()) {
			return supporters.stream().filter(v -> ((Class<?>) v.getGenericType()).isAssignableFrom(rawType)).findFirst();
		}
		return supporter;
	}
}
