/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.provider;

import java.lang.reflect.Type;

/**
 * {@link GTypeSupporter}の基底クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public abstract class GAbstractTypeSuppoter implements GTypeSupporter {

	private static final String $S_MUST_BE_REQUIRED = "%s must be required.";
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Class<?> getRawType() {
		if (hasSupportedType()) {
			return getRawTypeValue();
		}
		throw new IllegalStateException(mustBeRequired(SupportedType.class.getSimpleName()));
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Type getGenericType() {
		if (hasSupportedType()) {
			return isDefaultGenericType() ? getRawTypeValue() : getGenericTypeValue();
		}
		throw new IllegalStateException(mustBeRequired(SupportedType.class.getSimpleName()));
	}
	
	private static String mustBeRequired(Object arg) {
		return message($S_MUST_BE_REQUIRED, arg);
	}
	
	private static String message(String message, Object... args) {
		return String.format(message, args);
	}
	
	private boolean hasSupportedType() {
		return getClass().isAnnotationPresent(SupportedType.class);
	}
	
	private Class<?> getRawTypeValue() {
		return getClass().getAnnotation(SupportedType.class).value();
	}
	
	private Type getGenericTypeValue() {
		return getClass().getAnnotation(SupportedType.class).genericType();
	}
	
	private boolean isDefaultGenericType() {
		return Type.class.equals(getClass().getAnnotation(SupportedType.class).genericType());
	}
}
