/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.provider;

import java.lang.reflect.Type;

/**
 * (任意の型と関連付けられた)サポーター({@link GTypeSupporter})を表します.<br/>
 * このサポーターは、抽象的な表現であり、ある特定のインタフェースを実装したグループに所属する各具象クラスを示します。<br/>
 * 各具象クラス(Concrete Class)がもし、特定の型ごとにマッピングされる場合、ここではそれをサポーターと表現します。<br/>
 * 例えば、Concrete Class群が2つあるうち、一方はHoge型を、他方はFuga型の場合に処理を実行したい場合、それぞれHoge型またはFuga型に対応するサポーターとなります。<br/>
 * {@link GTypeSupporter}の具象クラスに{@link SupportedType}アノテーションを宣言し、サポーターに関連付けされた型を指定することで、
 * {@link GTypeSupporterProvider}から供給可能となります。<br/>
 * 
 * <pre>
 *  example.
 *  
 *  ※下記の例では、GHogeインタフェースに所属するGConcleteHogeは、Hoge.classをサポートします。
 * {@code
 *      @SupportedType(Hoge.class)
 *      <code>@</code>Priority(GPriority.NORMAL)
 *      public class GConcleteHoge extends GAbstractTypeSuppoter implements GHoge<GEndpointResource> 
 *      ...
 *      }
 * </pre>
 * 
 * @see GTypeSupporterProvider
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GTypeSupporter {

	Class<?> getRawType();
	
	Type getGenericType();

	public static class Null {
	}
}
