/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.provider;

import java.lang.reflect.Type;
import java.util.Optional;

/**
 * 当該インタフェースは、「任意の型と関連付けられたサポーター({@link GTypeSupporter})」を供給するための汎用的なインタフェースを規定します.<br/>
 * {@link GTypeSupporterProvider}を実装するクラスは、指定された型に対応する{@link GTypeSupporter}を返却する責任があります。<br/>
 * 
 * <pre>
 * example type supporter provider.
 * {@code
 *      @ScanConfiguration(isPublic = true, scannedAnnotations = SupportedType.class, scannedAssignableTypes = GHoge.class)
 *      public class GHogeProviderImpl<T> extends GAbstractTypeSupporterProvider<GHoge<T>> implements GHogeProvider<T> {
 * 	     <code>@</code>Override
 * 	     public GHoge<T> getHoge(T material) {
 * 		     Class<?> type = Objects.isNull(material) ? Null.class : material.getClass();
 * 		     Optional<GHoge<T>> supporter = super.getTypeSupporter(type);
 * 		     ...
 * 	     }
 *      }
 * 
 * 
 * example type supporter.
 * {@code
 *      @SupportedType(GEndpointResource.class)
 *      <code>@</code>Priority(GPriority.NORMAL)
 *      public class GConcleteHoge extends GAbstractTypeSuppoter implements GHoge<GEndpointResource> 
 *      ...
 *      }
 * </pre>
 * 
 * @see GTypeSupporter
 * @create 2023/10/25
 * @param <SUPPORTER>
 * @author yamashita
 * @since 23.10.0
 */
public interface GTypeSupporterProvider<SUPPORTER extends GTypeSupporter> {

	/**
	 * 指定した型に対応するサポーターを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param supportType 関連付けされたクラス型
	 * @return 対応するサポーター
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<SUPPORTER> getTypeSupporter(Class<?> supportType);
	
	/**
	 * 指定した型、総称型に対応するサポーターを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param rawType 関連付けされたクラス型
	 * @param genericType 総称型
	 * @return 対応するサポーター
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<SUPPORTER> getTypeSupporter(Class<?> rawType, Type genericType);

	/**
	 * 指定した型、総称型に対応するサポーターを取得します.<br/>
	 *
	 * @create 2024/04/30
	 * @param instance オブジェクト
	 * @return 対応するサポーター
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	Optional<SUPPORTER> getTypeSupporter(Object instance);
	/**
	 * 管理対象のサポーターをクリアします.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void clear();
}
