/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.provider;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Type;

/**
 * サポート対象の型を指定します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface SupportedType {

	/**
	 * サポート対象の型(raw type)を指定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return サポート対象の型(raw type)
	 * @author yamashita
	 * @since 23.10.0
	 */
	Class<?> value();

	/**
	 * サポート対象の総称型(generic type)を指定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return サポート対象の総称型(generic type)
	 * @author yamashita
	 * @since 23.10.0
	 */
	Class<?> genericType() default Type.class;
}
