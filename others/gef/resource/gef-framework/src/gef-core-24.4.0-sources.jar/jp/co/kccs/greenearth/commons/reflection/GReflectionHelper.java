/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.reflection;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.annotation.AnnotatedElementUtils;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.commons.collection.GListMapImpl;

/**
 * リフレクション関連の汎用的なAPIを提供します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public final class GReflectionHelper {

	private static final Log LOGGER = LogFactory.getLog(GReflectionHelper.class);
	
	private static final String UNABLE_TO_GET_THE_$s_ANNOTATION_VALUE_PROPERTY = "Unable to get the %s annotation value property.";
	
	/**
	 * 指定したインスタンスのクラスを起点とし、インタフェース・スーパークラスの順に祖先を深さ優先に探索し抽出します.<br/>
	 * 返却値は、順序付き{@link LinkedHashMap}とし、キー・バリューは同じ値を設定します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param sut 対象インスタンス
	 * @return 対象クラスを含む祖先の一覧
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static <T> GListMap<Class<?>, Class<?>> extractClassHierarchies(T sut) {
		if (Objects.isNull(sut)) {
			return new GListMapImpl<>();
		}
		return extractClassHierarchies(sut.getClass());
	}
	
	/**
	 * 指定したインスタンスのクラスを起点とし、インタフェース・スーパークラスの順に祖先を深さ優先に探索し抽出します.<br/>
	 * 返却値は、順序付き{@link LinkedHashMap}とし、キー・バリューは同じ値を設定します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param sut 対象クラス
	 * @return 対象クラスを含む祖先の一覧
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GListMap<Class<?>, Class<?>> extractClassHierarchies(Class<?> sut) {
		GListMap<Class<?>, Class<?>> hierarchies = new GListMapImpl<>();
		if (Objects.isNull(sut)) {
			return new GListMapImpl<>();
		}
		hierarchies.put(sut, sut);
		LinkedList<Class<?>> temp = new LinkedList<>();
		Class<?>[] interfaces = sut.getInterfaces();
		temp.addAll(Arrays.asList(interfaces));
		Class<?> superClazz = sut.getSuperclass();
		if (Objects.nonNull(superClazz)) {
			temp.add(superClazz);
		}
		while (!temp.isEmpty()) {
			Class<?> first = temp.removeFirst();
			hierarchies.put(first, first);
			GListMap<Class<?>, Class<?>> extract = extractClassHierarchies(first);
			hierarchies.putAll(extract);
		}
		return hierarchies;
	}
	
	/**
	 * 指定したアノテーションの(value属性の)値を取得します.<br/>
	 * 値が配列を示す場合、先頭の要素(x[0])を返却します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param annotation
	 * @return アノテーションの値
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static Optional<String> getAnnotationValue(Annotation annotation) {
		return getAnnotationValues(annotation).map(v -> v[0]);
	}
	
	/**
	 * 指定したアノテーションの(value属性の)値を配列で取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param annotation
	 * @return アノテーションの値
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static Optional<String[]> getAnnotationValues(Annotation annotation) {
		if (Objects.isNull(annotation)) {
			return Optional.empty();
		}
		String[] values = null;
		try {
			Method method = annotation.annotationType().getMethod("value");
			if (method.getReturnType() == String.class) {
				values = new String[] {(String) method.invoke(annotation)};
			} else if (method.getReturnType() == String[].class) {
				values = (String[]) method.invoke(annotation);
			} else if (method.getReturnType() == int.class || method.getReturnType() == Integer.class) {
				values = new String[] {method.invoke(annotation).toString()};
			}
		} catch (Exception e) {
			LOGGER.warn(message(UNABLE_TO_GET_THE_$s_ANNOTATION_VALUE_PROPERTY, annotation.getClass().getSimpleName()), e);
		}
		return Optional.ofNullable(values);
	}

	/**
	 * 第１引数で指定したエレメン({@link AnnotatedElement})トに、第2引数に指定したアノテーションが含まれるかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param element 検査対象のエレメント
	 * @param annotationClass 検査するアノテーション
	 * @return true: 含まれる / false: 含まれない
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static boolean isAnnotationPresent(AnnotatedElement element, Class<? extends Annotation> annotationClass) {
		return isNotNull(element) && AnnotatedElementUtils.hasAnnotation(element, annotationClass);
	}

	public static boolean isMatch(Annotation source, Class<? extends Annotation> pattern) {
		return source.annotationType() == pattern;
	}

	/**
	 * 指定名のクラスを取得し、Optional<Class>として返す、取得できない場合、Optional.empty()を返す.<br/>
	 * 
	 * @param className クラス名
	 * @return Optional<Class>
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static Optional<Class<?>> classForName(String className) {
		try {
			return Optional.of(uncheckedCall(() -> Class.forName(className.trim())));
		} catch (Exception e) {
			return Optional.empty();
		}
	}
	
	public static <T> T uncheckedCall(Callable<T> callable) {
		try {
			return callable.call();
		} catch (Exception e) {
			throw new GFrameworkException(e);
		}
	}

	static <T extends Object> boolean isNotNull(T obj) {
		return obj != null;
	}
	
	private static String message(String message, Object... args) {
		return String.format(message, args);
	}

	/**
	 * 第１引数で指定したクラス名のクラスに、第2引数に指定したアノテーションが含まれるかどうかを判定します.<br/>
	 *
	 * @param className クラス名
	 * @param annotationClass 検査するアノテーション
	 * @return true: 含まれる / false: 含まれない
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static boolean isAnnotationPresent(String className, Class<? extends Annotation> annotationClass) {
		Optional<Class<?>> optional = classForName(className);
		if (optional.isPresent()) {
			return GReflectionHelper.isAnnotationPresent(optional.get(), annotationClass);
		}
		return false;
	}
}
