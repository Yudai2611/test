/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;

/**
 * {@link GResourceManager}のデフォルト実装です.<br><br>
 * 
 * <b>【キャッシュ機能の実装】</b><br>
 * {@link GAbstractResourceManager}は、3タイプのキャッシュ方式を提供します。
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>キャッシュモード</td><td>キャッシュ方法</td></tr>
 * <tr><td><code>init</code></td><td>アプリケーション起動時に全てのリソースを読み込みキャッシュします</td></tr>
 * <tr><td><code>used</code></td><td>コード毎に初回利用時にリソースを読み込みキャッシュします</td></tr>
 * <tr><td><code>none</code></td><td>一切キャッシュしません</td></tr>
 * </table>
 * キャッシュモードは、<code>ge-framework.properties</code>にて指定します。<br>
 * プロパティのキーは、この抽象クラスを実装したクラスで決定されます。<br><br>
 * 
 * <b>【ロケールに対するリソースの検索順序】</b><br>
 * リソースを取得する際のロケールの解決は次の優先順位で検索されます。<br>
 * 　1.指定されたロケールの 言語コード_国コード_バリアントコード<br>
 * 　2.指定されたロケールの	言語コード_国コード<br>
 * 　3.指定されたロケールの	言語コード<br>
 * 　4.デフォルトロケール
 * 
 * [例] : <pre>ja_JP_KANSAI -> ja_JP -> ja -> デフォルトロケール</pre>
 * 
 * <b>【デフォルトロケール】</b><br>
 * デフォルトロケールは、指定したロケールに対応するリソースが存在しない場合に、適応されるロケールです。<br>
 * デフォルトロケールとして扱われるロケールはDAOの実装によって異なります。<br>
 * デフォルトロケールでは、ロケールオブジェクトが<code>new Locale( "" )</code>として扱われます。<br>
 * 
 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager
 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao
 * @create 2007/03/28
 * @param <T> 取り扱うリソースの型
 * @author kitamura
 * @since 3.0.0
 */
public abstract class GAbstractResourceManager<T> implements GResourceManager<T> {

	/** エラーメッセージリソースキャッシュ. */
	private Map<Locale, Map<String, T>> cache = null;
	/** 文字列リソースのキャッシュモード. */
	private GCacheMode cacheMode = GCacheMode.NONE;
	/** エラーメッセージリソース情報読み取り用DAO. */
	private GResourceDao<T> dao = null;

	/**
	 * {@link GAbstractResourceManager}インスタンスを初期化します.
	 * 
	 * @create 2007/03/28
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GAbstractResourceManager() {
	}

	/**
	 * リソースアクセス用DAOを指定して、{@link GAbstractResourceManager}インスタンスを初期化します.
	 * 
	 * @create 2007/03/28
	 * @param dao リソースアクセス用DAO
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GAbstractResourceManager(GResourceDao<T> dao) throws GResourceAccessException {
		this.dao = dao;
	}
	
	/**
	 * キャッシュデータの初期化を行っています。
	 * 
	 * @create 2013/06/28
	 * @author KCCS T.kitamura
	 * @since 3.12.0
	 */
	public void init() {
		cacheMode = GCacheMode.convert(GFrameworkUtils.getProperty(getCachePropertyKey(), GCacheMode.CACHE_NONE));

		// キャッシュを初期化時に作成する場合
		if (cacheMode == GCacheMode.INIT) {
			// 全件キャッシュ
			cache = dao.findResourceAll();
		}
		else if (cacheMode == GCacheMode.USED) {
			// 空のキャッシュ領域を確保
			cache = new HashMap<Locale, Map<String, T>>();
			for (Locale locale : dao.getLocaleList()) {
				cache.put(locale, new HashMap<String, T>());
			}
		}
	}

	/**
	 * キャッシュデータの破棄を行います。
	 * 
	 * @create 2013/06/28
	 * @author KCCS T.kitamura
	 * @since 3.12.0
	 */
	@Override
	public void destroy() throws GResourceAccessException {
		cache.clear();
	}

	/**
	 * キャッシュ済みの情報を取得します.
	 * 
	 * @create 2007/03/28
	 * @return キャッシュマップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected Map<Locale, Map<String, T>> getCache() {
		return cache;
	}

	/**
	 * キャッシュを設定します。
	 * 
	 * @param cache キャッシュ
	 */
	protected void setCache(Map<Locale, Map<String, T>> cache) {
		this.cache = cache;
	}

	/**
	 * キャッシュモードを取得します.
	 * 
	 * @create 2007/03/28
	 * @return キャッシュモード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GCacheMode getCacheMode() {
		return cacheMode;
	}

	/**
	 * キャッシュモードを設定します。
	 * 
	 * @param cacheMode キャッシュモード
	 */
	protected void setCacheMode(GCacheMode cacheMode) {
		this.cacheMode = cacheMode;
	}

	/**
	 * デフォルトロケールより、指定したキーに該当するリソースを取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager#getResource(java.lang.String)
	 * @create 2007/03/28
	 * @param key キー
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public T getResource(String key) throws GResourceAccessException {
		return getResource(key, DEFAULT_LOCALE);
	}

	/**
	 * ロケール名に対するリソースの検索順序に基づき、
	 * 指定したキーとロケールに該当するリソースを取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager#getResource(java.lang.String, java.util.Locale)
	 * @create 2007/03/28
	 * @param key キー
	 * @param locale ロケール
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public T getResource(String key, Locale locale) throws GResourceAccessException {
		if (key == null) {
			throw new NullPointerException("code is null.");
		}
		if (locale == null) {
			locale = DEFAULT_LOCALE;
		}

		// 与えられたロケール名でリソースを取得
		T resource = searchResource(key, locale);

		return resource;
	}

	/**
	 * デフォルトロケールより、キーに該当したリソースのバインド変数に、
	 * 指定したパラメータをバインドした結果を取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager#getResource(java.lang.String, java.lang.String[])
	 * @create 2007/03/28
	 * @param key キー
	 * @param params バインドパラメータ
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public T getResource(String key, Object[] params) throws GResourceAccessException {
		return getResource(key, params, DEFAULT_LOCALE);
	}

	/**
	 * ロケールに対するリソースの検索順序に基づき、
	 * 指定したキーとロケールに該当したリソースのバインド変数に、
	 * 指定したパラメータをバインドした結果を取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager#getResource(java.lang.String, java.lang.String[], java.util.Locale)
	 * @create 2007/03/28
	 * @param key キー
	 * @param params バインドパラメータ
	 * @param locale ロケール
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public T getResource(String key, Object[] params, Locale locale) throws GResourceAccessException {
		// 前提条件判定
		if (params == null) {
			throw new NullPointerException("Binding paramater is null.");
		}

		T resource = getResource(key, locale);

		// パラメータのバインド適用
		if (resource != null) {
			resource = bindParameter(resource, params);
		}

		return resource;
	}
	
	/**
	 * 全てのリソースを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager#getAllResources()
	 * @return 全リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author KCCS N.Nishimura
	 * @create 2014/06/21
	 * @since 3.16.0
	 */
	@Override
	public Map<Locale, Map<String, T>> getAllResources() throws GResourceAccessException {
		return dao.findResourceAll();
	}

	/**
	 * リソースアクセスに利用するDAOインスタンスを取得します.
	 * 
	 * @create 2007/03/28
	 * @return リソースアクセス用DAO
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GResourceDao<T> getResourceDao() {
		return dao;
	}

	/**
	 * データソースへのDao{@link GResourceDao}を設定します.
	 * 
	 * @create 2007/03/28
	 * @param resourceDao リソースDAO
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setResourceDao(GResourceDao<T> resourceDao) {
		dao = resourceDao;
	}

	/**
	 * 指定されたリソースにバインドパラメータをバインドします.
	 * 
	 * @create 2007/03/28
	 * @param source リソース
	 * @param params バインドパラメータ
	 * @return バインド済みリソース
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected abstract T bindParameter(T source, Object[] params);

	/**
	 * キャッシュ方式を指定するプロパティキー名を取得します.
	 * 
	 * @create 2007/03/28
	 * @return プロパティキー名
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected abstract String getCachePropertyKey();

	/**
	 * キャッシュより、指定されたキー、ロケールに該当するリソースを取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2007/03/28
	 * @param key キー
	 * @param locale ロケール
	 * @return リソース
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected T searchCache(String key, Locale locale) {
		T message = null;

		if (cache.containsKey(locale)) {
			Map<String, T> resourceMap = cache.get(locale);
			message = resourceMap.get(key);
		}
		return message;
	}

	/**
	 * 指定したキー、ロケールに該当するリソースを検索します.<br>
	 * 指定したロケールで見つからない場合は、<b>ロケール名に対するリソースの検索順序</b>
	 * に従い、検索を続けます。<br>
	 * 該当するリソースが見つかった場合は、見つかったロケールでキャッシュします。<br>
	 * 該当するリソースが存在しない場合、デフォルトロケール(<code>null</code>）で取
	 * 
	 * @create 2007/03/28
	 * @param key キー
	 * @param locale ロケール
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected T searchResource(String key, Locale locale) throws GResourceAccessException {
		Locale targetLocale = locale;
		Locale usedLocale = null;
		while (true) {
			T value = null;

			if (cacheMode == GCacheMode.NONE) {
				value = dao.findResource(key, targetLocale);
			}
			else if (cacheMode == GCacheMode.INIT) {
				value = searchCache(key, targetLocale);
			}
			else if (cacheMode == GCacheMode.USED) {
				if (!cache.containsKey(targetLocale)) {
					cache.put(targetLocale, new HashMap<String, T>());
				}
				value = searchCache(key, targetLocale);
				if (value == null) {
					value = dao.findResource(key, targetLocale);
					if (value != null) {
						Map<String, T> resourceMap = cache.get(targetLocale);
						resourceMap.put(key, value);
						if (usedLocale != null) {
							cache.get(usedLocale).put(key, value);
						}
					}
				}
				if (usedLocale == null) {
					usedLocale = targetLocale;
				}
			}

			// 終了条件
			if (value != null) {
				return value;
			}
			else if (DEFAULT_LOCALE.equals(targetLocale)) {
				return null;
			}

			// ロケールコードを短縮する(例:ja_JP -> ja -> null)
			String localeKey = targetLocale.toString();
			int underscore = localeKey.lastIndexOf("_");
			if (underscore < 0) {
				targetLocale = DEFAULT_LOCALE;
			}
			else {
				targetLocale = GLocaleUtils.getLocale(localeKey.substring(0, underscore));
			}
		}
	}
}
