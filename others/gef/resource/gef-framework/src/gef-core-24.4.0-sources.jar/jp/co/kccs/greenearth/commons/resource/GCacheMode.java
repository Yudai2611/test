/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource;

import java.util.HashMap;
import java.util.Map;

/**
 * リソース情報のキャッシュモードを定義します.
 * 
 * @create 2007/03/01
 * @author kitamura
 * @since 3.0.0
 */
public enum GCacheMode {
	/** 起動時に全てキャッシュする. */
	INIT,
	/** キャッシュしない. */
	NONE,
	/** 適時読込、使用した物のみキャッシュする. */
	USED;

	/** {@link #INIT}を表す文字列. */
	public static final String CACHE_INIT = "init";
	/** {@link #NONE}を表す文字列. */
	public static final String CACHE_NONE = "none";
	/** {@link #USED}を表す文字列. */
	public static final String CACHE_USED = "used";

	/** 文字列-列挙値マップ. */
	private static final Map<String, GCacheMode> VALUE_MAP = new HashMap<String, GCacheMode>();

	static {
		VALUE_MAP.put(CACHE_INIT, INIT);
		VALUE_MAP.put(CACHE_NONE, NONE);
		VALUE_MAP.put(CACHE_USED, USED);
	}

	/**
	 * キャッシュモードを表す文字列より列挙値を取得します.
	 * 
	 * @create 2007/03/02
	 * @param mode キャッシュモード文字列
	 * @return キャッシュモード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GCacheMode convert(final String mode) {
		GCacheMode key = VALUE_MAP.get(mode);
		if (key == null) {
			key = GCacheMode.NONE;
		}
		return key;
	}
}
