/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource;

import jp.co.kccs.greenearth.commons.GFrameworkException;

/**
 * リソース取得に関する例外を表します.
 * 
 * @create 2007/02/28
 * @author kitamura
 * @since 3.0.0
 */
public class GResourceAccessException extends GFrameworkException {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = 4353107252307436773L;

	/**
	 * {@link GResourceAccessException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GResourceAccessException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GResourceAccessException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GResourceAccessException(final String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GResourceAccessException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GResourceAccessException(final Throwable cause) {
		super(cause);
	}
	
	/**
	 * 例外メッセージとこの例外の発生原因を指定し、{@link GResourceAccessException}のインスタンスを初期化します.
	 * 
	 * @create 2013/08/01
	 * @param message メッセージ
	 * @param cause 原因となった例外
	 * @author KCCS K.Fujita
	 * @since 3.12.0
	 */
	public GResourceAccessException(final String message, final Throwable cause) {
		super(message, cause);
	}
}
