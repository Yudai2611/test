/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource;

import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * データソースからメッセージリソースを取得するクラスのインターフェイスを定義します.
 * 
 * @create 2007/02/23
 * @param <T> 取り扱うリソースの型
 * @author aono
 * @since 3.0.0
 */
public interface GResourceDao<T> {

	/** デフォルトロケール. */
	Locale DEFAULT_LOCALE = new Locale("");

	/**
	 * 全メッセージリソースを取得します.
	 * 
	 * @create 2007/02/21
	 * @return 全メッセージリソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author aono
	 * @since 3.0.0
	 */
	Map<Locale, Map<String, T>> findResourceAll() throws GResourceAccessException;

	/**
	 * リソースを取得します.<br>
	 * ※指定キーに該当するリソースが登録されていない場合は、<code>null</code>を返します。
	 * 
	 * @create 2007/02/21
	 * @param key キー
	 * @param locale ロケール名
	 * @return メッセージリソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author aono
	 * @since 3.0.0
	 */
	T findResource(String key, Locale locale) throws GResourceAccessException;

	/**
	 * ロケールの一覧を取得します.
	 * 
	 * @create 2007/02/27
	 * @return ロケールのリスト
	 * @author aono
	 * @since 3.0.0
	 */
	List<Locale> getLocaleList();
}
