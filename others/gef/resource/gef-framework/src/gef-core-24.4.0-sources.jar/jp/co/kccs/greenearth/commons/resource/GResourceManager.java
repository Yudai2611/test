/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource;

import java.util.Locale;
import java.util.Map;

/**
 * 地域化された外部リソースへのアクセスを管理する機能を提供します.<br>
 * 
 * {@link GResourceManager}では、一度取得したリソース情報をメモリ上にキャッシュすることで、
 * リソースアクセスによるレスポンス悪化を防止する機能を持ちます。<br>
 * 
 * リソースへのアクセスには、別途データアクセスオブジェクトを用意する必要があります。<br>
 * {@link GResourceDao}インターフェースを実装したオブジェクトを利用してリソースを格納するデータソースへの
 * アクセスを行います。<br>
 * 
 * また、{@link GResourceManager}は、一度アクセスしたリソース情報をメモリ上にキャッシュする仕組みを提供します。
 * 
 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao
 * @create 2007/03/28
 * @param <T> 取り扱うリソースの型
 * @author kitamura
 * @since 3.0.0
 */
public interface GResourceManager<T> {

	/** デフォルトロケール. */
	Locale DEFAULT_LOCALE = new Locale("");

	/**
	 * デフォルトロケールより、指定したキーに該当するリソースを取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2007/03/28
	 * @param key キー
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	T getResource(String key) throws GResourceAccessException;

	/**
	 * ロケール名に対するリソースの検索順序に基づき、
	 * 指定したキーとロケールに該当するリソースを取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2007/03/28
	 * @param key キー
	 * @param locale ロケール
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	T getResource(String key, Locale locale) throws GResourceAccessException;

	/**
	 * デフォルトロケールより、キーに該当したリソースのバインド変数に、
	 * 指定したパラメータをバインドした結果を取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2007/03/28
	 * @param key キー
	 * @param params バインドパラメータ
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	T getResource(String key, Object[] params) throws GResourceAccessException;

	/**
	 * ロケールに対するリソースの検索順序に基づき、
	 * 指定したキーとロケールに該当したリソースのバインド変数に、
	 * 指定したパラメータをバインドした結果を取得します.<br>
	 * 対応する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager#getResource(java.lang.String, java.lang.String[], java.util.Locale)
	 * @create 2007/03/28
	 * @param key キー
	 * @param params バインドパラメータ
	 * @param locale ロケール
	 * @return リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	T getResource(String key, Object[] params, Locale locale) throws GResourceAccessException;
	
	/**
	 * 全てのリソースを取得します.<br>
	 * 
	 * @return 全リソース
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author KCCS N.Nishimura
	 * @create 2014/06/21
	 * @since 3.16.0
	 */
	Map<Locale, Map<String, T>> getAllResources() throws GResourceAccessException;
	
	/**
	 * インスタンスの初期化を行います。
	 * 
	 * @create 2013/06/28
	 * @author KCCS T.kitamura
	 * @since 3.12.0
	 */
	void init() throws GResourceAccessException;
	
	/**
	 * インスタンスの破棄処理を行います。
	 * 
	 * @create 2013/06/28
	 * @author KCCS T.kitamura
	 * @since 3.12.0
	 */
	void destroy() throws GResourceAccessException;
}