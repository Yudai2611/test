/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.error;

import java.io.Serializable;

import jp.co.kccs.greenearth.commons.GFrameworkException;

/**
 * エラーメッセージを表します.
 * 
 * @see jp.co.kccs.greenearth.commons.resource.error.GErrorType
 * @create 2007/02/28
 * @author kitamura
 * @since 3.0.0
 */
public class GErrorMessage implements Cloneable, Serializable {
	
	/** シリアルバージョン. */
	private static final long serialVersionUID = 8034929922719028747L;
	/** エラーコード. */
	private String code = null;
	/** エラーメッセージ. */
	private String message = null;
	/** エラータイプ. */
	private GErrorType type = null;

	/**
	 * {@link GErrorMessage}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GErrorMessage() {
	}

	/**
	 * エラーコードを指定して{@link GErrorMessage}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param errorCode エラーコード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GErrorMessage(final String errorCode) {
		code = errorCode;
	}

	/**
	 * このインスタンスの状態を基に、常用インスタンス（クローン）を生成します.<br>
	 * 
	 * @create 2007/11/16
	 * @return 常用インスタンス
	 * @throws GFrameworkException 常用インスタンスの生成に失敗した場合
	 * @author kitamura
	 * @since 3.2.1
	 */
	public GErrorMessage createPracticalInstance() throws GFrameworkException {
		GErrorMessage clone = null;
		try {
			clone = (GErrorMessage) clone();
		}
		catch (CloneNotSupportedException e) {
			throw new GFrameworkException(e);
		}

		return clone;
	}

	/**
	 * 	エラーコードを取得します.
	 * 
	 * @create 2007/02/28
	 * @return エラーコード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getCode() {
		return code;
	}

	/**
	 * エラーメッセージを取得します.
	 * 
	 * @create 2007/02/28
	 * @return エラーメッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * エラータイプを取得します.
	 * 
	 * @create 2007/02/28
	 * @return エラータイプ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GErrorType getType() {
		return type;
	}

	/**
	 * エラーコードを設定します.
	 * 
	 * @create 2007/02/28
	 * @param code エラーコード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setCode(final String code) {
		this.code = code;
	}

	/**
	 * エラーメッセージを設定します.
	 * 
	 * @create 2007/02/28
	 * @param message エラーメッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * エラータイプを設定します.
	 * 
	 * @create 2007/02/28
	 * @param type エラータイプ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setType(final GErrorType type) {
		this.type = type;
	}

	/**
	 * 文字列表現を返します.
	 * エラーコード、エラーメッセージ、エラータイプをパイプ"|"区切りで連結し、出力しています。
	 * 
	 * @see java.lang.Object#toString()
	 * @create 2007/03/04
	 * @return 文字列表現
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public String toString() {
		return getCode() + "|" + getType() + "|" + getMessage();
	}
}
