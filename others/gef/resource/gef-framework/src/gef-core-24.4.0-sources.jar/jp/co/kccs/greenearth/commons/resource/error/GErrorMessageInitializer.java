/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.error;

import jp.co.kccs.greenearth.commons.listener.GFrameworkListener;
import jp.co.kccs.greenearth.commons.resource.GResourceManager;

// もし必要な場合、GErrorMessageManagerだけの初期化では不十分で、GErrorMessagesの初期化も必要です。
public class GErrorMessageInitializer implements GFrameworkListener {

	@Override
	public void frameworkDestroyed() {
		GResourceManager<GErrorMessage> manager = GErrorMessages.getResourceManager();
		manager.destroy();
	}

	@Override
	public void frameworkInitialized() {
		GResourceManager<GErrorMessage> manager = GErrorMessages.getResourceManager();
		manager.init();
	}

}
