/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.error;

import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.resource.GAbstractResourceManager;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.resource.GResourceDao;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * エラーメッセージリソースのアクセス管理を行います.<br><br>
 * 
 * <b>【キャッシュキー】</b><br>
 * キャッシュ方式の指定するプロパティキーは<code>"geframe.commons.ErrorMessage.Cache"</code>になります。<br>
 * [指定方法]
 * <pre>
 *    geframe.commons.ErrorMessage.Cache=init
 * </pre>
 * 
 * <b>【バインド変数の取り扱い】</b><br>
 * エラーメッセージには、メッセージ情報に対しバインド変数（実行時置換変数）を定義することができます。<br>
 * バインド変数は、バインド変数のインデックスを中括弧<code>"{}"</code>で囲んだ文字列で表されます。<br>
 * <br>
 * 利用例<br>
 * エラーメッセージ定義=<code>'{0}'項目には、{1}を入力してください。</code><br>
 * <pre>
 *  Locale locale = new Locale( "ja", "JP" );
 *  GErrorMessage error = GErrorMessages.getErrorMessage( "SAMPLE-00001", locale, new String[]{ "電話番号", "11桁の数値" } );
 *  System.out.println( error.getMessge() );
 * </pre>
 * 出力結果:<code>'電話番号'項目には、11桁の数値を入力してください。</code>
 * ※バインド変数に設定できるパラメータは文字列型のみとなります。<br><br>
 * 
 * <b>【DAOクラスの指定】</b><br>
 * {@link GErrorMessageManager}がデータソースアクセスに利用する{@link GResourceDao}は
 * {@link GErrorMessageManager}がDIコンテナより生成される際のセッターインジェクションとして指定します。<br>
 * [指定例(Spring Frameworkの場合)]
 * <pre>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.error.GErrorMessageManager" class="jp.co.kccs.greenearth.commons.resource.error.GErrorMessageManagerImpl" singleton="true">
 *    &lt;constructor-arg>
 *       &lt;ref bean="jp.co.kccs.greenearth.commons.resource.error.GErrorMessageDao"/>
 *    &lt;/constructor-arg>
 * &lt;/bean>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.error.GErrorMessageDao" class="jp.co.kccs.greenearth.framework.dao.resource.GJk2ErrorMessageDao" singleton="true"/>
 * </pre>
 * 
 * @see jp.co.kccs.greenearth.commons.resource.error.GErrorMessage
 * @see jp.co.kccs.greenearth.commons.resource.error.GErrorMessages
 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager
 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao
 * @create 2007/03/02
 * @author kitamura
 * @since 3.0.0
 */
public class GErrorMessageManager extends GAbstractResourceManager<GErrorMessage> {

	/** キャッシュプロパティキー. */
	public static final String MESSAGE_CACHE = "geframe.commons.ErrorMessage.Cache";

	/**
	 * {@link GErrorMessageManager}インスタンスを初期化します.
	 * 
	 * @create 2007/03/04
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GErrorMessageManager() {
	}

	/**
	 * リソースアクセス用DAOを指定して、{@link GErrorMessageManager}インスタンスを初期化します.
	 * 
	 * @see GErrorMessageDao
	 * @create 2007/03/04
	 * @param dao リソースアクセス用DAO
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GErrorMessageManager(final GResourceDao<GErrorMessage> dao) throws GResourceAccessException {
		super(dao);
	}

	/**
	 * ロケール名に対するリソースの検索順序に基づき、 指定したキーとロケールに該当するリソースを取得します.
	 * 対応する値が存在しない場合はnullを返します。 
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GAbstractResourceManager#getResource(java.lang.String, java.util.Locale)
	 * @create 2007/11/16
	 * @param key キー
	 * @param locale ロケール
	 * @return エラーメッセージ
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author kitamura
	 * @since 3.2.1
	 */
	@Override
	public GErrorMessage getResource(final String key, final Locale locale) throws GResourceAccessException {
		GErrorMessage message = super.getResource(key, locale);
		if (message != null) {
			message = message.createPracticalInstance();
		}
		return message;
	}

	/**
	 * 指定されたリソースにバインドパラメータをバインドします.
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GAbstractResourceManager#bindParameter(T, Object[])
	 * @create 2007/03/28
	 * @param source リソース
	 * @param params バインドパラメータ
	 * @return バインド済みリソース
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	protected GErrorMessage bindParameter(final GErrorMessage source, final Object[] params) {
		String message = GStringUtils.bindParameter(source.getMessage(), (String[]) params);
		source.setMessage(message);
		return source;
	}

	/**
	 * キャッシュ方式を指定するプロパティキー名を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GAbstractResourceManager#getCachePropertyKey()
	 * @create 2007/03/28
	 * @return プロパティキー名
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	protected String getCachePropertyKey() {
		return MESSAGE_CACHE;
	}
	
	@Override
	protected Map<Locale, Map<String, GErrorMessage>> getCache() {
		return super.getCache();
	}
}
