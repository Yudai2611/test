/*
 * Copyright 2007-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.error;

import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.GResourceManager;

/**
 * エラーメッセージリソースを取得するためのインターフェースを提供します.<br>
 * エラーコードとロケールを指定すると、エラーメッセージリソースの情報が取得できます。<br>
 * ◆利用例
 * <pre>
 *    Locale locale = new Locale( "ja", "JP" );
 *    GErrorMessage error = GErrorMessages.getErrorMessage( "GEF-0000001", locale );
 * </pre>
 * 
 * <b>【バインド変数の利用】</b><br>
 * エラーメッセージには、バインド変数（実行時置換変数）を定義することができます。<br>
 * バインド変数は、エラーメッセージ定義時にエラーメッセージに埋め込んでおくことで、
 * エラーメッセージ取得時に、任意の文字列で置換されます。<br>
 * 利用例<br>
 * エラーメッセージ定義=<code>'{0}'項目には、{1}を入力してください。</code><br>
 * <pre>
 *   Locale locale = new Locale( "ja", "JP" );
 *   GErrorMessage error = GErrorMessages.getErrorMessage( "SAMPLE-00001", locale, new String[]{ "電話番号", "11桁の数値" } );
 *   System.out.println( error.getMessge() );
 * </pre>
 * 出力結果:<code>'電話番号'項目には、11桁の数値を入力してください。</code><br><br>
 * 
 * <b>【リソースへアクセス方法の切り替え】</b><br>
 * エラーメッセージ取得の仕組みは、取得したリソースを管理するManager層と実際にリソースアクセスを行うDAO層とに別れます。<br>
 * ◆Manager層<br>
 * 　{@link GErrorMessages}では、{@link GResourceManager}を利用して取得したリソースの管理を行っています。<br>
 * 　{@link GResourceManager}では、一度取得したリソース情報のキャッシュやロケール単位での管理を行います。<br>
 * 
 * ◆DAO層<br>
 * 　{@link GErrorMessages}では、{@link GResourceDao}を利用してリソースアクセスを行っています。
 * 　{@link GResourceDao}では、ファイルやDBといった、リソースにアクセスし、情報を取得します。<br>
 * <br>
 * 
 * Manager層、DAO層の実装は、DIコンテナによって管理されているため、その処理内容を変更することができます。<br>
 * [{@link GResourceManager}、{@link GResourceDao}の指定]
 * <pre>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.error.ErrorMessageManager" class="jp.co.kccs.greenearth.commons.resource.error.GErrorMessageManager" singleton="true">
 *    &lt;constructor-arg>
 *       &lt;ref bean="jp.co.kccs.greenearth.commons.resource.error.ErrorMessageDao"/>
 *    &lt;/constructor-arg>
 * &lt;/bean>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.error.ErrorMessageDao" class="jp.co.kccs.greenearth.framework.dao.resource.GJk2ErrorMessageDao" singleton="true"/>
 * </pre>
 * @see jp.co.kccs.greenearth.commons.resource.error.GErrorMessage
 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager
 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao
 * @create 2007/03/02
 * @author kitamura
 * @since 3.0.0
 */
public final class GErrorMessages {

	/** リソースマネージャDIキー. */
	static final String MANAGER_DI_KEY = GErrorMessages.class.getPackage().getName() + ".ErrorMessageManager";

	/** 利用する{@link GErrorMessageManager}. */
	private static GResourceManager<GErrorMessage> resourceManager = null;

	/**
	 * {@link GErrorMessages}インスタンスを初期化します.
	 * 
	 * @create 2007/03/02
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GErrorMessages() {
	}
	
	/**
	 * フィールドが空のエラーメッセージを取得します.
	 * リソースへのアクセスは行いません。
	 * 
	 * @create 2009/06/03
	 * @return エラーメッセージ
	 * @author okajima
	 * @since 3.6.0
	 */
	public static GErrorMessage createErrorMessage() {
		return new GErrorMessage();
	}

	/**
	 * 指定したコードとシステムロケール情報に該当するエラーメッセージを取得します.
	 * 
	 * @create 2007/03/02
	 * @param code エラーコード
	 * @return エラーメッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GErrorMessage getErrorMessage(final String code) {
		return getResourceManager().getResource(code);
	}

	/**
	 * 指定したコードと指定したロケールに該当するエラーメッセージを取得します.
	 * 
	 * @create 2007/03/02
	 * @param code エラーコード
	 * @param locale ロケール
	 * @return エラーメッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GErrorMessage getErrorMessage(final String code, final Locale locale) {
		return getResourceManager().getResource(code, locale);
	}

	/**
	 * 指定したエラーコードとシステムロケールに該当したエラーメッセージのバインド変数に、
	 * 指定したパラメータをバインドした結果を取得します.
	 * 
	 * @create 2007/03/04
	 * @param code エラーコード
	 * @param params バインドパラメータ
	 * @return エラーメッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GErrorMessage getErrorMessage(final String code, final String[] params) {
		return getResourceManager().getResource(code, params);
	}

	/**
	 * 指定したエラーコードとロケールに該当したエラーメッセージのバインド変数に、
	 * 指定したパラメータをバインドした結果を取得します.
	 * 
	 * @create 2007/03/04
	 * @param code エラーコード
	 * @param params バインドパラメータ
	 * @param locale ロケール
	 * @return エラーメッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GErrorMessage getErrorMessage(final String code, final String[] params, final Locale locale) {
		return getResourceManager().getResource(code, params, locale);
	}

	/**
	 * 全てのエラーメッセージを取得します.
	 * 
	 * @return 全エラーメッセージ
	 * @author KCCS N.Nishimura
	 * @create 2014/06/21
	 * @since 3.16.0
	 */
	public static Map<Locale, Map<String, GErrorMessage>> getAllErrorMessages(){
		return getResourceManager().getAllResources();
	}

	// ---- プロテクテッドメソッド -----------------------------------------------

	/**
	 * リソースマネージャーを取得します.
	 * 
	 * @create 2007/03/09
	 * @return リソースマネージャー
	 * @author aono
	 * @since 3.0.0
	 */
	protected static GResourceManager<GErrorMessage> getResourceManager() {
		if (resourceManager == null) {
			resourceManager = GFrameworkUtils.getComponent(MANAGER_DI_KEY);
		}
		return resourceManager;
	}

	/**
	 * リソースマネージャーを設定します.
	 * 
	 * @create 2007/03/09
	 * @param resourceManager リソースマネージャー
	 * @deprecated  内部処理制御用のため使用しないでください。
	 * @author aono
	 * @since 3.0.0
	 */
	@Deprecated
	protected static void setResourceManager(final GResourceManager<GErrorMessage> resourceManager) {
		GErrorMessages.resourceManager = resourceManager;
	}

}
