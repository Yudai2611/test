/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.error;


/**
 * エラータイプを定義します.
 * 
 * @create 2007/03/04
 * @author kitamura
 * @since 3.0.0
 */
public enum GErrorType {
	
	/** デフォルト。 */ // TODO これは何？
	DEFAULT("default"),
	
	/** インフォメーション. */
	INFO("info"),
	/** 警告. */
	WARNING("warning"),
	/** エラー. */
	ERROR("error");

	/** 表示名. */
	private String name = null;

	/**
	 * コンストラクタ.<br>
	 * 
	 * @create 2007/03/27
	 * @param name 表示名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	GErrorType(final String name) {
		this.name = name;
	}

	/**
	 * String型のエラータイプをGErrorType型に変換します.<br>
	 * 
	 * @create 2007/03/27
	 * @param errorType	エラータイプの文字列
	 * @return エラータイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static GErrorType convert(final String errorType) {
		for (GErrorType type : GErrorType.values()) {
			if (type.name.equals(errorType)) {
				return type;
			}
		}
		return DEFAULT;
	}

	/**
	 * 文字列表現を返します.<br>
	 * 
	 * @create 2007/03/27
	 * @return 表示名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public String toString() {
		return name;
	}
}
