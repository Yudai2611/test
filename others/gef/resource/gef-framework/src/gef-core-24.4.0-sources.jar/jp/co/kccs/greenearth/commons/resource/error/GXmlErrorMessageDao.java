/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.error;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Stack;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.resource.GResourceDao;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * xmlファイルを読み込んでエラーメッセージリソースを取得するクラスです。<br>
 * エラーメッセージリソースは、ロケール毎に異なるxmlファイルに定義します。<br>
 * <br>
 * プロパティファイル内にインポート記号（<code>@import.File</code>）と数字を使用して追加ファイルが指定されている場合、指定された追加ファイルのメッセージリソースも取得可能です。<br>
 * また、追加ファイルの中に更に追加ファイルの指定があった場合、更に指定された追加ファイルに定義されているメッセージリソースも読み込まれます。<br>
 * ファイルの読み込みには深さ優先探索が用いられます。<br>
 *
 * @author KCCS N.Nishimura
 * @create 2013/08/08
 * @since 3.12.0
 */
public class GXmlErrorMessageDao implements GResourceDao<GErrorMessage> {

	/** データソースファイル拡張子. */
	private static final String RESOURCE_EXTENSION = ".xml";
	/** XMLスキーマ定義ファイル. */
	private static final String XSD_RESOURCE_PATH = "jp/co/kccs/greenearth/commons/resource/error/error-message.xsd";
	/** ロケールの一覧. */
	protected List<Locale> localeList = null;
	/** エラーメッセージファイル名のパス(拡張子以外) */
	private String xmlFileNamePath = null;
	
	/** ビルドパス上のファイルパス */
	protected String _filePath = null;

	/**
	 * {@link GXmlErrorMessageDao}を初期化します。<br>
	 * 指定されたxmlファイルパスから、全てのロケールパターンを読み込み、ロケールの一覧を作成します。
	 *
	 * @param filePath デフォルトロケールのxmlファイルのパス（拡張子を含む）
	 * @throws GResourceAccessException 指定されたファイルの読み込みに失敗した場合
	 * @author KCCS N.Nishimura
	 * @since 2013/08/12
	 */
	public GXmlErrorMessageDao(String filePath) throws GResourceAccessException{
		if (filePath == null) {
			throw new GResourceAccessException("Errors Resource file is Null.");
		}
		xmlFileNamePath = GFileUtils.excludeExtension(filePath);
		if (!filePath.endsWith(RESOURCE_EXTENSION.toLowerCase())) {
			throw new GResourceAccessException("File extension is not '.xml'. : " + filePath);
		}
		_filePath = filePath;
	}

	/**
	 * 全てのエラーメッセージを取得します。
	 * リソースとして定義されている全てのエラーメッセージをマップとして取得します。
	 * 結果データのエラーメッセージ格納状態は次の通りです。<br>
	 * <code>Map&lt;Locale locale,Map&lt;String code,GErrorMessage message>></code><br>
	 *
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao#findResourceAll()
	 * @return 全エラーメッセージマップ
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author KCCS N.Nishimura
	 * @since 2013/08/08
	 */
	@Override
	public Map<Locale, Map<String, GErrorMessage>> findResourceAll() throws GResourceAccessException {
		Map<Locale, Map<String, GErrorMessage>> allErrors = new HashMap<Locale, Map<String, GErrorMessage>>();
		for (Locale locale : getLocaleList()) {
			// ロケール毎にメッセージのリストを取得
			Map<String, GErrorMessage> errorMap = findErrorMap(null, locale);
			if(errorMap.size()>0){
				allErrors.put(locale, errorMap);
			}
		}
		return allErrors;
	}

	/**
	 * 指定したエラーコードとロケールに該当するエラーメッセージを検索します.
	 *
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao#findResource(java.lang.String, java.util.Locale)
	 * @param errorCode エラーコード
	 * @param locale ロケール
	 * @return エラーメッセージ
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author KCCS N.Nishimura
	 * @create 2013/08/08
	 * @since 3.12.0
	 */
	@Override
	public GErrorMessage findResource(String errorCode, Locale locale) throws GResourceAccessException {
		// インプットチェック
		if (errorCode == null) {
			throw new NullPointerException("errorcode is null.");
		}
		if (errorCode.length() == 0) {
			return null;
		}
		Map<String, GErrorMessage> errorMap = findErrorMap(errorCode, locale);
		if(errorMap != null){
			return errorMap.get(errorCode);
		}
		return null;
	}

	/**
	 * ファイル名に含まれるロケールを抽出します。<br>
	 *
	 * @param fileName ファイル名
	 * @return ロケール
	 * @author KCCS N.Nishimura
	 * @create 2013/08/01
	 * @since 3.12.0
	 */
	protected Locale extractLocaleString(String fileName) {
		String name = fileName;
		int exIndex = name.lastIndexOf(RESOURCE_EXTENSION);
		name = name.substring(0, exIndex);
		String locale = "";
		while (true) {
			int underscore = name.lastIndexOf("_");
			if (underscore < 0) {
				break;
			}
			locale = name.substring(underscore) + locale;
			name = name.substring(0, underscore);
		}
		if (!"".equals(locale)) {
			locale = locale.substring(1);
		}
		return GLocaleUtils.getLocale(locale);
	}

	/**
	 * エラーコード、ロケールを指定してエラーメッセージを検索します。
	 * エラーコードにnullを指定した場合、全メッセージを検索します。
	 *
	 * @param errorCode エラーコード
	 * @param locale ロケール
	 * @return エラーメッセージリスト
	 * @author KCCS N.Nishimura
	 * @create 2013/08/08
	 * @since 3.12.0
	 */
	private Map<String, GErrorMessage> findErrorMap(String errorCode, Locale locale) {
		// 指定したロケールによって、読み込むxmlファイルのパスを変更する
		String filePath = null;
		if(!DEFAULT_LOCALE.equals(locale) && !getLocaleList().contains(locale)){
			return null;
		}

		if (locale == null || DEFAULT_LOCALE.equals(locale)) {
			filePath = xmlFileNamePath + RESOURCE_EXTENSION;
		} else {
			filePath = xmlFileNamePath + "_" + locale + RESOURCE_EXTENSION;
		}
		ErrorMessageFileParseHandler handler = new ErrorMessageFileParseHandler();
		try {
			List<GErrorMessage> errorList = handler.lookup(filePath, errorCode);
			Map<String, GErrorMessage> errorMap = new HashMap<String, GErrorMessage>();
			for (GErrorMessage error : errorList) {
				// リストの中身をMapに詰める
				errorMap.put(error.getCode(), error);
			}
			return errorMap;
		}catch(SAXException e){
			throw new GResourceAccessException(e);
		 }
	}

	/**
	 * エラーメッセージを格納する、ロケールのリストを取得します。<br>
	 *
	 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao#getLocaleList()
	 * @return ロケールのリスト
	 * @author KCCS N.Nishimura
	 * @create 2013/08/08
	 * @since 3.12.0
	 */
	@Override
	public List<Locale> getLocaleList() {
		if (localeList == null) {
			localeList = GFileUtils.listLocaleFrom(_filePath);
		}
		return localeList;
	}

	/**
	 * エラーメッセージ用のSaxのイベントハンドラです。
	 * xmlファイルを解析して、{@link GErrorMessage}を作成します。
	 *
	 * @author KCCS N.Nishimura
	 * @create 2013/08/08
	 * @since 3.12.0
	 */
	public class ErrorMessageFileParseHandler extends DefaultHandler {

		/** 抽出結果. */
		public List<GErrorMessage> errors = new ArrayList<GErrorMessage>();

		/** importファイル内から抽出されたエラー. */
		public List<GErrorMessage> tmpImportErrors = new ArrayList<GErrorMessage>();

		/** 現在解析中のエラーメッセージ. */
		GErrorMessage current = null;

		/** 現在のタグを格納するスタック. */
		Stack<String> tagStack = new Stack<String>();

		/** 解析中のエラーコード */
		private String currentErrorCode = null;

		/**
		 * エラーコードを指定して、xmlファイルからエラーメッセージを取得します。<br>
		 * エラーコードにnullを指定すると、xmlファイル内の全てのエラーメッセージを取得します。<br>
		 *
		 * @param filePath 解析するxmlファイルパス
		 * @param errorCode エラーコード
		 * @return エラーメッセージのリスト
		 * @throws SAXException xmlファイルの解析に失敗した場合
		 * @author KCCS N.Nishimura
		 * @create 2013/08/12
		 * @since 3.12.0
		 */
		public List<GErrorMessage> lookup(String filePath, String errorCode) throws SAXException {
			currentErrorCode = errorCode;
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setNamespaceAware(true);
			factory.setValidating(true);
			try {
				URI fileUri = GFileUtils.getResource(filePath).toURI();
				URL parserUrl = GFileUtils.getResource(XSD_RESOURCE_PATH, getClass().getClassLoader());
				try (InputStream fileStream = fileUri.toURL().openStream(); InputStream parserStream = parserUrl.openStream()) {
					SAXParser parser = factory.newSAXParser();
					parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
					parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", parserStream);
					parser.parse(fileStream, this);
				} catch(ParserConfigurationException | IOException e){
					throw new GResourceAccessException(e);
				}
			} catch (URISyntaxException e){
				throw new GResourceAccessException(e);
			}
			return errors;
		}

		/**
		 * 要素の開始通知を受け取ります。<br>
		 * エラーコードの設定、インポートファイルの読み込みを行います。<br>
		 *
		 * @see org.xml.sax.helpers.DefaultHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
		 * @param uri URI
		 * @param localName タグのローカル名
		 * @param qName タグ名
		 * @param attributes タグの属性
		 * @throws SAXException xmlの解析に失敗した場合
		 * @author KCCS N.Nishimura
		 * @create 2013/08/12
		 * @since 3.12.0
		 */
		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException  {
			if ("error".equals(qName)) {
				if (currentErrorCode == null || currentErrorCode.equals(attributes.getValue("code"))) {
					current = new GErrorMessage();
					current.setCode(attributes.getValue("code"));
				}
			} else if ("import".equals(qName)) {
				String fileNamePath = attributes.getValue("resource");
				List<GErrorMessage> importErrors = new ErrorMessageFileParseHandler().lookup(fileNamePath,currentErrorCode);
				if (currentErrorCode == null) {
					tmpImportErrors.addAll(importErrors);
				} else if(importErrors.size()>0){
					GErrorMessage message = importErrors.get(importErrors.size()-1);
					if (message != null) {
						tmpImportErrors.add(message);
					}
				}
			}
			tagStack.push(qName);
		}

		/**
		 * 要素内の文字データの通知を受け取ります。<br>
		 * エラータイプ、エラーメッセージを取得します。<br>
		 *
		 * @see org.xml.sax.helpers.DefaultHandler#characters(char[], int, int)
		 * @param ch タグの内容
		 * @param start 開始位置
		 * @param length 内容の長さ
		 * @throws SAXException xmlの解析に失敗した場合
		 * @author KCCS N.Nishimura
		 * @create 2013/08/12
		 * @since 3.12.0
		 */
		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			if (current!=null) {
				String text = new String(ch, start, length).trim();
				if ("type".equals(tagStack.peek())) {
					current.setType(GErrorType.convert(text));
				} else if ("message".equals(tagStack.peek())) {
					current.setMessage(GStringUtils.nullToBlank(current.getMessage()) + GStringUtils.nullToBlank(text));
				}
			}
		}

		/**
		 * 要素内の終了通知を受け取ります。<br>
		 * 「解析中」のメッセージをクリアします。<br>
		 *  インポートしたエラーメッセージを追加します。<br>
		 * @see org.xml.sax.helpers.DefaultHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
		 * @param uri URI
		 * @param localName タグのローカル名
		 * @param qName タグ名
		 * @throws SAXException xmlの解析に失敗した場合
		 * @author KCCS N.Nishimura
		 * @create 2013/08/12
		 * @since 3.12.0
		 */
		@Override
		public void endElement(String uri, String localName, String qName) throws SAXException {
			if ("error".equals(qName)) {
				if (current !=null) {
					errors.add(current);
					current = null;
				}
			}else if("error-messages".equals(qName)){
				//重複の場合、インポートが後勝ちになるように、リストの後ろに追加
				errors.addAll(tmpImportErrors);
			}
			tagStack.pop();
		}
	}
}
