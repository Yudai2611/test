/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * エラーメッセージリソースに関連するパッケージです。
 */
package jp.co.kccs.greenearth.commons.resource.error;

