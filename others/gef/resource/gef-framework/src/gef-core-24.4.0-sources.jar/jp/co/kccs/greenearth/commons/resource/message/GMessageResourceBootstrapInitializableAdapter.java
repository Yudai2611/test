/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.resource.message;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;
import jp.co.kccs.greenearth.commons.listener.BootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializableAdapter;
import jp.co.kccs.greenearth.commons.priority.GPriority;

/**
 * {@link GMessageResourceInitializer}を{@link GBootstrapInitializable}にアダプトします.<br/>
 *
 * @create 2023/10/25
 * @author Dhiaz Chebastian
 * @since 23.10.0
 */
@BootstrapInitializable()
@Priority(GPriority.NORMAL)
public class GMessageResourceBootstrapInitializableAdapter extends GBootstrapInitializableAdapter {
    public GMessageResourceBootstrapInitializableAdapter() {
        super(new GMessageResourceInitializer());
    }
    public GMessageResourceBootstrapInitializableAdapter(GBootstrapConfiguration bootstrapConfiguration) {
        super(bootstrapConfiguration, new GMessageResourceInitializer());
    }
}
