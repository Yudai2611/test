/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.message;

import jp.co.kccs.greenearth.commons.listener.GFrameworkListener;
import jp.co.kccs.greenearth.commons.resource.GResourceManager;

// もし、必要とする場合は、managerのみの初期化と破棄では不十分で、GMessageResourcesに保持させているインスタンスの処理も必要です。
public class GMessageResourceInitializer implements GFrameworkListener {

	@Override
	public void frameworkDestroyed() {
		GResourceManager<String> manager = GMessageResources.getResourceManager();
		manager.destroy();
	}

	@Override
	public void frameworkInitialized() {
		GResourceManager<String> manager = GMessageResources.getResourceManager();
		manager.init();
	}

}
