/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.message;

import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.resource.GAbstractResourceManager;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.resource.GResourceDao;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * メッセージリソースのアクセス管理を行います.<br><br>
 * 
 * <b>【キャッシュキー】</b><br>
 * キャッシュ方式の指定するプロパティキーは<code>"geframe.commons.MessageResource.Cache"</code>になります。<br>
 * [指定方法]
 * <pre>
 *    geframe.commons.MessageResource.Cache=init
 * </pre>
 * 
 * <b>【バインド変数の取り扱い】</b><br>
 * メッセージリソースには、メッセージ情報に対しバインド変数（実行時置換変数）を定義することができます。<br>
 * バインド変数は、バインド変数のインデックスを中括弧<code>"{}"</code>で囲んだ文字列で表されます。<br>
 * <br>
 * 利用例<br>
 * メッセージリソース定義=<code>'{0}'項目には、{1}を入力してください。</code><br>
 * <pre>
 *  Locale locale = new Locale( "ja", "JP" );
 *  String message = GMessageResources.getMessage( "SAMPLE-00001", locale, new String[]{ "電話番号", "11桁の数値" } );
 *  System.out.println( message );
 * </pre>
 * 出力結果:<code>'電話番号'項目には、11桁の数値を入力してください。</code>
 * ※バインド変数に設定できるパラメータは文字列型のみとなります。<br><br>
 * 
 * <b>【DAOクラスの指定】</b><br>
 * {@link GMessageResourceManager}がデータソースアクセスに利用する{@link GResourceDao}は
 * {@link GMessageResourceManager}がDIコンテナより生成される際のセッターインジェクションとして指定します。<br>
 * [指定例(Spring Frameworkの場合)]
 * <pre>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.message.MessageResourceManager" class="jp.co.kccs.greenearth.commons.resource.message.GMessageResourceManager" singleton="true">
 *    &lt;constructor-arg>
 *       &lt;ref bean="jp.co.kccs.greenearth.commons.resource.message.MessageResourceDao"/>
 *    &lt;/constructor-arg>
 * &lt;/bean>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.message.MessageResourceDao" class="jp.co.kccs.greenearth.framework.dao.resource.GJk2MessageResourceDao" singleton="true"/>
 * </pre>
 * 
 * @see jp.co.kccs.greenearth.commons.resource.message.GMessageResources
 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager
 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao
 * @create 2007/02/21
 * @author aono
 * @since 3.0.0
 */
public class GMessageResourceManager extends GAbstractResourceManager<String> {

	/** キャッシュプロパティキー. */
	public static final String PROPERTY_MESSAGE_RESOURCE_CACHE = "geframe.commons.MessageResource.Cache";

	/**
	 * {@link GMessageResourceManager}インスタンスを初期化します.
	 * 
	 * @create 2007/02/26
	 * @author aono
	 * @since 3.0.0
	 */
	public GMessageResourceManager() {
	}

	/**
	 * リソースアクセス用DAOを指定して、{@link GMessageResourceManager}インスタンスを初期化します.
	 * 
	 * @create 2007/02/26
	 * @param dao リソース取得用DAO
	 * @throws GResourceAccessException リソースアクセスに失敗した場合
	 * @author aono
	 * @since 3.0.0
	 */
	public GMessageResourceManager(GResourceDao<String> dao) throws GResourceAccessException {
		super(dao);
	}

	/**
	 * 指定されたリソースにバインドパラメータをバインドします.
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GAbstractResourceManager#bindParameter(T, Object[])
	 * @create 2007/03/28
	 * @param source リソース
	 * @param params バインドパラメータ
	 * @return バインド済みリソース
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	protected String bindParameter(String source, Object[] params) {
		return GStringUtils.bindParameter(source, (String[]) params);
	}

	/**
	 * キャッシュ方式を指定するプロパティキー名を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.commons.resource.GAbstractResourceManager#getCachePropertyKey()
	 * @create 2007/03/28
	 * @return プロパティキー名
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	protected String getCachePropertyKey() {
		return PROPERTY_MESSAGE_RESOURCE_CACHE;
	}
	
	@Override
	protected Map<Locale, Map<String, String>> getCache() {
		return super.getCache();
	}
}