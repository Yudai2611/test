/*
 * Copyright 2007-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.message;

import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.resource.GResourceManager;

/**
 * メッセージリソースを取得するためのインターフェースを提供します.<br><br>
 * 
 * ◆利用例
 * <pre>
 *    Locale locale = new Locale( "ja", "JP" );
 *    String message = GMessageResources.getMessage( "0000001", locale );
 * </pre>
 * 
 * <b>【バインド変数の利用】</b><br>
 * メッセージリソースには、バインド変数（実行時置換変数）を定義することができます。<br>
 * バインド変数は、メッセージリソース定義時に定義情報内に埋め込んでおくことで、
 * メッセージリソース取得時に、任意の文字列で置換されます。<br>
 * 利用例<br>
 * メッセージリソース定義=<code>'{0}'項目には、{1}を入力してください。</code><br>
 * <pre>
 *   Locale locale = new Locale( "ja", "JP" );
 *   String message = GMessageResources.getMessage( "SAMPLE-00001", locale, new String[]{ "電話番号", "11桁の数値" } );
 *   System.out.println( message );
 * </pre>
 * 出力結果:<code>'電話番号'項目には、11桁の数値を入力してください。</code><br><br>
 * 
 * <b>【リソースへアクセス方法の切り替え】</b><br>
 * エラーメッセージ取得の仕組みは、取得したリソースを管理するManager層と実際にリソースアクセスを行うDAO層との別れます。<br>
 * ◆Manager層<br>
 * 　{@link GMessageResources}では、{@link GResourceManager}を利用して取得したリソースの管理を行っています。<br>
 * 　{@link GResourceManager}では、一度取得したリソース情報のキャッシュやロケール単位での管理を行います。<br>
 * 
 * ◆DAO層<br>
 * 　{@link GMessageResources}では、{@link GResourceDao}を利用してリソースアクセスを行っています。
 * 　{@link GResourceDao}では、ファイルやDBといった、リソースにアクセスし、情報を取得します。<br>
 * <br>
 * 
 * Manager層、DAO層の実装は、DIコンテナによって管理されているため、その処理内容を変更することができます。<br>
 * [{@link GResourceManager}、{@link GResourceDao}の指定]
 * <pre>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.message.MessageResourceManager" class="jp.co.kccs.greenearth.commons.resource.message.GMessageResourceManager" singleton="true">
 *    &lt;constructor-arg>
 *       &lt;ref bean="jp.co.kccs.greenearth.commons.resource.message.MessageResourceDao"/>
 *    &lt;/constructor-arg>
 * &lt;/bean>
 * &lt;bean name="jp.co.kccs.greenearth.commons.resource.message.MessageResourceDao" class="jp.co.kccs.greenearth.framework.dao.resource.GJk2MessageResourceDao" singleton="true"/>
 * </pre>
 * 
 * @see jp.co.kccs.greenearth.commons.resource.GResourceManager
 * @see jp.co.kccs.greenearth.commons.resource.GResourceDao
 * @create 2007/02/23
 * @author aono
 * @since 3.0.0
 */
public final class GMessageResources {

	/** リソースマネージャDIキー. */
	private static final String RESOURCE_MANAGER_DI_KEY = GMessageResources.class.getPackage().getName() + ".MessageResourceManager";

	/** {@link GMessageResourceManager}の実装クラスのインスタンス. */
	private static GResourceManager<String> resourceManager = null;
	/**
	 * {@link GMessageResources}インスタンスを初期化します.
	 * 
	 * @create 2007/02/23
	 * @author aono
	 * @since 3.0.0
	 */
	private GMessageResources() {
	}

	// ---- パブリックメソッド -----------------------------------------------
	/**
	 * 文字列リソースを取得します.<br>
	 * 実装で定義された既定のロケールを使用して、文字列リソースを取得します。<br>
	 * 
	 * @create 2007/02/21
	 * @param id リソースID
	 * @return 文字列リソース
	 * @author aono
	 * @throws GResourceAccessException  リソースのアクセス中に例外が発生
	 * @since 3.0.0
	 */
	public static String getMessage(String id) throws GResourceAccessException {
		return getResourceManager().getResource(id);
	}

	/**
	 * 文字列リソースを取得します.
	 * 
	 * @create 2007/02/21
	 * @param id リソースID
	 * @param locale ロケール名
	 * @return 文字列リソース
	 * @author aono
	 * @throws GResourceAccessException  リソースのアクセス中に例外が発生
	 * @since 3.0.0
	 */
	public static String getMessage(String id, Locale locale) throws GResourceAccessException {
		return getResourceManager().getResource(id, locale);
	}

	/**
	 * 文字列リソースを取得します.<br>
	 * [1]パラメータを使用して加工した、文字列リソースを取得します。<br>
	 * 　加工方法は実装で定義します。<br>
	 * 　例：文字列リソース(フォーマット定義)に、パラメータの値を適用して取得する。<br>
	 * [2]実装で定義された既定のロケールを使用して、文字列リソースを取得します。
	 * 
	 * @create 2007/02/21
	 * @param id リソースID
	 * @param params パラメータ
	 * @return 文字列リソース
	 * @author aono
	 * @throws GResourceAccessException  リソースのアクセス中に例外が発生
	 * @since 3.0.0
	 */
	public static String getMessage(String id, String[] params) throws GResourceAccessException {
		return getResourceManager().getResource(id, params);
	}

	/**
	 * 文字列リソースを取得します.<br>
	 * [1]パラメータを使用して加工した、文字列リソースを取得します。<br>
	 * 　加工方法は実装で定義します。<br>
	 * 　例：文字列リソース(フォーマット定義)に、パラメータの値を適用して取得する。<br>
	 * [2]実装で定義された既定のロケールを使用して、文字列リソースを取得します。<br>
	 * 
	 * @create 2007/02/21
	 * @param id リソースID
	 * @param params パラメータ
	 * @param locale ロケール名
	 * @return 文字列リソース
	 * @author aono
	 * @throws GResourceAccessException  リソースのアクセス中に例外が発生
	 * @since 3.0.0
	 */
	public static String getMessage(String id, String[] params, Locale locale) throws GResourceAccessException {
		return getResourceManager().getResource(id, params, locale);
	}

	/**
	 * 全てのメッセージを取得します.
	 * 
	 * @return 全メッセージ
	 * @author KCCS N.Nishimura
	 * @create 2014/06/21
	 * @since 3.16.0
	 */
	public static Map<Locale, Map<String, String>> getAllMessages(){
		return getResourceManager().getAllResources();
	}
	// ---- プロテクテッドメソッド -----------------------------------------------
	/**
	 * メッセージリソースマネージャーを取得します.
	 * 
	 * @create 2007/03/01
	 * @return メッセージリソースマネージャー
	 * @author aono
	 * @since 3.0.0
	 */
	protected static GResourceManager<String> getResourceManager() {
		if(resourceManager == null) {
			resourceManager = GFrameworkUtils.getComponent(RESOURCE_MANAGER_DI_KEY);
		}
		return resourceManager;
	}

	/**
	 * メッセージリソースマネージャーを設定します.
	 * 
	 * @create 2007/03/01
	 * @param manager メッセージリソースマネージャー
	 * @deprecated  内部処理制御用のため使用しないでください。
	 * @author aono
	 * @since 3.0.0
	 */
	protected static void setResourceManager(GResourceManager<String> manager) {
		resourceManager = manager;
	}
}
