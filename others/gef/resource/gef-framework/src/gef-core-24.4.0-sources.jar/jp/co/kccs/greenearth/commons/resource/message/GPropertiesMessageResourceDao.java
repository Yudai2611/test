/*
 * Copyright 2013-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.resource.message;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.resource.GResourceDao;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;

/**
 * プロパティファイルを読み込んでメッセージリソースを取得するクラスです。<br>
 * メッセージリソースは、ロケール毎に異なるプロパティファイルに定義します。<br>
 * <br>
 * プロパティファイル内にインポート記号（<code>@import.File</code>）と数字を使用して追加ファイルが指定されている場合、指定された追加ファイルのメッセージリソースも取得可能です。<br>
 * 同じファイル内に複数のインポートが指定されている場合、読み込み順はインポート記号の後に続く数字の昇順となります。<br>
 * また、追加ファイルの中に更に追加ファイルの指定があった場合、更に指定された追加ファイルに定義されているメッセージリソースも読み込まれます。<br>
 * ファイルの読み込みには深さ優先探索が用いられます。<br>
 * <br>
 * @author KCCS K.Fujita
 * @create 2013/07/31
 * @since 3.12.0
 */
public class GPropertiesMessageResourceDao implements GResourceDao<String> {

	/* Private Constants. */
	/** プロパティファイルの拡張子 */
	private static final String RESOURCE_EXTENSION = ".properties";
	/** 追加ファイル読み込みを表すキー */
	private static final String IMPORT_FILE_KEY = "@import.File";

	/** ロケールの一覧 */
	protected List<Locale> localeList = null;
	/** プロパティファイルを解析する際のエンコード方式 */
	protected String encoding = null;

	/** プロパティファイルのパス（ロケールに依存しない部分のみ、拡張子は含まない） */
	protected String propertyFilePath = null;
	
	/** ビルドパス上のファイルパス */
	protected String _filePath = null;

	/**
	 * {@link GPropertiesMessageResourceDao}を初期化します。<br>
	 * 指定されたプロパティファイルの全てのロケールのパターンを読み込み、ロケールの一覧を作成します。<br>
	 * <br>
	 * @param defaultPropertyFilePath デフォルトロケールのプロパティファイルのパス（拡張子を含む）
	 * @throws GResourceAccessException 指定されたファイルの読み込みに失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/31
	 * @since 3.12.0
	 */
	public GPropertiesMessageResourceDao(String filePath) throws GResourceAccessException {
		if (filePath == null) {
			throw new GResourceAccessException("Message Resource file is Null. ");
		}
		this.propertyFilePath = GFileUtils.excludeExtension(filePath);
		if (!"properties".equals(GFileUtils.getExtension(filePath).toLowerCase())) {
			throw new GResourceAccessException("File extension is not '.properties'. : " + filePath);
		}
		_filePath = filePath;
	}

	/**
	 * 全てのロケールの全てのメッセージリソースが格納されたマップを取得します。<br>
	 * <br>
	 * @see GResourceDao#findResourceAll()
	 * @return 全てのロケールの全てのメッセージリソースが格納されたマップ（キー：ロケール、値：リソースIDをキーとしメッセージを値とするマップ）
	 * @throws GResourceAccessException ファイルが存在しないなどの理由でファイルが読み込めない場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/31
	 * @since 3.12.0
	 */
	@Override
	public Map<Locale, Map<String, String>> findResourceAll() throws GResourceAccessException {
		Map<Locale, Map<String, String>> messages = new HashMap<Locale, Map<String, String>>();
		for (Locale locale : this.getLocaleList()) {
			Properties properties = this.createProperties(locale);
			for (Entry<Object, Object> entry : properties.entrySet()) {
				final String id = (String) entry.getKey();
				final String message = (String) entry.getValue();
				if (id.startsWith(IMPORT_FILE_KEY)) {
					// キーがインポート記号で始まっている場合はリソースIDとして扱わない
					continue;
				}
				if (!messages.containsKey(locale)) {
					messages.put(locale, new HashMap<String, String>());
				}
				messages.get(locale).put(id, message);
			}
		}
		return messages;
	}

	/**
	 * 指定されたリソースIDとロケールからメッセージリソースを取得します。<br>
	 * 該当するメッセージリソースが存在しない場合はnullを返します。<br>
	 * <br>
	 * @see GResourceDao#findResource(String, Locale)
	 * @param id リソースID
	 * @param locale ロケール
	 * @return メッセージリソース
	 * @throws GResourceAccessException ファイルが存在しないなどの理由でファイルが読み込めない場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/31
	 * @since 3.12.0
	 */
	@Override
	public String findResource(final String id, final Locale locale) throws GResourceAccessException {
		if (getLocaleList().contains(locale)) {
			return this.createProperties(locale).getProperty(id);
		}
		return null;
	}

	/**
	 * ロケールの一覧を取得します。<br>
	 * ロケール一覧の作成は、コンストラクタ引数で指定されたパスを使用して、インスタンス生成時に以下のルールに従って行われます。<br>
	 * <ul>
	 * <li>条件に合致するファイルの探索
	 * <ul>
	 * <li>ファイル名がコンストラクタ引数で指定された名前で始まり、拡張子が'properties'であるファイルを探索します。
	 * <li>ロケール一覧を作成するための探索は、コンストラクタ引数で指定されたディレクトリに対してのみ行われます。
	 * </ul>
	 * <li>ファイル名からのロケールの収集
	 * <ul>
	 * <li>ファイル名に含まれる国コードや言語コードから、そのファイルがどのロケールのリソースかを判定します。
	 * <li>ファイル名がコンストラクタ引数で指定された名前と拡張子のみから成る場合、デフォルトロケールのリソースとして扱われます。
	 * </ul>
	 * <br>
	 * 例えば、コンストラクタ引数が"message/MessageResource.properties"の場合、"message"ディレクトリに含まれる"MessageResource"から始まるファイルを検索します。<br>
	 * MessageResource.properties ⇒ デフォルトロケールのリソースとして扱われます。<br>
	 * MessageResource_ja.properties ⇒ 日本語リソースとして扱われます。<br>
	 * <br>
	 * @see GResourceDao#getLocaleList()
	 * @return ロケールの一覧
	 * @author KCCS K.Fujita
	 * @create 2013/07/31
	 * @since 3.12.0
	 */
	@Override
	public List<Locale> getLocaleList() {
		if (localeList == null) {
			localeList = GFileUtils.listLocaleFrom(_filePath);
		}
		return localeList;
	}

	/**
	 * 指定れたロケールのプロパティファイルを読み込みます。<br>
	 * <br>
	 * @param locale 読み込むプロパティファイルのロケール
	 * @return 指定されたロケールの{@link Properties}インスタンス
	 * @throws GResourceAccessException ファイルが存在しないなどの理由でファイルが読み込めない場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/31
	 * @since 3.12.0
	 */
	protected Properties createProperties(final Locale locale) throws GResourceAccessException {
		Properties properties = new Properties();

		// 指定されたロケールのプロパティファイルのパスを取得
		String filePath = null;
		if (GResourceDao.DEFAULT_LOCALE.equals(locale)) {
			filePath = new StringBuilder(this.propertyFilePath).append(RESOURCE_EXTENSION).toString();
		} else {
			filePath = new StringBuilder(this.propertyFilePath).append("_").append(locale).append(RESOURCE_EXTENSION).toString();
		}

		// 各ファイルに定義されたメッセージリソースを読み込む
		loadProperties(properties, GFileUtils.createURL(filePath));
		return properties;
	}

	/**
	 * 指定されたURLのファイルからプロパティーリスト（キーと要素の組み合わせ）を読み込みます。<br>
	 * ファイル読み込みの際のエンコード方式には{@link GPropertiesMessageResourceDao#encoding}の値が使用されます。<br>
	 * 指定されたファイル内に追加ファイルのパスが指定されている場合、追加ファイルからもプロパティーリストを読み込みます。<br>
	 * <br>
	 * @param properties 読み込まれたプロパティリストが設定される{@link Properties}のインスタンス
	 * @param url プロパティリストの読み込み元となるプロパティファイルのURL
	 * @throws GResourceAccessException 指定されたファイルが存在しない等の理由でファイルが読み込めない場合
	 * @author KCCS K.Fujita
	 * @create 2013/08/08
	 * @since 3.12.0
	 */
	protected void loadProperties(Properties properties, final URL url) throws GResourceAccessException {
		InputStream stream = null;
		try {
			// 指定されたファイルの読み込み
			stream = url.openStream();
			properties.load(new InputStreamReader(stream, Charset.forName(this.getEncoding())));
			// 追加ファイルの読み込み
			this.loadImportProperties(properties);
			List<String> deleteTargets = new ArrayList<String>();
			// インポート記号から始まるキーの取得
			for (Object key : properties.keySet()) {
				String keyStr = (String) key;
				if (keyStr.startsWith(IMPORT_FILE_KEY)) {
					deleteTargets.add(keyStr);
				}
			}
			// インポート記号から始まるキーをプロパティーから削除
			for (String target :deleteTargets) {
				properties.remove(target);
			}
		} catch (IOException e) {
			throw new GResourceAccessException("Failed to load file. ", e);
		} finally {
			if (stream != null) {
				try {
					stream.close();
				} catch (IOException e) {
					throw new GResourceAccessException("Failed to close stream. ", e);
				}
			}
		}
	}

	/**
	 * 追加のプロパティファイルを読み込みます。<br>
	 * <br>
	 * @param properties 追加で読み込まれたプロパティリストが設定される{@link Properties}のインスタンス
	 * @throws GResourceAccessException ファイルが存在しないなどの理由でファイルが読み込めない場合
	 * @author KCCS K.Fujita
	 * @create 2013/08/08
	 * @since 3.12.0
	 */
	protected void loadImportProperties(Properties properties) throws GResourceAccessException {
		List<String> importKeys = new ArrayList<String>();

		for (String key : properties.stringPropertyNames()) {
			if (!key.startsWith(IMPORT_FILE_KEY)) {
				continue;
			}
			importKeys.add(key);
		}
		// "importKeys"を昇順にソート
		Collections.sort(importKeys, new Comparator<String>() {
			@Override
			public int compare(String val1, String val2) {
				int num1 = Integer.parseInt(val1.replace(IMPORT_FILE_KEY, ""));
				int num2 = Integer.parseInt(val2.replace(IMPORT_FILE_KEY, ""));
				return num1 - num2;
			}
		});

		Properties branchProperties = new Properties();
		for (String importKey : importKeys) {
			String importFilePath = properties.getProperty(importKey);

			Properties leafProperties = new Properties();
			loadProperties(leafProperties, GFileUtils.createURL(importFilePath));
			branchProperties.putAll(leafProperties);
		}
		properties.putAll(branchProperties);
	}

	/**
	 * ファイル名に含まれるロケールを抽出します。<br>
	 * <br>
	 * @param fileName ファイル名
	 * @return ロケール
	 * @author KCCS K.Fujita
	 * @create 2013/08/01
	 * @since 3.12.0
	 */
	protected Locale extractLocaleString(final String fileName) {
		String name = fileName;
		int exIndex = name.lastIndexOf(RESOURCE_EXTENSION);
		name = name.substring(0, exIndex);
		String locale = "";
		while (true) {
			int underscore = name.lastIndexOf("_");
			if (underscore < 0) {
				break;
			}
			locale = name.substring(underscore) + locale;
			name = name.substring(0, underscore);
		}
		if (!"".equals(locale)) {
			locale = locale.substring(1);
		}
		return GLocaleUtils.getLocale(locale);
	}

	/**
	 * プロパティファイルのエンコーディング方式を取得します。<br>
	 * <br>
	 * @return プロパティファイルのエンコーディング方式
	 * @author KCCS K.Fujita
	 * @create 2013/08/01
	 * @since 3.12.0
	 */
	public String getEncoding() {
		return encoding;
	}

	/**
	 * プロパティファイルのエンコーディング方式を設定します。<br>
	 * <br>
	 * @param encoding プロパティファイルのエンコーディング方式
	 * @author KCCS K.Fujita
	 * @create 2013/08/01
	 * @since 3.12.0
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

}
