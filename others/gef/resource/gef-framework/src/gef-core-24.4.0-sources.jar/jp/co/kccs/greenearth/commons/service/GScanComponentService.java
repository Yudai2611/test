/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.service;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * コンポーネントスキャンを実行します.<br/>
 * {@link ScanConfiguration}アノテーションを具象クラスに宣言し、スキャン条件を記述します。<br/>
 * 
 * <pre>
 *  exsample of definition.
 * {@code
 *     @ScanConfiguration( // スキャン条件を書く
 *	     isPublic = true, // アクセス修飾子はpublicであること
 *	     scannedAnnotations = PriorityConfigurator.class,  // PriorityConfiguratorアノテーションが宣言されていること
 *	     scannedAssignableTypes = GPriorityConfigurator.class  // GPriorityConfiguratorインタフェースの実装クラスであること
 *     )
 *     <code>@</code>NoArgsConstructor
 *     public class GPriorityRegistryImpl implements GPriorityRegistry {
 *     ...
 *     }
 *
 *  exsample of run a scanning.
 * {@code
 *     List<GPriorityConfigurator> configurators = GScanComponentService.getInstance().getScannedInstances(this.getClass());
 * }
 * </pre>
 * 
 * @see ScanConfiguration
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GScanComponentService {

	static final String GEFRAME_CORE_SERVICE_SCAN_PACKAGES = "geframe.core.service.scanPackages";
	
	/**
	 * 指定したクラスの{@link ScanConfiguration}を基にスキャンを実行し、スキャン済みクラスのリストを返却します.<br/>
	 * ※スキャン済みクラスのリストは、キャッシュします。<br/>
	 * 
	 * @create 2023/10/25
	 * @param clazz スキャン対象クラス
	 * @return スキャン結果のクラス一覧
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<Class<?>> getScannedClasses(Class<?> clazz);
	
	/**
	 * 指定したクラスの{@link ScanConfiguration}を基にスキャンを実行し、スキャン済みクラスのインスタンス化されたリストを返却します.<br/>
	 * インスタンス化は、DI({@link GFrameworkUtils#getComponent(Class)})経由を優先し、
	 * 次に、デフォルトコンストラクタを使用したインスタンス化を試みます.<br/>
	 * ※デフォルトコンストラクタでインスタンス化した場合、ライフサイクルは管理しません。都度、新しいインスタンスを生成します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param clazz スキャン対象クラス
	 * @return スキャン結果のインスタンスリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> List<T> getScannedInstances(Class<?> clazz);
	
	/**
	 * スキャン対象のパッケージ一覧を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return スキャン対象のパッケージ一覧
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<String> getScanPackages();
	
	/**
	 * リソースを解放します.<r/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void release();
	
	/**
	 * {@link GScanComponentService}インスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GScanComponentService}インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GScanComponentService getInstance() {
		return GFrameworkUtils.getComponent(GScanComponentService.class.getName());
	}

}
