/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.service;

import java.lang.annotation.Annotation;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.ScannedGenericBeanDefinition;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.core.type.filter.AssignableTypeFilter;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkProperties;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.priority.GPrioritySorter;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * {@link GScanComponentService}の実装クラスです.<br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GScanComponentServiceImpl implements GScanComponentService {

	private List<String> basePackages;
	private Map<Class<?>, List<Class<?>>> scanClasses = new ConcurrentHashMap<>();

	private static final String $s_IS_REQUIRED = "%s is required.";

	public GScanComponentServiceImpl(List<String> basePackages) {
		this.basePackages = basePackages;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<Class<?>> getScannedClasses(Class<?> clazz) {
		if (scanClasses.containsKey(clazz)) {
			return scanClasses.get(clazz);
		}
		return GPrioritySorter.sortByClass(create(clazz));
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> List<T> getScannedInstances(Class<?> clazz) {
		List<Class<?>> classes = getScannedClasses(clazz);
		List<T> instances = new ArrayList<>();
		for(Class<?> c: classes) {
			Optional<T> obj = GObjectInstantiator.getInstance().newInstance(c);
			obj.ifPresent(instances::add);
		}
		return GPrioritySorter.sortByInstance(instances);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<String> getScanPackages() {
		List<String> scanPackages = new ArrayList<>();
		scanPackages.addAll(this.basePackages);
		scanPackages.addAll(Arrays.asList(GFrameworkProperties.getProperty(GScanComponentService.GEFRAME_CORE_SERVICE_SCAN_PACKAGES, "").trim().split(",")));
		return scanPackages;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void release() {
		scanClasses.clear();
	}

	protected List<Class<?>> create(Class<?> clazz) {
		List<Class<?>> list = scanComponents(clazz);
		if (!list.isEmpty()) {
			scanClasses.put(clazz, list);
		}
		return list;
	}

	protected List<Class<?>> scanComponents(Class<?> clazz) {
		ScanConfiguration scanConfiguration = getRawClass(clazz).getAnnotation(ScanConfiguration.class);
		Objects.requireNonNull(scanConfiguration, isRequired(ScanConfiguration.class.getSimpleName()));
		List<Class<? extends Annotation>> annotations = Arrays.asList(scanConfiguration.scannedAnnotations());
		List<Class<?>> assignableTypes = Arrays.asList(scanConfiguration.scannedAssignableTypes());
		if (annotations.size() == 0 && assignableTypes.size() == 0) {
			throw new GFrameworkException("No scan target specified.");
		}
		ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
		annotations.forEach(annotation -> {
			scanner.addIncludeFilter(new AnnotationTypeFilter(annotation));
		});
		assignableTypes.forEach(assignableType -> {
			scanner.addIncludeFilter(new AssignableTypeFilter(assignableType));
		});
		Map<Class<?>, Class<?>> components = new ConcurrentHashMap<>();
		List<String> scanPackages = buildScanPackages(scanConfiguration);
		scanPackages.stream().filter(GStringUtils::isNotEmpty).forEach(scanPackage -> {
			scanner.findCandidateComponents(scanPackage.trim()).stream().map(ScannedGenericBeanDefinition.class::cast)
				.map(BeanDefinition::getBeanClassName).forEach(className -> {
					Optional<Class<?>> classOptional = GReflectionHelper.classForName(className);
					if (classOptional.isEmpty()) {
						return;
					}
					Class<?> c = classOptional.get();
					if (components.containsKey(c)) {	// 重複は除去
						return;
					}
					if (assignableTypes.size() != 0 && !isAssignableFrom(assignableTypes, c)) {
						return;
					}
					if (annotations.size() != 0 && !hasAnnotation(annotations, c)) {
						return;
					}
					if (!isSupportedModifiers(c, scanConfiguration)) {
						return;
					}
					components.put(c, c);

				});
		});
		return new ArrayList<>(components.keySet());
	}
	boolean hasAnnotation(List<Class<? extends Annotation>> annotations, Class<?> clazz) {
		for (Class<? extends Annotation> annotation : annotations) {
			if (clazz.isAnnotationPresent(annotation)) {
				return true;
			}
		}
		return false;
	}
	boolean isAssignableFrom(List<Class<?>> assignableTypes, Class<?> clazz) {
		for (Class<?> type : assignableTypes) {
			if (type.isAssignableFrom(clazz)) {
				return true;
			}
		}
		return false;
	}

	List<String> buildScanPackages(ScanConfiguration scanConfiguration) {
		List<String> scanPackages = new ArrayList<>();
		scanPackages.addAll(getScanPackages());
		scanPackages.addAll(Arrays.asList(scanConfiguration.scanPackages()));
		return scanPackages
			.stream()
			.filter(GStringUtils::isNotEmpty)
			.collect(Collectors.toList());
	}

	boolean isSupportedModifiers(Class<?> clazz, ScanConfiguration annotation) {
		jp.co.kccs.greenearth.commons.service.Modifier[] modifiers = annotation.modifiers();
		for (jp.co.kccs.greenearth.commons.service.Modifier modifier: modifiers) {
			List<Predicate<Integer>> predicates = new ArrayList<>();
			predicates.add(m -> modifier.isPublic() ? Modifier.isPublic(m) : !Modifier.isPublic(m));
			predicates.add(m -> modifier.isProtected() ? Modifier.isProtected(m) : !Modifier.isProtected(m));
			predicates.add(m -> modifier.isPrivate() ? Modifier.isPrivate(m) : !Modifier.isPrivate(m));
			predicates.add(m -> modifier.isInterface() ? Modifier.isInterface(m) : !Modifier.isInterface(m));
			predicates.add(m -> modifier.isAbstract() ? Modifier.isAbstract(m) : !Modifier.isAbstract(m));
			predicates.add(m -> modifier.isStatic() ? Modifier.isStatic(m) : !Modifier.isStatic(m));
			predicates.add(m -> modifier.isFinal() ? Modifier.isFinal(m) : !Modifier.isFinal(m));
			predicates.add(m -> modifier.isNative() ? Modifier.isNative(m) : !Modifier.isNative(m));
			//		predicates.add(m -> annotation.isStrict() ? Modifier.isStrict(m) : !Modifier.isStrict(m));
			predicates.add(m -> modifier.isSynchronized() ? Modifier.isSynchronized(m) : !Modifier.isSynchronized(m));
			if (isModifiers(clazz, predicates)) {
				return true;
			}
		}
		return false;
	}

	private boolean isModifiers(Class<?> clazz, List<Predicate<Integer>> predicates) {
		boolean is = true;
		for (Predicate<Integer> predicate : predicates) {
			if (predicate.test(clazz.getModifiers())) {
				continue;
			}
			is = false;
			break;
		}
		return is;
	}

	List<String> getBasePackages() {
		Objects.requireNonNull(basePackages, "scan packages is not specified.");
		return basePackages;
	}

	private static Class<?> getRawClass(Type type) {
		if (type == null) return null;
		if (type instanceof GenericArrayType) {
			Type componentType = ((GenericArrayType) type).getGenericComponentType();
			if (!(componentType instanceof ParameterizedType) && !(componentType instanceof Class)) {
				// type variable is not supported
				return null;
			}
			Class<?> rawComponentClass = getRawClass(componentType);
			String forNameName = "[L" + rawComponentClass.getName() + ";";
			try {
				return Class.forName(forNameName);
			} catch (Throwable th) {
				// ignore, but return null
				return null;
			}
		}
		if (type instanceof Class) {
			return (Class<?>) type;
		}
		if (type instanceof ParameterizedType) {
			Type rawType = ((ParameterizedType) type).getRawType();
			if (rawType instanceof Class) {
				return (Class<?>) rawType;
			}
		}
		return null;
	}

	private String isRequired(Object arg) {
		return String.format($s_IS_REQUIRED, arg);
	}
}

