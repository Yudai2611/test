/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.service;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link GScanComponentService}を利用する場合のモディファイアスキャン条件を指定します.<br/>
 * 例物は{@link ScanConfiguration}にあります。<br/>
 *
 * 条件として、複数を定義するのは可能です。複数で定義される場合、統一条件じゃなく、単一条件になります。<br/>
 * 例えば、下記のような条件があります。<br/>
 * <pre>
 * example.
 * {@code
 * 		modifiers={
 * 			@Modifier(isPublic=true),
 * 			@Modifier(isStatic=true, isPrivate=true)
 * 		}
 * }
 * </pre>
 * その条件は下記のような条件に実行されます。<br/>
 * (isPublic=true) OR (isStatic=true AND isPrivate=true). <br/>
 *
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Modifier {
	boolean isPublic() default false;
	boolean isProtected() default false;
	boolean isPrivate() default false;
	boolean isInterface() default false;
	boolean isAbstract() default false;
	boolean isStatic() default false;
	boolean isFinal() default false;
	//	boolean isStrict() default false;	TODO java標準が適切に機能していないため公開停止
	boolean isNative() default false;
	boolean isSynchronized() default false;
}
