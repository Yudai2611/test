/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.service;

import java.lang.annotation.*;

/**
 * {@link GScanComponentService}を利用する場合のスキャン条件を指定します.<br/>
 * 
 * <pre>
 * example.
 * {@code
 *      //public修飾子のResourceクラスをスキャンする
 *      @ScanConfiguration(
 *      	modifiers = {
 * 				@Modifier(
 * 					isPublic=true
 * 				)
 *      	},
 *      	scannedAnnotations = Resource.class
 *      )
 *      public class GEndpointResourceRegistryImpl extends GAbstractBootstrapInitializable implements GEndpointResourceRegistry {
 *      ...
 *      }
 * </pre>
 * 
 * @see GScanComponentService
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ScanConfiguration {
	String[] scanPackages() default "";
	Class<? extends Annotation>[] scannedAnnotations() default {};
	Class<?>[] scannedAssignableTypes() default {};
	Modifier[] modifiers() default {};
}
