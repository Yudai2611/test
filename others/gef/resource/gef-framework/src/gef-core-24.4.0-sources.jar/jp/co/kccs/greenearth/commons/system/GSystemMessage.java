/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.system;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

import jp.co.kccs.greenearth.commons.GFrameworkProperties;

/**
 * ﾘｿｰｽﾊﾞﾝﾄﾞﾙでｼｽﾃﾑﾒｯｾｰｼﾞを取得するｸﾗｽです。
 * 
 * @create 2013/02/06
 * @author Hirofumi Nozaki
 * @since 1.0.0
 */
public class GSystemMessage {

	/** ﾃﾞﾌｫﾙﾄﾛｹｰﾙ */
	private static final Locale DEFAULT_LOCALE = new Locale("");

	/** 基底名 */
	private static final String BASE_NAME = GFrameworkProperties.getProperty("geframe.commons.SystemMessage.File");

	/**
	 * ﾒｯｾｰｼﾞIDに対応するﾒｯｾｰｼﾞを取得します。
	 * 
	 * @param messageId ﾒｯｾｰｼﾞID
	 * @return ﾒｯｾｰｼﾞ
	 */
	public static String getMessage(String messageId) {
		try {
			ResourceBundle resource = ResourceBundle.getBundle(BASE_NAME, DEFAULT_LOCALE);
			return resource.getString(messageId);
		} catch (Exception e) {
			return String.format("missing message for key %s.", messageId);
		}
	}

	/**
	 * ﾒｯｾｰｼﾞIDに対応するﾒｯｾｰｼﾞを取得し、ﾊﾟﾗﾒｰﾀを埋め込んで返します。
	 * 
	 * @param messageId ﾒｯｾｰｼﾞID
	 * @param params 埋め込みﾊﾟﾗﾒｰﾀ
	 * @return ﾒｯｾｰｼﾞ
	 */
	public static String getMessage(String key, Object... params) {
		return bindParameter(getMessage(key), params);
	}

	/**
	 * ｿｰｽ文字列にﾊﾟﾗﾒｰﾀをﾊﾞｲﾝﾄﾞします。
	 * 
	 * @param source ｿｰｽ文字列
	 * @param params ﾊﾟﾗﾒｰﾀ
	 * @return ﾊﾞｲﾝﾄﾞした文字列
	 */
	private static String bindParameter(final String source, final Object... params) {
		return source == null ? null : MessageFormat.format(source, params);
	}
}
