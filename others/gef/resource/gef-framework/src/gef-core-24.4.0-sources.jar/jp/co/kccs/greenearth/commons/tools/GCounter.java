/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.tools;

/**
 * カウンターの機能を提供します.
 *
 * @create 2006/12/30
 * @author nishiduka
 * @since 3.0.0
 */
public class GCounter {

	/** カウンタ. */
	private int count = 0;

	/**
	 * {@link GCounter}インスタンスを初期化します.
	 *
	 * @create 2006/12/30
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public GCounter() {
	}

	/**
	 * カウントダウンします.
	 *
	 * @create 2006/12/30
	 * @return カウント
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public synchronized int countDown() {
		return --count;
	}

	/**
	 * カウントアップします.
	 *
	 * @create 2006/12/30
	 * @return カウント
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public synchronized int countUp() {
		return ++count;
	}

	/**
	 * 現在のカウント数を戻します.
	 *
	 * @create 2006/12/30
	 * @return カウント
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public int getCount() {
		return count;
	}

	/**
	 * カウンターをリセット、0に戻します.
	 *
	 * @create 2006/12/30
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public void reset() {
		count = 0;
	}
}
