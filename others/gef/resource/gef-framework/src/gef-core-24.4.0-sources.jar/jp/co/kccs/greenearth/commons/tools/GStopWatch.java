/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.tools;

/**
 * ストップウォッチを表します.
 * 
 * @create 2005/03/30
 * @author nishiduka
 * @since 3.0.0
 */
public class GStopWatch {

	/** 終了時間. */
	private long end = -1;
	/** ラップタイム. */
	private long lap = -1;
	/** 開始時間. */
	private long start = -1;

	/**
	 * {@link GStopWatch}クラスの新しいインスタンスを初期化します.
	 * 
	 * @create 2005/03/30
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public GStopWatch() {
	}

	/**
	 * ラップタイムを取得します.
	 * 
	 * @create 2005/03/30
	 * @return ラップタイム
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public long lap() {
		final long lapStart = lap;
		lap = System.currentTimeMillis();
		return (lap - lapStart);
	}

	/**
	 * 計測を開始します.
	 * 
	 * @create 2005/03/30
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public void start() {
		start = System.currentTimeMillis();
		lap = start;
	}

	/**
	 * 計測を終了します.
	 * 
	 * @create 2005/03/30
	 * @return 終了時間
	 * @author nishiduka
	 * @since 3.0.0
	 */
	public long stop() {
		end = System.currentTimeMillis();
		return (end - start);
	}
}
