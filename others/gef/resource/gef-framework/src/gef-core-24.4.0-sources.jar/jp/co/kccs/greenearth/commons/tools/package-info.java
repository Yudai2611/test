/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
/**
 * ユーティリティのパッケージです。
 */
package jp.co.kccs.greenearth.commons.tools;

