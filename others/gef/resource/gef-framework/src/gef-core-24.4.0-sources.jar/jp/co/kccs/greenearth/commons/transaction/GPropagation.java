/*
 * Copyright 2012-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.transaction;

/**
 * トランザクション伝搬列挙。
 * 
 * @author KCCS Shigeki Shoji
 */
public enum GPropagation {

	/**
	 * REQUIRED.
	 * <br />
	 * トランザクションのコンテキストがすでに開始されていれば、そのコンテキストに参加します。<br />
	 * 開始されていない場合は開始します。<br />
	 * このトランザクションコンテキストの終了時に、新しくトランザクションを開始した場合はトランザクションを完了(commit or rollback)します。
	 */
	REQUIRED,
	
	/**
	 * REQUIRES_NEW.
	 * <br />
	 * トランザクションのコンテキストが開始されている場合は、そのトランザクションを一時停止(Suspend)し、新しいトランザクションを開始します。<br />
	 * 開始されていない場合は開始します。<br />
	 * このトランザクションコンテキストの終了時には必ず開始したトランザクションを完了(commit or rollback)し、一時停止のトランザクションがあれば再開します。
	 */
	REQUIRES_NEW,
	
	/**
	 * MANDATORY.
	 * <br />
	 * トランザクションが開始されていない場合は、例外をスローします。<br />
	 * トランザクションが開始されていれば、そのコンテキストに参加します。
	 */
	MANDATORY,

	/**
	 * NOT_SUPPORTED.
	 * <br />
	 * トランザクションが開始されていれば一時停止(Suspend)し、コンテキスト終了時に、一時停止したトランザクションを再開します。<br />
	 * トランザクションが開始されていない場合は何もしません。
	 */
	NOT_SUPPORTED
	
}
