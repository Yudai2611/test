/*
 * Copyright 2012-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.transaction;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * トランザクション宣言アノテーション。
 * 
 * @author KCCS Shigeki Shoji
 */
@Inherited
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Transactional {

	/** value.*/
	GPropagation value() default GPropagation.REQUIRED;

	/** ロールバック対象例外。*/
	Class<? extends Throwable>[] rollbackFor() default {};

	/** ロールバック対象外の例外。*/
	Class<? extends Throwable>[] noRollbackFor() default {};
	
}
