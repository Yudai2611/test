/**
 * トランザクション管理パッケージ.
 * 
 * @author KCCS Shigeki Shoji
 */
package jp.co.kccs.greenearth.commons.transaction;