/*
 * Copyright 2007-2010 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

/**
 * 真偽値に関連する操作を簡素化する機能を提供します.
 * 
 * @create 2005/09/14
 * @author kitamura
 * @since 3.0.0
 */
public final class GBooleanUtils {

	/**
	 * 指定されたビット文字列が"<code>0</code>"の場合<code>true</code>を返します.
	 * 
	 * @create 2007/03/18
	 * @param bit ビット文字列
	 * @return ビット文字列が"<code>0</code>"の場合<code>true</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static boolean isFalseBit(String bit) {
		return "0".equals(bit);
	}

	/**
	 * 数値より真偽を判定します.
	 * 指定された数値が1の場合、trueを返します。
	 * 
	 * @create 2010/02/03
	 * @param value 数値
	 * @return 真偽値{1:true / 1以外:false}
	 * @author okajima
	 * @since 3.7.0
	 */
	public static boolean isTrueBit(int value) {
		if (value == 1) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 指定されたビット文字列が"<code>1</code>"の場合<code>true</code>を返します.
	 * 
	 * @create 2007/03/18
	 * @param bit ビット文字列
	 * @return ビット文字列が"<code>1</code>"の場合<code>true</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static boolean isTrueBit(String bit) {
		return "1".equals(bit);
	}

	/**
	 * 指定された文字列を真偽値に変換します.<br>
	 * <code>"true"</code> = <code>true</code>(大文字/小文字判別なし)
	 * <code>"true"</code>以外 = <code>false</code>
	 * <code>null</code> = false
	 * 
	 * @create 2005/06/16
	 * @param bool 真偽値を表す文字列
	 * @return 真偽値
	 * @author kitamura
	 * @since 1.0.0
	 */
	public static boolean toBoolean(String bool) {
		return bool != null && Boolean.valueOf(bool).booleanValue();
	}

	/**
	 * 指定された文字列を真偽値に変換します.<br>
	 * 真偽値として認識できない文字列、または<code>null</code>の場合は、
	 * デフォルト値として指定された値が返されます。<br>
	 * 大文字/小文字の判別は行いません。
	 * 
	 * @create 2007/01/13
	 * @param bool 真偽値を表す文字列
	 * @param defaultValue デフォルト値
	 * @return 真偽値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static boolean toBoolean(String bool, boolean defaultValue) {
		if (bool != null) {
			bool = bool.toLowerCase();
			if ("true".equals(bool) || "false".equals(bool)) {
				return Boolean.valueOf(bool).booleanValue();
			}
		}
		return defaultValue;
	}
	
	/**
	 * 指定された真偽値を数値に変換します.
	 * trueの場合を1、falseの場合を0とします。
	 * 
	 * @create 2010/02/03
	 * @param bool 真偽値
	 * @return 数値{true:1 / false:0}
	 * @author okajima
	 * @since 3.7.0
	 */
	public static int toInteger(boolean bool) {
		if (bool) {
			return 1;
		} else {
			return 0;
		}
	}

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2005/09/14
	 * @author kitamura
	 * @since 1.0.0
	 */
	private GBooleanUtils() {
	}
}
