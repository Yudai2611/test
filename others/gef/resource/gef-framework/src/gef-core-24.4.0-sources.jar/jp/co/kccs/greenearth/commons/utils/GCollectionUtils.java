/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

public final class GCollectionUtils {

	private GCollectionUtils() {
	}

	public static boolean isEmpty(Collection<?> collection) {
		return collection != null ? collection.isEmpty() : true;
	}

	public static boolean isEmpty(Map<?, ?> map) {
		return map != null ? map.isEmpty() : true;
	}

	/**
	 * 配列をリストに変換します.<br/>
	 *
	 * @param <T> 任意の型
	 * @param array 配列
	 * @return 配列より変換されたリスト
	 * @author KCCS hashimoto
	 * @create 2013/03/23
	 * @since
	 */
	public static <T> List<T> toList(T... array) {
		if (array == null) {
			return new ArrayList<T>();
		}
		List<T> list = new ArrayList<T>();
		for (T e : array) {
			list.add(e);
		}
		return list;
	}

	public static <S, E extends S> List<E> cast(List<S> list) {
		if (list == null) {
			return null;
		}
		return new CastList<S, E>(list);
	}

	public static <S, E extends S> ListIterator<E> cast(ListIterator<S> itr) {
		if (itr == null) {
			return null;
		}
		return new CastListIterator<S, E>(itr);
	}


	private static class CastList<S, E extends S> implements List<E> {

		private List<S> innerList = null;

		public CastList(List<S> innerList) {
			this.innerList = innerList;
		}

		@Override
		public int size() {
			return innerList.size();
		}

		@Override
		public boolean isEmpty() {
			return innerList.isEmpty();
		}

		@Override
		public boolean contains(Object o) {
			return innerList.contains(o);
		}

		@Override
		public Iterator<E> iterator() {
			return new CastListIterator<S, E>(innerList.listIterator());
		}

		@Override
		public Object[] toArray() {
			return innerList.toArray();
		}

		@Override
		public <T> T[] toArray(T[] a) {
			return innerList.toArray(a);
		}

		@Override
		public boolean add(E e) {
			return innerList.add(e);
		}

		@Override
		public boolean remove(Object o) {
			return innerList.remove(o);
		}

		@Override
		public boolean containsAll(Collection<?> c) {
			return innerList.containsAll(c);
		}

		@Override
		public boolean addAll(Collection<? extends E> c) {
			return innerList.addAll(c);
		}

		@Override
		public boolean addAll(int index, Collection<? extends E> c) {
			return innerList.addAll(index, c);
		}

		@Override
		public boolean removeAll(Collection<?> c) {
			return innerList.removeAll(c);
		}

		@Override
		public boolean retainAll(Collection<?> c) {
			return innerList.retainAll(c);
		}

		@Override
		public void clear() {
			innerList.clear();
		}

		@SuppressWarnings("unchecked")
		@Override
		public E get(int index) {
			return (E) innerList.get(index);
		}

		@SuppressWarnings("unchecked")
		@Override
		public E set(int index, E element) {
			return (E) innerList.set(index, element);
		}

		@Override
		public void add(int index, E element) {
			innerList.add(index, element);
		}

		@SuppressWarnings("unchecked")
		@Override
		public E remove(int index) {
			return (E) innerList.remove(index);
		}

		@Override
		public int indexOf(Object o) {
			return innerList.indexOf(o);
		}

		@Override
		public int lastIndexOf(Object o) {
			return innerList.lastIndexOf(o);
		}

		@Override
		public ListIterator<E> listIterator() {
			return new CastListIterator<S, E>(innerList.listIterator());
		}

		@Override
		public ListIterator<E> listIterator(int index) {
			return new CastListIterator<S, E>(innerList.listIterator(index));
		}

		@Override
		public List<E> subList(int fromIndex, int toIndex) {
			List<S> sub = innerList.subList(fromIndex, toIndex);
			return new CastList<S, E>(sub);
		}

	}

	private static class CastListIterator<S, E extends S> implements ListIterator<E> {

		private ListIterator<S> itr = null;

		public CastListIterator(ListIterator<S> itr) {
			this.itr = itr;
		}

		@Override
		public boolean hasNext() {
			return itr.hasNext();
		}

		@SuppressWarnings("unchecked")
		@Override
		public E next() {
			return (E) itr.next();
		}

		@Override
		public boolean hasPrevious() {
			return itr.hasPrevious();
		}

		@SuppressWarnings("unchecked")
		@Override
		public E previous() {
			return (E) itr.previous();
		}

		@Override
		public int nextIndex() {
			return itr.nextIndex();
		}

		@Override
		public int previousIndex() {
			return itr.previousIndex();
		}

		@Override
		public void remove() {
			itr.remove();
		}

		@Override
		public void set(E e) {
			itr.set(e);
		}

		@Override
		public void add(E e) {
			itr.add(e);
		}

	}

}
