/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 日付に関するユーティリティクラスです.
 * 
 * @create 2007/04/07
 * @author namazue
 * @since 3.0.0
 */
public final class GDateUtils {

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2007/03/27
	 * @author okajima
	 * @since 3.0.0
	 */
	private GDateUtils() {
	}

	/**
	 * 日付を指定された書式の文字列に変換します.<br>
	 * 
	 * 日付が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * JAVA VMデフォルトのロケールを使用します。<br>
	 * 
	 * @see #formatToString(Date, String, Locale)
	 * @create 2007/03/28
	 * @param value フォーマット対象インスタンス
	 * @param format 変換書式文字列
	 * @return フォーマット付文字列
	 * @author wadatani
	 * @since 3.0.0
	 */
	public static String formatToString(final Date value, final String format) {
		return formatToString(value, format, Locale.getDefault());
	}

	/**
	 * 日付を指定された書式の文字列に変換します.<br>
	 * 
	 * 日付が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * 変換書式文字列、ロケールが<code>null</code>の場合、{@link NullPointerException}が発生します。<br>
	 * 変換書式文字列が正しくない場合、{@link IllegalArgumentException}が発生します。<br>
	 * 
	 * @create 2007/03/28
	 * @param value フォーマット対象インスタンス
	 * @param format 変換書式文字列
	 * @param locale ロケール
	 * @return フォーマット付文字列
	 * @author wadatani
	 * @since 3.0.0
	 */
	public static String formatToString(final Date value, final String format, final Locale locale) {
		if (value == null) {
			return null;
		}

		SimpleDateFormat dateFormat = (SimpleDateFormat) DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL, locale);
		dateFormat.applyPattern(format);

		return dateFormat.format(value);
	}

	/**
	 * 指定された日付文字列を、指定された書式文字列に基づいて{@link Date}型オブジェクトに変換します.<br>
	 * 
	 * 変換に失敗した場合、<code>null</code>を返します。<br>
	 * JAVA VMデフォルトのロケールを使用します。<br>
	 * 
	 * @see #toDate(String, String, Locale)
	 * @create 2007/03/28
	 * @param value 日付文字列
	 * @param format 変換書式文字列
	 * @return {@link Date}型オブジェクト
	 * @throws ParseException 指定された文字列の解析に失敗
	 * @author okajima
	 * @since 3.0.0
	 */
	public static Date toDate(final String value, final String format) throws ParseException {
		return toDate(value, format, Locale.getDefault(), false);
	}

	/**
	 * 指定された名前・指定された日付フォーマットで格納されている値を{@link Date}型に変換して返却します.<br>
	 * 日付解析を厳密行うかどうかは、指定されたパラメータを使用します。<br>
	 * 
	 * @see #toDate(String, String, Locale, boolean)
	 * @create 2007/03/08
	 * @param value 変換対象文字列
	 * @param format 日付フォーマット文字列
	 * @param lenient 日付を厳密に解析するかどうか
	 * @return 日付型
	 * @throws ParseException 指定された文字列の解析に失敗
	 * @author aono
	 * @since 3.0.0
	 */
	public static Date toDate(String value, String format, boolean lenient) throws ParseException {
		return toDate(value, format, Locale.getDefault(), lenient);
	}

	/**
	 * 指定された日付文字列を、指定された書式文字列、ロケールに基づいて{@link Date}型オブジェクトに変換します.<br>
	 * 
	 * 変換に失敗した場合、<code>null</code>を返します。<br>
	 * 変換書式文字列、ロケールが<code>null</code>の場合、{@link NullPointerException}が発生します。<br>
	 * 変換書式文字列が正しくない場合、{@link IllegalArgumentException}が発生します。<br>
	 * 
	 * @create 2007/03/27
	 * @param value 日付文字列
	 * @param format 変換書式文字列
	 * @param locale ロケール
	 * @param lenient 検証緩和フラグ
	 * @return {@link Date}型オブジェクト
	 * @throws ParseException 指定された文字列の解析に失敗
	 * @author okajima
	 * @since 3.0.0
	 */
	public static Date toDate(String value, String format, Locale locale, boolean lenient) throws ParseException {
		if (value == null || value.length() == 0) {
			return null;
		}

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format, locale);
		simpleDateFormat.setLenient(lenient);
		Date date = simpleDateFormat.parse(value);

		return date;
	}
}
