/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * エクセプションに関連する操作を簡素化する機能を提供します.
 * 
 * @create 2007/01/31
 * @author fujikawa
 * @since 3.0.0
 */
public final class GExceptionUtils {

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2007/01/31
	 * @author fujikawa
	 * @since 3.0.0
	 */
	private GExceptionUtils() {
	}

	/**
	 * 指定されたエクセプションのStackTraceを文字列に変換します. <br>
	 * 
	 * @create 2007/01/31
	 * @param e エクセプション
	 * @return 変換文字列
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static String getStringStackTrace(Throwable e) {
		String result = null;
		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			result = sw.toString();
		}
		catch (Throwable e2) {
			return result;
		}
		return result;
	}

}
