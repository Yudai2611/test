/*
 * Copyright 2007-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import org.mvel2.util.StringAppender;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * ファイル操作に関するユーティリティクラスです.
 *
 * @create 2005/09/14
 * @author kitamura
 * @since 3.0.0
 */
public final class GFileUtils {

	private static GURISchemeHandlerFactory _factory = null;

	/**
	 * Don't let anyone instantiate this class.
	 *
	 * @create 2005/09/14
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GFileUtils() {
	}

	/**
	 * 指定されたuri文字列から{@link URI}のインスタンスを生成します.<br>
	 * 生成されたインスタンスがnullの場合は、リソースが存在しないことを示す例外をスローします。<br>
	 * <br>
	 * 四つパターンの文字列を対応できる：<br>
	 * 　<パターン１＞　相対パス指定（"dir/file.txt"）<br>
	 * 　<パターン２＞　絶対パス指定（fileObj.getAbsolutePath(): "c:/dir/file.txt"）<br>
	 * 　<パターン３＞　uriObj.toString()で指定（jarUriObj.toString(): "jar:file:/c:/..."）<br>
	 * 　<パターン４＞　uriObj.getPath()で指定（jarUriObj.getPath(): "file:/c:/..."）<br>
	 * 
	 * @param uri 文字列
	 * @return 指定されたuriで表されるリソースの{@link URI}インスタンス
	 * @throws GResourceAccessException 指定されたリソースが存在しない場合
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static URI createURI(final String uri) {
		return handler(uri).createURI(uri);
	}

	/**
	 * 指定されたurl文字列から{@link URL}のインスタンスを生成します.<br>
	 * 生成されたインスタンスがnullの場合は、リソースが存在しないことを示す例外をスローします。<br>
	 * <br>
	 * 四つパターンの文字列を対応できる：<br>
	 * 　<パターン１＞　相対パス指定（"dir/file.txt"）<br>
	 * 　<パターン２＞　絶対パス指定（fileObj.getAbsolutePath(): "c:/dir/file.txt"）<br>
	 * 　<パターン３＞　urlObj.toString()で指定（jarUrlObj.toString(): "jar:file:/c:/..."）<br>
	 * 　<パターン４＞　urlObj.getPath()で指定（jarUrlObj.getPath(): "file:/c:/..."）<br>
	 *
	 * @param url 文字列
	 * @return 指定されたurlで表されるリソースの{@link URL}インスタンス
	 * @throws GResourceAccessException 指定されたリソースが存在しない場合
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static URL createURL(final String url) throws GResourceAccessException {
		try {
			return handler(url).createURI(url).toURL();
		} catch (MalformedURLException e) {
			throw new GResourceAccessException("The specified resource is not found. : " + url);
		}
	}

	/**
	 * 現在実行中のスレッドのコンテキストクラスローダより、指定された名前を持つリソースを見つけます.
	 *
	 * @create 2007/04/25
	 * @param resourceName 要求されるリソースの名前
	 * @return クラスローダ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static URL getResource(String resourceName) {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		return getResource(resourceName, classLoader);
	}

	/**
	 * 指定されたクラスローダより、指定された名前を持つリソースを見つけます.
	 *
	 * @create 2005/09/15
	 * @param resourceName 要求されるリソースの名前
	 * @param loader クラスローダ
	 * @return ファイルURL
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static URL getResource(String resourceName, ClassLoader loader) {
		if (loader == null) {
			loader = GFileUtils.class.getClassLoader();
		}
		return loader.getResource(resourceName);
	}

	/**
	 * 指定されたファイルパスより、ファイル拡張子を取得します。
	 *
	 * @create 2007/12/03
	 * @param filePath ファイル名
	 * @return 拡張子名
	 * @author matsumoto
	 * @since 3.3.0
	 */
	public static String getExtension(final String filePath) {
		return filePath == null ? null
			: filePath.lastIndexOf(".") != -1 ? filePath.substring(filePath.lastIndexOf(".") + 1) : "";
	}

	/**
	 * ファイル名から、拡張子部分を排除する.<br>
	 * 
	 * @param fileName ファイル名
	 * @return 拡張子を含まないファイル名
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static String excludeExtension(String fileName) {
		return fileName == null ? null : fileName.substring(0, fileName.lastIndexOf("."));
	}

	/**
	 * ファイルパスにより、ファイル名を取得する（拡張子部分を含まない）.<br>
	 * 
	 * @param filePath ファイルパス
	 * @return 拡張子を含まないファイル名
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static String getFileNameAndExcludeExtension(String filePath) {
		String fileName = getFileName(filePath);
		return excludeExtension(fileName);
	}

	/**
	 * ファクトリーを呼出し、指定filePathで、GURISchemeHandlerのインスタンスを取得する.<br>
	 * 
	 * @param filePath ファイルパス
	 * @return GURISchemeHandlerのインスタンス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	private static GURISchemeHandler handler(String filePath) {
		if (_factory == null) {
			_factory = GFrameworkUtils.getComponent(GURISchemeHandlerFactory.class.getName());
		}
		return _factory.getSchemeHandler(filePath);
	}

	/**
	 * ファクトリーを呼出し、指定uriで、GURISchemeHandlerのインスタンスを取得する.<br>
	 * 
	 * @param uri URIオブジェクト
	 * @return GURISchemeHandlerのインスタンス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	private static GURISchemeHandler handler(URI uri) {
		if (_factory == null) {
			_factory = GFrameworkUtils.getComponent(GURISchemeHandlerFactory.class.getName());
		}
		return _factory.getSchemeHandler(uri);
	}

	/**
	 * 指定したファイル名からロケール文字列（ファイル名Suffix）を抽出し、ロケールリストとして返却します.<br/>
	 * 
	 * また、同階層に存在する同種のファイルも全て抽出対象とします。<br/>
	 * 
	 * @param relativeFilePath ファイルパス
	 * @author yamashita
	 * @create 2020/8/5
	 * @since 20.8.0b
	 */
	public static List<Locale> listLocaleFrom(String relativeFilePath) {
		Objects.requireNonNull(relativeFilePath);
		List<Locale> localeList = new ArrayList<>();
		Pattern pattern = buildPatternInLocale(relativeFilePath);
		listFileNamesFromClosestDir(relativeFilePath).stream().distinct().filter(s -> pattern.matcher(s).find())
			.forEach(s -> {
				Locale a = extractLocale(s);
				localeList.add(a);
			});
		return localeList;
	}

	private static Pattern buildPatternInLocale(String filePath) {
		String reg = new StringBuilder()
			// ^ Matches the beginning of the line. $ Matches the end of the line.
			.append("^").append(getFileNameAndExcludeExtension(filePath)).append(".*\\.").append(getExtension(filePath))
			.append("$").toString();
		return Pattern.compile(reg);
	}

	/**
	 * 指定ファイルオブジェクトにより、localeを抽出する.<br>
	 * 
	 * @param file Fileオブジェクト
	 * @return Locale Localeオブジェクト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static Locale extractLocale(File file) {
		return extractLocale(getFileName(file));
	}

	/**
	 * 指定fileNameにより、localeを抽出する.<br>
	 * 
	 * @param fileName 文字列
	 * @return Locale Localeオブジェクト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static Locale extractLocale(String fileName) {
		String excludeExtensionFileName = excludeExtension(fileName);
		final String empty = "";
		String localeString = empty;
		while (true) {
			int index = excludeExtensionFileName.lastIndexOf("_");
			if (index < 0) {
				break;
			}
			localeString = excludeExtensionFileName.substring(index) + localeString;
			excludeExtensionFileName = excludeExtensionFileName.substring(0, index);
		}
		if (!empty.equals(localeString)) {
			localeString = localeString.substring(1);
		}
		return GLocaleUtils.getLocale(localeString);
	}

	/**
	 * 指定ファイルオブジェクトでファイル名称を取得します.<br>
	 *
	 * @param file {@link File}
	 * @return ファイル名称
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static String getFileName(File file) {
		return getFileName(file.toURI());
	}

	/**
	 * 指定URIでファイル名称を取得します.<br>
	 *
	 * @param uri {@link URI}
	 * @return ファイル名称
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static String getFileName(URI uri) {
		return getFileName(createFile(uri).toURI().toString());
	}

	/**
	 * 指定ファイルのパスでファイル名称を取得します.<br>
	 *
	 * @param filePath ファイルのパス（相対パス・絶対パスが区別せず）
	 * @return ファイル名称
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static String getFileName(String filePath) {
		return filePath.substring(filePath.lastIndexOf("/") + 1);
	}

	/**
	 * 指定ファイルのパスでディレクトリパスを取得します.<br>
	 *
	 * @param filePath ファイルのパス（相対パス・絶対パスが区別せず）
	 * @return ディレクトリパス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static String getDirectoryPath(String filePath) {
		int index = filePath.lastIndexOf("/");
		return filePath.substring(0, index == -1 ? filePath.length() : index + 1);
	}

	/**
	 * relativeFilePath（相対パスのファイル）が所属されるディレクトリ配下のファイル名リスト取得.<br>
	 * （サブディレクトリ名も含むが、サブディレクトリ配下のファイル名を含まない）<br>
	 * 
	 * relativeFilePathは、ファイルの相対パスである<br>
	 *   "entityDir/subDir/1111.entity" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 * 
	 * ※推奨しないパラメータ指定：<br>
	 * relativeFilePathは、ディレクトリの相対パスであれば、ファイルリストも取得できるが、結果は、想定と異なるかもしれない。<br>
	 *   "entityDir/subDir/" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 *   "entityDir/subDir" ==> "entityDir/*"配下のファイル名リスト取得。<br>
	 * 
	 * @param relativeFilePath ファイルの相対パス
	 * @return 所属されるディレクトリ配下のファイル名リスト取得
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static List<String> listFileNamesFromClosestDir(String relativeFilePath) {
		return handler(relativeFilePath).listFileNamesFromClosestDir(relativeFilePath);
	}

	/**
	 * relativeDirPath（相対パスのディレクトリ）に配下のファイル名リスト取得.<br>
	 * （サブディレクトリ名を含むし、サブディレクトリ配下のファイル名リストも含む）<br>
	 *
	 * relativeDirPathは、ディレクトリの相対パスである。<br>
	 *   "entityDir/subDir/" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 *   "entityDir/subDir" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 *
	 * ※サポートしないパラメータ指定：<br>
	 * relativeDirPathは、ファイルの相対パスであれば、異常発生。<br>
	 *   例え、"entityDir/subDir/1111.entity"の場合、<br>
	 *     「1111.entity」をディレクトリと見なされ、存在しないディレクトリをアクセスすると、<br>
	 *     FileNotFoundException発生。<br>
	 * 
	 * @param relativeDirPath ディレクトリの相対パス
	 * @return 配下のファイル名リスト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static List<String> listFileNamesFrom(String relativeDirPath) {
		return handler(relativeDirPath).listFileNamesFrom(relativeDirPath);
	}
	
	/**
	 * 指定URIオブジェクトの絶対パスを取得する.<br>
	 * 
	 * @param uri URIオブジェクト
	 * @return 指定URIオブジェクトの絶対パス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static String getAbsolutePath(URI uri) {
		return handler(uri).getAbsolutePath(uri);
	}
	
	/**
	 * uriStringで指定されたファイルを指定エンコーディングで読み込んで、charの配列を取得します.<br>
	 * uriStringのパターンは、{@link GFileUtils#createURI(String)}}のパラメータパターンご参照ください<br>
	 * @param uriString {@link String}
	 * @param encoding エンコーディング
	 * @return 指定ファイルの中身から取得したcharの配列
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static char[] readCharArray(String uriString, String encoding) {
		return readCharArray(createURI(uriString), encoding);
	}
	
	/**
	 * uriで指定されたファイルを指定エンコーディングで読み込んで、charの配列を取得します.<br>
	 * @param uri {@link URI}
	 * @param encoding エンコーディング
	 * @return 指定ファイルの中身から取得したcharの配列
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static char[] readCharArray(URI uri, String encoding) {
		return readCharArray(createFile(uri), encoding);
	}
	
	/**
	 * fileオブジェクトを指定エンコーディングで読み込んで、charの配列を取得します.<br>
	 * @param file {@link File}
	 * @param encoding エンコーディング
	 * @return 指定ファイルの中身から取得したcharの配列
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static char[] readCharArray(File file, String encoding) {
		try (InputStream inStream = openStream(file)) {
			StringAppender sa = new StringAppender(200, encoding);
			int read = 0;
			while ((read = inStream.read()) != -1) {
				sa.append((byte) read);
			}
			return sa.toChars();
		} catch (IOException e) {
			throw new GResourceAccessException("Exception happened when read from file : " + file.toURI().toString(), e);
		}
	}
	
	/**
	 * 指定されたuriにより、ファイルのインスタンスを生成します.<br>
	 * @param uri {@link URI}
	 * @return 指定されたuriで表されるファイルのインスタンス
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private static File createFile(URI uri) {
		return isArchived(uri) ? new GMultiSchemeFile(uri) : new File(uri);
	}
	
	/**
	 * 指定URIのリソースは、アーカイブされるかどうかを判断します.<br>
	 * @param uri URIオブジェクト
	 * @return true:アーカイブされる、false:アーカイブされない（物理ファイル）
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private static boolean isArchived(URI uri) {
		return !GURIScheme.FILE.equals(GURIScheme.convert(uri.getScheme()));
	}
	
	/**
	 * fileオブジェクトのInputStreamを取得します.<br>
	 * @param file {@link File}
	 * @return 指定されたファイルのInputStream
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private static InputStream openStream(File file) {
		try {
			return createFile(file.toURI()).toURI().toURL().openStream();
		} catch (IOException e) {
			throw new GResourceAccessException("The specified resource is not found. : " + file.toURI().toString(), e);
		}
	}
	
	/**
	 * {@link File}ファイルの拡張クラスです.<br>
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private static class GMultiSchemeFile extends File {
		private URI fileUri;
		/**
		 * GMultiSchemeFileのコンストラクターです.<br>
		 * 
		 * @create 2024/04/30
		 * @author KCSS yangfeng
		 * @since 24.4.0
		 */
		public GMultiSchemeFile(URI uri) {
			// GMultiSchemeFileは、Fileオブジェクトを作るわけではなく、凌ぎで利用します。
			// uriは、jarスキームのURIであれば、super(uri)が例外発生しますので、これを回避するため、""を渡します。
			super("file".equals(uri.getScheme()) ? uri.getPath() : "");
			fileUri = uri;
		}
		@Override
		public URI toURI() {
			return fileUri;
		}
	}
}
