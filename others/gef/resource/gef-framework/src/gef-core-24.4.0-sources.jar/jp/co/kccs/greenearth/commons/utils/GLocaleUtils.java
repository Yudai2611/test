/*
 * Copyright 2007-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ロケールに関連する操作を簡素化する機能を提供します.
 * 
 * @create 2007/03/05
 * @author fujikawa
 * @since 3.0.0
 */
public final class GLocaleUtils {

	/** ロケール表現文字列検査用正規表現（アンダースコア版）. */
	private static final Pattern UNDERSCORE_PATTERN = Pattern.compile("^([a-z]+){1}((_[A-Z]+){1}(_[a-zA-Z0-9]+)*)?$");
	/** ロケール表現文字列検査用正規表現（ハイフン版）. */
	private static final Pattern HYPHEN_PATTERN = Pattern.compile("^([a-z]+){1}((-[A-Z]+){1}(-[a-zA-Z0-9]+)*)?$");
	/** アンダースコア文字列. */
	private static final String UNDERSCORE = "_";
	/** ハイフン文字列. */
	private static final String HYPHEN = "-";

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2007/03/05
	 * @author fujikawa
	 * @since 3.0.0
	 */
	private GLocaleUtils() {
	}

	/**
	 * 指定された言語情報に対するロケールを取得します. <br>
	 * 対象の文字列から、"_"で言語・国・バリアントの文字列を解析して対応するロケールを返却します。<br>
	 * 区切り文字は"_"だけでなく、"-"にも対応しています。
	 * 
	 * @create 2007/03/05
	 * @param lang 言語情報
	 * @return ロケール
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static Locale getLocale(String lang) {
		if (lang == null) {
			return null;
		}

		if ("".equals(lang)) {
			// 指定なし
			return new Locale("");
		}

		String splitter = null;
		Matcher underscoreMatcher = UNDERSCORE_PATTERN.matcher(lang);
		if (underscoreMatcher.matches()) {
			splitter = UNDERSCORE;
		} else {
			Matcher hyphenMatcher = HYPHEN_PATTERN.matcher(lang);
			if (hyphenMatcher.matches()) {
				splitter = HYPHEN;
			} else {
				throw new IllegalArgumentException("It is not correct as the Locale format. : " + lang);
			}
		}

		String[] language = new String[3];
		String[] parselang = lang.split(splitter);
		if (parselang.length == 1) {
			// 言語情報のみ
			return new Locale(parselang[0]);
		} else if (parselang.length == 2) {
			// 言語・国情報
			return new Locale(parselang[0], parselang[1]);
		} else {
			// 言語・国・バリアント情報
			language[0] = parselang[0];
			language[1] = parselang[1];
			language[2] = parselang[2];
			for (int i = 3; i < parselang.length; i++) {
				language[2] += splitter + parselang[i];
			}
			return new Locale(language[0], language[1], language[2]);
		}
	}

	/**
	 * 引数に与えられた文字列が、ロケールの構文になっているかチェックします。<br>
	 * ロケール構文であれば、true<br>
	 * ロケール構文以外であれば、falseを返します。<br>
	 * 引数が、null or 空の場合はfalseを返します。<br>
	 * 
	 * @param localeStr ロケール文字列
	 * @return boolean チェック結果true:ロケール構文　false:ロケール構文でない
	 * @create 2010/11/05
	 * @author fujimura
	 * @since 3.9.0
	 */
	public static boolean checkLocaleSyntax(String localeStr) {
		if (localeStr == null) {
			return false;
		}

		if ("".equals(localeStr)) {
			// 指定なし
			return false;
		}

		Matcher underscoreMatcher = UNDERSCORE_PATTERN.matcher(localeStr);
		if (underscoreMatcher.matches()) {
			return true;
		} else {
			Matcher hyphenMatcher = HYPHEN_PATTERN.matcher(localeStr);
			if (hyphenMatcher.matches()) {
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * ロケール全体のプログラム上の名前を取得します.
	 * 言語、国、バリアントは指定したセパレータ（区切り文字）で区切られます。セパレータを指定しない場合、代替として下線（アンダースコア）を使用します。<br/>
	 * 言語は常に小文字で、国は常に大文字です。言語が欠落している場合は、文字列の先頭はセパレータになります。<br/>
	 * 言語フィールドと国フィールドが欠落している場合は、バリアントフィールドが指定されていても、この関数は空の文字列を返します。
	 * バリアントだけを持つロケールは作成できません。<br/>
	 * バリアントは有効な言語コードまたは国コードとともに使用する必要があります。<br/>
	 * 
	 * @param locale ロケール
	 * @param separate セパレータ（区切り文字）
	 * @return ロケール文字列
	 * @create 2011/07/24
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String toString(Locale locale, String separate) {
		if (locale == null) {
			return null;
		}
		if (GStringUtils.isEmpty(separate)) {
			separate = UNDERSCORE;
		}
		boolean l = locale.getLanguage().length() != 0;
		boolean c = locale.getCountry().length() != 0;
		boolean v = locale.getVariant().length() != 0;
		StringBuffer result = new StringBuffer(locale.getLanguage());
		if (c || (l && v)) {
			result.append(separate).append(locale.getCountry()); // 場合によっては '_'のみ付与する
		}
		if (v && (l || c)) {
			result.append(separate).append(locale.getVariant());
		}
		return result.toString();
	}
}
