/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Locale;

/**
 * 数値操作に関するユーティリティクラスです.
 * 
 * @create 2006/03/15
 * @author kitamura
 * @since 3.0.0
 */
public final class GNumberUtils {

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2006/03/15
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GNumberUtils() {
	}

	/**
	 * 値１、値２の足し算を行います.<br>
	 * <code>null</code>を指定した場合は<code>"0"</code>として扱われます。
	 * 
	 * @create 2006/03/15
	 * @param value1 値1
	 * @param value2 値2
	 * @return 計算結果
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static BigDecimal add(final BigDecimal value1, final BigDecimal value2) {
		BigDecimal bdVal1 = null;
		BigDecimal bdVal2 = null;

		if (value1 == null) {
			bdVal1 = BigDecimal.ZERO;
		}
		else {
			bdVal1 = value1;
		}

		if (value2 == null) {
			bdVal2 = BigDecimal.ZERO;
		}
		else {
			bdVal2 = value2;
		}

		return bdVal1.add(bdVal2);
	}

	/**
	 * 値1、値2の文字列を数値に変換し足し算を行います.<br>
	 * <code>null</code>、空文字を指定した場合は<code>"0"</code>として扱われます。<br>
	 * 
	 * @create 2006/03/16
	 * @param value1 値1
	 * @param value2 値2
	 * @return 計算結果
	 * @throws NumberFormatException 指定された値が数値として認識できない場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static BigDecimal add(final String value1, final String value2) throws NumberFormatException {
		BigDecimal bd1 = toBigDecimal(value1);
		BigDecimal bd2 = toBigDecimal(value2);

		return bd1.add(bd2);
	}

	/**
	 * 値1と値2の比較を行います.<br>
	 * <code>null</code>を指定した場合は<code>"0"</code>として扱われます。
	 * 
	 * @create 2006/03/16
	 * @param value1 値1
	 * @param value2 値2
	 * @return 比較結果 ( 値1&lt;値2 : -1、値1=値2 : 0、値1&gt;値2 : 1 )
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static int compare(final BigDecimal value1, final BigDecimal value2) {
		BigDecimal bdVal1 = null;
		BigDecimal bdVal2 = null;

		if (value1 == null) {
			bdVal1 = BigDecimal.ZERO;
		}
		else {
			bdVal1 = value1;
		}

		if (value2 == null) {
			bdVal2 = BigDecimal.ZERO;
		}
		else {
			bdVal2 = value2;
		}

		return bdVal1.compareTo(bdVal2);
	}

	/**
	 * 値1と値2を数値に変換し比較を行います.<br>
	 * <code>null</code>、空文字を指定した場合は<code>"0"</code>として扱われます。
	 * 
	 * @create 2006/03/16
	 * @param value1 値1
	 * @param value2 値2
	 * @return 比較結果 ( 値1&lt;値2 : -1、値1=値2 : 0、値1&gt;値2 : 1 )
	 * @throws NumberFormatException 指定された値が数値として認識できない場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static int compare(final String value1, final String value2) throws NumberFormatException {
		BigDecimal bd1 = toBigDecimal(value1);
		BigDecimal bd2 = toBigDecimal(value2);

		return bd1.compareTo(bd2);
	}

	/**
	 * 数値を指定された書式の文字列に変換します.<br>
	 * 
	 * 数値が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * JAVA VMデフォルトのロケールを使用します。<br>
	 * {@see #formatToString(Number, String, Locale)}<br>
	 * 
	 * @create 2007/03/28
	 * @param value フォーマット対象の数値
	 * @param format 書式文字列
	 * @return 変換後文字列
	 * @author wadatani
	 * @since 3.0.0
	 */
	public static String formatToString(final Number value, final String format) {
		return formatToString(value, format, Locale.getDefault());
	}

	/**
	 * 数値を指定された書式の文字列に変換します.<br>
	 * 
	 * 数値が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * 書式文字列、ロケールが<code>null</code>の場合、{@link NullPointerException}が発生します。<br>
	 * 書式文字列が正しくない場合、{@link IllegalArgumentException}が発生します。<br>
	 * 
	 * @create 2007/03/28
	 * @param value フォーマット対象の数値
	 * @param format 書式文字列
	 * @param locale ロケール
	 * @return 変換後文字列
	 * @author wadatani
	 * @since 3.0.0
	 */
	public static String formatToString(final Number value, final String format, final Locale locale) {
		if (value == null) {
			return null;
		}

		DecimalFormat formatter = (DecimalFormat) NumberFormat.getNumberInstance(locale);
		formatter.applyPattern(format);

		return formatter.format(value);
	}

	/**
	 * 指定された数値文字列を{@link BigDecimal}に変換します.<br>
	 * 変換は{@link BigDecimal}クラスのコンストラクタを利用しています。<br>
	 * <code>null</code>、空文字は<code>"0"</code>として認識されます。<br>
	 * 
	 * @create 2006/03/16
	 * @param value 文字列表現された数値
	 * @return 変換された結果
	 * @throws NumberFormatException 指定された値が数値として認識できない場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static BigDecimal toBigDecimal(final String value) throws NumberFormatException {
		BigDecimal decimal = null;
		if (value == null || value.equals("")) {
			decimal = BigDecimal.ZERO;
		}
		else {
			decimal = new BigDecimal(value);
		}
		return decimal;
	}

	/**
	 * 数値文字列を指定された書式文字列、ロケールに基づいて、{@link BigDecimal}型オブジェクトに変換します.<br>
	 * <br>
	 * 数値文字列が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * 指定された文字列に数値以外の文字列が含まれていた場合、{@link ParseException}が発生します。<br>
	 * 書式文字列、ロケールが<code>null</code>の場合、{@link NullPointerException}が発生します。<br>
	 * <br>
	 * ※注意1<br>
	 * {@link DecimalFormat#parse(String, ParsePosition)}は指定された文字列を先頭から解析します。
	 * しかし、文字列の先頭が解析不能な文字の場合、{@link ParseException}が発生します。
	 * つまり、2文字目以降で解析不能な文字列が現れても、{@link ParseException}は発生しません。<br>
	 * ※注意2<br>
	 * フォーマット書式文字列にはjavaが推奨するパターンを使用してください。
	 * 詳細はjava2 API仕様をご参照ください。<br>
	 * 不正なパターンが指定された場合、例外は発生せず不正な解析結果を返すパターンも存在します。<br>
	 * 確認済み不正パターン "##,#!##.00"
	 * 
	 * @create 2007/03/28
	 * @param value 数値文字列
	 * @param format 書式文字列
	 * @param locale ロケール
	 * @return {@link BigDecimal}型オブジェクト
	 * @throws java.text.ParseException 変換に失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	public static BigDecimal toBigDecimal(String value, String format, Locale locale) throws ParseException {
		if (value == null) {
			return null;
		}

		DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getNumberInstance(locale);
		decimalFormat.applyPattern(format);
		decimalFormat.setParseBigDecimal(true);
		ParsePosition parsePosition = new ParsePosition(0);

		BigDecimal decimal = (BigDecimal) decimalFormat.parse(value, parsePosition);

		if (decimal == null || parsePosition.getIndex() < value.length()) {
			throw new ParseException("Unparseable number: \"" + value + "\"", parsePosition.getIndex());
		}

		return decimal;
	}

	/**
	 * 指定された文字列を{@link Integer}に変換します。<br>
	 * <code>null</code>、空文字列または{@link Integer}として認識できない文字列の場合は、<br>
	 * デフォルト値として指定された値が返されます。<br>
	 * 
	 * @param value 数値文字列
	 * @param defaultValue デフォルト値
	 * @return {@link Integer}型オブジェクト
	 * @create 2014/12/17
	 * @author KCCS XieHeping
	 * @since
	 */
	public static Integer toInteger(final String value, Integer defaultValue) {
		if (value == null || value.equals("")) {
			return defaultValue;
		}
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException e) {
			return defaultValue;
		}
	}

	/**
	 * 指定された文字列を{@link Double}に変換します。<br>
	 * <code>null</code>、空文字列または{@link Double}として認識できない文字列の場合は、<br>
	 * デフォルト値として指定された値が返されます。<br>
	 * 
	 * @param value 数値文字列
	 * @param defaultValue デフォルト値
	 * @return {@link Double}型オブジェクト
	 * @create 2014/12/17
	 * @author KCCS XieHeping
	 * @since
	 */
	public static Double toDouble(final String value, Double defaultValue) {
		if (value == null || value.equals("")) {
			return defaultValue;
		}
		try {
			return Double.parseDouble(value);
		} catch (NumberFormatException e) {
			return defaultValue;
		}
	}

	//	public static BigDecimal parseStrictToBigDecimal( String value, String format, Locale locale ) throws ParseException
	//	{
	//		BigDecimal decimal = parseToBigDecimal( value, format, locale );
	//
	//		DecimalFormat decimalFormat = (DecimalFormat)NumberFormat.getNumberInstance( locale );
	//		decimalFormat.applyPattern( format );
	//		decimalFormat.setParseBigDecimal( true );
	//
	//		int result = checkGrouping( value, format, decimalFormat );
	//		if ( result != -1 )
	//		{
	//			throw new ParseException( value, result );
	//		}
	//
	//		return decimal;
	//	}

	// TODO [2007/03/31][okajima] v3.0では提供しません。
	// 値がマイナスの場合
	// 値の先頭にグループ区切り子がある場合
	// 区切り子が連続している場合

	//	/**
	//	 * 
	//	 * @create 2007/04/04
	//	 * @param value
	//	 * @param pattern
	//	 * @param decimalFormat
	//	 * @return
	//	 * @author wadatani
	//	 * @since 3.0.0
	//	 */
	//	private static int checkGrouping( String value, String pattern, DecimalFormat decimalFormat )
	//	{
	//		String target = value;
	//
	//		if ( target.equals( "" ) )
	//		{
	//			return -1;
	//		}
	//
	//		DecimalFormatSymbols formatSymbols = decimalFormat.getDecimalFormatSymbols();
	//
	//		int groupingSize = decimalFormat.getGroupingSize();
	//		char groupingSeparater = formatSymbols.getGroupingSeparator();
	//		char decimalSeparater = formatSymbols.getDecimalSeparator();
	//		char minusSign = formatSymbols.getMinusSign();
	//
	//		int errorIndex = 0;
	//
	//		if ( target.indexOf( minusSign ) == 0 )
	//		{
	//			target = target.substring( 1 );
	//			errorIndex++;
	//		}
	//
	//		if ( target.indexOf( groupingSeparater ) == 0 )
	//		{
	//			return errorIndex;
	//		}
	//
	//		String integerValue;
	//		int decimalIndex = target.indexOf( decimalSeparater );
	//
	//		if ( decimalIndex == -1 )
	//		{
	//			integerValue = target;
	//		}
	//		else if ( decimalIndex == 0 )
	//		{
	//			char zeroDegit = formatSymbols.getZeroDigit();
	//			String zeroDecimalSeparater = String.valueOf( new char[]
	//			{ zeroDegit, decimalSeparater } );
	//
	//			if ( pattern.indexOf( zeroDecimalSeparater ) != -1 )
	//			{
	//				return 0;
	//			}
	//
	//			return -1;
	//		}
	//		else
	//		{
	//			integerValue = target.substring( 0, decimalIndex );
	//		}
	//
	//		if ( groupingSize == 0 )
	//		{
	//			return -1;
	//		}
	//
	//		String[] groups = split( integerValue, groupingSeparater );
	//
	//		for ( int i = 0; i < groups.length; i++ )
	//		{
	//			String group = groups[ i ];
	//
	//			if ( i == 0 && groupingSize < group.length() )
	//			{
	//				return errorIndex;
	//			}
	//			else if ( i > 0 && groupingSize != group.length() )
	//			{
	//				return errorIndex;
	//			}
	//			errorIndex += group.length();
	//		}
	//
	//		return -1;
	//	}

	// TODO [2007/03/31][okajima] v3.0では提供しません。
	//	private static String[] split( String value, char pattern )
	//	{
	//		String group = value;
	//		int patternIndex = group.indexOf( pattern );
	//
	//		if ( patternIndex < 0 )
	//		{
	//			return new String[]
	//			{ group };
	//		}
	//
	//		ArrayList<String> groups = new ArrayList<String>();
	//
	//		while ( patternIndex > -1 )
	//		{
	//			groups.add( group.substring( 0, patternIndex ) );
	//			group = group.substring( patternIndex + 1 );
	//			patternIndex = group.indexOf( pattern );
	//		}
	//
	//		groups.add( group );
	//
	//		return (String[])groups.toArray( new String[ groups.size() ] );
	//	}
}
