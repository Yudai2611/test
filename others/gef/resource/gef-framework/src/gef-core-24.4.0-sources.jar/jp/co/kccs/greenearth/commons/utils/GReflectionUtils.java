/*
 * Copyright 2007-2008 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.beanutils.MethodUtils;

/**
 * リフレクションに関するユーティリティクラス.
 * 
 * @create 2007/01/04
 * @author Aono
 * @since 3.0.0
 */
@Deprecated(since = "23.10.0", forRemoval = true)
public final class GReflectionUtils {

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2006/12/19
	 * @author Aono
	 * @since 3.0.0
	 */
	private GReflectionUtils() {
	}

	// ---- パブリックメソッド -------------------------------------------------

	/**
	 * オブジェクト間でプロパティをシャロウコピーします.<br>
	 * 1.コピーを行う際の規則性<br>
	 * [1]引数を持たないget又はisから始まるメソッドをgetterの候補とする。<br>
	 * [2]setから始まる引数が1個のメソッドをsetterの候補とする。<br>
	 * [3]setterの引数と同じ型を返すgetterを、getterの候補から探してプロパティのシャドウコピーを実行する。<br>
	 * 　[3-1]getterの候補を探す場合、getで始まるメソッドがあれば、isから始まるgetterは使用されない。<br>
	 * [4]getterとsetterのペアが見つからない場合、プロパティのコピーは行われない。<br>
	 * [5]setter,getter共に<code>public</code>である必要がある。
	 * 
	 * @create 2006/12/27
	 * @param src コピー元
	 * @param dest コピー先
	 * @author aono
	 * @since 3.0.0
	 */
	public static void copyProperties(Object src, Object dest) {
		// プロパティ名一覧
		Set<String> propertyNames = new HashSet<String>();
		// getter一覧
		Map<String, Method> getterMethods = new HashMap<String, Method>();

		Method[] methods = src.getClass().getMethods();
		for (int i = 0; i < methods.length; i++) {
			// 引数が0個以外無視
			if (methods[i].getParameterTypes().length != 0) {
				continue;
			}
			String methodName = methods[i].getName();
			// メソッド名がgetかisで始まるメソッド以外は無視
			if (methodName.startsWith("get", 0)) {
				propertyNames.add(methodName.substring(3));
			} else if (methodName.startsWith("is", 0)) {
				propertyNames.add(methodName.substring(2));
			} else {
				continue;
			}
			getterMethods.put(methodName, methods[i]);
		}

		// プロパティ名の一覧を取得
		for (String propertyNmae : propertyNames) {
			// getXxxの場合を処理
			Method getter = getterMethods.get("get" + propertyNmae);

			if (copyProperty(src, dest, getter, propertyNmae)) {
				continue;
			}

			// isXxxの場合を処理
			getter = getterMethods.get("is" + propertyNmae);

			if (copyProperty(src, dest, getter, propertyNmae)) {
				continue;
			}
		}
	}

	// ---- プロテクテッドメソッド ----------------------------------------------

	// ---- プライベートメソッド ------------------------------------------------------------

	/**
	 * アクセッサメソッド名を組み立てます.<br>
	 * 
	 * @create 2006/12/27
	 * @param prefix アクセッサの接頭詞
	 * @param property プロパティ名
	 * @return アクセッサ名
	 * @author aono
	 * @since 3.0.0
	 */
	private static String buildAccesserName(String prefix, String property) {
		StringBuilder accesserName = new StringBuilder(prefix);
		accesserName.append(property.substring(0, 1).toUpperCase());

		if (property.length() > 1) {
			accesserName.append(property.substring(1));
		}

		return accesserName.toString();
	}

	/**
	 * オブジェクト間でプロパティをシャロウウコピーします.<br>
	 * 
	 * @create 2006/12/27
	 * @param src コピー元
	 * @param dest コピー先 
	 * @param getter getterメソッド
	 * @param propertyNmae プロパティ名
	 * @return コピーの成否
	 * @author aono
	 * @since 3.0.0
	 */
	private static boolean copyProperty(Object src, Object dest, Method getter, String propertyNmae) {
		// getterメソッドを検索
		if (getter != null) {
			Class< ? > returnClass = getter.getReturnType();

			// setterメソッドを検索
			String setterName = buildAccesserName("set", propertyNmae);
			Method setter = MethodUtils.getAccessibleMethod(dest.getClass(), setterName, new Class[] {returnClass});

			if (setter != null) {
				// setterが取得できたのでコピーを実行
				Object value;
				try {
					value = getter.invoke(src, new Object[] {});
					setter.invoke(dest, new Object[] {value});
				} catch (IllegalArgumentException e) {
					// パラメータの数や型が合わない
					return false;
				} catch (IllegalAccessException e) {
					// メッソッドへのアクセス権限不足
					return false;
				} catch (InvocationTargetException e) {
					// 目的のメソッドが例外を発生
					return false;
				}
				return true;
			}
		}
		return false;
	}
}
