/*
 * Copyright 2007-2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 文字列に関連する操作を簡素化する機能を提供します.
 * 
 * @create 2005/09/14
 * @author kitamura
 * @since 3.0.0
 */
public final class GStringUtils {

	/** 数値文字参照(10進表記 or 16進表記) 正規表現.*/
	private static final Pattern NUMCHARREFERENCE_PATTERN = Pattern.compile("(&#[1-9]\\d*;)|(&#[xX][1-9a-fA-F][0-9a-fA-F]*;)");
	
	/**
	 * 指定された文字列のバインド変数に、指定されたパラメータをバインドします.<br>
	 * バインド変数は、バインド変数のインデックスを中括弧<code>"{}"</code>で囲んだ文字列で表されます。<br>
	 * <br>
	 * 例:'{0}'項目には、{1}を入力してください。<br>
	 * <pre>
	 *  String message = "'{0}'項目には、{1}を入力してください。";
	 *  String result = GStringUtils.bindParameter( message, new String[]{ "電話番号", "11桁の数値" };
	 *  System.out.println( result );
	 * </pre>
	 * 結果:'電話番号'項目には、11桁の数値を入力してください。<br>
	 * <br>
	 * バインド変数は、インデックス順に並べる必要はありません。(例："'{1}'項目には、{0}を入力してください。";)<br>
	 * 同じインデックスのバインド変数を指定することもできます。(例："'{0}'項目には、{0}を入力してください。";)<br>
	 * <br>
	 * ※以下の文字は、バインド変数と認識されません。<br>
	 * ・インデックスが数値でない場合(例："'{a}'項目には、{b}を入力してください。";)<br>
	 * ・インデックスが無い場合(例："'{}'項目には、{}を入力してください。";)<br>
	 * ・インデックスが前ゼロの場合(例："'{00}'項目には、{001}を入力してください。";)<br>
	 * <br>
	 * @create 2007/03/04
	 * @param src ソース文字列
	 * @param params バインドパラメータ
	 * @return バインド文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String bindParameter(String src, String[] params) {

		if (Objects.isNull(src)) {
			return null;
		} else if (Objects.isNull(params)) {
			return src;
		}

		StringBuilder bindBuilder = new StringBuilder();

		// ソース文字列より、バインド変数を探索
		Pattern pattern = Pattern.compile("\\{([0-9]|[1-9][0-9]+)\\}");
		Matcher matcher = pattern.matcher(src);
		int start = 0;

		while (matcher.find()) {

			try {
				// バインド変数のインデックス取得
				String matchSequence = matcher.group();
				String indexString = matchSequence.substring(1, matchSequence.length() - 1);
				int index = Integer.parseInt(indexString);

				// バインド変数をバインドパラメータの値に置換
				if (index < params.length && params[index] != null) {
					bindBuilder.append(src.substring(start, matcher.start()));
					bindBuilder.append(params[index]);
					start = matcher.end();
				}
			} catch (NumberFormatException e) {
				// 正規表現の定義上、数値しかあり得ないので、エラーは発生しない
			}
		}
		// 残りのソース文字列の結合
		bindBuilder.append(src.substring(start, src.length()));

		return bindBuilder.toString();
	}

	/**
	 * 指定された文字列が空文字、またはnullの場合、指定したデフォルト値に変換します.<br>
	 * 空文字または、null以外の値が指定された場合は何も行いません。
	 * 
	 * @create 2005/09/14
	 * @param src ソース文字列
	 * @param defaultValue デフォルト値
	 * @return 変換文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String blankToDefault(String src, String defaultValue) {
		String output = src;
		if (Objects.isNull(output) || "".equals(output)) {
			output = defaultValue;
		}
		return output;
	}
	
	/**
	 * 指定された文字列にサロゲートペア文字が含まれているかどうかチェックします。
	 * 
	 * @create 2011/02/24
	 * @param value チェック対象文字列
	 * @return true(含まれている)/false(含まれていない)
	 * @author KCCS murashige
	 * @since 3.9.0
	 */
	public static boolean checkSurrogatePair(String value) {
		if (Objects.isNull(value) || "".equals(value)) {
			return false;
		}
		char[] chars = value.toCharArray();  
		boolean isSurrogatePair = false;
		for (char c : chars) {
			if (isSurrogatePairChar(c)) {
				isSurrogatePair = true;
				break;
			}
		}
		return isSurrogatePair;
	}

	public static boolean isSurrogatePairChar(char c) {
		return Character.isHighSurrogate(c) || Character.isLowSurrogate(c);
	}

	
	/**
	 * 指定された文字列に数値参照文字が含まれているかどうかチェックします。
	 * "&#10進数;"または"&#16進数;"をそれぞれ数値文字参照と判断します。<br/>
	 * 
	 * @create 2011/02/24
	 * @param value チェック対象文字列
	 * @return true(含まれている)/false(含まれていない)
	 * @author KCCS murashige
	 * @since 3.9.0
	 */
	public static boolean checkNumCharReference(String value) {
		if (Objects.isNull(value) || "".equals(value)) {
			return false;
		}
		Matcher numCharReferenceMacher = NUMCHARREFERENCE_PATTERN.matcher(value);
		boolean isNumCharReference = false;
		if (numCharReferenceMacher.find()) {
			isNumCharReference = true;
		}
		return isNumCharReference;
	}

	/**
	 * 指定された文字列が空文字の場合、nullに変換します. <br>
	 * 空文字以外の値が指定された場合は何も行いません。
	 * 
	 * @create 2005/09/14
	 * @param src ソース文字列
	 * @return 変換文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String blankToNull(String src) {
		String output = src;
		if ("".equals(output)) {
			output = null;
		}
		return output;
	}

	/**
	 * 指定された文字列が<code>null</code>または<code>""</code>の場合、<code>true</code>を返します.
	 * 
	 * @create 2008/06/09
	 * @param src ソース文字列
	 * @return <code>null</code>または<code>""</code>の場合:<code>true</code>、それ以外:<code>false</code>
	 * @author kitamura
	 * @since 3.5.0
	 */
	@Deprecated
	public static boolean isEmpty(String src) {
		return Objects.isNull(src) || "".equals(src);
	}
	
	/**
	 * 指定された文字列が<code>null</code>または<code>""</code>の場合、<code>true</code>を返します.
	 * 
	 * @create 2022/03/31
	 * @param src ソース文字列
	 * @return <code>null</code>または<code>""</code>の場合:<code>true</code>、それ以外:<code>false</code>
	 * @author oka
	 * @since 22.3.0
	 */
	public static boolean isNullOrEmpty(String src) {
		return Objects.isNull(src) || "".equals(src);
	}

	public static boolean isNullOrTrimEmpty(String src) {
		return Objects.isNull(src) || src.trim().isEmpty();
	}

	/**
	 * 指定された文字列が<code>not null</code>かつ<code>!""</code>の場合、<code>true</code>を返します.
	 * 
	 * @create 2020/09/04
	 * @param src ソース文字列
	 * @return <code>not null</code>かつ<code>!""</code>の場合:<code>true</code>、それ以外:<code>false</code>
	 * @author okanishi
	 * @since 20.9.0
	 */
	public static boolean isNotEmpty(String src) {
		return src != null && !"".equals(src);
	}
	
	/**
	 * 指定された文字列がnullの場合、空文字に変換します.
	 * 
	 * @create 2006/12/31
	 * @param src ソース文字列
	 * @return 変換文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String nullToBlank(String src) {
		String output = src;
		if (Objects.isNull(output)) {
			output = "";
		}
		return output;
	}

	/**
	 * 指定された文字列の一つ目文字を{@link Character}に変換します。<br>
	 * <code>null</code>、空文字列の場合はデフォルト値として指定された値が返されます。<br>
	 * 
	 * @param value 数値文字列
	 * @param defaultValue デフォルト値
	 * @return {@link Character}型オブジェクト
	 * @create 2014/12/17
	 * @author KCCS XieHeping
	 * @since
	 */
	public static Character toCharacter(final String value, Character defaultValue) {
		if (Objects.isNull(value) || value.equals("")) {
			return defaultValue;
		}

		return value.charAt(0);
	}

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2005/09/14
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GStringUtils() {
	}
}
