/*
 * Copyright 2020-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.io.File;
import java.net.URI;

/**
 * URI Fileスキームハンドラの実装です.<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public class GURIFileSchemeHandler extends GURISchemeHandlerBase {

	public GURIFileSchemeHandler() {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public String getAbsolutePath(URI uri) {
		return new File(uri.getPath()).getAbsolutePath();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	protected GURIScheme getScheme() {
		return GURIScheme.FILE;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public URI createURI(String uri) {
		URI uriObj = super.createURI(uri);
		if (uriObj != null && uriObj.getPath() == null) {
			// uriObj != null の場合、ファイルが必ず存在することは、super.createURI(uri)にで保障できます。
			uriObj = new File(uri).toURI();
		}
		return uriObj;
	}
}
