/*
 * Copyright 2020-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.net.URI;

/**
 * URI Jarスキームハンドラの実装です.<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public class GURIJarSchemeHandler extends GURISchemeHandlerBase {

	public GURIJarSchemeHandler() {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public String getAbsolutePath(URI uri) {
		return uri.toString();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	protected GURIScheme getScheme() {
		return GURIScheme.JAR;
	}
}
