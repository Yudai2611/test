/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * URIのScheme種別.<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public enum GURIScheme {

	FILE("file"), JAR("jar"), VFS("vfs");

	/** 文字列-列挙値マップ. */
	private static final Map<String, GURIScheme> VALUE_MAP = new HashMap<>();

	static {
		VALUE_MAP.put("file", FILE);
		VALUE_MAP.put("jar", JAR);
		VALUE_MAP.put("vfs", VFS);
	}

	private final String _value;

	GURIScheme(String value) {
		_value = value;
	}

	/**
	 * schemeの文字列をGURISchemeに転換する.<br>
	 * 
	 * @param value schemeの文字列
	 * @return GURIScheme
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static GURIScheme convert(String value) {
		return VALUE_MAP.getOrDefault(value, null);
	}

	/**
	 * GURISchemeから、schemeの文字列を取得する.<br>
	 * 
	 * @return schemeの文字列
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public String getValue() {
		return _value;
	}
}