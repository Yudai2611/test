/*
 * Copyright 2020-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.net.URI;
import java.util.List;

/**
 * URIスキームハンドラのインターフェースです.<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public interface GURISchemeHandler {

	/**
	 * relativeFilePath（相対パスのファイル）が所属されるディレクトリ配下のファイル名リスト取得.<br>
	 * （サブディレクトリ名も含むが、サブディレクトリ配下のファイル名を含まない）<br>
	 *
	 * relativeFilePathは、ファイルの相対パスである。<br>
	 *   "entityDir/subDir/1111.entity" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 *
	 * ※推奨しないパラメータ指定：<br>
	 * relativeFilePathは、ディレクトリの相対パスであれば、ファイルリストも取得できるが、結果は、想定と異なるかもしれない。<br>
	 *   "entityDir/subDir/" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 *   "entityDir/subDir" ==> "entityDir/*"配下のファイル名リスト取得。<br>
	 *
	 * @param relativeFilePath ファイルの相対パス
	 * @return 所属されるディレクトリ配下のファイル名リスト取得
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	List<String> listFileNamesFromClosestDir(String relativeFilePath);

	/**
	 * relativeDirPath（相対パスのディレクトリ）に配下のファイル名リスト取得.<br>
	 * （サブディレクトリ名を含むし、サブディレクトリ配下のファイル名リストも含む）<br>
	 *
	 * relativeDirPathは、ディレクトリの相対パスである。<br>
	 *   "entityDir/subDir/" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 *   "entityDir/subDir" ==> "entityDir/subDir/"配下のファイル名リスト取得。<br>
	 *
	 * ※サポートしないパラメータ指定：<br>
	 * relativeDirPathは、ファイルの相対パスであれば、異常発生。<br>
	 *   例え、"entityDir/subDir/1111.entity"の場合、<br>
	 *     「1111.entity」をディレクトリと見なされ、存在しないディレクトリをアクセスすると、<br>
	 *     FileNotFoundException発生。<br>
	 *
	 * @param relativeDirPath ディレクトリの相対パス
	 * @return 配下のファイル名リスト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	List<String> listFileNamesFrom(String relativeDirPath);

	/**
	 * 指定URIオブジェクトの絶対パスを取得する.<br>
	 *   fileスキームの場合、FileObj.getAbsolutePath()を返す。※OSにより、スラッシュ・バックスラッシュ何れも可能。<br>
	 *   以外スキームの場合、uri.toString()を返す。<br>
	 * 
	 * @param uri URIオブジェクト
	 * @return 指定URIオブジェクトの絶対パス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	String getAbsolutePath(URI uri);

	/**
	 * 指定したuri文字列をハンドラが操作可能かどうかを判断する.<br>
	 * 
	 * @param uri 文字列
	 * @return boolean true:操作可能/false:操作不可能
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	boolean canHandle(String uri);

	/**
	 * 指定文字列で、URIオブジェクトを作る.<br>
	 * 作られない時、nullを返す。<br>
	 * 
	 * @param uri 文字列
	 * @return URIオブジェクト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	URI createURI(String uri);

}
