/*
 * Copyright 2020-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;

/**
 * URIスキームハンドラのデフォルト実装です.<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public abstract class GURISchemeHandlerBase implements GURISchemeHandler {

	// ".../*"： ディレクトリ配下のファイルリスト（サブディレクトリ名も含むが、サブディレクトリ配下のファイルを含まない）
	protected static String PATTERN_LISTDIR = "*";
	// ".../**"： ディレクトリ配下のファイルリスト（サブディレクトリ名も含む。サブディレクトリ配下のファイル名リストも含む）
	protected static String PATTERN_LISTDIR_RECURSIVE = "**";

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public List<String> listFileNamesFromClosestDir(String relativeFilePath) {
		List<String> fileNameList = new ArrayList<>();
		String relativeDir = GFileUtils.getDirectoryPath(relativeFilePath);
		List<Resource> list = getResources(relativeDir, PATTERN_LISTDIR);
		list.stream().filter(GURISchemeHandlerBase::isFile).forEach(resource -> {
			fileNameList.add(resource.getFilename());
		});
		return fileNameList;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public List<String> listFileNamesFrom(String relativeDirPath) {
		List<String> fileNameList = new ArrayList<>();

		String relativeDir = relativeDirPath + (relativeDirPath.endsWith("/") ? "" : "/");
		List<Resource> list = getResources(relativeDir, PATTERN_LISTDIR_RECURSIVE);
		list.forEach(resource -> {
			if (isFile(resource)) {
				fileNameList.add(extractFileName(resource, relativeDir));
			}
		});
		return fileNameList;
	}

	/**
	 * 指定ディレクトリの相対パス と マッチングパターンにより、リソースリストを取得する.<br>
	 * patternInfoは、PATTERN_LISTDIR と PATTERN_LISTDIR_RECURSIVE の定義ご参照。<br>
	 * リソースが存在しないと、空のリストを返す（nullではない）。<br>
	 * 
	 * @param relativePathDir ディレクトリの相対パス
	 * @param patternInfo マッチングパターン情報
	 * @return リソースのリスト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	private static List<Resource> getResources(String relativePathDir, String patternInfo) {
		List<Resource> list;
		try {
			list = Arrays.stream(new PathMatchingResourcePatternResolver().getResources(relativePathDir + patternInfo))
				.collect(Collectors.toList());
		} catch (IOException e) {
			throw new GResourceAccessException(e);
		}
		return list;
	}

	private static boolean isFile(Resource resource) {
		try {
			return !resource.getURL().toString().endsWith("/");
		} catch (IOException e) {
			throw new GResourceAccessException(e);
		}
	}

	private static String extractFileName(Resource resource, String relativeDir) {
		try {
			// vfsの場合、.getURI()（"vfs:///c: ..."）が、通常の.getURL()（"vfs:/c: ..."）と異なることを回避する
			return resource.getURL().toString().substring(GFileUtils.getResource(relativeDir).toString().length());
		} catch (IOException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public boolean canHandle(String uri) {
		return createURI(uri) != null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public URI createURI(String uri) {
		Resource resource = getResource(uri);
		try {
			if (resource.exists() && matchScheme(resource)) {
				return resource.getURI();
			}
		} catch (IOException e) {
			throw new GResourceAccessException("Resource is not found. : " + uri, e);
		}
		return null;
	}

	/**
	 * 指定リソースのSchemeが、該当GURISchemeHandlerインスタンスのschemeと一致するかのマッチ処理.<br>
	 * 
	 * @param resource
	 * @return boolean true:一致/false:一致しない
	 * @throws IOException
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	protected boolean matchScheme(Resource resource) throws IOException {
		return getScheme().getValue().equals(resource.getURI().getScheme());
	}

	/**
	 * 指定uriにより、リソース取得する.<br>
	 * uriで一回目取得できない場合、(scheme + ":" + uri)で再度取得する。<br>
	 * 
	 * @param uri 文字列
	 * @return Resource
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	protected Resource getResource(String uri) {
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		Resource resource = resolver.getResource(uri);
		if (!resource.exists()) {
			String newUri = addURIPrefix(uri);
			if (!uri.equals(newUri)) {
				resource = resolver.getResource(newUri);
			}
		}
		return resource;
	}

	/**
	 * uri文字列にscheme情報をつけない場合、scheme情報を付けて返す.<br>
	 * すでにscheme情報がある場合、そのまま返す。<br>
	 * 
	 * @param uri
	 * @return scheme情報を付けるuri文字列
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	protected String addURIPrefix(String uri) {
		String prefix = getScheme().getValue() + ":";
		if (!uri.startsWith(prefix)) {
			return prefix + uri;
		}
		return uri;
	}

	/**
	 * GURISchemeを取得する.<br>
	 * 
	 * @return GURIScheme
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	protected abstract GURIScheme getScheme();
}