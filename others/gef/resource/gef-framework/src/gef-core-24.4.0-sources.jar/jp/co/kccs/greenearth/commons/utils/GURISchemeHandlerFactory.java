/*
 * Copyright 2020-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.net.URI;

/**
 * GURISchemeHandler取得のファクトリーです.<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public interface GURISchemeHandlerFactory {

	/**
	 * URIにより、GURISchemeHandler取得.<br>
	 * 
	 * @param uri URIのインスタンス
	 * @return GURISchemeHandlerのインスタンス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	GURISchemeHandler getSchemeHandler(URI uri);

	/**
	 * 文字列により、GURISchemeHandler取得.<br>
	 * 
	 * @param uri 文字列
	 * @return GURISchemeHandlerのインスタンス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	GURISchemeHandler getSchemeHandler(String uri);

	/**
	 * GURISchemeにより、GURISchemeHandler取得.<br>
	 * 
	 * @param scheme GURIScheme
	 * @return GURISchemeHandlerのインスタンス
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	GURISchemeHandler getSchemeHandler(GURIScheme scheme);
}
