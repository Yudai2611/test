/*
 * Copyright 2020-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.net.URI;
import java.util.Map;
import java.util.Optional;

/**
 * {@link GURISchemeHandlerFactory}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public class GURISchemeHandlerFactoryImpl implements GURISchemeHandlerFactory {

	private final Map<GURIScheme, GURISchemeHandler> _handlerMap;

	public GURISchemeHandlerFactoryImpl(Map<GURIScheme, GURISchemeHandler> handlerMap) {
		_handlerMap = handlerMap;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public GURISchemeHandler getSchemeHandler(String uri) {
		checkNullOrEmpty(uri);
		Optional<GURISchemeHandler> opt = _handlerMap.values().stream().filter(s -> s.canHandle(uri)).findAny();
		if (opt.isPresent()) {
			return opt.get();
		}
		throw new IllegalArgumentException("The uri is not supported. uri : " + uri);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public GURISchemeHandler getSchemeHandler(URI uri) {
		checkNullOrEmpty(uri);
		return getSchemeHandler(GURIScheme.convert(uri.getScheme()));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public GURISchemeHandler getSchemeHandler(GURIScheme scheme) {
		checkNullOrEmpty(scheme);
		GURISchemeHandler handler = _handlerMap.get(scheme);
		checkNullOrEmpty(handler);
		return handler;
	}

	/**
	 * 共通チェック処理.<br>
	 * objがnull、または、objが空文字の場合、IllegalArgumentExceptionを発生させる。<br>
	 * 
	 * @param obj 判断対象
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	private void checkNullOrEmpty(Object obj) {
		if (obj == null || (obj instanceof String && GStringUtils.isNullOrEmpty((String) obj))) {
			throw new IllegalArgumentException("The specified value is null or empty.");
		}
	}
}
