/*
 * Copyright 2020-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.utils;

import java.net.URI;

/**
 * URI VFSスキームハンドラの実装です.<br>
 * WildflyのVirtual File Systemに対応しています。<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public class GURIVFSSchemeHandler extends GURISchemeHandlerBase {

	public GURIVFSSchemeHandler() {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public String getAbsolutePath(URI uri) {
		return uri.toString();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	protected GURIScheme getScheme() {
		return GURIScheme.VFS;
	}
}
