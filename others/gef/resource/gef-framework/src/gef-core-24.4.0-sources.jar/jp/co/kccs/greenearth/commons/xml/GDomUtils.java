package jp.co.kccs.greenearth.commons.xml;

import org.w3c.dom.Element;

public class GDomUtils {
	
	public static int getIntAttr(Element elem, String name) {
		String attr = elem.getAttribute(name);
		return Integer.parseInt(attr);
	}
	
	public static int getIntAttr(Element elem, String name, int defaultValue) {
		if (elem.hasAttribute(name)) {
			try {
				return getIntAttr(elem, name);
			}
			catch (NumberFormatException e) {
				return defaultValue;
			}
		}
		else {
			return defaultValue;
		}
	}
	
	public static boolean getBooleanAttr(Element elem, String name) {
		String attr = elem.getAttribute(name);
		return Boolean.valueOf(attr);
	}
	
	public static boolean getBooleanAttr(Element elem, String name, boolean defaultValue) {
		if (elem.hasAttribute(name)) {
			return getBooleanAttr(elem, name);
		}
		else {
			return defaultValue;
		}
	}

}
