/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.authorization.GEditableRoleDao;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.menu.GEditableMenu;

/**
 * MenuManager用の検証クラス.<br>
 * 
 * @create 2011/05/26
 * @author KCCS nishimura
 * @since 3.9.0
 */
public class GEditableMenuValidator {

	// Menuの項目名
	/** CompanyCode項目 */
	protected static final String COMPANY_CODE = "CompanyCode";
	/** ObjectID項目 */
	protected static final String OBJECTID = "ObjectID";
	/** MenuID項目 */
	protected static final String MENUID = "MenuID";
	/** DisplayNameResourceID項目 */
	protected static final String DISPLAYNAMERESOURCEID = "DisplayNameResourceID";
	/** ParentMenuObjectID項目 */
	protected static final String PARENTMENUID = "ParentMenuObjectID";
	/** ApplicationType項目 */
	protected static final String APPLICATIONTYPE = "ApplicationType";
	/** MenuType項目 */
	protected static final String MENUTYPE = "MenuType";
	/** StartModule項目 */
	protected static final String STARTMODULE = "StartModule";
	/** Parameter項目 */
	protected static final String PARAMETER = "Parameter";
	/** Status項目 */
	protected static final String STATUS = "Status";
	/** RoleObjectID項目 */
	protected static final String ROLEID = "RoleObjectID";
	/** Description項目 */
	protected static final String DESCRIPTION = "Description";
	/** SortIndex項目 */
	protected static final String SORTINDEX = "SortIndex";
	/** UpdatedPerson項目 */
	protected static final String UPDATEDPERSON = "UpdatedPerson";
	/** MenuName項目 */
	protected static final String MENUNAME = "MenuName";
	/** Locale項目 */
	protected static final String LOCALE = "Locale";

	// 桁数チェックの値
	/** CompanyCode項目 */
	private static final int MENU_COMPANY_CODE_DIGITNUMBER = 5;
	/** ObjectID項目 */
	private static final int MENU_OBJECTID_DIGITNUMBER = 36;
	/** MenuID項目 */
	private static final int MENU_MENUID_DIGITNUMBER = 50;
	/** DisplayNameResourceID項目 */
	private static final int MENU_DISPLAYNAMERESOURCEID_DIGITNUMBER = 36;
	/** ParentMenuObjectID項目 */
	private static final int MENU_PARENTMENUOBJECTID_DIGITNUMBER = 36;
	/** ApplicationType項目 */
	private static final int MENU_APPLICATIONTYPE_DIGITNUMBER = 50;
	/** MenuType項目 */
	private static final int MENU_MENUTYPE_DIGITNUMBER = 50;
	/** StartModule項目 */
	private static final int MENU_STARTMODULE_DIGITNUMBER = 255;
	/** Parameter項目 */
	private static final int MENU_PARAMETER_DIGITNUMBER = 255;
	/** RoleObjectID項目 */
	private static final int MENU_ROLEID_DIGITNUMBER = 36;
	/** Description項目 */
	private static final int MENU_DESCRIPTION_DIGITNUMBER = 255;
	/** SortIndex項目 */
	private static final int MENU_SORTINDEX_MAX_DIGITNUMBER = 4;
	/** UpdatedPerson項目 */
	protected static final int MENU_UPDATEDPERSON_DIGITNUMBER = 20;
	/** MenuName項目 */
	protected static final int MENU_MENUNAME_DIGITNUMBER = 255;
	/** Locale項目 */
	protected static final int MENU_LOCALE_DIGITNUMBER = 20;

	// エラーコード
	/** 入力して下さい */
	protected static final String REQUIRED_CHECK_ERRORCODE = "GEM-000003";
	/** 桁数が制限を超えています */
	protected static final String MAX_STRING_LENGTH_CHECK_ERRORCODE = "GEM-000002";
	/** 桁数が不正です */
	protected static final String ILLEAGAL_STRING_LENGTH_ERROR = "GEM-000020";
	/** アプリケーションタイプが存在しません */
	protected final String APPLICATIONTYPE_CHECK_ERRORCODE = "GEM-000012";
	/** メニュータイプが存在しません */
	protected final String MENUTYPE_CHECK_ERRORCODE = "GEM-000024";
	/** 不正な値が入力されています */
	protected final String ILLEGAL_VALUE_ERROR = "GEM-000013";
	/** 式に不備があります */
	protected static final String SYNTAX_CHECK_ERRORCODE = "GEM-000004";
	/** 定義したロールが存在しません */
	protected final String NODEFINED_ROLE_CHECK_ERRORCODE = "GEM-000005";
	/** カテゴリには設定できません */
	protected final String CATEGORY_SET_CHECK_ERRORCODE = "GEM-000029";
	/** 親メニューIDに紐付くメニュー情報がありません。 */
	protected final String PARENTMENUOBJECTID_CHECK_ERRORCODE = "GEM-000015";
	/** 親メニュー情報のアイテムフラグが不正です。 */
	protected final String ITEMFLAG_CHECK_ERROR = "GEM-000016";
	/** 循環参照が発生しました */
	protected static final String CIRCULAR_REFERENCE_MENU_CHECK_ERRORCODE = "GEM-000025";
	/** 循環参照チェック時、先祖のメニューが存在しないエラー */
	protected static final String ANCETOR_MENU_CHECK_ERRORCODE = "GEM-000026";

	/** 状態(実行可能状態)を表す文字列 */
	protected static final String STATUS_ACTIVE = "1";
	/** 状態(停止状態)を表す文字列 */
	protected static final String STATUS_STOP = "0";
	/** 状態を表す文字列の許可値 */
	protected final static List<String> STATUS_PERMISSION_LIST = Arrays.asList(STATUS_ACTIVE, STATUS_STOP);
	/** ロケール */
	private Locale _locale = null;
	/** エラーリスト */
	private List<GValidateError> _errorList = new ArrayList<GValidateError>();
	/** メニューファインダー */
	private MenuFinder _finder = null;

	/**
	 * メニューを検出する際に使用するインタフェースです.<br>
	 * 
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public interface MenuFinder {

		/**
		 * 引数のオブジェクトIDを検索条件に、メニューを検索します.<br>
		 * 
		 * @param menuObjectID オブジェクトID
		 * @return メニュー
		 * @create 2011/09/13
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		GEditableMenu findMenu(String menuObjectID);
	}

	/**
	 * デフォルトコンストラクタです.<br>
	 * 内部で、{@link GFrameworkContext}からロケールを取得しています.
	 * 
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GEditableMenuValidator() {
		_locale = GFrameworkContext.getInstance().getLocale();
	}

	/**
	 * 引数にロケールをとる、コンストラクタです.<br>
	 * 
	 * @param locale ロケール
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GEditableMenuValidator(Locale locale) {
		_locale = locale;
	}

	/**
	 * 引数に{@link MenuFinder}をとる、コンストラクタです.<br>
	 * 
	 * @param finder {@link MenuFinder}オブジェクト
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GEditableMenuValidator(MenuFinder finder) {
		this();
		_finder = finder;
	}

	/**
	 * 引数にロケールと{@link MenuFinder}をとる、コンストラクタです.<br>
	 * 
	 * @param finder {@link MenuFinder}オブジェクト
	 * @param locale ロケール
	 * @create 2011/09/13
	 * @author KCCS nihimura
	 * @since 3.9.0
	 */
	public GEditableMenuValidator(MenuFinder finder, Locale locale) {
		_locale = locale;
		_finder = finder;
	}

	/**
	 * 引数のエラー情報を基に{@link GValidateError}オブジェクトを生成し、エラーリストに追加します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void addValidateError(String errorCode, String errorColumn) {
		addValidateError(errorCode, errorColumn, -1);
	}

	/**
	 * 引数のエラー情報を基に{@link GValidateError}オブジェクトを生成し、エラーリストに追加します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @param rowDataNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void addValidateError(String errorCode, String errorColumn, int rowDataNo) {
		GValidateError error = createValidateError(errorCode, errorColumn, rowDataNo);
		getErrorList().add(error);
	}

	/**
	 * {@link GValidateError}型のエラーリストを返します.<br>
	 * 
	 * @return エラーリスト
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public List<GValidateError> getErrorList() {
		return _errorList;
	}

	/**
	 * {@link MenuFinder}オブジェクトを返します.<br>
	 * 
	 * @return {@link MenuFinder}オブジェクト
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public MenuFinder getMenuFinder() {
		return _finder;
	}

	/**
	 * エラーリストにエラーがあるかどうかを判定します.<br>
	 * 
	 * @return 真偽値
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public boolean hasError() {
		return _errorList.size() > 0;
	}

	/**
	 * {@link MenuFinder}オブジェクトを設定します.<br>
	 * 
	 * @param finder {@link MenuFinder}
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setMenuFinder(MenuFinder finder) {
		_finder = finder;
	}

	/**
	 * アプリケーションタイプの単項目チェックを行います.<br>
	 * 
	 * @param applicationType アプリケーションタイプ
	 * @param isItem アイテムフラグ
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateApplicationType(String applicationType, boolean isItem) {
		validateApplicationType(applicationType, isItem, -1);
	}

	/**
	 * アプリケーションタイプの単項目チェックを行います.<br>
	 * 
	 * @param applicationType アプリケーションタイプ
	 * @param isItem アイテムフラグ
	 * @param rowNo 行番号
	 * @create 2011/08/01
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateApplicationType(String applicationType, boolean isItem, int rowNo) {
		applicationType = GStringUtils.nullToBlank(applicationType);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(applicationType.trim())) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, APPLICATIONTYPE, rowNo));
			return;
		}

		// 桁数チェック
		if (MENU_APPLICATIONTYPE_DIGITNUMBER < applicationType.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, APPLICATIONTYPE, rowNo));
			return;
		}

		// 許可値チェック
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		Map<String, String> applicationTypeMap = isItem ? service.getItemAppTypeMap() : service.getCategoryAppTypeMap();
		if (!applicationTypeMap.containsKey(applicationType)) {
			getErrorList().add(createValidateError(APPLICATIONTYPE_CHECK_ERRORCODE, APPLICATIONTYPE, rowNo));
		}
	}

	/**
	 * 会社コードの単項目チェックを行います.<br>
	 * 
	 * @param companyCode 会社コード
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateCompanyCode(String companyCode) {
		validateCompanyCode(companyCode, -1);
	}

	/**
	 * 会社コードの単項目チェックを行います.<br>
	 * 
	 * @param companyCode 会社コード
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateCompanyCode(String companyCode, int rowNo) {
		// 前後の空白文字を取り除く
		companyCode = GStringUtils.nullToBlank(companyCode).trim();

		// 必須チェック
		if (GStringUtils.isEmpty(companyCode)) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, COMPANY_CODE, rowNo));
			return;
		}

		// 桁数チェック
		if (MENU_COMPANY_CODE_DIGITNUMBER < companyCode.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, COMPANY_CODE, rowNo));
		}
	}

	/**
	 * 備考の単項目チェックを行います.<br>
	 * 
	 * @param description 備考
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDescription(String description) {
		validateDescription(description, -1);
	}

	/**
	 * 備考の単項目チェックを行います.<br>
	 * 
	 * @param description 備考
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDescription(String description, int rowNo) {
		description = GStringUtils.nullToBlank(description);

		// 桁数チェック
		if (MENU_DESCRIPTION_DIGITNUMBER < description.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, DESCRIPTION, rowNo));
		}
	}

	/**
	 * メニュー名の単項目チェックを行います.<br>
	 * 
	 * @param displayName メニュー名
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDisplayName(String displayName) {
		validateDisplayName(displayName, -1);
	}

	/**
	 * メニュー名の単項目チェックを行います。<br>
	 * 
	 * @param displayName メニュー名
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDisplayName(String displayName, int rowNo) {
		displayName = GStringUtils.nullToBlank(displayName);
		if (GStringUtils.isEmpty(displayName)) {
			return;
		}

		// メニュー名の桁数チェック
		if (MENU_MENUNAME_DIGITNUMBER < displayName.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, MENUNAME, rowNo));
		}
	}

	/**
	 * ロケールの単項目チェックを行います.<br>
	 * 
	 * @param locale ロケール
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDisplayNameLocale(Locale locale) {
		validateDisplayNameLocale(locale, -1);
	}

	/**
	 * ロケールの単項目チェックを行います.<br>
	 * 
	 * @param locale ロケール
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDisplayNameLocale(Locale locale, int rowNo) {
		if (locale == null || "".equals(locale.toString())) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, LOCALE, rowNo));
			return;
		}
		if (MENU_LOCALE_DIGITNUMBER < locale.toString().length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, LOCALE, rowNo));
			return;
		}
		// ロケール構文チェック
		boolean localeFlag = GLocaleUtils.checkLocaleSyntax(locale.toString());
		if (!localeFlag) {
			getErrorList().add(createValidateError(SYNTAX_CHECK_ERRORCODE, LOCALE));
		}
	}

	/**
	 * 表示名リソースIDの単項目チェックを行うメソッドです。<br>
	 * 
	 * @param displayNameResourceID 表示名リソースID
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDisplayNameResourceID(String displayNameResourceID) {
		validateDisplayNameResourceID(displayNameResourceID, -1);
	}

	/**
	 * 表示名リソースIDの単項目チェックを行うメソッドです。<br>
	 * 
	 * @param displayNameResourceID リソースID
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateDisplayNameResourceID(String displayNameResourceID, int rowNo) {
		displayNameResourceID = GStringUtils.nullToBlank(displayNameResourceID);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(displayNameResourceID.trim())) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, DISPLAYNAMERESOURCEID, rowNo));
			return;
		}

		// 表示名の桁数チェック
		if (MENU_DISPLAYNAMERESOURCEID_DIGITNUMBER != displayNameResourceID.length()) {
			// getErrorList().add(createValidateError(ILLEAGAL_STRING_LENGTH_ERROR,
			// DISPLAYNAMERESOURCEID, rowNo));
			String[] params = new String[] {String.valueOf(MENU_DISPLAYNAMERESOURCEID_DIGITNUMBER)};
			getErrorList().add(
				createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR, DISPLAYNAMERESOURCEID,
					String.valueOf(rowNo), null, params));
		}
	}

	/**
	 * メニューの各項目に対してチェックを行います.<br>
	 * ※重複チェックは行いません。<br>
	 * 
	 * @param menu メニュー
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateMenu(GEditableMenu menu) {
		validateMenu(menu, -1);
	}

	/**
	 * メニューの各項目に対してチェックを行います.<br>
	 * ※重複チェックは行いません。<br>
	 * 
	 * @param menu メニュー
	 * @param index 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateMenu(GEditableMenu menu, int index) {
		validateMenuBasic(menu, index);

		validateParentObjectIDExisted(menu.getParentObjectID(), index);
		validateRoleObjectIDExisted(menu.getRoleObjectID(), index);
	}

	/**
	 * メニューの各項目に対して単項目チェックを行います.<br>
	 * ※重複チェックは行いません。<br>
	 * 
	 * @param menu メニュー
	 * @param index 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateMenuBasic(GEditableMenu menu, int index) {
		validateCompanyCode(menu.getCompanyCode(), index);
		validateObjectID(menu.getObjectID(), index);
		validateMenuID(menu.getMenuID(), index);
		validateDisplayNameResourceID(menu.getDisplayNameResourceID(), index);
		validateParentObjectIDBasic(menu.getParentObjectID(), index);
		validateApplicationType(menu.getApplicationType(), menu.isItem(), index);
		validateMenuType(menu.getMenuType(), menu.isItem(), index);
		validateStartModule(menu.getStartModule(), menu.isItem(), index);
		validateParameter(menu.getParameter(), index);
		validateStatus(String.valueOf(menu.getStatus().toInt()), index);
		validateRoleObjectID(menu.getRoleObjectID(), index);
		validateDescription(menu.getDescription(), index);
		validateSortIndex(menu.getSortIndex(), index);

		for (Entry<Locale, String> entry : menu.getDisplayNameMap().entrySet()) {
			String menuName = entry.getValue();
			Locale locale = entry.getKey();
			validateDisplayName(menuName, index);
			validateDisplayNameLocale(locale, index);
		}
	}

	/**
	 * メニューIDの単項目チェックを行います.<br>
	 * 
	 * @param menuID メニューID
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateMenuID(String menuID) {
		validateMenuID(menuID, -1);
	}

	/**
	 * メニューIDの単項目チェックを行います.<br>
	 * 
	 * @param menuID メニューID
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateMenuID(String menuID, int rowNo) {
		menuID = GStringUtils.nullToBlank(menuID);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(menuID.trim())) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, MENUID, rowNo));
			return;
		}

		// 桁数チェック
		if (MENU_MENUID_DIGITNUMBER < menuID.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, MENUID, rowNo));
		}
	}

	/**
	 * メニュータイプの単項目チェックを行います.<br>
	 * 
	 * @param menuType メニュータイプ
	 * @param isItem アイテムフラグ
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateMenuType(String menuType, boolean isItem) {
		validateMenuType(menuType, isItem, -1);
	}

	/**
	 * メニュータイプの単項目チェックを行います.<br>
	 * 
	 * @param menuType メニュータイプ
	 * @param isItem アイテムフラグ
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateMenuType(String menuType, boolean isItem, int rowNo) {
		menuType = GStringUtils.nullToBlank(menuType);
		if (GStringUtils.isEmpty(menuType)) {
			return;
		}

		// 桁数チェック
		if (MENU_MENUTYPE_DIGITNUMBER < menuType.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, MENUTYPE, rowNo));
			return;
		}

		// 許可値チェック
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		Map<String, String> menuTypeMap = isItem ? service.getItemMenuTypeMap() : service.getCategoryMenuTypeMap();
		if (!menuTypeMap.containsKey(menuType)) {
			getErrorList().add(createValidateError(MENUTYPE_CHECK_ERRORCODE, MENUTYPE, rowNo));
		}
	}

	/**
	 * オブジェクトIDの単項目チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateObjectID(String objectID) {
		validateObjectID(objectID, -1);
	}

	/**
	 * GMenuオブジェクトIDの単項目チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateObjectID(String objectID, int rowNo) {
		// 前後の空白文字を取り除く
		objectID = GStringUtils.nullToBlank(objectID);

		// 必須チェック
		if (GStringUtils.isEmpty(objectID.trim())) {
			// エラーがあれば、エラーリストに追加し、呼び出し元に返す。
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, OBJECTID, rowNo));
			return;
		}

		// 桁数チェック
		if (MENU_OBJECTID_DIGITNUMBER != objectID.length()) {
			// エラーがあれば、エラーリストに追加する。
			// getErrorList().add(createValidateError(ILLEAGAL_STRING_LENGTH_ERROR,
			// OBJECTID, rowNo));
			String[] params = new String[] {String.valueOf(MENU_OBJECTID_DIGITNUMBER)};
			getErrorList().add(
				createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR, OBJECTID, String.valueOf(rowNo),
					null, params));
		}
	}

	/**
	 * 起動パラメータの単項目チェックを行います.<br>
	 * 
	 * @param parameter 起動パラメータ
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateParameter(String parameter) {
		validateParameter(parameter, -1);
	}

	/**
	 * 起動パラメータの単項目チェックを行います.<br>
	 * 
	 * @param parameter 起動パラメータ
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateParameter(String parameter, int rowNo) {
		parameter = GStringUtils.nullToBlank(parameter);

		// 桁数チェック
		if (MENU_PARAMETER_DIGITNUMBER < parameter.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, PARAMETER, rowNo));
		}
	}

	/**
	 * 親メニューオブジェクトIDの単項目チェックを行います.<br>
	 * 
	 * @param parentObjectID 親メニューオブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateParentObjectIDBasic(String parentObjectID, int rowNo) {
		parentObjectID = GStringUtils.nullToBlank(parentObjectID);
		if (GStringUtils.isEmpty(parentObjectID)) {
			return;
		}

		// 親メニューオブジェクトIDの桁数チェック
		if (MENU_PARENTMENUOBJECTID_DIGITNUMBER != parentObjectID.length()) {
			String[] params = new String[] {String.valueOf(MENU_PARENTMENUOBJECTID_DIGITNUMBER)};
			getErrorList().add(
				createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR, PARENTMENUID,
					String.valueOf(rowNo), null, params));
			return;
		}
	}

	/**
	 * 親メニューオブジェクトの関連チェックを行います.<br>
	 * 
	 * @param parentObjectID 親メニューオブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateParentObjectIDExisted(String parentObjectID, int rowNo) {
		parentObjectID = GStringUtils.nullToBlank(parentObjectID);
		if (GStringUtils.isEmpty(parentObjectID)) {
			return;
		}

		// 存在チェック
		GEditableMenu menu = getMenuFinder().findMenu(parentObjectID);
		if (menu == null) {
			getErrorList().add(createValidateError(PARENTMENUOBJECTID_CHECK_ERRORCODE, PARENTMENUID, rowNo));
			return;
		}

		// 親がカテゴリかのチェック
		if (menu.isItem()) {
			getErrorList().add(createValidateError(ITEMFLAG_CHECK_ERROR, PARENTMENUID, rowNo));
		}
	}

	/**
	 * 親メニューオブジェクトIDの循環参照チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @param parentObjectID 親メニューオブジェクトID
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateParentObjectIDCircularReference(String objectID, String parentObjectID) {
		validateParentObjectIDCircularReference(objectID, parentObjectID, -1);
	}

	/**
	 * 親メニューオブジェクトIDの循環参照チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @param parentObjectID 親メニューオブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateParentObjectIDCircularReference(String objectID, String parentObjectID, int rowNo) {
		if (checkCircularReferenceRelation(objectID, parentObjectID, _finder, rowNo)) {
			getErrorList().add(createValidateError(CIRCULAR_REFERENCE_MENU_CHECK_ERRORCODE, PARENTMENUID, rowNo));
		}
	}

	/**
	 * ロールオブジェクトIDの単項目チェックを行います.<br>
	 * 
	 * @param roleObjectID ロールオブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateRoleObjectID(String roleObjectID, int rowNo) {
		roleObjectID = GStringUtils.nullToBlank(roleObjectID);
		if (GStringUtils.isEmpty(roleObjectID)) {
			return;
		}

		// 桁数チェック
		if (MENU_ROLEID_DIGITNUMBER != roleObjectID.length()) {
			// getErrorList().add(createValidateError(ILLEAGAL_STRING_LENGTH_ERROR,
			// ROLEID, rowNo));
			String[] params = new String[] {String.valueOf(MENU_ROLEID_DIGITNUMBER)};
			getErrorList().add(
				createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR, ROLEID, String.valueOf(rowNo),
					null, params));
			return;
		}
	}

	/**
	 * ロールオブジェクトIDの関連チェックを行います.<br>
	 * 
	 * @param roleObjectID ロールオブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateRoleObjectIDExisted(String roleObjectID, int rowNo) {
		roleObjectID = GStringUtils.nullToBlank(roleObjectID);
		if (GStringUtils.isEmpty(roleObjectID)) {
			return;
		}

		// 存在チェック
		try {
			// ここは必ずDB(永続層)を見に行くためdao依存でOK。 メニューのロール情報は永続層にしかないため。
			GEditableRoleDao dao = GEditableRoleDao.Factory.getInstance();
			if (dao.findRole(roleObjectID) == null) {
				getErrorList().add(createValidateError(NODEFINED_ROLE_CHECK_ERRORCODE, ROLEID, rowNo));
			}
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * ソート順の単項目チェックを行います.<br>
	 * 
	 * @param sortIndex ソート順
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateSortIndex(int sortIndex) {
		validateSortIndex(sortIndex, -1);
	}

	/**
	 * ソート順の単項目チェックを行います.<br>
	 * 
	 * @param sortIndex ソート順
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateSortIndex(int sortIndex, int rowNo) {
		// マイナス値チェック
		if (sortIndex < -1) {
			getErrorList().add(createValidateError(ILLEGAL_VALUE_ERROR, SORTINDEX, rowNo));
		}

		// 桁数チェック
		if (MENU_SORTINDEX_MAX_DIGITNUMBER < String.valueOf(sortIndex).length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, SORTINDEX, rowNo));
		}
	}

	/**
	 * 起動モジュールの単項目チェックを行います.<br>
	 * 
	 * @param startModule 起動モジュール
	 * @param isItem アイテムフラグ
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateStartModule(String startModule, boolean isItem) {
		validateStartModule(startModule, isItem, -1);
	}

	/**
	 * 起動モジュールの単項目チェックを行います.<br>
	 * 
	 * @param startModule 起動モジュール
	 * @param isItem アイテムフラグ
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateStartModule(String startModule, boolean isItem, int rowNo) {
		startModule = GStringUtils.nullToBlank(startModule);

		if (isItem) {
			// 必須(空文字)チェック
			if (GStringUtils.isEmpty(startModule.trim())) {
				getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, STARTMODULE, rowNo));
				return;
			}

			// 桁数チェック
			if (MENU_STARTMODULE_DIGITNUMBER < startModule.length()) {
				getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, STARTMODULE, rowNo));
			}
		} else {
			// 空文字でなければエラー
			if (!GStringUtils.isEmpty(startModule.trim())) {
				getErrorList().add(createValidateError(CATEGORY_SET_CHECK_ERRORCODE, STARTMODULE, rowNo));
				return;
			}
		}
	}

	/**
	 * 状態の単項目チェックを行います.<br>
	 * 
	 * @param status 状態
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateStatus(String status) {
		validateStatus(status, -1);
	}

	/**
	 * 状態の単項目チェックを行います.<br>
	 * 
	 * @param status 状態
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateStatus(String status, int rowNo) {
		status = GStringUtils.nullToBlank(status).trim();

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(status)) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, STATUS, rowNo));
			return;
		}

		// 許可値チェック
		if (!STATUS_PERMISSION_LIST.contains(status)) {
			getErrorList().add(createValidateError(ILLEGAL_VALUE_ERROR, STATUS, rowNo));
		}
	}

	/**
	 * 更新者の単項目チェックを行います.<br>
	 * 
	 * @param updatedPerson 更新者
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateUpdatedPerson(String updatedPerson, int rowNo) {
		updatedPerson = GStringUtils.nullToBlank(updatedPerson);
		if (GStringUtils.isEmpty(updatedPerson)) {
			return;
		}
		// 桁数チェック
		if (MENU_UPDATEDPERSON_DIGITNUMBER < updatedPerson.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, UPDATEDPERSON, rowNo));
		}
	}

	/**
	 * {@link GValidateError}に必須入力エラーの情報を設定し、返します.<br>
	 * 
	 * @param errorColumn エラー項目
	 * @param rowDataNo 行番号
	 * @return エラー情報
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createRquierdError(String errorColumn, int rowDataNo) {
		return createValidateError(REQUIRED_CHECK_ERRORCODE, errorColumn, rowDataNo);
	}

	/**
	 * {@link GValidateError}にエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorType エラータイプ
	 * @param errorColumn エラー項目
	 * @param labelSpace ラベルスペース
	 * @param description 備考
	 * @param params パラメータ
	 * @return エラー情報
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, GErrorType errorType, String errorColumn,
		String labelSpace, String description, String[] params) {
		GValidateError error = new GValidateError();
		if (errorCode != null) {
			error.setCode(errorCode);
			if (params != null) {
				error.setMessage(GErrorMessages.getErrorMessage(errorCode, params, _locale).getMessage());
			} else {
				error.setMessage(GErrorMessages.getErrorMessage(errorCode, _locale).getMessage());
			}
		}
		if (errorType != null) {
			error.setType(errorType);
		}
		if (errorColumn != null) {
			error.addFieldId(errorColumn);
			error.setLabel(errorColumn);
		}
		if (labelSpace != null) {
			error.setLabelspace(labelSpace);
		}
		if (description != null) {
			error.setDescription(description);
		}

		return error;
	}

	/**
	 * {@link GValidateError}にエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @return エラー情報
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, String errorColumn) {
		return createValidateError(errorCode, errorColumn, GErrorType.ERROR);
	}

	/**
	 * {@link GValidateError}にエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @param errorType エラータイプ
	 * @return エラー情報
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, String errorColumn, GErrorType errorType) {
		return createValidateError(errorCode, errorType, errorColumn, null, null, null);
	}

	/**
	 * {@link GValidateError}にエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @param rowDataNo エラータイプ
	 * @return エラー情報
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, String errorColumn, int rowDataNo) {

		GValidateError error = createValidateError(errorCode, errorColumn);
		if (rowDataNo != -1) {
			error.addFieldId(errorColumn);
			error.setLabelspace(String.valueOf(rowDataNo));
		}

		return error;
	}

	/**
	 * 循環参照チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @param ancetorObjectID 先祖メニューオブジェクトID
	 * @param finder {@link MenuFinder}オブジェクト
	 * @param rowNo 行番号
	 * @return 真偽値
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private boolean checkCircularReferenceRelation(String objectID, String ancetorObjectID, MenuFinder finder, int rowNo) {

		// 親がnullの場合、循環参照ではない
		if (GStringUtils.blankToNull(ancetorObjectID) == null) {
			return false;
		}
		// 自身のObjectIDと先祖のObjectIDを比較
		if (objectID.equals(ancetorObjectID)) {
			// 一致した場合、循環参照発生
			return true;
		} else {
			// 一致しない場合、先祖のメニューを取得
			GEditableMenu ancetorMenu = finder.findMenu(ancetorObjectID);
			if (ancetorMenu == null) {
				// メニューが存在しない場合エラー
				getErrorList().add(createValidateError(ANCETOR_MENU_CHECK_ERRORCODE, PARENTMENUID, rowNo));
				return false;
			} else {
				// メニューが存在する場合、更に親をチェック
				return checkCircularReferenceRelation(objectID, ancetorMenu.getParentObjectID(), finder, rowNo);
			}

		}
	}

}
