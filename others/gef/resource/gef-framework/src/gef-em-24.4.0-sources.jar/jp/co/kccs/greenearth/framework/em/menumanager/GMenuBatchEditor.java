/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.io.File;
import java.net.URL;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateException;

/**
 * MenuManagerの、一括編集操作用インターフェースです.<br>
 * 
 * @create 2011/09/08
 * @author KCCS nishimura
 * @since 3.9.0
 */
public interface GMenuBatchEditor {
	
	/**
	 * 一括編集データを出力します.<br>
	 * 
	 * @param user ユーザー
	 * @param locale ロケール
	 * @return 一括編集データファイル
	 * @throws GResourceProcessingException リソースアクセス時のエラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	File exportFile(GUser user, Locale locale) throws GResourceProcessingException;

	/**
	 * 一括編集データを取り込みます.<br>
	 * 
	 * @param url 一括編集データファイル
	 * @param user ユーザー
	 * @param locale ロケール
	 * @throws GResourceProcessingException リソースアクセス時のエラー
	 * @throws GValidateException ユーザ入力値検証時のエラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void importFile(URL url, GUser user, Locale locale) throws GResourceProcessingException, GValidateException;
}
