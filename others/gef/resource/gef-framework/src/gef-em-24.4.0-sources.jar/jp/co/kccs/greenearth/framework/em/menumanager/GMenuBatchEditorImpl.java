/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.tools.GCounter;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenuValidator.MenuFinder;
import jp.co.kccs.greenearth.framework.em.rolemanager.GEditableRoleValidator;
import jp.co.kccs.greenearth.framework.menu.GEditableMenu;
import jp.co.kccs.greenearth.framework.menu.GEditableMenuDao;
import jp.co.kccs.greenearth.framework.menu.GMenu;

/**
 * EnterpriseManagerV3のMenuManagerの一括編集機能のI/O処理を行うクラスです。
 * 
 * @create 2011/05/11
 * @author KCCS fujimura
 * @since 3.9.0
 */
public class GMenuBatchEditorImpl implements GMenuBatchEditor {

	/** テンプレートの各シート名 */
	private static final String MENU_SHEET = "Menu";
	/** テンプレートの各シート名 */
	private static final String LOCALIZATION_SHEET = "Localization";

	/** Menuシートの列番号 */
	private static final int MENU_SHEET_REQUIRE_CHECK_COLUMN_NO = 0;
	private static final int MENU_SHEET_NO_COLUMN_NO = 1;
	private static final int MENU_SHEET_OBJECTID_COLUMN_NO = 2;
	private static final int MENU_SHEET_MENUID_COLUMN_NO = 3;
	private static final int MENU_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO = 4;
	private static final int MENU_SHEET_MENUNAME_COLUMN_NO = 5;
	private static final int MENU_SHEET_PARENTMENUOBJECTID_COLUMN_NO = 6;
	private static final int MENU_SHEET_APPLICATIONTYPE_COLUMN_NO = 7;
	private static final int MENU_SHEET_MENUTYPE_COLUMN_NO = 8;
	private static final int MENU_SHEET_STARTMODULE_COLUMN_NO = 9;
	private static final int MENU_SHEET_PARAMETER_COLUMN_NO = 10;
	private static final int MENU_SHEET_ISITEM_COLUMN_NO = 11;
	private static final int MENU_SHEET_STATUS_COLUMN_NO = 12;
	private static final int MENU_SHEET_ROLEID_COLUMN_NO = 13;
	private static final int MENU_SHEET_DESCRIPTION_COLUMN_NO = 14;
	private static final int MENU_SHEET_UPDATEDPERSON_COLUMN_NO = 15;
	private static final int MENU_SHEET_UPDATEDDATE_COLUMN_NO = 16;

	/** Localizationシートの列番号 */
	private static final int LOCALIZATION_SHEET_REQUIRE_CHECK_COLUMN_NO = 0;
	private static final int LOCALIZATION_SHEET_NO_COLUMN_NO = 1;
	private static final int LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO = 2;
	private static final int LOCALIZATION_SHEET_VALUE_COLUMN_NO = 3;
	private static final int LOCALIZATION_SHEET_LOCALE_COLUMN_NO = 4;

	/** 明細行の開始インデックス */
	private static final int DATA_START_LINE = 11;
	private static final int END_CELL_COLUMN_NO = 2;

	/** 最終明細行に挿入する文字列 */
	private static final String END = "#END";
	/** #END文字列が無かった場合のエラー数値 */
	private static final int ERROR_NUMBER = -1;

	/** アイテムフラグを表す文字列 */
	private static final String IS_ITEM_TRUE = "1:true";
	private static final String IS_ITEM_FALSE = "0:false";
	private final static List<String> IS_ITEM_PERMISSION_LIST = Arrays.asList(IS_ITEM_TRUE, IS_ITEM_FALSE);
	/** 状態を表す文字列 */
	private static final String STATUS_ACTIVE = "active";
	private static final String STATUS_STOP = "stop";
	private final static List<String> STATUS_PERMISSION_LIST = Arrays.asList(STATUS_ACTIVE, STATUS_STOP);
	/** Menuシートの列項目名 */
	private static final String OBJECTID = "ObjectID";
	private static final String MENUID = "MenuID";
	private static final String DISPLAYNAMERESOURCEID = "DisplayNameResourceID";
	private static final String MENUNAME = "MenuName";
	private static final String PARENTMENUID = "ParentMenuObjectID";
	private static final String MENUTYPE = "MenuType";
	private static final String APPLICATIONTYPE = "ApplicationType";
	private static final String ISITEM = "IsItem";
	private static final String STATUS = "Status";
	private static final String UPDATEDDATE = "UpdatedDate";
	private static final String STARTMODULE = "StartModule";
	private static final String PARAMETER = "Parameter";
	private static final String ROLEID = "RoleObjectID";
	private static final String DESCRIPTION = "Description";
	private static final String UPDATEDPERSON = "UpdatedPerson";
	/** Localizationシートの列項目名 */
	private static final String LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME = "ResourceID";
	private static final String LOCALIZATION_SHEET_VALUE_COLUMN_NAME = "Value";
	private static final String LOCALIZATION_SHEET_LOCALE_COLUMN_NAME = "Locale";

	/** 桁数チェックの各値 */
	private final int LOCALIZATION_SHEET_RESOURCEID_DIGITNUMBER = 36;
	private final int LOCALIZATION_SHEET_VALUE_DIGITNUMBER = 255;
	private final int LOCALIZATION_SHEET_LOCALE_DIGITNUMBER = 20;

	/** エラーコード */
	private final String MAX_STRING_LENGTH_CHECK_ERRORCODE = "GEM-000002";
	private final String SYNTAX_CHECK_ERRORCODE = "GEM-000007";
	/** データが重複しています */
	private final String UNIQUE_CHECK_ERRORCODE = "GEM-000011";
	/** 桁数が不正です */
	private static final String ILLEAGAL_STRING_LENGTH_ERROR = "GEM-000020";
	/** 不正な値が入力された場合のエラー */
	private final String ILLEGAL_VALUE_ERRORCODE = "GEM-000013";
	/** 該当データがありません */
	private final String CONSISTENCY_CHECK_ERRORCODE = "GEM-000008";
	/** 日付型文字列に不備があります。 */
	private final String UPDATEDDATE_CHECK_ERRORCODE = "GEM-000017";
	/** エラーコード */
	public static final String SHEET_FORMAT_ERRORCODE = "GEM-000001";
	/** アプリケーションタイプが存在しません */
	protected final String APPLICATIONTYPE_CHECK_ERRORCODE = "GEM-000012";
	
	/** セルの型が不正です */
	private static final String ILLEGAL_CELL_TYPE_ERRORCODE = "GEM-000030";

	/** DATE_FORMAT */
	private static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss"; // TODO フォーマットを外だしにした方が良い

	/** ユーザー情報出力列番号 */
	private static final int MENU_SHEET_USERINFORMATION_COLUMN_NO = 15;
	/** ユーザー情報出力行番号 */
	private static final int MENU_SHEET_USERINFORMATION_COMPANYCD_ROW_NO = 1;
	private static final int MENU_SHEET_USERINFORMATION_USERID_ROW_NO = 2;
	private static final int MENU_SHEET_USERINFORMATION_USERNAME_ROW_NO = 3;
	private static final int MENU_SHEET_USERINFORMATION_LOCALE_ROW_NO = 4;
	private static final int MENU_SHEET_USERINFORMATION_EXPORTTIME_ROW_NO = 5;

	/** エクスポートファイル一時保管ディレクトリパスのプロパティキー */
	private static final String EXPORTFILE_TEMPORARY_DIRECTORY = "geframe.em.File.TempDirectory";

	/** デフォルトバッファサイズ */
	private int _bufferSize = 512;
	private String _templatePath = null;

	public GMenuBatchEditorImpl(String templatePath) {
		this._templatePath = templatePath;
	}

	public GMenuBatchEditorImpl(String templatePath, int bufferSize) {
		this(templatePath);
		this._bufferSize = bufferSize;
	}

	public GEditableMenuDao getMenuDao() {
		return GEditableMenuDao.Factory.getInstance();
	}

	/**
	 * メニュー情報をエクセルファイルに出力するメソッド.<br>
	 * 【出力ファイル形式 .xlsの理由】<br>
	 * 現在のEnterpriseManagerV3では、.xls形式の出力となっています。<br>
	 * 今回のエクセル出力用テンプレートにはマクロが含まれております。<br>
	 * 現時点でのPOIでは、マクロを出力する為のクラスは.xls形式のものしか提供されていない為です。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GMenuIOCreatable#exportData(java.lang.String,
	 *      java.lang.String, java.util.Locale)
	 * @param companyCode
	 * @param ObjectID
	 * @param locale
	 * @return file エクセルファイル
	 * @throws GResourceProcessingException
	 * @create 2010/11/11
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	@Override
	public File exportFile(GUser user, Locale locale) throws GResourceProcessingException {
		// 最上位メニューを呼び出す。
		List<GMenu> menulist = getMenuDao().findRootMenuList(user.getCompany().getCode());

		InputStream in = null;
		OutputStream out = null;
		try {

			// ワークブックオブジェクト作成(xls形式ワークブック)
			in = new BufferedInputStream(GFileUtils.getResource(_templatePath).openStream(), _bufferSize);
			Workbook workbook = new HSSFWorkbook(in);

			// 行番号
			GCounter menuRowCounter = new GCounter();
			GCounter localizationRowCounter = new GCounter();

			// Excelシートに書き込む処理
			writeUserInformation(workbook, user, locale);

			writeMenuList(workbook, menulist, locale, menuRowCounter, localizationRowCounter);

			writeEndData(workbook,menuRowCounter,localizationRowCounter);

			// 新規ファイルを作成する
			File excelFile = createFile();
			out = new BufferedOutputStream(new FileOutputStream(excelFile), _bufferSize);
			// 作成したファイルにエクセル情報を書き込む
			workbook.write(out);

			return excelFile;
		} catch (IOException e) {
			throw new GResourceProcessingException(e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				throw new GResourceProcessingException(e);
			}
		}
	}

	/**
	 * MenuSetの情報からExcelファイルのMenuシート、Localizationシートに、データを出力するメソッドです。<br>
	 * 
	 * @param workbook
	 * @param menuSet
	 * @param locale
	 * @create 2010/11/12
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeMenuList(Workbook workbook, List<GMenu> menuList, Locale locale, GCounter menuRowCounter,
		GCounter localizationRowCounter) throws GResourceProcessingException {
		for (GMenu m : menuList) {
			GEditableMenu menu = (GEditableMenu) m;
			writeMenu(workbook, menu, locale, menuRowCounter, localizationRowCounter);
			menuRowCounter.countUp();

			if (!menu.isItem()) {
				writeMenuList(workbook, menu.getChildren(), locale, menuRowCounter, localizationRowCounter);
			}
		}
	}

	/**
	 * Menuシートにデータを書き込みます。
	 * 
	 * @param menuSheet
	 * @param localizationSheet
	 * @param menu
	 * @param locale
	 * @param menuDataNo
	 * @create 2011/01/28
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeMenu(Workbook workbook, GEditableMenu menu, Locale locale, GCounter menuRowCounter, GCounter localizationRowCounter) {
		// シートの取得する
		Sheet menuSheet = workbook.getSheet(MENU_SHEET);
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		// ※POIではエクセル上のを0行目からカウントする
		Row menuSheetRow = menuSheet.createRow(menuRowCounter.getCount() + DATA_START_LINE);

		// Menuシートデータ入力処理
		// 列A:必須チェック(IF関数)
		// //※エクセルシート上のインデックスは1から始まるので開始行に+1
		int menuSheetRowNo = menuRowCounter.getCount() + DATA_START_LINE + 1;
		StringBuilder role_sb = new StringBuilder();
		role_sb.append("IF(C").append(menuSheetRowNo);
		role_sb.append("=\"\",\"NG\",IF(D").append(menuSheetRowNo);
		role_sb.append("=\"\",\"NG\",IF(E").append(menuSheetRowNo);
		role_sb.append("=\"\",\"NG\",IF(H").append(menuSheetRowNo);
		role_sb.append("=\"\",\"NG\",IF(L").append(menuSheetRowNo);
		role_sb.append("=\"\",\"NG\",IF(M").append(menuSheetRowNo);
		role_sb.append("=\"\",\"NG\",\"OK\"))))))");
		Cell menuSheetRequireCheckCell = menuSheetRow.createCell(MENU_SHEET_REQUIRE_CHECK_COLUMN_NO);
		menuSheetRequireCheckCell.setCellFormula(role_sb.toString());

		// 列B:No　※No項目は1から始まる為+1
		Cell menuSheetNoCell = menuSheetRow.createCell(MENU_SHEET_NO_COLUMN_NO);
		menuSheetNoCell.setCellValue(menuRowCounter.getCount() + 1);

		// 列C:ObjectID
		Cell objectIDCell = menuSheetRow.createCell(MENU_SHEET_OBJECTID_COLUMN_NO);
		objectIDCell.setCellValue(menu.getObjectID());

		// 列D:MenuID
		Cell menuIDCell = menuSheetRow.createCell(MENU_SHEET_MENUID_COLUMN_NO);
		menuIDCell.setCellValue(menu.getMenuID());

		// 列E:DisplayNameResourceID
		Cell displayNameResourceIDCell = menuSheetRow.createCell(MENU_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);
		displayNameResourceIDCell.setCellValue(menu.getDisplayNameResourceID());

		// 列F:MenuName
		Cell menuNameCell = menuSheetRow.createCell(MENU_SHEET_MENUNAME_COLUMN_NO);
		menuNameCell.setCellValue(menu.getDisplayNameMap().get(locale));

		// 列G:ParentMenuID
		Cell parentMenuObjectIDCell = menuSheetRow.createCell(MENU_SHEET_PARENTMENUOBJECTID_COLUMN_NO);
		parentMenuObjectIDCell.setCellValue(menu.getParentObjectID());

		// 列H:ApplicationType
		Cell applicationTypeCell = menuSheetRow.createCell(MENU_SHEET_APPLICATIONTYPE_COLUMN_NO);
		applicationTypeCell.setCellValue(menu.getApplicationType());

		// 列I:MenuType
		Cell menuTypeCell = menuSheetRow.createCell(MENU_SHEET_MENUTYPE_COLUMN_NO);
		menuTypeCell.setCellValue(menu.getMenuType());

		// 列J:StartModule
		Cell startModuleCell = menuSheetRow.createCell(MENU_SHEET_STARTMODULE_COLUMN_NO);
		startModuleCell.setCellValue(menu.getStartModule());

		// 列K:Parameter
		Cell parameterCell = menuSheetRow.createCell(MENU_SHEET_PARAMETER_COLUMN_NO);
		parameterCell.setCellValue(menu.getParameter());

		// 列L:IsItem
		Cell isItemCell = menuSheetRow.createCell(MENU_SHEET_ISITEM_COLUMN_NO);
		isItemCell.setCellValue(menu.isItem() ? IS_ITEM_TRUE : IS_ITEM_FALSE);

		// 列M:Status
		Cell statusCell = menuSheetRow.createCell(MENU_SHEET_STATUS_COLUMN_NO);
		// statusCell.setCellValue("0".equals(menu.getStatus()) ? STATUS_ACTIVE
		// : STATUS_STOP);
		statusCell.setCellValue(GStatus.Active == menu.getStatus() ? STATUS_ACTIVE : STATUS_STOP);

		// 列N:RoleID
		Cell roleIDCell = menuSheetRow.createCell(MENU_SHEET_ROLEID_COLUMN_NO);
		GEditableRole role = (GEditableRole) menu.getRole();
		if (role != null) {
			roleIDCell.setCellValue(role.getObjectID());
		}

		// 列O:Description
		Cell descriptionCell = menuSheetRow.createCell(MENU_SHEET_DESCRIPTION_COLUMN_NO);
		descriptionCell.setCellValue(menu.getDescription());

		// 列P:UpdatedPerson
		Cell updatedPersonCell = menuSheetRow.createCell(MENU_SHEET_UPDATEDPERSON_COLUMN_NO);
		updatedPersonCell.setCellValue(menu.getUpdatedPerson());

		// 列Q:UpdatedDate
		Cell updatedDateCell = menuSheetRow.createCell(MENU_SHEET_UPDATEDDATE_COLUMN_NO);
		GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		updatedDateCell.setCellValue(formatter.format(menu.getUpdatedDate(), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT));

		// ロールのgetDisplayName()のサイズ分取り出すfor文
		for (Locale localizationLocale : menu.getDisplayNameMap().keySet()) {
			writeDisplayName(localizationSheet, menu, localizationLocale, localizationRowCounter);
			localizationRowCounter.countUp();
		}
	}

	/**
	 * 最終行に終了文字列を書き込みます。
	 * 
	 * @param menuSheet
	 * @param localizationSheet
	 * @create 2011/01/28
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeEndData(Workbook workbook, GCounter menuRowCounter, GCounter localizationRowCounter) {
		// シートの取得する
		Sheet menuSheet = workbook.getSheet(MENU_SHEET);
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		// 最終明細行の次の行に最終行である事を表す文字列を挿入
		// Menuシート
		writeEndMenuData(menuSheet,menuRowCounter);
		// Localizationシート
		writeEndLocalizationData(localizationSheet,localizationRowCounter);
	}

	/**
	 * Menuシートの最終行に終了文字列を書き込みます。
	 * 
	 * @param menuSheet
	 * @create 2011/01/28
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeEndMenuData(Sheet menuSheet, GCounter menuRowCounter) {
		Row roleSheetRow = menuSheet.createRow(menuRowCounter.getCount() + DATA_START_LINE);
		Cell objectIDCell = roleSheetRow.createCell(MENU_SHEET_OBJECTID_COLUMN_NO);
		objectIDCell.setCellValue(END);
	}

	/**
	 * Localizationシートの最終行に終了文字列を書き込みます。
	 * 
	 * @param localizationSheet
	 * @create 2011/01/28
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeEndLocalizationData(Sheet localizationSheet, GCounter localizationRowCounter) {
		Row localizationSheetRow = localizationSheet.createRow(localizationRowCounter.getCount() + DATA_START_LINE);
		Cell displayNameResourceIDCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
		displayNameResourceIDCell.setCellValue(END);
	}

	/**
	 * Localizationシートにデータの書き込みを行います。
	 * 
	 * @param localizationSheet
	 * @param menu
	 * @param locale
	 * @param localizationDataNo
	 * @create 2011/01/28
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeDisplayName(Sheet localizationSheet, GEditableMenu menu, Locale locale,
		GCounter localizationRowCounter) {
		// ※行は0行目からカウントされる
		Row localizationSheetRow = localizationSheet.createRow(localizationRowCounter.getCount() + DATA_START_LINE);

		// ※列も0番目からカウントされる
		// 列A:必須チェック(IF関数)
		int localizationSheetRowNo = localizationRowCounter.getCount() + DATA_START_LINE + 1;
		StringBuilder localization_sb = new StringBuilder();
		localization_sb.append("IF(C").append(localizationSheetRowNo);
		localization_sb.append("=\"\",\"NG\",IF(E").append(localizationSheetRowNo);
		localization_sb.append("=\"\",\"NG\",\"OK\"))");
		Cell localizationSheetRequireCheckCell =
			localizationSheetRow.createCell(LOCALIZATION_SHEET_REQUIRE_CHECK_COLUMN_NO);
		localizationSheetRequireCheckCell.setCellFormula(localization_sb.toString());

		// 列B:No
		Cell localizationNoCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_NO_COLUMN_NO);
		localizationNoCell.setCellValue(localizationRowCounter.getCount() + 1);

		// 列C:ResourceID
		Cell localizationSheetDisplayNameResourceIDCell =
			localizationSheetRow.createCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
		localizationSheetDisplayNameResourceIDCell.setCellValue(menu.getDisplayNameResourceID());

		// 列D:メニュー名
		Cell localizationSheetMenuNameCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);
		localizationSheetMenuNameCell.setCellValue(menu.getDisplayNameMap().get(locale));

		// 列E:ロケール
		Cell localizationLocaleCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
		localizationLocaleCell.setCellValue(locale.toString());
	}

	/**
	 * 引数に与えられた項目を元に、洗い替えを行います。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GMenuIOCreatable#importData(java.lang.String,
	 *      java.lang.String, java.io.InputStream, java.util.Locale)
	 *      
	 * @param url インポートするリソースURL
	 * @param user ユーザ
	 * @param locale ロケール
	 * 
	 * @throws GResourceProcessingException 例外
	 * @throws GValidateException　例外
	 * @create 2010/11/13
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	@Override
	public void importFile(URL url, GUser user, Locale locale) throws GResourceProcessingException,
		GValidateException {
		InputStream in = null;
		try {
			in = url.openStream();
			InputStream stream = new BufferedInputStream(in, _bufferSize);
			Workbook workbook = new HSSFWorkbook(stream);

			// 入力チェックを行う
			validateWorkbook(workbook, locale);

			// 登録処理(洗替)を行う
			// GEMenuテーブルとGEMenuLocalizationResourceテーブルを全件削除する。
			getMenuDao().deleteMenuAll(user.getCompany().getCode());
			insertWorkbook(workbook, user);
		} catch (IOException e) {
			throw new GResourceProcessingException(e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException ioe) {
					throw new GResourceProcessingException(ioe);
				}
			}
		}
	}

	protected void validateWorkbook(Workbook workbook, Locale locale) throws GValidateException,
		GResourceProcessingException {
		// MenuとLocalizationシートのチェッククラスの作成
		GEditableMenuValidator validator = new GEditableMenuValidator(locale);

		// シートを取得
		Sheet menuSheet = workbook.getSheet(MENU_SHEET);
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		// シートの前提条件チェック(①両シートがあるか②#END文字列が両シートにあるかチェック)
		checkSheetExist(menuSheet, localizationSheet, validator);

		int menuLastRowDataNum = getEndCellRowNumber(menuSheet);
		int localizationLastRowDataNum = getEndCellRowNumber(localizationSheet);
		MenuFinder finder = new ExcelMenuFinder(menuSheet, menuLastRowDataNum);
		validator.setMenuFinder(finder);

		checkEndWordExist(menuLastRowDataNum, localizationLastRowDataNum, validator);

		// 解析処理①単項目チェック(必須、桁数、構文)
		checkSingleItem(validator, menuSheet, menuLastRowDataNum);
		checkSingleItemLocalization(validator, localizationSheet, localizationLastRowDataNum);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

		// 解析処理②相関チェック(整合性、ユニーク)
		checkCorrelation(validator, menuSheet, menuLastRowDataNum, localizationSheet, localizationLastRowDataNum);
		checkCorrelationLocalization(validator, localizationSheet, localizationLastRowDataNum, menuSheet,
			menuLastRowDataNum);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}
	}

	private class ExcelMenuFinder implements MenuFinder {

		private Map<String, GEditableMenu> _map = new HashMap<String, GEditableMenu>();

		private ExcelMenuFinder(Sheet menuSheet, int lastRowDataNum) {
			// 明細行チェック
			for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
				int rowNo = DATA_START_LINE + i;
				// 明細行を一行ずつ取得する
				Row row = menuSheet.getRow(rowNo);

				// 行がnullならチェックしない
				if (row == null) {
					continue;
				}

				Cell objectIDCell = row.getCell(MENU_SHEET_OBJECTID_COLUMN_NO);
				if (objectIDCell == null || objectIDCell.getCellType() != CellType.STRING) {
					continue;
				}
				String objectID = objectIDCell.getStringCellValue();

				String parentMenuObjectID = null;
				Cell parentMenuObjectIDCell = row.getCell(MENU_SHEET_PARENTMENUOBJECTID_COLUMN_NO);
				if(parentMenuObjectIDCell != null){
					if(parentMenuObjectIDCell.getCellType() == CellType.STRING){
						parentMenuObjectID = parentMenuObjectIDCell.getStringCellValue();
					}
				}
	
				Cell isItemCell = row.getCell(MENU_SHEET_ISITEM_COLUMN_NO);
				String isItem = isItemCell != null && isItemCell.getCellType() == CellType.STRING ? isItemCell.getStringCellValue() : null;

				GEditableMenu menu = getMenuDao().createMenu();
				menu.setObjectID(objectID);
				menu.setParentObjectID(parentMenuObjectID);
				menu.setIsItem(IS_ITEM_TRUE.equals(isItem));
				_map.put(objectID, menu);
			}
		}

		public GEditableMenu findMenu(String objectID) {
			return _map.get(objectID);
		}

	}

	private void checkSheetExist(Sheet roleSheet, Sheet localizationSheet, GEditableMenuValidator validator)
		throws GValidateException {
		if (roleSheet == null) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, MENU_SHEET);
		}
		if (localizationSheet == null) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, LOCALIZATION_SHEET);
		}
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}
	}

	/**
	 * エクセルシートの特定の列にあるEND文字列を検索します。<br>
	 * END文字列があれば、その行番号を返します。END文字列が無ければ、-1を返します。<br>
	 * エクセル用<br>
	 * 
	 * @param menuSheet
	 * @return int 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private int getEndCellRowNumber(Sheet menuSheet) {

		for (int i = 0; i < menuSheet.getLastRowNum(); i++) {
			Row row = menuSheet.getRow(DATA_START_LINE + i);

			if (row == null) {
				continue;
			}

			Cell cellValue = row.getCell(END_CELL_COLUMN_NO);

			if (cellValue == null || cellValue.getCellType() != CellType.STRING) {
				continue;
			}
			String value = cellValue.getStringCellValue().trim();
			if (value.equals(END)) {
				return DATA_START_LINE + i;
			}
		}
		return ERROR_NUMBER;
	}

	private void checkEndWordExist(int roleLastRowDataNum, int localizationLastRowDataNum,
		GEditableMenuValidator validator) throws GValidateException {
		if (roleLastRowDataNum == ERROR_NUMBER) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, MENU_SHEET);
		}

		if (localizationLastRowDataNum == ERROR_NUMBER) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, LOCALIZATION_SHEET);
		}
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}
	}

	/**
	 * {@link GMenu}のインポート解析処理において、単項目チェックを行うメソッドです。<br>
	 * 単項目チェックでは、以下の内容をチェックします。<br>
	 * ①必須 ②桁数 ③構文チェック　or 許可値チェック<br>
	 * エクセル用<br>
	 * 
	 * @param roleSheet
	 * @param menuLastRowDataNum
	 * @param errorList
	 * @param locale
	 * @create 2010/11/15
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItem(GEditableMenuValidator validator, Sheet menuSheet, int lastRowDataNum) {

		// Excelの実際の行番号変数
		int rowNo = 0;

		// 明細行チェック
		for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
			rowNo = DATA_START_LINE + i;

			// 明細行を一行ずつ取得する
			Row row = menuSheet.getRow(rowNo);

			// 行がnullならチェックしない
			if (row == null) {
				continue;
			}

			// オブジェクトIDの単項目チェック
			checkSingleItemObjectID(validator, row, i + 1);

			// メニューIDの単項目チェック
			checkSingleItemMenuID(validator, row, i + 1);

			// 表示名の単項目チェック
			checkSingleItemDisplayNameResourceID(validator, row, i + 1);

			// メニュー名の単項目チェック
			checkSingleItemMenuName(validator, row, i + 1);

			// 親メニューIDの単項目チェック
			checkSingleItemParentMenuID(validator, row, i + 1);

			// 起動パラメータの単項目チェック
			checkSingleItemParameter(validator, row, i + 1);

			// アイテムフラグ/アプリケーションタイプ/メニュータイプ/起動モジュールの単項目チェック
			checkSingleItemIsItem_AppType_MenuType_StartupModule(validator, row, i + 1);

			// 状態の単項目チェック
			checkSingleItemStatus(validator, row, i + 1);

			// ロールIDの単項目チェック
			checkSingleItemRoleID(validator, row, i + 1);

			// 備考の単項目チェック
			checkSingleItemDescription(validator, row, i + 1);

			// 更新者の単項目チェック処理
			checkSingleItemUpdatedPerson(validator, row, i + 1);

			// 更新日の単項目チェック処理
			checkSingleItemUpdatedDate(validator, row, i + 1);
		}
	}

	/**
	 * {@link GMenu}のインポート解析処理において、オブジェクトIDの単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 * 
	 * @param row
	 * @param errorList
	 * @param rowDataNo
	 * @param locale
	 * @create 2010/11/15
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemObjectID(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell objectIDCell = row.getCell(MENU_SHEET_OBJECTID_COLUMN_NO);

		// オブジェクトIDの必須(null)チェック
		if (objectIDCell == null || objectIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(OBJECTID, rowDataNo));
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != objectIDCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, OBJECTID, rowDataNo);
			return;
		}

		String objectID = objectIDCell.getStringCellValue();
		validator.validateObjectID(objectID, rowDataNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、MenuIDの単項目チェックを行うメソッドです。<br>
	 * 必須、桁数チェック
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemMenuID(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell menuIDCell = row.getCell(MENU_SHEET_MENUID_COLUMN_NO);

		// 必須(null)チェック
		if (menuIDCell == null || menuIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(MENUID, rowDataNo));
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != menuIDCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, MENUID, rowDataNo);
			return;
		}

		String menuID = menuIDCell.getStringCellValue();
		validator.validateMenuID(menuID, rowDataNo);
	}

	/**
	 * {@link GMenu} のインポート解析処理において、表示名の単項目チェックを行うメソッドです。<br>
	 * 必須、桁数チェック
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemDisplayNameResourceID(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell displayNameResourceIDCell = row.getCell(MENU_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);

		// 必須(null)チェック
		if (displayNameResourceIDCell == null || displayNameResourceIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(DISPLAYNAMERESOURCEID, rowDataNo));
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != displayNameResourceIDCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, DISPLAYNAMERESOURCEID, rowDataNo);
			return;
		}

		// 必須(空文字)チェック
		String displayNameResourceID = displayNameResourceIDCell.getStringCellValue();
		validator.validateDisplayNameResourceID(displayNameResourceID, rowDataNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、メニュー名の単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemMenuName(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell menuNameCell = row.getCell(MENU_SHEET_MENUNAME_COLUMN_NO);
		// 項目がnullだった場合、以下の処理は行わない。
		if (menuNameCell == null || menuNameCell.getCellType() == CellType.BLANK) {
			return;
		}

		// セルのタイプチェック
		if (CellType.STRING != menuNameCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, MENUNAME, rowDataNo);
			return;
		}
		
		String menuName = menuNameCell.getStringCellValue();
		validator.validateDisplayName(menuName, rowDataNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、親メニューIDの単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ(nullの場合はチェックしない)
	 * 
	 * @param validator チェッククラス
	 * @param row　行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemParentMenuID(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell parentMenuIDCell = row.getCell(MENU_SHEET_PARENTMENUOBJECTID_COLUMN_NO);

		if (parentMenuIDCell == null || parentMenuIDCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != parentMenuIDCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, PARENTMENUID, rowNo);
			return;
		}

		String parentMenuObjectID = parentMenuIDCell.getStringCellValue();
		validator.validateParentObjectIDBasic(parentMenuObjectID, rowNo);
		validator.validateParentObjectIDExisted(parentMenuObjectID, rowNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、アプリケーションタイプの単項目チェックを行うメソッドです。<br>
	 * 必須、桁数、許可値チェック<br>
	 * エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/08/01
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private void checkSingleItemApplicationType(GEditableMenuValidator validator, Row row, int rowDataNo) {
		
		Cell applicationTypeCell = row.getCell(MENU_SHEET_APPLICATIONTYPE_COLUMN_NO);
		// 必須(null)チェック
		if (applicationTypeCell == null || applicationTypeCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(APPLICATIONTYPE, rowDataNo));
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != applicationTypeCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, APPLICATIONTYPE, rowDataNo);
			return;
		}
		
		String applicationType = applicationTypeCell.getStringCellValue();
		validator.validateApplicationType(applicationType, isItem(row), rowDataNo);
	}

	/**
	 * エクセルのISITEM項目に入っている値が"アイテム"であるかを判定します。<br>
	 * カテゴリやアイテム以外のものであればfalseを返します。
	 * 
	 * @param row 行
	 * @return アイテムならtrue/それ以外ならfalse
	 * @create 2011/08/03
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	private boolean isItem(Row row) {
		Cell isItemCell = row.getCell(MENU_SHEET_ISITEM_COLUMN_NO);
		if (isItemCell == null || isItemCell.getCellType() == CellType.BLANK) {
			return false;
		}
		return IS_ITEM_TRUE.equals(isItemCell.getStringCellValue());
	}

	/**
	 * {@link GMenu}のインポート解析処理において、メニュータイプの単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ<br>
	 * エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemMenuType(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell menuTypeCell = row.getCell(MENU_SHEET_MENUTYPE_COLUMN_NO);
		if (menuTypeCell == null || menuTypeCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != menuTypeCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, MENUTYPE, rowNo);
			return;
		}
		
		String menuType = menuTypeCell.getStringCellValue();
		validator.validateMenuType(menuType, isItem(row), rowNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、起動モジュールの単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ<br>
	 * エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since
	 */
	private void checkSingleItemStartModule(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell startModuleCell = row.getCell(MENU_SHEET_STARTMODULE_COLUMN_NO);
		boolean isItem = isItem(row);
		if (isItem) {
			// アイテム  必須チェック
			if (startModuleCell == null || startModuleCell.getCellType() == CellType.BLANK) {
				validator.getErrorList().add(validator.createRquierdError(STARTMODULE, rowNo));
				return;
			}
		} else {
			// カテゴリ　未入力は終了
			if (startModuleCell == null || startModuleCell.getCellType() == CellType.BLANK) {
				return;
			}
		}

		// セルのタイプチェック
		if (CellType.STRING != startModuleCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, STARTMODULE, rowNo);
			return;
		}
		
		String startModule = startModuleCell.getStringCellValue();
		validator.validateStartModule(startModule, isItem, rowNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、起動パラメータの単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ<br>
	 * エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemParameter(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell parameterCell = row.getCell(MENU_SHEET_PARAMETER_COLUMN_NO);

		if (parameterCell == null || parameterCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != parameterCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, PARAMETER, rowNo);
			return;
		}

		String parameter = parameterCell.getStringCellValue();
		validator.validateParameter(parameter, rowNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、状態の単項目チェックを行うメソッドです。<br>
	 * 必須、許可値チェック<br>
	 * エクセル用<br>
	 * 
	 * @param row
	 * @param errorList
	 * @param rowNo
	 * @param locale
	 * @create 2010/11/16
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemStatus(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell statusCell = row.getCell(MENU_SHEET_STATUS_COLUMN_NO);

		// 必須(null)チェック
		if (statusCell == null || statusCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(STATUS, rowNo));
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != statusCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, STATUS, rowNo);
			return;
		}

		// 必須(空文字)チェック
		String status = statusCell.getStringCellValue();
		status = GStringUtils.nullToBlank(status);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(status.trim())) {
			validator.getErrorList().add(validator.createRquierdError(STATUS, rowNo));
			return;
		}

		// 許可値チェック
		if (!STATUS_PERMISSION_LIST.contains(status)) {
			validator.addValidateError(ILLEGAL_VALUE_ERRORCODE, STATUS, rowNo);
		}
	}

	/**
	 * {@link GMenu}のインポート解析処理において、ロールIDの単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ<br>
	 * エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemRoleID(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell roleIDCell = row.getCell(MENU_SHEET_ROLEID_COLUMN_NO);

		if (roleIDCell == null || roleIDCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != roleIDCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, ROLEID, rowNo);
			return;
		}

		String roleObjectID = roleIDCell.getStringCellValue();
		validator.validateRoleObjectID(roleObjectID, rowNo);
		validator.validateRoleObjectIDExisted(roleObjectID, rowNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、備考の単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ<br>
	 * エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemDescription(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell descriptionCell = row.getCell(MENU_SHEET_DESCRIPTION_COLUMN_NO);

		if (descriptionCell == null || descriptionCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != descriptionCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, DESCRIPTION, rowNo);
			return;
		}

		String description = descriptionCell.getStringCellValue();
		validator.validateDescription(description, rowNo);
	}

	/**
	 * {@link GMenu}のインポート解析処理において、更新者の単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ<br>
	 * エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemUpdatedPerson(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell updatedPersonCell = row.getCell(MENU_SHEET_UPDATEDPERSON_COLUMN_NO);

		if (updatedPersonCell == null || updatedPersonCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != updatedPersonCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, UPDATEDPERSON, rowDataNo);
			return;
		}

		String updatedPerson = updatedPersonCell.getStringCellValue();
		validator.validateUpdatedPerson(updatedPerson, rowDataNo);

	}

	/**
	 * {@link GMenu}のインポート解析処理において、更新日の単項目チェックを行うメソッドです。<br>
	 *       エクセル用<br>
	 * 
	 * @param validator チェッククラス
	 * @param row　行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/07
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemUpdatedDate(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell updatedDateCell = row.getCell(MENU_SHEET_UPDATEDDATE_COLUMN_NO);

		if (updatedDateCell == null || updatedDateCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != updatedDateCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, UPDATEDDATE, rowDataNo);
			return;
		}

		try {
			String updatedDateStr = updatedDateCell.getStringCellValue();
			GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
			formatter.parse(updatedDateStr, GFrameworkUtils.getDefaultLocale(), DATE_FORMAT);
		} catch (ParseException e) {
			validator.getErrorList().add(
				validator.createValidateError(UPDATEDDATE_CHECK_ERRORCODE, UPDATEDDATE, rowDataNo));
			return;
		}
	}

	/**
	 * {@link GMenu}のインポート解析処理において、アイテムフラグ/アプリケーションタイプ/メニュータイプ/起動モジュールの単項目チェックを行うメソッドです。<br>
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemIsItem_AppType_MenuType_StartupModule(GEditableMenuValidator validator, Row row, int rowNo) {
		Cell isItemCell = row.getCell(MENU_SHEET_ISITEM_COLUMN_NO);

		// 必須(null)チェック
		if (isItemCell == null || isItemCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(ISITEM, rowNo));
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != isItemCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, ISITEM, rowNo);
			return;
		}

		String isItem = isItemCell.getStringCellValue();
		isItem = GStringUtils.nullToBlank(isItem);
		if (GStringUtils.isEmpty(isItem.trim())) {
			validator.getErrorList().add(validator.createRquierdError(ISITEM, rowNo));
			return;
		}

		// 許可値チェック
		if (!IS_ITEM_PERMISSION_LIST.contains(isItem)) {
			validator.addValidateError(ILLEGAL_VALUE_ERRORCODE, ISITEM, rowNo);
			return;
		}
		
		// アプリケーションタイプの単項目チェック
		checkSingleItemApplicationType(validator, row, rowNo);
		// メニュータイプの単項目チェック
		checkSingleItemMenuType(validator, row, rowNo);
		// 起動モジュールの単項目チェック
		checkSingleItemStartModule(validator, row, rowNo);
	}

	/**
	 * 
	 * 
	 * @param localizationSheet
	 * @param lastRowDataNum
	 * @param errorList
	 * @param locale
	 * @create 2010/11/15
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemLocalization(GEditableMenuValidator validator, Sheet localizationSheet, int lastRowDataNum) {
		// Excelの実際の行番号変数
		int rowNo = 0;

		// 明細行チェック
		for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
			rowNo = DATA_START_LINE + i;

			// 明細行を一行ずつ取得する
			Row row = localizationSheet.getRow(rowNo);

			// 行がnullならチェックしない
			if (row == null) {
				continue;
			}

			// ResourceIDの単項目チェック
			checkSingleItemResourceID(validator, row, i + 1);
			// 値の単項目チェック
			checkSingleItemValue(validator, row, i + 1);
			// 地域コードの単項目チェック
			checkSingleItemLocale(validator, row, i + 1);
		}
	}

	/**
	 * メニューのインポート解析処理において、ResourceIDの単項目チェックを行うメソッドです。<br>
	 * 必須、桁数チェック
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemResourceID(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell resourceIDCell = row.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);

		// 必須(null)チェック
		if (resourceIDCell == null || resourceIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(
				validator.createRquierdError(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo));
			return;
		}
		// セルのタイプチェック
		if (CellType.STRING != resourceIDCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo);
			return;
		}
		// 必須(空文字)チェック
		String resourceID = resourceIDCell.getStringCellValue();
		resourceID = GStringUtils.nullToBlank(resourceID);
		if (GStringUtils.isEmpty(resourceID.trim())) {
			validator.getErrorList().add(
				validator.createRquierdError(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo));
			return;
		}

		// 桁数チェック
		if (LOCALIZATION_SHEET_RESOURCEID_DIGITNUMBER != resourceID.length()) {
			// validator.addValidateError(ILLEAGAL_STRING_LENGTH_ERROR,
			// LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo);
			String[] params = new String[] {String.valueOf(LOCALIZATION_SHEET_RESOURCEID_DIGITNUMBER)};
			GEditableRoleValidator roleValidator = new GEditableRoleValidator();
			validator.getErrorList().add(
				roleValidator.createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR,
					LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, String.valueOf(rowDataNo), null, params));

		}
	}

	/**
	 * メニューのインポート解析処理において、値の単項目チェックを行うメソッドです。<br>
	 * 桁数チェックのみ
	 * 
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemValue(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell valueCell = row.getCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);

		// nullだったらチェックしない
		if (valueCell == null || valueCell.getCellType() == CellType.BLANK) {
			return;
		}
		
		// セルのタイプチェック
		if (CellType.STRING != valueCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, LOCALIZATION_SHEET_VALUE_COLUMN_NAME, rowDataNo);
			return;
		}

		String value = valueCell.getStringCellValue();
		value = GStringUtils.nullToBlank(value);

		if (GStringUtils.isEmpty(value)) {
			return;
		}

		// 桁数チェック
		if (LOCALIZATION_SHEET_VALUE_DIGITNUMBER < value.length()) {
			validator.addValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, LOCALIZATION_SHEET_VALUE_COLUMN_NAME,
				rowDataNo);
		}
	}

	/**
	 * メニューのインポート解析処理において、ロケールの単項目チェックを行うメソッドです。<br>
	 * 必須、桁数、構文チェックのみ
	 * 
	 * @param row
	 * @param errorList
	 * @param rowDataNo
	 * @param locale
	 * @create 2010/11/16
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemLocale(GEditableMenuValidator validator, Row row, int rowDataNo) {
		Cell localeCell = row.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);

		// 必須(null)チェック
		if (localeCell == null || localeCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo));
			return;
		}

		// セルのタイプチェック
		if (CellType.STRING != localeCell.getCellType()) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo);
			return;
		}

		String localeStr = localeCell.getStringCellValue();
		localeStr = GStringUtils.nullToBlank(localeStr);
		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(localeStr)) {
			validator.getErrorList()
				.add(validator.createRquierdError(LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo));
			return;
		}

		// ロケールの桁数チェック
		if (LOCALIZATION_SHEET_LOCALE_DIGITNUMBER < localeStr.length()) {
			validator.addValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, LOCALIZATION_SHEET_LOCALE_COLUMN_NAME,
				rowDataNo);
			return;
		}

		// 構文チェック
		boolean localeFlag = GLocaleUtils.checkLocaleSyntax(localeStr);
		if (!localeFlag) {
			validator.addValidateError(SYNTAX_CHECK_ERRORCODE, LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo);
		}
	}

	/**
	 * {@link GMenu}のインポート解析処理において、相関チェックを行うメソッドです。<br>
	 * 相関チェックでは、以下の内容をチェックします。<br>
	 * ①ユニーク<br>
	 * ②整合性<br>
	 * エクセル用<br>
	 * 
	 * @param menuSheet
	 * @param localizationSheet
	 * @param lastRowDataNum
	 * @param errorList
	 * @param locale
	 * @throws GResourceProcessingException
	 * @create 2010/11/15
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkCorrelation(GEditableMenuValidator validator, Sheet menuSheet, int lastRowDataNum,
		Sheet localizationSheet, int localizationLastIndex) throws GResourceProcessingException {
		// オブジェクトIDの相関チェック処理(ユニークチェックのみ)
		checkUniqueObjectID(validator, menuSheet, lastRowDataNum);

		// メニューIDの相関チェック処理(ユニークチェックのみ)
		checkUniqueMenuID(validator, menuSheet, lastRowDataNum);

		// MenuシートからLocalizationシートへの整合性チェック
		checkMenuSheetConsistency(validator, menuSheet, lastRowDataNum, localizationSheet, localizationLastIndex);

		// アイテムフラグの相関チェック処理
		checkIsItemCorrelation(validator, menuSheet, lastRowDataNum);

		// オブジェクトIDと親オブジェクトIDの循環参照チェック
		checkParentObjectIDCircularReference(validator, menuSheet, lastRowDataNum);
	}

	/**
	 * オブジェクトID項目を相関チェックするメソッドです。<br>
	 * チェックする内容は下記の通りです。<br>
	 * ①ユニークチェック<br>
	 * 
	 * @param menuSheet
	 * @param row
	 * @param errorList
	 * @param rowDataNo
	 * @param locale
	 * @param lastRowDataNum
	 * @create 2010/11/17
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkUniqueObjectID(GEditableMenuValidator validator, Sheet menuSheet, int lastRowIndex) {

		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = menuSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			Cell mainCell = mainRow.getCell(MENU_SHEET_OBJECTID_COLUMN_NO);
			String mainValue = mainCell.getStringCellValue();

			// ユニークチェックを行う。
			for (int subIndex = DATA_START_LINE; subIndex < lastRowIndex; subIndex++) {
				// 明細行を一行ずつ取得する
				Row subRow = menuSheet.getRow(subIndex);
				if (subRow == null) {
					continue;
				}

				// 同じ行はチェックしない
				if (mainIndex != subIndex) {

					Cell subCell = subRow.getCell(MENU_SHEET_OBJECTID_COLUMN_NO);
					String subValue = subCell.getStringCellValue();

					// 同じ値があれば、エラーリストに追加する。
					if (mainValue.equals(subValue)) {
						// エラー行
						int errorNo = mainIndex - DATA_START_LINE + 1;
						validator.addValidateError(UNIQUE_CHECK_ERRORCODE, OBJECTID, errorNo);
						continue;
					}
				}
			}
		}
	}

	/**
	 * メニューIDを相関チェックするメソッドです。<br>
	 * チェックする内容は下記の通りです。<br>
	 * ①ユニークチェック<br>
	 * 
	 * @param menuSheet
	 * @param row
	 * @param errorList
	 * @param rowDataNo
	 * @param locale
	 * @param lastRowDataNum
	 * @create 2010/11/17
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkUniqueMenuID(GEditableMenuValidator validator, Sheet menuSheet, int lastRowIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = menuSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			Cell mainCell = mainRow.getCell(MENU_SHEET_MENUID_COLUMN_NO);
			String mainValue = mainCell.getStringCellValue();

			// ユニークチェックを行う。
			for (int subIndex = DATA_START_LINE; subIndex < lastRowIndex; subIndex++) {
				// 明細行を一行ずつ取得する
				Row subRow = menuSheet.getRow(subIndex);
				if (subRow == null) {
					continue;
				}

				// 同じ行はチェックしない
				if (mainIndex != subIndex) {

					Cell subCell = subRow.getCell(MENU_SHEET_MENUID_COLUMN_NO);
					String subValue = subCell.getStringCellValue();

					// 同じ値があれば、エラーリストに追加する。
					if (mainValue.equals(subValue)) {
						// エラー行
						int errorNo = mainIndex - DATA_START_LINE + 1;
						validator.addValidateError(UNIQUE_CHECK_ERRORCODE, MENUID, errorNo);
						continue;
					}
				}
			}
		}
	}

	/**
	 * Menuシートから、Localizationシートへの整合性をチェックします。<br>
	 * 
	 * @param validator チェッククラス
	 * @param menuSheet メニューシート
	 * @param lastRowIndex メニュー最終行番号
	 * @param localizationSheet Localizationシート
	 * @param localizationLastIndex Localization最終行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkMenuSheetConsistency(GEditableMenuValidator validator, Sheet menuSheet, int lastRowIndex,
		Sheet localizationSheet, int localizationLastIndex) {

		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = menuSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			// 表示名の取得
			String roleResourceID = mainRow.getCell(MENU_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO).getStringCellValue();
			// ロケールの取得
			String roleLocale =
				menuSheet.getRow(MENU_SHEET_USERINFORMATION_LOCALE_ROW_NO)
					.getCell(MENU_SHEET_USERINFORMATION_COLUMN_NO).getStringCellValue();

			// ロール名の取得
			Cell roleNameCell = mainRow.getCell(MENU_SHEET_MENUNAME_COLUMN_NO);
			String roleName = roleNameCell != null ? roleNameCell.getStringCellValue() : "";

			// Excelの行番号変数
			int localizationNo = 0;
			// // 最終明細行の行番号用変数
			// int lastLocalizationDataNum =
			// getEndCellRowNumber(localizationSheet);
			
			// TODO [2012/06/05][harada]EM課題対応 ADD
			boolean existLocalization = false;
			for (int i = 0; i < localizationLastIndex - DATA_START_LINE; i++) {
				localizationNo = DATA_START_LINE + i;
				Row row = localizationSheet.getRow(localizationNo);
				if (row == null) {
					continue;
				}
				// LocalizationシートのKeyとLocaleを取得
				String localizationKey = row.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO).getStringCellValue();
				String localizationLocale = row.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO).getStringCellValue();

				if (localizationKey.equals(roleResourceID) && localizationLocale.equals(roleLocale)) {
					// TODO [2012/06/05][harada]EM課題対応 ADD
					existLocalization = true;
					Cell valueCell = row.getCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);
					if (valueCell == null) {
						break;
					}
					String localizationValue = valueCell.getStringCellValue();
					if (!localizationValue.equals(roleName)) {
						validator.addValidateError(CONSISTENCY_CHECK_ERRORCODE, MENUNAME, mainIndex - DATA_START_LINE + 1);
					} else {
						break;
					}
				}
			}

			// TODO [2012/06/05][harada]EM課題対応 ADD Start
			// Menuシートに紐づく言語情報がLocalizationに存在しない場合
			if (!existLocalization)
			{
				validator.addValidateError(CONSISTENCY_CHECK_ERRORCODE, MENUNAME, mainIndex - DATA_START_LINE + 1);
			}
			// TODO [2012/06/05][harada]EM課題対応 ADD End
		}
	}

	/**
	 * アイテムフラグの整合性チェックを行います。<br>
	 * アイテムフラグがTrueの場合、ParentMenuObjectIDに紐付くメニューのアイテムフラグがTrueならエラー<br>
	 * ※アイテムの配下にアイテムは来ない為
	 * 
	 * @param validator チェッククラス
	 * @param menuSheet メニューシート
	 * @param lastRowIndex 最終行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkIsItemCorrelation(GEditableMenuValidator validator, Sheet menuSheet, int lastRowIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = menuSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			Cell isItemCell = mainRow.getCell(MENU_SHEET_ISITEM_COLUMN_NO);
			String isItem = isItemCell.getStringCellValue();
			boolean isItemFlag = IS_ITEM_TRUE.equals(isItem);
			if (isItemFlag) {
				Cell parentMenuObjectIDCell = mainRow.getCell(MENU_SHEET_PARENTMENUOBJECTID_COLUMN_NO);
				if (parentMenuObjectIDCell != null) {
					String parentMenuObjectID = parentMenuObjectIDCell.getStringCellValue();
					// 親がカテゴリかのチェック
					validator.validateParentObjectIDBasic(parentMenuObjectID, mainIndex);
					validator.validateParentObjectIDExisted(parentMenuObjectID, mainIndex);
				}
			}
		}
	}

	/**
	 * {@link GMenu}のインポート解析処理において、オブジェクトIDと親オブジェクトIDの循環参照チェックを行うメソッドです。<br>
	 * 
	 * @param validator エラー格納クラス
	 * @param menuSheet メニューシート
	 * @param lastRowIndex メニューシート最終行番号
	 * @create 2011/06/14
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkParentObjectIDCircularReference(GEditableMenuValidator validator, Sheet menuSheet,
		int lastRowIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = menuSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			Cell objectIDCell = mainRow.getCell(MENU_SHEET_OBJECTID_COLUMN_NO);
			String objectID = objectIDCell.getStringCellValue();

			Cell parentObjectIDCell = mainRow.getCell(MENU_SHEET_PARENTMENUOBJECTID_COLUMN_NO);
			String parentObjectID = null;
			if (parentObjectIDCell != null) {
				parentObjectID = parentObjectIDCell.getStringCellValue();
			}

			validator
				.validateParentObjectIDCircularReference(objectID, parentObjectID, mainIndex - DATA_START_LINE + 1);
		}
	}

	/**
	 * Roleのインポート解析処理において、相関チェックを行うメソッドです。<br>
	 * 相関チェックでは、以下の内容をチェックします。<br>
	 * ①ユニーク ②整合性
	 * 
	 * @param roleSheet
	 * @param localizationSheet
	 * @param lastRowDataNum
	 * @param errorList
	 * @param locale
	 * @create 2010/11/10
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkCorrelationLocalization(GEditableMenuValidator validator, Sheet localizationSheet,
		int localizationLastIndex, Sheet roleSheet, int roleLastIndex) {

		// リソースIDとロケールの一意チェック
		checkResourceIDAndLocaleUnique(validator, localizationSheet, localizationLastIndex);

		// LocalizationシートからMenuシートへの整合性チェック
		// リソースIDの値が、MenuシートのDisplayNameResourceIDに無ければ、エラー
		checkLocalizationSheetConsistency(validator, localizationSheet, localizationLastIndex, roleSheet, roleLastIndex);
	}

	/**
	 * リソースIDとロケールの組み合わせについて、ユニークチェックを行います。
	 * 
	 * @param validator チェッククラス
	 * @param localizationSheet Localizationシート
	 * @param lastRowIndex 最終行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkResourceIDAndLocaleUnique(GEditableMenuValidator validator, Sheet localizationSheet,
		int lastRowIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = localizationSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			// キーの取得
			Cell mainResourceIDCell = mainRow.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
			String mainResourceID = mainResourceIDCell.getStringCellValue();

			// ロケールの取得
			Cell mainLocaleCell = mainRow.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
			String mainLocale = mainLocaleCell.getStringCellValue();

			// ユニークチェックを行う。
			for (int subIndex = DATA_START_LINE; subIndex < lastRowIndex; subIndex++) {
				// 明細行を一行ずつ取得する
				Row subRow = localizationSheet.getRow(subIndex);
				if (subRow == null) {
					continue;
				}

				// 同じ行はチェックしない
				if (mainIndex != subIndex) {

					// ローカル変数リソースID
					Cell subResourceIDCell = subRow.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
					String subResourceID = subResourceIDCell.getStringCellValue();

					// ローカル変数ロケール
					Cell subLocaleCell = subRow.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
					String subLocale = subLocaleCell.getStringCellValue();

					if (mainResourceID.equals(subResourceID) && mainLocale.equals(subLocale)) {
						validator.addValidateError(UNIQUE_CHECK_ERRORCODE, LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME,
							mainIndex - DATA_START_LINE + 1);
						break;
					}
				}
			}
		}
	}

	/**
	 * LocalizationシートにあるリソースIDが、Roleシートに存在するかチェックします。
	 * 
	 * @param validator チェッククラス
	 * @param localizationSheet localizationシート
	 * @param localizationLastIndex 最終行番号(Localization)
	 * @param roleSheet ロールシート
	 * @param roleLastIndex 最終行番号(Role)
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkLocalizationSheetConsistency(GEditableMenuValidator validator, Sheet localizationSheet,
		int localizationLastIndex, Sheet roleSheet, int roleLastIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < localizationLastIndex; mainIndex++) {
			Row mainRow = localizationSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			// リソースIDの取得
			Cell mainResourceIDCell = mainRow.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
			String mainResourceID = mainResourceIDCell.getStringCellValue();

			boolean flag = false;
			for (int i = 0; i < roleLastIndex - DATA_START_LINE; i++) {
				int roleNo = DATA_START_LINE + i;
				// 明細行を一行ずつ取得する
				Row roleRow = roleSheet.getRow(roleNo);

				if (roleRow == null) {
					continue;
				}

				// RoleシートdisplayNameResourceIDを取得
				Cell displayNameResourceIDCell = roleRow.getCell(MENU_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);
				String displayNameResourceID = displayNameResourceIDCell.getStringCellValue();

				if (displayNameResourceID.equals(mainResourceID)) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				validator.addValidateError(CONSISTENCY_CHECK_ERRORCODE, LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME,
					mainIndex - DATA_START_LINE + 1);
			}
		}
	}

	/**
	 * エクセル明細行から得られる情報を元に、メニューを生成します。
	 * 
	 * @param menuSheet
	 * @param localizationSheet
	 * @param menuLastRowDataNum
	 * @param localizationLastRowDataNum
	 * @param companyCode
	 * @param menuDao
	 * @return
	 * @create 2011/01/20
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	protected void insertWorkbook(Workbook workbook, GUser user) throws GResourceProcessingException {

		Sheet menuSheet = workbook.getSheet(MENU_SHEET);
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		int menuLastRowDataNum = getEndCellRowNumber(menuSheet);
		int localizationLastRowDataNum = getEndCellRowNumber(localizationSheet);

		Map<String, Integer> sortIndexMap = new HashMap<String, Integer>();

		for (int i = 0; i < menuLastRowDataNum - DATA_START_LINE; i++) {
			int rowNo = DATA_START_LINE + i;
			Row row = menuSheet.getRow(rowNo);
			if (row == null) {
				continue;
			}

			GEditableMenu menu = createMenu(row, localizationSheet, localizationLastRowDataNum, user);

			// SortIndexを採番する
			int sortIndex = 0;
			if (sortIndexMap.containsKey(menu.getParentObjectID())) {
				sortIndex = sortIndexMap.get(menu.getParentObjectID()) + 1;
			}
			sortIndexMap.put(menu.getParentObjectID(), sortIndex);
			menu.setSortIndex(sortIndex);

			try {
				getMenuDao().insertMenu(menu);
			} catch (GOptimisticLockException e) {
				throw new GResourceProcessingException(e);
			}
		}
	}

	private GEditableMenu createMenu(Row row, Sheet localizationSheet, int localizationLastRowDataNum, GUser user)
		throws GResourceProcessingException {

		// オブジェクトIDの取得
		Cell objectIDCell = row.getCell(MENU_SHEET_OBJECTID_COLUMN_NO);
		String objectID = objectIDCell.getStringCellValue();

		// MenuIDの取得
		Cell menuIDCell = row.getCell(MENU_SHEET_MENUID_COLUMN_NO);
		String menuID = menuIDCell.getStringCellValue();

		// 表示名の取得
		Cell displayNameResourceIDCell = row.getCell(MENU_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);
		String displayNameResourceID = displayNameResourceIDCell.getStringCellValue();

		// 親メニューIDを取得します。
		Cell parentMenuIDCell = row.getCell(MENU_SHEET_PARENTMENUOBJECTID_COLUMN_NO);
		String parentMenuID = null;
		if (parentMenuIDCell != null) {
			parentMenuID = parentMenuIDCell.getStringCellValue();
		}

		// アプリケーションタイプを取得します。
		Cell applicationTypeCell = row.getCell(MENU_SHEET_APPLICATIONTYPE_COLUMN_NO);
		String applicationType = applicationTypeCell.getStringCellValue();

		// メニュータイプを取得します。
		Cell menuTypeCell = row.getCell(MENU_SHEET_MENUTYPE_COLUMN_NO);
		String menuType = null;
		if (menuTypeCell != null) {
			menuType = menuTypeCell.getStringCellValue();
		}

		// 起動モジュールを取得します。
		Cell startModuleCell = row.getCell(MENU_SHEET_STARTMODULE_COLUMN_NO);
		String startModule = null;
		if (startModuleCell != null) {
			startModule = startModuleCell.getStringCellValue();
		}

		// 起動パラメータを取得します。
		Cell parameterCell = row.getCell(MENU_SHEET_PARAMETER_COLUMN_NO);
		String parameter = null;
		if (parameterCell != null) {
			parameter = parameterCell.getStringCellValue();
		}

		// アイテムフラグを取得します。
		Cell isItemCell = row.getCell(MENU_SHEET_ISITEM_COLUMN_NO);
		String isItem = isItemCell.getStringCellValue().trim();
		boolean isItemFlag = IS_ITEM_TRUE.equals(isItem);

		// 状態を取得します。
		Cell statusCell = row.getCell(MENU_SHEET_STATUS_COLUMN_NO);
		String status = statusCell.getStringCellValue().trim();
		if (status.equals(STATUS_ACTIVE)) {
			status = "1";
		} else {
			status = "0";
		}

		// ロールIDを取得します。
		Cell roleIDCell = row.getCell(MENU_SHEET_ROLEID_COLUMN_NO);
		String roleID = null;
		if (roleIDCell != null) {
			roleID = roleIDCell.getStringCellValue();
		}

		// 詳細を取得します。
		Cell descriptionCell = row.getCell(MENU_SHEET_DESCRIPTION_COLUMN_NO);
		String description = null;
		if (descriptionCell != null) {
			description = descriptionCell.getStringCellValue();
		}

		// 更新者を取得します。
		Cell updatedPersonCell = row.getCell(MENU_SHEET_UPDATEDPERSON_COLUMN_NO);
		String updatedPerson = null;
		if (updatedPersonCell != null) {
			updatedPerson = updatedPersonCell.getStringCellValue();
			updatedPerson = GStringUtils.nullToBlank(updatedPerson).trim();
		}

		// 更新日を取得します。
		Cell updatedDateCell = row.getCell(MENU_SHEET_UPDATEDDATE_COLUMN_NO);
		String updatedDateStr = null;
		if (updatedDateCell != null) {
			updatedDateStr = updatedDateCell.getStringCellValue();
			updatedDateStr = GStringUtils.nullToBlank(updatedDateStr).trim();
		}

		// DisplayNameのMapを作成する。
		Map<Locale, String> displayNameMap =
			getDisplayNameMap(localizationSheet, localizationLastRowDataNum, displayNameResourceID);

		// GMENUを作成する。
		GEditableMenu menu = getMenuDao().createMenu();
		menu.setObjectID(objectID);
		menu.setCompanyCode(user.getCompany().getCode());
		menu.setMenuID(menuID);
		menu.setDisplayNameResourceID(displayNameResourceID);
		menu.setDisplayNameMap(displayNameMap);
		menu.setParentObjectID(parentMenuID);
		menu.setApplicationType(applicationType);
		menu.setMenuType(menuType);
		menu.setStartModule(startModule);
		menu.setParameter(parameter);
		menu.setIsItem(isItemFlag);

		boolean bool = GBooleanUtils.isTrueBit(status);
		if (bool) {
			menu.setStatus(GStatus.Active);
		} else {
			menu.setStatus(GStatus.Stop);
		}
		menu.setRoleObjectID(roleID);
		menu.setDescription(description);
		if (GStringUtils.isEmpty(updatedPerson)) {
			menu.setUpdatedPerson(user.getId());
		} else {
			menu.setUpdatedPerson(updatedPerson);
		}
		if (!GStringUtils.isEmpty(updatedDateStr)) {
			try {
				GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
				menu.setUpdatedDate(formatter.parse(updatedDateStr, GFrameworkUtils.getDefaultLocale(), DATE_FORMAT));
			} catch (ParseException e) {
				throw new GResourceProcessingException(e);
			}
		} else {
			Date updatedDate = new Date(System.currentTimeMillis());
			menu.setUpdatedDate(updatedDate);
		}
		return menu;
	}

	/**
	 * ログインユーザー情報を出力する処理を行います。
	 * 
	 * @param workbook　ワークブック
	 * @param ｌocale ロケール
	 */
	private void writeUserInformation(Workbook workbook, GUser user, Locale locale) {
		Row menuSheetRow = null;

		// Menuシートを取得する
		Sheet menuSheet = workbook.getSheet(MENU_SHEET);

		// 会社コード
		menuSheetRow = menuSheet.getRow(MENU_SHEET_USERINFORMATION_COMPANYCD_ROW_NO);
		Cell companyCDCell = menuSheetRow.getCell(MENU_SHEET_USERINFORMATION_COLUMN_NO);
		companyCDCell.setCellValue(user.getCompany().getCode());
		// ユーザーID
		menuSheetRow = menuSheet.getRow(MENU_SHEET_USERINFORMATION_USERID_ROW_NO);
		Cell userIDCell = menuSheetRow.getCell(MENU_SHEET_USERINFORMATION_COLUMN_NO);
		userIDCell.setCellValue(user.getId());
		// ユーザー名
		menuSheetRow = menuSheet.getRow(MENU_SHEET_USERINFORMATION_USERNAME_ROW_NO);
		Cell userNameCell = menuSheetRow.getCell(MENU_SHEET_USERINFORMATION_COLUMN_NO);
		userNameCell.setCellValue(user.getName(locale));
		// ロケール情報
		menuSheetRow = menuSheet.getRow(MENU_SHEET_USERINFORMATION_LOCALE_ROW_NO);
		Cell localeCell = menuSheetRow.getCell(MENU_SHEET_USERINFORMATION_COLUMN_NO);
		localeCell.setCellValue(locale.toString());
		// 出力時刻
		Calendar calendar = new GregorianCalendar();
		menuSheetRow = menuSheet.getRow(MENU_SHEET_USERINFORMATION_EXPORTTIME_ROW_NO);
		Cell exportDateCell = menuSheetRow.getCell(MENU_SHEET_USERINFORMATION_COLUMN_NO);
		GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		exportDateCell.setCellValue(formatter.format(calendar.getTime(), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT));
	}

	/**
	 * 「ファイルパス+export.+UUID」形式を引数に指定したFileクラスを返却するメソッド.<br>
	 * 
	 * @return File
	 * @throws IOException
	 * @create 2010/10/27
	 * @author fujimura
	 * @since 3.9.0
	 */
	private File createFile() throws IOException {

		UUID uuid = UUID.randomUUID();
		String filePath = GFrameworkUtils.getProperty(EXPORTFILE_TEMPORARY_DIRECTORY);
		File file = new File(filePath);
		file.mkdirs();
		String fileName = filePath + "export." + uuid.toString();

		return new File(fileName);
	}

	/**
	 * RoleシートのDisplayNameResourceIDを元に、Localizationシートにあるロケールとロール名のマップを返します。
	 * 
	 * @param localizationSheet
	 * @param localizationLastRowDataNum
	 * @param displayNameResourceID
	 * @return Map<Locale,String> マップ
	 * @create 2010/11/06
	 * @author fujimura
	 * @since 3.9.0
	 */
	private Map<Locale, String> getDisplayNameMap(Sheet localizationSheet, int localizationLastRowDataNum,
		String displayNameResourceID) {

		Map<Locale, String> displayNameMap = new HashMap<Locale, String>();

		for (int i = 0; i < localizationLastRowDataNum - DATA_START_LINE; i++) {
			int rowNo = DATA_START_LINE + i;
			// Localizationシートの明細行を一行ずつ取得する
			Row row = localizationSheet.getRow(rowNo);

			if (row == null) {
				continue;
			}

			// リソースIDの取得
			Cell resourceIDCell = row.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
			String resourceID = resourceIDCell.getStringCellValue();

			// リソースIDとdisplayNameResourceIDが一致した分のロール名とロケールをマップに詰める
			if (resourceID.equals(displayNameResourceID)) {
				// ロール名とロケールの取得
				Cell valueCell = row.getCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);
				String value = null;
				if (valueCell != null) {
					value = valueCell.getStringCellValue();
				}
				Cell localeCell = row.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
				String localeStr = localeCell.getStringCellValue();
				Locale locale = GLocaleUtils.getLocale(localeStr);
				displayNameMap.put(locale, value);
			}
		}

		return displayNameMap;

	}
}
