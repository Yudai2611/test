/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.io.File;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.menu.GEditableMenu;

/**
 * MenuManager用の操作を表すインタフェースです.<br>
 * 
 * @create 2011/09/08
 * @author KCCS nishimura
 * @since 3.9.0
 */
public interface GMenuManagementService {

	/**
	 * 入力値検証タイプを表す列挙値です.<br>
	 * 
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public enum ValidateType {
		/**
		 * BASIC：基本的な入力値検証<br>
		 * FULL：全項目に対しての入力値検証<br>
		 * DELETE：削除時の入力値検証<br>
		 */
		BASIC, FULL, DELETE;

		/**
		 * 引数の文字列に一致する入力値検証タイプを取得します.<br>
		 * 一致するタイプが存在しない場合、FULLを返します。<br>
		 * 
		 * @param type 入力値検証タイプの文字列
		 * @return 入力値検証タイプ
		 * @create 2011/09/08
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public static ValidateType get(String type) {
			if (BASIC.name().equals(type)) {
				return BASIC;
			} else if (DELETE.name().equals(type)) {
				return DELETE;
			} else {
				return FULL;
			}
		}
	}
	
	/**
	 * {@link GEditableMenu}オブジェクトを生成します.<br>
	 * 
	 * @return {@link GEditableMenu}オブジェクト
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableMenu createMenu();

	/**
	 * 引数の情報より、{@link GEditableMenu}を取得します.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @param loginUser ログインユーザー
	 * @return メニュー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableMenu findMenu(String objectID, GUser loginUser) throws GValidateException;

	/**
	 * メニューを登録します.<br>
	 * 
	 * @param menu メニュー
	 * @param user ユーザー
	 * @return 登録後のメニュー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableMenu insertMenu(GEditableMenu menu, GUser user) throws GValidateException;

	/**
	 * メニューを更新します.<br>
	 * 
	 * @param menu メニュー
	 * @param user ユーザー
	 * @return 更新後のメニュー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableMenu updateMenu(GEditableMenu menu, GUser user) throws GValidateException;

	/**
	 * メニューを更新します.<br>
	 * 
	 * @param menu メニュー
	 * @param user ユーザー
	 * @param validateType 入力値検証タイプ
	 * @return 更新後のメニュー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableMenu updateMenu(GEditableMenu menu, GUser user, ValidateType validateType) throws GValidateException;

	/**
	 * リスト内のメニューを更新します.<br>
	 * 
	 * @param menuList メニューリスト
	 * @param user ユーザー
	 * @return 更新後のメニューリスト
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	List<GEditableMenu> updateMenuList(List<GEditableMenu> menuList, GUser user) throws GValidateException;

	/**
	 * リスト内のメニューを更新します.<br>
	 * 
	 * @param menuList メニューリスト
	 * @param user ユーザー
	 * @param validateType 入力値検証タイプ
	 * @return 更新後のメニューリスト
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	List<GEditableMenu> updateMenuList(List<GEditableMenu> menuList, GUser user, ValidateType validateType)
		throws GValidateException;

	/**
	 * リスト内のメニューを削除します.<br>
	 * 
	 * @param menuList メニューリスト
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nihsimura
	 * @since 3.9.0
	 */
	void deleteMenuList(List<GEditableMenu> menuList, GUser user) throws GValidateException;

	/**
	 * 一括編集用ファイルを取り込みます.<br>
	 * 
	 * @param file 一括編集用ファイル
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void importBatchEditData(File file, GUser user) throws GValidateException;

	/**
	 * 一括編集用ファイルを出力します.<br>
	 * 
	 * @param user ユーザー
	 * @return 一括編集用ファイル
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	File exportBatchEditData(GUser user);

	/**
	 * データ移行用ファイルを取り込みます.<br>
	 * 
	 * @param parentMenu 移行先親メニュー
	 * @param file データ移行用ファイル
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void importTransitionalData(GEditableMenu parentMenu, File file, GUser user) throws GValidateException;

	/**
	 * データ移行用ファイルを出力します.<br>
	 * 
	 * @param menuList メニューリスト
	 * @param user ユーザー
	 * @return データ移行用ファイル
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	File exportTransitionalData(List<GEditableMenu> menuList, GUser user) throws GValidateException;

	/**
	 * メニューをコピーします.<br>
	 * 
	 * @param srcMenuList コピー元メニューリスト
	 * @param destMenu コピー先メニュー
	 * @param user ユーザー
	 * @return コピー後のメニューリスト
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	List<GEditableMenu> copyMenu(List<GEditableMenu> srcMenuList, GEditableMenu destMenu, GUser user)
		throws GValidateException;

	/**
	 * メニューを移動します.<br>
	 * 
	 * @param srcMenuList 移動元メニューリスト
	 * @param destMenu 移動先メニュー
	 * @param user ユーザー
	 * @return 移動後のメニューリスト
	 * @throws GValidateException 入力検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	List<GEditableMenu> moveMenu(List<GEditableMenu> srcMenuList, GEditableMenu destMenu, GUser user)
		throws GValidateException;

	/**
	 * メニュータイプ(アイテム)を取得します.<br>
	 * 
	 * @return メニュータイプ(アイテム)
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getItemMenuTypeMap();

	/**
	 * メニュータイプ(カテゴリ)を取得します.<br>
	 * 
	 * @return メニュータイプ(カテゴリ)
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getCategoryMenuTypeMap();

	/**
	 * アプリケーションタイプ(アイテム)を取得します.<br>
	 * 
	 * @return アプリケーションタイプ(アイテム)
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getItemAppTypeMap();

	/**
	 * アプリケーションタイプ(カテゴリ)を取得します.<br>
	 * 
	 * @return アプリケーションタイプ(カテゴリ)
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getCategoryAppTypeMap();

	/**
	 * {@link GMenuManagementService}インターフェースの実装クラスを取得するファクトリクラスです.<br>
	 * 
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public static class Factory {
		
		/**
		 * デフォルトコンストラクタ.<br>
		 * 
		 * @create 2011/09/08
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public Factory() {
		}
		
		/**
		 * {@link GMenuManagementService}インターフェースの実装クラスを取得します.<br>
		 * 
		 * @return 実装クラス
		 * @create 2011/09/08
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public static GMenuManagementService getInstance() {
			return (GMenuManagementService) GFrameworkUtils.getComponent(GMenuManagementService.class.getName());
		}

	}

}
