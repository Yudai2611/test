/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.exception.GAlreadyDeletedException;
import jp.co.kccs.greenearth.commons.exception.GAlreadyInsertedException;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenuValidator.MenuFinder;
import jp.co.kccs.greenearth.framework.menu.GEditableMenu;
import jp.co.kccs.greenearth.framework.menu.GEditableMenuDao;
import jp.co.kccs.greenearth.framework.menu.GMenu;

/**
 * GMenuManagementServiceImpl.
 */
public class GMenuManagementServiceImpl implements GMenuManagementService {

	/** MenuID項目 */
	protected static final String MENUID = "MenuID";
	protected static final String OBJECTID = "ObjectID";

	protected static final String UNIQUE_CHECK_ERRORCODE = "GEM-000011";
	protected static final String DELETED_CHECK_ERRORCODE = "GEM-000018";
	protected static final String EXCLUSIVE_CHECK_ERRORCODE = "GEM-000019";
	protected static final String DESTMENU_DELETED_CHECK_ERRORCODE = "GEM-000028";
	private GMenuTransporter _transporter = null;
	private GMenuBatchEditor _batchEditor = null;

	// エラーコード

	/** ファイルサイズがゼロの場合のエラーコード */
	protected static final String FILESIZE_CHECK_ERRORCODE = "GEM-000023";

	/** ペースト先に同じデータが存在する場合のエラーコード */
	protected static final String SAMEDATE_CHECK_ERRORCODE = "GEM-000027";

	/** エラーリスト */
	// private List<GValidateError> _errorList = new
	// ArrayList<GValidateError>();

	public GMenuManagementServiceImpl(GMenuTransporter transporter, GMenuBatchEditor batchEditor) {
		_transporter = transporter;
		_batchEditor = batchEditor;
	}

	public GEditableMenuDao getMenuDao() {
		return GEditableMenuDao.Factory.getInstance();
	}

	public GMenuTransporter getMenuTransporter() {
		return _transporter;
	}

	public GMenuBatchEditor getMenuBatchEditor() {
		return _batchEditor;
	}

	public GEditableMenu createMenu() {
		return getMenuDao().createMenu();
	}

	public GEditableMenu findMenu(String objectID, GUser user) throws GValidateException {

		// 通信が発生すれば、パラメータに対して検証をする
		GEditableMenuValidator validator = new GEditableMenuValidator();
		validator.validateObjectID(objectID);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

		try {
			return (GEditableMenu) getMenuDao().findMenu(objectID);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public GEditableMenu insertMenu(GEditableMenu menu, GUser user) throws GValidateException {
		// 一部項目を自動採番
		menu.setObjectID(UUID.randomUUID().toString());
		menu.setDisplayNameResourceID(UUID.randomUUID().toString());
		String companyCode = user.getCompany().getCode();
		menu.setCompanyCode(companyCode);
		menu.setUpdatedPerson(user.getId());

		List<GValidateError> errorList = validateMenu(menu, -1, ValidateType.FULL);
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}

		try {
			getMenuDao().insertMenu(menu);
			return getMenuDao().findMenu(menu.getObjectID());
		} catch (GOptimisticLockException e) {
			GValidateError error = createValidateError(UNIQUE_CHECK_ERRORCODE, MENUID);
			throw new GValidateException(error);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public List<GEditableMenu> updateMenuList(List<GEditableMenu> menuList, GUser user) throws GValidateException {
		return updateMenuList(menuList, user, ValidateType.FULL);
	}

	/**
	 * メニューリストを一括登録します.<br>
	 * 
	 * @param menuList
	 * @param user
	 * @throws GValidateException
	 * @create 2011/06/01
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	public List<GEditableMenu> updateMenuList(List<GEditableMenu> menuList, GUser user, ValidateType validateType)
		throws GValidateException {

		List<GValidateError> errorList = new ArrayList<GValidateError>();
		for (int i = 0; i < menuList.size(); i++) {
			GEditableMenu menu = menuList.get(i);
			errorList.addAll(validateMenu(menu, i, validateType));
		}
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}
		try {
			getMenuDao().updateMenuList(menuList);

			List<GEditableMenu> resultMenuList = new ArrayList<GEditableMenu>();
			for (GEditableMenu menu : menuList) {
				GEditableMenu returnMenu = getMenuDao().findMenu(menu.getObjectID());
				resultMenuList.add(returnMenu);
			}
			return resultMenuList;
		} catch (GOptimisticLockException e) {
			GValidateError error = null;
			if (e instanceof GAlreadyInsertedException) {
				error = createValidateError(UNIQUE_CHECK_ERRORCODE, MENUID);
				throw new GValidateException(error);
			} else if (e instanceof GAlreadyDeletedException) {
				error = createValidateError(DELETED_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			} else {
				error = createValidateError(EXCLUSIVE_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			}
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public GEditableMenu updateMenu(GEditableMenu menu, GUser user) throws GValidateException {
		return updateMenu(menu, user, ValidateType.FULL);
	}

	public GEditableMenu updateMenu(GEditableMenu menu, GUser user, ValidateType validateType)
		throws GValidateException {
		String companyCode = user.getCompany().getCode();
		menu.setCompanyCode(companyCode);
		menu.setUpdatedPerson(user.getId());

		List<GValidateError> errorList = validateMenu(menu, -1, validateType);
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}

		try {
			getMenuDao().updateMenu(menu);
			return getMenuDao().findMenu(menu.getObjectID());
		} catch (GOptimisticLockException e) {
			GValidateError error = null;
			if (e instanceof GAlreadyInsertedException) {
				error = createValidateError(UNIQUE_CHECK_ERRORCODE, MENUID);
				throw new GValidateException(error);
			} else if (e instanceof GAlreadyDeletedException) {
				error = createValidateError(DELETED_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			} else {
				error = createValidateError(EXCLUSIVE_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			}
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public void deleteMenuList(List<GEditableMenu> menuList, GUser user) throws GValidateException {
		// チェック処理
		List<GValidateError> errorList = new ArrayList<GValidateError>();
		for (int i = 0; i < menuList.size(); i++) {
			GEditableMenu menu = menuList.get(i);
			errorList.addAll(validateMenu(menu, i, ValidateType.DELETE));
		}
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}

		// 再帰的に末端の子供まで削除対象とする
		List<GEditableMenu> deleteList = new ArrayList<GEditableMenu>();
		for (GEditableMenu menu : menuList) {
			accumulateDescendant(menu, deleteList);
		}

		try {
			getMenuDao().deleteMenuList(deleteList);
		} catch (GOptimisticLockException e) {
			GValidateError error = null;
			if (e instanceof GAlreadyDeletedException) {
				error = createValidateError(DELETED_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			} else {
				error = createValidateError(EXCLUSIVE_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			}
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	protected void accumulateDescendant(GEditableMenu menu, List<GEditableMenu> accumulateList) {
		accumulateList.add(menu);
		List<GMenu> children = menu.getChildren();
		for (GMenu child : children) {
			accumulateDescendant((GEditableMenu) child, accumulateList);
		}
	}

	public void importBatchEditData(File file, GUser user) throws GValidateException {

		validateFile(file);

		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			getMenuBatchEditor().importFile(file.toURI().toURL(), user, locale);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		} catch (MalformedURLException e) {
			throw new GResourceAccessException(e);
		}
	}

	public File exportBatchEditData(GUser user) {
		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			return getMenuBatchEditor().exportFile(user, locale);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public void importTransitionalData(GEditableMenu parentMenu, File file, GUser user) throws GValidateException {
		validateFile(file);

		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			getMenuTransporter().importFileAddition(user, parentMenu, file, locale);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public File exportTransitionalData(List<GEditableMenu> menuList, GUser user) throws GValidateException {
		try {
			File file = getMenuTransporter().exportFile(menuList);
			validateFile(file);
			return file;
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public List<GEditableMenu> copyMenu(List<GEditableMenu> srcMenuList, GEditableMenu destMenu, GUser user)
		throws GValidateException {
		// int sortIndex;
		String destMenuObjectID = null;
		List<GEditableMenu> copyMenuList = new ArrayList<GEditableMenu>();
		try {
			if (destMenu != null) {
				destMenuObjectID = destMenu.getObjectID();

				// DB2用検索項目桁数チェック
				GEditableMenuValidator validator = new GEditableMenuValidator();
				validator.validateObjectID(destMenuObjectID);
				if (validator.hasError()) {
					throw new GValidateException(validator.getErrorList());
				}

				GEditableMenu toCopyCategory = getMenuDao().findMenu(destMenuObjectID);
				if (toCopyCategory == null) {
					GValidateError error = createValidateError(DESTMENU_DELETED_CHECK_ERRORCODE, null);
					throw new GValidateException(error);
				}
				// コピー先配下のメニュー数をソート順番とする
			}
			for (GEditableMenu selectedMenu : srcMenuList) {

				// コピーしたメニューを検索
				GEditableMenu originalMenu = findMenu(selectedMenu.getObjectID(), user);
				if (originalMenu == null) {
					GValidateError error = createValidateError(DELETED_CHECK_ERRORCODE, null);
					throw new GValidateException(error);
					// throw new GValidateException();
				}

				// 循環参照チェック
				// GEditableMenu validateMenu = getMenuDao().createMenu();
				// validateMenu.setObjectID(originalMenu.getObjectID());
				// validateMenu.setParentObjectID(destMenuObjectID);
				// List<GValidateError> errorList = validateMenu(validateMenu,
				// -1, ValidateType.BASIC);
				// if(errorList.size() > 0){
				// throw new GValidateException(errorList);
				// }

				MenuFinder finder = createFinder();
				GEditableMenuValidator validator = new GEditableMenuValidator(finder);
				validator.validateParentObjectIDCircularReference(originalMenu.getObjectID(), destMenuObjectID);
				List<GValidateError> errorList = validator.getErrorList();
				if (errorList.size() > 0) {
					throw new GValidateException(errorList);
				}

				GEditableMenu copyMenu = createCopyMenu(originalMenu, destMenuObjectID, user);

				// ソートインデックス再採番
				copyMenu.setSortIndex(-1);
				// 登録
				insertMenu(copyMenu, user);
				copyMenuList.add(copyMenu);

				if (!originalMenu.isItem()) {
					// カテゴリなら子孫を登録
					copyDescendant(originalMenu, copyMenu.getObjectID(), user);
				}

			}
			List<GEditableMenu> resultMenuList = new ArrayList<GEditableMenu>();
			// 登録したメニュー（コピーメニュー）の検索を行い、結果を返す
			for (GEditableMenu menu : copyMenuList) {
				GEditableMenu resultMenu = getMenuDao().findMenu(menu.getObjectID());
				resultMenuList.add(resultMenu);
			}
			return resultMenuList;
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public List<GEditableMenu> moveMenu(List<GEditableMenu> selectedMenuList, GEditableMenu destMenu, GUser user)
		throws GValidateException {
		String destMenuObjectID = null;
		GEditableMenu toCopyCategory = null;
		List<GMenu> destMenuChildren = new ArrayList<GMenu>();
		try {
			if (destMenu != null) {
				destMenuChildren = destMenu.getChildren();
				destMenuObjectID = destMenu.getObjectID();
				// GEditableMenu toCopyCategory =
				// getMenuDao().findMenu(destMenuObjectID);
				toCopyCategory = getMenuDao().findMenu(destMenuObjectID);
				if (toCopyCategory == null) {
					GValidateError error = createValidateError(DESTMENU_DELETED_CHECK_ERRORCODE, null);
					throw new GValidateException(error);
				}
			} else {
				destMenuChildren = getMenuDao().findRootMenuList(user.getCompany().getCode());
			}

			// 親メニューオブジェクトID変更の更新を行う
			for (GEditableMenu selectedMenu : selectedMenuList) {
				String selectedMenuObjectID = selectedMenu.getObjectID();

				for (GMenu menu : destMenuChildren) {
					// selectedMenuとdestMenuの子供のOBJECTIDと同じならエラー
					if (menu.getObjectID().equals(selectedMenuObjectID)) {
						GValidateError error = createValidateError(SAMEDATE_CHECK_ERRORCODE, OBJECTID);
						throw new GValidateException(error);
					}
				}
				selectedMenu.setParentObjectID(destMenuObjectID);
				// ソートインデックス再採番
				selectedMenu.setSortIndex(-1);

				updateMenu(selectedMenu, user);
			}

			// 更新したメニューの情報を検索して返す
			List<GEditableMenu> resultMenuList = new ArrayList<GEditableMenu>();
			for (GEditableMenu selectedMenu : selectedMenuList) {
				GEditableMenu resultMenu = getMenuDao().findMenu(selectedMenu.getObjectID());
				resultMenuList.add(resultMenu);
			}
			return resultMenuList;
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	private GEditableMenu createCopyMenu(GEditableMenu originalMenu, String parentObjectID, GUser user)
		throws GValidateException {
		GEditableMenu copyMenu = getMenuDao().createMenu();
		// コピー項目
		copyMenu.setApplicationType(originalMenu.getApplicationType());
		copyMenu.setDescription(originalMenu.getDescription());
		copyMenu.setIsItem(originalMenu.isItem());
		copyMenu.setMenuType(originalMenu.getMenuType());
		copyMenu.setParameter(originalMenu.getParameter());
		copyMenu.setRoleObjectID(originalMenu.getRoleObjectID());
		copyMenu.setStartModule(originalMenu.getStartModule());
		copyMenu.setStatus(originalMenu.getStatus());
		copyMenu.setSortIndex(originalMenu.getSortIndex());
		copyMenu.setDisplayNameMap(originalMenu.getDisplayNameMap());

		// 再設定項目
		copyMenu.setParentObjectID(parentObjectID);
		copyMenu.setUpdatedDate(new Date(System.currentTimeMillis()));

		// メニューID
		String randomNumber = "_COPY" + String.format("%05d", new Random().nextInt(100000));
		String newMenuID = originalMenu.getMenuID() + randomNumber;

		// 採番後のIDに対し、DB2用桁チェック
		GEditableMenuValidator validator = new GEditableMenuValidator();
		validator.validateMenuID(newMenuID);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

		try {
			GMenu checkMenu = getMenuDao().findMenu(user.getCompany().getCode(), newMenuID);
			if (checkMenu == null) {
				copyMenu.setMenuID(newMenuID);
			}
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
		return copyMenu;
	}

	protected void copyDescendant(GEditableMenu parentMenu, String parentObjectID, GUser user)
		throws GValidateException {
		List<GMenu> children = parentMenu.getChildren();
		for (GMenu child : children) {
			GEditableMenu copyMenu = createCopyMenu((GEditableMenu) child, parentObjectID, user);
			insertMenu(copyMenu, user);
			if (child.isItem()) {
				continue;
			}
			copyDescendant((GEditableMenu) child, copyMenu.getObjectID(), user);
		}
	}

	protected MenuFinder createFinder() {
		MenuFinder finder = new MenuFinder() {

			public GEditableMenu findMenu(String menuObjectID) {
				try {
					return getMenuDao().findMenu(menuObjectID);
				} catch (GResourceProcessingException e) {
					throw new GResourceAccessException(e);
				}
			}
		};
		return finder;
	}

	protected List<GValidateError> validateMenu(GEditableMenu menu, int index, ValidateType type) {
		MenuFinder finder = createFinder();
		GEditableMenuValidator validator = new GEditableMenuValidator(finder);
		if (type == ValidateType.BASIC) {
			validator.validateMenuBasic(menu, index);
		} else if (type == ValidateType.FULL) {
			validator.validateMenu(menu, index);
			validator.validateParentObjectIDCircularReference(menu.getObjectID(), menu.getParentObjectID(), index);
		} else if (type == ValidateType.DELETE) {
			validator.validateMenu(menu, index);
		}
		return validator.getErrorList();
	}

	public Map<String, String> getItemMenuTypeMap() {
		Locale locale = GFrameworkContext.getInstance().getLocale();
		return getMenuDao().getItemMenuTypeMap(locale);
	}

	public Map<String, String> getCategoryMenuTypeMap() {
		Locale locale = GFrameworkContext.getInstance().getLocale();
		return getMenuDao().getCategoryMenuTypeMap(locale);
	}

	public Map<String, String> getItemAppTypeMap() {
		Locale locale = GFrameworkContext.getInstance().getLocale();
		return getMenuDao().getItemAppTypeMap(locale);
	}

	public Map<String, String> getCategoryAppTypeMap() {
		Locale locale = GFrameworkContext.getInstance().getLocale();
		return getMenuDao().getCategoryAppTypeMap(locale);
	}

	/**
	 * ファイルのサイズを検証します.<br>
	 * 
	 * @param file
	 * @create 2011/06/06
	 * @author KCCS kyo
	 * @throws GValidateException
	 * @since v3.9.0
	 */
	protected void validateFile(File file) throws GValidateException {

		if (file == null) {
			GValidateError error = createValidateError(FILESIZE_CHECK_ERRORCODE, null);
			throw new GValidateException(error);
		}
		// ファイルサイズがゼロの場合
		if (file.length() < 0) {
			GValidateError error = createValidateError(FILESIZE_CHECK_ERRORCODE, null);
			throw new GValidateException(error);
		}
	}

	/**
	 * {@link GValidateError}を作成します.<br>
	 * 
	 * @create 2011/05/10
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	protected GValidateError createValidateError(String errorCode, String id) {
		GEditableMenuValidator menuValidator = new GEditableMenuValidator();
		return menuValidator.createValidateError(errorCode, id);
	}
}
