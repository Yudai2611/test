/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GUploadFile;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.db.GTransactionInterceptor;
import jp.co.kccs.greenearth.framework.em.menumanager.GMenuManagementService.ValidateType;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.menu.GEditableMenu;
import jp.co.kccs.greenearth.framework.xrmi.menu.GMenuAction;

public class GMenuManagerAction extends GMenuAction {

	protected static final String OBJECT_ID = "ObjectID";
	protected static final String MENU_ID = "MenuID";
	protected static final String DISPLAY_NAME_RESOURCE_ID = "DisplayNameResourceID";
	protected static final String PARENT_OBJECT_ID = "ParentID";
	protected static final String APPLICATION_TYPE = "ApplicationType";
	protected static final String MENU_TYPE = "MenuType";
	protected static final String START_MODULE = "StartModule";
	protected static final String PARAMETER = "Parameter";
	protected static final String IS_ITEM = "IsItem";
	protected static final String STATUS = "Status";
	protected static final String ROLE_OBJECT_ID = "RoleObjectID";
	protected static final String DESCRIPTION = "Description";
	protected static final String SORT_INDEX = "SortIndex";
	protected static final String EXCLUSIVE_KEY = "ExclusiveFG";
	protected static final String DISPLAY_NAME = "Value";
	protected static final String VALIDATE_TYPE = "ValidateType";
	
	/** インポートファイル一時保管ディレクトリパスのプロパティキー */
	protected final String EXPORTFILE_TEMPORARY_DIRECTORY = "geframe.em.File.TempDirectory";
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findMenuByOID(GParameter parameter, GResultData resultData) throws GValidateException {
		String objectID = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARTH_OBJECT_ID));
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		GEditableMenu menu = service.findMenu(objectID, GEXActionUtils.getLoginUser());
		resultData.setData(RESULT_MENU, menu);
		return resultData;
	}

	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData insertMenu(GParameter parameter, GResultData resultData) throws GValidateException {
		GEditableMenu menu = assembleMenu(parameter, 0);
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		GEditableMenu insertMenu = service.insertMenu(menu, GEXActionUtils.getLoginUser());
		//画面描画のために、登録したメニューを結果セットに設定する。
		resultData.setData(RESULT_MENU, insertMenu);
		return resultData;
	}

	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData updateMenu(GParameter parameter, GResultData resultData) throws GValidateException {
		GEditableMenu menu = assembleMenu(parameter, 0);
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		
		String validateType = parameter.getValue(VALIDATE_TYPE);
		GEditableMenu updateMenu = null;
		if (validateType != null) {
			updateMenu = service.updateMenu(menu, GEXActionUtils.getLoginUser(), ValidateType.get(validateType));
		}
		else {
			updateMenu = service.updateMenu(menu, GEXActionUtils.getLoginUser());
		}
		
		//画面描画のために、更新したメニューを結果セットに設定する。
		resultData.setData(RESULT_MENU, updateMenu);
		return resultData;
	}
	
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData updateMenuList(GParameter parameter, GResultData resultData) throws GValidateException {
		List<GEditableMenu> menuList = assembleMenuList(parameter);
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		
		String validateType = parameter.getValue(VALIDATE_TYPE);
		List<GEditableMenu> returnMenuList = null;
		if (validateType != null) {
			returnMenuList = service.updateMenuList(menuList, GEXActionUtils.getLoginUser(), ValidateType.get(validateType));
		}
		else {
			returnMenuList = service.updateMenuList(menuList, GEXActionUtils.getLoginUser());
		}

		//画面描画のために、更新したメニューを結果セットに設定する。
		resultData.setData(RESULT_MENU_LIST, returnMenuList);
		return resultData;
	}
	
	
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData deleteMenuList(GParameter parameter, GResultData resultData) throws GValidateException {
		List<GEditableMenu> menuList = assembleMenuList(parameter);
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		service.deleteMenuList(menuList, GEXActionUtils.getLoginUser());
		return resultData;
	}

	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData importBatchEditData(GParameter parameter, GResultData resultData) throws GValidateException, IOException {
		GUploadFile uploadFile = parameter.getFile("ImportFile");
		File file = createFile();
		uploadFile.write(file);	
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		service.importBatchEditData(file, GEXActionUtils.getLoginUser());		
		return resultData;
	}
	
	
	/**
	 * 検索したメニュー情報をエクセルファイルに出力するメソッドです。<br>
	 * 出力したファイルは、結果セットに詰められ、クライアント側に返されます。<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return resultData 結果セット
	 * @throws GResourceProcessingException
	 * @create 2010/11/11
	 * @author KCCS fujimura
	 * @throws GValidateException 
	 * @since 3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData exportBatchEditData(GParameter parameter, GResultData resultData) {
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		File file = service.exportBatchEditData(GEXActionUtils.getLoginUser());
		GDownloadFile downloadFile = new GDownloadFile(file);
		downloadFile.setDeleteFlag(true);
		downloadFile.setContentType("application/x-binary");
		resultData.setDownloadFile(downloadFile);
		resultData.setExitCode(GResultData.EXIT_CODE_FILE_DOWNLOAD);
		return resultData;
	}

	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData importTransitionalData(GParameter parameter, GResultData resultData) throws GValidateException, IOException {
		GEditableMenu parentMenu = null;
		if( parameter.getValue(OBJECT_ID, 0)!=null){
			 parentMenu = assembleMenu(parameter, 0);
		}
		
		GUploadFile uploadFile = parameter.getFile("ImportFile");
		File file = createFile();
		uploadFile.write(file);	
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		service.importTransitionalData(parentMenu, file, GEXActionUtils.getLoginUser());		
		return resultData;
	}
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData exportTransitionalData(GParameter parameter, GResultData resultData) throws GValidateException {
		List<GEditableMenu> menuList = assembleMenuList(parameter);
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		File file = service.exportTransitionalData(menuList, GEXActionUtils.getLoginUser());
		GDownloadFile downloadFile = new GDownloadFile(file);
		downloadFile.setDeleteFlag(true);
		downloadFile.setContentType("application/x-binary");
		resultData.setDownloadFile(downloadFile);
		resultData.setExitCode(GResultData.EXIT_CODE_FILE_DOWNLOAD);
		return resultData;
		
	}

	/**
	 * メニューのコピーを行います.
	 * コピー対象メニューを、コピー先メニューへコピーします。
	 * コピー対象メニュー、コピー先メニューはパラメータに設定されています。
	 * 
	 * @param parameter 画面パラメータ
	 * @param resultData 事前アクションの処理結果
	 * @return resultData 処理結果
	 * @throws GValidateException コピー作成時に入力エラーが発生した場合
	 * @throws GResourceProcessingException メニューの検索、登録処理に失敗した場合
	 * @create 2011/05/25
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData copyMenu(GParameter parameter , GResultData resultData)throws GValidateException,GResourceProcessingException{	
		List<GEditableMenu> srcMenuList = assembleMenuList(parameter);
		GEditableMenu destMenu = null;
		if( parameter.getValue(OBJECT_ID+"_dest", 0)!=null){
			destMenu = assembleMenu(parameter,"_dest", 0);
		}
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		List<GEditableMenu> resultMenuList = service.copyMenu( srcMenuList , destMenu ,GEXActionUtils.getLoginUser());
		//画面描画のために、コピーしたメニューを結果セットに設定する。
		resultData.setData(RESULT_MENU_LIST, resultMenuList);
		return resultData;
	}
	
	/**
	 * メニューの移動を行います.
	 * 移動対象メニューを、移動先メニューへ移動します。
	 * 移動対象メニュー、移動先メニューはパラメータに設定されています。
	 * 
	 * @param parameter 画面パラメータ
	 * @param resultData 事前アクションの処理結果
	 * @return resultData 処理結果
	 * @throws GValidateException メニュー移動時に入力エラーが発生した場合
	 * @throws GResourceProcessingException メニューの検索、更新処理に失敗した場合
	 * @create 2011/05/25
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData moveMenu(GParameter parameter , GResultData resultData)throws GValidateException,GResourceProcessingException{	
		List<GEditableMenu> srcMenuList = assembleMenuList(parameter);
		GEditableMenu destMenu = null;
		if( parameter.getValue(OBJECT_ID+"_dest", 0)!=null){
			destMenu = assembleMenu(parameter,"_dest", 0);
		}
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		List<GEditableMenu> resultMenuList =  service.moveMenu( srcMenuList , destMenu ,GEXActionUtils.getLoginUser());
		//移動したメニューのトップノードを返す
		resultData.setData(RESULT_MENU_LIST, resultMenuList);
		return resultData;
	}
	
	public GResultData getItemAppTypeMap(GParameter parameter ,GResultData resultData) {
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		Map<String, String> applicationTypeMap = service.getItemAppTypeMap();
		resultData.setData("ApplicationTypeMap", applicationTypeMap);
		return resultData;
	}
	
	public GResultData getCategoryAppTypeMap(GParameter parameter ,GResultData resultData) {
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		Map<String, String> applicationTypeMap = service.getCategoryAppTypeMap();
		resultData.setData("ApplicationTypeMap", applicationTypeMap);
		return resultData;
	}
	
	public GResultData getItemMenuTypeMap(GParameter parameter, GResultData resultData) {
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		Map<String, String> menuTypeMap = service.getItemMenuTypeMap();
		resultData.setData("MenuTypeMap", menuTypeMap);
		return resultData;
	}

	public GResultData getCategoryMenuTypeMap(GParameter parameter, GResultData resultData) {
		GMenuManagementService service = GMenuManagementService.Factory.getInstance();
		Map<String, String> menuTypeMap = service.getCategoryMenuTypeMap();
		resultData.setData("MenuTypeMap", menuTypeMap);
		return resultData;
	}
	
	private GEditableMenu assembleMenu(GParameter parameter, int index) {
		return assembleMenu(parameter , "" , index);
	}
	
	private GEditableMenu assembleMenu(GParameter parameter, String prefix ,int index) {
		// 値の抽出
		String companyCode = GEXActionUtils.getLoginCompany().getCode();
		String objectID = parameter.getValue(OBJECT_ID + prefix, index);
		String menuID = parameter.getValue(MENU_ID + prefix, index);
		String displayNameResourceID = parameter.getValue(DISPLAY_NAME_RESOURCE_ID + prefix, index);
		String parentObjectID = parameter.getValue(PARENT_OBJECT_ID + prefix, index);
		String applicationType = parameter.getValue(APPLICATION_TYPE + prefix, index);
		String menuType = parameter.getValue(MENU_TYPE + prefix, index);
		String startModule = parameter.getValue(START_MODULE + prefix, index);
		String param = parameter.getValue(PARAMETER + prefix, index);
		boolean isItem = parameter.getBoolean(IS_ITEM + prefix, index);
		String status = parameter.getValue(STATUS + prefix, index);
		String roleObjectID = parameter.getValue(ROLE_OBJECT_ID + prefix, index);
		String description = parameter.getValue(DESCRIPTION + prefix, index);
		int sortIndex = parameter.getInteger(SORT_INDEX + prefix, index);
		String exclusiveKey = parameter.getValue(EXCLUSIVE_KEY + prefix, index);

		List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
		Map<Locale, String> displayNameMap = new HashMap<Locale, String>();
		for (Locale locale : localeList) {
			String paramKey = DISPLAY_NAME + prefix + "@" + locale.toString();
			if (parameter.getValueCount(paramKey) > index) {
				displayNameMap.put(locale, parameter.getValue(paramKey, index));
			}			
		}
		
		return assembleMenu(companyCode, objectID, menuID, displayNameResourceID, parentObjectID, applicationType, menuType, startModule, param, isItem, status, roleObjectID, description, sortIndex, exclusiveKey, displayNameMap);
	}

	private GEditableMenu assembleMenu(String companyCode, String objectID, String menuID, String displayNameResourceID, String parentObjectID, String applicationType, String menuType, String startModule, String parameter, boolean isItem, String status, String roleObjectID, String description, int sortIndex, String exclusiveKey, Map<Locale, String> displayNameMap) {

		GEditableMenu menu = GMenuManagementService.Factory.getInstance().createMenu();
		menu.setCompanyCode(companyCode);
		menu.setObjectID(objectID);
		menu.setMenuID(menuID);
		menu.setDisplayNameResourceID(displayNameResourceID);
		menu.setParentObjectID(parentObjectID);
		menu.setApplicationType(applicationType);
		menu.setMenuType(menuType);
		menu.setStartModule(startModule);
		menu.setParameter(parameter);
		menu.setIsItem(isItem);
		boolean bool = GBooleanUtils.isTrueBit(status);
		menu.setStatus(GStatus.convert(bool));
		menu.setRoleObjectID(roleObjectID);
		menu.setDescription(description);
		menu.setSortIndex(sortIndex);
		menu.setExclusiveKey(exclusiveKey);
		menu.setDisplayNameMap(new HashMap<Locale, String>());
		for (Entry<Locale, String> entry : displayNameMap.entrySet()) {
			Locale key = entry.getKey();
			String value = entry.getValue();
			menu.getDisplayNameMap().put(key, value);
		}

		menu.setUpdatedDate(new Date(System.currentTimeMillis()));
		
		return menu;
	}

	private List<GEditableMenu> assembleMenuList(GParameter parameter) {
		List<GEditableMenu> menulist = new ArrayList<GEditableMenu>();
		int length = parameter.getInteger("MENU_LIST_COUNT");
		for (int i = 0; i < length; i++) {
			GEditableMenu menu = assembleMenu(parameter, i);
			menulist.add(menu);
		}

		return menulist;
	}
	
	protected File createFile() throws IOException {
		UUID uuid = UUID.randomUUID();
		String filePath = GFrameworkUtils.getProperty(EXPORTFILE_TEMPORARY_DIRECTORY);
		File file = new File(filePath);
		file.mkdirs();
		return new File( filePath + "temp." + uuid.toString());
	}
}
