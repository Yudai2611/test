/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.io.File;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.menu.GEditableMenu;


public interface GMenuTransporter {

	File exportFile(List<GEditableMenu> menuList) throws GResourceProcessingException;

	void importFileAddition(GUser user ,GEditableMenu parentMenu, File file, Locale locale) throws GResourceProcessingException, GValidateException;

}
