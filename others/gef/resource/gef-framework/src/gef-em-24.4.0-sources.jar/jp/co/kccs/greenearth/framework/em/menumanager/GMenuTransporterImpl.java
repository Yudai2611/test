/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.menumanager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.menu.GEditableMenu;
import jp.co.kccs.greenearth.framework.menu.GEditableMenuDao;
import jp.co.kccs.greenearth.framework.menu.GMenu;

public class GMenuTransporterImpl implements GMenuTransporter {

	private static final String FILE_ENCODING = "geframe.em.ExportFile.Encoding";

	private static final String ELEMENT_MENU_TREE = "MenuTree";
	private static final String ELEMENT_MENU = "Menu";
	private static final String ELEMENT_OBJECT_ID = "ObjectID";
	private static final String ELEMENT_MENU_ID = "MenuID";
	private static final String ELEMENT_DISPLAY_NAME_RESOURCE_ID = "DisplayNameResourceID";
	private static final String ELEMENT_APPLICATION_TYPE = "ApplicationType";
	private static final String ELEMENT_MENU_TYPE = "MenuType";
	private static final String ELEMENT_START_MODULE = "StartModule";
	private static final String ELEMENT_PARAMETER = "Parameter";
	private static final String ELEMENT_IS_ITEM = "IsItem";
	private static final String ELEMENT_STATUS = "Status";
	private static final String ELEMENT_ROLE_ID = "RoleObjectID";
	private static final String ELEMENT_DESCRIPTION = "Description";
	private static final String ELEMENT_UPDATED_DT = "UpdatedDate";
	private static final String ELEMENT_UPDATED_PERSON = "UpdatedPerson";
	private static final String ELEMENT_DISPLAY_NAME = "DisplayName";
	private static final String ELEMENT_RESOURCE = "Resource";
	private static final String ELEMENT_CHILD_MENUS = "ChildMenus";
	private static final String ATTRIBUTE_LOCALE = "locale";

	private static final String PARENTMENUID = "ParentMenuObjectID";
	private static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss"; // TODO フォーマットを外だしにする
	/** エクスポートファイル一時保管ディレクトリパスのプロパティキー */
	private static final String EXPORTFILE_TEMPORARY_DIRECTORY = "geframe.em.File.TempDirectory";

	// エラーコード
	/** データが重複しています */
	private static final String UNIQUE_CHECK_ERRORCODE = "GEM-000011";
	/** 親メニュー情報のアイテムフラグが不正です。 */
	protected final String ITEMFLAG_CHECK_ERROR = "GEM-000016";
	/** インポート先がありません。 */
	private final String IMPORT_NODESTINATION_ERRORCODE = "GEM-000022";
	/** インポート先がカテゴリではありません。 */
	private final String IMPORT_ITEMFLAG_CHECK_ERROR = "GEM-000021";
	/** 入力して下さい */
	private static final String REQUIRED_CHECK_ERRORCODE = "GEM-000003";
//	/** 定義したロールが存在しません */
//	private final String NODEFINED_ROLE_CHECK_ERRORCODE = "GEM-000005";
	
	/** 不正な値が入力されています */
	private final String ILLEGAL_VALUE_ERROR = "GEM-000013";

	private int _bufferSize = 512;

	public GMenuTransporterImpl() {
	}

	public GMenuTransporterImpl(int bufferSize) {
		_bufferSize = bufferSize;
	}

	public GEditableMenuDao getMenuDao() {
		return GEditableMenuDao.Factory.getInstance();
	}

	/**
	 * 
	 * 
	 * @param companyCode
	 * @param objectIDs
	 * @return
	 * @throws GResourceProcessingException
	 * @create 2010/11/12
	 * @author KCCS XXXXX
	 * @since v3.9.0
	 */
	public File exportFile(List<GEditableMenu> menuList) throws GResourceProcessingException {
		if (menuList == null || menuList.size() == 0) {
			return null;
		}
		BufferedOutputStream buffOutputStream = null;
		XMLStreamWriter xmlw = null;
		try {
			String encoding = GFrameworkUtils.getProperty(FILE_ENCODING);
			
			// ファイルを作成
			File exportFile = createFile();
			buffOutputStream = new BufferedOutputStream(new FileOutputStream(exportFile), _bufferSize);
			XMLOutputFactory xmlof = XMLOutputFactory.newInstance();
			xmlw = xmlof.createXMLStreamWriter(buffOutputStream,encoding);

			// 出力ファクトリを取得
			// XML宣言
			xmlw.writeStartDocument(encoding, "1.0");

			//MenuTree：Start
			xmlw.writeStartElement(ELEMENT_MENU_TREE);

			for (GEditableMenu menu : menuList) {
				menu = getMenuDao().findMenu(menu.getObjectID());
				createMenuElement(menu, xmlw);
			}

			//MenuTree：End
			xmlw.writeEndElement();

			// XML ドキュメントを終了する
			xmlw.writeEndDocument();

			return exportFile;
		} catch (IOException e) {
			throw new GResourceProcessingException(e);
		} catch (XMLStreamException e) {
			throw new GResourceProcessingException(e);
		} finally {
			// XMLStreamWriter をクローズしてリソースを解放する
			try {
				if (xmlw != null) {
					xmlw.close();
				}
				if (buffOutputStream != null) {
					buffOutputStream.close();
				}
			} catch (IOException e) {
				throw new GResourceProcessingException(e);
			} catch (XMLStreamException e) {
				throw new GResourceProcessingException(e);
			}
		}
	}

	/**
	 * Menuタグを作成します
	 * 
	 * @param menu
	 * @param xmlw
	 * @throws XMLStreamException
	 * @throws GResourceProcessingException
	 * @author KCCS nishimura
	 * @since 2010/10/21
	 */
	protected void createMenuElement(GEditableMenu menu, XMLStreamWriter xmlw) throws XMLStreamException, GResourceProcessingException {
		xmlw.writeStartElement(ELEMENT_MENU);
		createElement(ELEMENT_OBJECT_ID, menu.getObjectID(), xmlw);
		createElement(ELEMENT_MENU_ID, menu.getMenuID(), xmlw);
		//表示名
		createResourceElement(menu.getDisplayNameMap(), menu.getDisplayNameResourceID(), xmlw);
		createElement(ELEMENT_APPLICATION_TYPE, menu.getApplicationType(), xmlw);
		createElement(ELEMENT_MENU_TYPE, menu.getMenuType(), xmlw);
		createElement(ELEMENT_START_MODULE, menu.getStartModule(), xmlw);
		createElement(ELEMENT_PARAMETER, menu.getParameter(), xmlw);
		createElement(ELEMENT_IS_ITEM, String.valueOf(menu.isItem()), xmlw);
		if (GStatus.Active == menu.getStatus()) {
			createElement(ELEMENT_STATUS, "1", xmlw);
		} else {
			createElement(ELEMENT_STATUS, "0", xmlw);
		}
		if (menu.getRole() != null) {
			createElement(ELEMENT_ROLE_ID, menu.getRole().getObjectID(), xmlw);
		}
		createElement(ELEMENT_DESCRIPTION, menu.getDescription(), xmlw);
		GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		String updatedDate = formatter.format(menu.getUpdatedDate(), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT);
		createElement(ELEMENT_UPDATED_DT, updatedDate, xmlw);
		createElement(ELEMENT_UPDATED_PERSON, menu.getUpdatedPerson(), xmlw);

		//自身の子供
		if (!menu.isItem()) {
			List<GMenu> children = menu.getChildren();
			if (children.size() > 0) {
				xmlw.writeStartElement(ELEMENT_CHILD_MENUS);

				for (GMenu child : children) {
					createMenuElement((GEditableMenu) child, xmlw);
				}

				xmlw.writeEndElement();
			}
		}
		xmlw.writeEndElement();
	}

	/**
	 * XMLのタグを作成する
	 * 
	 * @param elementName
	 * @param character
	 * @param xmlw
	 * @throws XMLStreamException
	 * @create 2010/11/01
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void createElement(String elementName, String character, XMLStreamWriter xmlw) throws XMLStreamException {
		if (character == null) {
			return;
		}
		xmlw.writeStartElement(elementName);
		xmlw.writeCharacters(character);
		xmlw.writeEndElement();
	}

	/**
	 * DisplayNameタグを作成する
	 * 
	 * @param map
	 * @param xmlw
	 * @throws XMLStreamException
	 * @create 2010/10/21
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void createResourceElement(Map<Locale, String> map, String resourceID, XMLStreamWriter xmlw) throws XMLStreamException {
		xmlw.writeStartElement(ELEMENT_DISPLAY_NAME);
		xmlw.writeAttribute(ELEMENT_DISPLAY_NAME_RESOURCE_ID, resourceID);
		for (Map.Entry<Locale, String> e : map.entrySet()) {
			if (e.getKey() == null) {
				continue;
			}
			xmlw.writeStartElement(ELEMENT_RESOURCE);
			xmlw.writeAttribute(ATTRIBUTE_LOCALE, e.getKey().toString());
			if (e.getValue() != null) {
				xmlw.writeCharacters(e.getValue());
			}
			xmlw.writeEndElement();
		}
		xmlw.writeEndElement();
	}

	public void importFileAddition(GUser user, GEditableMenu parentMenu, File file, Locale locale) throws GResourceProcessingException, GValidateException {

		// インポートファイルに対応するリスト
		List<GEditableMenu> menuList = new ArrayList<GEditableMenu>();

		//インポート先のチェック
		int index;
		String destMenuObjectID = null;
		if (parentMenu != null) {
			destMenuObjectID = parentMenu.getObjectID();
			GEditableMenu destMenu = getMenuDao().findMenu(destMenuObjectID);
			if (destMenu == null) {
				//インポート先IDの存在チェック
				GValidateError error = createValidateError(IMPORT_NODESTINATION_ERRORCODE, locale, GErrorType.ERROR, PARENTMENUID, "");
				throw new GValidateException(error);
			}
			if (destMenu.isItem()) {
				//インポート先IDがカテゴリであることのチェック
				GValidateError error = createValidateError(IMPORT_ITEMFLAG_CHECK_ERROR, locale, GErrorType.ERROR, PARENTMENUID, "");
				throw new GValidateException(error);
			}
			index = destMenu.getChildren().size();

		} else {
			index = getMenuDao().findRootMenuList(user.getCompany().getCode()).size();
		}

		//単項目チェック +  xmlロード
		validateSingleItem(user.getCompany().getCode(), parentMenu, file, locale, menuList, index);

		//ユニークチェック
		validateUnique(user.getCompany().getCode(), locale, true, menuList);

		// 登録処理
		addition(user.getCompany().getCode(), parentMenu, file, locale, index);
	}

	protected void validateUnique(String companyCode, Locale locale, boolean isAddition, List<GEditableMenu> menuList) throws GResourceProcessingException, GValidateException {
		List<GValidateError> errorList = new ArrayList<GValidateError>();
		//xmlファイルをロードしたListでチェックを行う(xmlファイルのアクセス回数を減らす為）
		for (int i = 0; i < menuList.size(); i++) {
			GEditableMenu checkMenu = menuList.get(i);

			GEditableMenu objectIDResultMenu = null;
			//ObjectIDの重複チェック
			if (isAddition) {
				//xml内の重複チェック　⇒　重複があればERROR
				objectIDResultMenu = findMenuForObjectID(checkMenu.getObjectID(), menuList, i);
				if (objectIDResultMenu != null) {
					errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_OBJECT_ID, checkMenu.getObjectID()));
				} else {
					//永続化データとの重複チェック⇒重複があればERROR
					//本来は「どこの」メニューと重複しているかを検索する
					//インポート先、インポート先の親（先祖）との重複であればERROR,インポート先の子（子孫）、別部分木との重複であればWARNINGとするべき。
					//WARNINGの場合は、上書きができるような処理が必要であるが、実装が複雑になることから今回は全てERRORとしている
					objectIDResultMenu = (GEditableMenu) getMenuDao().findMenu(checkMenu.getObjectID());
					if (objectIDResultMenu != null) {
						errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_OBJECT_ID, checkMenu.getObjectID()));
					}
				}
			}
			//MenuIDの重複チェック				
			//xml内の重複チェック　⇒　重複があればERROR
			GEditableMenu menuIDResultMenu = findMenuForMenuID(checkMenu.getMenuID(), menuList, i);
			if (menuIDResultMenu != null) {
				errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_MENU_ID, checkMenu.getObjectID()));
			} else {
				//永続化データとの重複チェック
				menuIDResultMenu = (GEditableMenu) getMenuDao().findMenu(companyCode, checkMenu.getMenuID());
				if (menuIDResultMenu != null) {
					if (checkMenu.getObjectID() != null && checkMenu.getObjectID().equals(menuIDResultMenu.getObjectID())) {
						if (isAddition) {
							//①重複したメニューが、オブジェクトIDも重複していた場合ERROR
							//本来は「どこの」メニューと重複しているかを検索する
							//インポート先、インポート先の親（先祖）との重複であればERROR,インポート先の子（子孫）、別部分岐との重複であればWARNINGとするべき。
							//WARNINGの場合は、上書きができるような処理が必要であるが、実装が複雑になることから現在は全てERRORとしている
							errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_MENU_ID, checkMenu.getObjectID()));
						}
					} else {
						//②重複したメニューが、メニューIDのみ重複していた場合、ERROR
						errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_MENU_ID, checkMenu.getObjectID()));
					}
				}
			}

			//Resourceの重複チェック
			//xml内の重複チェック　⇒　重複があればERROR
			GEditableMenu resourceIDResultMenu = findMenuForResourceID(checkMenu.getDisplayNameResourceID(), menuList, i);
			if (resourceIDResultMenu != null) {
				errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_DISPLAY_NAME_RESOURCE_ID, checkMenu.getObjectID()));
			} //永続化データの重複チェックは行わない
			//ObjectIDが重複しているときのみ、上書きが可能であり、上書きされる際にはdelete,Insertで上書きされる為、ゴミは残らない	
		}
		//ユニークチェックで、エラーがあれば返す
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}
	}

	/**
	 * 
	 * 
	 * @param objectID
	 * @param menuList
	 * @param passIndex
	 * @return
	 * @create 2011/05/27
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private GEditableMenu findMenuForObjectID(String objectID, List<GEditableMenu> menuList, int passIndex) {
		if (objectID == null) {
			return null;
		}
		for (int i = 0; i < menuList.size(); i++) {
			if (i == passIndex) {
				continue;
			}
			if (objectID.equals(menuList.get(i).getObjectID())) {
				return menuList.get(i);
			}
		}
		return null;
	}

	/**
	 * メニューリストの中からメニューIDが一致するメニューを検索します
	 * 
	 * @param MenuID メニューID
	 * @param menuList メニューリスト
	 * @param passIndex 検索対象としないメニューのインデックス
	 * @return
	 * @create 2011/05/27
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private GEditableMenu findMenuForMenuID(String menuID, List<GEditableMenu> menuList, int passIndex) {
		if (menuID == null) {
			return null;
		}
		for (int i = 0; i < menuList.size(); i++) {
			if (i == passIndex) {
				continue;
			}
			if (menuID.equals(menuList.get(i).getMenuID())) {
				return menuList.get(i);
			}
		}
		return null;
	}

	private GEditableMenu findMenuForResourceID(String resourceID, List<GEditableMenu> menuList, int passIndex) {
		if (resourceID == null) {
			return null;
		}
		for (int i = 0; i < menuList.size(); i++) {
			if (i == passIndex) {
				continue;
			}
			if (resourceID.equals(menuList.get(i).getDisplayNameResourceID())) {
				return menuList.get(i);
			}
		}
		return null;
	}

	protected void validateSingleItem(String companyCode, GEditableMenu parentMenu, File file, Locale locale, List<GEditableMenu> menuList, int index) throws GValidateException, GResourceProcessingException {

		TransportMenuValidator validator = new TransportMenuValidator(locale);

		InputStream in = null;
		try {
			in = new BufferedInputStream(new FileInputStream(file), _bufferSize);
			XMLInputFactory inFactory = XMLInputFactory.newInstance();
			XMLEventReader reader = inFactory.createXMLEventReader(in);
			while (reader.hasNext()) {
				XMLEvent event = reader.nextEvent();
				if (event.isStartElement()) {
					if (ELEMENT_MENU.equals(event.asStartElement().getName().toString())) {
						GEditableMenu menu = getMenuDao().createMenu();
						if (parentMenu != null) {
							menu.setParentObjectID(parentMenu.getObjectID());
						}
						menu.setCompanyCode(companyCode);
						menu.setSortIndex(index++);
						validateMenu(validator, menu, reader, locale, menuList);
					}
				}
			}
			if (validator.hasError()) {
				throw new GValidateException(validator.getErrorList());
			}
		} catch (FileNotFoundException e) {
			throw new GResourceProcessingException(e);
		} catch (XMLStreamException e) {
			throw new GResourceProcessingException(e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ioe) {
				throw new GResourceProcessingException(ioe);
			}
		}
	}

	private void validateMenu(TransportMenuValidator validator, GEditableMenu menu, XMLEventReader reader, Locale locale, List<GEditableMenu> menuList) throws XMLStreamException, GResourceProcessingException {
		int childIndex = 0;
		boolean hasElementIsItem = false;
		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				if (ELEMENT_MENU.equals(startElement.getName().toString())) {
					if (menu.isItem()) {
						GValidateError error = createValidateError(ITEMFLAG_CHECK_ERROR, locale, GErrorType.ERROR, PARENTMENUID, menu.getObjectID());
						validator.getErrorList().add(error);
					}
					GEditableMenu childMenu = getMenuDao().createMenu();
					childMenu.setParentObjectID(menu.getObjectID());
					childMenu.setCompanyCode(menu.getCompanyCode());
					childMenu.setSortIndex(childIndex++);
					validateMenu(validator, childMenu, reader, locale, menuList);
				} else if (ELEMENT_OBJECT_ID.equals(startElement.getName().toString())) {
					menu.setObjectID(getCharacter(reader));
				} else if (ELEMENT_MENU_ID.equals(startElement.getName().toString())) {
					menu.setMenuID(getCharacter(reader));
				} else if (ELEMENT_APPLICATION_TYPE.equals(startElement.getName().toString())) {
					menu.setApplicationType(getCharacter(reader));
				} else if (ELEMENT_MENU_TYPE.equals(startElement.getName().toString())) {
					menu.setMenuType(getCharacter(reader));
				} else if (ELEMENT_START_MODULE.equals(startElement.getName().toString())) {
					menu.setStartModule(getCharacter(reader));
				} else if (ELEMENT_PARAMETER.equals(startElement.getName().toString())) {
					menu.setParameter(getCharacter(reader));
				} else if (ELEMENT_IS_ITEM.equals(startElement.getName().toString())) {
					String isItemStr = getCharacter(reader);
					isItemStr = isItemStr.toLowerCase();
					if(!isItemStr.equals("true")&&!isItemStr.equals("false")){
						GValidateError error = createValidateError(ILLEGAL_VALUE_ERROR, locale, GErrorType.ERROR, ELEMENT_IS_ITEM, menu.getObjectID());
						validator.getErrorList().add(error);
					}
					else {
						menu.setIsItem(Boolean.valueOf(isItemStr));
					}
					hasElementIsItem = true;
				} else if (ELEMENT_STATUS.equals(startElement.getName().toString())) {
					boolean bool = GBooleanUtils.isTrueBit(getCharacter(reader));
					if (bool) {
						menu.setStatus(GStatus.Active);
					} else {
						menu.setStatus(GStatus.Stop);
					}
				} else if (ELEMENT_ROLE_ID.equals(startElement.getName().toString())) {
					String roleObjectID = getCharacter(reader);
					menu.setRoleObjectID(roleObjectID);
				} else if (ELEMENT_DESCRIPTION.equals(startElement.getName().toString())) {
					menu.setDescription(getCharacter(reader));
				}
				else if (ELEMENT_UPDATED_DT.equals(startElement.getName().toString())) {
					try {
						GDateFormatter fomatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
						Date updateDate = fomatter.parse(getCharacter(reader), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT);
						menu.setUpdatedDate(updateDate);
					} catch (ParseException e) {
						throw new GResourceProcessingException(e);
					}
				} else if (ELEMENT_UPDATED_PERSON.equals(startElement.getName().toString())) {
					menu.setUpdatedPerson(getCharacter(reader));
				} else if (ELEMENT_DISPLAY_NAME.equals(startElement.getName().toString())) {
					//リソース情報の登録
					Attribute attr = (Attribute) startElement.getAttributes().next();
					if(attr!=null){
						menu.setDisplayNameResourceID(attr.getValue());
					}
					menu.setDisplayNameMap(createDisplayNameMap(reader));
				}				
			} else if (event.isEndElement()) {
				EndElement endElement = event.asEndElement();
				if (ELEMENT_MENU.equals(endElement.getName().toString())) {
					//isItemタグがないとエラーにする
					if(!hasElementIsItem){
						GValidateError error = createValidateError(REQUIRED_CHECK_ERRORCODE,locale,GErrorType.ERROR, ELEMENT_IS_ITEM,menu.getObjectID());
						validator.getErrorList().add(error);
					}					
					validator.setLabelSpaceValue(menu.getObjectID());
					validator.validateMenuBasic(menu, -1);
					if (validator.hasError()) {
						return;
					}

					validator.validateParentObjectIDExisted(menu.getParentObjectID(), -1);
					validator.validateRoleObjectIDExisted(menu.getRoleObjectID(), -1);
					if (validator.hasError()) {
						return;
					}
					
					//xmlのメニュー情報をlistへロード
					//単項目チェックにエラーがあればListへのロードを行わない
					GEditableMenu newMenu = getMenuDao().createMenu();
					newMenu.setObjectID(menu.getObjectID());
					newMenu.setMenuID(menu.getMenuID());
					newMenu.setDisplayNameResourceID(menu.getDisplayNameResourceID());
					menuList.add(newMenu);
					return;
				}
			}
		}
	}

	/**
	 * XMLファイルから、GMenuのリストを登録します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GMenuIOCreatable#importData(java.lang.String, java.lang.String, java.io.InputStream, java.util.Locale)
	 * @param companyCode
	 * @param parentObjectID
	 * @param stream
	 * @param locale
	 * @throws GResourceProcessingException
	 * @create 2010/10/23
	 * @author KCCS nishimura
	 * @since 3.9.0
	 * @since
	 */
	protected void addition(String companyCode, GEditableMenu parentMenu, File file, Locale locale, int index) throws GResourceProcessingException, GValidateException {

		InputStream in = null;
		try {
			in = new BufferedInputStream(new FileInputStream(file), _bufferSize);
			XMLInputFactory inFactory = XMLInputFactory.newInstance();
			XMLEventReader reader = inFactory.createXMLEventReader(in);

			while (reader.hasNext()) {
				XMLEvent event = reader.nextEvent();
				if (event.isStartElement()) {
					if (ELEMENT_MENU.equals(event.asStartElement().getName().toString())) {
						GEditableMenu menu = getMenuDao().createMenu();
						//						menu.setObjectID(UUID.randomUUID().toString());
						if (parentMenu != null) {
							menu.setParentObjectID(parentMenu.getObjectID());
						}
						menu.setCompanyCode(companyCode);
						menu.setSortIndex(-1);
						importMenu(menu, reader, locale);
					}
				}
			}
		} catch (FileNotFoundException e) {
			throw new GResourceProcessingException(e);
		} catch (XMLStreamException e) {
			throw new GResourceProcessingException(e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ioe) {
				throw new GResourceProcessingException(ioe);
			}
		}
	}

	protected void importMenu(GEditableMenu menu, XMLEventReader reader, Locale locale) throws XMLStreamException, GResourceProcessingException, GValidateException {
		int childIndex = 0;

		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();

			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				if (ELEMENT_MENU.equals(startElement.getName().toString())) {
					GEditableMenu childMenu = getMenuDao().createMenu();
					//					childMenu.setObjectID(UUID.randomUUID().toString());
					childMenu.setParentObjectID(menu.getObjectID());
					childMenu.setCompanyCode(menu.getCompanyCode());
					childMenu.setSortIndex(childIndex++);
					importMenu(childMenu, reader, locale);
				} else if (ELEMENT_OBJECT_ID.equals(startElement.getName().toString())) {
					menu.setObjectID(getCharacter(reader));
				} else if (ELEMENT_MENU_ID.equals(startElement.getName().toString())) {
					menu.setMenuID(getCharacter(reader));
				} else if (ELEMENT_APPLICATION_TYPE.equals(startElement.getName().toString())) {
					menu.setApplicationType(getCharacter(reader));
				} else if (ELEMENT_MENU_TYPE.equals(startElement.getName().toString())) {
					menu.setMenuType(getCharacter(reader));
				} else if (ELEMENT_START_MODULE.equals(startElement.getName().toString())) {
					menu.setStartModule(getCharacter(reader));
				} else if (ELEMENT_PARAMETER.equals(startElement.getName().toString())) {
					menu.setParameter(getCharacter(reader));
				} else if (ELEMENT_IS_ITEM.equals(startElement.getName().toString())) {
					menu.setIsItem(Boolean.valueOf(getCharacter(reader)));
				} else if (ELEMENT_STATUS.equals(startElement.getName().toString())) {
					//					menu.setStatus(getCharacter(reader));
					boolean bool = GBooleanUtils.isTrueBit(getCharacter(reader));
					if (bool) {
						menu.setStatus(GStatus.Active);
					} else {
						menu.setStatus(GStatus.Stop);
					}
				} else if (ELEMENT_ROLE_ID.equals(startElement.getName().toString())) {
					menu.setRoleObjectID(getCharacter(reader));
				} else if (ELEMENT_DESCRIPTION.equals(startElement.getName().toString())) {
					menu.setDescription(getCharacter(reader));
				} else if (ELEMENT_UPDATED_DT.equals(startElement.getName().toString())) {
					try {
						GDateFormatter fomatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
						Date updateDate = fomatter.parse(getCharacter(reader), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT);
						menu.setUpdatedDate(updateDate);
					} catch (ParseException e) {
						throw new GResourceProcessingException(e);
					}
				} else if (ELEMENT_UPDATED_PERSON.equals(startElement.getName().toString())) {
					menu.setUpdatedPerson(getCharacter(reader));
				} else if (ELEMENT_DISPLAY_NAME.equals(startElement.getName().toString())) {
					//リソース情報の登録
					Attribute attr = (Attribute) startElement.getAttributes().next();
					menu.setDisplayNameResourceID(attr.getValue());
					menu.setDisplayNameMap(createDisplayNameMap(reader));
				}
			} else if (event.isEndElement()) {
				EndElement endElement = event.asEndElement();
				if (ELEMENT_MENU.equals(endElement.getName().toString())) {
					//1メニューを登録する。
					try {
						getMenuDao().insertMenu(menu);
					} catch (GOptimisticLockException e) {
						// 一意制約違反
						throw new GValidateException(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, "", menu.getObjectID()));
					}
					return;
				}
			}
		}
	}

	/**
	 * 表示名のMAPを作成
	 * 
	 * @param reader
	 * @return
	 * @throws XMLStreamException
	 * @create 2010/10/25
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private Map<Locale, String> createDisplayNameMap(XMLEventReader reader) throws XMLStreamException {
		Map<Locale, String> displayName = new HashMap<Locale, String>();

		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				if (ELEMENT_RESOURCE.equals(startElement.getName().toString())) {
					Attribute attr = (Attribute) startElement.getAttributes().next();
					String localeStr = attr.getValue();
					Locale locale = GLocaleUtils.getLocale(localeStr != null ? localeStr.trim() : localeStr);
					String value = getCharacter(reader);
					displayName.put(locale, value != null ? value.trim() : value);
				} 
				else {
					return null;
				}

			} else if (event.isEndElement()) {
				EndElement endElement = event.asEndElement();
				if (ELEMENT_DISPLAY_NAME.equals(endElement.getName().toString())) {
					return displayName;
				}
			}

		}
		return null;
	}

	/**
	 * XMLタグで内包された文字列を取得します。
	 * 
	 * @param event
	 * @return
	 * @create 2010/10/23
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private String getCharacter(XMLEventReader reader) throws XMLStreamException {
		StringBuilder builder = new StringBuilder();
		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();
			if (event.isCharacters()) {
				builder.append(event.asCharacters().getData());
			} else if (event.isEndElement()) {
				return builder.toString();
			}
		}
		return null;
	}

	/**
	 * 「ファイルパス+export.+UUID」形式を引数に指定したFileクラスを返却するメソッド.<br>
	 * 
	 * @return File
	 * @throws IOException
	 * @create 2010/10/27
	 * @author fujimura
	 * @since 3.9.0
	 */
	protected File createFile() throws IOException {

		UUID uuid = UUID.randomUUID();
		String filePath = GFrameworkUtils.getProperty(EXPORTFILE_TEMPORARY_DIRECTORY);
		File file = new File(filePath);
		file.mkdirs();
		String fileName = filePath + "export." + uuid.toString();

		return new File(fileName);
	}

	/**
	 * {@link GValidateError}を作成します
	 * 
	 * @param errorCode エラーコード
	 * @param locale 地域コード
	 * @param type エラータイプ
	 * @param label エラー項目
	 * @param labelSpace エラーが発生しているロールのObjectID
	 * @return
	 * @create 2011/05/18
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private GValidateError createValidateError(String errorCode, Locale locale, GErrorType type, String label, String labelSpace) {

		String message = null;
		if (errorCode != null) {
			message = GErrorMessages.getErrorMessage(errorCode, locale).getMessage();
		}

		GValidateError error = new GValidateError(errorCode, message, type);

		if (label != null) {
			error.setLabel(label);
		}
		if (labelSpace != null && !"".equals(labelSpace)) {
			//エラー発生時、xmlのどの場所でエラーが発生しているかわかるように、ObjectIDを表示する
			error.setLabelspace("ObjectID=" + labelSpace);
		}
		return error;
	}

	private class TransportMenuValidator extends GEditableMenuValidator {

		private String _labelSpaceValue;
		public TransportMenuValidator(Locale locale) {
			super(locale);
		}

		@Override
		public void validateParentObjectIDExisted(String parentObjectID, int rowNo) {
			//存在チェック、アイテムかどうかチェックはこここでやらない
		}

		@Override
		public GValidateError createValidateError(String errorCode, GErrorType errorType, String label, String labelSpace, String description, String[] params) {
			GValidateError error = super.createValidateError(errorCode, errorType, label, labelSpace, description, params);
			//エラー発生時、xmlのどの場所でエラーが発生しているかわかるように、ObjectIDを表示する
			if (_labelSpaceValue != null && !"".equals(_labelSpaceValue)) error.setLabelspace("ObjectID=" + _labelSpaceValue);
			return error;
		}

		public void setLabelSpaceValue(String value) {
			_labelSpaceValue = value;

		}

	}

}