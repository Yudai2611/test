/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Set;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.authorization.GAuthoritySetInterpreter;
import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.authorization.GRole;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.em.zoom.GAccountZoomDaoFactory;

/**
 * RoleManager用の検証クラス.<br>
 * 
 * @create 2011/05/26
 * @author KCCS kyo
 * @since 3.9.0
 */
public class GEditableRoleValidator {

	// 桁数チェックの各値(DB項目の長さ)
	/** ObjectID項目 */
	private static final int ROLE_OBJECTID_DIGITNUMBER = 36;
	/** CompanyCode項目 */
	private static final int ROLE_COMPANY_CODE_DIGITNUMBER = 5;
	/** RoleID項目 */
	private static final int ROLE_ROLEID_DIGITNUMBER = 50;
	/** DisplayNameResourceID項目 */
	private static final int ROLE_DISPLAYNAMERESOURCEID_DIGITNUMBER = 36;
	/** RoleName項目 */
	private static final int ROLE_ROLENAME_DIGITNUMBER = 255;
	/** Locale項目 */
	private static final int ROLE_LOCALE_DIGITNUMBER = 20;
	/** AuthoritySet項目 */
	private static final int ROLE_AUTHORITYSET_DIGITNUMBER = 1023;
	/** Description項目 */
	private static final int ROLE_DESCRIPTION_DIGITNUMBER = 255;
	/** UpdatedPerson項目 */
	private static final int ROLE_UPDATEDPERSON_DIGITNUMBER = 20;

	// Roleの項目名
	/** ObjectID項目 */
	protected static final String OBJECTID = "ObjectID";
	/** CompanyCode項目 */
	protected static final String COMPANY_CODE = "CompanyCode";
	/** RoleID項目 */
	protected static final String ROLEID = "RoleID";
	/** DisplayNameResourceID項目 */
	protected static final String DISPLAYNAMERESOURCEID = "DisplayNameResourceID";
	/** RoleName項目 */
	protected static final String ROLENAME = "RoleName";
	/** Locale項目 */
	protected static final String LOCALE = "Locale";
	/** AuthoritySet項目 */
	protected static final String AUTHORITYSET = "AuthoritySet";
	/** Description項目 */
	protected static final String DESCRIPTION = "Description";
	/** UpdatedPerson項目 */
	protected static final String UPDATEDPERSON = "UpdatedPerson";

	// エラーコード
	/** 桁数が制限を超えています */
	protected static final String MAX_STRING_LENGTH_CHECK_ERRORCODE = "GEM-000002";
	/** 入力して下さい */
	protected static final String REQUIRED_CHECK_ERRORCODE = "GEM-000003";
	/** 桁数が不正です。{0}桁ではありません */
	protected static final String ILLEAGAL_STRING_LENGTH_ERROR = "GEM-000020";
	/** 式に不備があります */
	protected static final String SYNTAX_CHECK_ERRORCODE = "GEM-000004";
	/** 定義したロールが存在しません */
	protected static final String NODEFINED_ROLE_CHECK_ERRORCODE = "GEM-000005";
	/** 循環参照が発生しました */
	protected static final String CIRCULAR_REFERENCE_ROLE_CHECK_ERRORCODE = "GEM-000006";

	/** データが重複しています。 */
	protected static final String UNIQUE_CHECK_ERRORCODE = "GEM-000011";
	/** ロケール */
	private Locale _locale = null;
	/** エラーリスト */
	private List<GValidateError> _errorList = new ArrayList<GValidateError>();
	/** ロールファインダー */
	private RoleFinder _finder = null;

	/**
	 * ロールを検出する際に使用するインターフェースです.<br>
	 * 
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public interface RoleFinder {

		/**
		 * 引数のオブジェクトIDを検索条件に、ロールを検索します.<br>
		 * 
		 * @param objectID オブジェクトID
		 * @return ロール
		 * @create 2011/05/26
		 * @author KCCS kitamura
		 * @since 3.9.0
		 */
		GEditableRole findRole(String objectID);
	}

	/**
	 * デフォルトコンストラクタです.<br>
	 * 内部で、{@link GFrameworkContext}からロケールを取得しています.
	 * 
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GEditableRoleValidator() {
		_locale = GFrameworkContext.getInstance().getLocale();
	}

	/**
	 * 引数にロケールをとる、コンストラクタです.<br>
	 * 
	 * @param locale ロケール
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since
	 */
	public GEditableRoleValidator(Locale locale) {
		_locale = locale;
	}

	/**
	 * 引数に{@link RoleFinder}をとる、コンストラクタです.<br>
	 * 
	 * @param finder {@link RoleFinder}オブジェクト
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GEditableRoleValidator(RoleFinder finder) {
		this();
		_finder = finder;
	}

	/**
	 * 引数にロケールと{@link RoleFinder}をとる、コンストラクタです.<br>
	 * 
	 * @param locale ロケール
	 * @param finder {@link RoleFinder}オブジェクト
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GEditableRoleValidator(Locale locale, RoleFinder finder) {
		_locale = locale;
		_finder = finder;
	}

	/**
	 * {@link GValidateError}型のエラーリストを返します.<br>
	 * 
	 * @return エラーリスト
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public List<GValidateError> getErrorList() {
		return _errorList;
	}

	/**
	 * {@link RoleFinder}オブジェクトを返します.<br>
	 * 
	 * @return  {@link RoleFinder}オブジェクト
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public RoleFinder getRoleFinder() {
		return _finder;
	}

	/**
	 * {@link RoleFinder}オブジェクトを設定します.<br>
	 * 
	 * @param finder {@link RoleFinder}オブジェクト
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public void setRoleFinder(RoleFinder finder) {
		_finder = finder;
	}

	/**
	 * エラーリストにエラーがあるかどうかを判定します.<br>
	 * 
	 * @return 真偽値
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public boolean hasError() {
		return _errorList.size() > 0;
	}

	/**
	 * ロールの入力チェックを行います(RoleID,ObjectIDの重複チェックは行いません)
	 * 
	 * @param role ロール
	 * @create 2011/05/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateRoleSingleItem(GEditableRole role) {
		validateRoleSingleItem(role, -1);
	}

	/**
	 * ロールの入力チェックを行います(RoleID,ObjectIDの重複チェックは行いません)
	 * 
	 * @param role ロール
	 * @param index エラー対象ロールのインデックス
	 * @create 2011/05/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateRoleSingleItem(GEditableRole role, int index) {

		validateCompanyCode(role.getCompanyCode(), index);
		validateRoleID(role.getRoleID(), index);
		validateAuthoritySet(role.getAuthoritySet(), index);
		validateObjectID(role.getObjectID(), index);
		validateDescription(role.getDescription(), index);
		validateDisplayNameResourceID(role.getDisplayNameResourceID(), index);

		for (Entry<Locale, String> entry : role.getDisplayNameMap().entrySet()) {
			String roleName = entry.getValue();
			Locale locale = entry.getKey();
			validateDisplayName(roleName, index);
			validateDisplayNameLocale(locale, index);
		}

		return;
	}

	/**
	 * 会社コードの入力チェックを行います.
	 * 
	 * @param companyCode 会社コード
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateCompanyCode(String companyCode) {
		validateCompanyCode(companyCode, -1);
	}

	/**
	 * 会社コードの入力チェックを行います.
	 * 
	 * @param companyCode 会社コード
	 * @param rowNo 行番号
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateCompanyCode(String companyCode, int rowNo) {
		// 前後の空白文字を取り除く
		companyCode = GStringUtils.nullToBlank(companyCode).trim();
		if (GStringUtils.isEmpty(companyCode)) {
			// エラーがあれば、エラーリストに追加し、呼び出し元に返す。
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, COMPANY_CODE, rowNo));
			return;
		}

		// 必須チェックをクリアすると、桁数チェックを行う
		if (ROLE_COMPANY_CODE_DIGITNUMBER < companyCode.length()) {
			// エラーがあれば、エラーリストに追加する。
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, COMPANY_CODE, rowNo));
		}
	}

	/**
	 * ロールIDの入力チェックを行います.<br>
	 * 
	 * @param roleID ロールID
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateRoleID(String roleID) {
		validateRoleID(roleID, -1);
	}

	/**
	 * ロールIDの入力チェックを行います.<br>
	 * 
	 * @param roleID ロールID
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateRoleID(String roleID, int rowNo) {
		roleID = GStringUtils.nullToBlank(roleID);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(roleID.trim())) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, ROLEID, rowNo));
			return;
		}

		// 桁数チェック
		validateRoleIDMaxLength(roleID, rowNo);
	}
	/**
	 * ロールIDの桁数チェックを行います.<br>
	 * 
	 * @param roleID ロールID
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateRoleIDMaxLength(String roleID, int rowNo) {
		roleID = GStringUtils.nullToBlank(roleID);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(roleID.trim())) {
			return;
		}

		// 桁数チェック
		if (ROLE_ROLEID_DIGITNUMBER < roleID.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, ROLEID, rowNo));
		}
	}

	/**
	 * ロール名の入力チェックを行います.<br>
	 * 
	 * @param roleName ロール名
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateDisplayName(String roleName) {
		validateDisplayName(roleName, -1);
	}

	/**
	 * ロール名の入力チェックを行います.<br>
	 * 
	 * @param roleName ロール名
	 * @param rowNo 行番号
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateDisplayName(String roleName, int rowNo) {
		roleName = GStringUtils.nullToBlank(roleName);
		if (GStringUtils.isEmpty(roleName)) {
			return;
		}

		// ロール名の桁数チェック
		if (ROLE_ROLENAME_DIGITNUMBER < roleName.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, ROLENAME, rowNo));
		}
	}

	/**
	 * ロケールの単項目チェックを行います.<br>
	 * 
	 * @param locale ロケール
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateDisplayNameLocale(Locale locale) {
		validateDisplayNameLocale(locale, -1);
	}

	/**
	 * ロケールの単項目チェックを行います.<br>
	 * 
	 * @param locale ロケール
	 * @param rowNo 行番号
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateDisplayNameLocale(Locale locale, int rowNo) {
		if (locale == null || "".equals(locale.toString())) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, LOCALE, rowNo));
			return;
		}
		if (ROLE_LOCALE_DIGITNUMBER < locale.toString().length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, LOCALE, rowNo));
			return;
		}
		// ロケール構文チェック
		boolean localeFlag = GLocaleUtils.checkLocaleSyntax(locale.toString());
		if (!localeFlag) {
			getErrorList().add(createValidateError(SYNTAX_CHECK_ERRORCODE, LOCALE));
		}
	}

	/**
	 * 権限集合の単項目チェックを行います.<br>
	 * 
	 * @param authoritySet 権限集合
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateAuthoritySet(String authoritySet) {
		validateAuthoritySet(authoritySet, -1);
	}

	/**
	 * 権限集合の単項目チェックを行います.<br>
	 * 
	 * @param authoritySet 権限集合
	 * @param rowNo 行番号
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateAuthoritySet(String authoritySet, int rowNo) {

		authoritySet = GStringUtils.nullToBlank(authoritySet);
		if (GStringUtils.isEmpty(authoritySet)) {
			return;
		}

		// 桁数チェック
		if (ROLE_AUTHORITYSET_DIGITNUMBER < authoritySet.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, AUTHORITYSET, rowNo));
			return;
		}

		// 構文チェック
		Set<String> groupCategorys = GAccountZoomDaoFactory.getInstance().getGroupZoomDaoMap().keySet();
		GAuthoritySetInterpreter interpreter = new GAuthoritySetInterpreter();
		if (!interpreter.validateSyntax(authoritySet, groupCategorys)) {
			getErrorList().add(createValidateError(SYNTAX_CHECK_ERRORCODE, AUTHORITYSET, rowNo));
		}
	}

	/**
	 * オブジェクトIDの単項目チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateObjectID(String objectID) {
		validateObjectID(objectID, -1);
	}

	/**
	 * オブジェクトIDの単項目チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateObjectID(String objectID, int rowNo) {
		// オブジェクトIDの必須(空文字)チェック
		objectID = GStringUtils.nullToBlank(objectID);

		if (GStringUtils.isEmpty(objectID.trim())) {
			// エラーがあれば、エラーリストに追加し、呼び出し元に返す。
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, OBJECTID, rowNo));
			return;
		}

		validateObjectIDMaxLength(objectID, rowNo);
	}
	
	/**
	 * オブジェクトIDの最大桁数チェックを行います.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void validateObjectIDMaxLength(String objectID, int rowNo) {
		// オブジェクトIDの必須(空文字)チェック
		objectID = GStringUtils.nullToBlank(objectID);

		if (GStringUtils.isEmpty(objectID.trim())) {
			return;
		}
		
		if (ROLE_OBJECTID_DIGITNUMBER != objectID.length()) {
			String[] params = new String[] {String.valueOf(ROLE_OBJECTID_DIGITNUMBER)};
			getErrorList().add(createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR, OBJECTID, String.valueOf(rowNo), null, params));
		}
	}

	/**
	 * 備考の単項目チェックを行います.<br>
	 * 
	 * @param description 備考
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateDescription(String description) {
		validateDescription(description, -1);
	}

	/**
	 * 備考の単項目チェックを行います.<br>
	 * 
	 * @param description 備考
	 * @param rowNo 行番号
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateDescription(String description, int rowNo) {
		description = GStringUtils.nullToBlank(description);

		// 桁数チェック
		if (ROLE_DESCRIPTION_DIGITNUMBER < description.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, DESCRIPTION, rowNo));
		}
	}

	/**
	 * 更新者の単項目チェックを行います.<br>
	 * 
	 * @param updatedPerson 更新者
	 * @param rowNo 行番号
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateUpdatedPerson(String updatedPerson, int rowNo) {
		updatedPerson = GStringUtils.nullToBlank(updatedPerson);
		if (GStringUtils.isEmpty(updatedPerson)) {
			return;
		}
		// 桁数チェック
		if (ROLE_UPDATEDPERSON_DIGITNUMBER < updatedPerson.length()) {
			getErrorList().add(createValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, UPDATEDPERSON, rowNo));
		}
	}

	//	public void validateUpdatedDate(Date updatedDate, int rowNo) {
	//	//日付型文字列検証
	//	
	//	if (updatedDate == null) {
	//		return;
	//	}
	//	
	//	try {
	//		String updatedDateStr = GDateUtils.formatToString(updatedDate, GFrameworkUtils.getProperty(DATE_FORMAT));
	//		GDateUtils.toDate(updatedDateStr, GFrameworkUtils.getProperty(DATE_FORMAT));
	//	} catch(ParseException e) {
	//		getErrorList().add(createValidateError(SYNTAX_CHECK_ERRORCODE, UPDATEDDATE, rowNo));
	//	}
	//}

	/**
	 * 表示名リソースIDの単項目チェックを行います.<br>
	 * 
	 * @param displayNameResourceID 表示名リソースID
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateDisplayNameResourceID(String displayNameResourceID) {
		validateDisplayNameResourceID(displayNameResourceID, -1);
	}

	/**
	 * 表示名リソースIDの単項目チェックを行います.<br>
	 * 
	 * @param displayNameResourceID 表示名リソースID
	 * @param rowNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void validateDisplayNameResourceID(String displayNameResourceID, int rowNo) {
		displayNameResourceID = GStringUtils.nullToBlank(displayNameResourceID);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(displayNameResourceID.trim())) {
			getErrorList().add(createValidateError(REQUIRED_CHECK_ERRORCODE, DISPLAYNAMERESOURCEID, rowNo));
			return;
		}

		// 表示名の桁数チェック
		if (ROLE_DISPLAYNAMERESOURCEID_DIGITNUMBER != displayNameResourceID.length()) {
			String[] params = new String[] {String.valueOf(ROLE_DISPLAYNAMERESOURCEID_DIGITNUMBER)};
			getErrorList().add(createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR, DISPLAYNAMERESOURCEID, String.valueOf(rowNo), null, params));
		}
	}

	/**
	 * 権限集合の循環参照チェックを行います.<br>
	 * 
	 * @param authoritySet 権限集合
	 * @param roleObjectID ロールオブジェクトID
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateAuthoritySetCircularReference(String authoritySet, String roleObjectID) {
		validateAuthoritySetCircularReference(authoritySet, roleObjectID, -1);
	}

	/**
	 * 権限集合の循環参照チェックを行います.<br>
	 * 
	 * @param authoritySet 権限集合
	 * @param roleObjectID ロールオブジェクトID
	 * @param rowNo 行番号
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public void validateAuthoritySetCircularReference(String authoritySet, String roleObjectID, int rowNo) {
		Set<String> roleIDSet = new HashSet<String>();
		roleIDSet.add(roleObjectID);
		if (checkCircularReferenceRelation(authoritySet, roleIDSet, getRoleFinder(), rowNo)) {
			getErrorList().add(createValidateError(CIRCULAR_REFERENCE_ROLE_CHECK_ERRORCODE, AUTHORITYSET, rowNo));
		}
	}

	/**
	 * 権限集合の循環参照チェックを行います.<br>
	 * 
	 * @param authoritySet 権限集合
	 * @param roleIDSet ロールIDの集合
	 * @param finder {@link RoleFinder}オブジェクト
	 * @param rowNo 行番号
	 * @return 真偽値(循環参照発生したかどうか)
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	// NOTE EM kyo 簡略できるのでは？
	private boolean checkCircularReferenceRelation(String authoritySet, Set<String> roleIDSet, RoleFinder finder, int rowNo) {

		boolean hasCircularReferenceRelation = false;

		GAuthoritySetInterpreter interpreter = new GAuthoritySetInterpreter();
		List<String> roleObjectIDList = interpreter.extractRoleIDs(authoritySet);

		for (String roleObjectIDTemp : roleObjectIDList) {
			hasCircularReferenceRelation = roleIDSet.contains(roleObjectIDTemp);
			if (hasCircularReferenceRelation) {
				return hasCircularReferenceRelation;
			}
			roleIDSet.add(roleObjectIDTemp);
			GRole role = finder.findRole(roleObjectIDTemp);
			// ロールがDBに存在していない場合、エラー
			if (role == null) {
				//getErrorList().add(createValidateError(NODEFINED_ROLE_CHECK_ERRORCODE, AUTHORITYSET, rowNo));
				getErrorList().add(createValidateError(NODEFINED_ROLE_CHECK_ERRORCODE, GErrorType.ERROR, AUTHORITYSET, String.valueOf(rowNo), roleObjectIDTemp, null));
				//createValidateError(NODEFINED_ROLE_CHECK_ERRORCODE, AUTHORITYSET, rowNo, null,roleObjectIDTemp,null);
				//trueを返すとロールに循環参照が発生することが誤検出される。
				break;
				//return true;
			}

			String authoritySetTemp = role.getAuthoritySet();
			hasCircularReferenceRelation = checkCircularReferenceRelation(authoritySetTemp, roleIDSet, finder, rowNo);

			if (hasCircularReferenceRelation) {
				roleIDSet.clear();
				return hasCircularReferenceRelation;
			}

			roleIDSet.remove(roleObjectIDTemp);
		}

		return hasCircularReferenceRelation;
	}

	/**
	 * GValidateErrorにエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目名
	 * @return 入力エラー情報
	 * @create 2011/05/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, String errorColumn) {
		return createValidateError(errorCode, errorColumn, GErrorType.ERROR);
	}

	/**
	 * {@link GValidateError}にエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorType エラータイプ
	 * @param errorColumn エラー項目名
	 * @param labelSpace ラベルスペース
	 * @param description 備考
	 * @param params パラメータ
	 * @return エラー情報
	 * @create 2011/05/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, GErrorType errorType, String errorColumn, String labelSpace, String description, String[] params) {
		GValidateError error = new GValidateError();

		if (errorCode != null) {
			error.setCode(errorCode);
			if (params != null) {
				error.setMessage(GErrorMessages.getErrorMessage(errorCode, params, _locale).getMessage());
			} else {
				error.setMessage(GErrorMessages.getErrorMessage(errorCode, _locale).getMessage());
			}
		}
		if (errorType != null) {
			error.setType(errorType);
		}
		if (errorColumn != null) {
			error.addFieldId(errorColumn);
			error.setLabel(errorColumn);
		}
		if (labelSpace != null) {
			error.setLabelspace(labelSpace);
		}
		if (description != null) {
			error.setDescription(description);
		}

		return error;
	}

	/**
	 * {@link GValidateError}にエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @param errorType エラータイプ
	 * @return エラー情報
	 * @create 2010/10/30
	 * @author kyo
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, String errorColumn, GErrorType errorType) {
		return createValidateError(errorCode, errorType, errorColumn, null, null, null);
	}

	/**
	 * {@link GValidateError}にエラー情報を設定し、返します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @param rowDataNo 行番号
	 * @return エラー情報
	 * @create 2011/09/13
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GValidateError createValidateError(String errorCode, String errorColumn, int rowDataNo) {
		String labelSpace = null;
		if (rowDataNo != -1) {
			labelSpace = String.valueOf(rowDataNo);
		}
		return createValidateError(errorCode, GErrorType.ERROR, errorColumn, labelSpace, null, null);
	}

	/**
	 * {@link GValidateError}に必須入力エラーの情報を設定し、返します.<br>
	 * 
	 * @param errorColumn エラー項目
	 * @param rowDataNo 行番号
	 * @return エラー情報
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GValidateError createRquierdError(String errorColumn, int rowDataNo) {
		return createValidateError(REQUIRED_CHECK_ERRORCODE, errorColumn, rowDataNo);
	}

	/**
	 * 引数のエラー情報を基に{@link GValidateError}オブジェクトを生成し、エラーリストに追加します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @param rowDataNo 行番号
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void addValidateError(String errorCode, String errorColumn, int rowDataNo) {
		GValidateError error = createValidateError(errorCode, errorColumn, rowDataNo);
		getErrorList().add(error);
	}

	/**
	 * 引数のエラー情報を基に{@link GValidateError}オブジェクトを生成し、エラーリストに追加します.<br>
	 * 
	 * @param errorCode エラーコード
	 * @param errorColumn エラー項目
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void addValidateError(String errorCode, String errorColumn) {
		addValidateError(errorCode, errorColumn, -1);
	}

}
