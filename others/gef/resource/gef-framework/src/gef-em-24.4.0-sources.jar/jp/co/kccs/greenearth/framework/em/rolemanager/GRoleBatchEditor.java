/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.io.File;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateException;

/**
 * RoleManagerの、一括編集操作用インターフェースです.<br>
 * 
 * @create 2011/05/26
 * @author KCCS fujimura
 * @since 3.9.0
 */
public interface GRoleBatchEditor {
	
	/**
	 * 一括編集データを出力します.<br>
	 * 
	 * @param user ユーザー
	 * @param locale ロケール
	 * @return 一括編集データファイル
	 * @throws GResourceProcessingException リソースアクセス時のエラー
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	File exportFile(GUser user, Locale locale) throws GResourceProcessingException;

	/**
	 * 一括編集データを取り込みます.<br>
	 * 
	 * @param file ファイル
	 * @param user ユーザー
	 * @param locale ロケール
	 * @throws GResourceProcessingException リソースアクセス時のエラー
	 * @throws GValidateException ユーザ入力値検証時のエラー
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	void importFile(File file, GUser user, Locale locale) throws GResourceProcessingException, GValidateException;
}
