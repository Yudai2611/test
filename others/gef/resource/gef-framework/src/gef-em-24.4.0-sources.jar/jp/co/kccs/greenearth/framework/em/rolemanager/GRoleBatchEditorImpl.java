/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.management.relation.Role;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GExternalDataSet;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.tools.GCounter;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.authorization.GEditableRoleDao;
import jp.co.kccs.greenearth.framework.authorization.GRole;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.em.rolemanager.GEditableRoleValidator.RoleFinder;

/**
 * ロールの一括編集機能を実現する為のクラスです。<br>
 * 一括編集出力、取り込み機能の実装を提供します。<br>
 *
 * @create 2010/11/04
 * @author KCCS fujimura
 * @since 3.9.0
 */
public class GRoleBatchEditorImpl implements GRoleBatchEditor {

	/** ロール */
	private static final String ROLE_PREFIX = "Role";
	/** ロール　+ . */
	private static final String ROLE_DOT_PREFIX = ROLE_PREFIX + ".";
	/** AND　 */
	private static final String OP_AND = "&&";
	/** OR */
	private static final String OP_OR = "||";
	/** 右括弧　 */
	private static final String PARENTHESIS_RIGHT = ")";
	/** 二重右括弧　 */
	private static final String DOUBLE_PARENTHESIS_RIGHT = "))";

	private static final String REGULAR = "(" + ROLE_PREFIX + ")\\..*?((&&)|\\)|(\\|\\|)|$)";
	private static final Pattern PATTERN = Pattern.compile(REGULAR);

	/** Roleシートの列番号 */
	private static final int ROLE_SHEET_REQUIRE_CHECK_COLUMN_NO = 0;
	private static final int ROLE_SHEET_NO_COLUMN_NO = 1;
	private static final int ROLE_SHEET_OBJECTID_COLUMN_NO = 2;
	private static final int ROLE_SHEET_ROLEID_COLUMN_NO = 3;
	private static final int ROLE_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO = 4;
	private static final int ROLE_SHEET_ROLENAME_COLUMN_NO = 5;
	private static final int ROLE_SHEET_AUTHORITYSET_COLUMN_NO = 6;
	private static final int ROLE_SHEET_DESCRIPTION_COLUMN_NO = 7;
	private static final int ROLE_SHEET_UPDATEDPERSON_COLUMN_NO = 8;
	private static final int ROLE_SHEET_UPDATEDDATE_COLUMN_NO = 9;

	/** Localizationシートの列番号 */
	private static final int LOCALIZATION_SHEET_REQUIRE_CHECK_COLUMN_NO = 0;
	private static final int LOCALIZATION_SHEET_NO_COLUMN_NO = 1;
	private static final int LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO = 2;
	private static final int LOCALIZATION_SHEET_VALUE_COLUMN_NO = 3;
	private static final int LOCALIZATION_SHEET_LOCALE_COLUMN_NO = 4;

	/** ユーザー情報出力列番号 */
	private static final int ROLE_SHEET_USERINFORMATION_COLUMN_NO = 8;
	/** ユーザー情報出力行番号 */
	private static final int ROLE_SHEET_USERINFORMATION_COMPANYCD_ROW_NO = 1;
	private static final int ROLE_SHEET_USERINFORMATION_USERID_ROW_NO = 2;
	private static final int ROLE_SHEET_USERINFORMATION_USERNAME_ROW_NO = 3;
	private static final int ROLE_SHEET_USERINFORMATION_LOCALE_ROW_NO = 4;
	private static final int ROLE_SHEET_USERINFORMATION_EXPORTTIME_ROW_NO = 5;

	/** 明細行の開始インデックス */
	private static final int DATA_START_LINE = 11;
	private static final int END_CELL_COLUMN_NO = 2;

	/** 最終明細行に挿入する文字列 */
	private static final String END = "#END";
	/** #END文字列が無かった場合のエラー数値 */
	private static final int ERROR_NUMBER = -1;

	/** テンプレートの各シート名 */
	private static final String ROLE_SHEET = "Role";
	/** テンプレートの各シート名 */
	private static final String LOCALIZATION_SHEET = "Localization";

	/** 項目名 */
	private static final String ROLEID = "RoleID";
	private static final String OBJECTID = "ObjectID";
	private static final String DISPLAYNAMERESOURCEID = "DisplayNameResourceID";
	private static final String LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME = "ResourceID";
	private static final String LOCALIZATION_SHEET_LOCALE_COLUMN_NAME = "Locale";
	private static final String LOCALIZATION_SHEET_VALUE_COLUMN_NAME = "Value";
	private static final String ROLENAME = "RoleName";
	private static final String UPDATEDDATE = "UpdatedDate";
	/** AuthoritySet項目 */
	protected static final String AUTHORITYSET = "AuthoritySet";
	/** Description項目 */
	protected static final String DESCRIPTION = "Description";
	/** UpdatedPerson項目 */
	protected static final String UPDATEDPERSON = "UpdatedPerson";

	// Localeシートの桁数
	private static final int LOCALIZATION_SHEET_RESOURCEID_DIGITNUMBER = 36;
	private static final int LOCALIZATION_SHEET_VALUE_DIGITNUMBER = 255;
	private static final int LOCALIZATION_SHEET_LOCALE_DIGITNUMBER = 20;

	// エラーコード
	/** データが重複しています */
	private static final String UNIQUE_CHECK_ERRORCODE = "GEM-000011";
	/** 該当データがありません */
	private static final String CONSISTENCY_CHECK_ERRORCODE = "GEM-000008";
	/** 入力して下さい */
	private static final String REQUIRED_CHECK_ERRORCODE = "GEM-000003";
	/** 桁数が不正です */
	private static final String ILLEAGAL_STRING_LENGTH_ERROR = "GEM-000020";
	/** 桁数が制限を超えています */
	private static final String MAX_STRING_LENGTH_CHECK_ERRORCODE = "GEM-000002";
	/** 不正な値が入力されています */
	private static final String ILLEGAL_VALUE_CHECK_ERRORCODE = "GEM-000013";
	/** 日付型文字列に不備があります。 */
	private final String UPDATEDDATE_CHECK_ERRORCODE = "GEM-000017";
	/** エラーコード */
	private static final String SHEET_FORMAT_ERRORCODE = "GEM-000001";
	/** セルの型が不正です */
	private static final String ILLEGAL_CELL_TYPE_ERRORCODE = "GEM-000030";

	/** デフォルトバッファサイズ */
	private int _bufferSize = 512;
	private String _templatePath = null;

	/** オブジェクトIDとロールIDのマップ */
	private Map<String, String> _objectIDAndRoleIDMap = new HashMap<String, String>();

	/** DATE_FORMAT */
	private static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss"; // TODO フォーマットを外だしに
	/** エクスポートファイル一時保管ディレクトリパスのプロパティキー */
	private static final String EXPORTFILE_TEMPORARY_DIRECTORY = "geframe.em.File.TempDirectory";

	/**
	 * 引数に一括編集用テンプレートパスを受け取るコンストラクタ
	 *
	 * @param templatePath
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since
	 */
	public GRoleBatchEditorImpl(String templatePath) {
		this._templatePath = templatePath;
	}

	/**
	 * バッファサイズを引数に取るコンストラクタです。<br>
	 * バッファサイズはファイルにエクセル情報を書き込む際に使用します。<br>
	 *
	 * @param bufferSize
	 * @create 2010/11/11
	 * @author KCCS fujimura
	 * @since 3.9.0
	**/
	public GRoleBatchEditorImpl(String templatePath, int bufferSize) {
		this(templatePath);
		this._bufferSize = bufferSize;
	}

	/**
	 * {@link GEditableRoleDao}を実装したクラスを取得します。
	 *
	 * @return roleDaoオブジェクト
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public GEditableRoleDao getRoleDao() {
		return GEditableRoleDao.Factory.getInstance();
	}

	/**
	 * 	ロール情報をエクセルファイルに出力するメソッド.<br>
	 * 【出力ファイル形式 .xls　の理由】<br>
	 * 現在のEnterpriseManagerV3では、.xls形式の出力となっています。<br>
	 * 今回のエクセル出力用テンプレートにはマクロが含まれております。<br>
	 * 現時点でのPOIでは、マクロを出力する為のクラスは.xls形式のものしか提供されていない為,<br>
	 * 出力ファイル形式は.xlsとなります。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleBatchEditor#exportFile(jp.co.kccs.greenearth.framework.auth.GUser, java.util.Locale)
	 * @param user ユーザー情報
	 * @param locale ロケール
	 * @return 一括編集用ファイル
	 * @throws GResourceProcessingException 例外
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public File exportFile(GUser user, Locale locale) throws GResourceProcessingException {
		// ロール情報を検索する処理
		// DBにある全ロール情報を検索し、ロールセットを返します。
		//GExternalDataSet<GEditableRole> roleSet = getRoleDao().findRoleSet(user.getCompany().getCode(), null, null, locale);
		GExternalDataSet<GEditableRole> roleSet = getRoleDao().findRoleSet(user.getCompany().getCode(), null, null);

		InputStream in = null;
		OutputStream out = null;
		try {

			// ワークブックオブジェクト作成(xls形式ワークブック)
			in = new BufferedInputStream(GFileUtils.getResource(_templatePath).openStream(), _bufferSize);
			Workbook workbook = new HSSFWorkbook(in);

			// Excelシートに書き込む処理
			writeRoleSet(workbook, roleSet, user, locale);

			File excelFile = createFile();
			out = new BufferedOutputStream(new FileOutputStream(excelFile), _bufferSize);

			workbook.write(out);

			return excelFile;
		} catch (IOException e) {
			throw new GResourceProcessingException(e);
		} finally {
			try {
				if (roleSet != null) {
					roleSet.close();
				}
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				throw new GResourceProcessingException(e);
			}
		}
	}

	/**
	 * Roleシート、Localizationシートに関して、データを{@link Workbook}オブジェクトに出力するメソッドです。<br>
	 *
	 * @param workbook ワークブック
	 * @param roleSet ロールセット
	 * @param roleLocale ロケール
	 * @create 2010/11/10
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeRoleSet(Workbook workbook, GExternalDataSet<GEditableRole> roleSet, GUser user, Locale roleLocale) throws GResourceProcessingException {
		// 行番号
		GCounter roleRowCounter = new GCounter();
		GCounter localizationRowCounter = new GCounter();

		// Roleシートを取得する
		Sheet roleSheet = workbook.getSheet(ROLE_SHEET);
		// Localizationシートを取得する
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		//ユーザー情報出力処理
		writeUserInformation(roleSheet, user, roleLocale);

		// Role情報出力処理
		while (roleSet.next()) {
			GEditableRole role = roleSet.get();
			writeRole(workbook, role, roleLocale, roleRowCounter, localizationRowCounter);
			roleRowCounter.countUp();
		}

		// 最終明細行の次の行に最終行である事を表す文字列を挿入
		// Roleシート
		Row roleSheetRow = roleSheet.createRow(roleRowCounter.getCount() + DATA_START_LINE);
		Cell objectIDCell = roleSheetRow.createCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
		objectIDCell.setCellValue(END);
		// Localizationシート
		Row localizationSheetRow = localizationSheet.createRow(localizationRowCounter.getCount() + DATA_START_LINE);
		Cell displayNameResourceIDCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
		displayNameResourceIDCell.setCellValue(END);
	}

	/**
	 * {@link Workbook}オブジェクトに{@link Role}オブジェクト情報を書き込みます。
	 *
	 * @param workbook ワークブック
	 * @param role ロール
	 * @param locale ロケール
	 * @param roleRowCounte ロールシートへの挿入行カウンタ
	 * @param localizationRowCounter Localizationシートへの挿入行カウンタ
	 * @throws GResourceProcessingException 例外
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeRole(Workbook workbook, GEditableRole role, Locale locale, GCounter roleRowCounter, GCounter localizationRowCounter) throws GResourceProcessingException {
		// Roleシートを取得する
		Sheet roleSheet = workbook.getSheet(ROLE_SHEET);
		// Localizationシートを取得する
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		// ※POIではエクセル上のを0行目からカウントする
		Row roleSheetRow = roleSheet.createRow(roleRowCounter.getCount() + DATA_START_LINE);

		// Roleシートデータ入力処理
		// 列A:必須チェック(IF関数)
		// //※エクセルシート上のインデックスは1から始まるので開始行に+1
		int roleSheetRowNo = roleRowCounter.getCount() + DATA_START_LINE + 1;
		StringBuilder role_sb = new StringBuilder();
		role_sb.append("IF(C").append(roleSheetRowNo);
		role_sb.append("=\"\",\"NG\",IF(D").append(roleSheetRowNo);
		role_sb.append("=\"\",\"NG\",IF(E").append(roleSheetRowNo);
		role_sb.append("=\"\",\"NG\",\"OK\")))");
		Cell roleSheetRequireCheckCell = roleSheetRow.createCell(ROLE_SHEET_REQUIRE_CHECK_COLUMN_NO);
		roleSheetRequireCheckCell.setCellFormula(role_sb.toString());

		// 列B:No　※No項目は1から始まる為+1
		Cell roleSheetNoCell = roleSheetRow.createCell(ROLE_SHEET_NO_COLUMN_NO);
		roleSheetNoCell.setCellValue(roleRowCounter.getCount() + 1);

		// 列C:ObjectID
		Cell objectIDCell = roleSheetRow.createCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
		objectIDCell.setCellValue(role.getObjectID());

		// 列D:RoleID
		Cell roleIDCell = roleSheetRow.createCell(ROLE_SHEET_ROLEID_COLUMN_NO);
		roleIDCell.setCellValue(role.getRoleID());

		// 列E:DisplayNameResourceID
		Cell roleSheetDisplayNameResourceIDCell = roleSheetRow.createCell(ROLE_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);
		roleSheetDisplayNameResourceIDCell.setCellValue(role.getDisplayNameResourceID());

		// 列F:RoleName
		Cell roleSheetRoleNameCell = roleSheetRow.createCell(ROLE_SHEET_ROLENAME_COLUMN_NO);
		if (role.getDisplayNameMap() != null) {
			roleSheetRoleNameCell.setCellValue(role.getDisplayNameMap().get(locale));
		}

		// 列G:AuthoritySet
		Cell authoritySetCell = roleSheetRow.createCell(ROLE_SHEET_AUTHORITYSET_COLUMN_NO);
		String authoritySet = role.getAuthoritySet();
		if (authoritySet != null) {
			authoritySet = convertObjectIDToRoleID(authoritySet);
		}
		authoritySetCell.setCellValue(authoritySet);
		//		authoritySetCell.setCellValue(role.getAuthoritySet());

		// 列H:Description
		Cell descriptionCell = roleSheetRow.createCell(ROLE_SHEET_DESCRIPTION_COLUMN_NO);
		descriptionCell.setCellValue(role.getDescription());

		//列I:UpdatedPerson
		Cell updatedPersonCell = roleSheetRow.createCell(ROLE_SHEET_UPDATEDPERSON_COLUMN_NO);
		updatedPersonCell.setCellValue(role.getUpdatedPerson());

		//列J:UpdatedDate
		if (role.getUpdatedDate() != null) {
			Cell updatedDateCell = roleSheetRow.createCell(ROLE_SHEET_UPDATEDDATE_COLUMN_NO);
			GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
			updatedDateCell.setCellValue(formatter.format(role.getUpdatedDate(), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT));
		}

		// Localizationシートデータ入力処理
		// ロールのgetDisplayName()のサイズ分取り出すfor文
		for (Locale localizationLocale : role.getDisplayNameMap().keySet()) {
			writeDisplayName(localizationSheet, role, localizationLocale, localizationRowCounter);
			localizationRowCounter.countUp();
		}
	}

	/**
	 * Localizationシートへ表示名の情報を書き込みます。
	 *
	 * @param localizationSheet ローカライゼーションシート
	 * @param role ロール
	 * @param locale ロケール
	 * @param localizationRowCounter ローカライゼーションシートの行カウンタ
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void writeDisplayName(Sheet localizationSheet, GEditableRole role, Locale locale, GCounter localizationRowCounter) {
		// ※行は0行目からカウントされる
		Row localizationSheetRow = localizationSheet.createRow(localizationRowCounter.getCount() + DATA_START_LINE);

		// // ※列も0番目からカウントされる
		// // 列A:必須チェック(IF関数)
		int localizationSheetRowNo = localizationRowCounter.getCount() + DATA_START_LINE + 1;
		StringBuilder localization_sb = new StringBuilder();
		localization_sb.append("IF(C").append(localizationSheetRowNo);
		localization_sb.append("=\"\",\"NG\",IF(E").append(localizationSheetRowNo);
		localization_sb.append("=\"\",\"NG\",\"OK\"))");
		Cell localizationSheetRequireCheckCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_REQUIRE_CHECK_COLUMN_NO);
		localizationSheetRequireCheckCell.setCellFormula(localization_sb.toString());

		// 列B:No7
		Cell localizationNoCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_NO_COLUMN_NO);
		localizationNoCell.setCellValue(localizationRowCounter.getCount() + 1);

		// 列C:Key char型は末尾にスペースが付加されるため、トリムする。
		Cell localizationSheetDisplayNameResourceIDCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
		localizationSheetDisplayNameResourceIDCell.setCellValue(role.getDisplayNameResourceID());

		// 列D:ロール名
		Cell localizationSheetRoleNameCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);
		localizationSheetRoleNameCell.setCellValue(role.getDisplayNameMap().get(locale));

		// 列E:ロケール
		Cell localizationLocaleCell = localizationSheetRow.createCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
		localizationLocaleCell.setCellValue(locale.toString());
	}

	/**
	 * 引数に与えられたファイルを元に、洗い替えを行います。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleBatchEditor#importFile(java.io.File, jp.co.kccs.greenearth.framework.auth.GUser, java.util.Locale)
	 * @param file ファイル
	 * @param user ユーザー
	 * @param locale ロケール
	 * @throws GResourceProcessingException 例外
	 * @throws GValidateException 例外
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public void importFile(File file, GUser user, Locale locale) throws GResourceProcessingException, GValidateException {
		InputStream stream = null;
		try {
			// ワークブックオブジェクト作成
			stream = new BufferedInputStream(new FileInputStream(file), _bufferSize);
			Workbook workbook = new HSSFWorkbook(stream);

			convertWorkbook(workbook);

			// 入力チェックを行う
			validateWorkbook(workbook, locale);

			// 登録処理(洗替)を行う
			// GERoleテーブルとGERoleLocalizationResourceテーブルを全件削除する。
			getRoleDao().deleteRoleAll(user.getCompany().getCode());
			insertWorkbook(workbook, user);

		} catch (IOException e) {
			throw new GResourceProcessingException(e);
		} finally {
			if (stream != null) {
				try {
					stream.close();
				} catch (IOException ioe) {
					throw new GResourceProcessingException(ioe);
				}
			}
		}
	}

	/**
	 * 引数に与えられたロールシートの情報を元に、ロールIDをキー、オブジェクトIDを値とした、<br>
	 * Mapを組み立て、返却します。
	 *
	 * @param roleSheet ロールシート
	 * @return マップ
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private Map<String, String> createMapWithRoleIDAndObjectID(Sheet roleSheet) {

		Map<String, String> roleIDAndObjectIDMap = new HashMap<String, String>();

		int roleLastRowDataNum = getEndCellRowNumber(roleSheet);
		// Excelの実際の行番号変数
		int rowNo = 0;

		// 明細行チェック
		for (int i = 0; i < roleLastRowDataNum - DATA_START_LINE; i++) {
			rowNo = DATA_START_LINE + i;

			Row row = roleSheet.getRow(rowNo);

			// 行がnullならチェックしない
			if (row == null) {
				continue;
			}
			Cell roleObjectIDCell = row.getCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
			Cell roleIDCell = row.getCell(ROLE_SHEET_ROLEID_COLUMN_NO);
			if (roleObjectIDCell == null || roleObjectIDCell.getCellType() != CellType.STRING
					|| roleIDCell == null || roleIDCell.getCellType() != CellType.STRING) {
				continue;
			}

			String roleObjectID = roleObjectIDCell.getStringCellValue();
			String roleID = roleIDCell.getStringCellValue();

			roleIDAndObjectIDMap.put(roleID, roleObjectID);

		}
		return roleIDAndObjectIDMap;
	}

	/**
	 * エクセルシートの特定の列にあるEND文字列を検索します。<br>
	 * END文字列があれば、その行番号を返します。 END文字列が無ければ、-1を返します。<br>
	 * エクセル用<br>
	 *
	 * @param roleSheet
	 * @return int 行番号
	 * @create 2010/11/05
	 * @author fujimura
	 * @since 3.9.0
	 */
	private int getEndCellRowNumber(Sheet roleSheet) {

		for (int i = 0; i < roleSheet.getLastRowNum(); i++) {
			Row row = roleSheet.getRow(DATA_START_LINE + i);

			if (row == null) {
				continue;
			}

			Cell cellValue = row.getCell(END_CELL_COLUMN_NO);

			if (cellValue == null || cellValue.getCellType() != CellType.STRING) {
				continue;
			}
			String value = cellValue.getStringCellValue().trim();
			if (value.equals(END)) {
				return DATA_START_LINE + i;
			}
		}
		return ERROR_NUMBER;

	}

	/**
	 * ワークブックの情報を適切なデータであるかチェックします。<br>
	 * 第一段階で、Role、Localization両シートの単項目チェックを行い、<br>
	 * 第二段階で、両シートの整合性チェックを行います。
	 *
	 * @param workbook ワークブック
	 * @param locale ロケール
	 * @throws GValidateException　エラー
	 * @throws GResourceProcessingException　エラー
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	protected void validateWorkbook(Workbook workbook, Locale locale) throws GValidateException, GResourceProcessingException {
		// RoleとLocalizationシートのチェッククラスの作成
		GEditableRoleValidator validator = new GEditableRoleValidator(locale);

		// シートを取得
		Sheet roleSheet = workbook.getSheet(ROLE_SHEET);
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		// シートの前提条件チェック(①両シートがあるか②#END文字列が両シートにあるかチェック)
		checkSheetExist(roleSheet, localizationSheet, validator);

		int roleLastRowDataNum = getEndCellRowNumber(roleSheet);
		int localizationLastRowDataNum = getEndCellRowNumber(localizationSheet);
		RoleFinder finder = new ExcelRoleFinder(roleSheet, roleLastRowDataNum);
		validator.setRoleFinder(finder);

		checkEndWordExist(roleLastRowDataNum, localizationLastRowDataNum, validator);

		// 解析処理①単項目チェック(必須、桁数、構文)
		checkSingleItem(validator, roleSheet, roleLastRowDataNum);
		checkSingleItemLocalization(validator, localizationSheet, localizationLastRowDataNum);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

		// 解析処理②相関チェック(整合性、ユニーク、循環参照)
		checkCorrelation(validator, roleSheet, roleLastRowDataNum, localizationSheet, localizationLastRowDataNum);
		checkCorrelationLocalization(validator, localizationSheet, localizationLastRowDataNum, roleSheet, roleLastRowDataNum);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}
	}

	/**
	 * 	{@link GRole}のインポート解析処理において、単項目チェックを行うメソッドです。<br>
	 * 単項目チェックでは、以下の内容をチェックします。<br>
	 * ①必須 ②桁数 ③構文チェック(AuthoritySetと更新日のみ) エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param roleSheet ロールシート
	 * @param lastRowDataNum　ロールシート最終行番号
	 * @throws GResourceProcessingException リソースアクセス時例外
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItem(GEditableRoleValidator validator, Sheet roleSheet, int lastRowDataNum) throws GResourceProcessingException {

		// Excelの実際の行番号変数
		int rowNo = 0;

		// 明細行チェック
		for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
			rowNo = DATA_START_LINE + i;

			// 明細行を一行ずつ取得する
			Row row = roleSheet.getRow(rowNo);

			// 行がnullならチェックしない
			if (row == null) {
				continue;
			}

			// オブジェクトIDの単項目チェック処理
			checkSingleItemObjectID(validator, row, i + 1);

			// ロールIDの単項目チェック処理
			checkSingleItemRoleID(validator, row, i + 1);

			// 表示名の単項目チェック処理
			checkSingleItemDisplayNameResourceID(validator, row, i + 1);

			// ロール名の単項目チェック処理
			checkSingleItemRoleName(validator, row, i + 1);

			// 権限集合の単項目チェック処理
			checkSingleItemAuthoritySet(validator, row, i + 1);

			// 備考の単項目チェック処理
			checkSingleItemDescription(validator, row, i + 1);

			//更新者の単項目チェック処理
			checkSingleItemUpdatedPerson(validator, row, i + 1);

			//更新日の単項目チェック処理
			checkSingleItemUpdatedDate(validator, row, i + 1);
		}

		//		if( validator.hasError()){
		//			return;
		//		}
		// Role.ロールID -> Role.オブジェクトIDに変換
		//		convertWorkbook(roleSheet);

		//		rowNo = 0;
		//		for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
		//			rowNo = DATA_START_LINE + i;
		//
		//			// 明細行を一行ずつ取得する
		//			Row row = roleSheet.getRow(rowNo);
		//
		//			// 行がnullならチェックしない
		//			if (row == null) {
		//				continue;
		//			}
		//			// 権限集合の単項目チェック処理
		//			checkSingleItemAuthoritySet(validator, row, i + 1);
		//		}
	}

	/**
	 * {@link GRole}のインポート解析処理において、オブジェクトIDの単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemObjectID(GEditableRoleValidator validator, Row row, int rowDataNo){
		Cell objectIDCell = row.getCell(ROLE_SHEET_OBJECTID_COLUMN_NO);

		// オブジェクトIDの必須(null)チェック
		if (objectIDCell == null || objectIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(OBJECTID, rowDataNo));
			return;
		}

		if (objectIDCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, OBJECTID, rowDataNo);
			return;
		}

		String objectID = objectIDCell.getStringCellValue();
		validator.validateObjectID(objectID, rowDataNo);
	}

	/**
	 * {@link GRole}のインポート解析処理において、ロールIDの単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo　行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemRoleID(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell roleIDCell = row.getCell(ROLE_SHEET_ROLEID_COLUMN_NO);

		// 必須(null)チェック
		if (roleIDCell == null || roleIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(ROLEID, rowDataNo));
			return;
		}

		// セルの型チェック
		if (roleIDCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, ROLEID, rowDataNo);
			return;
		}

		String roleID = roleIDCell.getStringCellValue();
		validator.validateRoleID(roleID, rowDataNo);
	}

	/**
	 * {@link GRole}のインポート解析処理において、表示名の単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemDisplayNameResourceID(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell displayNameResourceIDCell = row.getCell(ROLE_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);

		// 必須(null)チェック
		if (displayNameResourceIDCell == null || displayNameResourceIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(DISPLAYNAMERESOURCEID, rowDataNo));
			return;
		}

		// セルの型チェック
		if (displayNameResourceIDCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, DISPLAYNAMERESOURCEID, rowDataNo);
			return;
		}

		String displayNameResourceID = displayNameResourceIDCell.getStringCellValue();
		validator.validateDisplayNameResourceID(displayNameResourceID, rowDataNo);
	}

	/**
	 * {@link GRole}のインポート解析処理において、ロール名の単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemRoleName(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell roleNameCell = row.getCell(ROLE_SHEET_ROLENAME_COLUMN_NO);

		// 項目がnullだった場合、以下の処理は行わない。
		if (roleNameCell == null || roleNameCell.getCellType() == CellType.BLANK) {
			return;
		}

		// セルの型チェック
		if (roleNameCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, ROLENAME, rowDataNo);
			return;
		}

		String roleName = roleNameCell.getStringCellValue();
		validator.validateDisplayName(roleName, rowDataNo);
	}

	/**
	 * {@link GRole}のインポート解析処理において、ロケールの単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param row
	 * @param errorList
	 * @param rowDataNo
	 * @param locale
	 * @create 2010/11/10
	 * @author KCCS fujimura
	 * @since 3.9.0

	protected void checkSingleItemLocale(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell localeCell = row.getCell(ROLE_SHEET_LOCALE_COLUMN_NO);

		// 必須(null)チェック
		if (localeCell == null) {
			validator.getErrorList().add(validator.createRquierdError(LOCALE, rowDataNo));
			return;
		}

		String localeStr = localeCell.getStringCellValue();
		validator.validateDisplayNameLocale(GLocaleUtils.getLocale(localeStr), rowDataNo);
	}
	 */

	/**
	 * {@link GRole}のインポート解析処理において、権限集合の単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemAuthoritySet(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell authoritySetCell = row.getCell(ROLE_SHEET_AUTHORITYSET_COLUMN_NO);

		if (authoritySetCell == null || authoritySetCell.getCellType() == CellType.BLANK) {
			return;
		}

		// セルの型チェック
		if (authoritySetCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, AUTHORITYSET, rowDataNo);
			return;
		}

		String authoritySet = authoritySetCell.getStringCellValue();
		validator.validateAuthoritySet(authoritySet, rowDataNo);
	}

	/**
	 * {@link GRole}のインポート解析処理において、備考の単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemDescription(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell descriptionCell = row.getCell(ROLE_SHEET_DESCRIPTION_COLUMN_NO);

		if (descriptionCell == null || descriptionCell.getCellType() == CellType.BLANK) {
			return;
		}

		// セルの型チェック
		if (descriptionCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, DESCRIPTION, rowDataNo);
			return;
		}

		String description = descriptionCell.getStringCellValue();
		validator.validateDescription(description, rowDataNo);
	}

	/**
	 * {@link GRole}のインポート解析処理において、更新者の単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemUpdatedPerson(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell updatedPersonCell = row.getCell(ROLE_SHEET_UPDATEDPERSON_COLUMN_NO);

		if (updatedPersonCell == null || updatedPersonCell.getCellType() == CellType.BLANK) {
			return;
		}

		// セルの型チェック
		if (updatedPersonCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, UPDATEDPERSON, rowDataNo);
			return;
		}

		String updatedPerson = updatedPersonCell.getStringCellValue();
		validator.validateUpdatedPerson(updatedPerson, rowDataNo);

	}

	/**
	 * {@link GRole}のインポート解析処理において、更新日の単項目チェックを行うメソッドです。<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param row チェック対象行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemUpdatedDate(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell updatedDateCell = row.getCell(ROLE_SHEET_UPDATEDDATE_COLUMN_NO);

		if (updatedDateCell == null || updatedDateCell.getCellType() == CellType.BLANK) {
			return;
		}

		// セルの型チェック
		if (updatedDateCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, UPDATEDDATE, rowDataNo);
			return;
		}

		try {
			String updatedDateStr = updatedDateCell.getStringCellValue();
			GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
			formatter.parse(updatedDateStr, GFrameworkUtils.getDefaultLocale(), DATE_FORMAT);
		} catch (ParseException e) {
			validator.getErrorList().add(validator.createValidateError(UPDATEDDATE_CHECK_ERRORCODE, UPDATEDDATE, rowDataNo));
			return;
		}
	}

	/**
	 * 	Roleのインポート解析処理において、Localizationシートの単項目チェックを行うメソッドです。<br>
	 * 単項目チェックでは、以下の内容をチェックします。<br>
	 * ①必須
	 * ②桁数
	 * ③構文チェック(Localeのみ)
	 *
	 * @param validator エラー格納クラス
	 * @param localizationSheet　ローカライゼーションシート
	 * @param lastRowDataNum　最終行番号
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemLocalization(GEditableRoleValidator validator, Sheet localizationSheet, int lastRowDataNum) {

		// Excelの行番号変数
		int rowNo = 0;

		// 明細行チェック
		for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {

			rowNo = DATA_START_LINE + i;
			// 明細行を一行ずつ取得する
			Row row = localizationSheet.getRow(rowNo);

			//行がnullならチェックしない。
			if (row == null) {
				continue;
			}

			// リソースIDの単項目チェック処理
			checkSingleItemResourceID(validator, row, i + 1);

			// 値の単項目チェック処理
			checkSingleItemValue(validator, row, i + 1);

			// ロケールの単項目チェック処理
			checkSingleItemDisplayNameLocale(validator, row, i + 1);

		}
	}

	/**
	 * Roleのインポート解析処理において、リソースIDの単項目チェックを行うメソッドです。<br>
	 *
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemResourceID(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell resourceIDCell = row.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);

		//必須(null)チェック
		if (resourceIDCell == null || resourceIDCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo));
			return;
		}

		// セルの型チェック
		if (resourceIDCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo);
			return;
		}

		String resourceID = resourceIDCell.getStringCellValue();
		//		validator.checkSingleItemKey(key, rowDataNo);
		resourceID = GStringUtils.nullToBlank(resourceID);
		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(resourceID.trim())) {
			validator.getErrorList().add(validator.createRquierdError(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo));
			return;
		}

		// 桁数チェック
		if (LOCALIZATION_SHEET_RESOURCEID_DIGITNUMBER != resourceID.length()) {
			//validator.addValidateError(ILLEAGAL_STRING_LENGTH_ERROR, LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, rowDataNo);
			String[] params = new String[] {String.valueOf(LOCALIZATION_SHEET_RESOURCEID_DIGITNUMBER)};
			GEditableRoleValidator roleValidator = new GEditableRoleValidator();
			validator.getErrorList().add(roleValidator.createValidateError(ILLEAGAL_STRING_LENGTH_ERROR, GErrorType.ERROR, LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, String.valueOf(rowDataNo), null, params));
		}
	}

	/**
	 * Roleのインポート解析処理において、値の単項目チェックを行うメソッドです。<br>
	 *
	 * @param validator チェッククラス
	 * @param row 行オブジェクト
	 * @param rowDataNo 行番号
	 * @create 2011/05/06
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemValue(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell valueCell = row.getCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);

		if (valueCell == null || valueCell.getCellType() == CellType.BLANK) {
			return;
		}

		// セルの型チェック
		if (valueCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, LOCALIZATION_SHEET_VALUE_COLUMN_NAME, rowDataNo);
			return;
		}

		String value = valueCell.getStringCellValue();
		if (GStringUtils.isEmpty(value)) {
			return;
		}

		// 桁数チェック
		if (LOCALIZATION_SHEET_VALUE_DIGITNUMBER < value.length()) {
			validator.addValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, LOCALIZATION_SHEET_VALUE_COLUMN_NAME, rowDataNo);
		}

	}

	/**
	 * Roleのインポート解析処理において、ロケールの単項目チェックを行うメソッドです。<br>
	 *
	 * @param row
	 * @param errorList
	 * @param rowDataNo
	 * @param locale
	 * @create 2010/11/10
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkSingleItemDisplayNameLocale(GEditableRoleValidator validator, Row row, int rowDataNo) {
		Cell localeCell = row.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);

		// 必須(null)チェック
		if (localeCell == null || localeCell.getCellType() == CellType.BLANK) {
			validator.getErrorList().add(validator.createRquierdError(LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo));
			return;
		}

		// セルの型チェック
		if (localeCell.getCellType() != CellType.STRING) {
			validator.addValidateError(ILLEGAL_CELL_TYPE_ERRORCODE, LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo);
			return;
		}

		String localeStr = localeCell.getStringCellValue();
		localeStr = GStringUtils.nullToBlank(localeStr);

		// 必須(空文字)チェック
		if (GStringUtils.isEmpty(localeStr.trim())) {
			validator.addValidateError(REQUIRED_CHECK_ERRORCODE, LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo);
			return;
		}

		// 桁数チェック
		if (LOCALIZATION_SHEET_LOCALE_DIGITNUMBER < localeStr.length()) {
			validator.addValidateError(MAX_STRING_LENGTH_CHECK_ERRORCODE, LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo);
			return;
		}

		// 構文チェック
		boolean localeFlag = GLocaleUtils.checkLocaleSyntax(localeStr);
		if (!localeFlag) {
			validator.addValidateError(ILLEGAL_VALUE_CHECK_ERRORCODE, LOCALIZATION_SHEET_LOCALE_COLUMN_NAME, rowDataNo);
		}
	}

	/**
	 * {@link GRole}のインポート解析処理において、相関チェックを行うメソッドです。<br>
	 * 相関チェックでは、以下の内容をチェックします。<br>
	 * ①ユニーク<br>
	 * ②整合性<br>
	 * ③循環参照チェック<br>
	 * エクセル用<br>
	 *
	 * @param validator エラー格納クラス
	 * @param roleSheet ロールシート
	 * @param roleEndIndex　ロールシート最終行番号
	 * @param localizationSheet　ローカライゼーションシート
	 * @param localizationEndIndex ローカライゼーションシート最終行番号
	 * @throws GResourceProcessingException　例外
	 * @throws GValidateException 例外
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkCorrelation(GEditableRoleValidator validator, Sheet roleSheet, int roleEndIndex, Sheet localizationSheet, int localizationEndIndex) throws GResourceProcessingException , GValidateException{

		// ObjectIDのユニークチェック
		checkUniqueObjectID(validator, roleSheet, roleEndIndex);

		// RoleIDのユニークチェック
		checkUniqueRoleID(validator, roleSheet, roleEndIndex);

		// ユニークチェックにてエラーがあった場合、循環参照チェックを行わない
		if(validator.hasError()){
			throw new GValidateException(validator.getErrorList());
		}


		// 多言語情報のシート間相関チェック
		checkRoleSheetConsistency(validator, roleSheet, roleEndIndex, localizationSheet, localizationEndIndex);

		// 権限セットの循環参照チェック＋式中ロールの存在チェック
		checkRoleRelation(validator, roleSheet, roleEndIndex);

		//		GListMap<String, List<String>> listMap = new GListMapImpl<String, List<String>>();
		//
		//		// Excelの実際の行番号変数
		//		int rowNo = 0;
		//
		//		// 明細行チェック
		//		for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
		//			rowNo = DATA_START_LINE + i;
		//			// 明細行を一行ずつ取得する
		//			Row row = roleSheet.getRow(rowNo);
		//
		//			// 行がnullならチェックしない
		//			if (row == null) {
		//				continue;
		//			}
		//
		//			// オブジェクトIDの相関チェック処理(ユニークチェックのみ)
		//			checkCorrelationObjectID(roleSheet, row, errorList, i + 1, lastRowDataNum, locale);
		//
		//			// ロールIDの相関チェック処理(ユニークチェックのみ)
		//			checkCorrelationRoleID(roleSheet, row, errorList, i + 1, lastRowDataNum, locale);
		//
		//			// RoleシートからLocalizationシートへの整合性チェック
		//			checkRoleSheetConsistency(localizationSheet, row, errorList, i + 1, locale);
		//
		//			Cell roleIDCell = row.getCell(ROLE_SHEET_ROLEID_COLUMN_NO);
		//			String roleID = roleIDCell.getStringCellValue();
		//			Cell authoritySetCell = row.getCell(ROLE_SHEET_AUTHORITYSET_COLUMN_NO);
		//			String authoritySet = authoritySetCell.getStringCellValue();
		//			List<String> roleIDlist = getRoleIDList(authoritySet);
		//			listMap.put(roleID, roleIDlist);
		//		}
		//
		//		// ロール存在のチェックと循環参照チェックを行う
		//		checkRoleRelation(listMap, errorList, locale);

	}

	/**
	 *  {@link GRole}のインポート解析処理において、循環参照チェックを行うメソッドです。<br>
	 *
	 * @param validator エラー格納クラス
	 * @param roleSheet ロールシート
	 * @param lastRowIndex ロールシート最終行番号
	 * @throws GResourceProcessingException 例外
	 * @create 2011/05/21
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkRoleRelation(GEditableRoleValidator validator, Sheet roleSheet, int lastRowIndex) throws GResourceProcessingException {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = roleSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			Cell objectIDCell = mainRow.getCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
			String objectID = objectIDCell.getStringCellValue();
			Cell authoritySetCell = mainRow.getCell(ROLE_SHEET_AUTHORITYSET_COLUMN_NO);
			if (authoritySetCell == null) {
				continue;
			}
			String authoritySet = authoritySetCell.getStringCellValue();
			validator.validateAuthoritySetCircularReference(authoritySet, objectID, mainIndex - DATA_START_LINE + 1);
		}
	}

	/**
	 * ユーザ名/グループ名/ロール名を抽出します.
	 *
	 * @param tempStr
	 * @param prefix
	 * @return ユーザ名/グループ名/ロール名
	 * @author KCCS kyo
	 * @since 2010/10/15
	 */
	private String extractID(String tempStr, String prefix) {
		String nameTemp = null;
		if (tempStr.endsWith(DOUBLE_PARENTHESIS_RIGHT) || tempStr.endsWith(OP_AND) || tempStr.endsWith(OP_OR)) {
			nameTemp = tempStr.substring(prefix.length(), tempStr.length() - 2);
		} else if (tempStr.endsWith(PARENTHESIS_RIGHT)) {
			nameTemp = tempStr.substring(prefix.length(), tempStr.length() - 1);
		} else {
			nameTemp = tempStr.substring(prefix.length(), tempStr.length());
		}
		return nameTemp;
	}

	/**
	 * エクセルファイルのコンバートを行います.<br>
	 * 権限集合セルの値を「Role.ロールID」→「Role.オブジェクトID」のようにコンバートします。<br>
	 *
	 *
	 * @param workbook
	 * @create 2011/05/11
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	private void convertWorkbook(Workbook workbook)
	// private void convertWorkbook(Sheet roleSheet)
	{

		Sheet roleSheet = workbook.getSheet(ROLE_SHEET);
		if (roleSheet == null) {
			return;
		}
		//RoleIDとObjectIDのマップを作成
		Map<String, String> roleIDAndObjectIDMap = createMapWithRoleIDAndObjectID(roleSheet);

		int roleLastRowDataNum = getEndCellRowNumber(roleSheet);
		int rowNo = 0;

		for (int i = 0; i < roleLastRowDataNum - DATA_START_LINE; i++) {
			rowNo = DATA_START_LINE + i;

			// 明細行を一行ずつ取得する
			Row row = roleSheet.getRow(rowNo);

			// 行がnullならチェックしない
			if (row == null) {
				continue;
			}
			Cell authritySetCell = row.getCell(ROLE_SHEET_AUTHORITYSET_COLUMN_NO);
			if (authritySetCell == null || authritySetCell.getCellType() != CellType.STRING) {
				continue;
			}
			String authritySet = authritySetCell.getStringCellValue();
			authritySet = convertRoleIDToObjectID(authritySet, roleIDAndObjectIDMap);
			authritySetCell.setCellValue(authritySet);
		}
	}

	/**
	 * エクセルファイルのコンバートを行います.<br>
	 * 権限集合セルの値を「Role.オブジェクトID」→「Role.ロールID」のようにコンバートします。<br>
	 *
	 * @param authoritySet 権限集合
	 * @param roleIDAndObjectIDMap マップ
	 * @return　コンバートした値
	 * @create 2011/05/21
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	private String convertRoleIDToObjectID(String authoritySet, Map<String, String> roleIDAndObjectIDMap) {
		// 正規表現で、ロールを抽出する。
		// 例：ロールフォーマット　 Role.CCC → CCC;

		Matcher matcher = PATTERN.matcher(authoritySet);

		while (matcher.find()) {
			String tempStr = matcher.group();
			// ロール名の抽出
			String roleIDTemp = extractID(tempStr, ROLE_DOT_PREFIX);
			String roleObjectIDTemp = roleIDAndObjectIDMap.get(roleIDTemp);
			if (roleObjectIDTemp != null) {
				authoritySet = authoritySet.replaceFirst(roleIDTemp, roleObjectIDTemp);
			}
		}

		return authoritySet;
	}

	private String convertObjectIDToRoleID(String authoritySet) throws GResourceProcessingException {

		// 正規表現で、ロールを抽出する。
		// 例：ロールフォーマット　 Role.CCC → CCC;

		Matcher matcher = PATTERN.matcher(authoritySet);

		GEditableRoleDao roleDao = getRoleDao();

		while (matcher.find()) {
			String tempStr = matcher.group();
			// ロール名の抽出
			String roleObjectIDTemp = extractID(tempStr, ROLE_DOT_PREFIX);

			String roleIDTemp = _objectIDAndRoleIDMap.get(roleObjectIDTemp);
			if (roleIDTemp == null) {
				GRole role = roleDao.findRole(roleObjectIDTemp);
				roleIDTemp = (role!=null) ? role.getRoleID(): "[RoleID not found]";
				//roleIDTemp = role.getRoleID();
				_objectIDAndRoleIDMap.put(roleObjectIDTemp, roleIDTemp);
			}
			authoritySet = authoritySet.replaceFirst(roleObjectIDTemp, roleIDTemp);
		}

		return authoritySet;
	}

	private class ExcelRoleFinder implements RoleFinder {

		private Map<String, GEditableRole> _map = new HashMap<String, GEditableRole>();

		private ExcelRoleFinder(Sheet roleSheet, int lastRowDataNum) {
			// 明細行チェック
			for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
				int rowNo = DATA_START_LINE + i;
				// 明細行を一行ずつ取得する
				Row row = roleSheet.getRow(rowNo);

				// 行がnullならチェックしない
				if (row == null) {
					continue;
				}

				Cell objectIDCell = row.getCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
				if (objectIDCell == null || objectIDCell.getCellType() != CellType.STRING) {
					continue;
				}
				String objectID = objectIDCell.getStringCellValue();

				Cell authoritySetCell = row.getCell(ROLE_SHEET_AUTHORITYSET_COLUMN_NO);
				String authoritySet = authoritySetCell != null && authoritySetCell.getCellType() == CellType.STRING ? authoritySetCell.getStringCellValue() : null;

				GEditableRole role = getRoleDao().createRole();
				role.setObjectID(objectID != null ? objectID : "");
				role.setAuthoritySet(authoritySet);
				_map.put(objectID, role);
			}
		}

		public GEditableRole findRole(String objectID) {
			return _map.get(objectID);
		}

	}

	private void checkUniqueObjectID(GEditableRoleValidator validator, Sheet roleSheet, int lastRowIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = roleSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			Cell mainCell = mainRow.getCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
			String mainValue = mainCell.getStringCellValue();

			// ユニークチェックを行う。
			for (int subIndex = DATA_START_LINE; subIndex < lastRowIndex; subIndex++) {
				// 明細行を一行ずつ取得する
				Row subRow = roleSheet.getRow(subIndex);
				if (subRow == null) {
					continue;
				}

				//同じ行はチェックしない
				if (mainIndex != subIndex) {

					Cell subCell = subRow.getCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
					String subValue = subCell.getStringCellValue();

					// 同じ値があれば、エラーリストに追加する。
					if (mainValue.equals(subValue)) {
						//エラー行
						int errorNo = mainIndex - DATA_START_LINE + 1;
						validator.addValidateError(UNIQUE_CHECK_ERRORCODE, OBJECTID, errorNo);
						continue;
					}
				}
			}
		}
	}

	private void checkUniqueRoleID(GEditableRoleValidator validator, Sheet roleSheet, int lastRowIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = roleSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			Cell mainCell = mainRow.getCell(ROLE_SHEET_ROLEID_COLUMN_NO);
			String mainValue = mainCell.getStringCellValue();

			// ユニークチェックを行う。
			for (int subIndex = DATA_START_LINE; subIndex < lastRowIndex; subIndex++) {
				// 明細行を一行ずつ取得する
				Row subRow = roleSheet.getRow(subIndex);
				if (subRow == null) {
					continue;
				}

				//同じ行はチェックしない
				if (mainIndex != subIndex) {

					Cell subCell = subRow.getCell(ROLE_SHEET_ROLEID_COLUMN_NO);
					String subValue = subCell.getStringCellValue();

					// 同じ値があれば、エラーリストに追加する。
					if (mainValue.equals(subValue)) {
						//エラー行
						int errorNo = mainIndex - DATA_START_LINE + 1;
						validator.addValidateError(UNIQUE_CHECK_ERRORCODE, ROLEID, errorNo);
						continue;
					}
				}
			}
		}
	}

	private void checkRoleSheetConsistency(GEditableRoleValidator validator, Sheet roleSheet, int lastRowIndex, Sheet localizationSheet, int localizationLastIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = roleSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			// 表示名の取得
			String roleResourceID = mainRow.getCell(ROLE_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO).getStringCellValue();
			// ロケールの取得
			String roleLocale = roleSheet.getRow(ROLE_SHEET_USERINFORMATION_LOCALE_ROW_NO).getCell(ROLE_SHEET_USERINFORMATION_COLUMN_NO).getStringCellValue();

			// ロール名の取得
			Cell roleNameCell = mainRow.getCell(ROLE_SHEET_ROLENAME_COLUMN_NO);
			String roleName = roleNameCell != null ? roleNameCell.getStringCellValue() : "";

			// Excelの行番号変数
			int localizationNo = 0;
			//			// 最終明細行の行番号用変数
			//			int lastLocalizationDataNum = getEndCellRowNumber(localizationSheet);

			boolean existLocalization = false;
			for (int i = 0; i < localizationLastIndex - DATA_START_LINE; i++) {
				localizationNo = DATA_START_LINE + i;
				Row row = localizationSheet.getRow(localizationNo);
				if (row == null) {
					continue;
				}
				// LocalizationシートのKeyとLocaleを取得
				String localizationKey = row.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO).getStringCellValue();
				String localizationLocale = row.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO).getStringCellValue();

				if (localizationKey.equals(roleResourceID) && localizationLocale.equals(roleLocale)) {
					existLocalization = true;
					Cell valueCell = row.getCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);
					String value = valueCell != null ? valueCell.getStringCellValue() : "";
					if (!value.equals(roleName)) {
						validator.addValidateError(CONSISTENCY_CHECK_ERRORCODE, ROLENAME, mainIndex- DATA_START_LINE + 1);
					} else {
						break;
					}
				}
			}
			// Menuシートに紐づく言語情報がLocalizationに存在しない場合
			if (!existLocalization)
			{
				validator.addValidateError(CONSISTENCY_CHECK_ERRORCODE, ROLENAME, mainIndex - DATA_START_LINE + 1);
			}
		}
	}

	/**
	 * Roleのインポート解析処理において、相関チェックを行うメソッドです。<br>
	 * 相関チェックでは、以下の内容をチェックします。<br>
	 * ①ユニーク
	 * ②整合性
	 *
	 * @param roleSheet
	 * @param localizationSheet
	 * @param lastRowDataNum
	 * @param errorList
	 * @param locale
	 * @create 2010/11/10
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	private void checkCorrelationLocalization(GEditableRoleValidator validator, Sheet localizationSheet, int localizationLastIndex, Sheet roleSheet, int roleLastIndex) {

		// リソースIDとロケールの一意チェック
		checkResourceIDAndLocaleUnique(validator, localizationSheet, localizationLastIndex);

		// LocalizationシートからRoleシートへの整合性チェック
		// Keyの値が、RoleシートのDisplayNameResourceIDに無ければ、エラー
		checkLocalizationSheetConsistency(validator, localizationSheet, localizationLastIndex, roleSheet, roleLastIndex);

		//		// Excelの行番号変数
		//		int rowNo = 0;
		//
		//		// 明細行チェック
		//		for (int i = 0; i < lastRowDataNum - DATA_START_LINE; i++) {
		//
		//			rowNo = DATA_START_LINE + i;
		//			// 明細行を一行ずつ取得する
		//			Row row = localizationSheet.getRow(rowNo);
		//
		//			//行がnullならチェックしない。
		//			if (row == null) {
		//				continue;
		//			}
		//
		//			// キーとロケールの一意チェック
		//			checkKeyAndLocaleUnique(localizationSheet, row, errorList, i + 1, locale, lastRowDataNum);
		//
		//			// LocalizationシートからRoleシートへの整合性チェック
		//			//Keyの値が、RoleシートのDisplayNameResourceIDに無ければ、エラー
		//			checkLocalizationSheetConsistency(roleSheet, row, errorList, i + 1, locale);
		//
		//		}
	}

	private void checkResourceIDAndLocaleUnique(GEditableRoleValidator validator, Sheet localizationSheet, int lastRowIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < lastRowIndex; mainIndex++) {
			Row mainRow = localizationSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			// キーの取得
			Cell mainResourceIDCell = mainRow.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
			String mainResourceID = mainResourceIDCell.getStringCellValue();

			// ロケールの取得
			Cell mainLocaleCell = mainRow.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
			String mainLocale = mainLocaleCell.getStringCellValue();

			// ユニークチェックを行う。
			for (int subIndex = DATA_START_LINE + 1; subIndex < lastRowIndex; subIndex++) {
				// 明細行を一行ずつ取得する
				Row subRow = localizationSheet.getRow(subIndex);
				if (subRow == null) {
					continue;
				}

				//同じ行はチェックしない
				if (mainIndex != subIndex) {

					// ローカル変数キー
					Cell subResourceIDCell = subRow.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
					String subResourceID = subResourceIDCell.getStringCellValue();

					// ローカル変数ロケール
					Cell subLocaleCell = subRow.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
					String subLocale = subLocaleCell.getStringCellValue();

					if (mainResourceID.equals(subResourceID) && mainLocale.equals(subLocale)) {
						validator.addValidateError(UNIQUE_CHECK_ERRORCODE, LOCALIZATION_SHEET_RESOURCEID_COLUMN_NAME, mainIndex - DATA_START_LINE + 1);
						break;
					}
				}
			}
		}
	}

	private void checkLocalizationSheetConsistency(GEditableRoleValidator validator, Sheet localizationSheet, int localizationLastIndex, Sheet roleSheet, int roleLastIndex) {
		for (int mainIndex = DATA_START_LINE; mainIndex < localizationLastIndex; mainIndex++) {
			Row mainRow = localizationSheet.getRow(mainIndex);
			if (mainRow == null) {
				continue;
			}

			// リソースIDの取得
			Cell mainResourceIDCell = mainRow.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
			String mainResourceID = mainResourceIDCell.getStringCellValue();

			boolean flag = false;
			for (int i = 0; i < roleLastIndex - DATA_START_LINE; i++) {
				int roleNo = DATA_START_LINE + i;
				// 明細行を一行ずつ取得する
				Row roleRow = roleSheet.getRow(roleNo);

				if (roleRow == null) {
					continue;
				}

				// RoleシートdisplayNameResourceIDを取得
				Cell displayNameResourceIDCell = roleRow.getCell(ROLE_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);
				String displayNameResourceID = displayNameResourceIDCell.getStringCellValue();

				if (displayNameResourceID.equals(mainResourceID)) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				validator.addValidateError(CONSISTENCY_CHECK_ERRORCODE, LOCALIZATION_SHEET_VALUE_COLUMN_NAME, mainIndex- DATA_START_LINE + 1);
			}
		}
	}

	/**
	 * 解析済みのインポートファイルから、Roleを作成し、登録します。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.authorization.GRoleDao#createRoleList(org.apache.poi.ss.usermodel.Sheet,
	 *      org.apache.poi.ss.usermodel.Sheet, int, int, java.util.List,
	 *      java.lang.String)
	 * @param roleSheet
	 * @param localizationSheet
	 * @param roleLastRowDataNum
	 * @param localizationLastRowDataNum
	 * @param roleList
	 * @param companyCode
	 * @return List<GRole>
	 * @create 2010/11/12
	 * @author KCCS fujimura
	 * @throws GValidateException
	 * @throws GOptimisticLockException
	 * @since 3.9.0
	 */
	protected void insertWorkbook(Workbook workbook, GUser user) throws GResourceProcessingException {
		Sheet roleSheet = workbook.getSheet(ROLE_SHEET);
		Sheet localizationSheet = workbook.getSheet(LOCALIZATION_SHEET);

		int roleLastRowDataNum = getEndCellRowNumber(roleSheet);
		int localizationLastRowDataNum = getEndCellRowNumber(localizationSheet);

		for (int i = 0; i < roleLastRowDataNum - DATA_START_LINE; i++) {
			int rowNo = DATA_START_LINE + i;
			Row row = roleSheet.getRow(rowNo);
			if (row == null) {
				continue;
			}

			GEditableRole role = createRole(row, localizationSheet, localizationLastRowDataNum, user);
			try {
				getRoleDao().insertRole(role);
			} catch (GOptimisticLockException e) {
				throw new GResourceProcessingException(e);
			}
		}
	}

	/**
	 * エクセル明細行から得られる情報を元に、ロールを生成します。
	 *
	 * @param row
	 * @param localizationSheet
	 * @param localizationLastRowDataNum
	 * @param roleDao
	 * @param companyCode
	 * @return　ロール
	 * @create 2011/01/20
	 * @author KCCS fujimura
	 * @param roleIDAndObjectIDMap
	 * @since 3.9.0
	 */
	private GEditableRole createRole(Row row, Sheet localizationSheet, int localizationLastRowDataNum, GUser user) throws GResourceProcessingException {
		// オブジェクトIDの取得
		Cell objectIDCell = row.getCell(ROLE_SHEET_OBJECTID_COLUMN_NO);
		String objectID = objectIDCell.getStringCellValue();

		// RoleIDの取得
		Cell roleIDCell = row.getCell(ROLE_SHEET_ROLEID_COLUMN_NO);
		String roleID = roleIDCell.getStringCellValue();

		// 表示名の取得
		Cell displayNameResourceIDCell = row.getCell(ROLE_SHEET_DISPLAYNAMERESOURCEID_COLUMN_NO);
		String displayNameResourceID = displayNameResourceIDCell.getStringCellValue();

		// 権限集合項目を取得します。
		Cell authoritySetCell = row.getCell(ROLE_SHEET_AUTHORITYSET_COLUMN_NO);
		String authoritySet = null;
		if (authoritySetCell != null) {
			authoritySet = authoritySetCell.getStringCellValue();
		}

		// 備考項目を取得します。
		Cell descriptionCell = row.getCell(ROLE_SHEET_DESCRIPTION_COLUMN_NO);
		String description = null;
		if (descriptionCell != null) {
			description = descriptionCell.getStringCellValue();
		}

		//更新者を取得します。
		Cell updatedPersonCell = row.getCell(ROLE_SHEET_UPDATEDPERSON_COLUMN_NO);
		String updatedPerson = null;
		if (updatedPersonCell != null) {
			updatedPerson = GStringUtils.nullToBlank(updatedPersonCell.getStringCellValue());
		}

		//更新日を取得します。
		Cell updatedDateCell = row.getCell(ROLE_SHEET_UPDATEDDATE_COLUMN_NO);
		String updatedDateStr = null;
		if (updatedDateCell != null) {
			updatedDateStr = updatedDateCell.getStringCellValue();
			updatedDateStr = GStringUtils.nullToBlank(updatedDateStr).trim();
		}

		// DisplayNameのMapを作成する。
		Map<Locale, String> displayNameMap = getDisplayNameMap(localizationSheet, localizationLastRowDataNum, displayNameResourceID);

		// ロールの作成
		GEditableRole role = getRoleDao().createRole();
		role.setObjectID(objectID);
		role.setCompanyCode(user.getCompany().getCode());
		role.setRoleID(roleID);
		role.setDisplayNameResourceID(displayNameResourceID);
		role.setDisplayNameMap(displayNameMap);
		role.setAuthoritySet(authoritySet);
		role.setDescription(description);
		if (GStringUtils.isEmpty(updatedPerson)) {
			role.setUpdatedPerson(user.getId());
		} else {
			role.setUpdatedPerson(updatedPerson);
		}

		if (!GStringUtils.isEmpty(updatedDateStr)) {
			try{
				GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
				role.setUpdatedDate(formatter.parse(updatedDateStr, GFrameworkUtils.getDefaultLocale(), DATE_FORMAT));
			}
			catch (ParseException e) {
				throw new GResourceProcessingException(e);
			}
		}
		else{
			Date updatedDate = new Date(System.currentTimeMillis());
			role.setUpdatedDate(updatedDate);
		}

		return role;
	}

	/**
	 * ログインユーザー情報を出力する処理を行います。
	 * @param roleSheet　ロールシート
	 * @param roleLocale ロケール
	 */
	private void writeUserInformation(Sheet roleSheet, GUser user, Locale roleLocale) {
		Row roleSheetRow = null;

		//会社コード
		roleSheetRow = roleSheet.getRow(ROLE_SHEET_USERINFORMATION_COMPANYCD_ROW_NO);
		Cell companyCDCell = roleSheetRow.getCell(ROLE_SHEET_USERINFORMATION_COLUMN_NO);
		companyCDCell.setCellValue(user.getCompany().getCode());
		//ユーザーID
		roleSheetRow = roleSheet.getRow(ROLE_SHEET_USERINFORMATION_USERID_ROW_NO);
		Cell userIDCell = roleSheetRow.getCell(ROLE_SHEET_USERINFORMATION_COLUMN_NO);
		userIDCell.setCellValue(user.getId());
		//ユーザー名
		roleSheetRow = roleSheet.getRow(ROLE_SHEET_USERINFORMATION_USERNAME_ROW_NO);
		Cell userNameCell = roleSheetRow.getCell(ROLE_SHEET_USERINFORMATION_COLUMN_NO);
		userNameCell.setCellValue(user.getName(roleLocale));
		//ロケール情報
		roleSheetRow = roleSheet.getRow(ROLE_SHEET_USERINFORMATION_LOCALE_ROW_NO);
		Cell localeCell = roleSheetRow.getCell(ROLE_SHEET_USERINFORMATION_COLUMN_NO);
		localeCell.setCellValue(roleLocale.toString());
		//出力時刻
		Calendar calendar = new GregorianCalendar();
		roleSheetRow = roleSheet.getRow(ROLE_SHEET_USERINFORMATION_EXPORTTIME_ROW_NO);
		Cell exportDateCell = roleSheetRow.getCell(ROLE_SHEET_USERINFORMATION_COLUMN_NO);
		GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		exportDateCell.setCellValue(formatter.format(calendar.getTime(), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT));
	}

	private void checkSheetExist(Sheet roleSheet, Sheet localizationSheet, GEditableRoleValidator validator) throws GValidateException {
		if (roleSheet == null) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, ROLE_SHEET);
		}
		if (localizationSheet == null) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, LOCALIZATION_SHEET);
		}
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}
	}

	private void checkEndWordExist(int roleLastRowDataNum, int localizationLastRowDataNum, GEditableRoleValidator validator) throws GValidateException {
		if (roleLastRowDataNum == ERROR_NUMBER) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, ROLE_SHEET);
		}

		if (localizationLastRowDataNum == ERROR_NUMBER) {
			validator.addValidateError(SHEET_FORMAT_ERRORCODE, LOCALIZATION_SHEET);
		}
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}
	}

	/**
	 * 「ファイルパス+export.+UUID」形式を引数に指定したFileクラスを返却するメソッド.<br>
	 *
	 * @return File
	 * @throws IOException
	 * @create 2010/10/27
	 * @author fujimura
	 * @since 3.9.0
	 */
	private File createFile() throws IOException {

		UUID uuid = UUID.randomUUID();
		String filePath = GFrameworkUtils.getProperty(EXPORTFILE_TEMPORARY_DIRECTORY);
		File file = new File(filePath);
		file.mkdirs();
		String fileName = filePath + "export." + uuid.toString();

		return new File(fileName);
	}

	/**
		 * RoleシートのDisplayNameResourceIDを元に、Localizationシートにあるロケールとロール名のマップを返します。
		 *
		 * @param localizationSheet
		 * @param localizationLastRowDataNum
		 * @param displayNameResourceID
		 * @return Map<Locale,String> マップ
		 * @create 2010/11/06
		 * @author fujimura
		 * @since 3.9.0
		 */
	private Map<Locale, String> getDisplayNameMap(Sheet localizationSheet, int localizationLastRowDataNum, String displayNameResourceID) {

		Map<Locale, String> displayNameMap = new HashMap<Locale, String>();

		for (int i = 0; i < localizationLastRowDataNum - DATA_START_LINE; i++) {
			int rowNo = DATA_START_LINE + i;
			// Localizationシートの明細行を一行ずつ取得する
			Row row = localizationSheet.getRow(rowNo);

			if (row == null) {
				continue;
			}

			// リソースIDの取得
			Cell resourceIDCell = row.getCell(LOCALIZATION_SHEET_RESOURCEID_COLUMN_NO);
			String resourceID = resourceIDCell.getStringCellValue().trim();

			// リソースIDとdisplayNameResourceIDが一致した分のロール名とロケールをマップに詰める
			if (resourceID.equals(displayNameResourceID)) {
				// ロール名とロケールの取得
				Cell valueCell = row.getCell(LOCALIZATION_SHEET_VALUE_COLUMN_NO);
				String value = null;
				if (valueCell != null) {
					value = valueCell.getStringCellValue().trim();
				}
				Cell localeCell = row.getCell(LOCALIZATION_SHEET_LOCALE_COLUMN_NO);
				String localeStr = localeCell.getStringCellValue().trim();
				Locale locale = GLocaleUtils.getLocale(localeStr);
				displayNameMap.put(locale, value);
			}
		}

		return displayNameMap;

	}
}
