/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.io.File;
import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.data.GPageableList;
import jp.co.kccs.greenearth.framework.data.GValidateException;

/**
 * EnterpriseManagerV3用の操作を表すサービスクラスです.<br>
 * 
 * @create 2011/05/26
 * @author KCCS kitamura
 * @since 3.9.0
 */
public interface GRoleManagementService {
	
	/**
	 * {@link GEditableRole}オブジェクトを生成します.
	 * 
	 * @return {@link GEditableRole}オブジェクト
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	GEditableRole createRole();
	
	/**
	 * 引数の情報から、ページングされた{@link GEditableRole}リストを取得します.
	 * 
	 * @param likeRoleID 曖昧検索用ロールID
	 * @param likeRoleName 曖昧検索用ロール名
	 * @param startIndex ロールリスト開始番号
	 * @param listSize ロールリストのサイズ
	 * @param mode 検索モード
	 * @param user ユーザー情報
	 * @return {@link GEditableRole}型のリスト
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @throws GValidateException 入力値検証エラー
	 * @since 3.9.0
	 */
	GPageableList<GEditableRole> findPageableRoleList(String likeRoleID, String likeRoleName, int startIndex, int listSize, String mode, GUser user) throws GValidateException;
	
	/**
	 * 引数の情報より、{@link GEditableRole}を取得します.
	 * 
	 * @param objectID オブジェクトID
	 * @param user ユーザー
	 * @return ロール
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @throws GValidateException 入力値検証エラー
	 * @since 3.9.0
	 */
	GEditableRole findRole(String objectID, GUser user) throws GValidateException;

	/**
	 * ロールを登録します.
	 * 
	 * @param role ロール
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void insertRole(GEditableRole role, GUser user) throws GValidateException;

	/**
	 * ロールを更新します.
	 * 
	 * @param role ロール
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void updateRole(GEditableRole role, GUser user) throws GValidateException;

	/**
	 * ロールを削除します.
	 * 
	 * @param roleList ロールのリスト
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	void deleteRoleList(List<GEditableRole> roleList, GUser user) throws GValidateException;
	
	/**
	 * データ移行用ファイルを出力します.
	 * 
	 * @param likeRoleID 曖昧検索用ロールID
	 * @param likeRoleName 曖昧検索用ロール名
	 * @param user ユーザー
	 * @return データ移行用ファイル
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @throws GValidateException 入力値検証エラー
	 * @since 3.9.0
	 */
	File exportTransitionalData(String likeRoleID, String likeRoleName, GUser user) throws GValidateException;
	
	/**
	 * データ移行用ファイルを取り込みます.(追加)
	 * 
	 * @param file データ移行用ファイル
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void importTransitionalDataAddition(File file, GUser user) throws GValidateException;
	
	/**
	 * データ移行用ファイルを取り込みます.(差分更新)
	 * 
	 * @param file データ移行用ファイル
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void importTransitionalDataDiffUpdate(File file, GUser user) throws GValidateException;
	
	/**
	 * 一括編集用ファイルを出力します.
	 * 
	 * @param user ユーザー
	 * @return 一括編集用ファイル
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	File exportBatchEditData(GUser user);
	
	/**
	 * 一括編集用ファイルを取り込みます.
	 * 
	 * @param file 一括編集用ファイル
	 * @param user ユーザー
	 * @throws GValidateException 入力値検証エラー
	 * @create 2011/05/26
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	void importBatchEditData(File file, GUser user) throws GValidateException;

	/**
	 * {@link GRoleManagementService}インターフェースの実装クラスを取得するファクトリクラスです.
	 * 
	 * @create 2011/05/26
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public static class Factory {

		/**
		 * デフォルトコンストラクタ.<br>
		 * 
		 * @create 2011/09/08
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public Factory() {
		}
		/**
		 * {@link GRoleManagementService}インターフェースの実装クラスを取得します.
		 * 
		 * @return 実装クラス
		 * @create 2011/05/26
		 * @author KCCS kitamura
		 * @since 3.9.0
		 */
		public static GRoleManagementService getInstance() {
			return (GRoleManagementService) GFrameworkUtils.getComponent(GRoleManagementService.class.getName());
		}
		
	}

	

}
