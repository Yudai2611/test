/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.exception.GAlreadyDeletedException;
import jp.co.kccs.greenearth.commons.exception.GAlreadyInsertedException;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.authorization.GEditableRoleDao;
import jp.co.kccs.greenearth.framework.data.*;
import jp.co.kccs.greenearth.framework.em.rolemanager.GEditableRoleValidator.RoleFinder;

public class GRoleManagementServiceImpl implements GRoleManagementService {

	/** RoleID項目 */
	protected static final String ROLEID = "RoleID";
	/** RoleName項目 */
	protected static final String ROLENAME = "RoleName";
	/** ObjectID項目 */
	protected static final String OBJECTID = "ObjectID";

	protected static final String UNIQUE_CHECK_ERRORCODE = "GEM-000011";
	protected static final String DELETED_CHECK_ERRORCODE = "GEM-000018";
	protected static final String EXCLUSIVE_CHECK_ERRORCODE = "GEM-000019";
	protected static final String FILESIZE_CHECK_ERRORCODE = "GEM-000023";

	private GRoleTransporter _transporter = null;
	private GRoleBatchEditor _batchEditor = null;

	/** 処理タイプ */
	private enum Type {
		INSERT, UPDATE, DELETE
	}

	public GRoleManagementServiceImpl(GRoleTransporter transporter, GRoleBatchEditor batchEditor) {
		_transporter = transporter;
		_batchEditor = batchEditor;
	}

	public GEditableRoleDao getRoleDao() {
		return GEditableRoleDao.Factory.getInstance();
	}

	public GRoleTransporter getRoleTransporter() {
		return _transporter;
	}

	public GRoleBatchEditor getRoleBatchEditor() {
		return _batchEditor;
	}

	public GEditableRole createRole() {
		return getRoleDao().createRole();
	}

	/**
	 * ロールを検索します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleManagementService#findRole(java.lang.String, jp.co.kccs.greenearth.framework.auth.GUser)
	 * @param objectID
	 * @param user
	 * @return
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since v3.9.0
	 */
	public GEditableRole findRole(String objectID, GUser user) throws GValidateException {
		
		//通信が発生すれば、パラメータに対して検証をする、NGの場合クライアント側へエラーを返す
		//オブジェクトIDの桁数をチェックする
		GEditableRoleValidator validator = new GEditableRoleValidator();
		validator.validateObjectID(objectID);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

		try {
			GEditableRole role = (GEditableRole) getRoleDao().findRole(objectID);
			return role;
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * ロールの{@link GPageableList}を検索します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleManagementService#findPageableRoleList(java.lang.String, java.lang.String, int, int, java.lang.String, jp.co.kccs.greenearth.framework.auth.GUser)
	 * @param likeRoleID
	 * @param likeRoleName
	 * @param startIndex
	 * @param listSize
	 * @param mode
	 * @param user
	 * @return GPageableList
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since v3.9.0
	 */
	public GPageableList<GEditableRole> findPageableRoleList(String likeRoleID, String likeRoleName, int startIndex, int listSize, String mode, GUser user) throws GValidateException {
		
		//通信が発生すれば、パラメータに対して検証をする、NGの場合クライアントでシステムエラーで表示する
		//ロールIDの桁数とロールネームの桁数をチェックする	
		GEditableRoleValidator validator = new GEditableRoleValidator();
		validator.validateRoleIDMaxLength(likeRoleID, -1);
		validator.validateDisplayName(likeRoleName);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

		String companyCode = user.getCompany().getCode();
		int count = countRoleList(companyCode, likeRoleID, likeRoleName);

		GSearchMode searchMode = GSearchMode.create(mode);
		startIndex = GPagingNavigator.calculateStartIndex(startIndex, listSize, count, searchMode) + 1;
		List<GEditableRole> list = null;
		if (count == 0) {
			list = new ArrayList<GEditableRole>();
		} else {
			list = findRoleList(companyCode, likeRoleID, likeRoleName, startIndex, listSize);
		}

		GPageableList<GEditableRole> listData = new GArrayPageableList<GEditableRole>();
		listData.addAll(list);
		listData.setStartIndex(startIndex - 1);
		listData.setTotalSize(count);
		listData.setMaxListSize(listSize);
		return listData;
	}

	/**
	 * ロールリストを検索します.<br>
	 * 
	 * @param companyCode
	 * @param likeRoleID
	 * @param likeRoleName
	 * @param startIndex
	 * @param listSize
	 * @return List
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since v3.9.0
	 */
	protected List<GEditableRole> findRoleList(String companyCode, String likeRoleID, String likeRoleName, int startIndex, int listSize) throws GValidateException {
		try {
			return getRoleDao().findRoleList(companyCode, likeRoleID, likeRoleName, startIndex, listSize);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * ロールの数をカウントします.<br>
	 * 
	 * @param companyCode
	 * @param likeRoleID
	 * @param likeRoleName
	 * @return int
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	protected int countRoleList(String companyCode, String likeRoleID, String likeRoleName) {
		try {
			return getRoleDao().countRole(companyCode, likeRoleID, likeRoleName);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * 対象のロールを検証します.<br>
	 * 
	 * @param role
	 * @param index
	 * @param type
	 * @return List
	 * @create 2011/05/31
	 * @author KCCS XXXXX
	 * @since v3.9.0
	 */
	protected List<GValidateError> validateRole(GEditableRole role, int index, Type type) {

		// 値の検証
		RoleFinder finder = new RoleFinder() {

			public GEditableRole findRole(String objectID) {
				try {
					return (GEditableRole) getRoleDao().findRole(objectID);
				} catch (GResourceProcessingException e) {
					throw new GResourceAccessException(e);
				}
			}
		};

		List<GValidateError> errorList = new ArrayList<GValidateError>();
		GEditableRoleValidator validator = new GEditableRoleValidator(finder);
		if (type == Type.INSERT) {
			validator.validateRoleSingleItem(role, index);
			if (validator.getErrorList().size() <= 0) { 
				// 重複チェックはDBに任せる。
				validator.validateAuthoritySetCircularReference(role.getAuthoritySet(), role.getObjectID(), index);
			}
			errorList = validator.getErrorList();
		} else if (type == Type.UPDATE) {
			validator.validateRoleSingleItem(role, index);
			if (validator.getErrorList().size() <= 0) { 
				validator.validateAuthoritySetCircularReference(role.getAuthoritySet(), role.getObjectID(), index);
			}
			errorList = validator.getErrorList();
		} else if (type == Type.DELETE) {
			validator.validateObjectID(role.getObjectID(), index);
		}
		return errorList;
	}

	/**
	 * ロールを登録します.<br>
	 * 引数のnullチェックは行いません.<br><br>
	 * 
	 * @param role
	 * @throws GResourceProcessingException
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since 2010/09/29
	 */
	public void insertRole(GEditableRole role, GUser user) throws GValidateException {

		// 一部項目を自動採番
		role.setObjectID(UUID.randomUUID().toString());
		role.setDisplayNameResourceID(UUID.randomUUID().toString());
		String companyCode = user.getCompany().getCode();
		role.setCompanyCode(companyCode);
		role.setUpdatedPerson(user.getId());

		List<GValidateError> errorList = validateRole(role, -1, Type.INSERT);
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}

		try {
			getRoleDao().insertRole(role);
		} catch (GOptimisticLockException e) {
			GValidateError error = createValidateError(UNIQUE_CHECK_ERRORCODE, ROLEID);
			throw new GValidateException(error);

		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * {@link GValidateError}を作成します.<br>
	 * 
	 * @create 2011/05/10
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	protected GValidateError createValidateError(String errorCode, String id) {
		GEditableRoleValidator roleValidator = new GEditableRoleValidator();
		return roleValidator.createValidateError(errorCode, id);
	}

	/**
	 * ロールを更新します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleManagementService#updateRole(jp.co.kccs.greenearth.framework.em.rolemanager.GEditableRole, jp.co.kccs.greenearth.framework.auth.GUser)
	 * @param role
	 * @param user
	 * @throws GValidateException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	public void updateRole(GEditableRole role, GUser user) throws GValidateException {

		String companyCode = user.getCompany().getCode();
		role.setCompanyCode(companyCode);
		role.setUpdatedPerson(user.getId());

		List<GValidateError> errorList = validateRole(role, -1, Type.UPDATE);
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}

		try {
			getRoleDao().updateRole(role);
		} catch (GOptimisticLockException e) {
			GValidateError error = null;
			if (e instanceof GAlreadyInsertedException) {
				error = createValidateError(UNIQUE_CHECK_ERRORCODE, ROLEID);
				throw new GValidateException(error);
			} else if (e instanceof GAlreadyDeletedException) {
				error = createValidateError(DELETED_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			} else {
				error = createValidateError(EXCLUSIVE_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			}
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * ロールのリストを削除します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleManagementService#deleteRoleList(java.util.List, jp.co.kccs.greenearth.framework.auth.GUser)
	 * @param roleList
	 * @param user
	 * @throws GValidateException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	public void deleteRoleList(List<GEditableRole> roleList, GUser user) throws GValidateException {
		//通信が発生すれば、パラメータに対して検証をする、NGの場合クライアントでシステムエラーで表示する
		//オブジェクトIDの桁数をチェックする
		List<GValidateError> errorList = new ArrayList<GValidateError>();
		for (GEditableRole role : roleList) {
			List<GValidateError> errorListTemp = validateRole(role, -1, Type.DELETE);
			errorList.addAll(errorListTemp);
		}
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}

		try {
			getRoleDao().deleteRoleList(roleList);
		} catch (GOptimisticLockException e) {
			if (e instanceof GAlreadyDeletedException) {
				GValidateError error = createValidateError(DELETED_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			} else {
				GValidateError error = createValidateError(EXCLUSIVE_CHECK_ERRORCODE, null);
				throw new GValidateException(error);
			}
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public File exportTransitionalData(String likeRoleID, String likeRoleName, GUser user) throws GValidateException {
		
		//通信が発生すれば、パラメータに対して検証をする、NGの場合クライアントでシステムエラーで表示する
		//ロールIDの桁数とロールネームの桁数をチェックする
		GEditableRoleValidator validator = new GEditableRoleValidator();
		validator.validateRoleIDMaxLength(likeRoleID, -1);
		validator.validateDisplayName(likeRoleName);
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			String companyCode = user.getCompany().getCode();
			File file = getRoleTransporter().exportFile(companyCode, likeRoleID, likeRoleName, locale);
			validateFile(file);
			return file;
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public void importTransitionalDataAddition(File file, GUser user) throws GValidateException {

		validateFile(file);

		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			getRoleTransporter().importFileAddition(user, file, locale);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public void importTransitionalDataDiffUpdate(File file, GUser user) throws GValidateException {

		validateFile(file);

		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			getRoleTransporter().importFileDiffUpdate(user, file, locale);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public File exportBatchEditData(GUser user) {
		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			return getRoleBatchEditor().exportFile(user, locale);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	public void importBatchEditData(File file, GUser user) throws GValidateException {

		validateFile(file);

		try {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			getRoleBatchEditor().importFile(file, user, locale);
		} catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}

	/**
	 * ファイルのサイズを検証します.<br>
	 * 
	 * @param file
	 * @create 2011/06/06
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since v3.9.0
	 */
	protected void validateFile(File file) throws GValidateException {
		
		if(file==null){
			GValidateError error = createValidateError(FILESIZE_CHECK_ERRORCODE, null);
			throw new GValidateException(error);
		}
		
		//ファイルサイズがゼロの場合
		if (file.length() < 0) {
			GValidateError error = createValidateError(FILESIZE_CHECK_ERRORCODE, null);
			throw new GValidateException(error);
		}
	}
}
