/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GUploadFile;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;
import jp.co.kccs.greenearth.framework.data.GPageableList;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.db.GTransactionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.xrmi.authorization.GRoleAction;

/**
 * EnterpriseManagerV3におけるRoleManagerのアクションクラスとなります。
 * 
 * @create 2011/05/21
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GRoleManagerAction extends GRoleAction {

	// パラメーターキー
	protected static final String PARAM_SEARCH_ROLE_ID = "RoleID";
	protected static final String PARAM_SEARCH_ROLE_NAME = "RoleName";
	protected static final String PARAM_SEARCH_OBJECT_ID = "ObjectID";

	protected static final String OBJECTID = "ObjectID";
	protected static final String ROLE_ID = "RoleID";
	protected static final String AUTHORITY_SET = "AuthoritySet";
	protected static final String DESCRIPTION = "Description";
	protected static final String EXCLUSIVE_FG = "ExclusiveFG";
	protected static final String DISPLAY_NAME_RESOURCE_ID = "DisplayNameResourceID";
	protected static final String DISPLAY_NAME = "Value";

	// 結果データキー
	protected static final String RESULT_ROLE_LIST = "RoleList";

	/** インポートファイル一時保管ディレクトリパスのプロパティキー */
	protected final String EXPORTFILE_TEMPORARY_DIRECTORY = "geframe.em.File.TempDirectory";

	/**
	 * ロールリストを検索します.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return GResultData
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since v3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findRoleList(GParameter parameter, GResultData resultData) throws GValidateException {
		String roleID = GStringUtils.blankToNull(parameter.getValue("RoleID"));
		String roleName = GStringUtils.blankToNull(parameter.getValue("RoleName"));
		int startIndex = parameter.getInteger("StartIndex");
		int listSize = parameter.getInteger("ListSize");
		String mode = parameter.getValue(GActionServlet.ACTION_MODE_KEY);

		GRoleManagementService servie = GRoleManagementService.Factory.getInstance();
		GPageableList<GEditableRole> listData = servie.findPageableRoleList(roleID, roleName, startIndex, listSize, mode, GEXActionUtils.getLoginUser());
		resultData.setData(RESULT_ROLE_LIST, listData);
		return resultData;
	}

	/**
	 * ロールを検索します.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return GResultData
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since v3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findRoleByOID(GParameter parameter, GResultData resultData) throws GValidateException {
		String objectID = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_OBJECT_ID));
		GRoleManagementService servie = GRoleManagementService.Factory.getInstance();
		GEditableRole role = servie.findRole(objectID, GEXActionUtils.getLoginUser());
		resultData.setData(RESULT_ROLE, role);
		return resultData;
	}

	/**
	 * ロールを作成します.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return resultData
	 * @throws GValidateException
	 * @throws GOptimisticLockException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData insertRole(GParameter parameter, GResultData resultData) throws GValidateException, GOptimisticLockException {
		GEditableRole role = assembleRole(parameter, 0);
//		GEditableRole role = assembleRole(parameter);
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		service.insertRole(role, GEXActionUtils.getLoginUser());
		return resultData;
	}

	/**
	 * ロールを更新します.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return resultData
	 * @throws GValidateException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData updateRole(GParameter parameter, GResultData resultData) throws GValidateException {
		GEditableRole role = assembleRole(parameter, 0);
//		GEditableRole role = assembleRole(parameter);
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		service.updateRole(role, GEXActionUtils.getLoginUser());
		return resultData;
	}

	/**
	 * ロールのリストを削除します.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return resultData
	 * @throws GValidateException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData deleteRoleList(GParameter parameter, GResultData resultData) throws GValidateException {
		List<GEditableRole> roleList = assembleDeleteRoleList(parameter);
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		service.deleteRoleList(roleList, GEXActionUtils.getLoginUser());
		return resultData;
	}

	/**
	 * ロールを
	 * 
	 * @param parameter
	 * @param resultData
	 * @return
	 * @create 2011/05/31
	 * @author KCCS XXXXX
	 * @throws GValidateException 
	 * @since
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData exportTransitionalData(GParameter parameter, GResultData resultData) throws GValidateException {
		String roleID = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_ROLE_ID));
		String roleName = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_ROLE_NAME));
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		File file = service.exportTransitionalData(roleID, roleName, GEXActionUtils.getLoginUser());
		if (file != null) {
			GDownloadFile downloadFile = new GDownloadFile(file);
			downloadFile.setDeleteFlag(true);
			downloadFile.setContentType("application/x-binary");
			resultData.setDownloadFile(downloadFile);
			resultData.setExitCode(GResultData.EXIT_CODE_FILE_DOWNLOAD);
		}
		return resultData;
	}

	/**
	 * xmlをインポートします.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return GResultData
	 * @throws GValidateException
	 * @throws IOException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData importTransitionalDataAddition(GParameter parameter, GResultData resultData) throws GValidateException, IOException {
		// アップロードファイルの情報を取得
		GUploadFile uploadFile = parameter.getFile("ImportFile");
		File file = createFile();
		uploadFile.write(file);
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		service.importTransitionalDataAddition(file, GEXActionUtils.getLoginUser());
		return resultData;
	}

	/**
	 * xmlインポート、重複後の更新処理
	 * @param parameter
	 * @param resultData
	 * @return
	 * @throws GValidateException
	 * @throws IOException
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData importTransitionalDataDiffUpdate(GParameter parameter, GResultData resultData) throws GValidateException, IOException {
		// アップロードファイルの情報を取得
		GUploadFile uploadFile = parameter.getFile("ImportFile");
		File file = createFile();
		uploadFile.write(file);
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		service.importTransitionalDataDiffUpdate(file, GEXActionUtils.getLoginUser());
		return resultData;
	}

	/**
	 * エクセルをエクスポートします.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return GResultData
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @throws GValidateException 
	 * @since v3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData exportBatchEditData(GParameter parameter, GResultData resultData){
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		File file = service.exportBatchEditData(GEXActionUtils.getLoginUser());
		GDownloadFile downloadFile = new GDownloadFile(file);
		downloadFile.setDeleteFlag(true);
		downloadFile.setContentType("application/x-binary");
		resultData.setDownloadFile(downloadFile);
		resultData.setExitCode(GResultData.EXIT_CODE_FILE_DOWNLOAD);
		return resultData;
	}

	/**
	 * エクセルをインポートします.<br>
	 * 
	 * @param parameter
	 * @param resultData
	 * @return GResultData
	 * @throws GValidateException
	 * @throws IOException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData importBatchEditData(GParameter parameter, GResultData resultData) throws GValidateException, IOException {
		GUploadFile uploadFile = parameter.getFile("ImportFile");
		File file = createFile();
		uploadFile.write(file);
		GRoleManagementService service = GRoleManagementService.Factory.getInstance();
		service.importBatchEditData(file, GEXActionUtils.getLoginUser());
		return resultData;
	}

	/**
	 * {@link GEditableRole}を組立てます.<br>
	 * 
	 * @param parameter
	 * @param index
	 * @return GEditableRole
	 * @throws GValidateException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	private GEditableRole assembleRole(GParameter parameter, int index) throws GValidateException {

		// 値の抽出
		String companyCode = GEXActionUtils.getLoginCompany().getCode();
		String roleID = parameter.getValue(ROLE_ID, index);
		String authoritySet = parameter.getValue(AUTHORITY_SET, index);

		String objectID = parameter.getValue(OBJECTID, index);
		String description = parameter.getValue(DESCRIPTION, index);
		String displayNameResourceID = parameter.getValue(DISPLAY_NAME_RESOURCE_ID, index);
		String exclusiveKey = parameter.getValue(EXCLUSIVE_FG, index);

		List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
		Map<Locale, String> displayNameMap = new HashMap<Locale, String>();

		for (Locale locale : localeList) {
			String key = parameter.getValue(DISPLAY_NAME + "@" + locale.toString() + String.valueOf(index));
			displayNameMap.put(locale, key);
		}

		return assembleRole(companyCode, roleID, authoritySet, objectID, description, displayNameResourceID, exclusiveKey, displayNameMap);
	}

	/**
	 * {@link GEditableRole}を組立てます.<br>
	 * 
	 * @param companyCode
	 * @param roleID
	 * @param authoritySet
	 * @param objectID
	 * @param description
	 * @param displayNameResourceID
	 * @param exclusiveKey
	 * @param displayNameMap
	 * @return GEditableRole
	 * @throws GValidateException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	private GEditableRole assembleRole(String companyCode, String roleID, String authoritySet, String objectID, String description, String displayNameResourceID, String exclusiveKey, Map<Locale, String> displayNameMap) throws GValidateException {

		// ロールの組み立て
		GEditableRole role = GRoleManagementService.Factory.getInstance().createRole();
		role.setCompanyCode(companyCode);
		role.setRoleID(roleID);
		role.setAuthoritySet(authoritySet);
		role.setObjectID(objectID);
		role.setDescription(description);
		role.setDisplayNameResourceID(displayNameResourceID);
		role.setExclusiveKey(exclusiveKey);
		role.setDisplayNameMap(new HashMap<Locale, String>());
		for (Entry<Locale, String> entry : displayNameMap.entrySet()) {
			Locale key = entry.getKey();
			String value = entry.getValue();
			role.getDisplayNameMap().put(key, value);
		}

		role.setUpdatedDate(new Date(System.currentTimeMillis()));

		return role;
	}

	/**
	 * リストの{@link GEditableRole}を組立てます.<br>
	 * 
	 * @param parameter
	 * @return List
	 * @throws GValidateException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	private List<GEditableRole> assembleDeleteRoleList(GParameter parameter) throws GValidateException {
		List<GEditableRole> rolelist = new ArrayList<GEditableRole>();
		int length = parameter.getInteger("ROLE_LIST_COUNT");
		for (int i = 0; i < length; i++) {
			GEditableRole role = assembleRole(parameter, i);
			rolelist.add(role);
		}
		return rolelist;
	}

	/**
	 * {@link File}を作成します.<br>
	 * 
	 * @return File
	 * @throws IOException
	 * @create 2011/05/31
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	protected File createFile() throws IOException {
		UUID uuid = UUID.randomUUID();
		String filePath = GFrameworkUtils.getProperty(EXPORTFILE_TEMPORARY_DIRECTORY);
		File file = new File(filePath);
		file.mkdirs();
		return new File(filePath + "temp." + uuid.toString());
	}

}
