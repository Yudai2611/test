/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.io.File;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateException;


public interface GRoleTransporter {
	
	File exportFile(String companyCode, String likeRoleID, String likeRoleName, Locale locale) throws GResourceProcessingException;
	
	void importFileAddition(GUser user, File file, Locale locale) throws GResourceProcessingException, GValidateException;
	
	void importFileDiffUpdate(GUser user,  File file, Locale locale) throws GResourceProcessingException, GValidateException;
	
//	public static class Factory {
//
//		public static GRoleTransporter getInstance() {
//			return (GRoleTransporter) GFrameworkUtils.getComponent(GRoleTransporter.class.getName());
//		}
//		
//	}

}
