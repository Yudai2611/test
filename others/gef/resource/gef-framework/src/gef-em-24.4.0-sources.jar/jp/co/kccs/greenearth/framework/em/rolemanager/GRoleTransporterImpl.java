/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.rolemanager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GExternalDataSet;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.authorization.GEditableRoleDao;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.em.rolemanager.GEditableRoleValidator.RoleFinder;

/**
 * 
 * @create 2011/05/12
 * @author KCCS nishimura
 * @since 3.9.0
 */
public class GRoleTransporterImpl implements GRoleTransporter {

	private static final String ELEMENT_ROLELIST = "RoleList";
	private static final String ELEMENT_ROLE = "Role";
	private static final String ELEMENT_OBJECT_ID = "ObjectID";
	private static final String ELEMENT_ROLE_ID = "RoleID";
	private static final String ELEMENT_DISPLAY_NAME_RESOURCE_ID = "DisplayNameResourceID";
	private static final String ELEMENT_AUTHORITY_SET = "AuthoritySet";
	private static final String ELEMENT_DESCRIPTION = "Description";
	private static final String ELEMENT_UPDATED_DT = "UpdatedDate";
	private static final String ELEMENT_UPDATED_PERSON = "UpdatedPerson";

	private static final String ELEMENT_DISPLAY_NAME = "DisplayName";
	private static final String ELEMENT_RESOURCE = "Resource";
	private static final String ATTRIBUTE_LOCALE = "locale";

	/** DATE_FORMAT */
	private static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss"; // TODO フォーマットを外だしにする
	private static final String FILE_ENCODING = "geframe.em.ExportFile.Encoding";
	/** エクスポートファイル一時保管ディレクトリパスのプロパティキー */
	private static final String EXPORTFILE_TEMPORARY_DIRECTORY = "geframe.em.File.TempDirectory";

	// エラーコード
	/** データが重複しています */
	private static final String UNIQUE_CHECK_ERRORCODE = "GEM-000011";
	
	private int _bufferSize = 512;

	/**
	 * コンストラクタ
	 * 
	 * @create 2010/11/24
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GRoleTransporterImpl() {
	}

	/**
	 * コンストラクタ
	 * 
	 * @param bufferSize バッファリングサイズ
	 * @create 2011/05/12
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GRoleTransporterImpl(int bufferSize) {
		_bufferSize = bufferSize;
	}

	/**
	 * GEditableRoleDao の取得
	 * 
	 * @return GEditableRoleDaoインスタンス
	 * @create 2011/05/12
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GEditableRoleDao getRoleDao() {
		return GEditableRoleDao.Factory.getInstance();
	}

	/**
	 * ロール情報のエクスポートを行います。
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleBatchEditor#exportData(java.lang.String,
	 *      java.lang.String, java.lang.String, java.util.Locale)
	 * @param companyCode
	 * @param likeRoleID
	 * @param likeRoleName
	 * @param locale
	 * @return
	 * @throws GResourceProcessingException
	 * @create 2010/11/24
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public File exportFile(String companyCode, String likeRoleID, String likeRoleName, Locale locale)
		throws GResourceProcessingException {
		GExternalDataSet<GEditableRole> roleset = null;
		try {
			//roleset = getRoleDao().findRoleSet(companyCode, likeRoleID, likeRoleName, locale);
			roleset = getRoleDao().findRoleSet(companyCode, likeRoleID, likeRoleName);
			boolean hasSet = false;

			BufferedOutputStream buffOutputStream = null;
			XMLStreamWriter xmlw = null;
			try {
				String encoding = GFrameworkUtils.getProperty(FILE_ENCODING);

				// ファイルを作成
				File exportFile = createFile();
				buffOutputStream = new BufferedOutputStream(new FileOutputStream(exportFile), _bufferSize);
				XMLOutputFactory xmlof = XMLOutputFactory.newInstance();
				xmlw = xmlof.createXMLStreamWriter(buffOutputStream,encoding);

				// 出力ファクトリを取得
				// XML宣言
				xmlw.writeStartDocument(encoding, "1.0");

				// RoleList：Start
				xmlw.writeStartElement(ELEMENT_ROLELIST);

				while (roleset.next()) {
					hasSet = true;
					// role作成
					createRoleElement(roleset.get(), xmlw);
				}
				
				if (!hasSet) {
					return null;
				}
				
				// RoleList：End
				xmlw.writeEndElement();

				// XML ドキュメントを終了する
				xmlw.writeEndDocument();

				return exportFile;
			} catch (IOException e) {
				throw new GResourceProcessingException(e);
			} catch (XMLStreamException e) {
				throw new GResourceProcessingException(e);
			} finally {
				// XMLStreamWriter をクローズしてリソースを解放する
				try {
					if (xmlw != null) {
						xmlw.close();
					}
					if (buffOutputStream != null) {
						buffOutputStream.close();
					}
				} catch (IOException e) {
					throw new GResourceProcessingException(e);
				} catch (XMLStreamException e) {
					throw new GResourceProcessingException(e);
				}
			}
		} finally {
			if (roleset != null) {
				roleset.close();
			}
		}
	}

	/**
	 * {@link GEditableRole}からエクスポート（xml）用のRoleエレメントを作成します
	 * 
	 * @param role エクスポート対象ロール
	 * @param xmlw XML書き込み用ストリーム
	 * @throws XMLStreamException XMLへの書き込みが失敗した場合
	 * @create 2011/05/12
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void createRoleElement(GEditableRole role, XMLStreamWriter xmlw) throws XMLStreamException {
		// Role：Start
		xmlw.writeStartElement(ELEMENT_ROLE);
		createElement(ELEMENT_OBJECT_ID, role.getObjectID(), xmlw);
		createElement(ELEMENT_ROLE_ID, role.getRoleID(), xmlw);
		// 表示名
		createResourceElement(role.getDisplayNameMap(), role.getDisplayNameResourceID(), xmlw);
		createElement(ELEMENT_AUTHORITY_SET, role.getAuthoritySet(), xmlw);
		createElement(ELEMENT_DESCRIPTION, role.getDescription(), xmlw);
		GDateFormatter formatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		String updatedDate = formatter.format(role.getUpdatedDate(), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT);
		createElement(ELEMENT_UPDATED_DT, updatedDate, xmlw);
		createElement(ELEMENT_UPDATED_PERSON, role.getUpdatedPerson(), xmlw);
		//		createElement(ELEMENT_EXCLUSIVE_FG, role.getExclusiveKey(), xmlw);

		// Role：End
		xmlw.writeEndElement();

	}

	/**
	 * XMLのタグを作成する
	 * 
	 * @param elementName
	 * @param character
	 * @param xmlw
	 * @throws XMLStreamException
	 * @create 2010/11/01
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void createElement(String elementName, String character, XMLStreamWriter xmlw) throws XMLStreamException {
		if (character == null) {
			return;
		}
		xmlw.writeStartElement(elementName);
		xmlw.writeCharacters(character);
		xmlw.writeEndElement();
	}

	/**
	 * DisplayNameタグを作成する
	 * 
	 * @param map
	 * @param xmlw
	 * @throws XMLStreamException
	 * @create 2010/10/21
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void createResourceElement(Map<Locale, String> map, String resourceID, XMLStreamWriter xmlw) throws XMLStreamException {

		xmlw.writeStartElement(ELEMENT_DISPLAY_NAME);
		xmlw.writeAttribute(ELEMENT_DISPLAY_NAME_RESOURCE_ID, resourceID);
		for (Map.Entry<Locale, String> e : map.entrySet()) {
			if (e.getKey() == null) {
				continue;
			}
			xmlw.writeStartElement(ELEMENT_RESOURCE);
			xmlw.writeAttribute(ATTRIBUTE_LOCALE, e.getKey().toString());
			if (e.getValue() != null) {
				xmlw.writeCharacters(e.getValue());
			}
			xmlw.writeEndElement();
		}
		xmlw.writeEndElement();
	}

	/**
	 * ロール情報のインポートを行います。
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleTransporter#importFile(java.lang.String, java.lang.String, java.io.File, java.util.Locale)
	 * @param user ユーザー
	 * @param file インポートファイル(xml)
	 * @param locale 地域コード
	 * @throws GResourceProcessingException 入力チェック、又は登録処理に失敗した場合
	 * @throws GValidateException 入力エラー
	 * @create 2011/05/12
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void importFileAddition(GUser user, File file, Locale locale) throws GResourceProcessingException, GValidateException {
		
		// インポートファイルに対応するリスト
		// データ層 ,インポートファイルの両方から重複チェックを行う為にファイルの内容をリストにロード
		List<GEditableRole>roleList = new ArrayList<GEditableRole>();
		
		// インポートファイルに対応するマップ/
		Map<String , GEditableRole> roleMap = new HashMap<String, GEditableRole>();
		
		//xmlロード ＆　単項目チェック
		validateSingleItem(user.getCompany().getCode(), file, locale, roleList, roleMap);

		//ユニークチェック
		validateUnique(user.getCompany().getCode(), locale, true , roleList);
		
		//循環参照チェック
		validateCircularReference(user.getCompany().getCode() , locale , roleMap);
		
		// 登録処理
		addition(user.getCompany().getCode(), file , locale);
	}

	/**
	 * ロール情報のインポートを行います
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.rolemanager.GRoleTransporter#importFile(java.lang.String, java.lang.String, java.io.File, java.util.Locale)
	 * @param companyCode 会社コード
	 * @param userID ユーザーID
	 * @param file インポートファイル(xml)
	 * @param locale 地域コード
	 * @throws GResourceProcessingException 入力チェック、又は登録＆更新処理に失敗した場合
	 * @throws GValidateException 入力エラー
	 * @create 2011/05/12
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void importFileDiffUpdate(GUser user, File file, Locale locale) throws GResourceProcessingException, GValidateException {
		
		// インポートファイルに対応するリスト
		List<GEditableRole>roleList = new ArrayList<GEditableRole>();
		// インポートファイルに対応するマップ/
		Map<String , GEditableRole> roleMap = new HashMap<String, GEditableRole>();
		
		//xmlロード ＆　単項目チェック
		validateSingleItem(user.getCompany().getCode(), file, locale, roleList, roleMap);
		
		//ユニークチェック
		//単項目エラーがあると、関連チェックができないため段階を分けている。
		validateUnique(user.getCompany().getCode(), locale, false, roleList);
		
		//循環参照チェック
		//重複エラーがあると、循環参照のチェックができないため段階を分けている。
		validateCircularReference(user.getCompany().getCode(), locale , roleMap);
		
		// 登録＆更新処理
		diffUpdate(user.getCompany().getCode(), file , locale);
	}
	
	/**
	 * XMLファイルを読み込み、ロールのリスト、マップを作成する
	 * XMLファイルの項目が正しくない場合、GValidateExceptionをthrowする
	 * 
	 * @param companyCode 会社コード
	 * @param file インポートファイル(xml)
	 * @param locale 地域コード
	 * @param roleList インポートファイルに対応するロールリスト
	 * @param roleMap インポートファイルに対応するロールマップ
	 * @throws GResourceProcessingException ファイルアクセスに失敗した場合
	 * @throws GValidateException 単項目エラーが発生した場合
	 * @create 2011/05/19
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void validateSingleItem(String companyCode, File file, Locale locale, List<GEditableRole> roleList, Map<String, GEditableRole> roleMap) throws GResourceProcessingException, GValidateException {
		
		TransportRoleValidator validator = new TransportRoleValidator(locale);
		InputStream in = null;
		try {
			in = new BufferedInputStream(new FileInputStream(file), _bufferSize);
			XMLInputFactory inFactory = XMLInputFactory.newInstance();
			XMLEventReader reader = inFactory.createXMLEventReader(in);;
			while (reader.hasNext()) {
				XMLEvent event = reader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					if (ELEMENT_ROLE.equals(startElement.getName().toString())) {
						GEditableRole role = createRole(companyCode, reader);
						//labelSpaceにObjectIDを表示させる
						validator.setLabelSpaceValue(role.getObjectID());
						//単項目チェック
						validator.validateRoleSingleItem(role);
						
						//単項目エラーが発生している場合、List,Mapへのロードを行わない
						if (validator.hasError()) {
							continue;
						}
						GEditableRole newRole = getRoleDao().createRole();
						newRole.setObjectID(role.getObjectID());
						newRole.setRoleID(role.getRoleID());
						newRole.setAuthoritySet(role.getAuthoritySet());
						newRole.setDisplayNameResourceID(role.getDisplayNameResourceID());
						//チェック処理時に、インポートファイルへのアクセス回数を減らすために、ListとMapへロードする
						//Listは重複チェックにて使用
						roleList.add(newRole);
						//Mapは循環参照チェックにて使用
						roleMap.put(newRole.getObjectID(), newRole);
					}
				}
			}
			//単項目チェックで、エラーがあれば返す
			if (validator.hasError()) {
				throw new GValidateException(validator.getErrorList());
			}
		} catch (FileNotFoundException e) {
			throw new GResourceProcessingException(e);
		} catch (XMLStreamException e) {
			throw new GResourceProcessingException(e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ioe) {
				throw new GResourceProcessingException(ioe);
			}
		}
	}
	


	/**
	 * オブジェクトID,ロールID,リソースIDの重複チェックを行います
	 * ※単項目チェックにエラーがないことが前提となります
	 * 
	 * @param companyCode 会社コード
	 * @param locale 地域コード
	 * @param isObjectIDUniqueCheck オブジェクトIDの重複チェックを行うか true:チェックする,false:チェックしない
	 * @param roleList インポートファイルに対応するロールリスト
	 * @throws GResourceProcessingException daoでの検索に失敗した場合
	 * @throws GValidateException データの重複が発生した場合
	 * @create 2011/05/19
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void validateUnique(String companyCode, Locale locale, boolean isAddition, List<GEditableRole> roleList) throws GResourceProcessingException, GValidateException {
		List<GValidateError> errorList = new ArrayList<GValidateError>();
		//xmlファイルをロードしたListでチェックを行う(xmlファイルのアクセス回数を減らす為）
		for (int i = 0; i < roleList.size(); i++) {
			GEditableRole checkRole = roleList.get(i);

			GEditableRole objectIDResultRole = null;
			//ObjectIDの重複チェック
			if (isAddition) {
				//xml内の重複チェック　⇒　重複があればERROR
				objectIDResultRole = findRoleForObjectID(checkRole.getObjectID() , roleList , i);
				if (objectIDResultRole != null) {
					errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_OBJECT_ID, checkRole.getObjectID()));
				} else {
					//永続化データとの重複チェック⇒重複があればWARNING
					objectIDResultRole = (GEditableRole) getRoleDao().findRole(checkRole.getObjectID());
					if (objectIDResultRole != null) {
						errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.WARNING, ELEMENT_OBJECT_ID, checkRole.getObjectID()));
					}
				}
			}
			
			//RoleIDの重複チェック				
			//xml内の重複チェック　⇒　重複があればERROR
			GEditableRole roleIDResultRole = findRoleForRoleID(checkRole.getRoleID() , roleList , i);
			if (roleIDResultRole != null) {
				errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_ROLE_ID, checkRole.getObjectID()));
			} else {
				//永続化データとの重複チェック
				roleIDResultRole = (GEditableRole) getRoleDao().findRole(companyCode, checkRole.getRoleID());
				if (roleIDResultRole != null) {
					if (checkRole.getObjectID() != null && checkRole.getObjectID().equals(roleIDResultRole.getObjectID())) {
						if (isAddition) {
							//①重複したロールが、オブジェクトIDも重複していた場合WARNING
							errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.WARNING, ELEMENT_ROLE_ID, checkRole.getObjectID()));
						}
					} else {
						//②重複したロールが、ロールIDのみ重複していた場合、ERROR
						errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_ROLE_ID, checkRole.getObjectID()));
					}
				}
			}
			//ResourceIDの重複チェック				
			//xml内の重複チェック　⇒　重複があればERROR
			GEditableRole resourceIDResultRole = findRoleForResourceID(checkRole.getDisplayNameResourceID(), roleList, i);
			if (resourceIDResultRole != null) {
				errorList.add(createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, ELEMENT_DISPLAY_NAME_RESOURCE_ID, checkRole.getObjectID()));
			}
			//永続化データの重複チェックは行わない
			//ObjectIDが重複しているときのみ、上書きが可能であり、上書きされる際にはdeleat,Insertで上書きされる為、ゴミは残らない
		
		}
		//ユニークチェックで、エラーがあれば返す
		if (errorList.size() > 0) {
			throw new GValidateException(errorList);
		}
	}

	/**
	 * 循環参照のチェックを行います
	 * ※単項目チェック、重複チェックにエラーがないことが前提となります
	 * 
	 * @param companyCode 会社コード
	 * @param locale 地域コード
	 * @param roleMap インポートファイルに対応するロールマップ
	 * @throws GValidateException 循環参照エラーが発生した場合
	 * @create 2011/05/19
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected void validateCircularReference(String companyCode , Locale locale, Map<String, GEditableRole> roleMap) throws GValidateException {
		//xmlファイルをロードしたMapでチェックを行う(xmlファイルのアクセス回数を減らす為）
		RoleFinder finder = new TransportRoleFinder(companyCode , roleMap);
		TransportRoleValidator validator = new TransportRoleValidator(locale, finder);
		for (GEditableRole role:roleMap.values()) {
			validator.setLabelSpaceValue(role.getObjectID());
			validator.validateAuthoritySetCircularReference(role.getAuthoritySet(), role.getObjectID());
		}
		//循環参照でエラーがあれば返す
		if (validator.hasError()) {
			throw new GValidateException(validator.getErrorList());
		}

	}
	/**
	 * {@link GValidateError}を作成します
	 * 
	 * @param errorCode エラーコード
	 * @param locale 地域コード
	 * @param type エラータイプ
	 * @param label エラー項目
	 * @param labelSpace エラーが発生しているロールのObjectID
	 * @return
	 * @create 2011/05/18
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	protected GValidateError createValidateError(String errorCode, Locale locale , GErrorType type, String label, String labelSpace) {
		
		String message = null;
		if (errorCode != null) {
			message = GErrorMessages.getErrorMessage(errorCode, locale).getMessage();
		}
		
		GValidateError error = new GValidateError(errorCode, message, type);

		if (label != null) {
			error.setLabel(label);
		}
		if (labelSpace != null && !"".equals(labelSpace)) {
			//エラー発生時、xmlのどの場所でエラーが発生しているかわかるように、ObjectIDを表示する
			error.setLabelspace("ObjectID=" + labelSpace);
		}
		return error;
	}

	/**
	 * ロールリストの中からオブジェクトIDが一致するロールの検索を行います
	 * 
	 * @param objectID オブジェクトID
	 * @param roleList ロールリスト
	 * @param passIndex リスト内で検索をパスするインデックス
	 * @return
	 * @create 2011/05/17
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private GEditableRole findRoleForObjectID(String objectID , List<GEditableRole> roleList , int passIndex) {
		if (objectID == null) {
			return null;
		}
		for (int i = 0; i < roleList.size(); i++) {
			if (i == passIndex) {
				continue;
			}
			if (objectID.equals(roleList.get(i).getObjectID())) {
				return roleList.get(i);
			}
		}
		return null;
	}
	
	/**
	 * ロールリストの中からロールIDが一致するロールの検索を行います
	 * 
	 * @param roleID ロールID
	 * @param roleList ロールリスト
	 * @param passIndex リストの中で検索をパスするインデックス
	 * @return
	 * @create 2011/05/17
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private GEditableRole findRoleForRoleID(String roleID , List<GEditableRole> roleList , int passIndex) {
		if (roleID == null) {
			return null;
		}
		for (int i = 0; i < roleList.size(); i++) {
			if (i == passIndex) {
				continue;
			}
			if (roleID.equals(roleList.get(i).getRoleID())) {
				return roleList.get(i);
			}
		}
		return null;
	}
	
	/**
	 * ロールリストの中からロールIDが一致するロールの検索を行います
	 * 
	 * @param resourceID リソースID
	 * @param roleList ロールリスト
	 * @param passIndex リストの中で検索をパスするインデックス
	 * @return
	 * @create 2011/06/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private GEditableRole findRoleForResourceID(String resourceID , List<GEditableRole> roleList , int passIndex) {
		if (resourceID == null) {
			return null;
		}
		for (int i = 0; i < roleList.size(); i++) {
			if (i == passIndex) {
				continue;
			}
			if (resourceID.equals(roleList.get(i).getDisplayNameResourceID())) {
				return roleList.get(i);
			}
		}
		return null;
	}
	
	protected void addition(String companyCode, File file , Locale locale) throws GResourceProcessingException {

		InputStream in = null;
		String objectID = null;
		try {
			in = new BufferedInputStream(new FileInputStream(file), _bufferSize);
			XMLInputFactory inFactory = XMLInputFactory.newInstance();
			XMLEventReader reader = inFactory.createXMLEventReader(in);
			while (reader.hasNext()) {
				XMLEvent event = reader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					if (ELEMENT_ROLE.equals(startElement.getName().toString())) {
						GEditableRole role = createRole(companyCode, reader);
						objectID = role.getObjectID();
						getRoleDao().insertRole(role);
					}
				}
			}
		} catch (GOptimisticLockException e) {
			createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, null, objectID);
		} catch (FileNotFoundException e) {
			throw new GResourceProcessingException(e);
		} catch (XMLStreamException e) {
			throw new GResourceProcessingException(e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ioe) {
				throw new GResourceProcessingException(ioe);
			}
		}
	}

	/**
	 * xmlファイルよりロールを登録又は更新する
	 * ObjectIDが重複している場合は更新、そうでない場合は登録する。
	 * 
	 * @param companyCode
	 * @param file
	 * @throws GResourceProcessingException
	 */
	protected void diffUpdate(String companyCode, File file , Locale locale) throws GResourceProcessingException {
		InputStream in = null;
		String objectID = null;
		try {
			in = new BufferedInputStream(new FileInputStream(file), _bufferSize);
			XMLInputFactory inFactory = XMLInputFactory.newInstance();
			XMLEventReader reader = inFactory.createXMLEventReader(in);
			while (reader.hasNext()) {
				XMLEvent event = reader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					if (ELEMENT_ROLE.equals(startElement.getName().toString())) {
						GEditableRole role = createRole(companyCode, reader);
						objectID = role.getObjectID();
						GEditableRole selectRole = (GEditableRole) getRoleDao().findRole(role.getObjectID());
						if (selectRole == null) {
							getRoleDao().insertRole(role);
						} else {
							role.setExclusiveKey(selectRole.getExclusiveKey());
							getRoleDao().updateRole(role);
						}
					}
				}
			}
		} catch (GOptimisticLockException e) {
			createValidateError(UNIQUE_CHECK_ERRORCODE, locale, GErrorType.ERROR, null, objectID);
		} catch (FileNotFoundException e) {
			throw new GResourceProcessingException(e);
		} catch (XMLStreamException e) {
			throw new GResourceProcessingException(e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ioe) {
				throw new GResourceProcessingException(ioe);
			}
		}
	}
	
	/**
	 * XMLタグで内包された文字列を取得します。
	 * 
	 * @param reader
	 * @return
	 * @throws XMLStreamException
	 * @create 2011/01/25
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	private String getCharacter(XMLEventReader reader) throws XMLStreamException {
		StringBuilder builder = new StringBuilder();
		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();
			if (event.isCharacters()) {
				builder.append(event.asCharacters().getData());
			} else if (event.isEndElement()) {
				return builder.toString();
			}
		}
		return null;
	}

	protected GEditableRole createRole(String companyCode, XMLEventReader reader) throws XMLStreamException, GResourceProcessingException {
		GEditableRole role = getRoleDao().createRole();
		role.setDisplayNameMap(new HashMap<Locale, String>());
		role.setCompanyCode(companyCode);
		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				if (ELEMENT_OBJECT_ID.equals(startElement.getName().toString())) {
					role.setObjectID(getCharacter(reader));
				} else if (ELEMENT_ROLE_ID.equals(startElement.getName().toString())) {
					role.setRoleID(getCharacter(reader));
				} else if (ELEMENT_AUTHORITY_SET.equals(startElement.getName().toString())) {
					role.setAuthoritySet(getCharacter(reader));
				} else if (ELEMENT_DESCRIPTION.equals(startElement.getName().toString())) {
					role.setDescription(getCharacter(reader));
				} else if (ELEMENT_UPDATED_DT.equals(startElement.getName().toString())) {
					try {
						GDateFormatter fomatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
						Date updateDate = fomatter.parse(getCharacter(reader).trim(), GFrameworkUtils.getDefaultLocale(), DATE_FORMAT);
						role.setUpdatedDate(updateDate);
					} catch (ParseException e) {
						throw new GResourceProcessingException(e);
					}
				} else if (ELEMENT_UPDATED_PERSON.equals(startElement.getName().toString())) {
					role.setUpdatedPerson(getCharacter(reader));
					//				} else if (ELEMENT_EXCLUSIVE_FG.equals(startElement.getName().toString())) {
					//					role.setExclusiveKey(getCharacter(reader));
				} else if (ELEMENT_DISPLAY_NAME.equals(startElement.getName().toString())) {
					//リソース情報の登録
					Attribute attr = (Attribute) startElement.getAttributes().next();
					if (attr != null) {
						role.setDisplayNameResourceID(attr.getValue());
					}
					role.setDisplayNameMap(createDisplayNameMap(reader));
					
				}
			} else if (event.isEndElement()) {
				EndElement endElement = event.asEndElement();
				if (ELEMENT_ROLE.equals(endElement.getName().toString())) {
					break;
				}
			}
		}
		return role;
	}

	private Map<Locale, String> createDisplayNameMap(XMLEventReader reader) throws XMLStreamException {
		Map<Locale, String> displayName = new HashMap<Locale, String>();

		while (reader.hasNext()) {
			XMLEvent event = reader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				if (ELEMENT_RESOURCE.equals(startElement.getName().toString())) {
					Attribute attr = (Attribute) startElement.getAttributes().next();
					if (attr != null) {
						Locale locale = GLocaleUtils.getLocale(attr.getValue());
						String value = getCharacter(reader);
						displayName.put(locale, value);
					}
				} else {
					continue;
				}
			} else if (event.isEndElement()) {
				EndElement endElement = event.asEndElement();
				if (ELEMENT_DISPLAY_NAME.equals(endElement.getName().toString())) {
					return displayName;
				}
			}
		}
		return new HashMap<Locale , String>();
	}

	/**
	 * 「ファイルパス+export.+UUID」形式を引数に指定したFileクラスを返却するメソッド.<br>
	 * 
	 * @return File
	 * @throws IOException
	 * @create 2010/10/27
	 * @author fujimura
	 * @since 3.9.0
	 */
	protected File createFile() throws IOException {

		UUID uuid = UUID.randomUUID();
		String filePath = GFrameworkUtils.getProperty(EXPORTFILE_TEMPORARY_DIRECTORY);
		File file = new File(filePath);
		file.mkdirs();
		String fileName = filePath + "export." + uuid.toString();

		return new File(fileName);
	}
	
	
	private class TransportRoleFinder implements RoleFinder {

		/** xml内のロールデータをMapで保持する */
		private Map<String, GEditableRole> _map = new HashMap<String, GEditableRole>();
		
		public TransportRoleFinder(String companyCode, Map<String, GEditableRole> map) {
			_map = map;		
		}
		
		public GEditableRole findRole(String ObjectID) {
			try {
				GEditableRole role = (GEditableRole) getRoleDao().findRole(ObjectID);
				if (role != null) {
					return role;
				}
				return _map.get(ObjectID);
			} catch (GResourceProcessingException e) {
				throw new GResourceAccessException(e);
			}
		}
	}
	private class TransportRoleValidator extends GEditableRoleValidator {
		
		private String _labelSpaceValue;
		public TransportRoleValidator(Locale locale) {
			super(locale);
		}
		
		public TransportRoleValidator(Locale locale , RoleFinder finder) {
			super(locale , finder);
		}
		
		@Override
		public GValidateError createValidateError(String errorCode, GErrorType errorType, String label, String labelSpace,
			String description, String[] params) {
			GValidateError error = super.createValidateError(errorCode, errorType , label , labelSpace , description , params);
			//エラー発生時、xmlのどの場所でエラーが発生しているかわかるように、ObjectIDを表示する
			if (_labelSpaceValue != null && !"".equals(_labelSpaceValue))
			error.setLabelspace("ObjectID=" + _labelSpaceValue);
			return error;
		}
		
		public void setLabelSpaceValue(String value) {
			_labelSpaceValue = value;
		
		}
		
	}
}
