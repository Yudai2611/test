/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.zoom;

import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;


public class GAccountZoomDaoFactory {

	private GUserZoomDao _userZoomDao = null;
	private Map<String, GGroupZoomDao> _groupZoomDaoMap = null;
	
	public static GAccountZoomDaoFactory getInstance() {
		return (GAccountZoomDaoFactory) GFrameworkUtils.getComponent(GAccountZoomDaoFactory.class.getName());
	}
	
	public GAccountZoomDaoFactory(GUserZoomDao userZoomDao, Map<String, GGroupZoomDao> groupZoomDaoMap){
		_userZoomDao = userZoomDao;
		_groupZoomDaoMap = groupZoomDaoMap;
	}
	
	public GUserZoomDao getUserZoomDao() {
		return _userZoomDao;
	}
	
	public Map<String, GGroupZoomDao> getGroupZoomDaoMap() {
		return _groupZoomDaoMap;
	}
	
	public GGroupZoomDao getGroupZoomDao(String category) {
		return _groupZoomDaoMap.get(category);
	}
}
