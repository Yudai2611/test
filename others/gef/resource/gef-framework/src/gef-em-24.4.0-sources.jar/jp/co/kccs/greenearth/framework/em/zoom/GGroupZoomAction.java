/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.zoom;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.auth.GGroup;
import jp.co.kccs.greenearth.framework.data.GPageableList;
import jp.co.kccs.greenearth.framework.data.GPagingNavigator;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;

public class GGroupZoomAction {

	/** EnterpriseManagerV3用グループズームリスト */
	protected static final String GROUP_LIST = "groupListZoom";

	/** グループズーム検索用変数 */
	protected static final String GROUP_CATEGORY = "GroupCategory";
	protected static final String SEARCH_PARENT_ID = "ParentID";
	protected static final String SEARCH_GROUP_ID = "GroupID";
	protected static final String SEARCH_GROUP_NAME = "GroupName";

	/** グループズーム変数 */
	protected static final String GROUP_DISPLAY_NAME_LIST = "GroupDisplayNameList";
	protected static final String GROUP_CATEGORY_LIST = "GroupCategoryList";

	/**
	 * グループ検索用メソッド.
	 * 
	 * @create 2010/09/25
	 * @param parameter
	 * @param resultData
	 * @throws GResourceProcessingException
	 * @author fujimura
	 * @since 3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findGroupList(GParameter parameter, GResultData resultData) throws GResourceProcessingException {

		GPagingNavigator<GGroup> pager = new GPagingNavigator<GGroup>() {
			
			@Override
			public List<GGroup> findList(GParameter parameter, String listID, int startIndex, int listSize, int totalCount) throws GResourceProcessingException {
				
				String groupCategory = parameter.getValue(GROUP_CATEGORY);
				GGroupZoomDao dao = GAccountZoomDaoFactory.getInstance().getGroupZoomDao(groupCategory);
				String companyCode = GEXActionUtils.getLoginCompany().getCode();
				String parentID = GStringUtils.blankToNull(parameter.getValue(SEARCH_PARENT_ID));
				String groupID = GStringUtils.blankToNull(parameter.getValue(SEARCH_GROUP_ID));
				String groupName = GStringUtils.blankToNull(parameter.getValue(SEARCH_GROUP_NAME));
				return dao.findZoomGroupList(companyCode, parentID, groupID, groupName, startIndex + 1, listSize);
			}
			
			@Override
			public int count(GParameter parameter, String listID) throws GResourceProcessingException {
				String groupCategory = parameter.getValue(GROUP_CATEGORY);
				GGroupZoomDao dao = GAccountZoomDaoFactory.getInstance().getGroupZoomDao(groupCategory);
				String companyCode = GEXActionUtils.getLoginCompany().getCode();
				String parentID = GStringUtils.blankToNull(parameter.getValue(SEARCH_PARENT_ID));
				String groupID = GStringUtils.blankToNull(parameter.getValue(SEARCH_GROUP_ID));
				String groupName = GStringUtils.blankToNull(parameter.getValue(SEARCH_GROUP_NAME));
				return dao.countZoomGroup(companyCode, parentID, groupID, groupName);
			}
		};
		
		GPageableList<GGroup> listData = pager.findList(parameter, GROUP_LIST);

		resultData.setData(GROUP_LIST, listData);
		return resultData;
	}

	/**
	 * グループ情報詳細メソッド.
	 * 
	 * @create 2010/09/27
	 * @param parameter
	 * @param resultData
	 * @throws GResourceProcessingException
	 * @author fujimura
	 * @since 3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findGroup(GParameter parameter, GResultData resultData) throws GResourceProcessingException {
		String companyCode = GEXActionUtils.getLoginCompany().getCode();
		String category = GStringUtils.blankToNull(parameter.getValue(GROUP_CATEGORY));
		String groupID = GStringUtils.blankToNull(parameter.getValue(SEARCH_GROUP_ID));
		GGroupZoomDao dao = GAccountZoomDaoFactory.getInstance().getGroupZoomDao(category);
		GGroup group = dao.findZoomGroup(companyCode, groupID);
		resultData.setData("group", group);
		return resultData;
	}

	/**
	 * グループ名とキーを取得するメソッド
	 * 
	 * @param parameter
	 * @param resultData
	 * @return resultData結果セット
	 * @throws GResourceProcessingException
	 * @author kyo
	 * @since 3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData getGroupCategory(GParameter parameter, GResultData resultData) throws GResourceProcessingException {
		
		Map<String, GGroupZoomDao> groupDaoMap = GAccountZoomDaoFactory.getInstance().getGroupZoomDaoMap();
		List<String> categoryList = new ArrayList<String>();
		List<String> displayNameList = new ArrayList<String>();
		for (Map.Entry<String, GGroupZoomDao> entry : groupDaoMap.entrySet()) {
			categoryList.add(entry.getKey());
			GGroupZoomDao dao = entry.getValue();
			displayNameList.add(dao.getDisplayName(GFrameworkContext.getInstance().getLocale()));
		}
		resultData.setData(GROUP_DISPLAY_NAME_LIST, displayNameList);
		resultData.setData(GROUP_CATEGORY_LIST, categoryList);
		return resultData;
	}
}
