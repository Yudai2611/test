/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.zoom;

import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.auth.GGroup;


public interface GGroupZoomDao {

	String getDisplayName(Locale locale);
	
	int countZoomGroup(String companyCode, String likeParentID, String likeGroupID, String likeGroupName) throws GResourceProcessingException;

	GGroup findZoomGroup(String companyCode, String id) throws GResourceProcessingException;
	
	List<GGroup> findZoomGroupList(String companyCode, String likeParentID, String likeGroupID, String likeGroupName, int startIndex, int listSize) throws GResourceProcessingException;

}
