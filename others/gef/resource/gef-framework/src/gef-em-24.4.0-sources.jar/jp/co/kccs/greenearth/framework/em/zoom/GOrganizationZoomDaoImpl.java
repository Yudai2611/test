package jp.co.kccs.greenearth.framework.em.zoom;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.auth.*;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;
import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.catchConnection;
import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.releaseConnection;

public class GOrganizationZoomDaoImpl implements GGroupZoomDao {

	/** 組織マスタ */
	protected static final String ORGANIZATION_MASTER = "OrganizationMaster";

	/** 会社コード */
	protected static final String COMPANYCD = "CompanyCD";

	/** 組織ID */
	protected static final String ORG_ID = "ID";

	/** 親組織ID */
	protected static final String ORG_PARENTID = "ParentID";

	/** 組織名 */
	protected static final String ORG_NAME = "Name";

	/** 状態 */
	protected static final String STATUS = "Status";

	/** グループ定義名 */
	protected static final String GROUP_CATEGORY_RESOURCE_ID = "ORGANIZATION";

	private Map<String, GGroup> _groupMap = new HashMap<String, GGroup>();

	private GCompanyDao _companyDao = null;

	/**
	 * 会社DAOを指定して{@link GOrganizationDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @param companyDao
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GOrganizationZoomDaoImpl(GCompanyDao companyDao) {
		_companyDao = companyDao;
	}

	/**
	 * 表示名を取得します。
	 *
	 * @create 2020/6/23
	 * @param locale ロケール
	 * @return 表示名
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public String getDisplayName(Locale locale) {
		return GMessageResources.getMessage(GROUP_CATEGORY_RESOURCE_ID, locale);
	}

	/**
	 * {@link GGroup}を生成します。
	 *
	 * @create 2020/6/23
	 * @return GGroup
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GGroup createGroup() {
		return 	new GGroupImpl();
	}

	private GGroup findGroup(String companyCD, String id) throws GResourceProcessingException {
		if (companyCD == null || id == null) {
			return null;
		}

		String key = companyCD + "_" + id;
		if (_groupMap.containsKey(key)) {
			return _groupMap.get(key);
		}

		GGroup organization = null;
		Connection conn = catchConnection();

		// グループ情報の取得
		try {
			List<GRecord> list = select(ORGANIZATION_MASTER).wherePK(companyCD, id).orderBy(asc(col(exp("#" + ORG_ID)))).findList();
			if (list.size() != 0) {
				GRecord record = list.get(0);
				organization = createGroup();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				organization.setLocaleNameMap(nameMap);
				GCompany company = _companyDao.findCompany(companyCD);
				organization.setCompany(company);
				organization.setId(record.getString(ORG_ID));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					organization.setStatus(GStatus.Active);
				} else {
					organization.setStatus(GStatus.Stop);
				}
				organization.setName(record.getString(ORG_NAME));
				// 親グループの取得
				String parentCode = record.getString(ORG_PARENTID);
				if (parentCode != null) {
					GGroup parent = findGroup(companyCD, parentCode);
					organization.setParent(parent);
				}
				_groupMap.put(key, organization);
			}
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(conn);
		}
		return organization;
	}


	/**
	 * グループ情報を検索します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param id グループID
	 * @return グループ情報
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public GGroup findZoomGroup(String companyCD, String id) throws GResourceProcessingException {
		if (companyCD == null || id == null) {
			return null;
		}

		GGroup organization = null;
		Connection conn = catchConnection();

		// グループ情報の取得
		try {
			List<GRecord> list = select(ORGANIZATION_MASTER).wherePK(companyCD, id).findList();

			if (list.size() != 0) {
				GRecord record = list.get(0);

				organization = createGroup();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				organization.setLocaleNameMap(nameMap);
				GCompany company = _companyDao.findCompany(companyCD);
				organization.setCompany(company);
				organization.setId(record.getString(ORG_ID));
				// 親グループの取得
				String parentCode = record.getString(ORG_PARENTID);
				if (parentCode != null) {
					GGroup parent = findGroup(companyCD, parentCode);
					organization.setParent(parent);
				}
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					organization.setStatus(GStatus.Active);
				} else {
					organization.setStatus(GStatus.Stop);
				}
				organization.setName(record.getString(ORG_NAME));
			}
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(conn);
		}

		return organization;
	}

	/**
	 * 条件に一致するグループの件数を検索します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param likePrentID 前方一致の親ID
	 * @param likeGroupID 前方一致のID
	 * @param likeGroupName 部分一致のID
	 * @return 条件に一致するグループのレコード数
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public int countZoomGroup(String companyCD, String likeParentID, String likeGroupID, String likeGroupName) throws GResourceProcessingException {
		int count = 0;
		try {
			count = buildZoomGroupQuery(companyCD, likeParentID, likeGroupID, likeGroupName).count();
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
		return count;
	}

	/**
	 * 条件に一致するグループを検索します。
	 *
	 * @create 2020/6/23
	 * @param companyCode 会社コード
	 * @param likePrentID 前方一致の親ID
	 * @param likeGroupID 前方一致のID
	 * @param likeGroupName 部分一致のID
	 * @param startIndex 開始行
	 * @param listSize 取得行数
	 * @return 条件に一致するグループのレコード数
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public List<GGroup> findZoomGroupList(String companyCD, String likeParentID, String likeGroupID, String likeGroupName, int startIndex, int listSize) throws GResourceProcessingException {
		try {
			// グループ情報検索処理
			List<GRecord> dataset = buildZoomGroupQuery(companyCD, likeParentID, likeGroupID, likeGroupName)
				.orderBy(asc(col(exp("#" + ORG_ID))))
				.range(startIndex - 1, listSize)
				.findList();
			if (dataset == null) {
				return null;
			}

			List<GGroup> listGroups = new ArrayList<GGroup>();
			for (GRecord record : dataset) {
				GGroup group = createGroup();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				group.setLocaleNameMap(nameMap);
				group.setId(record.getString(ORG_ID));
				group.setName(record.getString(ORG_NAME));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					group.setStatus(GStatus.Active);
				} else {
					group.setStatus(GStatus.Stop);
				}
				listGroups.add(group);
			}
			return listGroups;
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 条件を元に{@link GEntitySelect}を構築します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param likeParentID 前方一致の親組織ID
	 * @param likeGroupID 前方一致の組織ID
	 * @param likeGroupName 部分一致の組織名
	 * @return {@link GEntitySelect}
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GEntitySelect buildZoomGroupQuery(String companyCD, String likeParentID, String likeGroupID, String likeGroupName) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyCD", companyCD);
		params.put("likeParentID", likeParentID);
		params.put("likeGroupID", likeGroupID);
		params.put("likeGroupName", likeGroupName);

		return select(ORGANIZATION_MASTER)
			.where(expMap($("#" + COMPANYCD + " = :companyCD")
				.AND("#" + ORG_PARENTID +" LIKE :[likeParentID%]")
				.AND("#" + ORG_ID + " LIKE :[likeGroupID%]")
				.AND("#" + ORG_NAME +" LIKE :[%likeGroupName%]"), params));
	}
}
