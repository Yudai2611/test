/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.zoom;

import java.util.List;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GPageableList;
import jp.co.kccs.greenearth.framework.data.GPagingNavigator;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;

/**
 * リクエストパラメータを元に、ユーザー情報を任意の型で返すクラスです。<br>
 * <br>
 * <b>【処理概要】</b><br>
 * EnterpriseManagerV3において、ユーザー情報を表示するズームが提供されています。<br>
 * 本クラスはそのユーザー情報ズーム機能を提供しているアクションクラスになります。<br>
 * <br>
 * <b>【アクションの実行ルール】</b><br>
 * 　{@link GUserZoomAction}は特定のルールに則り、リクエストに応じた任意のビジネスロジックを実行します。<br>
 * 
 * @create 2010/10/14
 * @author KCCS fujimura
 * @since 3.9.0
 */
public class GUserZoomAction {

	/** EnterpriseManagerV3用ユーザーズームリスト. */
	protected static final String USER_LIST = "userListZoom";
	
	/** ユーザーズーム検索用定数 */
	protected static final String SEARCH_USER_ID = "ID_0";
	protected static final String SEARCH_USER_NAME = "Name_1";
	protected static final String SEARCH_USER_COMPANY_CODE = "CompanyCode_2";

	/**
	 * EnterpriseManagerV3において、検索した複数のユーザー情報をリスト型で取得し、 その結果を{@link GResultData}
	 * に格納し返却するアクションメソッドです。.
	 * 
	 * @create 2010/09/25
	 * @param parameter
	 * @param resultData
	 * @throws GResourceProcessingException
	 * @author fujimura
	 * @since 3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findUserList(GParameter parameter, GResultData resultData) throws GResourceProcessingException {

		GPagingNavigator<GUser> pager = new GPagingNavigator<GUser>() {
			
			@Override
			public List<GUser> findList(GParameter parameter, String listID, int startIndex, int listSize, int totalCount) throws GResourceProcessingException {
				GUserZoomDao dao = GAccountZoomDaoFactory.getInstance().getUserZoomDao();
				String companyCode = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_COMPANY_CODE));
				String userID = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_ID));
				String userName = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_NAME));
				return dao.findZoomUserList(companyCode, userID, userName, startIndex + 1, listSize);
			}
			
			@Override
			public int count(GParameter parameter, String listID) throws GResourceProcessingException {
				GUserZoomDao dao = GAccountZoomDaoFactory.getInstance().getUserZoomDao();
				String companyCode = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_COMPANY_CODE));
				String userID = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_ID));
				String userName = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_NAME));
				return dao.countZoomUser(companyCode, userID, userName);
			}
		};
		
		GPageableList<GUser> listData = pager.findList(parameter, USER_LIST);

		resultData.setData(USER_LIST, listData);
		return resultData;
	}

	/**
	 * EnterpriseManagerV3において、ユーザーズーム検索画面上の個人のユーザー情報を検索し、 取得した結果を、それぞれ
	 * {@link GResultData}に格納し、返却するメソッドです。<br>
	 * 
	 * @create 2010/09/25
	 * @param parameter
	 * @param resultData
	 * @throws GResourceProcessingException
	 * @author fujimura
	 * @since 3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findUser(GParameter parameter, GResultData resultData) throws GResourceProcessingException {
		
		String companyCode = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_COMPANY_CODE));
		String userid = GStringUtils.blankToNull(parameter.getValue(SEARCH_USER_ID));
		GUserZoomDao dao = GAccountZoomDaoFactory.getInstance().getUserZoomDao();
		GUser user = dao.findZoomUser(companyCode, userid);
		resultData.setData("user", user);
		return resultData;
	}
}