/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.em.zoom;

import java.util.List;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.auth.GUser;


public interface GUserZoomDao {
	
	int countZoomUser(String companyCode, String likeUserId, String likeUserName) throws GResourceProcessingException;
	GUser findZoomUser(String comapnyCode , String id) throws GResourceProcessingException;
	List<GUser> findZoomUserList(String companyCode, String likeUserId, String likeUserName, int startIndex, int listSize) throws GResourceProcessingException;
}
