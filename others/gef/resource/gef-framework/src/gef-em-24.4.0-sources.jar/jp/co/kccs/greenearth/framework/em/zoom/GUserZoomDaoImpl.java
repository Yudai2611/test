package jp.co.kccs.greenearth.framework.em.zoom;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.auth.*;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.catchConnection;
import static jp.co.kccs.greenearth.framework.utils.GJdbcUtil.releaseConnection;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.$;

public class GUserZoomDaoImpl implements GUserZoomDao {

	/** ユーザーマスタ */
	protected static final String USER_MASTER = "UserMaster";

	/** 会社コード */
	protected static final String COMPANYCD = "CompanyCD";

	/** ユーザーID */
	protected static final String USER_ID = "ID";

	/** ユーザー名 */
	protected static final String USER_NAME = "Name";

	/** パスワード */
	protected static final String PASSWORD = "Password";

	/** 状態 */
	protected static final String STATUS = "Status";

	/** 外部キー（ユーザー組織マップ） */
	protected static final String ORGANIZATION_KEY = "OrganizationKey";

	/** 外部キー（ユーザー職位マップ） */
	protected static final String RANK_KEY = "RankKey";

	/** 組織ID（ユーザー組織マップ） */
	protected static final String ORGANIZATION_ID = "OrganizationID";

	/** 職位ID（ユーザー職位マップ） */
	protected static final String RANKID = "RankID";

	/** 会社DAO. */
	private GCompanyDao _companyDao = null;

	/** グループDAOマップ. */
	private Map<String, GGroupZoomDao> _groupDaoMap = null;

	private Map<String, GUser> _userMap = new HashMap<String, GUser>();

	/**
	 * 会社DAOを指定して{@link GUserDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @param companyDao
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GUserZoomDaoImpl(GCompanyDao companyDao) {
		_companyDao = companyDao;
	}

	/**
	 * 会社DAOとグループDAOリストを指定して{@link GUserDaoImpl}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @param companyDao
	 * @param groupDaoMap
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GUserZoomDaoImpl(GCompanyDao companyDao, Map<String, GGroupZoomDao> groupDaoMap) {
		_companyDao = companyDao;
		_groupDaoMap = groupDaoMap;
	}

	/**
	 * {@link GUser}を生成します。
	 *
	 * @create 2020/6/23
	 * @return GUser
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GUser createUser() {
		return new GUserImpl();
	}



	/**
	 * ユーザ情報を検索します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param id ユーザID
	 * @return ユーザ情報
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public GUser findZoomUser(String companyCD, String id) throws GResourceProcessingException {

		GUser user = null;
		Connection conn = null;

		try {
			conn = catchConnection();
			// ユーザ情報の取得
			List<GRecord> list = select(USER_MASTER).wherePK(companyCD, id).findList();
			if (list.size() == 0) {
				return null;
			} else {
				GRecord record = list.get(0);
				user = createUser();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				user.setLocaleNameMap(nameMap);
				user.setId(id);
				user.setName(record.getString(USER_NAME));
				user.setPassword(record.getString(PASSWORD));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					user.setStatus(GStatus.Active);
				} else {
					user.setStatus(GStatus.Stop);
				}

				// 会社情報の取得
				GCompany company = null;
				if (_companyDao != null) {
					company = _companyDao.findCompany(companyCD);
					user.setCompany(company);
				}

				return user;
			}
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(conn);
		}
	}

	/**
	 * 条件に一致するユーザ数を返します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param likeUserId 前方一致のユーザID
	 * @param likeUserName 部分一致のユーザ名
	 * @return 条件に一致するユーザ数
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public int countZoomUser(String companyCD, String likeUserId, String likeUserName) throws GResourceProcessingException {
		int count = 0;
		try {
			// 総件数の取得
			count = buildZoomUserQuery(companyCD, likeUserId, likeUserName).count();
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
		return count;
	}

	/**
	 * 条件に一致するユーザ情報を返します。
	 *
	 * @create 2020/6/23
	 * @param companyCode 会社コード
	 * @param likeUserId 前方一致のユーザID
	 * @param likeUserName 部分一致のユーザ名
	 * @param startIndex 開始行
	 * @param listSize 取得する行数
	 * @return ユーザ情報のリスト
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public List<GUser> findZoomUserList(String companyCD, String likeUserId, String likeUserName, int startIndex, int listSize) throws GResourceProcessingException {
		try {
			// ユーザー情報検索処理
			Map<String, Object> searchParams = new HashMap<String, Object>();
			searchParams.put("companyCD", companyCD);
			searchParams.put("likeUserId", likeUserId);
			searchParams.put("likeUserName", likeUserName);

			List<GRecord> dataset = select(USER_MASTER)
				.where(expMap($("#" + COMPANYCD + " = :companyCD")
					.AND("#" + USER_ID + " like :[likeUserId%]")
					.AND("#" + USER_NAME + " like :[%likeUserName%]"), searchParams))
				.orderBy(asc(col(exp("#" + USER_ID))))
				.range(startIndex - 1, listSize)
				.findList();
			if (dataset == null) {
				return null;
			}

			List<GUser> listUsers = new ArrayList<GUser>();
			for (GRecord record : dataset) {
				GUser user = createUser();
				Map<Locale,String> nameMap = new HashMap<Locale, String>();
				List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
				for(Locale locale : localeList){
					nameMap.put(locale, null);
				}
				user.setLocaleNameMap(nameMap);
				user.setId(record.getString(USER_ID));
				user.setName(record.getString(USER_NAME));
				user.setPassword(record.getString(PASSWORD));
				boolean bool = GBooleanUtils.isTrueBit(record.getInteger(STATUS));
				if (bool) {
					user.setStatus(GStatus.Active);
				} else {
					user.setStatus(GStatus.Stop);
				}
				listUsers.add(user);
			}
			return listUsers;
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 条件を元に{@link GEntitySelect}を構築します。
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param likeUserId 前方一致のユーザID
	 * @param likeUserName 部分一致のユーザ名
	 * @return GEntitySelect
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private GEntitySelect buildZoomUserQuery(String companyCD, String likeUserId, String likeUserName) {
		// ユーザー情報検索処理
		Map<String, Object> searchParams = new HashMap<String, Object>();
		searchParams.put("companyCD", companyCD);
		searchParams.put("likeUserId", likeUserId);
		searchParams.put("likeUserName", likeUserName);

		return select(USER_MASTER)
			.where(expMap($("#" + COMPANYCD +" = :companyCD")
				.AND("#" + USER_ID + " like :[%likeUserId%]")
				.AND("#" + USER_NAME + " like :[%likeUserName%]"), searchParams));
	}
}
