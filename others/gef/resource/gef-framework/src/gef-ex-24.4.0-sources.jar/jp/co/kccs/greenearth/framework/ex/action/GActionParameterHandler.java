/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.ex.action;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;

public interface GActionParameterHandler {
	static String GEF_RIA_CLIENT_ID = "gef-ria-client";
	static String GEF_XRMI_CLIENT_ID = "gef-smart-client";
	
	String extractCellData(GParameter parameter);
	GListData extractListData(GParameter parameter, String listName);
	GRowData extractRowData(GParameter parameter);
	String getCellNameInActionId(GParameter parameter);
	String getListNameInActionId(GParameter parameter);
	int getRowIndexInActionId(GParameter parameter);
}
