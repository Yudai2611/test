/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.ex.action;

import jp.co.kccs.greenearth.framework.GParameter;

public interface GActionParameterHandlerFactory {
	GActionParameterHandler getActionParameterHandler(String productid);
	GActionParameterHandler getActionParameterHandler(GParameter parameter);
}
