/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.ex.action;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.framework.GParameter;

public class GActionParameterHandlerFactoryImpl implements GActionParameterHandlerFactory {

	private Map<String, GActionParameterHandler> _handlerMap = new HashMap<String, GActionParameterHandler>();
	private static final String DEFAULT_HANDLER_KEY = GActionParameterHandler.GEF_RIA_CLIENT_ID;
	private static final String PRODUCT_ID = "productid";

	public GActionParameterHandlerFactoryImpl(Map<String, GActionParameterHandler> handlerMap) {
		_handlerMap = handlerMap;
	}

	public GActionParameterHandler getActionParameterHandler(String productid) {
		GActionParameterHandler handler = _handlerMap.get(productid);
		if (handler == null) {
			return _handlerMap.get(DEFAULT_HANDLER_KEY);
		}
		return handler;
	}
	
	public GActionParameterHandler getActionParameterHandler(GParameter parameter) {
		return getActionParameterHandler(parameter.getValue(PRODUCT_ID));
	}
}
