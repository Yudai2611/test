/*
 * Copyright 2008-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.ex.action;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;
import jp.co.kccs.greenearth.framework.utils.GActionUtils;

/**
 * アクションで利用する基本的な操作を簡素化する機能を提供します.<br>
 *
 * @create 2008/06/17
 * @author kitamura
 * @since 3.5.0
 */
public final class GEXActionUtils extends GActionUtils  {

	private static GActionParameterHandlerFactory _factory = null;
	
	/**
	 * Don't let anyone instantiate this class.
	 *
	 * @create 2007/03/07
	 * @author fujikawa
	 * @since 3.5.0
	 */
	private GEXActionUtils() {
	}

	/**
	 * 取得したエラーコードからメッセージを取得しエラー情報を生成します。<br>
	 *
	 * @author zhu kaiyun
	 * @param errorCode エラーコード
	 * @return エラー情報
	 * @create 2007/06/16
	 * @since 3.5.0
	 */
	public static GValidateError createValidateError(String errorCode) {
		GErrorMessage message = GErrorMessages.getErrorMessage(errorCode, GFrameworkContext.getInstance().getLocale());
		return new GValidateError(message);
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたリスト・インデックスの各値を取得し、 結果セット行データ
	 * {@link jp.co.kccs.greenearth.framework.data.GRowData}で返却します.<br>
	 *
	 * @create 2011/08/11
	 * @param parameter パラメータ
	 * @return 結果セット行データ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static GRowData extractRowData(GParameter parameter) {
		return handler(parameter).extractRowData(parameter);
	}

	/**
	 * アクションIDより、該当する行データを取得します.<br/>
	 *
	 * @create 2011/07/24
	 * @param parameter パラメータ
	 * @return セルの値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String extractCellData(GParameter parameter) {
		return handler(parameter).extractCellData(parameter);
	}

	/**
	 * {@link jp.co.kccs.greenearth.framework.GParameter}から指定されたリスト名の各値を取得し
	 * 結果セットリストデータ{@link jp.co.kccs.greenearth.framework.data.GListData}で返却します.<br>
	 *
	 * @create 2011/03/25
	 * @param parameter パラメータ
	 * @param listName リスト名
	 * @return 結果セットリストデータ
	 * @author t.aono
	 * @since 3.9.0
	 */
	public static GListData extractListData(final GParameter parameter, final String listName) {
		return handler(parameter).extractListData(parameter, listName);
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたセルのIDを返却します.<br>
	 *
	 * @create 2011/07/24
	 * @param parameter パラメータ
	 * @return セルのID
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String getCellNameInActionId(GParameter parameter) {
		return handler(parameter).getCellNameInActionId(parameter);
	}

	public static String getListNameInActionId(GParameter parameter) {
		return handler(parameter).getListNameInActionId(parameter);
	}

	public static int getRowIndexInActionId(GParameter parameter) {
		return handler(parameter).getRowIndexInActionId(parameter);
	}

	/**
	 * {@link GWebContext}の情報よりログインユーザが所属する会社情報を取得します.<br>
	 *
	 * @author zhu kaiyun
	 * @return 会社情報
	 * @create 2007/06/16
	 * @since 3.5.0
	 */
	public static GCompany getLoginCompany() {
		GUser user = getLoginUser();
		if (user == null) {
			return null;
		}
		return user.getCompany();
	}

	/**
	 * {@link GWebContext}の情報よりログインユーザを取得します.<br>
	 *
	 * @author zhu kaiyun
	 * @return ログインユーザ
	 * @create 2007/06/16
	 * @since 3.5.0
	 */
	public static GUser getLoginUser() {
		GWebContext localContext = GWebContext.getInstance();
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session = manager.getSession(localContext.getRequest().getSession());
		if (session != null && !session.isInvalid()) {
			return session.getLoginUser();
		}
		return null;
	}

	private static GActionParameterHandler handler(GParameter parameter) {
		if (_factory == null) {
			_factory = GFrameworkUtils.getComponent(GActionParameterHandlerFactory.class.getName());
		}
		return _factory.getActionParameterHandler(parameter);
	}
}
