/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.ex.action;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;

import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.*;
import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.sql.GUniqueConstraintException;
import jp.co.kccs.greenearth.framework.utils.GCopyType;


/**
 * TODO [2013/07/31][kitamura]会社コード、登録者、更新者の取り扱いの検討
 * TODO [2013/07/31][kitamura]検索条件の自動抽出の仕組みの検討
 *
 * アクション中の処理におけるGjdbcを利用する処理を簡易化するユーティリティです。<br>
 *
 * @author KCCS K.Fujita
 * @create 2013/07/23
 * @since 3.12.0
 */
public class GGjdbcActionUtils {

	/** 排他エラーのエラーコード. */
	static final String ERROR_CD_EXCLUSIVE = "GEF-000102";
	/** ユニークエラーのエラーコード. */
	static final String ERROR_CD_UNIQUE = "GEF-000052";

	private static Connection catchConnection(String dataSource) throws SQLException {
		GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
		return ds.open(dataSource);
	}

	private static void releaseConnection(Connection connection) throws SQLException {
		GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
		ds.close(connection);
	}

	/**
	 * エンティティの各列に対応する値を{@link GParameter}からコピーして{@link GRecord}に設定します。<br>
	 *
	 * @param record 値が設定されるレコード
	 * @param parameter 値のコピー元となるパラメータ
	 * @param entityName エンティティ名
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void copyValue(GRecord record, GParameter parameter, String entityName) {
		copyValue(record, parameter, entityName, GCopyType.ALL_COPY);
	}

	/**
	 * エンティティの各列に対応する値を{@link GParameter}からコピーして{@link GRecord}に設定します。<br>
	 * copyTypeに{@link GCopyType#ALL_COPY}を指定した場合、全ての項目をコピーします。<br>
	 * copyTypeに{@link GCopyType#BLANK_TO_NULL}を指定した場合、空文字値を<code>null</code>に変換してコピーします。<br>
	 * copyTypeに{@link GCopyType#EXCEPT_BLANK}を指定した場合、空文字項目はコピーされません。<br>
	 *
	 * @param record 値が設定されるレコード
	 * @param parameter 値のコピー元となるパラメータ
	 * @param entityName エンティティ名
	 * @param copyType コピータイプ
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void copyValue(GRecord record, GParameter parameter, String entityName, GCopyType copyType) {
		GEntity entity = entity(entityName);
		if (entity == null) {
			return;
		}

		for (String columnName : entity.getColumns().keySet()) {
			// 対象項目がGParameter内に含まれていない場合は、GRecordにはセットしない
			if (parameter.containsValueKey(columnName)) {
				String value = parameter.getValue(columnName);

				// 空文字を無視する
				if (!(copyType == GCopyType.EXCEPT_BLANK && "".equals(value))) {
					GColumnType type = entity.getColumns().get(columnName).getType();

					// String
					if (GColumnType.VARCHAR.equals(type) || GColumnType.CHAR.equals(type) || GColumnType.LONGVARCHAR.equals(type)) {
						if (copyType == GCopyType.BLANK_TO_NULL) {
							record.setObject(columnName, GStringUtils.blankToNull(parameter.getValue(columnName)));
						} else {
							record.setObject(columnName, parameter.getValue(columnName));
						}
					}
					// Boolean
					else if (GColumnType.BOOLEAN.equals(type)) {
						record.setObject(columnName, parameter.getBoolean(columnName));
					}
					// BigDecimal
					else if (GColumnType.NUMERIC.equals(type)) {
						record.setObject(columnName, parameter.getBigDecimal(columnName));
					}
					// Byte
					else if (GColumnType.BYTE.equals(type)) {
						record.setObject(columnName, parameter.getByte(columnName));
					}
					// Short
					else if (GColumnType.SHORT.equals(type)) {
						record.setObject(columnName, parameter.getShort(columnName));
					}
					// Integer
					else if (GColumnType.INTEGER.equals(type)) {
						record.setObject(columnName, parameter.getInteger(columnName));
					}
					// Long
					else if (GColumnType.LONG.equals(type)) {
						record.setObject(columnName, parameter.getLong(columnName));
					}
					// Float
					else if (GColumnType.FLOAT.equals(type)) {
						record.setObject(columnName, parameter.getFloat(columnName));
					}
					// Double
					else if (GColumnType.DOUBLE.equals(type)) {
						record.setObject(columnName, parameter.getDouble(columnName));
					}
					// Date
					else if (GColumnType.DATE.equals(type) || GColumnType.TIMESTAMP.equals(type)) {
						record.setObject(columnName, parameter.getDate(columnName));
					}
				}
			}
		}
	}

	/**
	 * エンティティの各列に対応する値を{@link GParameter}からコピーして{@link GRecord}に設定します。<br>
	 *
	 * @param record 値が設定されるレコード
	 * @param rowData 値のコピー元となる行データ
	 * @param entityName エンティティ名
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void copyValue(GRecord record, GRowData rowData, String entityName) {
		copyValue(record, rowData, entityName, GCopyType.ALL_COPY);
	}

	/**
	 * エンティティの各列に対応する値を{@link GParameter}からコピーして{@link GRecord}に設定します。<br>
	 * copyTypeに{@link GCopyType#ALL_COPY}を指定した場合、全ての項目をコピーします。<br>
	 * copyTypeに{@link GCopyType#BLANK_TO_NULL}を指定した場合、空文字値を<code>null</code>に変換してコピーします。<br>
	 * copyTypeに{@link GCopyType#EXCEPT_BLANK}を指定した場合、空文字項目はコピーされません。<br>
	 *
	 * @param record 値が設定されるレコード
	 * @param rowData 値のコピー元となる行データ
	 * @param entityName エンティティ名
	 * @param copyType コピータイプ
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void copyValue(GRecord record, GRowData rowData, String entityName, GCopyType copyType) {
		GEntity entity = entity(entityName);
		if (entity == null) {
			return;
		}

		for (String columnName : entity.getColumns().keySet()) {
			// 対象項目がGRowData内に含まれていない場合は、GRecordにはセットしない
			if (rowData.containsName(columnName)) {

				// 空文字を無視する
				if (!(copyType == GCopyType.EXCEPT_BLANK && "".equals(rowData.getData(columnName)))) {
					GColumnType type = entity.getColumns().get(columnName).getType();

					// String
					if (GColumnType.VARCHAR.equals(type) || GColumnType.CHAR.equals(type) || GColumnType.LONGVARCHAR.equals(type)) {
						if (copyType == GCopyType.BLANK_TO_NULL) {
							record.setObject(columnName, GStringUtils.blankToNull(rowData.getString(columnName)));
						} else {
							record.setObject(columnName, rowData.getString(columnName));
						}
					}
					// Boolean
					else if (GColumnType.BOOLEAN.equals(type)) {
						record.setObject(columnName, rowData.getBoolean(columnName));
					}
					// BigDecimal
					else if (GColumnType.NUMERIC.equals(type)) {
						record.setObject(columnName, rowData.getBigDecimal(columnName));
					}
					// Byte
					else if (GColumnType.BYTE.equals(type)) {
						record.setObject(columnName, rowData.getByte(columnName));
					}
					// Short
					else if (GColumnType.SHORT.equals(type)) {
						record.setObject(columnName, rowData.getShort(columnName));
					}
					// Integer
					else if (GColumnType.INTEGER.equals(type)) {
						record.setObject(columnName, rowData.getInteger(columnName));
					}
					// Long
					else if (GColumnType.LONG.equals(type)) {
						record.setObject(columnName, rowData.getLong(columnName));
					}
					// Float
					else if (GColumnType.FLOAT.equals(type)) {
						record.setObject(columnName, rowData.getFloat(columnName));
					}
					// Double
					else if (GColumnType.DOUBLE.equals(type)) {
						record.setObject(columnName, rowData.getDouble(columnName));
					}
					// Date
					else if (GColumnType.DATE.equals(type) || GColumnType.TIMESTAMP.equals(type)) {
						record.setObject(columnName, rowData.getDate(columnName));
					}
				}
			}
		}
	}

	/**
	 * {@link GRecord}の各列に設定されている値を{@link GResultData}に設定します。<br>
	 *
	 * @param resultData 値が設定される結果データ
	 * @param record 値のコピー元となるレコード
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void copyValue(GResultData resultData, GRecord record) {
		copyValue(resultData, record, GCopyType.ALL_COPY);
	}

	/**
	 * {@link GRecord}の各列に設定されている値を{@link GResultData}に設定します。<br>
	 * copyTypeに{@link GCopyType#ALL_COPY}を指定した場合、全ての項目をコピーします。<br>
	 * copyTypeに{@link GCopyType#BLANK_TO_NULL}を指定した場合、空文字値を<code>null</code>に変換してコピーします。<br>
	 * copyTypeに{@link GCopyType#EXCEPT_BLANK}を指定した場合、空文字項目はコピーされません。<br>
	 *
	 * @param resultData 値が設定される結果データ
	 * @param record 値のコピー元となるレコード
	 * @param copyType コピータイプ
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void copyValue(GResultData resultData, GRecord record, GCopyType copyType) {
		for (String columnName : record.getVariants().keySet()) {
			Object data = record.getObject(columnName);
			// 空文字を無視する
			if (!(copyType == GCopyType.EXCEPT_BLANK && "".equals(data))) {
				if (data instanceof String && copyType == GCopyType.BLANK_TO_NULL) {
					resultData.setData(columnName, GStringUtils.blankToNull((String) data));
				} else {
					resultData.setData(columnName, data);
				}
			}
		}
	}

	/**
	 * {@link GRecord}およびそのサブタイプのリストから{@link GListData}を生成します。<br>
	 *
	 * @param list {@link GListData}の生成元となるレコードのリスト
	 * @return レコードのリストから生成された{@link GListData}
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static GListData createListData(List< ? extends GRecord> list) {
		GListData listData = new GListData();
		for (GRecord record : list) {
			GRowData rowData = new GRowData();
			for (String columnName : record.getVariants().keySet()) {
				rowData.setData(columnName, record.getObject(columnName));
			}
			listData.add(rowData);
		}
		return listData;
	}

	/**
	 * {@link GRecord}の各列に設定されている値から{@link GResultData}を生成します。<br>
	 *
	 * @param record {@link GResultData}の生成元となるレコード
	 * @return レコードの持つ値から生成された{@link GResultData}
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static GResultData createResultData(GRecord record) {
		GResultData resultData = GResultData.Factory.create();
		for (String columnName : record.getVariants().keySet()) {
			resultData.setData(columnName, record.getObject(columnName));
		}
		return resultData;
	}

	/**
	 * {@link GRecord}の各列に設定されている値から{@link GRowData}を生成します。<br>
	 *
	 * @param record {@link GRowData}の生成元となるレコード
	 * @return レコードの持つ値から生成された{@link GRowData}
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static GRowData createRowData(GRecord record) {
		GRowData rowData = new GRowData();
		for (String columnName : record.getVariants().keySet()) {
			rowData.setData(columnName, record.getObject(columnName));
		}
		return rowData;
	}

	/**
	 * {@link GParameter}より指定されたエンティティの情報を抽出し、それを基にレコードを削除します。<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param entityName エンティティ名
	 * @throws SQLException 削除処理中に例外が発生した場合
	 * @throws GValidateException 楽観的排他制御のため削除処理が失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void deleteRecord(GParameter parameter, String entityName) throws SQLException, GValidateException {
		GRecord record = createRecord();
		copyValue(record, parameter, entityName);
		try {
			delete(entityName).wherePK(record).execute();
		} catch (GOptimisticLockException e) {
			// FIXME エラーメッセージ取得のファイル化対応が完了していないため、一時保留
//			throw new GValidateException(GActionUtils.createValidateError(ERROR_CD_EXCLUSIVE));
			throw new GValidateException();
		}
	}

	/**
	 * {@link GRowData}より指定されたエンティティの情報を抽出し、それを基にレコードを削除します。<br>
	 *
	 * @param rowData 行データ
	 * @param entityName エンティティ名
	 * @throws SQLException 削除処理中に例外が発生した場合
	 * @throws GValidateException 楽観的排他制御のため削除処理が失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void deleteRecord(GRowData rowData, String entityName) throws SQLException, GValidateException {
		GRecord record = createRecord();
		copyValue(record, rowData, entityName);
		try {
			delete(entityName).wherePK(record).execute();
		} catch (GOptimisticLockException e) {
			// FIXME エラーメッセージ取得のファイル化対応が完了していないため、一時保留
//			throw new GValidateException(GActionUtils.createValidateError(ERROR_CD_EXCLUSIVE));
			throw new GValidateException();
		}
	}

	/**
	 * {@link GParameter}より指定されたエンティティの情報を抽出し、それを基にレコードを新規登録します。<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param entityName エンティティ名
	 * @throws SQLException 登録処理中に例外が発生した場合
	 * @throws GValidateException 楽観的排他制御のため登録処理が失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void insertRecord(GParameter parameter, String entityName) throws SQLException, GValidateException {
		GRecord record = createRecord();
		copyValue(record, parameter, entityName);

		try {
			insert(entityName).values(record).execute();
		} catch (GUniqueConstraintException e) {
			throw new GValidateException(GEXActionUtils.createValidateError(ERROR_CD_UNIQUE));
		}
	}

	/**
	 * {@link GRowData}より指定されたエンティティの情報を抽出し、それを基にレコードを新規登録します。<br>
	 *
	 * @param rowData 行データ
	 * @param entityName エンティティ名
	 * @throws SQLException 登録処理中に例外が発生した場合
	 * @throws GValidateException 楽観的排他制御のため登録処理が失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void insertRecord(GRowData rowData, String entityName) throws SQLException, GValidateException {
		GRecord record = createRecord();
		copyValue(record, rowData, entityName);

		try {
			insert(entityName).values(record).execute();
		} catch (GUniqueConstraintException e) {
			throw new GValidateException(GEXActionUtils.createValidateError(ERROR_CD_UNIQUE));
		}
	}

	/**
	 * {@link GParameter}より指定されたエンティティの情報を抽出し、それを基にレコードを更新します。<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param entityName エンティティ名
	 * @throws SQLException 更新処理中に例外が発生した場合
	 * @throws GValidateException 楽観的排他制御のため更新処理が失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void updateRecord(GParameter parameter, String entityName) throws SQLException, GValidateException {
		GRecord record = createRecord();
		copyValue(record, parameter, entityName);
		try {
			update(entityName).set(record).wherePK().execute();
		} catch (GOptimisticLockException e) {
			throw new GValidateException(GEXActionUtils.createValidateError(ERROR_CD_EXCLUSIVE));
		}
	}

	/**
	 * {@link GRowData}より指定されたエンティティの情報を抽出し、それを基にレコードを更新します。<br>
	 *
	 * @param rowData 行データ
	 * @param entityName エンティティ名
	 * @throws SQLException 更新処理中に例外が発生した場合
	 * @throws GValidateException 楽観的排他制御のため更新処理が失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static void updateRecord(GRowData rowData, String entityName) throws SQLException, GValidateException {
		GRecord record = createRecord();
		copyValue(record, rowData, entityName);
		try {
			update(entityName).set(record).wherePK().execute();
		} catch (GOptimisticLockException e) {
			throw new GValidateException(GEXActionUtils.createValidateError(ERROR_CD_EXCLUSIVE));
		}
	}

	/**
	 * パラメータに含まれる"mode"の値により、検索モードを決め、ページネーション用の検索処理を実行します.<br>
	 * 検索した結果は、{@link GListData}形式で取得されます。<br>
	 *
	 * <code>mode</code>パラメータを識別子に利用することで、「次へ」、「前へ」「最初へ」、「最後へ」のページング処理を自動化します。
	 * <table border="1" cellpadding="3" cellspacing="0">
	 * <tr bgcolor="#CCCCFF"><td>mode</td><td>動作</td></tr>
	 * <tr><td>first</td><td>最初へ</td></tr>
	 * <tr><td>previous</td><td>前へ</td></tr>
	 * <tr><td>next</td><td>次へ</td></tr>
	 * <tr><td>last</td><td>最後へ</td></tr>
	 * </table>
	 *
	 * @param select 検索条件が設定されたクエリ(GEntitySelect・GDirectSelect両方設定可能)
	 * @param listID リストID
	 * @param parameter 画面パラメータ
	 * @return 検索結果のリスト
	 * @throws SQLException 検索処理中に例外が発生した場合
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public static GListData findListData(GSelect select, String listID, GParameter parameter) throws SQLException {
		GSearchMode searchMode = GSearchMode.create(parameter.getValue(GActionServlet.ACTION_MODE_KEY));
		return findList(select, listID, parameter, searchMode);
	}

	/**
	 * パラメータに含まれる"destpage"の値により、検索モードを決め、ページネーション用の検索処理を実行します.<br>
	 * 検索した結果は、{@link GListData}形式で取得されます。<br>
	 *
	 * <code>destpage</code>パラメータを識別子に利用することで、「次へ」、「前へ」、「指定ページへ」のページング処理を自動化します。
	 * <table border="1" cellpadding="3" cellspacing="0">
	 * <tr bgcolor="#CCCCFF"><td>destpage</td><td>動作</td></tr>
	 * <tr><td>previous</td><td>前へ</td></tr>
	 * <tr><td>next</td><td>次へ</td></tr>
	 * <tr><td>pageno</td><td>指定ページへ</td></tr>
	 * </table>
	 *
	 * @param select 検索条件が設定されたクエリ(GEntitySelect・GDirectSelect両方設定可能)
	 * @param listID リストID
	 * @param parameter 画面パラメータ
	 * @return ページネーション用の検索結果
	 * @throws SQLException 検索処理中に例外が発生した場合
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public static GListData findPaginationData(GSelect select, String listID, GParameter parameter) throws SQLException {
		GSearchMode searchMode = GSearchMode.create(parameter.getValue(GPagingNavigator.DESTPAGE));
		return findList(select, listID, parameter, searchMode);
	}

	/**
	 * プライマリーキーを条件に、単一レコードを検索します。<br>
	 *
	 * @param entityName エンティティ名
	 * @param primaryKeyValues プライマリキーの検索条件
	 * @return 検索結果
	 * @throws SQLException 検索処理中に例外が発生した場合
	 * @author KCCS K.Fujita
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public static GRecord findRecord(String entityName, Object... primaryKeyValues) throws SQLException {
		return select(entityName).wherePK(primaryKeyValues).findRecord();
	}

	/**
	 * 指定検索モードで、検索処理を実行し、検索結果を返します。<br>
	 *
	 * @param select 検索クエリ(GEntitySelect・GDirectSelect両方設定可能)
	 * @param listID リストID
	 * @param parameter 画面パラメータ
	 * @param searchMode 検索モード
	 * @return 指定された範囲の検索結果
	 * @throws SQLException 検索実行時の例外
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public static GListData findList(GSelect select, String listID, GParameter parameter, GSearchMode searchMode) throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(select.getDatabase().getDataSource());
			// 検索処理実行
			// 件数カウント
			int totalCount = select.count(connection);

			int listSize = getListSize(listID, parameter);

			int startIndex = GPagingNavigator.calculateStartIndex(getStartIndex(listID, parameter),
					listSize, totalCount, searchMode);

			List<GRecord> list = select.range(startIndex, listSize).findList(connection);

			GListData listData = createListData(list);
			listData.setStartIndex(startIndex);
			listData.setTotalSize(totalCount);
			listData.setMaxListSize(listSize);

			return listData;
		} finally {
			releaseConnection(connection);
		}
	}

	private static int getStartIndex(String listID, GParameter parameter) {
		int startIndex = 0;
		String strStartIndex = parameter.getValue(listID + GPagingNavigator.STARTINDEX);
		if (!GStringUtils.isEmpty(strStartIndex)) {
			startIndex = Integer.parseInt(strStartIndex);
		}
		return startIndex;
	}

	private static int getListSize(String listID, GParameter parameter) {
		int listSize = GPagingNavigator.DEFAULT_LIST_SIZE;
		String strListSize = parameter.getValue(listID + GPagingNavigator.LISTSIZE);
		if (!GStringUtils.isEmpty(strListSize)) {
			listSize = Integer.parseInt(strListSize);
		}
		return listSize;
	}
}

