/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.ex.action;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.richview.utils.GRIAActionUtils;

/**
 * gef-ria-clientのアクションパラメターをハンドリングします.
 * 
 * @author yamashita
 * @since 2020/08/28
 * @version 20.9.0
 */
public class GRIAActionParameterHandler implements GActionParameterHandler {

	public GRIAActionParameterHandler() {
	}

	@Override
	public String extractCellData(GParameter parameter) {
		return GRIAActionUtils.extractCellData(parameter);
	}

	@Override
	public GListData extractListData(GParameter parameter, String listName) {
		return GRIAActionUtils.extractListData(parameter, listName);
	}

	@Override
	public GRowData extractRowData(GParameter parameter) {
		return GRIAActionUtils.extractRowData(parameter);
	}

	@Override
	public String getCellNameInActionId(GParameter parameter) {
		return GRIAActionUtils.getCellNameInActionId(parameter);
	}

	@Override
	public String getListNameInActionId(GParameter parameter) {
		return GRIAActionUtils.getListNameInActionId(parameter);
	}

	@Override
	public int getRowIndexInActionId(GParameter parameter) {
		return GRIAActionUtils.getRowIndexInActionId(parameter);
	}
}
