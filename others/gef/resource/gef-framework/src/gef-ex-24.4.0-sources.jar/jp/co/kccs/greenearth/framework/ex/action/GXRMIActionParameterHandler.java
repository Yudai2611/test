/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.ex.action;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.xrmi.utils.GXRMIActionUtils;

/**
 * gef-ria-clientのアクションパラメターをハンドリングします.
 * 
 * @author yamashita
 * @since 2020/08/28
 * @version 20.9.0
 */
public class GXRMIActionParameterHandler implements GActionParameterHandler {

	public GXRMIActionParameterHandler() {
	}

	@Override
	public String extractCellData(GParameter parameter) {
		return GXRMIActionUtils.extractCellData(parameter);
	}

	@Override
	public GListData extractListData(GParameter parameter, String listName) {
		return GXRMIActionUtils.extractListData(parameter, listName);
	}

	@Override
	public GRowData extractRowData(GParameter parameter) {
		return GXRMIActionUtils.extractRowData(parameter);
	}

	@Override
	public String getCellNameInActionId(GParameter parameter) {
		return GXRMIActionUtils.getCellNameInActionId(parameter);
	}

	@Override
	public String getListNameInActionId(GParameter parameter) {
		return GXRMIActionUtils.getListNameInActionId(parameter);
	}

	@Override
	public int getRowIndexInActionId(GParameter parameter) {
		return GXRMIActionUtils.getRowIndexInActionId(parameter);
	}
}
