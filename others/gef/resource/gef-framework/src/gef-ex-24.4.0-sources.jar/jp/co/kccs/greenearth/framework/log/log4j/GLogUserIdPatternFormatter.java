/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.log.log4j;

import org.apache.logging.log4j.core.LogEvent;
import org.springframework.beans.factory.BeanCreationException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.log.log4j.GLogPatternFormatter;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.session.GSession;

/**
 * ログにログインユーザ名を出力する{@link GLogPatternFormatter}クラスです.
 * 
 * @create 2022/03/31
 * @author oka
 * @since 22.3.0
 */
public class GLogUserIdPatternFormatter implements GLogPatternFormatter {

	private String pattern;

	/** useridのデフォルト値のプロパティファイル上でのキー名. */
	private static final String DEFAULT_USER_ID_KEY = "geframe.core.Log.DefaultUserId";

	/**
	 * コンストラクタ.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	public GLogUserIdPatternFormatter(String pattern) {
		this.pattern = pattern;
	}

	/**
	 * ユーザIDを出力します.
	 * 
	 * @create 2022/03/31
	 * @param event ログイベント、toAppendTo ログ出力文字列
	 * @author oka
	 * @since 22.3.0
	 */
	@Override
	public void format(final LogEvent event, final StringBuilder toAppendTo) {

		String userid = GFrameworkUtils.getProperty(DEFAULT_USER_ID_KEY, "GEFRAMEWORK");
		GUser user = getUser();
		if (user != null) {
			userid = user.getId();
		}
		toAppendTo.append(GStringUtils.nullToBlank(userid));
	}

	/**
	 * セッションを取得します.<br>
	 * 本メソッドがサーバ起動直後(BeanCreationExceptionを送出時)に実行された場合、nullを返します.<br>
	 * SpringによるGWebContextのインスタンスのライフサイクルは、HTTPのリクエスト単位です.<br>
	 * サーバ起動直後（HTTPリクエストを受信するまで）は、GWebContextインスタンスは生成されず、取得できません.<br>
	 * 
	 * @create 2022/03/31
	 * @return GSession
	 * @author oka
	 * @since 22.3.0
	 */
	private GSession getSession() {
		try {
			return GWebContext.getInstance().getSession();
		} catch (BeanCreationException e) {
			return null;
		}
	}

	/**
	 * GUserを取得します.
	 * 
	 * @create 2022/03/31
	 * @author oka
	 * @since 22.3.0
	 */
	private GUser getUser() {
		GSession session = getSession();
		if (session == null || session.isInvalid()) {
			return null;
		}
		return session.getLoginUser();
	}

	/**
	 * patternを取得します.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	public String getPattern() {
		return this.pattern;
	}
}
