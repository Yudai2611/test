package jp.co.kccs.greenearth.framework.fqecore;
/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * 設定ファイルのキーを格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public enum GFqePropertyKey {

	/** アプリケーションID **/
	APPLICATION_ID("geframe.fqecore.ApplicationId", "", true),

	/** レジストリキャシューモード */
	DATASOURCE_CACHE_MODE("geframe.fqecore.datasource.CacheMode", "none", false),

	/** データソースメタ情報ファイルの配置ディレクトリ **/
	DATASOURCE_BASEDIR("geframe.fqecore.datasource.Basedir", "", false),

	/** データソースロギング設定 **/
	DATASOURCE_SCANNING_MODE("geframe.fqecore.datasource.Scan.ErrorAction", "error", false),

	/** データ出力時のエンコード **/
	EXPORT_ENCODING("geframe.fqecore.export.Encoding", "UTF-8", false),

	/** データ出力時のエスケープ処理の有無 **/
	EXPORT_ESCAPE("geframe.fqecore.export.Escape", "disable", false),

	/** 出力ファイル名 **/
	EXPORT_FILE_NAME_DEFAULT("geframe.fqecore.export.FileName.Default", "", false),

	/** 出力条件保存名 **/
	HISTORY_CONDITION_NAME_DEFAULT("geframe.fqecore.history.ConditionName.Default", "", false),

	/** 日付フォーマット **/
	IMPORT_DATE_FORMAT("geframe.fqecore.import.filter.Format.Date", "", true),

	/** フィルターカラム最大数 **/
	IMPORT_FILTER_GROUP_FIELD_LIMIT_SIZE("geframe.fqecore.import.filter.group.field.LimitSize", "", false),

	/** フィルターグループ数の最大値 **/
	IMPORT_FILTER_GROUP_LIMIT_SIZE("geframe.fqecore.import.filter.group.LimitSize", "", false),

	/** 出力最大数 **/
	IMPORT_LIMIT_SIZE("geframe.fqecore.import.LimitSize.Default", "-1", false),

	/** 数字フォーマット **/
	IMPORT_NUMBER_FORMAT("geframe.fqecore.import.LimitSize.Default", "", true),

	/** ソートカラム最大数 **/
	IMPORT_SORT_LIMIT_SIZE("geframe.fqecore.import.sort.LimitSize", "", false);

	/** デフォルト値 **/
	String defaultValue;

	/** 必須項目であるかどうか **/
	boolean isRequired;

	/** キー **/
	String value;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @param value キー
	 * @author KCCS dhiaz
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	GFqePropertyKey(String value, String defaultValue, boolean isRequired) {
		this.value = value;
		this.defaultValue = defaultValue;
		this.isRequired = isRequired;
	}

	/**
	 * 設定ファイルのキーを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return キー
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String getValue() {
		return value;
	}

	/**
	 * 設定値を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 設定値
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public String getPropertyValue() {
		if (isRequired) {
			return GFrameworkUtils.getProperty(getValue());
		}
		return GFrameworkUtils.getProperty(getValue(), defaultValue);
	}
}
