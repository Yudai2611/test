/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.context;

/**
 * FQEのマルチコンテナー用の情報を保管するクラスです。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFqeContext {

	/** アプリID **/
	String APPLICATION_ID = "applicationId";
	/** ユーザーID **/
	String USER_ID = "userId";

	/**
	 * ユーザーIDを取得します。<br>
	 *
	 * @create 2023/10/25
	 * @return ユーザーID
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getUserId();

	/**
	 * アプリIDを取得します。<br>
	 *
	 * @create 2023/10/25
	 * @return アプリID
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getApplicationId();

}
