/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.context;

import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

/**
 * {@link HttpServletRequest}からコンテキスト為の情報を解凍します。<br>
 * {@link GFqeContextDataExtractorResolver}にスキャン出来る為、実装クラスには{@link FqeContextDataExtractor}を付けることは必要です。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFqeContextDataExtractor {

	/**
	 * {@link HttpServletRequest}の情報から検証して、サポート出来るかどうかを判断します。<br>
	 *
	 * @create 2023/10/25
	 * @param servletRequest リクエスト
	 * @return サポート出来るかどうか
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	boolean canHandle(HttpServletRequest servletRequest);

	/**
	 * {@link HttpServletRequest}からコンテキストが必要な情報を解凍します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Map<String, Object> extract(HttpServletRequest servletRequest);
}
