/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.context;

import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link HttpServletRequest}によって、最適な{@link GFqeContextDataExtractor}を選びます。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFqeContextDataExtractorResolver {

	/**
	 * {@link HttpServletRequest}によって、最適な{@link GFqeContextDataExtractor}を返します。<br>
	 *
	 * @create 2023/10/25
	 * @param httpServletRequest リクエスト
	 * @return 最適な {@link GFqeContextDataExtractor}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GFqeContextDataExtractor> resolve(HttpServletRequest httpServletRequest);

	/**
	 * DIから{@link GFqeContextDataExtractorResolver}の実装オブジェクトを取得します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static GFqeContextDataExtractorResolver getInstance() {
		return GFrameworkUtils.getComponent(GFqeContextDataExtractorResolver.class);
	}
}
