/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.context;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;

/**
 * {@inheritDoc}
 *
 * @see GFqeContextDataExtractorResolver
 */
@ScanConfiguration(
		modifiers = {
				@Modifier(
						isPublic = true
				)
		},
	scannedAnnotations = FqeContextDataExtractor.class,
	scannedAssignableTypes = GFqeContextDataExtractor.class
)
public class GFqeContextDataExtractorResolverImpl implements GFqeContextDataExtractorResolver {
	private List<GFqeContextDataExtractor> extractors = new ArrayList<>();
	private void loadContextProviders() {
		if (!extractors.isEmpty ()) {
			return;
		}
		GScanComponentService.getInstance().getScannedClasses(getClass())
			.stream()
			.map(clazz -> GObjectInstantiator.getInstance().newInstance(clazz))
			.forEach(object-> {
				object.ifPresent(o -> extractors.add((GFqeContextDataExtractor) o));
			});
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFqeContextDataExtractorResolver#resolve(HttpServletRequest) 
	 */
	@Override
	public Optional<GFqeContextDataExtractor> resolve(HttpServletRequest httpServletRequest) {
		loadContextProviders();
		for (GFqeContextDataExtractor extractor : extractors) {
			if (extractor.canHandle(httpServletRequest)) {
				return Optional.of(extractor);
			}
		}
		return Optional.empty();
	}
}
