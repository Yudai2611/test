/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.context;

import java.util.Map;
import java.util.Objects;

import jakarta.servlet.http.HttpServletRequest;

/**
 * {@link GFqeContext}を管理する為のクラスです。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public final class GFqeContextHolder {
	private static final ThreadLocal<GFqeContext> THREAD_LOCAL = new ThreadLocal<>();

	/**
	 * {@link GFqeContext}をの初期化処理をします.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static void init(HttpServletRequest servletRequest) {
		GFqeContextDataExtractorResolver.getInstance().resolve(servletRequest)
				.ifPresent (resolve -> THREAD_LOCAL.set(createContext(resolve.extract (servletRequest))));
	}

	/**
	 * {@link GFqeContext}を作成します.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static GFqeContext createContext(Map<String, Object> contextData) {
		String applicationId = Objects.requireNonNullElse(contextData.get(GFqeContext.APPLICATION_ID), "").toString();
		String userId = Objects.requireNonNullElse(contextData.get(GFqeContext.USER_ID), "").toString();
		return new GFqeContextImpl(applicationId, userId);
	}

	/**
	 * {@link GFqeContext}を取得します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static GFqeContext getContext() {
		return THREAD_LOCAL.get();
	}

	/**
	 * キャシューから、{@link GFqeContext}を削除します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static void release() {
		THREAD_LOCAL.remove();
	}
}
