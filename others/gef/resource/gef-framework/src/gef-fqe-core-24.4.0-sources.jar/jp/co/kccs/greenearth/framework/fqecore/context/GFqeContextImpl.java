/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.context;

/**
 * {@inheritDoc}
 *
 * @see GFqeContext
 */
public class GFqeContextImpl implements GFqeContext {
	private String userId;
	private String applicationId;
	public GFqeContextImpl(String applicationId, String userId) {
		this.userId = userId;
		this.applicationId = applicationId;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFqeContext#getUserId()
	 */
	@Override
	public String getUserId() {
		return userId;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFqeContext#getApplicationId()
	 */
	@Override
	public String getApplicationId() {
		return applicationId;
	}
}
