/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;

/**
 * データソースのカラムメタ情報を格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GAbstractDatasourceFieldMetadata implements GDatasourceFieldMetadata {

	/** データタイプ{@link GFieldDataType} **/
	private GFieldDataType dataType;

	/** フォーマット **/
	private String format;

	/** id **/
	private String id;

	/** ラベル名 **/
	private String label;

	/** ラベルid **/
	private String labelId;

	/** データソースメタ情報{@link GDatasourceMetadata} **/
	private GDatasourceMetadata<? extends GDatasourceType> parent;

	/** ソース元 **/
	private String src;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	GAbstractDatasourceFieldMetadata() {

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceFieldMetadata#getDataType()
	 */
	@Override
	public GFieldDataType getDataType() {
		return dataType;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceFieldMetadata#getFormat()
	 */
	@Override
	public String getFormat() {
		return format;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceFieldMetadata#getId()
	 */
	@Override
	public String getId() {
		return id;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceFieldMetadata#getLabel()
	 */
	@Override
	public String getLabel() {
		if (Objects.nonNull(getLabelId())) {
			return GMessageResources.getMessage(getLabelId(), GFrameworkContext.getInstance().getLocale());
		}
		return label;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceFieldMetadata#getLabelId()
	 */
	@Override
	public String getLabelId() {
		return labelId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceFieldMetadata#getParent()
	 */
	@Override
	public GDatasourceMetadata<?> getParent() {
		return parent;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceFieldMetadata#getSrc()
	 */
	@Override
	public String getSrc() {
		return src;
	}

	/**
	 * このフィールドが所属するデータソースメタ情報を設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param parent データソースメタ情報
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public void setParent(GDatasourceMetadata<?> parent) {
		this.parent = parent;
	}

	/**
	 * {@link GFieldDataType}を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param dataType {@link GFieldDataType}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	 void setDataType (GFieldDataType dataType) {
		this.dataType = dataType;
	}

	/**
	 * フォーマットを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param format フォーマット
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	 void setFormat (String format) {
		this.format = format;
	}

	/**
	 * idを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param id
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setId (String id) {
		this.id = id;
	}

	/**
	 * ラベル名を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param label　ラベル名
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	 void setLabel (String label) {
		this.label = label;
	}

	/**
	 * ラベルIDを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param labelId　ラベルID
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setLabelId (String labelId) {
		this.labelId = labelId;
	}

	/**
	 * ソース元を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param src ソース元
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setSrc (String src) {
		this.src = src;
	}
}
