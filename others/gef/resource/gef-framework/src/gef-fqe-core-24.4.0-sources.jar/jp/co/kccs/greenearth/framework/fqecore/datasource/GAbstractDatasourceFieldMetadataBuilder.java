/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * {@link GDatasourceFieldMetadata}を生成するためのビルダークラスです.<br>
 *
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public abstract class GAbstractDatasourceFieldMetadataBuilder implements GDatasourceFieldMetadataBuilder {

	/** データタイプ{@link GFieldDataType} */
	private GFieldDataType dataType;

	/** フォーマット **/
	private String format;

	/** id */
	private String id;

	/** ラベル名 */
	private String label;

	/** ラベルid **/
	private String labelId;

	/** ソース元 **/
	private String src;

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceFieldMetadata build() {
		GAbstractDatasourceFieldMetadata metadata = createMetadata ();
		metadata.setId (id);
		metadata.setLabel (label);
		metadata.setSrc (src);
		metadata.setFormat (format);
		metadata.setDataType (dataType);
		metadata.setLabelId (labelId);
		return metadata;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceFieldMetadataBuilder dataType(GFieldDataType dataType) {
		this.dataType = dataType;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceFieldMetadataBuilder format(String format) {
		this.format = format;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceFieldMetadataBuilder id(String id) {
		this.id = id;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceFieldMetadataBuilder label(String label) {
		this.label = label;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceFieldMetadataBuilder labelId(String labelId) {
		this.labelId = labelId;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceFieldMetadataBuilder src(String src) {
		this.src = src;
		return this;
	}

	/**
	 * {@link GAbstractDatasourceFieldMetadata}を生成します.<br>
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	protected abstract GAbstractDatasourceFieldMetadata createMetadata();
}
