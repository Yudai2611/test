/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;

/**
 * データソースメタ情報を格納します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GAbstractDatasourceMetadata<T extends GDatasourceType> implements GDatasourceMetadata<T> {

	/** アプリケーションID **/
	private String applicationId;

	/** 作成日時 **/
	private long creationTime;

	/** フィールド{@link GDatasourceFieldMetadata}のリスト **/
	private List<GDatasourceFieldMetadata> datasourceFields;

	/** id **/
	private String id;

	/** ラベル名 **/
	private String label;

	/** ラベルid **/
	private String labelId;

	/** 最終更新日時 **/
	private long lastModifiedTime;

	/** データ出力件数最大値 **/
	private long limitSize;

	/** ソース元 **/
	private String src;

	/** ソースタイプ **/
	private T srcType;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	GAbstractDatasourceMetadata() {

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getApplicationId()
	 */
	@Override
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata#getCreationTime()
	 */
	@Override
	public Long getCreationTime() {
		return creationTime;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getDatasourceFields()
	 */
	@Override
	public List<GDatasourceFieldMetadata> getDatasourceFields() {
		return Optional.ofNullable (datasourceFields).orElseGet (() -> new ArrayList<GDatasourceFieldMetadata> ());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getId()
	 */
	@Override
	public String getId() {
		return id;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getLabel()
	 */
	@Override
	public String getLabel() {
		if (getLabelId() != null) {
			return GMessageResources.getMessage(getLabelId(), GFrameworkContext.getInstance().getLocale());
		}
		return label;
	}

	@Override
	public Long getLastModifiedTime() {

		return lastModifiedTime;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getLabelId()
	 */
	@Override
	public String getLabelId() {
		return labelId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getLimitSize()
	 */
	@Override
	public long getLimitSize() {
		return limitSize;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getSrc()
	 */
	@Override
	public String getSrc() {
		return src;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadata#getSrcType()
	 */
	@Override
	public T getSrcType() {
		return srcType;
	}

	/**
	 * アプリケーションIdを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param applicationId アプリケーションId
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setApplicationId (String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * 作成日時を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param creationTime 作成日時
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setCreationTime (long creationTime) {
		this.creationTime = creationTime;
	}

	/**
	 * {@link GDatasourceFieldMetadata}のリストを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param datasourceFields {@link GDatasourceFieldMetadata}のリスト
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setDatasourceFields (List<GDatasourceFieldMetadata> datasourceFields) {
		this.datasourceFields = datasourceFields;
	}

	/**
	 * idを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param id
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setId (String id) {
		this.id = id;
	}

	/**
	 *  ラベル名を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param label ラベル名
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	 void setLabel (String label) {
		this.label = label;
	}

	/**
	 * ラベルIdを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param labelId ラベルId
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setLabelId (String labelId) {
		this.labelId = labelId;
	}

	/**
	 * 最終更新日時を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param lastModifiedTime 最終更新日時
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setLastModifiedTime (long lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	/**
	 * データ出力件数最大値を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param limitSize データ出力件数最大値
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setLimitSize (long limitSize) {
		this.limitSize = limitSize;
	}

	/**
	 * ソース元を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param src  ソース元
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setSrc (String src) {
		this.src = src;
	}

	/**
	 *  {@link GDatasourceType}を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param srcType {@link GDatasourceType}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	void setSrcType (T srcType) {
		this.srcType = srcType;
	}
}