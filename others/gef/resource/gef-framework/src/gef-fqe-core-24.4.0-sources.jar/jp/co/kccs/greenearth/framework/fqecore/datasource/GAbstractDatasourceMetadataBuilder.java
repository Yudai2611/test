/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.List;
import java.util.Optional;

/**
 * {@link GDatasourceMetadata}を生成するビルダークラスです.<br>
 * 
 * @create 2024/04/30
 * @param <T>
 * @author KCCS oka
 * @since 24.4.0
 */
public abstract class GAbstractDatasourceMetadataBuilder<T extends GDatasourceType> implements GDatasourceMetadataBuilder<T> {

	/** アプリケーションID **/
	private String applicationId;

	/** 作成日時 **/
	private long creationTime;

	/** フィールド{@link GDatasourceFieldMetadata}のリスト **/
	private List<GDatasourceFieldMetadata> datasourceFields;

	/** id **/
	private String id;

	/** ラベル名 **/
	private String label;

	/** ラベルid **/
	private String labelId;

	/** 最終更新日時 **/
	private long lastModifiedTime;

	/** データ出力件数最大値 **/
	private long limitSize;

	/** ソース元 **/
	private String src;

	/** ソースタイプ **/
	private GDatasourceType srcType;

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder applicationId(String applicationId) {
		this.applicationId = applicationId;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadata build() {
		GAbstractDatasourceMetadata metadata = createMetadata ();
		metadata.setId (id);
		metadata.setLabel (label);
		metadata.setSrc (src);
		metadata.setApplicationId (applicationId);
		metadata.setCreationTime (creationTime);
		metadata.setDatasourceFields (datasourceFields);
		metadata.setLastModifiedTime (lastModifiedTime);
		metadata.setLimitSize (limitSize);
		metadata.setSrcType (srcType);
		metadata.setLabelId (labelId);
		setMetadataForChild(metadata, metadata.getDatasourceFields());
		return metadata;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder creationTime(long creationTime) {
		this.creationTime = creationTime;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder datasourceFields(List<GDatasourceFieldMetadata> datasourceFields) {
		this.datasourceFields = datasourceFields;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder id(String id) {
		this.id = id;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder label(String label) {
		this.label = label;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder labelId(String labelId) {
		this.labelId = labelId;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder lastModifiedTime(long lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder limitSize(long limitSize) {
		this.limitSize = limitSize;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder src(String src) {
		this.src = src;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public GDatasourceMetadataBuilder srcType(GDatasourceType srcType) {
		this.srcType = (GEntityDatasourceType) srcType;
		return this;
	}

	/**
	 * {@link GAbstractDatasourceMetadata}を生成します.<br>
	 *
	 * @create 2024/04/30
	 * @return
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	protected abstract GAbstractDatasourceMetadata createMetadata();

	/**
	 * {@link GDatasourceMetadata}に{@link GDatasourceFieldMetadata}のリストを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param metadata
	 * @param datasourceFields
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	private void setMetadataForChild(GDatasourceMetadata metadata, List<GDatasourceFieldMetadata> datasourceFields) {
		Optional.ofNullable(datasourceFields)
			.ifPresent(data -> data.forEach(datasourceField -> ((GAbstractDatasourceFieldMetadata) datasourceField).setParent(metadata)));
	}
}
