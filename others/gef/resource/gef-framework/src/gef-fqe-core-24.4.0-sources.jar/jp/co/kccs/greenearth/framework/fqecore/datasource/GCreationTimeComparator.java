/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.Comparator;

/**
 * 作成日時で並び替えるComparatorです.
 * 
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public class GCreationTimeComparator implements Comparator<GDatasourceMetadata<? extends GDatasourceType>> {

	/**
	 * 作成日時で並び替えます.
	 * 
	 * @create 2024/04/30
	 * @see Comparator<GDatasourceMetadata<? extends
	 *      GDatasourceType>>#compare(jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata,
	 *      jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata)
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public int compare(GDatasourceMetadata<? extends GDatasourceType> o1, GDatasourceMetadata<? extends GDatasourceType> o2) {
		return o1.getCreationTime().compareTo(o2.getCreationTime());
	}
}
