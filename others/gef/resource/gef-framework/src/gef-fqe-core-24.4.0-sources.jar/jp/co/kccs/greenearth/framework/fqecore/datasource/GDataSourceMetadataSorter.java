/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.Comparator;
import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GDatasourceMetadata}を{@link Comparator}に従って並び替えます.
 * 
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public interface GDataSourceMetadataSorter {

	/**
	 * {@link GDatasourceMetadata}を並び替えます.<br>
	 * 
	 * @create 2024/04/30
	 * @param target ソート対象
	 * @param comparator {@link Comparator}
	 * @return 並び替え済みの{@link GDatasourceMetadata}のリスト
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public List<GDatasourceMetadata<? extends GDatasourceType>> sort(List<GDatasourceMetadata<? extends GDatasourceType>> target,
		Comparator<? super GDatasourceMetadata<? extends GDatasourceType>> comparator);

	/**
	 * インスタンスを生成します.<br>
	 * 
	 * @create 2024/04/30
	 * @return {@link GDataSourceMetadataSorter}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public static GDataSourceMetadataSorter getInstance() {
		return GFrameworkUtils.getComponent(GDataSourceMetadataSorter.class);
	}
}
