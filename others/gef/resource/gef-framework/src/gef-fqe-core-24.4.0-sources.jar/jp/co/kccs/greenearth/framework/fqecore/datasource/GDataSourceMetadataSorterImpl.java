/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.Comparator;
import java.util.List;

/**
 * {@link GDatasourceMetadata}を{@link Comparator}に従って並び替えます.<br>
 * 
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public class GDataSourceMetadataSorterImpl implements GDataSourceMetadataSorter {

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see jp.co.kccs.greenearth.framework.fqecore.datasource.GDataSourceMetadataSorter#sort(java.util.List,
	 *      java.util.Comparator)
	 *
	 */
	@Override
	public List<GDatasourceMetadata<? extends GDatasourceType>> sort(List<GDatasourceMetadata<? extends GDatasourceType>> target,
		Comparator<? super GDatasourceMetadata<? extends GDatasourceType>> comparator) {
		return target.stream().sorted(comparator).toList();
	}
}
