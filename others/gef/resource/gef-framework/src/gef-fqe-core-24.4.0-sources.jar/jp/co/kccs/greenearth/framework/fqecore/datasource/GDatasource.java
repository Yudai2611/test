/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.List;

/**
 * データソースを示すクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasource {
	
	/** データソースID **/
	String DATASOURCE_ID = GDatasourceMetadata.DATASOURCE_ID;
	
	/** 行 **/
	String ROWS = "rows";

	/**
	 * データソースフィールド{@link GDatasourceField}を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return データソースフィールド{@link GDatasourceField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GDatasourceRow> getRows();

	/**
	 * データソースIDを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return データソースメタ情報 {@link GDatasourceMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getId();

}
