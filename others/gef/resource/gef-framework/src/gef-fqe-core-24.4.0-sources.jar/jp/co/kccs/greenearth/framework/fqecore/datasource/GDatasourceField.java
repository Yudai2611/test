/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * データソースフィールドを示すクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceField {

	/** フィールID **/
	String FIELD_ID = GDatasourceFieldMetadata.FIELD_ID;

	/** 値 **/
	String VALUE = "value";

	/**
	 * フィールドIDを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getId();

	/**
	 * フィールドの値を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return フィールドの値
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	Object getValue();

}
