/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * データソースフィールドを示すクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceFieldImpl implements GDatasourceField {

	/** フィールドのメタデータ */
	private GDatasourceFieldMetadata datasourceFieldMetadata;

	/** フィールドの値 */
	private Object fieldValue;

	/**
	 * コンストラクタです. <br>
	 *
	 * @create 2023/10/25
	 * @param fieldMetadata フィールドのメタデータ
	 * @param fieldValue フィールドの値
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GDatasourceFieldImpl(GDatasourceFieldMetadata fieldMetadata, Object fieldValue) {
		this.datasourceFieldMetadata = fieldMetadata;
		this.fieldValue = fieldValue;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GDatasourceField#getId()
	 */
	@Override
	public String getId() {
		return datasourceFieldMetadata.getId();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GDatasourceField#getValue()
	 */
	@Override
	public Object getValue() {
		return fieldValue;
	}

}
