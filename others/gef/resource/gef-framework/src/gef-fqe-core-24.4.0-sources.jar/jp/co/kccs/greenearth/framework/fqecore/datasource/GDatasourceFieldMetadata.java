/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * データソースのカラムメタ情報を格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceFieldMetadata {

	/** フォーマット */
	String FORMAT = "format";

	/** フィールドId */
	String FIELD_ID = "fieldId";

	/** ソース元 */
	String SRC = "src";

	/** データタイプ */
	String DATA_TYPE = "dataType";

	/** ラベル名 */
	String LABEL = "label";

	/** ラベルId */
	String LABEL_ID = "labelId";

	/**
	 * カラムのデータタイプ{@link GFieldDataType}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return カラムのデータタイプ{@link GFieldDataType}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GFieldDataType getDataType();

	/**
	 * フォーマットを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フォーマット
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFormat();

	/**
	 * idを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return id
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getId();

	/**
	 * ラベル名を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ラベル名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getLabel();

	/**
	 * ラベルidを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ラベルid
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getLabelId();

	/**
	 * データソースメタ情報{@link GDatasourceMetadata}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースメタ情報{@link GDatasourceMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasourceMetadata<? extends GDatasourceType> getParent();

	/**
	 * ソース元を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return ソース元
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getSrc();
}
