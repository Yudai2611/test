/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * {@link GDatasourceFieldMetadata}を生成するためのビルダークラスです.<br>
 *
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public interface GDatasourceFieldMetadataBuilder {

	/**
	 * 生成した{@link GDatasourceFieldMetadata}を取得します.<br>
	 *
	 * @create 2024/04/30
	 * @return {@link GDatasourceFieldMetadata}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceFieldMetadata build();

	/**
	 * {@link GFieldDataType}を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param dataType
	 * @return {@link GDatasourceFieldMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceFieldMetadataBuilder dataType(GFieldDataType dataType);

	/**
	 * フォーマット文字列を設定します.<br>
	 *
	 * @param format
	 * @return {@link GDatasourceFieldMetadataBuilder}
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceFieldMetadataBuilder format(String format);

	/**
	 * idを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param id
	 * @return {@link GDatasourceFieldMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceFieldMetadataBuilder id(String id);

	/**
	 * ラベル名を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param label
	 * @return {@link GDatasourceFieldMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceFieldMetadataBuilder label(String label);

	/**
	 * ラベルIDを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param labelId
	 * @return {@link GDatasourceFieldMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceFieldMetadataBuilder labelId(String labelId);

	/**
	 * ソース元を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param src
	 * @return
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceFieldMetadataBuilder src(String src);
}
