/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.List;

/**
 * データソースを示すクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceImpl implements GDatasource {

	/** データソースメタ情報{@link GDatasourceMetadata} */
	private GDatasourceMetadata<? extends GDatasourceType> metadata;

	/** データソースフィールド{@link GDatasourceField}のリスト */
	private List<GDatasourceRow> datasourceRows;

	/**
	 * コンストラクタです. <br>
	 *
	 * @create 2023/10/25
	 * @param metadata データソースメタ情報{@link GDatasourceMetadata}
	 * @param datasourceRows データソースの行{@link GDatasourceRow}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GDatasourceImpl(GDatasourceMetadata<? extends GDatasourceType> metadata, List<GDatasourceRow> datasourceRows) {
		this.metadata = metadata;
		this.datasourceRows = datasourceRows;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GDatasource#getId()
	 */
	@Override
	public String getId() {
		return metadata.getId();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GDatasource#getRows()
	 */
	@Override
	public List<GDatasourceRow> getRows() {
		return datasourceRows;
	}

}
