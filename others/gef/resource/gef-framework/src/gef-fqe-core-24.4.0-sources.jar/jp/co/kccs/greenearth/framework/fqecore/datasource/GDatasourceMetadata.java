/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.List;

/**
 * データソースメタ情報を格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceMetadata<T extends GDatasourceType> {

	/** データソースId */
	String DATASOURCE_ID = "datasourceId";

	/** フィールド */
	String FIELDS = "fields";

	/** ラベル */
	String LABEL = "label";

	/** ラベルId */
	String LABEL_ID = "labelId";

	/** データ最大取得件数 */
	String LIMIT_SIZE = "limitSize";

	/** ソース元 */
	String SRC = "src";

	/** ソースタイプ */
	String SRC_TYPE = "srcType";

	/**
	 * アプリケーションIDを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * 作成日時を取得します.<br>
	 *
	 * @create 2024/04/30
	 * @return 作成日時
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	Long getCreationTime();

	/**
	 * フィールド{@link GDatasourceFieldMetadata}のリストを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GDatasourceFieldMetadata> getDatasourceFields();

	/**
	 * idを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return id
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getId();

	/**
	 * ラベル名を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return ラベル名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getLabel();

	/**
	 * ラベルIDを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return ラベルID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getLabelId();

	/**
	 * 最終更新日時を取得します.<br>
	 *
	 * @create 2024/04/30
	 * @return 最終更新日時
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	Long getLastModifiedTime();

	/**
	 * データ出力最大件数を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return データ出力最大件数
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	long getLimitSize();

	/**
	 * ソース元を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return ソース元
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getSrc();

	/**
	 * ソースタイプを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return ソースタイプ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	T getSrcType();
}
