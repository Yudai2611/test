/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.List;

/**
 * {@link GDatasourceMetadata}を生成するビルダークラスです.<br>
 * 
 * @create 2024/04/30
 * @param <T>
 * @author KCCS oka
 * @since 24.4.0
 */
public interface GDatasourceMetadataBuilder<T> {

	/**
	 * アプリケーションIDを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param applicationId アプリケーションID
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder applicationId(String applicationId);

	/**
	 * 生成した{@link GAbstractDatasourceMetadata}を取得します.<br>
	 *
	 * @create 2024/04/30
	 * @return {@link GAbstractDatasourceMetadata}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadata build();

	/**
	 * 作成日時を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param creationTime 作成日時
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder creationTime(long creationTime);

	/**
	 * フィールド{@link GDatasourceFieldMetadata}のリストを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param datasourceFields
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder datasourceFields(List<GDatasourceFieldMetadata> datasourceFields);

	/**
	 * idを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param id
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder id(String id);

	/**
	 * ラベル名を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param label ラベル名
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder label(String label);

	/**
	 * ラベルidを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param labelId ラベルid
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder labelId(String labelId);

	/**
	 * 最終更新日時を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param lastModifiedTime 最終更新日時
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder lastModifiedTime(long lastModifiedTime);

	/**
	 * データ出力件数最大値を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param limitSize データ出力件数最大値
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder limitSize(long limitSize);

	/**
	 * ソース元を設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param src ソース元
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder src(String src);

	/**
	 * ソースタイプを設定します.<br>
	 *
	 * @create 2024/04/30
	 * @param srcType ソースタイプ
	 * @return {@link GDatasourceMetadataBuilder}
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	public GDatasourceMetadataBuilder srcType(T srcType);
}