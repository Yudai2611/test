/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.List;

/**
 * {@link GDatasourceField}を集約してデータソースの行の情報を保持するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceRow {

	/** フィールドリスト **/
	String FIELDS = "fields";

	/**
	 * {@link GDatasourceField}のリストを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return {@link GDatasourceField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GDatasourceField> getFields();
}
