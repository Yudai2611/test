/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.List;

/**
 * {@link GDatasourceField}を集約してデータソースの行の情報を保持するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceRowImpl implements GDatasourceRow {
	
	/** {@link GDatasourceField}のリスト */
    private List<GDatasourceField> datasourceFields;

    /**
     * コンストラクタです. <br>
     * 
     * @create 2023/10/25
     * @param datasourceFields {@link GDatasourceField}のリスト
     * @author KCCS dhiaz
     * @since 23.10.0
     */
    public GDatasourceRowImpl(List<GDatasourceField> datasourceFields) {
        this.datasourceFields = datasourceFields;
    }

    /**
     * {@inheritDoc}
     * 
     * @see GDatasourceRow#getFields()
     */
    @Override
    public List<GDatasourceField> getFields() {
        return datasourceFields;
    }
}
