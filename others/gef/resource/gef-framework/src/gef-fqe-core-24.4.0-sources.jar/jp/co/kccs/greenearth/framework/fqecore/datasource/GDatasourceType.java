/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * データソースタイプを格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceType {

	/**
	 * データソースタイプ {@link GDatasourceType}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースタイプ {@link GDatasourceType}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getValue();
}
