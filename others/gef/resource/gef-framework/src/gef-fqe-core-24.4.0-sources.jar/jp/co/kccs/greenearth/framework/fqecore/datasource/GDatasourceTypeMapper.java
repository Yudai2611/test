/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * データソースの種類をマッピングするクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceTypeMapper {

	/**
	 * データソースのタイプを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceType
	 * @return {@link GDatasourceType}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasourceType get(String datasourceType);

	/**
	 * データソースのタイプ一覧を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return {@link GDatasourceType}のマップ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	Map<String, GDatasourceType> getDatasourceTypes();

	/**
	 * {@link GDatasourceTypeMapper}のインスタンス生成をするファクトリークラスです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	class Factory {

		/**
		 * {@link GDatasourceTypeMapper}のインスタンスを生成します. <br>
		 * 
		 * @create 2023/10/25
		 * @return {@link GDatasourceTypeMapper}のインスタンス
		 * @author KCCS dhiaz
		 * @since 23.10.0
		 */
		public static GDatasourceTypeMapper getInstance() {
			return GFrameworkUtils.getComponent(GDatasourceTypeMapper.class);
		}
	}
}
