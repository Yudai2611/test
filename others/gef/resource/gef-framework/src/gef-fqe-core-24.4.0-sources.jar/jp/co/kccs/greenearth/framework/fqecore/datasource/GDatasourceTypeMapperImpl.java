/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */


package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.Map;

/**
 * データソースの種類をマッピングするクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceTypeMapperImpl implements GDatasourceTypeMapper {

	/** {@link GDatasourceType}のマップ */
	private Map<String, GDatasourceType> datasourceTypeMap;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceTypeMap
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GDatasourceTypeMapperImpl(Map<String, GDatasourceType> datasourceTypeMap) {
		this.datasourceTypeMap = datasourceTypeMap;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceTypeMapper#get(java.lang.String)
	 */
	@Override
	public GDatasourceType get(String datasourceType) {
		return datasourceTypeMap.get(datasourceType);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceTypeMapper#getDatasourceTypes()
	 */
	@Override
	public Map<String, GDatasourceType> getDatasourceTypes() {
		return datasourceTypeMap;
	}

}
