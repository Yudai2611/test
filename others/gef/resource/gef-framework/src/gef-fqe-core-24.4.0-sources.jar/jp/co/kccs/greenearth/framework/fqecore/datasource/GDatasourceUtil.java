/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import static java.util.Objects.isNull;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.collection.GListMapImpl;

/**
 * データソースメタ情報が記述されたxmlファイルを解釈するクラスです. <br>
 *
 * @author KCCS dhiaz
 * @create 2023/10/25
 * @since 23.10.0
 */
public class GDatasourceUtil {

	/** xmlファイルの読み取りモードのデフォルト値 */
	public static final String DEFAULT_SCAN_MODE = "error";

	/**
	 * ノードの属性値を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @param attributeName 属性
	 * @param element ノード {@link Element}
	 * @param required 必須項目の有無
	 * @return 属性値
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static String getNodeAttribute(String attributeName, Element element, boolean required) {
		if (element.hasAttribute(attributeName)) {
			return element.getAttribute(attributeName);
		}
		if (required) {
			throw new GFrameworkException(String.format("Node %s attribute is missing", attributeName));
		}
		return null;
	}

	/**
	 * XMLファイルのpathからファイル名を取得します. <br>
	 *
	 * @param path XMLファイルのpath
	 * @return ファイル名
	 * @author KCCS dhiaz
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	public static String parseDatasourceIdFromPath(String path) {
		
		if (isNull(path)) {
			return "";
		}
		
		String[] extracted = path.split("/");
		String entityId = extracted[extracted.length - 1];
		extracted = entityId.split("\\\\");
		entityId = extracted[extracted.length - 1];
		String[] extractedEntityId = entityId.split("\\.");
		return extractedEntityId[0];
	}

	/**
	 * データソースフィールド{@link GDatasourceField}の値リストをマップに変換します. <br>
	 *
	 * @param datasourceFields データソースフィールド{@link GDatasourceField}の値リスト
	 * @return データソースフィールド{@link GDatasourceField}の値マップ
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static Map<String, Object> toFieldMap(List<GDatasourceField> datasourceFields) {
		Map<String, Object> datasourceFieldMap = new GListMapImpl<>();
		
		Optional.ofNullable(datasourceFields)
			.ifPresent(data -> data.forEach(datasourceField -> datasourceFieldMap.put(datasourceField.getId(), datasourceField.getValue())));
		return datasourceFieldMap;
	}

	/**
	 * データソースフィールドメタ情報{@link GDatasourceField}のリストをマップに変換します. <br>
	 *
	 * @param datasourceFieldMetadatas
	 *            データソースフィールドメタ情報{@link GDatasourceField}のリスト
	 * @return datasourceFieldMetadataMap
	 *         データソースフィールドメタ情報{@link GDatasourceField}のマップ
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static Map<String, GDatasourceFieldMetadata> toFieldMetadataMap(List<GDatasourceFieldMetadata> datasourceFieldMetadatas) {
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap = new GListMapImpl<>();
		Optional.ofNullable (datasourceFieldMetadatas)
				.ifPresent (data -> data.forEach (datasourceField -> datasourceFieldMetadataMap.put(datasourceField.getId(), datasourceField)));
		return datasourceFieldMetadataMap;
	}

	/**
	 * ノードがエレメントノードであるか確認します. <br>
	 *
	 * @create 2023/10/25
	 * @param node {@link Node}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static void validateNodeTypeIsElement(Node node) {
		if (node.getNodeType() != Node.ELEMENT_NODE) {
			throw new GFrameworkException("Xml node is not an element type");
		}
	}
}
