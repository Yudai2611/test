/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * データソースのカラムのメタ情報を格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GEntityDatasourceFieldMetadata extends GAbstractDatasourceFieldMetadata {
}
