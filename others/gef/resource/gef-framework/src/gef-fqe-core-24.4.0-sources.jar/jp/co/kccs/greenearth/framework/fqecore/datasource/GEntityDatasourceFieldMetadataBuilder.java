/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * {@link GEntityDatasourceFieldMetadata}を生成するビルダークラスです.<br>
 * 
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public class GEntityDatasourceFieldMetadataBuilder extends GAbstractDatasourceFieldMetadataBuilder {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	protected GAbstractDatasourceFieldMetadata createMetadata () {
		return new GEntityDatasourceFieldMetadata ();
	}
}
