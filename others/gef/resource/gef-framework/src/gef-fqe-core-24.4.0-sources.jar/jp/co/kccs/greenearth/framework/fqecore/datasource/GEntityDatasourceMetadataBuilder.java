/*
 *  Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * {@link GEntityDatasourceMetadata}を生成するビルダークラスです.<br>
 * 
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public class GEntityDatasourceMetadataBuilder extends GAbstractDatasourceMetadataBuilder {

	/**
	 * {@link GAbstractDatasourceMetadata}を生成します.<br>
	 *
	 * @return
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	protected GAbstractDatasourceMetadata createMetadata () {
		return new GEntityDatasourceMetadata ();
	}
}
