/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * <code>ENTITY</code>のデータソースタイプを示すます. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GEntityDatasourceType implements GDatasourceType {

	/** 値 **/
	private String value;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GEntityDatasourceType() {
		this.value = "ENTITY";
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceType#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}
}
