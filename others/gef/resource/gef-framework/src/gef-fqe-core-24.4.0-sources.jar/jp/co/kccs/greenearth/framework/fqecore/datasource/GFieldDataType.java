/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

/**
 * フィールドのデータ型を示します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public enum GFieldDataType {

	/** 日付型 **/
	DATE("date"),
	/** 数値型 **/
	NUMERIC("numeric"),
	/** 文字列型 **/
	STRING("string");

	/** データ型 **/
	String value;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param value データ型
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GFieldDataType(String value) {
		this.value = value;
	}

	/**
	 * データタイプ [{@link GFieldDataType}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param dataType データ型
	 * @return データタイプ [{@link GFieldDataType}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GFieldDataType getDataType(String dataType) {
		if (GFieldDataType.STRING.getValue().equalsIgnoreCase(dataType)) {
			return GFieldDataType.STRING;
		} else if (GFieldDataType.NUMERIC.getValue().equalsIgnoreCase(dataType)) {
			return GFieldDataType.NUMERIC;
		} else if (GFieldDataType.DATE.getValue().equalsIgnoreCase(dataType)) {
			return GFieldDataType.DATE;
		}
		return null;
	}

	/**
	 * データ型を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データ型
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public String getValue() {
		return value;
	}

}
