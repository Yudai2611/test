/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource;

import java.util.Comparator;

/**
 * {@link GDatasourceMetadata}のidで並び替える{@link Comparator}です.<br>
 * 
 * @create 2024/04/30
 * @author KCCS oka
 * @since 24.4.0
 */
public class GIdComparator implements Comparator<GDatasourceMetadata<? extends GDatasourceType>> {

	/**
	 * {@link GDatasourceMetadata}を並び替えます.<br>
	 * 
	 * @create 2024/04/30
	 * @see Comparator<GDatasourceMetadata<? extends
	 *      GDatasourceType>>#compare(jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata,
	 *      jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata)
	 * @param o1
	 * @param o2
	 * @return 並び替えた{@link GDatasourceMetadata}のリスト
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	@Override
	public int compare(GDatasourceMetadata<? extends GDatasourceType> o1, GDatasourceMetadata<? extends GDatasourceType> o2) {
		return o1.getId().compareTo(o2.getId());
	}
}
