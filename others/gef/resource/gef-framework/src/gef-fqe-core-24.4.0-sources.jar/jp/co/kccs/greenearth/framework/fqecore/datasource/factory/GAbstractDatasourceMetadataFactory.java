/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource.factory;

import static java.lang.String.format;
import static java.nio.file.Files.readAttributes;
import static java.util.Objects.nonNull;
import static java.util.Objects.requireNonNull;
import static jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil.getNodeAttribute;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Objects;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil;

/**
 * データソースメタ情報が記載されているXMLを解析するクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GAbstractDatasourceMetadataFactory<T extends GDatasourceMetadata<? extends GDatasourceType>, Y extends GDatasourceType>
	implements GDatasourceMetadataFactory<T> {

	/** データソースタイプ */
	protected Y datasourceType;
	/** フィールドノード */
	protected final static String DATASOURCES_DATASOURCE_FIELD_NODE = "field";
	/** フォーマット属性 */
	protected final static String DATASOURCES_DATASOURCE_FIELD_NODE_FORMAT_ATTRIBUTE = "format";
	/** id属性 */
	protected final static String DATASOURCES_DATASOURCE_FIELD_NODE_ID_ATTRIBUTE = "id";
	/** ラベル属性 */
	protected final static String DATASOURCES_DATASOURCE_FIELD_NODE_LABEL_ATTRIBUTE = "label";
	/** ラベルid属性 */
	protected final static String DATASOURCES_DATASOURCE_FIELD_NODE_LABEL_ID_ATTRIBUTE = "label-id";
	/** タイプ属性 */
	protected final static String DATASOURCES_DATASOURCE_FIELD_NODE_TYPE_ATTRIBUTE = "type";
	/** ソース属性 */
	protected final static String DATASOURCES_DATASOURCE_FIELD_NODE_SRC_ATTRIBUTE = "src";
	/** アプリケーションid属性 */
	protected final static String DATASOURCES_DATASOURCE_NODE_APPLICATION_ID_ATTRIBUTE = "application-id";
	/** id属性 */
	protected final static String DATASOURCES_DATASOURCE_NODE_ID_ATTRIBUTE = "id";
	/** ラベル属性 */
	protected final static String DATASOURCES_DATASOURCE_NODE_LABEL_ATTRIBUTE = "label";
	/** ラベルid属性 */
	protected final static String DATASOURCES_DATASOURCE_NODE_LABEL_ID_ATTRIBUTE = "label-id";
	/** 出力データ最大値属性 */
	protected final static String DATASOURCES_DATASOURCE_NODE_READ_MAX_SIZE_ATTRIBUTE = "limit-size";
	/** ソース属性 */
	protected final static String DATASOURCES_DATASOURCE_NODE_SRC_ATTRIBUTE = "src";
	/** ソースタイプ属性 */
	protected final static String DATASOURCES_DATASOURCE_NODE_SRC_TYPE_ATTRIBUTE = "src-type";

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataFactory#create(java.lang.String)
	 */
	@Override
	public T create(String datasourceId) {
		requireNonNull(datasourceId, "Datasource id cannot be null.");
		if (canParse(datasourceId)) {
			return createInternal(getDatasourceMetadataNode(datasourceId));
		}
		return null;
	}


	/**
	 * xmlファイルからデータソースメタ情報を生成します. <br>
	 * 
	 * @param datasourceNode
	 * @return データソースメタ情報
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected abstract T createInternal(Element datasourceNode);

	/**
	 * xmlファイルからデータソースメタ情報が読込可能であるか、判定します. <br>
	 * 
	 * @param datasourceId データソースID
	 * @return 真偽値：データソースメタ情報が読込可能であるか
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private boolean canParse(String datasourceId) {
		Element datasourceNode = null;
		try {
			datasourceNode = getDatasourceMetadataNode(datasourceId);
		} catch (GFrameworkException e) {
			throw new GFrameworkException(format("Error while parsing datasource (%s).", datasourceId));
		}
		String datasourceSrcType = getNodeAttribute(DATASOURCES_DATASOURCE_NODE_SRC_TYPE_ATTRIBUTE, datasourceNode, true);
		if (nonNull(datasourceType)) {
			return Objects.equals(datasourceSrcType, datasourceType.getValue());
		} else {
			throw new GFrameworkException("Datasource type cannot be null.");
		}
	}

	/**
	 * データソース定義XMLのファイルURLを取得します.<br>
	 * 
	 * 
	 * @create 2024/04/30
	 * @param datasourceId
	 * @return URL
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	private URL createDatasourceFileUrl(String datasourceId) {
		return GFileUtils.createURL(format("%s/%s.%s", getDatasourceDirectory(), datasourceId, "xml"));
	}
	
	/**
	 * データソースxml内のrootノードを取得します. <br>
	 * 
	 * @param datasourceId
	 * @return rootノード
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private Element getDatasourceMetadataNode(String datasourceId) {
		Element datasourceElement = null;
		try {
			datasourceElement = openDatasourceFile(datasourceId).getDocumentElement();
		} catch (ParserConfigurationException | IOException | SAXException e) {
			throw new GFrameworkException(format("Error while parsing datasource (%s)", datasourceId));
		}
		validateDatasourceId(datasourceElement, datasourceId);
		return datasourceElement;
	}

	/**
	 * データソースxmlのデフォルト配置ディレクトリを取得します. <br>
	 * 
	 * @return ディレクトリ
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String getDatasourceDirectory() {
		return GFqePropertyKey.DATASOURCE_BASEDIR.getPropertyValue();
	}

	/**
	 * xmlファイルを読込みます. <br>
	 *
	 * @create 2023/10/25
	 * @param datasourceId 開きたいのデータソースのID
	 * @return xmlドキュメント {@link Document}
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private Document openDatasourceFile(String datasourceId) throws ParserConfigurationException, IOException, SAXException {
		InputStream inputStream = null;
		try {
			inputStream = createDatasourceFileUrl(datasourceId).openStream();
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			return db.parse(inputStream);
		} catch (IllegalArgumentException e) {
			throw new GFrameworkException(format("File with name %s is not exist.", datasourceId), e);
		} finally {
			if (nonNull(inputStream)) {
				inputStream.close();
			}
		}
	}

	/**
	 * 読込んだXMLファイルがデータソースメタ情報ファイルとして適切か、判定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceElement
	 * @param filePath
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private void validateDatasourceId(Element datasourceElement, String filePath) {
		String fileName = GDatasourceUtil.parseDatasourceIdFromPath(filePath);
		String datasourceId = getNodeAttribute(DATASOURCES_DATASOURCE_NODE_ID_ATTRIBUTE, datasourceElement, true);
		if (!Objects.equals(datasourceId, fileName)) {
			throw new GFrameworkException(format("Datasource id(%s) should be the same as file name(%s)", datasourceId, fileName));
		}
	}

}
