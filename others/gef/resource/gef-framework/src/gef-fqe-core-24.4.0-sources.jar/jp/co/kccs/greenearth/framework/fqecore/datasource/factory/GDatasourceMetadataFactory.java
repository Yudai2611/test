/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource.factory;

import static java.util.Objects.isNull;
import static java.util.Optional.ofNullable;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceTypeMapper;

/**
 * データソースメタ情報が記載されているXMLを解析するクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceMetadataFactory<T extends GDatasourceMetadata<? extends GDatasourceType>> {

	/**
	 * XMLファイルを解析します. <br>
	 *
	 * @create 2023/10/25
	 * @param datasourceId 作成されたいのデータソースID
	 * @return 解析結果
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	T create(String datasourceId);

	/**
	 * {@link GDatasourceMetadata}を生成するファクトリークラスです. <br>
	 * 
	 * @author KCCS dhiaz
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	class Factory {

		/** データソースメタ情報一覧 */
		private static Map<Class<GDatasourceType>, GDatasourceMetadataFactory<? extends GDatasourceMetadata<?>>> datasourceMetadataFactoryMap;
		/** データソースタイプ一覧 */
		private static GDatasourceTypeMapper datasourceTypeMapper;

		/**
		 * コンストラクターです. <br>
		 * 
		 * @param datasourceTypeMapper データソースタイプ一覧
		 * @param datasourceMetadataFactoryMap データソースメタ情報一覧
		 * @create 2023/10/25
		 * @author KCCS dhiaz
		 * @since 23.10.0
		 */
		public Factory(GDatasourceTypeMapper datasourceTypeMapper,
						Map<Class<GDatasourceType>, GDatasourceMetadataFactory<? extends GDatasourceMetadata<?>>> datasourceMetadataFactoryMap) {
			if (isNull(datasourceTypeMapper) || isNull(datasourceMetadataFactoryMap)) {
				throw new GFrameworkException(GDatasourceMetadataFactory.Factory.class + " has not been initialized.");
			}
			Factory.datasourceTypeMapper = datasourceTypeMapper;
			Factory.datasourceMetadataFactoryMap = datasourceMetadataFactoryMap;
		}

		/**
		 * データソースメタ情報 {@link GDatasourceMetadata}を作成します. <br>
		 * 
		 * @param datasourceId データソースID
		 * @return データソースメタ情報 {@link GDatasourceMetadata}
		 * @throws ParserConfigurationException
		 * @throws IOException
		 * @throws SAXException
		 * @create 2023/10/25
		 * @author KCCS dhiaz
		 * @since 23.10.0
		 */
		public static GDatasourceMetadata<?> create(String datasourceId) {
			final String id = Objects.requireNonNull(datasourceId, "Datasource id cannot be null.");
			return ofNullable(datasourceTypeMapper.getDatasourceTypes().entrySet().stream()
				.filter(mapper -> ofNullable(datasourceMetadataFactoryMap.get(mapper.getValue().getClass())).isPresent())
				.filter(mapper -> ofNullable(datasourceMetadataFactoryMap.get(mapper.getValue().getClass()).create(id)).isPresent())
				.findFirst().map(mapper -> datasourceMetadataFactoryMap.get(mapper.getValue().getClass()).create(id)).get())
					.orElseThrow(() -> new GFrameworkException("No Suitable datasource factory found for this datasource(" + id + ")."));
		}
	}
}
