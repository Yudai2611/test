/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.datasource.factory;

import static jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil.getNodeAttribute;
import static jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil.validateNodeTypeIsElement;
import static java.util.Optional.ofNullable;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GEntityDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GFieldDataType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GEntityDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GEntityDatasourceFieldMetadataBuilder;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GEntityDatasourceMetadataBuilder;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import jp.co.kccs.greenearth.commons.GFrameworkException;

/**
 * データソースメタ情報が記載されているXMLを解析するクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GEntityDatasourceMetadataFactory extends GAbstractDatasourceMetadataFactory<GEntityDatasourceMetadata, GEntityDatasourceType> {

	/**
	 * デフォルトコンストラクタです. <br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private GEntityDatasourceMetadataFactory() {
		this.datasourceType = new GEntityDatasourceType();
	}

	/**
	 * フィールドノードを解析します. <br>
	 *
	 * @create 2023/10/25
	 * @param fieldNode フィールドノード {@link Element}
	 * @return 解析結果 {@link GDatasourceFieldMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected GDatasourceFieldMetadata createField(Element fieldNode) {

		String fieldType = getNodeAttribute(DATASOURCES_DATASOURCE_FIELD_NODE_TYPE_ATTRIBUTE, fieldNode, true);
		GFieldDataType dataType = GFieldDataType.getDataType(fieldType);

		return ofNullable(dataType).map(data -> {
			return new GEntityDatasourceFieldMetadataBuilder ()
				.id(getNodeAttribute(DATASOURCES_DATASOURCE_FIELD_NODE_ID_ATTRIBUTE, fieldNode, true))
				.label(getNodeAttribute(DATASOURCES_DATASOURCE_FIELD_NODE_LABEL_ATTRIBUTE, fieldNode, false))
				.src(getNodeAttribute(DATASOURCES_DATASOURCE_FIELD_NODE_SRC_ATTRIBUTE, fieldNode, true))
				.format(getNodeAttribute(DATASOURCES_DATASOURCE_FIELD_NODE_FORMAT_ATTRIBUTE, fieldNode, false))
				.labelId(getNodeAttribute(DATASOURCES_DATASOURCE_FIELD_NODE_LABEL_ID_ATTRIBUTE, fieldNode, false)).dataType(dataType)
				.build();
		}).orElseThrow(() -> new GFrameworkException(String.format("Field data type %s is not compatible", fieldType)));
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractDatasourceMetadataFactory#createInternal(Element)
	 */
	protected GEntityDatasourceMetadata createInternal(Element datasourceNode) {

		String datasourceId = getNodeAttribute(DATASOURCES_DATASOURCE_NODE_ID_ATTRIBUTE, datasourceNode, true);
		return (GEntityDatasourceMetadata) new GEntityDatasourceMetadataBuilder ().id(datasourceId)
			.applicationId(getNodeAttribute(DATASOURCES_DATASOURCE_NODE_APPLICATION_ID_ATTRIBUTE, datasourceNode, true))
			.srcType(datasourceType).label(getNodeAttribute(DATASOURCES_DATASOURCE_NODE_LABEL_ATTRIBUTE, datasourceNode, false))
			.labelId(getNodeAttribute(DATASOURCES_DATASOURCE_NODE_LABEL_ID_ATTRIBUTE, datasourceNode, false))
			.src(getNodeAttribute(DATASOURCES_DATASOURCE_NODE_SRC_ATTRIBUTE, datasourceNode, true))
			.limitSize(parseLong(getNodeAttribute(DATASOURCES_DATASOURCE_NODE_READ_MAX_SIZE_ATTRIBUTE, datasourceNode, false)))
			.datasourceFields(createFieldMetadataList(datasourceNode.getElementsByTagName(DATASOURCES_DATASOURCE_FIELD_NODE)))
			.build();
	}

	/**
	 * {@link NodeList}から{@link GDatasourceFieldMetadata}のリストを作成します.<br>
	 *
	 * @create 2024/04/30
	 * @param datasourceFields
	 * @return {@link GDatasourceFieldMetadata}のリスト
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	private List<GDatasourceFieldMetadata> createFieldMetadataList(NodeList datasourceFields) {
		if (datasourceFields.getLength() == 0) {
			return new ArrayList<GDatasourceFieldMetadata>();
		}
		return IntStream.range(0, datasourceFields.getLength()).mapToObj(datasourceFields::item).map(node -> {
			validateNodeTypeIsElement(node);
			return createField((Element) node);
		}).toList();
	}

	/**
	 * 数値を{@link String}から{@link long}へ変換します.<br>
	 * 
	 * @create 2024/04/30
	 * @param number {@link String} 型数値
	 * @return {@link}型数値
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	private long parseLong(String number) {
		return Long.parseLong(ofNullable(number).orElse("-1"));
	}

}
