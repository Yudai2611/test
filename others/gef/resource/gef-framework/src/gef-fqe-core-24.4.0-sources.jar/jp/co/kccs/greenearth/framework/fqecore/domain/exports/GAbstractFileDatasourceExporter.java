/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;

/**
 * 得られたデータをファイル出力するための抽象クラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GAbstractFileDatasourceExporter implements GDatasourceExporter<File> {


	 /**
	  * {@inheritDoc}
	  * 
	  * @see GDatasourceExporter#write(GDatasource, GExportCondition)
	  */
	@Override
	public GExportedResult<File> write(GDatasource datasource, GExportCondition exportCondition) {
		Objects.requireNonNull(exportCondition, "export condition cannot be null.");

		File file = null;
		try {
			file = File.createTempFile(exportCondition.getFileName() + "temp", null);
		} catch (IOException e) {
			throw new GFrameworkException("Writing file is failed due to." + e.getMessage(), e);
		}
		OutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(file);
			writeInternal(outputStream, datasource, exportCondition);
			outputStream.close();
		} catch (IOException e) {
			throw new GFrameworkException("Writing file is failed due to." + e.getMessage(), e);
		}
		return (GExportedResult<File>) GExportedResult.Factory.getInstance(file, datasource, getExportNameWithExtension(exportCondition.getFileName()));
	}

	/**
	 * 出力フラグが有効になっている出力カラム｛{@link GExportConditionExportField}のみをリストで返します. <br>
	 * 
	 * @create 2023/10/25
	 * @param exportFields
	 * @return 出力カラムのリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected List<GExportConditionExportField> filterExportedFieldOnly(List<GExportConditionExportField> exportFields) {
		return exportFields.stream().filter(GExportConditionExportField::isUseField).collect(Collectors.toList());
	}
	
	/**
	 * 出力ファイルタイプ(パラメータ)を取得します. <br>
	 * 
	 * @return ファイル拡張子
	 * @author KCCS okanishi
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	protected abstract String getExtension();
	
	/**
	 * 出力するファイル名を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @param fileName 出力ファイルネーム
	 * @return ファイル名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected String getExportNameWithExtension(String fileName) {
		return String.format("%s.%s", GStringUtils.nullToBlank(fileName), getExtension());
	}

	
	/**
	 * データをファイルに出力するための内部処理を担います. <br>
	 * 
	 * @create 2023/10/25
	 * @param outputStream データの書き込み先
	 * @param datasource データソース {@link GDatasource}
	 * @param writerCondition 書き出し条件 {@link GExportCondition}
	 * @throws IOException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected abstract void writeInternal(OutputStream outputStream, GDatasource datasource,
		GExportCondition writerCondition) throws IOException;
	
}
