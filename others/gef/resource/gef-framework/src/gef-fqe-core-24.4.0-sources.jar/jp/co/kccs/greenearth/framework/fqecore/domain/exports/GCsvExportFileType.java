/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

/**
 * ファイル出力タイプ<code>csv</code>のenumクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GCsvExportFileType implements GExportFileType {

	/** ファイルタイプ(パラメータ) */
	private String fileType;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GCsvExportFileType() {
		this.fileType = "CSV";
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportFileType#getValue()
	 */
	@Override
	public String getValue() {
		return fileType;
	}

}
