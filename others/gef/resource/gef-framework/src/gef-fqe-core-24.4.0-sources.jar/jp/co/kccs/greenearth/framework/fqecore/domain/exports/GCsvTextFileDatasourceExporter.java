/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;


/**
 * データをCSVファイル形式で出力するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GCsvTextFileDatasourceExporter extends GTextFileDatasourceExporter {

	/** ファイルセパレータ */
	private static final String VALUE_SEPARATOR = ",";
	
	/** ファイルタイプ（文字列） */
	private static final String EXTENSION = "csv";

	/**
	 * {@inheritDoc}
	 *
	 * @see GTextFileDatasourceExporter#getSeparator()
	 */
	@Override
	protected String getSeparator() {
		return VALUE_SEPARATOR;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GTextFileDatasourceExporter#getExtension()
	 */
	@Override
	protected String getExtension() {
		return EXTENSION;
	}
}
