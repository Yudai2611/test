/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;

/**
 *
 * データを出力するためのインタフェースです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceExporter<T> {

	/**
	 * データをファイルに出力します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasource データ
	 * @param exportCondition 出力条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GExportedResult<T> write(GDatasource datasource, GExportCondition exportCondition);
	
	/**
	 * ファクトリクラスです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	class Factory {

		private static Map<Class<GExportFileType>, GDatasourceExporter<?>> defaultExportWriterList = new HashMap<>();

		public Factory(Map<Class<GExportFileType>, GDatasourceExporter<?>> defaultExportWriterList) {
			Factory.defaultExportWriterList = Objects.requireNonNullElse(defaultExportWriterList, new HashMap<>());
		}

		/**
		 * インスタンスを取得します. <br>
		 * 
		 * @create 2023/10/25
		 * @author KCCS dhiaz	
		 * @throws GFrameworkException
		 * @since 23.10.0
		 */
		@SuppressWarnings("unchecked")
		public static <F> GDatasourceExporter< F > getInstance(GExportFileType exportFileType) {
			Objects.requireNonNull(exportFileType, "export file type cannot be null");
			GDatasourceExporter< F > exportWriterClass = ((GDatasourceExporter<F>) defaultExportWriterList.get(exportFileType.getClass()));
			if (exportWriterClass != null) {
				return exportWriterClass;
			}
			throw new GFrameworkException("Exporter is not exist for type " + exportFileType.getValue());
		}
	}
}
