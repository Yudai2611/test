/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.formatter.GNumberFormatter;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GFieldDataType;

/**
 * 出力するデータをフォーマットします. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceExporterHelper {

	/**
	 * フィールド値をフォーマットします. <br>
	 * 
	 * @create 2023/10/25
	 * @param fieldValue データ
	 * @param format フォーマット
	 * @return フォーマット整形されたデータ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static String formatField(Object fieldValue, String format, GFieldDataType type) {
		if (Objects.isNull(fieldValue)) {
			return "";
		}
		if (Objects.isNull(format)) {
			return fieldValue.toString();
		}
		switch (type) {
			case NUMERIC:
				return formatNumber(fieldValue, format);
			case DATE:
				if (fieldValue instanceof Date) {
					return formatDate((Date) fieldValue, format);
				}
				if (fieldValue instanceof LocalDateTime) {
					return formatDate(
						Date.from(ZonedDateTime.of((LocalDateTime) fieldValue, ZoneId.systemDefault()).toInstant()),
						format);
				}
			default:
				return fieldValue.toString();
		}
	}

	/**
	 * 日付型のデータにフォーマットを適用します. <br>
	 * 
	 * @create 2023/10/25
	 * @param cell データ
	 * @param format フォーマット
	 * @return フォーマット整形されたデータ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private static String formatDate(Date cell, String format) {
		GDateFormatter dateFormatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		return dateFormatter.format(cell, GFrameworkContext.getInstance().getLocale(), format);
	}

	/**
	 * 数値型のデータにフォーマットを適用します. <br>
	 * 
	 * @create 2023/10/25
	 * @param cell データ
	 * @param format フォーマット
	 * @return フォーマット整形されてデータ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private static String formatNumber(Object cell, String format) {
		GNumberFormatter numericFormatter = GFrameworkUtils.getComponent(GNumberFormatter.class.getName());
		return numericFormatter.format((Number) cell, GFrameworkContext.getInstance().getLocale(), format);
	}

}
