/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceRow;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;

/**
 * データをexcel形式で出力するクラスです.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GExcelFileDatasourceExporter extends GAbstractFileDatasourceExporter {

	/** ファイルタイプ（文字列） */
	private String extension;

	/** Excel操作プロバイダー */
	private GExcelPartCreationProvider provider;

	/**
	 * コンストラクターです. <br>
	 * 
	 * @create 2023/10/25
	 * @param extension
	 * @param provider
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GExcelFileDatasourceExporter(String extension, GExcelPartCreationProvider provider) {
		this.extension = extension;
		this.provider = provider;
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @see GAbstractFileDatasourceExporter#getExtension()
	 */
	@Override
	protected String getExtension() {
		return extension;
	}

	/**
	 * Excelへ出力データのヘッダを書き込みます. <br>
	 * 
	 * @create 2023/10/25
	 * @param row 行
	 * @param exportFields 出力フィールド{@link GExportConditionExportField}のリスト
	 * @param datasourceFieldMap データソースメタ情報{@link GDatasourceFieldMetadata}のマップ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected void writeHeader(Row row, List<GExportConditionExportField> exportFields,
		Map<String, GDatasourceFieldMetadata> datasourceFieldMap) {
		for (int i = 0; i < exportFields.size(); i++) {
			GDatasourceFieldMetadata fieldMetadata = datasourceFieldMap.get(exportFields.get(i).getFieldId());
			if (fieldMetadata != null) {
				Cell cell = row.createCell(i);
				cell.setCellValue(fieldMetadata.getLabel());
			}
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GAbstractFileDatasourceExporter
	 */
	@Override
	protected void writeInternal(OutputStream outputStream, GDatasource datasource, GExportCondition exportCondition)
		throws IOException {
		int rowIndex = 0;
		Workbook workBook = provider.createWorkBook();
		Sheet sheet = provider.createSheet(workBook);
		Row row = provider.createRow(sheet, rowIndex);
		GDatasourceMetadata< ? extends GDatasourceType> datasourceMetadata = null;
		try {
			datasourceMetadata = GDatasourceMetadataService.getInstance().lookupById(exportCondition.getDatasourceId());
		} catch (NullPointerException e) {
			throw new GFrameworkException(exportCondition.getDatasourceId() + "is not found.");
		}
		
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap = GDatasourceUtil.toFieldMetadataMap(datasourceMetadata.getDatasourceFields());
		List<GExportConditionExportField> exportFields = filterExportedFieldOnly(exportCondition.getExportFields());
		if (exportCondition.isUseHeader()) {
			writeHeader(row, exportFields, datasourceFieldMetadataMap);
			rowIndex += 1;
		}

		for (GDatasourceRow datasourceRow : datasource.getRows()) {
			row = sheet.createRow(rowIndex);
			writeRow(row, datasourceRow, exportFields, datasourceFieldMetadataMap);
			rowIndex += 1;
		}

		workBook.write(outputStream);
		workBook.close();
	}

	/**
	 * Excelの列にデータを書き込みます. <br>
	 * 
	 * @create 2023/10/25
	 * @param row 行
	 * @param datasourceRow データソース行
	 * @param exportFields 出力フィールド{@link GExportConditionExportField}のリスト
	 * @param datasourceFieldMap データソースメタ情報{@link GDatasourceFieldMetadata}のマップ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected void writeRow(Row row, GDatasourceRow datasourceRow,
		List<GExportConditionExportField> exportFields, Map<String, GDatasourceFieldMetadata> datasourceFieldMap) {
		Map<String, Object> datasourceRowMap = GDatasourceUtil.toFieldMap(datasourceRow.getFields());
		for (int i = 0; i < exportFields.size(); i++) {
			GDatasourceFieldMetadata fieldMetadata = datasourceFieldMap.get(exportFields.get(i).getFieldId());
			if (fieldMetadata != null) {
				Cell cell = row.createCell(i);
				cell.setCellValue(GDatasourceExporterHelper.formatField(datasourceRowMap.get(fieldMetadata.getId()),
						fieldMetadata.getFormat(), fieldMetadata.getDataType()));
			}
		}
	}

}
