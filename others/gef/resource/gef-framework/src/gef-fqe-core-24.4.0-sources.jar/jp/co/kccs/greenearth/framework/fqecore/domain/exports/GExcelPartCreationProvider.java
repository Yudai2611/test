/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * Excel操作を行うために利用するインターフェースです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public interface GExcelPartCreationProvider {
	
	/**
	 * {@link Workbook}を作成します.<br>
	 * 
	 * @return {@link Workbook}の情報
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public Workbook createWorkBook();
	
	/**
	 * {@link Sheet}を作成します.<br>
	 * 
	 * @param <T> Workbookの型
	 * @param workBook {@link Workbook}
	 * @return {@link Sheet}の情報
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public <T extends Workbook> Sheet createSheet(T workBook);
	
	/**
	 * {@link Row}を作成します.<br>
	 * 
	 * @param <T> Sheetの型
	 * @param sheet {@link Sheet}
	 * @param rowIndex 作成する行インデックス
	 * @return {@link Row}の情報
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public <T extends Sheet> Row createRow(T sheet, int rowIndex);
	
	/**
	 * {@link Cell}を作成します.<br>
	 * 
	 * @param <T> Rowの型
	 * @param row {@link Row}
	 * @param cellIndex 作成するセルインデックス
	 * @return {@link Cell}の情報
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public <T extends Row> Cell createCell(T row, int cellIndex);
}
