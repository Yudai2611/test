/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.util.List;

/**
 * 出力するための諸条件を格納します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GExportCondition {
	String USE_HEADER = "useHeader";
	String FILE_TYPE = "fileType";
	String EXPORT_FIELDS = "exportFields";

	/**
	 * データソースIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getDatasourceId();

	/**
	 * 出力項目のリストを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 出力項目のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GExportConditionExportField> getExportFields();

	/**
	 * ファイル名を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ファイル名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFileName();

	/**
	 * ファイルタイプ{@link GExportFileType}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ファイルタイプ{@link GExportFileType}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GExportFileType getFileType();

	/**
	 * ヘッダ出力の有無を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ヘッダ出力の有無
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	boolean isUseHeader();
	
	/**
	 * データソースIDを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasource データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setDatasourceId(String datasource);

	/**
	 * 出力項目のリストを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param filedList 出力項目のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setExportFields(List<GExportConditionExportField> filedList);

	/**
	 * ファイル名を設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param name ファイル名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFileName(String name);

	/**
	 * ファイルタイプ{@link GExportFileType}を設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @return type ファイルタイプ{@link GExportFileType}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFileType(GExportFileType type);

	/**
	 * ヘッダ出力の有無を設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param isHeader ヘッダ出力の有無
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setUseHeader(boolean isHeader);

}
