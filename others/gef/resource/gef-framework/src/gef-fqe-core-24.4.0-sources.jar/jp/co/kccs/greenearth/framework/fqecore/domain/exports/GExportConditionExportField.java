/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;

/**
 * 出力条件フィールドを示すクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GExportConditionExportField {
	String FIELD_ID = GDatasourceFieldMetadata.FIELD_ID;
	String USE_FIELD = "useField";

	/**
	 * フィールドIDを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

	/**
	 * 出力対象になるかどうかのフラグを取得します。<br>
	 *
	 * @create 2023/10/25
	 * @return 出力対象になるかどうかのフラグ
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	boolean isUseField();
}
