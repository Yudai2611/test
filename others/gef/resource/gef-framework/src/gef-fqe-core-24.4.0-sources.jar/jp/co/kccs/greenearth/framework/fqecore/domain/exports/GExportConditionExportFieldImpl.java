/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

/**
 * 出力条件フィールドを示すクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GExportConditionExportFieldImpl implements GExportConditionExportField {

	/** フィールドID */
	private String fieldId;
	private boolean useField;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GExportConditionExportFieldImpl(String fieldId, boolean useField) {
		this.fieldId = fieldId;
		this.useField = useField;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportConditionExportField#getFieldId()
	 */
	public String getFieldId() {
		return fieldId;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExportConditionExportField#isUseField()
	 */
	@Override
	public boolean isUseField() {
		return useField;
	}

}
