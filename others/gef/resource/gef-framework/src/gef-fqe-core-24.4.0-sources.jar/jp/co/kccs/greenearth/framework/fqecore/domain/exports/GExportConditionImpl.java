/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;

/**
 * 出力するための諸条件を格納します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class  GExportConditionImpl implements GExportCondition {

	/** データソースID **/
	private String datasourceId;
	/** 出力項目のリスト **/
	private List<GExportConditionExportField> exportFields;
	/** ファイル名 **/
	private String fileName;
	/** ファイルタイプ{@link GExportFileType} **/
	private GExportFileType fileType;
	/** ヘッダ出力有無 **/
	private boolean useHeader;

	/**
	 * デフォルトコンストラクタです.<br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GExportConditionImpl() {
	}

	/**
	 * コンストラクタです.<br>
	 * 
	 * @create 2023/10/25
	 * @param fileName ファイル名
	 * @param useHeader ヘッダ出力有無
	 * @param fileType ファイルタイプ{@link GExportFileType}
	 * @param exportFields 出力項目のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GExportConditionImpl(String fileName, boolean useHeader, GExportFileType fileType,
								List<GExportConditionExportField> exportFields, String datasourceId) {
		this.fileName = fileName;
		this.useHeader = useHeader;
		this.fileType = fileType;
		this.exportFields = exportFields;
		this.datasourceId = datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#getDatasourceId()
	 */
	@Override
	public String getDatasourceId() {
		return datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#getExportFields()
	 */
	@Override
	public List<GExportConditionExportField> getExportFields() {
		return exportFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#getFileName()
	 */
	@Override
	public String getFileName() {
		if (fileName == null || fileName.isBlank() || fileName.isEmpty()) {
			return GFqePropertyKey.EXPORT_FILE_NAME_DEFAULT.getPropertyValue();
		}
		return fileName;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#getFileType()
	 */
	@Override
	public GExportFileType getFileType() {
		return fileType;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#isUseHeader()
	 */
	@Override
	public boolean isUseHeader() {
		return useHeader;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#setDatasourceId(String))
	 */
	@Override
	public void setDatasourceId(String datasourceId) {
		this.datasourceId = datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#setExportFields(List)
	 */
	@Override
	public void setExportFields(List<GExportConditionExportField> exportFields) {
		this.exportFields = exportFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#setFileName(String)
	 */
	@Override
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#setFileName(String)
	 */
	@Override
	public void setFileType(GExportFileType fileType) {
		this.fileType = fileType;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportCondition#setUseHeader(boolean)
	 */
	@Override
	public void setUseHeader(boolean useHeader) {
		this.useHeader = useHeader;
	}
	
	

}
