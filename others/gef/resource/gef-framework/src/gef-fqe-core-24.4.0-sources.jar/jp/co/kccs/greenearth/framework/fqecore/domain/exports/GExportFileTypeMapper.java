/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

import java.util.Map;

/**
 *
 * Enumの値から{@link GExportFileType}を返します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GExportFileTypeMapper {

	/**
	 * Enumの値から{@link GExportFileType}を返します. <br>
	 * 
	 * @create 2023/10/25
	 * @param fileType ファイルタイプ（数字）
	 * @return {@link GExportFileType} ファイルタイプ（enumクラス）
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GExportFileType get(String fileType);

	/**
	 * 出力ファイルタイプのマップを取得します。<br>
	 *
	 * @create 2023/10/25
	 * @return 出力ファイルタイプのマップ
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Map<String, GExportFileType> getExportFileTypes();

	/**
	 * {@link GExportFileTypeMapper}のインスタンスを生成するファクトリです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	class Factory {

		/**
		 * {@link GExportFileTypeMapper}のインスタンスを生成します.
		 * 
		 * @create 2023/10/25
		 * @return {@link GExportFileTypeMapper}のインスタンス
		 * @author KCCS dhiaz
		 * @since 23.10.0
		 */
		public static GExportFileTypeMapper getInstance() {
			return GFrameworkUtils.getComponent(GExportFileTypeMapper.class);
		}
	}
}
