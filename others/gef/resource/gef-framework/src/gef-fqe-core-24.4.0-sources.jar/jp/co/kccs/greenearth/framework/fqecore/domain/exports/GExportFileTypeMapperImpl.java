/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.util.Map;

/**
 * Enumの値から{@link GExportFileType}を返します.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GExportFileTypeMapperImpl implements GExportFileTypeMapper {

	/** ファイルタイプ */
	private Map<String, GExportFileType> exportFileTypeMap;

	/**
	 * コンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GExportFileTypeMapperImpl(Map<String, GExportFileType> exportFileTypeMap) {
		this.exportFileTypeMap = exportFileTypeMap;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GExportFileTypeMapper#get(String)
	 */
	@Override
	public GExportFileType get(String fileType) {
		return exportFileTypeMap.get(fileType);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExportFileTypeMapper#getExportFileTypes()
	 */
	@Override
	public Map<String, GExportFileType> getExportFileTypes() {
		return exportFileTypeMap;
	}

}
