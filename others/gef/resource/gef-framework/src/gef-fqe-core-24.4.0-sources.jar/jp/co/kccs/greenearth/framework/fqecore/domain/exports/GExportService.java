/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;

/**
 *
 * データを出力する機能を担うインタフェースです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GExportService {

	/**
	 * 画面から入力された条件を満たすデータ出力をします. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasource データソース{@link GDatasource}
	 * @param exportCondition 出力条件{@link GExportCondition}
	 * @return 出力結果 {@link GExportedResult}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	<T> GExportedResult<T> export(GDatasource datasource, GExportCondition exportCondition);

	/**
	 * インスタンスを生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @return {@link GExportService}インスタンス
	 * @since 23.10.0
	 */
	public static GExportService getInstance() {
		return GFrameworkUtils.getComponent(GExportService.class);
	}
}
