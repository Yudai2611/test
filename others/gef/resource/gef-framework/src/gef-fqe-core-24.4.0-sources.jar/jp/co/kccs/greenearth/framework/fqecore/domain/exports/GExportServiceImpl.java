/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;

import java.util.Objects;

/**
 * データ出力するサービスクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GExportServiceImpl implements GExportService {
	
	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GExportService#export(GDatasource
	 *      datasource,
	 *      GExportCondition
	 *      exportCondition)
	 */
	@Override
	public <T> GExportedResult<T> export(GDatasource datasource, GExportCondition exportCondition) {
		validateIfExportIsEligible(exportCondition);
		GDatasourceExporter<T> exporter =  GDatasourceExporter.Factory.getInstance(exportCondition.getFileType());
		GExportedResult<T> exportMedia = exporter.write(datasource, exportCondition);
		return exportMedia;
	}

	/**
	 * 出力項目が1件以上であるか、確認します. <br>
	 * 
	 * @create 2023/10/25
	 * @param exportCondition 出力条件{@link GExportCondition}
	 * @authorKCCS dhiaz
	 * @since 23.10.0
	 */
	private void validateIfExportIsEligible(GExportCondition exportCondition) {
		validateExportCondition(exportCondition);
		if (exportCondition.getExportFields().size() == 0) {
			throw new GFrameworkException("Export field size cannot be 0.");
		}
	}
	/**
	 * {@link GExportCondition}の検証をします.
	 *
	 * @create 2023/10/25
	 * @param exportCondition
	 * @author KCCS 200450201
	 * @since 23.10.0
	 */
	private static void validateExportCondition(GExportCondition exportCondition) {
		Objects.requireNonNull(exportCondition, "export condition cannot be null");
		Objects.requireNonNull(exportCondition.getFileName(), "file name cannot be null");
		Objects.requireNonNull(exportCondition.getExportFields(), "export field cannot be null");
		Objects.requireNonNull(exportCondition.getFileType(), "file type cannot be null");
		Objects.requireNonNull(exportCondition.getDatasourceId(), "datasource id cannot be null");
	}
}
