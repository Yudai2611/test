/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;

/**
 * データ出力結果を格納するクラスです. <br>
 *
 * @create 2023/10/25
 * @param <T>
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GExportedResult<T> {
	String EXPORTED_DATA = "exportedData";
	String EXPORTED_MEDIA = "exportedMedia";
	String EXPORTED_MEDIA_NAME = "exportedMediaName";

	/**
	 * 出力データ{@link GDatasource}を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return 出力データ {@link GDatasource}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasource getData();


	/**
	 * データ出力する形式を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return データ出力形式
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	T getMedia();

	/**
	 * 出力結果名を取得します。<br>
	 *
	 * @create 2023/10/25
	 * @return 出力結果ファイル名
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getMediaName();

	/**
	 * ファクトリクラスです. <br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	class Factory {
		
		/**
		 * インスタンスを取得します. <br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz
		 * @throws GFrameworkException
		 * @since 23.10.0
		 */
		@SuppressWarnings("unchecked")
		public static<T> GExportedResult<?> getInstance(T exportMedia, GDatasource datasource, String exportMediaName) {
			GExportedResult<?> exportResult = GFrameworkUtils.getComponent(GExportedResult.class);
			Class<?> exportMediaClass = exportMedia.getClass();
			Constructor<? extends GExportedResult<?>> constructor = null;
			try {
				constructor = (Constructor<? extends GExportedResult<?>>) exportResult.getClass().getConstructor(exportMediaClass, GDatasource.class, String.class);
			} catch (NoSuchMethodException e) {
				throw new GFrameworkException(String.format("Mismatch constructor for type %s, %s, %s.", exportMediaClass, GDatasource.class, String.class));
			}
			try {
				return constructor.newInstance(exportMedia, datasource, exportMediaName);
			} catch (InstantiationException | IllegalAccessException | InvocationTargetException e) {
				throw new GFrameworkException("Export result creation is failed due to :" + e.getMessage() + ".");
			}
		}
	}
}
