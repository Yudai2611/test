/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.io.File;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;

/**
 * {@inheritDoc}
 *
 * @see GExportedResult
 */
public class GExportedResultImpl implements GExportedResult<File> {

	/** 出力ファイル */
	private File exportMedia;

	/** 出力データ{@link GDatasource} */
	private GDatasource exportData;
	private String exportMediaName;

	public GExportedResultImpl() { }

	/**
	 * コンストラクタです.
	 *
	 * @create 2023/10/25
	 * @param exportMedia 出力ファイル
	 * @param exportData {@link GDatasource}
	 * @param exportMediaName 出力結果ファイル名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GExportedResultImpl(File exportMedia, GDatasource exportData, String exportMediaName) {
		this.exportData = exportData;
		this.exportMedia = exportMedia;
		this.exportMediaName = exportMediaName;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExportedResult#getData()
	 */
	@Override
	public GDatasource getData() {
		return exportData;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExportedResult#getMedia()
	 */
	@Override
	public File getMedia() {
		return exportMedia;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExportedResult#getMediaName()
	 */
	@Override
	public String getMediaName() {
		return exportMediaName;
	}

}
