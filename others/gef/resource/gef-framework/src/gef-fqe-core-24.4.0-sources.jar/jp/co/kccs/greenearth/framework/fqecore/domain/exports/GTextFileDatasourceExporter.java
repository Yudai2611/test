/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceRow;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;

/**
 * データをテキスト形式で出力します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GTextFileDatasourceExporter extends GAbstractFileDatasourceExporter {



	/**
	 * データのヘッダを出力します. <br>
	 *
	 * @create 2023/10/25
	 * @param exportFields 出力条件{@link GExportConditionExportField}のリスト
	 * @param datasourceFieldMap データソースメタ情報{@link GDatasourceFieldMetadata}のマップ
	 * @throws IOException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected void writeHeader(Writer writer, List<GExportConditionExportField> exportFields,
							   Map<String, GDatasourceFieldMetadata> datasourceFieldMap) throws IOException {
		StringBuilder headerStringBuilder = new StringBuilder();
		exportFields.forEach(exportField -> {
			GDatasourceFieldMetadata datasourceFieldMetadata = null;
			try {
				datasourceFieldMetadata = datasourceFieldMap.get(exportField.getFieldId());
			}  catch (NullPointerException e) {
				throw new GFrameworkException(exportField.getFieldId() + "is not found");
			}
			
			if (datasourceFieldMetadata != null) {
				headerStringBuilder.append(escapeSpecialSymbol(datasourceFieldMetadata.getLabel())).append(getSeparator());
			}
		});
		String headerString = headerStringBuilder.toString();
		writer.write(headerString.substring(0, headerString.length() - 1));
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractFileDatasourceExporter#writeInternal(OutputStream,
	 *      GDatasource, GExportCondition)
	 */
	@Override
	protected void writeInternal(OutputStream outputStream, GDatasource datasource, GExportCondition exportCondition)
			throws IOException {
		List<GExportConditionExportField> exportFields = filterExportedFieldOnly(exportCondition.getExportFields());
		GDatasourceMetadata datasourceMetadata = null;
		try {
			datasourceMetadata = GDatasourceMetadataService.getInstance().lookupById(exportCondition.getDatasourceId());
		} catch (NullPointerException e) {
        	throw new GFrameworkException(exportCondition.getDatasourceId() + "is not found");
        }
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap = GDatasourceUtil.toFieldMetadataMap(datasourceMetadata.getDatasourceFields());
		Writer writer = new BufferedWriter(new OutputStreamWriter(
				outputStream, GFqePropertyKey.EXPORT_ENCODING.getPropertyValue()));
		if (exportCondition.isUseHeader()) {
			writeHeader(writer, exportFields, datasourceFieldMetadataMap);
			if (datasource.getRows().size() > 0) {
				writer.write(System.lineSeparator());
			}
		}
		for (int i = 0; i < datasource.getRows().size(); i++) {
			writeRow(writer, datasource.getRows().get(i), exportFields,
					datasourceFieldMetadataMap);
			if (i < datasource.getRows().size() - 1) {
				writer.write(System.lineSeparator());
			}
		}
		writer.close();
	}

	/**
	 * データを列として出力します. <br>
	 * 
	 * @create 2023/10/25
	 * @param writer 出力先
	 * @param datasourceRow  データソースレコード
	 * @param exportFields 出力フィールド
	 * @param datasourceFieldMap データソースフィールドメタ情報のマップ
	 * @throws IOException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected void writeRow(Writer writer, GDatasourceRow datasourceRow,
							List<GExportConditionExportField> exportFields, Map<String, GDatasourceFieldMetadata> datasourceFieldMap)
			throws IOException {
		StringBuilder rowStringBuilder = new StringBuilder();
		Map<String, Object> datasourceFieldRow = GDatasourceUtil.toFieldMap(datasourceRow.getFields());
		exportFields.forEach(exportField -> {
			GDatasourceFieldMetadata datasourceFieldMetadata = datasourceFieldMap.get(exportField.getFieldId());
			if (datasourceFieldMetadata != null) {
				rowStringBuilder.append(escapeSpecialSymbol(GDatasourceExporterHelper.formatField(datasourceFieldRow.get(exportField.getFieldId()),
						datasourceFieldMetadata.getFormat(), datasourceFieldMetadata.getDataType()))).append(getSeparator());
			}
		});
		String rowString = rowStringBuilder.toString();
		writer.write(rowString.substring(0, rowString.length() - 1));
	}

	/**
	 * 文字列のエスケープ処理をします. <br>
	 * 
	 * @create 2023/10/25
	 * @param value
	 * @return 処理後の文字列
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String escapeSpecialSymbol(String value) {
		if (GFqePropertyKey.EXPORT_ESCAPE.getPropertyValue().equals("enable")) {
			value = value.replace("\"", "\"\"");
			return String.format("\"%s\"", value);
		}
		return value;
	}
	
	/**
	 * 文字列のセパレータを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected abstract String getSeparator();
}
