/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.exports;


/**
 * データをTSV形式で出力します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GTsvTextFileDatasourceExporter extends GTextFileDatasourceExporter {
	
	/** ファイルセパレータ */
	private static final String VALUE_SEPARATOR = "\t";
	
	/** ファイルタイプ（文字列） */
	private static final String EXTENSION = "tsv";

	/**
	 * {@inheritDoc}
	 *
	 * @see GTextFileDatasourceExporter#getSeparator()
	 */
	@Override
	protected String getSeparator() {
		return VALUE_SEPARATOR;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GTextFileDatasourceExporter#getExtension()
	 */
	@Override
	protected String getExtension() {
		return EXTENSION;
	}
}
