/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.domain.exports;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * {@link GExcelPartCreationProvider}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GXLSXPartCreationProvider implements GExcelPartCreationProvider {

	/** シート名 */
	private String _sheetName;

	/**
	 * {@inheritDoc}
	 *
	 * @see GExcelPartCreationProvider#createWorkBook()
	 */
	@Override
	public Workbook createWorkBook() {
		return new XSSFWorkbook();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExcelPartCreationProvider#createSheet(Workbook)
	 */
	@Override
	public <XSSFWorkbook extends Workbook> Sheet createSheet(XSSFWorkbook workBook) {
		return GStringUtils.isNotEmpty(_sheetName) ? workBook.createSheet(_sheetName) : workBook.createSheet();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExcelPartCreationProvider#createRow(Sheet, int)
	 */
	@Override
	public <XSSFSheet extends Sheet> Row createRow(XSSFSheet sheet, int rowIndex) {
		return sheet.createRow(rowIndex);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GExcelPartCreationProvider#createCell(Row, int) 
	 */
	@Override
	public <XSSFRow extends Row> Cell createCell(XSSFRow row, int cellIndex) {
		return row.createCell(cellIndex);
	}

	/**
	 * シート名を設定します.<br>
	 * 
	 * @param name シート名
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setSheetName(String name) {
		this._sheetName = name;
	}
}
