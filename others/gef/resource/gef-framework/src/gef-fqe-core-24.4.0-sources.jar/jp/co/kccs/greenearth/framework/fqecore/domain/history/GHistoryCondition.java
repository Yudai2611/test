/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history;

import java.util.Date;

import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportCondition;

/**
 * 出力条件履歴を格納するクラスです.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryCondition {
	String HISTORY_ID = "historyId";
	String HISTORY_NAME = "historyName";
	String SAVED_BY = "savedBy";
	String SAVED_AT = "savedAt";
	String IMPORT_CONDITION = "importCondition";
	String EXPORT_CONDITION = "exportCondition";

	/**
	 * 出力条件を取得します.
	 *
	 * @create 2023/10/25
	 * @return 出力条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GExportCondition getExportCondition();

	/**
	 * 履歴IDを取得します.
	 *
	 * @create 2023/10/25
	 * @return 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getId();

	/**
	 * 履歴名を取得します.
	 *
	 * @create 2023/10/25
	 * @return 履歴名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getName();

	/**
	 * 取得条件を取得します.
	 *
	 * @create 2023/10/25
	 * @return 取得条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GImportCondition getImportCondition();

	/**
	 * 保存日を取得します.
	 *
	 * @create 2023/10/25
	 * @return 保存日
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	Date getSavedAt();

	/**
	 * 保存者を取得します.
	 *
	 * @create 2023/10/25
	 * @return 保存者
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getSavedBy();

	/**
	 * 出力条件を設定します.
	 *
	 * @create 2023/10/25
	 * @param exportCondition 出力条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setExportCondition(GExportCondition exportCondition);

	/**
	 * 履歴IDを設定します.
	 *
	 * @create 2023/10/25
	 * @param id 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setId(String id);

	/**
	 * 履歴名を設定します.
	 *
	 * @create 2023/10/25
	 * @param name 履歴名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setName(String name);

	/**
	 * 取得条件を設定します.
	 *
	 * @create 2023/10/25
	 * @param importCondition 取得条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setImportCondition(GImportCondition importCondition);

	/**
	 * 保存日を設定します.
	 *
	 * @create 2023/10/25
	 * @param savedAt 保存日
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setSavedAt(Date savedAt);

	/**
	 * 保存者を設定します.
	 *
	 * @create 2023/10/25
	 * @param savedBy 保存者
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setSavedBy(String savedBy);
}
