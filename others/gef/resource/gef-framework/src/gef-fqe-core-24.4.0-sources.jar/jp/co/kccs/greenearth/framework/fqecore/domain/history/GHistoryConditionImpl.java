/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history;

import java.util.Date;

import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportCondition;

/**
 * 出力条件履歴を格納するクラスです.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GHistoryConditionImpl implements GHistoryCondition {

	/** 出力条件 */
	private GExportCondition exportCondition;

	/** 履歴ID */
	private String id;

	/** 履歴名 */
	private String name;

	/** 取得条件 */
	private GImportCondition importCondition;

	/** 保存日 */
	private Date savedAt;

	/** 保存者 */
	private String savedBy;

	/**
	 * デフォルトコンストラクタです.
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryConditionImpl() {
	}

	/**
	 * コンストラクターです.
	 *
	 * @create 2023/10/25
	 * @param id 履歴ID
	 * @param name 履歴名
	 * @param importCondition 取得条件
	 * @param exportCondition 出力条件
	 * @param savedBy 保存者
	 * @param savedAt 保存日
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryConditionImpl(String id, String name, GImportCondition importCondition, GExportCondition exportCondition,
		String savedBy, Date savedAt) {
		this.id = id;
		this.name = name;
		this.importCondition = importCondition;
		this.exportCondition = exportCondition;
		this.savedBy = savedBy;
		this.savedAt = savedAt;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#getExportCondition()
	 */
	@Override
	public GExportCondition getExportCondition() {
		return exportCondition;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#getId()
	 */
	@Override
	public String getId() {
		return id;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#getName()
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#getImportCondition()
	 */
	@Override
	public GImportCondition getImportCondition() {
		return importCondition;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#getSavedAt()
	 */
	@Override
	public Date getSavedAt() {
		return savedAt;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#getSavedBy()
	 */
	@Override
	public String getSavedBy() {
		return savedBy;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#setExportCondition(GExportCondition)
	 */
	@Override
	public void setExportCondition(GExportCondition exportCondition) {
		this.exportCondition = exportCondition;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#setId(String)
	 */
	@Override
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#setName(String) (String)
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#setImportCondition(GImportCondition)
	 */
	@Override
	public void setImportCondition(GImportCondition importCondition) {
		this.importCondition = importCondition;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#setSavedAt(Date)
	 */
	@Override
	public void setSavedAt(Date savedAt) {
		this.savedAt = savedAt;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryCondition#setSavedBy(String)
	 */
	@Override
	public void setSavedBy(String savedBy) {
		this.savedBy = savedBy;
	}
}
