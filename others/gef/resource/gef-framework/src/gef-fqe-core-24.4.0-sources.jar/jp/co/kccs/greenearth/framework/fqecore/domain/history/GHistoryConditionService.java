/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;

/**
 * 出力条件の読込・更新担うクラスです.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryConditionService {

	/**
	 * 出力条件を1件、削除します.
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void deleteById(String historyId) throws GFrameworkException;

	/**
	 * 出力条件を複数件、削除します.
	 * 
	 * @create 2023/10/25
	 * @param historyIds 履歴Idのリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void deleteByIds(List<String> historyIds) throws GFrameworkException;
	
	/**
	 * 指定した出力条件ID<code>conditionId</code>の出力条件を探します.
	 * 
	 * @create 2023/10/25
	 * @param historyId 出力履歴ID
	 * @return {@link GHistoryCondition}
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GHistoryCondition findById(String historyId) throws GFrameworkException;
	
	/**
	 * 指定した条件(データソース名<code>datasourceName</code>、条件名<code>conditionName</code>、保存者<code>savedUser</code>)を満たす、出力条件を探します.
	 *
	 * @create 2023/10/25
	 * @param datasourceName データソース名
	 * @param historyName 履歴名
	 * @param savedBy 保存者名
	 * @return {@link GHistoryCondition}のリスト
	 * @throws SQLException
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GRangeResult<GHistoryCondition> findByContains(String datasourceName, String historyName, String savedBy, GRange range)
		throws GFrameworkException;
	
	/**
	 * 出力条件を1件、保存します.
	 * 
	 * @create 2023/10/25
	 * @param historyCondition {@link GHistoryCondition}
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GHistoryCondition save(GHistoryCondition historyCondition) throws GFrameworkException;
	
	/**
	 * 出力条件を複数件、保存します.
	 * 
	 * @param historyConditions {@link GHistoryCondition}のリスト
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	List<GHistoryCondition> saves(List<GHistoryCondition> historyConditions) throws GFrameworkException;
	
	

		/**
		 * {@link GHistoryConditionService}インスタンスを生成するファクトリです.
		 * 
		 * @return {@link GHistoryConditionService}インスタンス
		 * @author KCCS dhiaz
		 * @create 2023/10/25
		 * @since 23.10.0
		 */
	static GHistoryConditionService getInstance() {
		return GFrameworkUtils.getComponent(GHistoryConditionService.class);
	}
}
