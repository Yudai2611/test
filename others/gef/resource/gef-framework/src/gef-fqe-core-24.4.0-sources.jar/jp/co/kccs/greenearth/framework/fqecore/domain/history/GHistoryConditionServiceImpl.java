/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.dao.GHistoryConditionDao;

/**
 * 出力条件の読込・更新担うクラスです.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GHistoryConditionServiceImpl implements GHistoryConditionService {

	/** export条件のDAO */
	private GHistoryConditionDao historyConditionDao;

	/**
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryConditionServiceImpl(GHistoryConditionDao historyConditionDao) {
		this.historyConditionDao = historyConditionDao;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionServiceImpl#findById(String)
	 */
	@Override
	public GHistoryCondition findById(String historyId) {
		try {
			return historyConditionDao.findById(historyId);
		} catch (SQLException e) {
			throw new GFrameworkException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionServiceImpl#findByContains(String, String, String, GRange)
	 */
	@Override
	public GRangeResult<GHistoryCondition> findByContains(String datasourceName, String historyName, String savedBy, GRange range) {
		try {
			return historyConditionDao.findByContains(datasourceName, historyName, savedBy, range);
		} catch (SQLException e) {
			throw new GFrameworkException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionServiceImpl#deleteById(String)
	 */
	@Override
	public void deleteById(String historyId) {
		try {
			historyConditionDao.deleteById(historyId);
		} catch (SQLException e) {
			throw new GFrameworkException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionServiceImpl#deleteByIds(List)
	 */
	@Override
	public void deleteByIds(List<String> historyIds) {
		if (Objects.nonNull(historyIds)) {
			historyIds.forEach(historyId -> {
				try {
					historyConditionDao.deleteById(historyId);

				} catch (SQLException e) {
					throw new GFrameworkException(e);
				}
			});
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionServiceImpl#save(GHistoryCondition)
	 */
	@Override
	public GHistoryCondition save(GHistoryCondition historyCondition) throws GFrameworkException {
		try {
			return historyConditionDao.save(historyCondition);
		} catch (SQLException e) {
			throw new GFrameworkException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionServiceImpl#saves(List)
	 */
	@Override
	public List<GHistoryCondition> saves(List<GHistoryCondition> historyConditions) throws GFrameworkException {
		if (Objects.nonNull(historyConditions)) {
			return historyConditions.stream().map(this::save).collect(Collectors.toList());
		}
		return Collections.emptyList();
	}
}
