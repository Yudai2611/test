/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */


package jp.co.kccs.greenearth.framework.fqecore.domain.history.dao;

import java.io.IOException;
import java.sql.SQLException;

import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryConditionEntity;

import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * QueryConditionsテーブルにアクセスします. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryConditionDao {

	/**
	 * テーブルから指定された<code>conditionId</code>のレコードを削除します. <br>
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void deleteById(String historyId) throws SQLException;

	/**
	 * 指定された<code>conditionId</code>の条件を{@link GHistoryConditionEntity}として返します. <br>
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @return {@link GHistoryConditionEntity} 出力条件
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GHistoryCondition findById(String historyId) throws SQLException;

	/**
	 * 指定された条件<code>datasourceLabel</code>、<code>historyName</code>、<code>savedBy</code>を満たす{@link GHistoryConditionEntity}のリストとして返します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceLabel データソースラベル
	 * @param historyName 履歴名
	 * @param savedBy 保存者名
	 * @return {@link GHistoryConditionEntity} 出力条件のリスト
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GRangeResult<GHistoryCondition> findByContains(String datasourceLabel, String historyName, String savedBy, GRange range)
		throws SQLException;


	/**
	 * テーブルに1件のレコードを保存します. <br>
	 * 
	 * @create 2023/10/25
	 * @param historyCondition {@link GHistoryConditionEntity}
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GHistoryCondition save(GHistoryCondition historyCondition) throws SQLException;

	/**
	 * {@link GHistoryConditionDao}のインスタンスを生成するファクトリです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	class Factory {

		/**
		 * {@link GHistoryConditionDao}のインスタンスを生成します. <br>
		 * 
		 * @create 2023/10/25
		 * @return {@link GHistoryConditionDao}
		 * @author KCCS dhiaz
		 * @since 23.10.0
		 */
		public static GHistoryConditionDao getInstance() {
			return GFrameworkUtils.getComponent(GHistoryConditionDao.class);
		}
	}
}
