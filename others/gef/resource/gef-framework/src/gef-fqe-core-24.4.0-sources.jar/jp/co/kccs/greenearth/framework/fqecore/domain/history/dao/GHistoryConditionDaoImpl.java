/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.dao;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.$;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.exp;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.select;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.asc;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.commons.data.GRangeResultImpl;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryConditionEntity;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryConditionEntityImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryExportConditionEntity;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryExportConditionEntityImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryExportConditionExportFieldEntity;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryExportConditionExportFieldEntityImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionEntity;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionEntityImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionFilterFieldEntity;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionFilterFieldEntityImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionImportFieldEntity;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionImportFieldEntityImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionSortFieldEntity;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.entity.GHistoryImportConditionSortFieldEntityImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;
import jp.co.kccs.greenearth.framework.jdbc.GExpressionFactor;
import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.orm.GORMapper;

/**
 * QueryConditionsテーブルにアクセスします.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GHistoryConditionDaoImpl implements GHistoryConditionDao {

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionDao#deleteById(String)
	 */
	@Override
	public void deleteById(String historyId) throws SQLException {

		List<String> entityList = Arrays.asList(GHistoryExportConditionExportFieldEntity.ENTITY_NAME,
			GHistoryExportConditionEntity.ENTITY_NAME, GHistoryImportConditionImportFieldEntity.ENTITY_NAME,
			GHistoryImportConditionFilterFieldEntity.ENTITY_NAME, GHistoryImportConditionSortFieldEntity.ENTITY_NAME,
			GHistoryImportConditionEntity.ENTITY_NAME, GHistoryConditionEntity.ENTITY_NAME);
		for (String entity : entityList) {
			GQueryAssistants.delete(entity)
				.where(exp(
					$("#" + GHistoryExportConditionExportFieldEntity.APPLICATION_ID + "= ?")
						.AND($("#" + GHistoryExportConditionExportFieldEntity.HISTORY_ID + "= ?")),
					GFqeContextHolder.getContext().getApplicationId(), historyId))
				.execute();
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionDao#findById(String)
	 */
	@Override
	public GHistoryCondition findById(String historyId) throws SQLException {
		GORMapper mapper = GORMapper.Factory.getInstance();
		GEntitySelect conditionSelect = mapper.buildQuery(select(GHistoryConditionEntity.ENTITY_NAME), GHistoryConditionEntityImpl.class);
		GHistoryConditionEntity conditionEntity = mapper.mapSingle(conditionSelect, GHistoryConditionEntityImpl.class, conditionSelect
			.whereUK(GHistoryConditionEntity.UNIQUE_KEY, GFqeContextHolder.getContext().getApplicationId(), historyId).findList());
		if (Objects.isNull(conditionEntity)) {
			return null;
		}
		GEntitySelect exportSelect =
			mapper.buildQuery(select(GHistoryExportConditionEntity.ENTITY_NAME), GHistoryExportConditionEntityImpl.class);
		GHistoryExportConditionEntity exportEntity = mapper.mapSingle(exportSelect, GHistoryExportConditionEntityImpl.class, exportSelect
			.whereUK(GHistoryExportConditionEntity.UNIQUE_KEY, GFqeContextHolder.getContext().getApplicationId(), historyId).findList());

		GEntitySelect exportFieldSelect = mapper.buildQuery(select(GHistoryExportConditionExportFieldEntity.ENTITY_NAME),
			GHistoryExportConditionExportFieldEntityImpl.class);
		List exportFieldEntitys = mapper.mapMultiple(exportFieldSelect, GHistoryExportConditionExportFieldEntityImpl.class,
			exportFieldSelect.where(exp(
				$("#" + GHistoryExportConditionExportFieldEntity.APPLICATION_ID + "= ?")
					.AND($("#" + GHistoryExportConditionExportFieldEntity.HISTORY_ID + "= ?")),
				GFqeContextHolder.getContext().getApplicationId(), historyId)).findList());

		GEntitySelect importSelect =
			mapper.buildQuery(select(GHistoryImportConditionEntity.ENTITY_NAME), GHistoryExportConditionEntityImpl.class);
		GHistoryImportConditionEntity importEntity = mapper.mapSingle(importSelect, GHistoryImportConditionEntityImpl.class, importSelect
			.whereUK(GHistoryImportConditionEntity.UNIQUE_KEY, GFqeContextHolder.getContext().getApplicationId(), historyId).findList());

		GEntitySelect importFieldSelect = mapper.buildQuery(select(GHistoryImportConditionImportFieldEntity.ENTITY_NAME),
			GHistoryImportConditionImportFieldEntityImpl.class);
		List importFieldEntitys = mapper.mapMultiple(importFieldSelect, GHistoryImportConditionImportFieldEntityImpl.class,
			importFieldSelect.where(exp(
				$("#" + GHistoryImportConditionImportFieldEntity.APPLICATION_ID + "= ?")
					.AND($("#" + GHistoryImportConditionImportFieldEntity.HISTORY_ID + "= ?")),
				GFqeContextHolder.getContext().getApplicationId(), historyId)).findList());

		GEntitySelect importFilterSelect = mapper.buildQuery(select(GHistoryImportConditionFilterFieldEntity.ENTITY_NAME),
			GHistoryImportConditionFilterFieldEntityImpl.class);
		List importFilterEntitys = mapper.mapMultiple(importFilterSelect, GHistoryImportConditionFilterFieldEntityImpl.class,
			importFilterSelect.where(exp(
				$("#" + GHistoryImportConditionFilterFieldEntity.APPLICATION_ID + "= ?")
					.AND($("#" + GHistoryImportConditionFilterFieldEntity.HISTORY_ID + "= ?")),
				GFqeContextHolder.getContext().getApplicationId(), historyId)).findList());

		GEntitySelect importSortSelect =
			mapper.buildQuery(select(GHistoryImportConditionSortFieldEntity.ENTITY_NAME), GHistoryImportConditionSortFieldEntityImpl.class);
		List importSortEntitys = mapper.mapMultiple(importSortSelect, GHistoryImportConditionSortFieldEntityImpl.class,
			importSortSelect.where(exp(
				$("#" + GHistoryImportConditionSortFieldEntity.APPLICATION_ID + "= ?")
					.AND($("#" + GHistoryImportConditionSortFieldEntity.HISTORY_ID + "= ?")),
				GFqeContextHolder.getContext().getApplicationId(), historyId)).findList());

		exportEntity.setExportFields(exportFieldEntitys);
		importEntity.setFilterFields(importFilterEntitys);
		importEntity.setImportFields(importFieldEntitys);
		importEntity.setSortFields(importSortEntitys);
		conditionEntity.setExportCondition(exportEntity);
		conditionEntity.setImportCondition(importEntity);

		return GHistoryConditionEntity.to(conditionEntity);

	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionDao#findByContains(String, String, String, GRange)
	 */
	@Override
	public GRangeResult<GHistoryCondition> findByContains(String datasourceLabel, String historyName, String savedBy, GRange range)
		throws SQLException {
		if (Objects.isNull(range)) {
			throw new GFrameworkException("GRange object cannot be null");
		}
		GORMapper mapper = GORMapper.Factory.getInstance();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put(GHistoryConditionEntity.APPLICATION_ID, GFqeContextHolder.getContext().getApplicationId());
		paramMap.put(GHistoryConditionEntity.HISTORY_NAME, GStringUtils.blankToNull(historyName));
		paramMap.put(GHistoryConditionEntity.SAVED_BY, GStringUtils.blankToNull(savedBy));

		GEntitySelect entitySelect = select(GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.ENTITY_NAME)
			.innerJoinFK(GHistoryConditionEntity.IMPORT_CONDITION, GHistoryConditionEntity.IMPORT_CONDITION)
			.where(GQueryAssistants.expMap(createWhereExpression(datasourceLabel), paramMap))
			.orderBy(asc(exp($(String.format("#%s.%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.HISTORY_NAME)))),
				asc(exp($(String.format("#%s.%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.SAVED_BY)))))
			.range(range.getBeginIndex(), range.getEndIndex() - range.getBeginIndex());

		List<GRecord> historyConditionList = entitySelect.findList();
		List<GHistoryConditionEntityImpl> historyConditionEntities =
			mapper.mapMultiple(entitySelect, GHistoryConditionEntityImpl.class, historyConditionList);

		GEntitySelect entitySelectCount = select(GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.ENTITY_NAME)
			.innerJoinFK(GHistoryConditionEntity.IMPORT_CONDITION, GHistoryConditionEntity.IMPORT_CONDITION)
			.where(GQueryAssistants.expMap(createWhereExpression(datasourceLabel), paramMap));

		Map<String, String> historyImportConditionmap =
			historyConditionList.stream().collect(Collectors.toMap(r -> r.getString(GHistoryImportConditionEntity.HISTORY_ID),
				r -> r.getString(GHistoryImportConditionEntity.DATASOURCE_ID)));
		historyConditionEntities.forEach(e -> e
			.setImportCondition(new GHistoryImportConditionEntityImpl(historyImportConditionmap.get(e.getHistoryId()), null, null, null)));
		List<GHistoryCondition> historyConditions =
			historyConditionEntities.stream().map(GHistoryConditionEntity::to).collect(Collectors.toList());
		return new GRangeResultImpl<>(historyConditions, range, entitySelectCount.count());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GHistoryConditionDao#save(GHistoryCondition)
	 */
	@Override
	public GHistoryCondition save(GHistoryCondition historyCondition) throws SQLException {
		Objects.requireNonNull(historyCondition, "cannot save null object");
		GORMapper mapper = GORMapper.Factory.getInstance();

		String historyId = UUID.randomUUID().toString();
		GHistoryConditionEntity historyConditionEntity = GHistoryConditionEntity.from(historyCondition);
		((GHistoryConditionEntityImpl) historyConditionEntity).setHistoryId(historyId);
		((GHistoryExportConditionEntityImpl) historyConditionEntity.getExportCondition()).setHistoryId(historyId);
		((GHistoryImportConditionEntityImpl) historyConditionEntity.getImportCondition()).setHistoryId(historyId);
		historyConditionEntity.getImportCondition().getImportFields().forEach(importField -> {
			((GHistoryImportConditionImportFieldEntityImpl) importField).setHistoryId(historyId);
		});
		historyConditionEntity.getImportCondition().getFilterFields().forEach(filterField -> {
			((GHistoryImportConditionFilterFieldEntityImpl) filterField).setHistoryId(historyId);
		});
		historyConditionEntity.getImportCondition().getSortFields().forEach(sortField -> {
			((GHistoryImportConditionSortFieldEntityImpl) sortField).setHistoryId(historyId);
		});
		historyConditionEntity.getExportCondition().getExportFields().forEach(exportField -> {
			((GHistoryExportConditionExportFieldEntityImpl) exportField).setHistoryId(historyId);
		});

		Map<String, Object> singleRecord = new HashMap<String, Object>() {

			{
				put(GHistoryConditionEntity.ENTITY_NAME, historyConditionEntity);
				put(GHistoryExportConditionEntity.ENTITY_NAME, historyConditionEntity.getExportCondition());
				put(GHistoryImportConditionEntity.ENTITY_NAME, historyConditionEntity.getImportCondition());
			}
		};

		Map<String, List<?>> multipleRecord = new HashMap<String, List<?>>() {

			{
				put(GHistoryExportConditionExportFieldEntity.ENTITY_NAME, historyConditionEntity.getExportCondition().getExportFields());
				put(GHistoryImportConditionImportFieldEntity.ENTITY_NAME, historyConditionEntity.getImportCondition().getImportFields());
				put(GHistoryImportConditionFilterFieldEntity.ENTITY_NAME, historyConditionEntity.getImportCondition().getFilterFields());
				put(GHistoryImportConditionSortFieldEntity.ENTITY_NAME, historyConditionEntity.getImportCondition().getSortFields());
			}
		};

		for (Entry<String, Object> entry : singleRecord.entrySet()) {
			GRecord record = mapper.mapSingle(GQueryAssistants.entity(entry.getKey()), entry.getValue());
			GQueryAssistants.insert(entry.getKey()).values(record).execute();
		}

		for (Entry<String, List<?>> entry : multipleRecord.entrySet()) {
			List<GRecord> recordList = mapper.mapMultiple(GQueryAssistants.entity(entry.getKey()), entry.getValue());
			GQueryAssistants.insert(entry.getKey()).values(recordList).executeList();
		}

		return GHistoryConditionEntity.to(historyConditionEntity);
	}

	/**
	 * where条件を作成します.
	 * 
	 * @param datasourceLabel
	 * @return where条件
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	private GExpressionFactor createWhereExpression(String datasourceLabel) {
		if (GStringUtils.isNullOrEmpty(datasourceLabel)) {
			return $(String.format("#%s.%s = :%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.APPLICATION_ID,
				GHistoryConditionEntity.APPLICATION_ID))
					.AND($(String.format("#%s.%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.HISTORY_NAME)
						+ " LIKE :[%HistoryName%]"))
					.AND($(String.format("#%s.%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.SAVED_BY)
						+ " LIKE :[%SavedBy%]"));
		} else {
			return $(String.format("#%s.%s = :%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.APPLICATION_ID,
				GHistoryConditionEntity.APPLICATION_ID))
					.AND($(String.format("#%s.%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.HISTORY_NAME)
						+ " LIKE :[%HistoryName%]"))
					.AND($(String.format("#%s.%s", GHistoryConditionEntity.ENTITY_NAME, GHistoryConditionEntity.SAVED_BY)
						+ " LIKE :[%SavedBy%]"))
					.AND($(String.format("#%s.%s %s", GHistoryConditionEntity.IMPORT_CONDITION, GHistoryImportConditionEntity.DATASOURCE_ID,
						generateDatasourceIdsQueryParams(GDatasourceMetadataService.getInstance().lookupAll(), datasourceLabel))));
		}
	}

	/**
	 * 指定されたデータソース名を基にして、SQLクエリーを生成します. <br>
	 *
	 * @param datasourceMetadataList データソースメタデータのリスト
	 * @param datasourceName データソース名
	 * @return query 生成されたSQLクエリー
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String generateDatasourceIdsQueryParams(List<GDatasourceMetadata<? extends GDatasourceType>> datasourceMetadataList,
		String datasourceName) {

		List<String> datasourceIds = new ArrayList<>();
		String query = "";
		if (Objects.nonNull(datasourceMetadataList)) {
			datasourceMetadataList.forEach(datasourceMetadata -> {
				if (!datasourceName.isEmpty() && datasourceName != null && datasourceMetadata.getLabel().contains(datasourceName)) {
					datasourceIds.add("'" + datasourceMetadata.getId() + "'");
				}
			});
			if (datasourceIds.isEmpty()) {
				if (datasourceName.isEmpty()) {
					return "LIKE '%%'";
				}
				return "= ''";
			}
			query = String.format("IN (%s) ", String.join(",", datasourceIds));
		}
		return query;
	}

}
