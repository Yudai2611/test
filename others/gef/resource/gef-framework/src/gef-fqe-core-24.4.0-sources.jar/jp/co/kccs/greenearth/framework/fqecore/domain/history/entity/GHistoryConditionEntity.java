/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.Date;

import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryConditionImpl;

/**
 * 出力条件履歴を格納するクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryConditionEntity {

	/** アプリケーションID */
	String APPLICATION_ID = "ApplicationId";

	/** エンティティ名 */
	String ENTITY_NAME = "HISTORY_CONDITION";

	/** <code>ExportCondition</code>に対する外部キー */
	String EXPORT_CONDITION = "FkExportCondition";

	/** <code>ImportCondition</code>に対する外部キー */
	String IMPORT_CONDITION = "FkImportCondition";

	/** 履歴ID */
	String HISTORY_ID = "HistoryId";

	/** 履歴名 */
	String HISTORY_NAME = "HistoryName";

	/** 保存日時 */
	String SAVED_AT = "SavedAt";

	/** 保存者 */
	String SAVED_BY = "SavedBy";

	/** ユニークキー */
	String UNIQUE_KEY = "UkHistoryCondition";

	/**
	 * アプリケーションIDを取得します.
	 *
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * {@link GHistoryExportConditionEntity} 出力条件を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return {@link GHistoryExportConditionEntity} 出力条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GHistoryExportConditionEntity getExportCondition();

	/**
	 * 履歴IDを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getHistoryId();

	/**
	 * 履歴名を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return 履歴名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getHistoryName();

	/**
	 * {@link GHistoryImportConditionEntity} 取得条件を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return {@link GHistoryImportConditionEntity} 取得条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GHistoryImportConditionEntity getImportCondition();

	/**
	 * 保存日時を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return 保存日時
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	Date getSavedAt();

	/**
	 * 保存者を取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return 保存者
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getSavedBy();

	/**
	 * {@link GHistoryCondition}から{@link GHistoryConditionEntity}に変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param historyCondition 出力条件履歴
	 * @return {@link GHistoryConditionEntity}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static GHistoryConditionEntity from(GHistoryCondition historyCondition) {
		if (historyCondition != null) {
			return new GHistoryConditionEntityImpl(historyCondition.getId(), historyCondition.getName(),
				GHistoryImportConditionEntity.from(historyCondition.getImportCondition()),
				GHistoryExportConditionEntity.from(historyCondition.getExportCondition()));
		}
		return null;
	}

	/**
	 * アプリケーションIDを設定します. <br>
	 *
	 * @create 2023/10/25
	 * @param applicationId アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setApplicationId(String applicationId);

	/**
	 * {@link GHistoryExportConditionEntity}出力条件を設定します. <br>
	 *
	 * @create 2023/10/25
	 * @param exportCondition 出力条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setExportCondition(GHistoryExportConditionEntity exportCondition);

	/**
	 * 履歴IDを設定します. <br>
	 *
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryId(String historyId);

	/**
	 * 履歴名を設定します. <br>
	 *
	 * @create 2023/10/25
	 * @param historyName 履歴名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryName(String historyName);

	/**
	 * {@link GHistoryImportConditionEntity}取得条件を設定します. <br>
	 *
	 * @create 2023/10/25
	 * @param improtCondition 取得条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setImportCondition(GHistoryImportConditionEntity improtCondition);

	/**
	 * 保存日時を設定します. <br>
	 *
	 * @create 2023/10/25
	 * @param {@link Date} 保存日時
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setSavedAt(Date savedAt);

	/**
	 * 保存者を設定します.  <br>
	 *
	 * @create 2023/10/25
	 * @param saveBy 保存者
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setSavedBy(String saveBy);

	/**
	 * {@link GHistoryConditionEntity}から{@link GHistoryCondition}へ変換します.  <br>
	 *
	 * @create 2023/10/25
	 * @param historyConditionEntity 出力条件履歴
	 * @return {@link GHistoryCondition} 出力条件履歴
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static GHistoryCondition to(GHistoryConditionEntity historyConditionEntity) {
		if (historyConditionEntity != null) {
			return new GHistoryConditionImpl(historyConditionEntity.getHistoryId(), historyConditionEntity.getHistoryName(),
				GHistoryImportConditionEntity.to(historyConditionEntity.getImportCondition()),
				GHistoryExportConditionEntity.to(historyConditionEntity.getExportCondition()), historyConditionEntity.getSavedBy(),
				historyConditionEntity.getSavedAt());
		}
		return null;
	}
}
