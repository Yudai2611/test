/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.Date;

import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;

/**
 * 出力条件履歴を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
@Entity(keyType = Entity.KeyType.UNIQUE, keyName = GHistoryConditionEntity.UNIQUE_KEY)
public class GHistoryConditionEntityImpl implements GHistoryConditionEntity {

	/** アプリケーションID */
	private String applicationId;

	/** {@link GHistoryExportConditionEntityImpl} 出力条件 */
	private GHistoryExportConditionEntityImpl exportCondition;

	/** 履歴ID */
	private String historyId;

	/** 履歴名 */
	private String historyName;

	/** {@link GHistoryImportConditionEntityImpl} 取得条件 */
	private GHistoryImportConditionEntityImpl importCondition;

	/** 保存日時 */
	private Date savedAt;

	/** 保存者 */
	private String savedBy;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryConditionEntityImpl() {
	}

	/**
	 * コンストラクターです.
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @param historyName 履歴名
	 * @param importCondition 取得条件
	 * @param exportCondition 出力条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryConditionEntityImpl(String historyId, String historyName, GHistoryImportConditionEntity importCondition,
										GHistoryExportConditionEntity exportCondition) {
		this.applicationId = GFqeContextHolder.getContext().getApplicationId();
		this.historyId = historyId;
		this.historyName = historyName;
		this.savedBy = GFqeContextHolder.getContext().getUserId();
		this.importCondition = (GHistoryImportConditionEntityImpl) importCondition;
		this.exportCondition = (GHistoryExportConditionEntityImpl) exportCondition;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#getApplicationId()
	 */
	@Override
	@Column(name = APPLICATION_ID)
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#getExportCondition()
	 */
	@Override
	public GHistoryExportConditionEntity getExportCondition() {
		return exportCondition;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#getHistoryId()
	 */
	@Override
	@Column(name = HISTORY_ID)
	public String getHistoryId() {
		return historyId;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#getHistoryName()
	 */
	@Override
	@Column(name = HISTORY_NAME)
	public String getHistoryName() {
		return historyName;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#getImportCondition()
	 */
	@Override
	public GHistoryImportConditionEntityImpl getImportCondition() {
		return importCondition;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#getSavedAt()
	 */
	@Override
	@Column(name = SAVED_AT)
	public Date getSavedAt() {
		return savedAt;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#getSavedBy()
	 */
	@Override
	@Column(name = SAVED_BY)
	public String getSavedBy() {
		return savedBy;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#setApplicationId(String)
	 */
	@Override
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#setExportCondition(GHistoryExportConditionEntity)
	 */
	@Override
	public void setExportCondition(GHistoryExportConditionEntity exportCondition) {
		this.exportCondition = (GHistoryExportConditionEntityImpl) ((Object) exportCondition);
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#setHistoryId(String)
	 */
	@Override
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#setHistoryName(String)
	 */
	@Override
	public void setHistoryName(String historyName) {
		this.historyName = historyName;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#setImportCondition(GHistoryImportConditionEntity)
	 */
	@Override
	public void setImportCondition(GHistoryImportConditionEntity importCondition) {
		this.importCondition = (GHistoryImportConditionEntityImpl) ((Object) importCondition);
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#setSavedAt(Date)
	 */
	@Override
	public void setSavedAt(Date savedAt) {
		this.savedAt = savedAt;
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @see GHistoryConditionEntity#setSavedBy(String)
	 */
	@Override
	public void setSavedBy(String savedBy) {
		this.savedBy = savedBy;
	}
}
