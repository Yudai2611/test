/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportConditionImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportFileTypeMapper;

/**
 * 出力条件を格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryExportConditionEntity {

	/** アプリケーションID */
	String APPLICATION_ID = "ApplicationId";

	/** データソースID */
	String DATASOURCE_ID = "DatasourceId";

	/** エンティティ名 */
	String ENTITY_NAME = "HISTORY_EXPORT_CONDITION";

	/** <code>ExportFields</code>の外部キー */
	String EXPORT_FIELD = "FkExportFields";

	/** ファイルタイプ */
	String FILE_TYPE = "FileType";

	/** 履歴ID */
	String HISTORY_ID = "HistoryId";

	/** ユニークキー */
	String UNIQUE_KEY = "UkHistoryExportCondition";

	/** ヘッダー利用有無 */
	String USE_HEADER = "UseHeader";

	/**
	 * アプリケーションIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * データソースIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getDatasourceId();

	/**
	 * 出力項目（出力条件用）のリストを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return {@link GHistoryExportConditionExportFieldEntity} 出力項目（出力条件用）のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GHistoryExportConditionExportFieldEntity> getExportFields();

	/**
	 * ファイルタイプを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ファイルタイプ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFileType();

	/**
	 * {@link GExportCondition}から{@link GHistoryExportConditionEntity}へ変換します. <br>
	 * 
	 * @create 2023/10/25
	 * @param exportCondition 出力条件
	 * @return {@link GHistoryExportConditionEntity}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static GHistoryExportConditionEntity from(GExportCondition exportCondition) {
		if (exportCondition != null) {
			return new GHistoryExportConditionEntityImpl(exportCondition.getDatasourceId(), exportCondition.getFileType().getValue(),
				exportCondition.isUseHeader() ? 1 : 0, GHistoryExportConditionExportFieldEntity.from(exportCondition.getExportFields()));
		}
		return null;
	}

	/**
	 * 履歴IDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getHistoryId();

	/**
	 * ヘッダー利用有無を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ヘッダー利用有無
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getUseHeader();

	/**
	 * アプリケーションIDを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param applicationId アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setApplicationId(String applicationId);

	/**
	 * データソースIDを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setDatasourceId(String datasourceId);

	/**
	 * 出力項目（出力条件用）のリストを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param exportFields 出力項目（出力条件用）のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setExportFields(List<GHistoryExportConditionExportFieldEntity> exportFields);

	/**
	 * ファイルタイプを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param fileType ファイルタイプ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFileType(String fileType);

	/**
	 * 履歴IDを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryId(String historyId);

	/**
	 * ヘッダー利用有無を設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param useHeader ヘッダー利用有無
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setUseHeader(int useHeader);

	/**
	 * {@link GHistoryExportConditionEntity}から{@link GExportCondition}へ変換します. <br>
	 * 
	 * @create 2023/10/25
	 * @param historyExportConditionEntity 出力条件
	 * @return {@link GExportCondition}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static GExportCondition to(GHistoryExportConditionEntity historyExportConditionEntity) {
		if (historyExportConditionEntity != null) {
			GExportFileTypeMapper fileTypeResolver = GFrameworkUtils.getComponent(GExportFileTypeMapper.class);
			return new GExportConditionImpl(null, historyExportConditionEntity.getUseHeader() == 1,
				fileTypeResolver.get(historyExportConditionEntity.getFileType()),
				GHistoryExportConditionExportFieldEntity
					.to((List<GHistoryExportConditionExportFieldEntity>) historyExportConditionEntity.getExportFields()),
				historyExportConditionEntity.getDatasourceId());
		}
		return null;
	}

}
