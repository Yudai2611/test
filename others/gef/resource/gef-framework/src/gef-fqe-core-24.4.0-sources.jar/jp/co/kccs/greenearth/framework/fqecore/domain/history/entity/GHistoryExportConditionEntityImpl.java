/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;

/**
 * 出力条件を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
@Entity(keyType = Entity.KeyType.UNIQUE, keyName = GHistoryExportConditionEntity.UNIQUE_KEY)
public class GHistoryExportConditionEntityImpl implements GHistoryExportConditionEntity {

	/** アプリケーションID */
	private String applicationId;

	/** データソースID */
	private String datasourceId;

	/** 出力項目 **/
	private List<GHistoryExportConditionExportFieldEntity> exportFields;

	/** ファイルタイプ **/
	private String fileType;

	/** 履歴ID **/
	private String historyId;

	/** ヘッダ使用有無 **/
	private int useHeader;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryExportConditionEntityImpl() {
	}

	/**
	 * コンストラクターです.
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @param fileType ファイルタイプ
	 * @param useHeader ヘッダー利用有無
	 * @param exportFields 出力項目
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryExportConditionEntityImpl(String datasourceId, String fileType, int useHeader,
											List<GHistoryExportConditionExportFieldEntity> exportFields) {
		this.datasourceId = datasourceId;
		this.fileType = fileType;
		this.useHeader = useHeader;
		this.exportFields = exportFields;
		this.applicationId = GFqeContextHolder.getContext().getApplicationId();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#getApplicationId()
	 */
	@Override
	@Column(name = APPLICATION_ID)
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#getDatasourceId()
	 */
	@Override
	@Column(name = DATASOURCE_ID)
	public String getDatasourceId() {
		return datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#getFileType()
	 */
	@Override
	@Column(name = FILE_TYPE)
	public String getFileType() {
		return fileType;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#getExportFields()
	 */
	@Override
	public List<GHistoryExportConditionExportFieldEntity> getExportFields() {
		return exportFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#getHistoryId()
	 */
	@Override
	@Column(name = HISTORY_ID)
	public String getHistoryId() {
		return historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#getUseHeader()
	 */
	@Override
	@Column(name = USE_HEADER)
	public int getUseHeader() {
		return useHeader;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#setApplicationId(String)
	 */
	@Override
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#setDatasourceId(String)
	 */
	@Override
	public void setDatasourceId(String datasourceId) {
		this.datasourceId = datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#setExportFields(List)
	 */
	@Override
	public void setExportFields(List<GHistoryExportConditionExportFieldEntity> exportFields) {
		this.exportFields = exportFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#setFileType(String)
	 */
	@Override
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#setHistoryId(String)
	 */
	@Override
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryExportConditionEntity#setUseHeader(int)
	 */
	@Override
	public void setUseHeader(int useHeader) {
		this.useHeader = useHeader;
	}
}
