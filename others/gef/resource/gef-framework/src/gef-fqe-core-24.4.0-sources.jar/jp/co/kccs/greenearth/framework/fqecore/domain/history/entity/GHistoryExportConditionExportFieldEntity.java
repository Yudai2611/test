/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportConditionExportField;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportConditionExportFieldImpl;

/**
 * 出力項目（出力条件用）を格納するクラスです.  <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryExportConditionExportFieldEntity {

	/** アプリケーションID */
	String APPLICATION_ID = "ApplicationId";

	/** エンティティ名 */
	String ENTITY_NAME = "HISTORY_EXPORT_CONDITION_EXPORT_FIELD";

	/** フィールドID */
	String FIELD_ID = "FieldId";

	/** フィールドインデックス */
	String FIELD_INDEX = "FieldIndex";

	/** 出力フラグ */
	String USE_FIELD = "UseField";

	/** 履歴ID */
	String HISTORY_ID = "HistoryId";

	/** ユニークキー */
	String UNIQUE_KEY = "UkHistoryExportConditionExportField";

	/**
	 * アプリケーションIDを取得します.
	 * 
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * 出力フラグを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 出力フラグ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getUseField();

	/**
	 * フィールドIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

	/**
	 * フィールドインデックスを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィールドインデックス
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getFieldIndex();

	/**
	 * 履歴IDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getHistoryId();

	/**
	 * {@link GExportConditionExportField}のリストから{@link GHistoryExportConditionExportFieldEntity}のリストに変換します.
	 * 
	 * @create 2023/10/25
	 * @param exportFields 出力項目
	 * @return {@link GHistoryExportConditionExportFieldEntity}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GHistoryExportConditionExportFieldEntity> from(List<GExportConditionExportField> exportFields) {
		if (exportFields != null) {
			List<GHistoryExportConditionExportFieldEntity> exportFieldEntities = new ArrayList<>();
			for (int i = 0; i < exportFields.size(); i++) {
				GExportConditionExportField exportField = exportFields.get(i);
				exportFieldEntities
					.add(new GHistoryExportConditionExportFieldEntityImpl(exportField.getFieldId(), i, exportField.isUseField() ? 1 : 0));
			}
			return exportFieldEntities;
		}
		return Collections.emptyList();
	}

	/**
	 * アプリケーションIDを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param applicationId アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setApplicationId(String applicationId);

	/**
	 * 出力フラグを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param useField 出力フラグ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setUseField(int useField);

	/**
	 * フィールドIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldId(String fieldId);

	/**
	 * フィールドインデックスを設定します.  <br>
	 * 
	 * @create 2023/10/25
	 * @param index フィールドインデックス
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldIndex(int index);

	/**
	 * 履歴IDを設定します. <br>
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryId(String historyId);

	/**
	 * {@link GHistoryExportConditionExportFieldEntity}のリストから{@link GExportConditionExportField}のリストに変換します.<br>
	 *   <br>
	 * @create 2023/10/25
	 * @param exportFieldEntities 出力項目
	 * @return {@link GExportConditionExportField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GExportConditionExportField> to(List<GHistoryExportConditionExportFieldEntity> exportFieldEntities) {
		if (exportFieldEntities != null) {
			List<GExportConditionExportField> exportFields = new ArrayList<>();
			Collections.sort(exportFieldEntities, Comparator.comparingInt(GHistoryExportConditionExportFieldEntity::getFieldIndex));

			for (GHistoryExportConditionExportFieldEntity exportConditionExportFieldEntity : exportFieldEntities) {
				exportFields.add(new GExportConditionExportFieldImpl(exportConditionExportFieldEntity.getFieldId(),
					exportConditionExportFieldEntity.getUseField() == 1));
			}
			return exportFields;
		}
		return Collections.emptyList();
	}
}
