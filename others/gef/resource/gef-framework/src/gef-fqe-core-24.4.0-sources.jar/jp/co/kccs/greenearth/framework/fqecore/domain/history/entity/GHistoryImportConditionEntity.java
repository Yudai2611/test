/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionImpl;

/**
 * 取得条件を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryImportConditionEntity {

	/** アプリケーションID */
	String APPLICATION_ID = "ApplicationId";

	/** データソースID */
	String DATASOURCE_ID = "DatasourceId";

	/** エンティティ名 */
	String ENTITY_NAME = "HISTORY_IMPORT_CONDITION";

	/** <code>FilterFields</code>の外部キー */
	String FILTER_FIELDS = "FkFilterFields";

	/** 履歴ID */
	String HISTORY_ID = "HistoryId";

	/** <code>ImportFields</code>の外部キー */
	String IMPORT_FIELDS = "FkImportFields";

	/** <code>SortFields</code>の外部キー */
	String SORT_FIELDS = "FkSortFields";

	/** ユニークキー */
	String UNIQUE_KEY = "UkHistoryImportCondition";

	/**
	 * アプリケーションIDを取得します.
	 * 
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * データソースIDを取得します.
	 * 
	 * @create 2023/10/25
	 * @return データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getDatasourceId();

	/**
	 * 絞り込み条件を取得します.
	 * 
	 * @create 2023/10/25
	 * @return {@link GHistoryImportConditionFilterFieldEntity}のリスト 絞り込み条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GHistoryImportConditionFilterFieldEntity> getFilterFields();

	String getHistoryId();

	/**
	 * 取得項目条件を取得します.
	 * 
	 * @create 2023/10/25
	 * @return {@link GHistoryImportConditionImportFieldEntity}のリスト 取得項目条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GHistoryImportConditionImportFieldEntity> getImportFields();

	/**
	 * ソート条件を取得します.
	 * 
	 * @create 2023/10/25
	 * @return {@link GHistoryImportConditionSortFieldEntity}のリスト ソート条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GHistoryImportConditionSortFieldEntity> getSortFields();

	/**
	 * {@link GImportCondition}から{@link GHistoryImportConditionEntity}へ変換します.
	 * 
	 * @create 2023/10/25
	 * @param importCondition 取得条件
	 * @return {@link GHistoryImportConditionEntity}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static GHistoryImportConditionEntity from(GImportCondition importCondition) {
		if (importCondition != null) {
			return new GHistoryImportConditionEntityImpl(importCondition.getDatasourceId(),
				GHistoryImportConditionImportFieldEntity.from(importCondition.getImportFields()),
				GHistoryImportConditionFilterFieldEntity.from(importCondition.getFilterFields()),
				GHistoryImportConditionSortFieldEntity.from(importCondition.getSortFields()));
		}
		return null;
	}

	/**
	 * アプリケーションIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param applicationId アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setApplicationId(String applicationId);

	/**
	 * データソースIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setDatasourceId(String datasourceId);

	/**
	 * 絞り込み条件を設定します.
	 * 
	 * @create 2023/10/25
	 * @param filterFields 絞り込み条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFilterFields(List<GHistoryImportConditionFilterFieldEntity> filterFields);

	/**
	 * 履歴IDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryId(String historyId);

	/**
	 * 取得項目条件を設定します.
	 * 
	 * @create 2023/10/25
	 * @param improtFileds 取得項目条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setImportFields(List<GHistoryImportConditionImportFieldEntity> improtFileds);

	/**
	 * ソート条件を設定します.
	 * 
	 * @create 2023/10/25
	 * @param sortFields ソート条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setSortFields(List<GHistoryImportConditionSortFieldEntity> sortFields);

	/**
	 * {@link GHistoryImportConditionEntity}から{@link GImportCondition}へ変換します.
	 * 
	 * @create 2023/10/25
	 * @param historyImportConditionEntity 取得条件
	 * @return {@link GImportCondition}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static GImportCondition to(GHistoryImportConditionEntity historyImportConditionEntity) {
		if (historyImportConditionEntity != null) {
			List<GHistoryImportConditionImportFieldEntity> importConditionImportFieldEntities =
				(List<GHistoryImportConditionImportFieldEntity>) Objects.requireNonNullElse(historyImportConditionEntity.getImportFields(),
					Collections.emptyList());
			List<GHistoryImportConditionFilterFieldEntity> importConditionFilterFieldEntities =
				(List<GHistoryImportConditionFilterFieldEntity>) Objects.requireNonNullElse(historyImportConditionEntity.getFilterFields(),
					Collections.emptyList());
			List<GHistoryImportConditionSortFieldEntity> importConditionSortFieldEntities =
				(List<GHistoryImportConditionSortFieldEntity>) Objects.requireNonNullElse(historyImportConditionEntity.getSortFields(),
					Collections.emptyList());
			return new GImportConditionImpl(historyImportConditionEntity.getDatasourceId(),
				GHistoryImportConditionImportFieldEntity.to(importConditionImportFieldEntities),
				GHistoryImportConditionFilterFieldEntity.to(importConditionFilterFieldEntities),
				GHistoryImportConditionSortFieldEntity.to(importConditionSortFieldEntities));
		}
		return null;
	}

}
