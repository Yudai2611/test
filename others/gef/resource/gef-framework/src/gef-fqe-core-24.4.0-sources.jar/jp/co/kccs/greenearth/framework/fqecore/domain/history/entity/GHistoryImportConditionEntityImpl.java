/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;

/**
 * 取得条件を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
@Entity(keyType = Entity.KeyType.UNIQUE, keyName = GHistoryImportConditionEntity.UNIQUE_KEY)
public class GHistoryImportConditionEntityImpl implements GHistoryImportConditionEntity {

	/** アプリケーションID */
	private String applicationId;

	/** データソースID */
	private String datasourceId;

	/** 絞り込み条件 */
	private List<GHistoryImportConditionFilterFieldEntity> filterFields;

	/** 履歴ID */
	private String historyId;

	/** 取得項目条件 */
	private List<GHistoryImportConditionImportFieldEntity> importFields;

	/** ソート条件 */
	private List<GHistoryImportConditionSortFieldEntity> sortFields;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryImportConditionEntityImpl() {
	}

	/**
	 * コンストラクターです.
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @param importFields 取得項目条件
	 * @param filterFields 絞り込み条件
	 * @param sortFields ソート条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryImportConditionEntityImpl(String datasourceId, List<GHistoryImportConditionImportFieldEntity> importFields,
											List<GHistoryImportConditionFilterFieldEntity> filterFields,
											List<GHistoryImportConditionSortFieldEntity> sortFields) {
		this.applicationId = GFqeContextHolder.getContext().getApplicationId();
		this.datasourceId = datasourceId;
		this.importFields = (List<GHistoryImportConditionImportFieldEntity>) importFields;
		this.filterFields = (List<GHistoryImportConditionFilterFieldEntity>) filterFields;
		this.sortFields = (List<GHistoryImportConditionSortFieldEntity>) sortFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#getApplicationId()
	 */
	@Override
	@Column(name = GHistoryExportConditionEntity.APPLICATION_ID)
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#getDatasourceId()
	 */
	@Override
	@Column(name = DATASOURCE_ID)
	public String getDatasourceId() {
		return datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#getFilterFields()
	 */
	@Override
	public List<GHistoryImportConditionFilterFieldEntity> getFilterFields() {
		return filterFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#getHistoryId()
	 */
	@Override
	@Column(name = HISTORY_ID)
	public String getHistoryId() {
		return historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#getImportFields()
	 */
	@Override
	public List<GHistoryImportConditionImportFieldEntity> getImportFields() {
		return importFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#getSortFields()
	 */
	@Override
	public List<GHistoryImportConditionSortFieldEntity> getSortFields() {
		return sortFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#setApplicationId(String)
	 */
	@Override
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#setDatasourceId(String)
	 */
	@Override
	public void setDatasourceId(String datasourceId) {
		this.datasourceId = datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#setFilterFields(List)
	 */
	@Override
	public void setFilterFields(List<GHistoryImportConditionFilterFieldEntity> filterFields) {
		this.filterFields = (List<GHistoryImportConditionFilterFieldEntity>) filterFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#setImportFields(List)
	 */
	@Override
	public void setImportFields(List<GHistoryImportConditionImportFieldEntity> importFields) {
		this.importFields = (List<GHistoryImportConditionImportFieldEntity>) importFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#setHistoryId(String)
	 */
	@Override
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionEntity#setSortFields(List)
	 */
	@Override
	public void setSortFields(List<GHistoryImportConditionSortFieldEntity> sortFields) {
		this.sortFields = (List<GHistoryImportConditionSortFieldEntity>) sortFields;
	}
}
