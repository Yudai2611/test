/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterFieldGroup;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterFieldGroupImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterFieldImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GSqlQueryOperator;

/**
 * 絞り込み条件を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryImportConditionFilterFieldEntity {

	/** アプリケーションID */
	String APPLICATION_ID = "ApplicationId";

	/** エンティティ名 */
	String ENTITY_NAME = "HISTORY_IMPORT_CONDITION_FILTER_FIELD";

	/** フィールドID */
	String FIELD_ID = "FieldId";

	/** AND条件間の順位 */
	String FIELD_INDEX = "FieldIndex";

	/** OR条件間の順位 */
	String GROUP_INDEX = "GroupIndex";

	/** 履歴ID */
	String HISTORY_ID = "HistoryId";

	/** 演算子 */
	String OPERATOR = "Operator";

	/** ユニークキー */
	String UNIQUE_KEY = "UkHistoryImportConditionFilterField";

	/** 条件値 */
	String VALUE = "Value";

	/**
	 * アプリケーションIDを取得します.
	 *
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * 履歴ID を取得します.
	 *
	 * @create 2023/10/25
	 * @return 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getHistoryId();

	/**
	 * フィールドIDを取得します.
	 *
	 * @create 2023/10/25
	 * @return フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

	/**
	 * OR条件間における、本条件の順番を取得します.
	 *
	 * @create 2023/10/25
	 * @return OR条件順位
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getGroupIndex();

	/**
	 * AND条件間における、本条件の順番を取得します.
	 *
	 * @create 2023/10/25
	 * @return AND条件順位
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getFieldIndex();

	/**
	 * 演算子を取得します.
	 *
	 * @create 2023/10/25
	 * @return 演算子を示すパラメータ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getOperator();

	/**
	 * 条件条件値を取得します.
	 *
	 * @create 2023/10/25
	 * @return 条件条件値
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getValue();

	/**
	 * {@link GImportConditionFilterFieldGroup}のリストから{@link GHistoryImportConditionFilterFieldEntity}のリストに変換します.
	 * 
	 * @create 2023/10/25
	 * @param importConditionFilterFields 絞り込み条件
	 * @return {@link GHistoryImportConditionFilterFieldEntity}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GHistoryImportConditionFilterFieldEntity> from(List<GImportConditionFilterFieldGroup> importConditionFilterFields) {
		if (importConditionFilterFields != null) {
			List<GHistoryImportConditionFilterFieldEntity> importConditionFilterFieldEntities = new ArrayList<>();
			for (int i = 0; i < importConditionFilterFields.size(); i++) {
				GImportConditionFilterFieldGroup importConditionFilterFieldGroup = importConditionFilterFields.get(i);
				for (int j = 0; j < importConditionFilterFieldGroup.getFilterFields().size(); j++) {
					GImportConditionFilterField filterField = importConditionFilterFieldGroup.getFilterFields().get(j);
					importConditionFilterFieldEntities.add(new GHistoryImportConditionFilterFieldEntityImpl(filterField.getFieldId(), i,
						filterField.getOperator().getInternalParam(), j, String.join(System.lineSeparator(), filterField.getValue())));
				}
			}
			return importConditionFilterFieldEntities;
		}
		return Collections.emptyList();
	}

	/**
	 * アプリケーションIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param applicationId アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setApplicationId(String applicationId);

	/**
	 * フィールドIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldId(String fieldId);

	/**
	 * AND条件間の順位を設定します.
	 * 
	 * @create 2023/10/25
	 * @param index AND条件間の順位
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldIndex(int index);

	/**
	 * OR条件間の順位を設定します.
	 * 
	 * @create 2023/10/25
	 * @param index OR条件間の順位
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setGroupIndex(int index);

	/**
	 * 履歴IDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryId(String historyId);

	/**
	 * 演算子を設定します.
	 * 
	 * @create 2023/10/25
	 * @param operator 演算子
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setOperator(int operator);

	/**
	 * 条件値を設定します.
	 * 
	 * @create 2023/10/25
	 * @param value 条件値
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setValue(String value);

	/**
	 * {@link GHistoryImportConditionFilterFieldEntity}のリストから{@link GImportConditionFilterFieldGroup}のリストに変換します.
	 * 
	 * @create 2023/10/25
	 * @param filterFieldEntities 絞り込み条件
	 * @return {@link GImportConditionFilterFieldGroup}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GImportConditionFilterFieldGroup> to(List<GHistoryImportConditionFilterFieldEntity> filterFieldEntities) {
		if (filterFieldEntities != null) {
			List<GImportConditionFilterFieldGroup> filterFieldsList = new ArrayList<>();
			filterFieldEntities.sort(Comparator.comparingInt(GHistoryImportConditionFilterFieldEntity::getGroupIndex)
				.thenComparing(GHistoryImportConditionFilterFieldEntity::getFieldIndex));
			for (GHistoryImportConditionFilterFieldEntity filterFieldEntity : filterFieldEntities) {
				List<GImportConditionFilterField> temp = null;
				if (filterFieldsList.size() > filterFieldEntity.getGroupIndex()) {
					temp = filterFieldsList.get(filterFieldEntity.getGroupIndex()).getFilterFields();
				} else {
					temp = new ArrayList<>();
					filterFieldsList.add(filterFieldEntity.getGroupIndex(), new GImportConditionFilterFieldGroupImpl(temp));
				}
				temp.add(filterFieldEntity.getFieldIndex(),
					new GImportConditionFilterFieldImpl(filterFieldEntity.getFieldId(),
						Arrays.stream(filterFieldEntity.getValue() == null ? new String[] {}
							: filterFieldEntity.getValue().split(System.lineSeparator(), -1)).collect(Collectors.toList()),
						GSqlQueryOperator.of(filterFieldEntity.getOperator())));
			}
			return filterFieldsList;
		}
		return Collections.emptyList();
	}

}
