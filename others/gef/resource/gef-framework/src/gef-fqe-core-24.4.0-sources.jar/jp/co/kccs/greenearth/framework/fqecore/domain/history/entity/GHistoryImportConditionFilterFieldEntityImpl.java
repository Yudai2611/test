/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;

/**
 * 絞り込み条件を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
@Entity(keyType = Entity.KeyType.UNIQUE, keyName = GHistoryImportConditionFilterFieldEntity.UNIQUE_KEY)
public class GHistoryImportConditionFilterFieldEntityImpl implements GHistoryImportConditionFilterFieldEntity {

	/** アプリケーションID **/
	private String applicationId;

	/** フィールドID **/
	private String fieldId;

	/** AND条件間の順位 **/
	private int fieldIndex;

	/** OR条件間の順位 **/
	private int groupIndex;

	/** 履歴ID **/
	private String historyId;

	/** 演算子 **/
	private int operator;

	/** 条件値 **/
	private String value;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryImportConditionFilterFieldEntityImpl() {
	}

	/**
	 * コンストラクターです.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @param groupIndex OR条件間の順位
	 * @param operator 演算子
	 * @param fieldIndex AND条件間の順位
	 * @param value 条件値
	 * @author KCCS 200450201
	 * @since 23.10.0
	 */
	public GHistoryImportConditionFilterFieldEntityImpl(String fieldId, int groupIndex, int operator, int fieldIndex, String value) {
		this.applicationId = GFqeContextHolder.getContext().getApplicationId();
		this.fieldId = fieldId;
		this.groupIndex = groupIndex;
		this.operator = operator;
		this.fieldIndex = fieldIndex;
		this.value = value;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#getApplicationId()
	 */
	@Override
	@Column(name = APPLICATION_ID)
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#getFieldId()
	 */
	@Override
	@Column(name = FIELD_ID)
	public String getFieldId() {
		return fieldId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#getFieldIndex()
	 */
	@Override
	@Column(name = FIELD_INDEX)
	public int getFieldIndex() {
		return fieldIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#getGroupIndex()
	 */
	@Override
	@Column(name = GROUP_INDEX)
	public int getGroupIndex() {
		return groupIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#getHistoryId()
	 */
	@Override
	@Column(name = HISTORY_ID)
	public String getHistoryId() {
		return historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#getOperator()
	 */
	@Override
	@Column(name = OPERATOR)
	public int getOperator() {
		return operator;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#getValue()
	 */
	@Override
	@Column(name = VALUE)
	public String getValue() {
		return value;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#setApplicationId(String)
	 */
	@Override
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#setFieldId(String)
	 */
	@Override
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#setFieldIndex(int)
	 */
	@Override
	public void setFieldIndex(int fieldIndex) {
		this.fieldIndex = fieldIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#setGroupIndex(int)
	 */
	@Override
	public void setGroupIndex(int groupIndex) {
		this.groupIndex = groupIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#setHistoryId(String)
	 */
	@Override
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#setOperator(int)
	 */
	@Override
	public void setOperator(int operator) {
		this.operator = operator;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionFilterFieldEntity#setValue(String)
	 */
	@Override
	public void setValue(String value) {
		this.value = value;
	}
}
