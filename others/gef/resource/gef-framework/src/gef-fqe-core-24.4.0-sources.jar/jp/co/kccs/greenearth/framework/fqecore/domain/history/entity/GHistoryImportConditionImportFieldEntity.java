/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionImportField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionImportFieldImpl;

/**
 * 取得項目を格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryImportConditionImportFieldEntity {

	/** アプリケーションID **/
	String APPLICATION_ID = "ApplicationId";

	/** エンティティ名 */
	String ENTITY_NAME = "HISTORY_IMPORT_CONDITION_IMPORT_FIELD";

	/** フィールドID */
	String FIELD_ID = "FieldId";

	/** フィールドインデックス */
	String FIELD_INDEX = "FieldIndex";

	/** 出力フラグ */
	String USE_FIELD = "UseField";

	/** 履歴ID */
	String HISTORY_ID = "HistoryId";

	/** ユニークキー */
	String UNIQUE_KEY = "UkHistoryImportConditionImportField";

	/**
	 * アプリケーションIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * 出力フラグを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 出力フラグ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getUseField();

	/**
	 * フィールドIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

	/**
	 * フィールドインデックスを取得します .<br>
	 *
	 * @create 2023/10/25
	 * @return フィールドインデックス
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getFieldIndex();

	/**
	 * 履歴IDを取得します.
	 * 
	 * @create 2023/10/25
	 * @return 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getHistoryId();

	/**
	 * {@link GImportConditionImportField}のリストから{@link GHistoryImportConditionImportFieldEntity}のリストに変換します.
	 * 
	 * @create 2023/10/25
	 * @param importFields 取得項目
	 * @return {@link GHistoryImportConditionImportFieldEntity}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GHistoryImportConditionImportFieldEntity> from(List<GImportConditionImportField> importFields) {
		if (importFields != null) {
			List<GHistoryImportConditionImportFieldEntity> importConditionImportFieldEntities = new ArrayList<>();
			for (int i = 0; i < importFields.size(); i++) {
				GImportConditionImportField importField = importFields.get(i);
				importConditionImportFieldEntities
					.add(new GHistoryImportConditionImportFieldEntityImpl(importField.getFieldId(), i, importField.isUseField() ? 1 : 0));
			}
			return importConditionImportFieldEntities;
		}
		return Collections.emptyList();
	}

	/**
	 * アプリケーションIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param applicationId アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setApplicationId(String applicationId);

	/**
	 * 出力フラグを設定します.
	 * 
	 * @create 2023/10/25
	 * @param useField 出力フラグ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setUseField(int useField);

	/**
	 * フィールドIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldId(String fieldId);

	/**
	 * フィールドインデックスを設定します.
	 * 
	 * @create 2023/10/25
	 * @param index フィールドインデックス
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldIndex(int index);

	/**
	 * 履歴IDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryId(String historyId);

	/**
	 * {@link GHistoryImportConditionImportFieldEntity}からのリスト{@link GImportConditionImportField}のリストに変換します.
	 * 
	 * @create 2023/10/25
	 * @param importFieldEntities 取得項目
	 * @return {@link GImportConditionImportField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GImportConditionImportField> to(List<GHistoryImportConditionImportFieldEntity> importFieldEntities) {
		if (importFieldEntities != null) {
			List<GImportConditionImportField> importFields = new ArrayList<>();
			importFieldEntities.sort(Comparator.comparingInt(GHistoryImportConditionImportFieldEntity::getFieldIndex));

			for (GHistoryImportConditionImportFieldEntity importConditionImportField : importFieldEntities) {
				importFields.add(new GImportConditionImportFieldImpl(importConditionImportField.getFieldId(),
					importConditionImportField.getUseField() == 1));
			}
			return importFields;
		}
		return Collections.emptyList();
	}

}
