/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;

/**
 * 取得項目を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
@Entity(keyType = Entity.KeyType.UNIQUE, keyName = GHistoryImportConditionImportFieldEntity.UNIQUE_KEY)
public class GHistoryImportConditionImportFieldEntityImpl implements GHistoryImportConditionImportFieldEntity {

	/** アプリケーションID **/
	private String applicationId;

	/** 出力フラグ */
	private int useField;

	/** フィールドID */
	private String fieldId;

	/** フィールドインデックス */
	private int fieldIndex;

	/** 履歴ID */
	private String historyId;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryImportConditionImportFieldEntityImpl() {
	}

	/**
	 * コンストラクターです.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @param fieldIndex フィールドインデックス
	 * @param useField 出力フラグ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryImportConditionImportFieldEntityImpl(String fieldId, int fieldIndex, int useField) {
		this.applicationId = GFqeContextHolder.getContext().getApplicationId();
		this.fieldId = fieldId;
		this.fieldIndex = fieldIndex;
		this.useField = useField;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#getApplicationId()
	 */
	@Override
	@Column(name = APPLICATION_ID)
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#getFieldId()
	 */
	@Override
	@Column(name = FIELD_ID)
	public String getFieldId() {
		return fieldId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#getFieldIndex()
	 */
	@Override
	@Column(name = FIELD_INDEX)
	public int getFieldIndex() {
		return fieldIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#getUseField()
	 */
	@Override
	@Column(name = USE_FIELD)
	public int getUseField() {
		return useField;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#getHistoryId()
	 */
	@Override
	@Column(name = HISTORY_ID)
	public String getHistoryId() {
		return historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#setApplicationId(String)
	 */
	@Override
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#setUseField(int)
	 */
	@Override
	public void setUseField(int useField) {
		this.useField = useField;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#setFieldId(String) 
	 */
	@Override
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#setFieldIndex(int) 
	 */
	@Override
	public void setFieldIndex(int fieldIndex) {
		this.fieldIndex = fieldIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionImportFieldEntity#setHistoryId(String)
	 */
	@Override
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}
}
