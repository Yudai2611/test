/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFieldSortOrder;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionSortField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionSortFieldImpl;

/**
 * ソート条件を格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GHistoryImportConditionSortFieldEntity {

	/** アプリケーションID */
	String APPLICATION_ID = "ApplicationId";

	/** エンティティ名 */
	String ENTITY_NAME = "HISTORY_IMPORT_CONDITION_SORT_FIELD";

	/** フィールドID */
	String FIELD_ID = "FieldId";

	/** 履歴ID */
	String HISTORY_ID = "HistoryId";

	/** ソート優先順位 */
	String FIELD_INDEX = "FieldIndex";

	/** ソート順 */
	String SORT_ORDER = "SortOrder";

	/** ユニークキー */
	String UNIQUE_KEY = "UkHistoryImportConditionSortField";

	/**
	 * アプリケーションIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getApplicationId();

	/**
	 * フィールドIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

	/**
	 * 履歴IDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getHistoryId();

	/**
	 * ソート優先順位を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ソート優先順位
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int getFieldIndex();

	/**
	 * ソート順を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ソート順
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getSortOrder();

	/**
	 * {@link GImportConditionSortField}のリストから{@link GHistoryImportConditionSortFieldEntity}のリストに変換します. <br>
	 * 
	 * @create 2023/10/25
	 * @param sortFields ソート条件
	 * @return {@link GHistoryImportConditionSortFieldEntity}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GHistoryImportConditionSortFieldEntity> from(List<GImportConditionSortField> sortFields) {
		if (sortFields != null) {
			List<GHistoryImportConditionSortFieldEntity> sortFieldEntities = new ArrayList<>();
			for (int i = 0; i < sortFields.size(); i++) {
				GImportConditionSortField sortField = sortFields.get(i);
				sortFieldEntities
					.add(new GHistoryImportConditionSortFieldEntityImpl(sortField.getFieldId(), sortField.getOrder().toString(), i));
			}
			return sortFieldEntities;
		}
		return Collections.emptyList();
	}

	/**
	 * アプリケーションIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param applicationId アプリケーションID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setApplicationId(String applicationId);

	/**
	 * フィールドIDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldId(String fieldId);

	/**
	 * 履歴IDを設定します.
	 * 
	 * @create 2023/10/25
	 * @param historyId 履歴ID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setHistoryId(String historyId);

	/**
	 * ソート優先順位を設定します.
	 * 
	 * @create 2023/10/25
	 * @param index ソート優先順位
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setFieldIndex(int index);

	/**
	 * ソート順を設定します.
	 * 
	 * @create 2023/10/25
	 * @param sortOrder ソート順
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void setSortOrder(String sortOrder);

	/**
	 * {@link <HistoryImportConditionSortFieldEntity}のリストから{@link GImportConditionSortField}のリストに変換します.
	 * 
	 * @create 2023/10/25
	 * @param sortFieldEntities ソート条件
	 * @return {@link GImportConditionSortField}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static List<GImportConditionSortField> to(List<GHistoryImportConditionSortFieldEntity> sortFieldEntities) {
		if (sortFieldEntities != null) {
			List<GImportConditionSortField> importConditionSortFields = new ArrayList<>();
			sortFieldEntities.sort(Comparator.comparingInt(GHistoryImportConditionSortFieldEntity::getFieldIndex));
			for (GHistoryImportConditionSortFieldEntity sortFieldEntity : sortFieldEntities) {
				importConditionSortFields.add(new GImportConditionSortFieldImpl(sortFieldEntity.getFieldId(),
					GImportConditionFieldSortOrder.valueOf(sortFieldEntity.getSortOrder())));
			}
			return importConditionSortFields;
		}
		return Collections.emptyList();
	}

}
