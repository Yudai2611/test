/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.history.entity;

import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;

/**
 * ソート条件を格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
@Entity(keyType = Entity.KeyType.UNIQUE, keyName = GHistoryImportConditionSortFieldEntity.UNIQUE_KEY)
public class GHistoryImportConditionSortFieldEntityImpl implements GHistoryImportConditionSortFieldEntity {

	/** アプリケーションID */
	private String applicationId;

	/** フィールドID */
	private String fieldId;

	/** 履歴ID */
	private String historyId;

	/** ソート優先順位 */
	private int fieldIndex;

	/** ソート順 */
	private String sortOrder;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryImportConditionSortFieldEntityImpl() {
	}

	/**
	 * コンストラクターです.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @param sortOrder ソート順
	 * @param fieldIndex ソート優先順位
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GHistoryImportConditionSortFieldEntityImpl(String fieldId, String sortOrder, int fieldIndex) {
		this.applicationId = GFqeContextHolder.getContext().getApplicationId();
		this.fieldId = fieldId;
		this.sortOrder = sortOrder;
		this.fieldIndex = fieldIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#getApplicationId()
	 */
	@Override
	@Column(name = APPLICATION_ID)
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#getFieldId()
	 */
	@Override
	@Column(name = FIELD_ID)
	public String getFieldId() {
		return fieldId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#getHistoryId()
	 */
	@Override
	@Column(name = HISTORY_ID)
	public String getHistoryId() {
		return historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#getFieldIndex() ()
	 */
	@Override
	@Column(name = FIELD_INDEX)
	public int getFieldIndex() {
		return fieldIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#getOrder()
	 */
	@Override
	@Column(name = SORT_ORDER)
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#setApplicationId(String)
	 */
	@Override
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#setFieldId(String)
	 */
	@Override
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#setHistoryId(String)
	 */
	@Override
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#setFieldIndex(int)
	 */
	@Override
	public void setFieldIndex(int fieldIndex) {
		this.fieldIndex = fieldIndex;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GHistoryImportConditionSortFieldEntity#setOrder(String)
	 */
	@Override
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

}
