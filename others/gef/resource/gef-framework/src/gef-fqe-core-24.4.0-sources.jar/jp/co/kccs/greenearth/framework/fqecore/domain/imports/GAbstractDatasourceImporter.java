/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.commons.db.GDataSourceConnectionManager;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceField;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldImpl;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceImpl;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceRow;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceRowImpl;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;

/**
 * 出力するデータを読込みます.　<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GAbstractDatasourceImporter implements GDatasourceImporter {

	/** データベース接続のコネクション */
	Connection connection = null;

	/**
	 * {@inheritDoc}
	 *
	 * @see GDatasourceImporter#read(GImportCondition)
	 */
	@Override
	public GDatasource read(GImportCondition importCondition) {
		validateIfReadIsEligible(importCondition);
		GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata = null;
		try {
			datasourceMetadata = GFrameworkUtils.getComponent(GDatasourceMetadataService.class).lookupById(importCondition.getDatasourceId());
		} catch (GFrameworkException e) {
			return null;
		}
		if (Objects.nonNull(datasourceMetadata)) {
			try (GRecordSet records = readInternal(importCondition, datasourceMetadata);) {
				return new GDatasourceImpl(datasourceMetadata,
					convertTo(records, importCondition, datasourceMetadata));
			} catch (SQLException e) {
				throw new GFrameworkException("Unable to load data.");
			} finally {
				GConnectionManager connectionManager = GDataSourceConnectionManager.getInstance();
				try {
					connectionManager.releaseConnection(connection);
				} catch (SQLException e) {
					throw new GFrameworkException("Release connection is failed.");
				}
			}
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GDatasourceImporter#getSize(GImportCondition)
	 */
	@Override
	public int getSize(GImportCondition importCondition) {
		validateIfReadIsEligible(importCondition);
		GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata = null;
		try {
			datasourceMetadata = GFrameworkUtils.getComponent(GDatasourceMetadataService.class).lookupById(importCondition.getDatasourceId());
		} catch (GFrameworkException e) {
			return 0;
		}
		if (Objects.nonNull(datasourceMetadata)) {
			try {
				return getSizeInternal(importCondition, datasourceMetadata);
			} finally {
				GConnectionManager connectionManager = GDataSourceConnectionManager.getInstance();
				try {
					connectionManager.releaseConnection(connection);
				} catch (SQLException e) {
					throw new GFrameworkException("Release connection is failed.");
				}
			}
		}
		return 0;
	}

	/**
	 *
	 * データを読込む内部処理を行います. <br>
	 *
	 * @create 2023/10/25
	 * @param importCondition インポート条件
	 * @param datasourceMetadata データソースメタデータ
	 * @return 読込データ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected abstract GRecordSet readInternal(GImportCondition importCondition, GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata);

	/**
	 *
	 * データ件数を取得する内部処理を行います. <br>
	 *
	 * @create 2023/10/25
	 * @param importCondition インポート条件
	 * @param datasourceMetadata データソースメタデータ
	 * @return データソース件数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	protected abstract int getSizeInternal(GImportCondition importCondition, GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata);

	/**
	 *
	 * データの読込が可能かどうか、判定します. <br>
	 *
	 * @create 2023/10/25
	 * @param importCondition インポート条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected void validateIfReadIsEligible(GImportCondition importCondition) {
		Objects.requireNonNull(importCondition, "Import condition must not be null.");
		Objects.requireNonNull(importCondition.getImportFields(), "Import fields must not be null.");
		if (importCondition.getImportFields().size() == 0) {
			throw new GFrameworkException("Export fields should not be null or empty.");
		}
		validateFieldSize(importCondition.getFilterFields(), importCondition.getSortFields());
	}

	/**
	 * {@link GRecord}のリストを{@link GListData}へ変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param datasourceRecords インポートされたいデータソースのデータ
	 * @param importCondition インポート条件
	 * @param datasourceMetadata データソースメタデータ
	 * @return {@link GListData}
	 * @author KCCS dhiaz
	 * @throws SQLException
	 * @since 23.10.0
	 */
	private List<GDatasourceRow> convertTo(GRecordSet datasourceRecords, GImportCondition importCondition, GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata) throws SQLException {
		List<GDatasourceRow> datasourceFieldList = new ArrayList<>();
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap = GDatasourceUtil.toFieldMetadataMap(datasourceMetadata.getDatasourceFields());
		while (datasourceRecords.next()) {
			List<GDatasourceField> datasourceField = new ArrayList<>();

			Map<String, Object> caseInsensitiveMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

			caseInsensitiveMap.putAll(datasourceRecords.getRecord().getVariants());
			importCondition.getImportFields().forEach(field -> {
				GDatasourceFieldMetadata fieldMetadata = datasourceFieldMetadataMap.get(field.getFieldId());
				datasourceField.add(new GDatasourceFieldImpl(fieldMetadata, caseInsensitiveMap.get(fieldMetadata.getSrc())));
			});
			datasourceFieldList.add(new GDatasourceRowImpl(datasourceField));
		}
		return datasourceFieldList;
	}

	/**
	 * タブ数、フィルターフィールド、ソートフィールドが上限値に達していないか、確認します. <br>
	 *
	 * @create 2023/10/25
	 * @param filterFieldGroups {@link GImportConditionFilterFieldGroup}のリスト
	 * @param sortFields {@link GImportConditionSortField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private void validateFieldSize(List<GImportConditionFilterFieldGroup> filterFieldGroups, List<GImportConditionSortField> sortFields) {
		Objects.requireNonNull(sortFields, "Sort fields should not be null.");
		Objects.requireNonNull(filterFieldGroups, "Filter fields should not be null.");
		String sortLimitSize = GFqePropertyKey.IMPORT_SORT_LIMIT_SIZE.getPropertyValue();
		String filterGroupLimitSize = GFqePropertyKey.IMPORT_FILTER_GROUP_LIMIT_SIZE.getPropertyValue();
		String filterFieldLimitSize = GFqePropertyKey.IMPORT_FILTER_GROUP_FIELD_LIMIT_SIZE.getPropertyValue();

		if (!filterGroupLimitSize.equals("") && filterFieldGroups.size() > Integer.parseInt(filterGroupLimitSize)) {
			throw new GFrameworkException("Filter group is oversized.");
		}
		if (!filterFieldLimitSize.equals("")) {
			for (GImportConditionFilterFieldGroup filterFieldGroup : filterFieldGroups) {
				if (filterFieldGroup.getFilterFields().size() > Integer.parseInt(filterFieldLimitSize)) {
					throw new GFrameworkException("Filter fields are oversized.");
				}
			}
		}
		if (!sortLimitSize.equals("") && sortFields.size() > Integer.parseInt(sortLimitSize)) {
			throw new GFrameworkException("Sort fields are oversized.");
		}
	}
}
