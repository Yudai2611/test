/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;

/**
 * 出力するデータを読込みます. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceImporter {


	/**
	 * 出力するデータを読込みます.
	 *
	 * @create 2023/10/25
	 * @param importCondition データ取得条件{@link GImportCondition}
	 * @return 読込んだデータ {@link GDatasource}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasource read(GImportCondition importCondition);
	
	/**
	 * データの件数を取得します. <br>
	 * 
	 * @param importCondition データ取得条件{@link GImportCondition}
	 * @return データの件数
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	int getSize(GImportCondition importCondition);

	/**
	 * {@link GDatasourceImporter}を生成するファクトリです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	class Factory {

		/** {@link GDatasourceImporter}のリスト */
		private static Map<Class<GDatasourceType>, GDatasourceImporter> defaultExportReaderList = new HashMap<>();

		/**
		 * コンストラクタです. <br>
		 *
		 * @create 2023/10/25
		 * @param defaultExportReaderList {@link GDatasourceImporter}のリスト
		 * @author KCCS dhiaz
		 * @since 23.10.0
		 */
		public Factory(Map<Class<GDatasourceType>, GDatasourceImporter> defaultExportReaderList) {
			Factory.defaultExportReaderList = defaultExportReaderList;
		}

		/**
		 * {@link GDatasourceImporter}を生成します. <br>
		 * 
		 * @param datasourceType データソースメタ情報{@link GDatasourceMetadata}
		 * @return {@link GDatasourceImporter}
		 * @author KCCS dhiaz
		 * @create 2023/10/25
		 * @since 23.10.0
		 */
		public static GDatasourceImporter getInstance(GDatasourceType datasourceType) {
			GDatasourceImporter importer = defaultExportReaderList.get(datasourceType.getClass());
			if (importer != null) {
				return importer;
			}
			throw new GFrameworkException("Importer is not exist for datasource type " + datasourceType.getValue());
		}
	}
}
