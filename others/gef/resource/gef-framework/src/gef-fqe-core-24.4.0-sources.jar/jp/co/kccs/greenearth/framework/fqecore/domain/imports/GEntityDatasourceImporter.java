/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectSelect;

/**
 * 出力するデータを読込みます. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GEntityDatasourceImporter extends GAbstractDatasourceImporter {

	private GEntitySqlQueryGenerator sqlQueryGenerator;

	public GEntityDatasourceImporter() {
		sqlQueryGenerator = new GEntitySqlQueryGenerator();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GAbstractDatasourceImporter#readInternal(GImportCondition, GDatasourceMetadata) (GImportConditionImpl, GDatasourceMetadata)
	 */
	@Override
	protected GRecordSet readInternal(GImportCondition importCondition, GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata) {
		GDirectSelect query = null;
		try {
			query = sqlQueryGenerator.createSelectQuery(importCondition, datasourceMetadata.getId(), getDatabaseSourceName(datasourceMetadata.getSrc()));
		} catch (ParseException e) {
			throw new GFrameworkException(e.getMessage());
		}
		query = setLimitSize(datasourceMetadata, query);
		try {
			return query.findRecordSet(getConnection(datasourceMetadata.getSrc()));
		} catch (SQLException e) {
			throw new GFrameworkException("Failed to access database.");
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GAbstractDatasourceImporter#getSizeInternal(GImportCondition,
	 *      GDatasourceMetadata)
	 */
	@Override
	protected int getSizeInternal(GImportCondition importCondition, GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata) {
		try {
			return sqlQueryGenerator.createSelectQuery(importCondition, datasourceMetadata.getId(), getDatabaseSourceName(datasourceMetadata.getSrc())).count(getConnection(datasourceMetadata.getSrc()));
		} catch (SQLException e) {
			throw new GFrameworkException("Failed to access database.");
		} catch (ParseException e) {
			throw new GFrameworkException(e.getMessage());
		}
	}

	/**
	 * {@link Connection}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param tableName テーブル名
	 * @return {@link Connection}
	 * @throws SQLException
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	private Connection getConnection(String tableName) throws SQLException {
		connection = sqlQueryGenerator.catchConnection(getDatabaseSourceName(tableName));
		return connection;
	}

	private  String getDatabaseSourceName (String tableName) {
		return GQueryAssistants.entity(tableName).getDatabase().getDataSource();
	}
	
	/**
	 * データ出力の最大値を設定します.  <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceMetadata データソースメタ情報
	 * @return {@link GDirectSelect}
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	private GDirectSelect setLimitSize(GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata, GDirectSelect query) {
		int limitSize = (datasourceMetadata.getLimitSize() > 0 ? Math.toIntExact(datasourceMetadata.getLimitSize())
			: Integer.parseInt(GFqePropertyKey.IMPORT_LIMIT_SIZE.getPropertyValue()));
		if (limitSize <= 0) {
			return query;
		}
		return query.range(0, limitSize);
	}
}
