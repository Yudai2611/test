/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;

/**
 * スキーマを生成するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GEntitySqlQueryGenerator extends GAbstractSqlQueryGenerator {


	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	@Override
	protected String getSchema(String tableName) {
		return GQueryAssistants.entity(tableName).getDatabase().getSchema();
	}

}
