/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;

/**
 * データの取得条件を格納します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GImportCondition {
	String DATASOURCE_ID = GDatasourceMetadata.DATASOURCE_ID;
	String IMPORT_FIELDS = "importFields";
	String FILTER_FIELDS = "filterFieldGroups";
	String SORT_FIELDS = "sortFields";

	/**
	 * データソースIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getDatasourceId();

	/**
	 * データ取得検索条件{@link GImportConditionFilterFieldGroup}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データ取得検索条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GImportConditionFilterFieldGroup> getFilterFields();

	/**
	 * データ取得検索条件{@link GImportConditionImportField}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データ取得検索条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GImportConditionImportField> getImportFields();

	/**
	 * データ取得時のソート条件{@link GImportConditionSortField}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ソート条件
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GImportConditionSortField> getSortFields();
}
