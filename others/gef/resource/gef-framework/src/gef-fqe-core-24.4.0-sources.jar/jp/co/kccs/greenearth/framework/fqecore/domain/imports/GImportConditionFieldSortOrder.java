/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

/**
 * データ取得時のソート順を示すクラスです.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public enum GImportConditionFieldSortOrder {

	/** 昇順 **/
	ASC,

	/** 降順 **/
	DESC;
}
