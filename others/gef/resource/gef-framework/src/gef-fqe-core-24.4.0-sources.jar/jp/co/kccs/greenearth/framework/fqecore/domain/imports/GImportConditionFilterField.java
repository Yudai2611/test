/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;


import java.util.List;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;

/**
 * データ取得時のフィルター条件を格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GImportConditionFilterField {
	String FIELD_ID = GDatasourceFieldMetadata.FIELD_ID;
	String OPERATOR = "operator";
	String VALUE = "value";

	/**
	 * フィールドIdを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィールド名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

	/**
	 * フィールドに紐づくフィルター条件値を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィルター条件値
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<String> getValue();

	/**
	 * フィルター条件の演算子{@link GSqlQueryOperator}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィルター条件の演算子{@link GSqlQueryOperator}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GSqlQueryOperator getOperator();


}
