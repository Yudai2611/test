/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.util.List;

/**
 * {@link GImportConditionFilterField}を格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GImportConditionFilterFieldGroup {
	String FILTER_FIELDS = "filterFields";

	/**
	 * {@link GImportConditionFilterField}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return {@link GImportConditionFilterField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GImportConditionFilterField> getFilterFields();
}
