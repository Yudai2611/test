/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.util.List;

/**
 * {@link GImportConditionFilterField}を格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GImportConditionFilterFieldGroupImpl implements GImportConditionFilterFieldGroup {

	/** 検索条件のリスト **/
	private List<GImportConditionFilterField> filterFields;

	/**
	 * デフォルトコンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionFilterFieldGroupImpl() {
	}

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param filterFields 検索条件のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionFilterFieldGroupImpl(List<GImportConditionFilterField> filterFields) {
		this.filterFields = filterFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionFilterFieldGroup#getFilterFields()
	 */
	@Override
	public List<GImportConditionFilterField> getFilterFields() {
		return filterFields;
	}
}
