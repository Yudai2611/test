/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;


import java.util.List;

/**
 * データ取得時のフィルター条件を格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GImportConditionFilterFieldImpl implements GImportConditionFilterField {

	/** フィールドID **/
	private String fieldId;

	/** フィルター条件値 **/
	private List<String> value;

	/** フィルター条件の演算子{@link GSqlQueryOperator} **/
	private GSqlQueryOperator operator;

	/**
	 * デフォルトコンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionFilterFieldImpl() {
	}

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param value フィルター条件値
	 * @param operator フィルター条件の演算子{@link GSqlQueryOperator}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionFilterFieldImpl(String fieldId, List<String> value, GSqlQueryOperator operator) {
		this.fieldId = fieldId;
		this.value = value;
		this.operator = operator;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionFilterField#getFieldId()
	 */
	@Override
	public String getFieldId() {
		return fieldId;
	}


	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionFilterField#getValue()
	 */
	@Override
	public List<String> getValue() {
		return value;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionFilterField#getOperator()
	 */
	@Override
	public GSqlQueryOperator getOperator() {
		return operator;
	}

}
