/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.util.List;

/**
 * データの取得条件を格納します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GImportConditionImpl implements GImportCondition {

	/** データソースID **/
	private String datasourceId;

	/** フィールド */
	private List<GImportConditionImportField> importFields;

	/** フィルターフィールド **/
	private List<GImportConditionFilterFieldGroup> filterFields;

	/** ソートフィールド **/
	private List<GImportConditionSortField> sortFields;

	/**
	 * デフォルトコンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @param importFields フィールド
	 * @param filterFields フィルターフィールド
	 * @param sortFields ソートフィールド
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionImpl(String datasourceId, List<GImportConditionImportField> importFields,
								List<GImportConditionFilterFieldGroup> filterFields, List<GImportConditionSortField> sortFields) {
		this.importFields = importFields;
		this.filterFields = filterFields;
		this.sortFields = sortFields;
		this.datasourceId = datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportCondition#getDatasourceId()
	 */
	@Override
	public String getDatasourceId() {
		return datasourceId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportCondition#getFilterFields()
	 */
	@Override
	public List<GImportConditionFilterFieldGroup> getFilterFields() {
		return filterFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see GImportCondition#getImportFields()
	 */
	@Override
	public List<GImportConditionImportField> getImportFields() {
		return importFields;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportCondition#getSortFields()
	 */
	@Override
	public List<GImportConditionSortField> getSortFields() {
		return sortFields;
	}
}
