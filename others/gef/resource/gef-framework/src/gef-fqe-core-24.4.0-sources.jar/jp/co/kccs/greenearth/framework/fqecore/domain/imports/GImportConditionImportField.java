/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;

/**
 * フィールドIDと出力有無を格納します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GImportConditionImportField {
	String FIELD_ID = GDatasourceFieldMetadata.FIELD_ID;
	String USE_FIELD = "useField";

	/**
	 * 出力有無を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return 出力有無
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	boolean isUseField();

	/**
	 * フィールドIDを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィールドID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

}
