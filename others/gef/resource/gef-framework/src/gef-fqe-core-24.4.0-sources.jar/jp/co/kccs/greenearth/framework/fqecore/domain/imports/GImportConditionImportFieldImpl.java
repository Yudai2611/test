/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

/**
 * フィールドIDと出力有無を格納します.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GImportConditionImportFieldImpl implements GImportConditionImportField {

	/** フィールドID **/
	private String fieldId;

	/** 出力有無 **/
	private boolean useField;

	/**
	 * コンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @param fieldId フィールドID
	 * @param useField 出力有無
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionImportFieldImpl(String fieldId, boolean useField) {
		this.fieldId = fieldId;
		this.useField = useField;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionImportField#isUseField()
	 */
	@Override
	public boolean isUseField() {
		return useField;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionImportField#getFieldId()
	 */
	@Override
	public String getFieldId() {
		return fieldId;
	}

}
