/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;

/**
 * データ取得順を格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GImportConditionSortField {
	String FIELD_ID = GDatasourceFieldMetadata.FIELD_ID;
	String ORDER = "order";

	/**
	 * フィールドIdを取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return フィールド名
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	String getFieldId();

	/**
	 * ソート順{@link GImportConditionFieldSortOrder}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return ソート順{@link GImportConditionFieldSortOrder}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GImportConditionFieldSortOrder getOrder();

}
