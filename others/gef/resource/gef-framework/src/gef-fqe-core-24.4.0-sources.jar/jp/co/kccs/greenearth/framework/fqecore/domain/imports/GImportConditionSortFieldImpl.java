/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

/**
 * データ取得順を格納します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GImportConditionSortFieldImpl implements GImportConditionSortField {

	/** フィールド名 **/
	private String fieldId;

	/** ソート順{@link GImportConditionFieldSortOrder} **/
	private GImportConditionFieldSortOrder order;

	/**
	 * デフォルトコンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionSortFieldImpl() {
	}

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param order ソート順{@link GImportConditionFieldSortOrder}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GImportConditionSortFieldImpl(String fieldId, GImportConditionFieldSortOrder order) {
		this.fieldId = fieldId;
		this.order = order;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionSortField#getFieldId()
	 */
	@Override
	public String getFieldId() {
		return fieldId;
	}


	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportConditionSortField#getOrder() ()
	 */
	@Override
	public GImportConditionFieldSortOrder getOrder() {
		return order;
	}

}
