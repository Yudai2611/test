/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;

/**
 * データを取得するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GImportService {
	
	/**
	 * データ件数を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param importCondition 取得条件
	 * @return {@link GDatasource} 取得データ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasource imports(GImportCondition importCondition);
	
	/**
	 * データ件数を取得します.
	 * 
	 * @create 2023/10/25
	 * @param importCondition 取得条件
	 * @return データ件数
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	int importsSize(GImportCondition importCondition);

	/**
	 * {@link GImportService}を生成します.
	 * 
	 * @create 2023/10/25
	 * @return
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GImportService getInstance() {
		return GFrameworkUtils.getComponent(GImportService.class);
	}
}
