/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;

/**
 * {@inheritDoc}
 *
 * @see GImportService
 */
public class GImportServiceImpl implements GImportService {
	
	private GImportServiceImpl() {
		
	};

	/**
	 * {@inheritDoc}
	 *
	 * @see GImportService#imports(GImportCondition)
	 */
	@Override
	public GDatasource imports(GImportCondition importCondition) {
		GDatasourceMetadataService datasourceMetadataService = GFrameworkUtils.getComponent(GDatasourceMetadataService.class);
		GDatasourceImporter importer =
			GDatasourceImporter.Factory.getInstance(datasourceMetadataService.lookupById(importCondition.getDatasourceId()).getSrcType());
		return importer.read(importCondition);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GImportService#importsSize(GImportCondition)
	 */
	@Override
	public int importsSize(GImportCondition importCondition) {
		GDatasourceMetadataService datasourceMetadataService = GFrameworkUtils.getComponent(GDatasourceMetadataService.class);
		GDatasourceImporter importer =
			GDatasourceImporter.Factory.getInstance(datasourceMetadataService.lookupById(importCondition.getDatasourceId()).getSrcType());
		return importer.getSize(importCondition);
	}
	
}
