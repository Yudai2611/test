/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.commons.db.GDataSourceConnectionManager;
import jp.co.kccs.greenearth.commons.formatter.GBigDecimalFormatter;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.formatter.GFormatter;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GFieldDataType;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;
import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectSelect;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;

/**
 * SQLを生成します. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GSqlQueryGenerator {

	/**
	 * コネクション{@link Connection}を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param dataSource
	 * @return コネクション{@link Connection}
	 * @throws SQLException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public Connection catchConnection(String dataSource) throws SQLException {
		GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
		if (GStringUtils.isNullOrEmpty(dataSource)) {
			return ds.open();
		}
		return ds.open(dataSource);

	}
	
	/**
	 * SQLを生成します.　<br>
	 * 
	 * @create 2023/10/25
	 * @param importCondition
	 * @param datasourceId
	 * @param datasourceName
	 * @return
	 * @throws ParseException
	 * @author KCCS 200450201
	 * @since 23.10.0
	 */
	public GDirectSelect createSelectQuery (GImportCondition importCondition, String datasourceId, String datasourceName) throws ParseException {
		Object[] params = createFilterStatementValues(importCondition, datasourceId, datasourceName);
		String sqlString = createSelectSQL(importCondition.getFilterFields(), importCondition.getSortFields(),
			importCondition.getImportFields(), datasourceId);
		return GQueryAssistants.selectSql().sql(GQueryAssistants.exp(sqlString, params));
	}

	/**
	 * SQLを生成します.　<br>
	 * 
	 * @create 2023/10/25
	 * @param filterFields フィルター条件{@link GImportConditionFilterField}
	 * @param sortFilters ソート条件{@link GImportConditionSortField}
	 * @param datasourceId データソースID
	 * @return 生成されたSQL
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String createSelectSQL(List<GImportConditionFilterFieldGroup> filterFields,
										 List<GImportConditionSortField> sortFilters, List<GImportConditionImportField> importFields, String datasourceId) {

		Objects.requireNonNull(datasourceId, "datasource id cannot be null.");
		Objects.requireNonNull(filterFields, "filter fields cannot be null.");
		Objects.requireNonNull(sortFilters, "sort fields cannot be null.");
		Objects.requireNonNull(importFields, "import fields cannot be null.");

		GDatasourceMetadata< ? extends GDatasourceType > datasourceMetadata = GDatasourceMetadataService.getInstance().lookupById(datasourceId);
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap = GDatasourceUtil.toFieldMetadataMap(datasourceMetadata.getDatasourceFields());

		StringBuilder sql = new StringBuilder();

		// SELECT
		sql.append(createSelectStatement(importFields, datasourceMetadata.getSrc(), datasourceFieldMetadataMap));
		
		// WHERE
		StringBuilder wheresql = new StringBuilder();
		wheresql.append(createFilterStatement(filterFields, datasourceFieldMetadataMap));
		if (wheresql.length() > 0) {
			wheresql.insert(0, " WHERE ");
		}
		sql.append(wheresql);
		// ORDER BY
		StringBuilder ordersql = new StringBuilder();
		ordersql.append(createOrderStatement(sortFilters, datasourceFieldMetadataMap));
		if (ordersql.length() > 0) {
			ordersql.insert(0, " ORDER BY ");
		}
		sql.append(ordersql);

		return sql.toString();
	}

	/**
	 * SQLのバインドパラメータを生成します.　<br>
	 * 
	 * @create 2023/10/25
	 * @param importCondition インポート条件
	 * @param datasourceId データソースID
	 * @param datasourceName データソース名
	 * @return バインドパラメータ
	 * @throws ParseException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private Object[] createFilterStatementValues(
			GImportCondition importCondition, String datasourceId, String datasourceName) throws ParseException {
		GDatasourceMetadata< ? extends GDatasourceType > datasourceMetadata = GDatasourceMetadataService.getInstance().lookupById(datasourceId);
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap = GDatasourceUtil.toFieldMetadataMap(datasourceMetadata.getDatasourceFields());
		GSqlTypeProvider typeProvider = createTypeProvider(createSelectStatement(importCondition.getImportFields(), datasourceMetadata.getSrc(), datasourceFieldMetadataMap), datasourceName);
		List<Object> params = new ArrayList<Object>();
		for (GImportConditionFilterFieldGroup importConditionFilterFieldGroup : importCondition.getFilterFields()) {
			for (GImportConditionFilterField importConditionFilterField : importConditionFilterFieldGroup.getFilterFields()) {
				if (importConditionFilterField.getValue().stream().map(Object::toString).collect(Collectors.joining()).length() >= 100) {
					throw new GFrameworkException("Value length exceeded.");
				}
				GDatasourceFieldMetadata datasourceFieldMetadata =
					datasourceFieldMetadataMap.get(importConditionFilterField.getFieldId());
				GSqlQueryOperator operator = importConditionFilterField.getOperator();
				switch (operator) {
					case EQUAL :// 等しい（=）
					case NOT_EQUAL :// 等しくない（<>）
					case GREATER_THAN :// 大きい（<）
					case GREATER_THAN_OR_EQUAL :// 以上（<=）
					case LESS_THAN :// 小さい（>）
					case LESS_THAN_OR_EQUAL :// 以下（>=）
						params.add(getValueByType(importConditionFilterField.getValue().get(0), typeProvider.getSqlDataType(datasourceFieldMetadataMap.get(importConditionFilterField.getFieldId()).getSrc())));
						break;
					case EITHER :// いずれか IN
					case NEITHER :// いずれでもない NOT IN
						for (String value : importConditionFilterField.getValue()) {
							params.add(getValueByType(value, typeProvider.getSqlDataType(datasourceFieldMetadataMap.get(importConditionFilterField.getFieldId()).getSrc())));
						}
						break;
					case FORWARD_MATCH :// 前方一致 LIKE
						params.add(new GBindParam(importConditionFilterField.getValue().get(0) + "%", GColumnType.VARCHAR));
						break;
					case BACKWARD_MATCH :// 後方一致 LIKE
						params.add(new GBindParam("%" + importConditionFilterField.getValue().get(0), GColumnType.VARCHAR));
						break;
					case PARTIAL_MATCH :// 部分一致 LIKE
						params.add(new GBindParam("%" + importConditionFilterField.getValue().get(0) + "%", GColumnType.VARCHAR));
						break;
				}

			}


		}
		return params.toArray();
	}

	/**
	 * Where句を生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @param importConditionFilterFieldsList
	 *            フィルター条件{@link GImportConditionFilterFieldGroup}のリスト
	 * @param datasourceFieldMetadataMap データソースメタ情報
	 * @return Where句
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String createFilterStatement(List<GImportConditionFilterFieldGroup> importConditionFilterFieldsList,
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap) {

		StringBuilder searchConditionsql = new StringBuilder();

		if (importConditionFilterFieldsList.size() != 0) {

			for (GImportConditionFilterFieldGroup exportConditionFilterFieldGroup : importConditionFilterFieldsList) {
				if (exportConditionFilterFieldGroup.getFilterFields().size() == 0) {
					continue;
				}
				searchConditionsql.append("(");
				for (GImportConditionFilterField exportConditionFilterField : exportConditionFilterFieldGroup.getFilterFields()) {
					searchConditionsql
						.append(createFilterSubStatement(exportConditionFilterField, datasourceFieldMetadataMap));
					searchConditionsql.append(" AND ");
				}
				searchConditionsql.delete(searchConditionsql.length() - " AND ".length(), searchConditionsql.length());
				searchConditionsql.append(")");
				searchConditionsql.append(" OR ");
			}
			if (searchConditionsql.length() > 0) {
				searchConditionsql.delete(searchConditionsql.length() - " OR ".length(), searchConditionsql.length());
			}
		}

		return searchConditionsql.toString();
	}

	/**
	 * Where区内の演算子とプレースホルダを生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @param importConditionFilterField
	 *            フィルター条件{@link GImportConditionFilterField}のリスト
	 * @return Where句
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String createFilterSubStatement(GImportConditionFilterField importConditionFilterField, Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap) {
		Objects.requireNonNull(datasourceFieldMetadataMap, "DatasourceFieldMedadata cannot be null.");
		StringBuilder conditionsql = new StringBuilder();
		final String placeholder = " ?";
		conditionsql.append(datasourceFieldMetadataMap.get(importConditionFilterField.getFieldId()).getSrc());
		conditionsql.append(" ");

		switch (importConditionFilterField.getOperator()) {
			case EQUAL :
			case NOT_EQUAL :
			case GREATER_THAN :
			case GREATER_THAN_OR_EQUAL :
			case LESS_THAN :
			case LESS_THAN_OR_EQUAL :
			case FORWARD_MATCH :
			case BACKWARD_MATCH :
			case PARTIAL_MATCH :
				conditionsql.append(importConditionFilterField.getOperator().getOperator()).append(placeholder);
				break;
			case IS_NULL :
			case IS_NOT_NULL :
				conditionsql.append(importConditionFilterField.getOperator().getOperator());
				break;
			case EITHER :
			case NEITHER :
				conditionsql.append(importConditionFilterField.getOperator().getOperator()).append("(");

				importConditionFilterField.getValue().forEach(value -> conditionsql.append(" ?,"));
				conditionsql.delete(conditionsql.length() - 1, conditionsql.length());
				conditionsql.append(" )");
				break;
		}

		return conditionsql.toString();
	}

	/**
	 * OrderBy句を生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @param sortFields ソート条件{@link GImportConditionSortField}
	 * @param datasourceFieldMetadataMap フィールド名と{@link GDatasourceFieldMetadata}のペアー
	 * @return OrderBy句
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private String createOrderStatement(List<GImportConditionSortField> sortFields, Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap) {
		Objects.requireNonNull(datasourceFieldMetadataMap, "DatasourceFieldMedadata cannot be null.");
		StringBuilder ordersql = new StringBuilder();
		sortFields.forEach(sortField -> ordersql
			.append(String.format("%s %s,", datasourceFieldMetadataMap.get(sortField.getFieldId()).getSrc(),
				sortField.getOrder().toString())));
		if (ordersql.length() > 0) {
			ordersql.delete(ordersql.length() - 1, ordersql.length());
		}
		return ordersql.toString();

	}

	/**
	 * Select句を生成します. <br>
	 *
	 * @param tableName テーブル名
	 * @param datasourceFieldMetadataMap データソースメタ情報
	 * @return Select句
	 * @author KCCS dhiaz
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	private String createSelectStatement(List<GImportConditionImportField> importFields, String tableName,
												Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap) {
		Objects.requireNonNull(datasourceFieldMetadataMap, "DatasourceFieldMedadata cannot be null.");
		StringBuilder columsPhyNames = new StringBuilder();
		importFields.stream().filter(GImportConditionImportField::isUseField).forEach(field -> {
			columsPhyNames.append(datasourceFieldMetadataMap.get(field.getFieldId()).getSrc());
			columsPhyNames.append(", ");
		});
		String schemaAndTableName = String.format("%s.%s", getSchema(tableName), tableName);
		if (columsPhyNames.length() == 0) {
			StringBuilder columsPhyAllNames = new StringBuilder();
			importFields.stream().forEach(field -> {
				columsPhyAllNames.append(datasourceFieldMetadataMap.get(field.getFieldId()).getSrc());
				columsPhyAllNames.append(", ");
			});
			columsPhyAllNames.delete(columsPhyAllNames.length() - ", ".length(), columsPhyAllNames.length());
			return "SELECT " + columsPhyAllNames + " FROM " + schemaAndTableName;
		} 
		columsPhyNames.delete(columsPhyNames.length() - ", ".length(), columsPhyNames.length());
		return "SELECT " + columsPhyNames + " FROM " + schemaAndTableName;
	}

	

	/**
	 * 文字列型日付、文字列型数値のパラメータに対して、それぞれ日付型、数値型へ型変換します. <br>
	 * 
	 * @create 2023/10/25
	 * @param value パラメータ
	 * @param dataType データ型{@link GFieldDataType}
	 * @return フォーマット適用後のパラメータ
	 * @throws ParseException
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private Object getValueByType(String value, GColumnType dataType) throws ParseException {
		
		Objects.requireNonNull(dataType, "Data type cannot be null.");
		
		if (GColumnType.DATE.equals(dataType)) {
			return typeConversion(value, GFqePropertyKey.IMPORT_DATE_FORMAT.getPropertyValue().split("\\|"), GFrameworkUtils.getComponent(GDateFormatter.class.getName()), dataType);
		}
		if (GColumnType.NUMERIC.equals(dataType)) {
			return typeConversion(value, GFqePropertyKey.IMPORT_NUMBER_FORMAT.getPropertyValue().split("\\|"), GFrameworkUtils.getComponent(GBigDecimalFormatter.class.getName()), dataType);
		}
		return new GBindParam(value, dataType);
	}
	
	/**
	 * パラメータの値を{@link GBindParam}へ格納します. <br>
	 * 
	 * @create 2023/10/25
	 * @param value パラメータ
	 * @param dateFormats パターン
	 * @param formatter フォーマッタ
	 * @param dataType データ型
	 * @return バインドパラメータ
	 * @throws ParseException
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	private Object typeConversion (String value, String[] dateFormats, GFormatter formatter, GColumnType dataType) throws ParseException {
		if (GStringUtils.isNullOrEmpty(value)) {
			return new GBindParam(value, dataType);
		}
		
		for (String format: dateFormats) {
			try {
				return new GBindParam(formatter.parse(value, GFrameworkContext.getInstance().getLocale(), format), dataType);
			} catch (ParseException pe) {
				continue;
			}
		}
		return new GBindParam(formatter.parse(value, GFrameworkContext.getInstance().getLocale()), dataType);
	}
	
	/**
	 * 
	 * 
	 * @create 2023/10/25
	 * @param sql
	 * @param dataSource
	 * @return {@link GSqlTypeProvider}
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	private GSqlTypeProvider createTypeProvider (String sql, String dataSource) {
		ResultSet resultset = null;
		Connection connection = null;
		try {
			connection = catchConnection(dataSource);
			resultset = GQueryAssistants.selectSql().sql(GQueryAssistants.exp(sql)).findResultSet(connection);
			return new GSqlTypeProvider(resultset.getMetaData());
		} catch (SQLException e) {
			throw new GFrameworkException("Failed to access database.");
		} finally {
			GConnectionManager connectionManager = GDataSourceConnectionManager.getInstance();
			try {
				resultset.close();
				connectionManager.releaseConnection(connection);
			} catch (SQLException e) {
				throw new GFrameworkException("Failed to close connnection.");
			}
		}
	}

	protected abstract String getSchema(String tableName);
		
	public class GSqlTypeProvider {
		Map<String, GColumnType> sqlTypeMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
		private final List<Integer> DATE_TYPE = Arrays.asList(Types.DATE, Types.TIME, Types.TIMESTAMP, Types.TIME_WITH_TIMEZONE, Types.TIMESTAMP_WITH_TIMEZONE);
		private final List<Integer> NUMERIC_TYPE = Arrays.asList(Types.SMALLINT, Types.INTEGER, Types.BIGINT, Types.FLOAT, Types.DOUBLE, Types.NUMERIC, Types.DECIMAL, Types.REAL);
		private final List<Integer> STRING_TYPE = Arrays.asList(Types.CHAR, Types.VARCHAR, Types.LONGVARCHAR, Types.NVARCHAR, Types.NCHAR, Types.LONGNVARCHAR);
		
		
		public GSqlTypeProvider(ResultSetMetaData metaData) throws SQLException {
			setTypes(metaData);
		
		}
		
		private void setTypes(ResultSetMetaData metaData) throws SQLException {
			
			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				sqlTypeMap.put(metaData.getColumnName(i), toColumnType(metaData.getColumnType(i)));
			}
			
		}
		
		private GColumnType toColumnType (int type) {
			
			if (DATE_TYPE.contains(type)) {
				return GColumnType.DATE;
			}
			if (NUMERIC_TYPE.contains(type)) {
				return GColumnType.NUMERIC;
			}
			if (STRING_TYPE.contains(type)) {
				return GColumnType.VARCHAR;
			}
			throw new GFrameworkException("this type is not supported.");
		}
		
		public GColumnType getSqlDataType(String name) {
			return sqlTypeMap.get(name); 
		}
		
	}

}
