/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.imports;


import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import static java.util.stream.Collectors.toMap;

/**
 * フィルター条件の演算子とパラメータのマッピングするクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
public enum GSqlQueryOperator {

	/** 等しい */
	EQUAL(0, "="),
	/** 等しくない */
	NOT_EQUAL(1, "<>"),
	/** より大きい */
	GREATER_THAN(2, ">"),
	/** 以上 */
	GREATER_THAN_OR_EQUAL(3, ">="),
	/** より小さい */
	LESS_THAN(4, "<"),
	/** 以下 */
	LESS_THAN_OR_EQUAL(5, "<="),
	/** いづれか */
	EITHER(6, "IN"),
	/** いづれでもない */
	NEITHER(7, "NOT IN"),
	/** 前方一致 */
	FORWARD_MATCH(8, "LIKE"),
	/** 後方一致 */
	BACKWARD_MATCH(9, "LIKE"),
	/** 部分一致 */
	PARTIAL_MATCH(10, "LIKE"),
	/** nullと等しい */
	IS_NULL(11, "IS NULL"),
	/** nullと等しくない */
	IS_NOT_NULL(12, "IS NOT NULL");

	/** 演算子のマップ **/
	private static final Map<Integer, GSqlQueryOperator> OPERATOR_MAP;
	
	static {
		Map<Integer, GSqlQueryOperator> filterOperatorMap =
			Arrays.stream(values()).collect(toMap(operator -> operator.number, e -> e));
		OPERATOR_MAP = Collections.unmodifiableMap(filterOperatorMap);
	}

	/** パラメータ **/
	private int number;

	/** 演算子 **/
	private String operator;

	/**
	 * コンストラクターです. <br>
	 *
	 * @create 2023/10/25
	 * @param num パラメータ
	 * @param operator 演算子
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	GSqlQueryOperator(int num, String operator) {
		this.number = num;
		this.operator = operator;
	}

	/**
	 * パラメータを取得します. <br>
	 *
	 * @create 2023/10/25
	 * @return number パラメータ
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public int getInternalParam() {
		return number;
	}

	/**
	 * 演算子をSQLクエリーとして返します.  <br>
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public String getOperator() {
		return operator;
	}

	/**
	 * {@link GSqlQueryOperator}を取得します. <br>
	 * 
	 * @param number パラメータ
	 * @return {@link GSqlQueryOperator}
	 * @author KCCS oka
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	public static GSqlQueryOperator of(Integer number) {
		return OPERATOR_MAP.get(number);
	}

}
