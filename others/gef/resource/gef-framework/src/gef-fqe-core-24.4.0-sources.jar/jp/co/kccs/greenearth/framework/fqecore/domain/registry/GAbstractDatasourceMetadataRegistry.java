/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import static java.util.Objects.isNull;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResultImpl;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextHolder;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDataSourceMetadataSorter;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GIdComparator;
import jp.co.kccs.greenearth.framework.fqecore.datasource.factory.GDatasourceMetadataFactory;

/**
 * データソースメタ情報を探します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public abstract class GAbstractDatasourceMetadataRegistry implements GDatasourceMetadataRegistry {

	/** データソースメタ情報のキャッシュ{@link GDatasourceMetadataCache} **/
	protected GDatasourceMetadataCache datasourceMetadataCache;
	/** ロガー **/
	protected static final Log LOGGER = LogFactory.getLog(GAbstractDatasourceMetadataRegistry.class);

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceMetadataCache {@link GDatasourceMetadataCache}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GAbstractDatasourceMetadataRegistry(GDatasourceMetadataCache datasourceMetadataCache) {
		if (isNull(datasourceMetadataCache)) {
			throw new GFrameworkException("Cache object cannot be null.");
		}
		this.datasourceMetadataCache = datasourceMetadataCache;
	}

	/**
	 * データソースメタ情報xmlファイルを読込みます. <br>
	 *
	 * @create 2023/10/25
	 * @return データソースメタ情報のリスト {@link GDatasourceMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GRangeResultImpl<String> extract(GRange range) {
		Objects.requireNonNull(range, "Range cannot be null.");
		List<String> datasourceIds = lookupIds();
		int overallSize = datasourceIds.size();
		validatePaginating(datasourceIds, range);
		return new GRangeResultImpl<>(datasourceIds, range, overallSize);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataRegistry#lookupById(String)
	 */
	@Override
	public GDatasourceMetadata<? extends GDatasourceType> lookupById(String datasourceId) {
		Objects.requireNonNull(datasourceId, "Datasource id is required.");
		GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata = lookupInternal(datasourceId);
		Predicate<String> isNotEqualApplicationId =
			applicationId -> !applicationId.equals(GFqeContextHolder.getContext().getApplicationId());
		if (isNull(datasourceMetadata) || isNotEqualApplicationId.test(datasourceMetadata.getApplicationId())) {
			return null;
		}
		return datasourceMetadata;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataRegistry#lookupIds()
	 */
	@Override
	public List<String> lookupIds() {
		List<GDatasourceMetadata<? extends GDatasourceType>> datasourceMetadataList =
			lookupFileNames().stream().map(name -> lookupById(name.replaceFirst("[.][^.]+$", ""))).collect(Collectors.toList());
		return GDataSourceMetadataSorter.getInstance().sort(datasourceMetadataList, new GIdComparator()).stream()
			.map(GDatasourceMetadata::getId).collect(Collectors.toList());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataRegistry#release(String)
	 */
	@Override
	public void release(String datasourceId) {
		Objects.requireNonNull(datasourceId, "Datasource id is required.");
		datasourceMetadataCache.release(datasourceId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataRegistry#releaseAll()
	 */
	@Override
	public void releaseAll() {
		datasourceMetadataCache.releaseAll();
	}

	/**
	 * データソースメタ情報xmlファイルを読込み時の内部処理です. <br>
	 *
	 * @create 2023/10/25
	 * @param datasourceId データソースメタID
	 * @return データソースメタ情報 {@link GDatasourceMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 * @see GAbstractDatasourceMetadataRegistry#loadDatasourceMetadata(String)
	 */
	protected GDatasourceMetadata<? extends GDatasourceType> loadDatasourceMetadata(String datasourceId) {
		return GDatasourceMetadataFactory.Factory.create(datasourceId);
	}

	/**
	 * データソース定義xmlのファイル名一覧を取得します.<br>
	 * 
	 * @create 2024/04/30
	 * @return データソースidのリスト
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	protected List<String> lookupFileNames() {
		return GFileUtils.listFileNamesFrom(GFqePropertyKey.DATASOURCE_BASEDIR.getPropertyValue()).stream()
			.map(datasourceFile -> datasourceFile.replaceFirst("[.][^.]+$", "")).collect(Collectors.toList());
	}

	/**
	 * 指定されたデータソースIDに紐づくデータソースメタ情報を取得する際の内部処理です. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceId
	 * @return データソースメタ情報 [{@link GDatasourceMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 * @see GAbstractDatasourceMetadataRegistry#lookupInternal(String)
	 */
	protected abstract GDatasourceMetadata<? extends GDatasourceType> lookupInternal(String datasourceId);

	/**
	 * ページネーションの設定値を検証します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceIds データソースメタ情報id
	 * @param range 出力用レンジ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected void validatePaginating(List<String> datasourceIds, GRange range) {
		if (datasourceIds.size() < range.getBeginIndex()) {
			throw new GFrameworkException("Range begin index is out of bound.");
		}
		if (range.getBeginIndex() > range.getEndIndex()) {
			throw new GFrameworkException("Begin index cannot be less than end index.");
		}
	}
}
