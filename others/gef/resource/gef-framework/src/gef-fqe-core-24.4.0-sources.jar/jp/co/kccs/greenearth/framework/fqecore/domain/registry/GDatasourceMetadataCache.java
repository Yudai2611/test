/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;

/**
 *
 * データソースメタ情報をキャッシュします. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceMetadataCache {

	/**
	 * 指定されたデータソースのメタ情報を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @return {@link GDatasourceMetadata} データソースメタ情報
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	Optional<GDatasourceMetadata<?>> get(String datasourceId);
	
	/**
	 * データソースを1件キャッシュします. <br>
	 * 
	 * @param datasourceId データソースID
	 * @param datasource データソースメタ情報
	 * @author KCCS dhiaz
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	void put(String datasourceId, GDatasourceMetadata<?> datasource);

	/**
	 * データソースを複数件キャッシュします. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceList データソースメタ情報のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void put(List<GDatasourceMetadata<?>> datasourceList);

	

	/**
	 * データソース全件分のメタ情報を取得します.
	 * 
	 * @create 2023/10/25
	 * @return {@link GDatasourceMetadata}のマップ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	Map<String, GDatasourceMetadata<?>> getAll();

	/**
	 * 指定されたデータソースのメタ情報をキャッシュから削除します.
	 * 
	 * @create 2023/10/25 
	 * @param datasourceId データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void release(String datasourceId);

	/**
	 * キャッシュされているデータソース全件分のメタ情報を削除します.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void releaseAll();
}
