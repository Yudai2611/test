/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;

/**
 *
 * データソースメタ情報をキャッシュします. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceMetadataMemoryCache implements GDatasourceMetadataCache {

	/** データソースメタ情報のキャッシュ **/
	private Map<String, GDatasourceMetadata<?>> datasourceCacheMap = new ConcurrentHashMap<>();

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#put(java.lang.String,
	 *      GDatasourceMetadata)
	 */
	@Override
	public void put(String datasourceId, GDatasourceMetadata<?> datasource) {
		datasourceCacheMap.put(datasourceId, datasource);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#put(List)
	 */
	@Override
	public void put(List<GDatasourceMetadata<?>> datasourceList) {
		datasourceList.forEach(datasource -> {
			put(datasource.getId(), datasource);
		});
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#get(String)
	 */
	@Override
	public Optional<GDatasourceMetadata<? extends GDatasourceType>> get(String datasourceId) {
		GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata = datasourceCacheMap.get(datasourceId);
		if (Objects.nonNull(datasourceMetadata)) {
			return Optional.of(datasourceMetadata);
		}
		return Optional.empty();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#getAll()
	 */
	@Override
	public Map<String, GDatasourceMetadata<?>> getAll() {
		return datasourceCacheMap;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#release(String)
	 */
	@Override
	public void release(String datasourceId) {
		datasourceCacheMap.remove(datasourceId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#releaseAll()
	 */
	@Override
	public void releaseAll() {
		datasourceCacheMap.clear();
	}
}
