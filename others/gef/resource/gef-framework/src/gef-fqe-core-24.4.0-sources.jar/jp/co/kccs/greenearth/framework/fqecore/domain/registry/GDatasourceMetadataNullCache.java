/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;

/**
 *
 * データソースメタ情報をキャッシュします. <br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceMetadataNullCache implements GDatasourceMetadataCache {

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#get(java.lang.String)
	 */
	@Override
	public Optional<GDatasourceMetadata<? extends GDatasourceType>> get(String datasourceId) {
		return Optional.empty();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#getAll()
	 */
	@Override
	public Map<String, GDatasourceMetadata<?>> getAll() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#put(String,
	 *      GDatasourceMetadata)
	 */
	@Override
	public void put(String datasourceId, GDatasourceMetadata<?> datasource) {

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#put(List)
	 */
	@Override
	public void put(List<GDatasourceMetadata<?>> datasourceList) {

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#release(String)
	 */
	@Override
	public void release(String datasourceId) {

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataCache#releaseAll()
	 */
	@Override
	public void releaseAll() {

	}
}
