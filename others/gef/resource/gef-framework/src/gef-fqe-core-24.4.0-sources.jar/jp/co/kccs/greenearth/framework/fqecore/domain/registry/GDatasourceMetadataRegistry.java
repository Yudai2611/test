/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;

/**
 * データソースメタ情報を探します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceMetadataRegistry {

	/**
	 * データソースメタ情報を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @return {@link GDatasourceMetadata} データソースメタ情報
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasourceMetadata<? extends GDatasourceType> lookupById(String datasourceId);

	/**
	 * データソースメタ情報を全件取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースメタIdリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GRangeResult<String> extract(GRange range);
	List<String> lookupIds();

	/**
	 * 指定したデータソースメタ情報のキャッシュをクリアにします. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースID
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void release(String datasourceId);

	/**
	 * データソースメタ情報のキャッシュを全件クリアにします. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	void releaseAll();


	/**
	 * {@link GDatasourceMetadataRegistry}のインスタンスを生成するファクトリです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	class Factory {
		private static Map<String, GDatasourceMetadataRegistry> datasourceRegistryMap = new HashMap<>();
		public Factory(GDatasourceMetadataCache datasourceMetadataCache) {
			Factory.datasourceRegistryMap.put("init", new GDatasourceMetadataRegistryInitCache(datasourceMetadataCache));
			Factory.datasourceRegistryMap.put("used", new GDatasourceMetadataRegistryUsedCache(datasourceMetadataCache));
			Factory.datasourceRegistryMap.put("none", new GDatasourceMetadataRegistryNoneCache());
		}

		/**
		 * {@link GDatasourceMetadataRegistry}のインスタンスを生成します. <br>
		 *
		 * @create 2023/10/25
		 * @return
		 * @author KCCS dhiaz
		 * @since 23.10.0
		 */
		public static GDatasourceMetadataRegistry getInstance() {
			String cacheMode = GFqePropertyKey.DATASOURCE_CACHE_MODE.getPropertyValue();
			return Optional.ofNullable (datasourceRegistryMap.get(cacheMode))
					.orElseThrow (() -> new GFrameworkException(String.format("Datasource registry for cache mode %s is not found.", cacheMode)));

		}
	}
}
