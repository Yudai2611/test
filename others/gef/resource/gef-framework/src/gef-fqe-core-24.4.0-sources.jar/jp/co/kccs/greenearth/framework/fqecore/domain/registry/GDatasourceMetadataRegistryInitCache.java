/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;

/**
 * データソースメタ情報キャッシュ<code>Init</code>設定時に使用される{@link GAbstractDatasourceMetadataRegistry}の具象クラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceMetadataRegistryInitCache extends GAbstractDatasourceMetadataRegistry {

	/** キャッシュ初期化処理のフラグ */
	private boolean isCacheInitialized = false;

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceMetadataCache データソースメタ情報XMLファイルのpath
	 *            {@link GDatasourceMetadataCache}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GDatasourceMetadataRegistryInitCache(GDatasourceMetadataCache datasourceMetadataCache) {
		super(datasourceMetadataCache);
		this.isCacheInitialized = false;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GAbstractDatasourceMetadataRegistry#lookupInternal(java.lang.String)
	 */
	@Override
	protected GDatasourceMetadata<?> lookupInternal(String datasourceId) {
		if (!isCacheInitialized) {
			initCache();
		}
		Optional<GDatasourceMetadata<?>> datasourceOptional = datasourceMetadataCache.get(datasourceId);
		return datasourceOptional.orElse(null);
	}

	/**
	 * データソースメタ情報をキャッシュします. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private void initCache() {
		List<GDatasourceMetadata<?>> datasourceMetadataList = new ArrayList<>();
		for (String id : lookupFileNames ()) {
			try {
				datasourceMetadataList.add(loadDatasourceMetadata(id));
			} catch (GFrameworkException e) {
				String errorMsg = String.format("scanning datasource(%s) is failed.", id);
				LOGGER.info(errorMsg);
				String scanningMode = GFqePropertyKey.DATASOURCE_SCANNING_MODE.getPropertyValue();
				if (scanningMode.equals("break")) {
					break;
				} else if (scanningMode.equals("error")) {
					throw new GFrameworkException(errorMsg, e);
				} else if (scanningMode.equals("ignore")) {
					LOGGER.info("error is ignored");
				} else {
					throw new GFrameworkException("Not compatible error-action.", e);
				}

			}
		}
		datasourceMetadataCache.put(datasourceMetadataList);
		isCacheInitialized = true;
	}

}
