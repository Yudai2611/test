/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;

/**
 * データソースメタ情報キャッシュ<code>None</code>設定時に使用される{@link GAbstractDatasourceMetadataRegistry}の具象クラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceMetadataRegistryNoneCache extends GAbstractDatasourceMetadataRegistry {

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GDatasourceMetadataRegistryNoneCache() {
		super(new GDatasourceMetadataNullCache());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GAbstractDatasourceMetadataRegistry#lookupInternal(java.lang.String)
	 */
	@Override
	protected GDatasourceMetadata<?> lookupInternal(String datasourceId) {
		return loadDatasourceMetadata(datasourceId);
	}

}
