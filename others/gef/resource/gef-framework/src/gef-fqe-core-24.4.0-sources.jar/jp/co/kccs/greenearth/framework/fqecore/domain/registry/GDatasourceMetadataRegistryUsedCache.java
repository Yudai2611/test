/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;

/**
 * データソースメタ情報キャッシュ<code>Used</code>設定時に使用される{@link GAbstractDatasourceMetadataRegistry}の具象クラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceMetadataRegistryUsedCache extends GAbstractDatasourceMetadataRegistry {

	/**
	 * コンストラクタです. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceMetadataCache データソースメタ情報キャッシュ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public GDatasourceMetadataRegistryUsedCache(GDatasourceMetadataCache datasourceMetadataCache) {
		super(datasourceMetadataCache);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GAbstractDatasourceMetadataRegistry#lookupInternal(java.lang.String)
	 */
	@Override
	protected GDatasourceMetadata<?> lookupInternal(String datasourceId) {
		Optional<GDatasourceMetadata<?>> datasourceMetadataOptional = null;
		synchronized (this) {
			datasourceMetadataOptional = datasourceMetadataCache.get(datasourceId);
			if (datasourceMetadataOptional.isEmpty()) {
				GDatasourceMetadata<?> datasourceMetadata = loadDatasourceMetadata(datasourceId);
				if (Objects.nonNull(datasourceMetadata)) {
					datasourceMetadataCache.put(datasourceMetadata.getId(), datasourceMetadata);
				}
				return datasourceMetadata;
			}
		}
		return datasourceMetadataOptional.orElse(null);
	}

}
