/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;

/**
 * データソースメタ情報{@link GDatasourceMetadata}を取得します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public interface GDatasourceMetadataService {

	/**
	 * 指定されたレンジの基づいてデータソースメタ情報{@link GDatasourceMetadata}取得をします. <br>
	 * 
	 * @create 2023/10/25
	 * @param range データ取得件数用レンジ
	 * @return 結果セット
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GRangeResult<GDatasourceMetadata<? extends GDatasourceType >> extract(GRange range);

	/**
	 * データソースメタ情報{@link GDatasourceMetadata}を全件取得をします. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースメタ情報{@link GDatasourceMetadata}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	List<GDatasourceMetadata<? extends GDatasourceType >> lookupAll();

	/**
	 * 指定したidのデータソースメタ情報{@link GDatasourceMetadata}1件取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceId データソースid
	 * @return データソースメタ情報{@link GDatasourceMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasourceMetadata<? extends GDatasourceType > lookupById(String datasourceId);
	
	/**
	 * データソースメタ情報{@link GDatasourceMetadata}を生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @return データソースメタ情報{@link GDatasourceMetadata}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	static GDatasourceMetadataService getInstance() {
		return GFrameworkUtils.getComponent(GDatasourceMetadataService.class);
	}
}
