/*
 * Copyright 2022-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqecore.domain.registry;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

import jp.co.kccs.greenearth.framework.fqecore.datasource.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.commons.data.GRangeResultImpl;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;

/**
 * データソースメタ情報{@link GDatasourceMetadata}を取得します. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceMetadataServiceImpl implements GDatasourceMetadataService {

	/** ロガー */
	protected static final Log LOGGER = LogFactory.getLog(GDatasourceMetadataServiceImpl.class);
	/** Comparator */
	protected static Comparator comparator;

	/**
	 * コンストラクターです.
	 * 
	 * @create 2024/04/30
	 * @param comparator
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	GDatasourceMetadataServiceImpl(Comparator comparator) {

		this.comparator = comparator;
	}

	/**
	 * コンストラクターです.
	 * 
	 * @create 2024/04/30
	 * @author KCCS oka
	 * @since 24.4.0
	 */
	GDatasourceMetadataServiceImpl() {

		comparator = new GIdComparator ();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataService#extract(GRange)
	 */
	@Override
	public GRangeResult<GDatasourceMetadata<? extends GDatasourceType>> extract(GRange range) {
		GDatasourceMetadataRegistry datasourceMetadataRegistry = GDatasourceMetadataRegistry.Factory.getInstance();
		GRangeResult<String> datasourceIdsPagination = datasourceMetadataRegistry.extract(range);
		List<GDatasourceMetadata<? extends GDatasourceType>> datasourceMetadataList = lookupInternal(datasourceIdsPagination);
		return new GRangeResultImpl<>(datasourceMetadataList, range, datasourceIdsPagination.getOverallSize());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataService#lookupAll()
	 */
	@Override
	public List<GDatasourceMetadata<?>> lookupAll() {
		GDatasourceMetadataRegistry datasourceMetadataRegistry = GDatasourceMetadataRegistry.Factory.getInstance();
		return lookupInternal(new GRangeResultImpl<String>(datasourceMetadataRegistry.lookupIds(), null, 0));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see GDatasourceMetadataService#lookupById(String)
	 */
	@Override
	public GDatasourceMetadata<? extends GDatasourceType> lookupById(String datasourceId) {
		return GDatasourceMetadataRegistry.Factory.getInstance().lookupById(datasourceId);
	}

	/**
	 * データソースメタ情報{@link GDatasourceMetadata}のリストを取得する内部処理をします. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceIdsPagination
	 * @return データソースメタ情報{@link GDatasourceMetadata}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private List<GDatasourceMetadata<? extends GDatasourceType>> lookupInternal(GRangeResult<String> datasourceIdsPagination) {
		List<GDatasourceMetadata<? extends GDatasourceType>> datasourceMetadataList = new ArrayList<>();
		int listIndex = 0;
		ReadFile: for (String datasourceId : datasourceIdsPagination.getResult()) {
			try {
				GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata = lookupById(datasourceId);
				if (Objects.isNull(datasourceMetadata)) {
					continue;
				}
				listIndex++;
				if (Objects.isNull(datasourceIdsPagination.getRange())) {
					datasourceMetadataList.add(datasourceMetadata);
					continue;
				}
				Predicate<Integer> listIndexGreaterThanBeginIndex = index -> datasourceIdsPagination.getRange().getBeginIndex() < index;
				Predicate<Integer> listIndexLessThanEndIndex = index -> index <= datasourceIdsPagination.getRange().getEndIndex();

				if (listIndexGreaterThanBeginIndex.and(listIndexLessThanEndIndex).test(listIndex)) {
					datasourceMetadataList.add(datasourceMetadata);
				}

			} catch (GFrameworkException exception) {
				String errorMsg = String.format("scanning datasource(%s) is failed.", datasourceId);
				LOGGER.info(errorMsg);
				String scanningMode = GFqePropertyKey.DATASOURCE_SCANNING_MODE.getPropertyValue();

				switch (scanningMode) {
					case "break" :
						break ReadFile;
					case "error" :
						throw new GFrameworkException(errorMsg, exception);
					case "ignore" :
						LOGGER.info("error is ignored");
						break;
					default :
						throw new GFrameworkException("Not compatible error-action.");
				}
			}
		}
		datasourceIdsPagination.setOverallSize(listIndex);
		return GDataSourceMetadataSorter.getInstance().sort(datasourceMetadataList, comparator);
	}

}
