/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria;

/**
 * データソースメタデータに関するキーを格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public enum GDatasourceMetadataKeys {

	/** データソースリストのキー **/
	DATASOURCE_CREATION_DATE("datasourceCreationDate"),
	/** データソースリストのキー **/
	DATASOURCE_LIST("datasourceList"),
	/** データソースIDのキー　**/
	DATASOURCE_ID("datasourceId"),
	/** データソースラベルのキー　**/
	DATASOURCE_LABEL("datasourceLabel"),
	/** データソースエキスパートリストのキー　**/
	DATASOURCE_FIELDS("fieldList"),
	/** データソースエキスパートリストのカラムIDのキー　**/
	DATASOURCE_FIELD_ID("fieldId"),
	/** データソースエキスパートリストのカラム名のキー　**/
	DATASOURCE_FIELD_LABEL("fieldLabel"),
	/** データソースエキスパートリストのカラムタイプのキー　**/
	DATASOURCE_FIELD_DATA_TYPE("fieldDataType");

	private String value;

	/**
	 * コンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GDatasourceMetadataKeys(String value) {
		this.value = value;
	}

	/**
	 * キーを取得します.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @return キー
	 * @since 23.10.0
	 */
	public String getValue() {
		return value;
	}
}
