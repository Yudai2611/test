/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria;

/**
 * 出力条件に関するキーを格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public enum GExportConditionKeys {
	EXPORT_FIELD_EXPORT_FLAG("isUsed"),
	/** ソートカラムリストのデータソースIDのキー **/
	DATASOURCE_ID("datasourceId"),
	/** ヘーダフラグのキー **/
	USE_HEADER("useHeader"),
	/** ファイルタイプのキー **/
	FILE_TYPE("fileType"),
	/** エキスポートファイルネームのキー **/
	EXPORT_NAME("exportName");

	private String value;


	/**
	 * コンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GExportConditionKeys(String value) {
		this.value = value;
	}

	/**
	 * キーを取得します.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @return キー
	 * @since 23.10.0
	 */
	public String getValue() {
		return value;
	}
}
