/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.http.protocol.UriPatternMatcher;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.context.FqeContextDataExtractor;
import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContext;
import jp.co.kccs.greenearth.framework.fqecore.context.GFqeContextDataExtractor;

/**
 * FQEで使用する情報を管理するコンテキストです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
@FqeContextDataExtractor
@Priority(GPriority.NORMAL)
public class GFqeContextDataExtractorSessionFul implements GFqeContextDataExtractor {
	private static final List<String> ALLOWED_PATTERNS = List.of("*.ria-action", "*.ajax-action", "*.view-action");
	private static final UriPatternMatcher<Boolean> MATCHER = new UriPatternMatcher<>();
	public GFqeContextDataExtractorSessionFul() {
		registerPatterns();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	@Override
	public boolean canHandle(HttpServletRequest servletRequest) {
		Object result = MATCHER.lookup(servletRequest.getRequestURI());
		return Objects.nonNull(result);
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	@Override
	public Map<String, Object> extract(HttpServletRequest servletRequest) {
		Map<String, Object> dataMap = new HashMap<>();
		String applicationId = GFqePropertyKey.APPLICATION_ID.getPropertyValue();
		if (Objects.nonNull(GWebContext.getInstance().getSession()) && Objects.nonNull(GWebContext.getInstance().getSession().getLoginUser())) {
			String userId = GWebContext.getInstance().getSession().getLoginUser().getId();
			dataMap.put(GFqeContext.USER_ID, userId);
		}
		dataMap.put(GFqeContext.APPLICATION_ID, applicationId);
		return dataMap;
	}
	

	private void registerPatterns() {
		for (String pattern : ALLOWED_PATTERNS) {
			MATCHER.register(pattern, true);
		}
	}
}
