/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria;

/**
 * 履歴条件に関するキーを格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public enum GHistoryConditionKeys {

	/** データソースIDのキー **/
	DATASOURCE_ID("datasourceId"),

	/** データソースラベルのキー **/
	DATASOURCE_LABEL("datasourceLabel"),

	/** 出力フラグのキー **/
	EXPORT_FIELD_EXPORT_FLAG("isUsed"),

	/** ファイルタイプのキー **/
	FILE_TYPE("fileType"),

	/** フィルターリストのカラムIDのキー **/
	FILTER_FIELD_ID("fieldId"),

	/** フィルターリストのカラム名前のキー **/
	FILTER_FIELD_LABEL("fieldLabel"),

	/** フィルターリストのキー **/
	FILTER_FIELD_LIST("filterFieldList"),

	/** フィルターリストの演算子のキー **/
	FILTER_FIELD_OPERATOR("operator"),

	/** フィルターリストの値のキー **/
	FILTER_FIELD_VALUE("value"),

	/** フィルター条件のキー **/
	FILTER_GROUP_LIST("filterFieldGroupList"),

	/** 出力条件のキー **/
	HISTORY_CONDITION_LIST("historyConditionList"),

	/** 条件のIDのキー **/
	HISTORY_ID("historyId"),

	/** 条件の名前のキー **/
	HISTORY_NAME("historyName"),

	/** 保存者の名前のキー **/
	SAVED_AT("savedAt"),

	/** 保存者の名前のキー **/
	SAVED_BY("savedBy"),

	/** ソートリストのカラムIDのキー **/
	SORT_FIELD_ID("fieldId"),

	/** ソートリストのカラム名前のキー **/
	SORT_FIELD_LABEL("fieldLabel"),

	/** ソートリストのキー **/
	SORT_FIELD_LIST("sortFieldList"),

	/** ソート順のキー **/
	SORT_FIELD_ORDER("sortOrder"),

	/** ヘッダー利用有無のフラグのキー **/
	USE_HEADER("useHeader");

	private String value;

	/**
	 * コンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GHistoryConditionKeys(String value) {
		this.value = value;
	}
	
	/**
	 * キーを取得します.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @return キー
	 * @since 23.10.0
	 */
	public String getValue() {
		return value;
	}

}
