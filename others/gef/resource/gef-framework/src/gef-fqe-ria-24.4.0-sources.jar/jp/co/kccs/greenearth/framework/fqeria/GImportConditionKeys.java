/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria;

/**
 * データ取得条件に関するキーを格納するクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */public enum GImportConditionKeys {
	/** ソートカラムリストのデータソースID **/
	DATASOURCE_ID("datasourceId"),

	/** フィルターグループのリストID **/
	FILTER_GROUP_LIST("filterFieldGroupList"),

	/** フィルターカラムリストのカラムID **/
	FILTER_FIELD_ID("fieldId"),

	/** フィルターカラムリストのキー **/
	FILTER_FIELD_LIST("filterFieldList"),

	/** フィルターカラムリストのオペレーターキー **/
	FILTER_FIELD_OPERATOR("operator"),

	/** フィルターカラムリストのシングル値キー **/
	FILTER_FIELD_VALUE("value"),

	/** ソートカラムリストのカラムID **/
	SORT_FIELD_ID("fieldId"),

	/** フィルターカラムリストの複数値のキー **/
	SORT_FIELD_LIST("sortFieldList"),

	/** ソートカラムリストのソートオーダーのキー **/
	SORT_FIELD_ORDER("sortOrder");

	private String value;

	/**
	 * コンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	GImportConditionKeys(String value) {
		this.value = value;
	}

	/**
	 * キーを取得します.
	 * 
	 * @create 2023/10/25
	 * @author KCCS dhiaz
	 * @return キー
	 * @since 23.10.0
	 */
	public String getValue() {
		return value;
	}
}
