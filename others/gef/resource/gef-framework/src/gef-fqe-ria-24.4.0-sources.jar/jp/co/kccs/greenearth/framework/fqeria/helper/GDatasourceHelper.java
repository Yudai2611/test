/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.helper;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.commons.utils.GDateUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqeria.GDatasourceMetadataKeys;


/**
 * 画面パラメータ{@link GParameter}から値を取得、また結果を{@link GResultData}に格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GDatasourceHelper {

	/**
	 * {@link GDatasourceMetadata}を{@link GResultData}へ格納します.
	 *
	 * @create 2023/10/25
	 * @param datasource {@link GDatasourceMetadata}
	 * @param resultData {@link GResultData}
	 * @return{@link GResultData}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GResultData convertTo(GDatasourceMetadata<? extends GDatasourceType> datasource, GResultData resultData) {
		GListData exportColumnList = new GListData();
		if (Objects.nonNull(datasource) && Objects.nonNull(datasource.getDatasourceFields())) {
			datasource.getDatasourceFields().forEach(datasourceFieldMetadata -> {
				GRowData rowData = new GRowData();
				rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_ID.getValue(), datasourceFieldMetadata.getId());
				rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_LABEL.getValue(), datasourceFieldMetadata.getLabel());
				rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_DATA_TYPE.getValue(), datasourceFieldMetadata.getDataType().getValue());
				exportColumnList.add(rowData);
			});
			resultData.setData(GDatasourceMetadataKeys.DATASOURCE_ID.getValue(), datasource.getId());
			resultData.setData(GDatasourceMetadataKeys.DATASOURCE_LABEL.getValue(), datasource.getLabel());
			resultData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELDS.getValue(), exportColumnList);
		}
		return resultData;
	}

	/**
	 * {@link GDatasourceMetadata}のリストを{@link GResultData}へ格納します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceMetadataList {@link GDatasourceMetadata}のリスト
	 * @param resultData {@link GResultData}
	 * @return {@link GResultData}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GResultData convertTo(List<GDatasourceMetadata<? extends GDatasourceType>> datasourceMetadataList,
		GResultData resultData) {
		GListData listData = new GListData();
		if (Objects.nonNull(datasourceMetadataList)) {
			datasourceMetadataList.forEach(datasourceMetadata -> {
				GRowData datasourceRow = new GRowData();
				datasourceRow.setData(GDatasourceMetadataKeys.DATASOURCE_ID.getValue(), datasourceMetadata.getId());
				datasourceRow.setData(GDatasourceMetadataKeys.DATASOURCE_LABEL.getValue(), datasourceMetadata.getLabel());
				listData.add(datasourceRow);
			});
			resultData.setData(GDatasourceMetadataKeys.DATASOURCE_LIST.getValue(), listData);
		}
		return resultData;
	}

	/**
	 * {@link GRangeResult}のリストを{@link GResultData}へ格納します. <br>
	 * 
	 * @create 2023/10/25
	 * @param datasourceMetadataList {@link GRangeResult}
	 * @param resultData {@link GResultData}
	 * @return {@link GResultData}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GResultData convertTo(GRangeResult<GDatasourceMetadata<? extends GDatasourceType>> datasourceMetadataList,
		GResultData resultData) {
		GListData listData = new GListData();
		if (Objects.nonNull(datasourceMetadataList) && Objects.nonNull(datasourceMetadataList.getResult())) {
			datasourceMetadataList.getResult().forEach(datasourceMetadata -> {
				GRowData datasourceRow = new GRowData();
				datasourceRow.setData(GDatasourceMetadataKeys.DATASOURCE_ID.getValue(), datasourceMetadata.getId());
				datasourceRow.setData(GDatasourceMetadataKeys.DATASOURCE_LABEL.getValue(), datasourceMetadata.getLabel());
				listData.add(datasourceRow);
			});
			GRangingHelper.setListDataSize(listData, datasourceMetadataList);
			resultData.setData(GDatasourceMetadataKeys.DATASOURCE_LIST.getValue(), listData);
		}
		return resultData;
	}

	/**
	 * {@link GParameter}から{@link GRange}を生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @return {@link GRange}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GRange getPaginationCondition(GParameter parameter) {
		return GRangingHelper.getPaginationCondition(parameter, GDatasourceMetadataKeys.DATASOURCE_LIST.getValue());
	}

}
