/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.helper;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportConditionExportField;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportConditionExportFieldImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportConditionImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportFileTypeMapper;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportedResult;
import jp.co.kccs.greenearth.framework.fqeria.GDatasourceMetadataKeys;
import jp.co.kccs.greenearth.framework.fqeria.GExportConditionKeys;


/**
 * 画面パラメータ{@link GParameter}から値を取得、また結果を{@link GResultData}に格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GExportConditionHelper {

    /**
     * {@link GParameter}から{@link GExportCondition} に変換します. <br>
     *
     * @create 2023/10/25
     * @param parameter 画面パラメータ
     * @return {@link GExportCondition}
     * @author KCCS dhiaz
     * @since 23.10.0
     */
    public static GExportCondition convertTo(GParameter parameter) {
        GExportFileTypeMapper exportFileTypeMapper = GFrameworkUtils.getComponent(GExportFileTypeMapper.class);
        String datasourceId = parameter.getValue(GExportConditionKeys.DATASOURCE_ID.getValue());
        GExportCondition exportCondition = new GExportConditionImpl(
                parameter.getValue(GExportConditionKeys.EXPORT_NAME.getValue()),
                parameter.getBoolean(GExportConditionKeys.USE_HEADER.getValue()),
                exportFileTypeMapper.get(parameter.getValue(GExportConditionKeys.FILE_TYPE.getValue())),
                convertToExportList(parameter),
                datasourceId
        );
        validateExportCondition(exportCondition);
        return exportCondition;
    }

    /**
     * {@link GExportedResult} を｛@link GResultData}へ格納します. <br>
     * 
     * @create 2023/10/25
     * @param file {@link GExportedResult}
     * @param resultData @link GResultData}
     * @return resultData @link GResultData}
     * @author KCCS dhiaz
     * @since 23.10.0
     */
    public static GResultData convertTo(GExportedResult<File> file, GResultData resultData) {
        if (Objects.nonNull(file)) {
            GDownloadFile downloadFile = new GDownloadFile(file.getMedia());
            downloadFile.setDeleteFlag(true);
            downloadFile.setName(file.getMediaName());
            resultData.setDownloadFile(downloadFile);
            resultData.setExitCode(GResultData.EXIT_CODE_FILE_DOWNLOAD);
        }
        return resultData;
    }

    /**
     * {@link GExportCondition}の検証をします. <br>
     * 
     * @create 2023/10/25
     * @param exportCondition
     * @author KCCS 200450201
     * @since 23.10.0
     */
    public static void validateExportCondition(GExportCondition exportCondition) {
        Objects.requireNonNull(exportCondition, "export condition cannot be null");
        Objects.requireNonNull(exportCondition.getFileName(), "file name cannot be null");
        Objects.requireNonNull(exportCondition.getExportFields(), "export field cannot be null");
        Objects.requireNonNull(exportCondition.getFileType(), "file type cannot be null");
        Objects.requireNonNull(exportCondition.getDatasourceId(), "datasource id cannot be null");
    }

    /**
     * {@link GParameter}から{@link GExportConditionExportField} のリストに変換します. <br>
     *
     * @create 2023/10/25
     * @param parameter {@link GParameter}
     * @return {@link GExportConditionExportField}のリスト
     * @author KCCS dhiaz
     * @since 23.10.0
     */
    protected static List<GExportConditionExportField> convertToExportList(GParameter parameter) {
        GListData exportFieldList = GEXActionUtils.extractListData(parameter, GDatasourceMetadataKeys.DATASOURCE_FIELDS.getValue());
        if (Objects.isNull(exportFieldList)) {
            return Collections.emptyList();
        }
        return exportFieldList.getRows().stream()
                .map(rowData -> new GExportConditionExportFieldImpl(
                        rowData.getString(GDatasourceMetadataKeys.DATASOURCE_FIELD_ID.getValue()),
                        rowData.getInteger(GExportConditionKeys.EXPORT_FIELD_EXPORT_FLAG.getValue()) == 1
                ))
                .collect(Collectors.toList());
    }

}
