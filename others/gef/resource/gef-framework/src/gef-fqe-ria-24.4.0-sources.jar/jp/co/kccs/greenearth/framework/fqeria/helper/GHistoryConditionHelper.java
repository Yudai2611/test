/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.helper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportConditionExportField;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryConditionImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterFieldGroup;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionSortField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GSqlQueryOperator;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;
import jp.co.kccs.greenearth.framework.fqeria.GDatasourceMetadataKeys;
import jp.co.kccs.greenearth.framework.fqeria.GHistoryConditionKeys;


/**
 * 画面パラメータ{@link GParameter}から値を取得、また結果を{@link GResultData}に格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GHistoryConditionHelper {

	/**
	 * {@link GParameter}から{@link GHistoryCondition}に変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @return {@link GHistoryCondition}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GHistoryCondition convertTo(GParameter parameter) {
		GHistoryCondition historyCondition = new GHistoryConditionImpl();
		String historyId = parameter.getValue(GHistoryConditionKeys.HISTORY_ID.getValue());
		String historyName = parameter.getValue(GHistoryConditionKeys.HISTORY_NAME.getValue());
		historyCondition.setExportCondition(GExportConditionHelper.convertTo(parameter));
		historyCondition.setImportCondition(GImportConditionHelper.convertTo(parameter));
		historyCondition.setName(historyName);
		historyCondition.setId(historyId);

		validateHistoryCondition(historyCondition);

		return historyCondition;
	}

	/**
	 * {@link GHistoryCondition}リストから{@link GResultData}に変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param historyConditionList {@link GHistoryCondition}
	 * @return {@link GResultData}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GResultData convertTo(GRangeResult<GHistoryCondition> historyConditionList, GResultData resultData) {
		GDatasourceMetadataService datasourceMetadataService = GFrameworkUtils.getComponent(GDatasourceMetadataService.class);
		GListData listData = new GListData();
		if (Objects.nonNull(historyConditionList) && Objects.nonNull(historyConditionList.getResult())) {
			historyConditionList.getResult().forEach(historyCondition -> {
				GRowData rowData = new GRowData();
				Objects.requireNonNull(historyCondition.getImportCondition(), "import condition is not found");
				String datasourceId = historyCondition.getImportCondition().getDatasourceId();
				GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata = null;
				try {
					datasourceMetadata = datasourceMetadataService.lookupById(datasourceId);
				} catch (NullPointerException e) {
					throw new GFrameworkException(datasourceId + " is not found");
				}
				if (datasourceMetadata != null) {
					rowData.setData(GHistoryConditionKeys.HISTORY_NAME.getValue(), historyCondition.getName());
					rowData.setData(GHistoryConditionKeys.HISTORY_ID.getValue(), historyCondition.getId());
					rowData.setData(GHistoryConditionKeys.DATASOURCE_LABEL.getValue(), datasourceMetadata.getLabel());
					rowData.setData(GHistoryConditionKeys.DATASOURCE_ID.getValue(), datasourceId);
					rowData.setData(GHistoryConditionKeys.SAVED_BY.getValue(), historyCondition.getSavedBy());
					rowData.setData(GHistoryConditionKeys.SAVED_AT.getValue(), historyCondition.getSavedAt());
					listData.add(rowData);
				}
			});
			GRangingHelper.setListDataSize(listData, historyConditionList);
			resultData.setData(GHistoryConditionKeys.HISTORY_CONDITION_LIST.getValue(), listData);
		}
		return resultData;
	}

	
	/**
	 * {@link GHistoryCondition}から{@link GResultData}に変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param historyCondition {@link GHistoryCondition}
	 * @return {@link GResultData}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GResultData convertTo(GHistoryCondition historyCondition, GResultData resultData) {
		if (!Objects.isNull(historyCondition)) {
			Objects.requireNonNull(historyCondition.getImportCondition(), "import condition is not found");
			Objects.requireNonNull(historyCondition.getExportCondition(), "export condition is not found");
			GDatasourceMetadataService datasourceMetadataService = GFrameworkUtils.getComponent(GDatasourceMetadataService.class);
			String datasourceId = historyCondition.getImportCondition().getDatasourceId();
			GDatasourceMetadata<? extends GDatasourceType> datasourceMetadata = datasourceMetadataService.lookupById(datasourceId);
			if (datasourceMetadata != null) {
				Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap =
					GDatasourceUtil.toFieldMetadataMap(datasourceMetadata.getDatasourceFields());
				resultData.setData(GHistoryConditionKeys.DATASOURCE_ID.getValue(), datasourceId);
				resultData.setData(GHistoryConditionKeys.DATASOURCE_LABEL.getValue(), datasourceMetadata.getLabel());
				resultData.setData(GHistoryConditionKeys.USE_HEADER.getValue(), historyCondition.getExportCondition().isUseHeader());
				resultData.setData(GHistoryConditionKeys.FILE_TYPE.getValue(), historyCondition.getExportCondition().getFileType().getValue());
				resultData.setData(GHistoryConditionKeys.HISTORY_NAME.getValue(), historyCondition.getName());
				resultData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELDS.getValue(),
					convertToExportFields(historyCondition.getExportCondition().getExportFields(), datasourceFieldMetadataMap));
				List<GListData> filterListData =
					convertToFilterFields(historyCondition.getImportCondition().getFilterFields(), datasourceFieldMetadataMap);
				for (int i = 0; i < filterListData.size(); i++) {
					resultData.setData(GHistoryConditionKeys.FILTER_FIELD_LIST.getValue() + i, filterListData.get(i));
				}
				resultData.setData(GHistoryConditionKeys.FILTER_GROUP_LIST.getValue() + ".displaysize", filterListData.size());
				resultData.setData(GHistoryConditionKeys.SORT_FIELD_LIST.getValue(),
					convertToSortFields(historyCondition.getImportCondition().getSortFields(), datasourceFieldMetadataMap));

			}

		}
		return resultData;
	}
	
	/**
	 * {@link GParameter}から{@link GRange}にを生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @return {@link GRange}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GRange getPaginationCondition(GParameter parameter) {
		return GRangingHelper.getPaginationCondition(parameter, GHistoryConditionKeys.HISTORY_CONDITION_LIST.getValue());
	}

	
	/**
	 * {@link GExportConditionExportField}のリストから{@link GListData}に変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param exportFields {@link GExportConditionExportField}のリスト
	 * @return {@link GListData}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private static GListData convertToExportFields(List<GExportConditionExportField> exportFields,
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap) {
		GListData listData = new GListData();
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMapClone = new LinkedHashMap<>(datasourceFieldMetadataMap);
		if (Objects.nonNull(exportFields)) {
			exportFields.forEach(exportField -> {
				GRowData rowData = new GRowData();
				GDatasourceFieldMetadata datasourceFieldMetadata = datasourceFieldMetadataMapClone.get(exportField.getFieldId());
				if (Objects.nonNull(datasourceFieldMetadata)) {
					rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_ID.getValue(), datasourceFieldMetadata.getId());
					rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_LABEL.getValue(), datasourceFieldMetadata.getLabel());
					rowData.setData(GHistoryConditionKeys.EXPORT_FIELD_EXPORT_FLAG.getValue(), exportField.isUseField());
					rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_DATA_TYPE.getValue(), datasourceFieldMetadata.getDataType().getValue());
					listData.add(rowData);
					datasourceFieldMetadataMapClone.remove(exportField.getFieldId());
				}
			});
		}
		datasourceFieldMetadataMapClone.values().forEach(datasourceFieldMetadata -> {
			GRowData rowData = new GRowData();
			rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_ID.getValue(), datasourceFieldMetadata.getId());
			rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_LABEL.getValue(), datasourceFieldMetadata.getLabel());
			rowData.setData(GHistoryConditionKeys.EXPORT_FIELD_EXPORT_FLAG.getValue(), false);
			rowData.setData(GDatasourceMetadataKeys.DATASOURCE_FIELD_DATA_TYPE.getValue(), datasourceFieldMetadata.getDataType().getValue());
			listData.add(rowData);
		});
		return listData;
	}

	/**
	 * {@link GImportConditionFilterField}のリストから{@link GListData}のリストに変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param filterFieldsList {@link GImportConditionFilterField}のトリスト
	 * @return {@link GListData}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private static List<GListData> convertToFilterFields(List<GImportConditionFilterFieldGroup> filterFieldsList,
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap) {
		List<GListData> lists = new ArrayList<GListData>();
		if (Objects.nonNull(filterFieldsList)) {
			for (GImportConditionFilterFieldGroup importConditionFilterFieldGroup : filterFieldsList) {
				GListData listData = new GListData();
				lists.add(listData);
				if (Objects.isNull(importConditionFilterFieldGroup)) {
					continue;
				}
				if (Objects.nonNull(importConditionFilterFieldGroup.getFilterFields())) {
					for (GImportConditionFilterField exportConditionFilterField : importConditionFilterFieldGroup.getFilterFields()) {
						GRowData rowData = new GRowData();
						String columnId = exportConditionFilterField.getFieldId();
						GDatasourceFieldMetadata datasourceFieldMetadata = datasourceFieldMetadataMap.get(columnId);
						if (datasourceFieldMetadata != null) {
							GSqlQueryOperator sqlQueryOperator = exportConditionFilterField.getOperator();
							rowData.setData(GHistoryConditionKeys.FILTER_FIELD_ID.getValue(), columnId);
							rowData.setData(GHistoryConditionKeys.FILTER_FIELD_LABEL.getValue(), datasourceFieldMetadata.getLabel());
							rowData.setData(GHistoryConditionKeys.FILTER_FIELD_OPERATOR.getValue(), sqlQueryOperator.getInternalParam());
							listData.add(rowData);
							if (sqlQueryOperator == GSqlQueryOperator.IS_NULL || sqlQueryOperator == GSqlQueryOperator.IS_NOT_NULL) {
								continue;
							}
							StringBuilder values = new StringBuilder();
							int filterValueSize = exportConditionFilterField.getValue().size();
							for (int i = 0; i < filterValueSize; i++) {
								values.append(exportConditionFilterField.getValue().get(i));
								if (i < filterValueSize - 1) {
									values.append(System.lineSeparator());
								}
							}
							rowData.setData(GHistoryConditionKeys.FILTER_FIELD_VALUE.getValue(), values.toString());
						}
					}
				}
				
			}
		}
		return lists;
	}

	/**
	 * {@link GImportConditionSortField}のリストから{@link GListData}に変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param sortFields {@link GImportConditionSortField}のリスト
	 * @return {@link GListData}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private static GListData convertToSortFields(List<GImportConditionSortField> sortFields,
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap) {
		GListData listData = new GListData();
		if (!Objects.isNull(sortFields)) {
			sortFields.forEach(column -> {
				GDatasourceFieldMetadata datasourceFieldMetadata = datasourceFieldMetadataMap.get(column.getFieldId());
				if (datasourceFieldMetadata != null) {
					GRowData rowData = new GRowData();
					rowData.setData(GHistoryConditionKeys.SORT_FIELD_ID.getValue(), column.getFieldId());
					rowData.setData(GHistoryConditionKeys.SORT_FIELD_LABEL.getValue(), datasourceFieldMetadata.getLabel());
					rowData.setData(GHistoryConditionKeys.SORT_FIELD_ORDER.getValue(), column.getOrder());
					listData.add(rowData);
				}
			});
		}
		return listData;
	}

	/**
	 * {@link GHistoryCondition}の検証をします. <br>
	 * 
	 * @create 2023/10/25
	 * @param historyCondition {@link GHistoryCondition}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	private static void validateHistoryCondition(GHistoryCondition historyCondition) {
		Objects.requireNonNull(historyCondition.getName());
		GExportConditionHelper.validateExportCondition(historyCondition.getExportCondition());
	}

}
