/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFieldSortOrder;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterFieldGroup;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterFieldGroupImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionFilterFieldImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionImportField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionImportFieldImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionSortField;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportConditionSortFieldImpl;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GSqlQueryOperator;
import jp.co.kccs.greenearth.framework.fqeria.GDatasourceMetadataKeys;
import jp.co.kccs.greenearth.framework.fqeria.GExportConditionKeys;
import jp.co.kccs.greenearth.framework.fqeria.GImportConditionKeys;

/**
 * 画面パラメータ{@link GParameter}から値を取得、また結果を{@link GResultData}に格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GImportConditionHelper {

	/**
	 * {@link GParameter}から{@link GImportCondition}を生成します. <br>
	 * 
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @return {@link GImportCondition}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static GImportCondition convertTo(GParameter parameter) {
		String datasourceId = parameter.getValue(GExportConditionKeys.DATASOURCE_ID.getValue());
		GImportCondition importCondition = new GImportConditionImpl(datasourceId, convertToImportList(parameter),
			convertToFilterFields(parameter), convertToSortList(parameter));
		validateImportCondition(importCondition);
		return importCondition;
	}

	/**
	 * {@link GImportCondition}の検証をします. <br>
	 * 
	 * @create 2023/10/25
	 * @param importCondition
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	public static void validateImportCondition(GImportCondition importCondition) {
		Objects.requireNonNull(importCondition.getImportFields());
		Objects.requireNonNull(importCondition.getFilterFields());
		Objects.requireNonNull(importCondition.getSortFields());
		Objects.requireNonNull(importCondition.getDatasourceId());
	}

	/**
	 * {@link GParameter}から{@link GImportConditionFilterField}のネストリストに変換します. <br>
	 *
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @return {@link GImportConditionFilterField} のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected static List<GImportConditionFilterFieldGroup> convertToFilterFields(GParameter parameter) {
		int maxSize = parameter.getInteger(GImportConditionKeys.FILTER_GROUP_LIST.getValue() + ".displaysize");
		List<GImportConditionFilterFieldGroup> filterFieldGroupList = new ArrayList<>();
		int groupIndex = 0;
		for (int i = 0; i < maxSize; i++) {
			GListData firstDimensionFilterFieldList = GEXActionUtils.extractListData(parameter, GImportConditionKeys.FILTER_FIELD_LIST.getValue() + i);
			firstDimensionFilterFieldList = Objects.requireNonNullElse(firstDimensionFilterFieldList, new GListData());
			List<GImportConditionFilterField> filterFields = new ArrayList<>();
			for (int j = 0; j < firstDimensionFilterFieldList.size(); j++) {
				GRowData filterFieldList = firstDimensionFilterFieldList.get(j);
				String fieldId = filterFieldList.getString(GImportConditionKeys.FILTER_FIELD_ID.getValue());
				int operator = filterFieldList.getInteger(GImportConditionKeys.FILTER_FIELD_OPERATOR.getValue());

				List<String> fieldValues =
					List.of(filterFieldList.getString(GImportConditionKeys.FILTER_FIELD_VALUE.getValue()).split(System.lineSeparator(), -1));

				filterFields.add(j, new GImportConditionFilterFieldImpl(fieldId, fieldValues, GSqlQueryOperator.of(operator)));
			}
			if (!firstDimensionFilterFieldList.isEmpty()) {
				filterFieldGroupList.add(groupIndex, new GImportConditionFilterFieldGroupImpl(filterFields));
				groupIndex++;
			}
		}
		return filterFieldGroupList;
	}

	/**
	 * {@link GParameter}から{@link GImportConditionImportField}のリストを生成します. <br>
	 *
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @return {@link GImportConditionImportField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected static List<GImportConditionImportField> convertToImportList(GParameter parameter) {
		GListData importFieldList = GEXActionUtils.extractListData(parameter, GDatasourceMetadataKeys.DATASOURCE_FIELDS.getValue());
		if (Objects.isNull(importFieldList) || Objects.isNull(importFieldList.getRows())) {
			return Collections.emptyList();
		}
		return importFieldList.getRows().stream()
			.map(rowData -> new GImportConditionImportFieldImpl(rowData.getString(GDatasourceMetadataKeys.DATASOURCE_FIELD_ID.getValue()),
				rowData.getInteger(GExportConditionKeys.EXPORT_FIELD_EXPORT_FLAG.getValue()) == 1))
			.collect(Collectors.toList());
	}

	/**
	 * {@link GParameter}から{@link GImportConditionSortField}のリストを生成します. <br>
	 *
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @return {@link GImportConditionSortField}のリスト
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected static List<GImportConditionSortField> convertToSortList(GParameter parameter) {
		GListData sortFieldList = GEXActionUtils.extractListData(parameter, GImportConditionKeys.SORT_FIELD_LIST.getValue());
		if (Objects.isNull(sortFieldList)) {
			return Collections.emptyList();
		}
		return sortFieldList.getRows().stream()
			.map(rowData -> new GImportConditionSortFieldImpl(rowData.getString(GImportConditionKeys.SORT_FIELD_ID.getValue()),
				GImportConditionFieldSortOrder.valueOf(rowData.getString(GImportConditionKeys.SORT_FIELD_ORDER.getValue()))))
			.collect(Collectors.toList());
	}
}
