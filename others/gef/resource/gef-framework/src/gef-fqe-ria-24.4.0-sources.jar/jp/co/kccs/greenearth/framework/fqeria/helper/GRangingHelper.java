/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.helper;

import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeImpl;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GPagingNavigator;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GSearchMode;

/**
 * 画面パラメータ{@link GParameter}から値を取得、また結果を{@link GResultData}に格納するクラスです. <br>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz
 * @since 23.10.0
 */
public class GRangingHelper {

	/**
	 * {@link GParameter}からリストサイズ<code>listSize</code>を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @param listId リストID
	 * @return リストサイズ
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected static int getListSize(GParameter parameter, String listId) {
		int listSize = GPagingNavigator.DEFAULT_LIST_SIZE;
		String strListSize = parameter.getValue(listId + GPagingNavigator.LISTSIZE);
		if (GStringUtils.isNotEmpty(strListSize)) {
			listSize = Integer.parseInt(strListSize);
		}
		return listSize;
	}

	/**
	 * {@link GParameter}からページ情報を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @param listId リストID
	 * @return {@link GRangeImpl}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected static GRange getPaginationCondition(GParameter parameter, String listId) {
		GSearchMode searchMode = GSearchMode.create(parameter.getValue(GActionServlet.ACTION_MODE_KEY));
		int totalCount = parameter.getInteger(listId + ".totalsize");
		int pageSize = GRangingHelper.getListSize(parameter, listId);
		int startIndex =
			GPagingNavigator.calculateStartIndex(GRangingHelper.getStartIndex(parameter, listId), pageSize, totalCount, searchMode);
		return new GRangeImpl(startIndex, startIndex + pageSize);
	}

	/**
	 * {@link GParameter}からリスト開始位置<code>startIndex</code>を取得します. <br>
	 * 
	 * @create 2023/10/25
	 * @param parameter {@link GParameter}
	 * @param listId リストID
	 * @return startIndex リスト開始位置
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected static int getStartIndex(GParameter parameter, String listId) {
		int startIndex = 0;
		String strStartIndex = parameter.getValue(listId + GPagingNavigator.STARTINDEX);
		if (GStringUtils.isNotEmpty(strStartIndex)) {
			startIndex = Integer.parseInt(strStartIndex);
		}
		return startIndex;
	}

	/**
	 * {@link GRangeResult}を{@link GListData}を格納します. <br>
	 * 
	 * @create 2023/10/25
	 * @param listData {@link GListData}
	 * @param rangeResult {@link GRangeResult}
	 * @author KCCS dhiaz
	 * @since 23.10.0
	 */
	protected static <T> void setListDataSize(GListData listData, GRangeResult<T> rangeResult) {
		GRange range = rangeResult.getRange();
		listData.setStartIndex(range.getBeginIndex());
		listData.setMaxListSize(range.getEndIndex() - range.getBeginIndex());
		listData.setTotalSize(rangeResult.getOverallSize());
	}

}
