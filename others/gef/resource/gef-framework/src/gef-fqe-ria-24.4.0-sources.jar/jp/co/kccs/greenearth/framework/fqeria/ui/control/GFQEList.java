/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListRow;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPList;

/**
 * リストを表すUIコンポーネントです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
public class GFQEList extends GPList {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = -4085441262775177617L;

	/** 動的に追加可能な最大行数. */
	private String _maxlistsize;

	/** 隠し明細行. */
	private GFQEListRow _tempListRow;

	/**
	 * デフォルトコンストラクタです.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEList() {
	}

	/**
	 * 動的に追加可能な最大行数を取得します.
	 *
	 * @create 2023/10/25
	 * @return 動的に追加可能な最大行数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public String getMaxlistsize() {
		return _maxlistsize;
	}

	/**
	 * 名前空間を取得します.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public String getLabelspace() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getLabelspace());
		prefixBuilder.append(GStringUtils.nullToBlank(getLabel()));
		return prefixBuilder.toString();
	}

	/**
	 * 隠し明細行を取得します.
	 *
	 * @create 2023/10/25
	 * @return 隠し明細行
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListRow getTempListRow() {
		return _tempListRow;
	}

	/**
	 * 1階層までをローディング、今のところ2階層目以降はロードしない.
	 *
	 * @create 2023/10/25
	 * @param parameter
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		GListData listData = GEXActionUtils.extractListData(parameter, getName());
		if (listData == null) {
			listData = new GListData();
		}
		loadData(listData);
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * リポジトリ情報より、隠し明細行を生成します.
	 *
	 * @create 2023/10/25
	 * @see GPList#loadResultData(GResultData)
	 * @param data 結果セット
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		GListRow repository = ((GPList) getRepository()).getRows().get(0);
		_tempListRow = (GFQEListRow) repository.createPracticalInstance();
		_tempListRow.setParent(this);
		_tempListRow.setTemp(true);
		super.loadResultData(data);
	}

	/**
	 * 動的に追加可能な最大行数を設定します.
	 *
	 * @create 2023/10/25
	 * @param maxlistsize 動的に追加可能な最大行数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setMaxlistsize(String maxlistsize) {
		_maxlistsize = maxlistsize;
	}

	/**
	 * 隠し明細行を設定します.
	 *
	 * @create 2023/10/25
	 * @param tempListRow 隠し明細行
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTempListRow(GFQEListRow tempListRow) {
		_tempListRow = tempListRow;
	}
}
