/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListFooter;

/**
 * リストのヘッダを表すUIアイテムです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
public class GFQEListFooter extends GPListFooter {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4100705499362379871L;

	/**
	 * デフォルトコンストラクタです.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListFooter() {
	}
}
