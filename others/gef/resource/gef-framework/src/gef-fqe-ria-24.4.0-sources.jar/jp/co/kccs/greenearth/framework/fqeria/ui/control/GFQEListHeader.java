/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListHeader;

/**
 * リストのヘッダを表すUIアイテムです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
public class GFQEListHeader extends GPListHeader {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = -1013888563444405523L;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListHeader() {
	}
}
