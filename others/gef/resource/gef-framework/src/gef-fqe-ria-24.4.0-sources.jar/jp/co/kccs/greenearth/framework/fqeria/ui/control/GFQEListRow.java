/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListRow;

/**
 * リストの明細行を表すUIアイテムです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
public class GFQEListRow extends GPListRow {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = -6932899632955840835L;

	/** 隠し明細行の判定フラグ. */
	private boolean _isTemp;
	/** ID接頭語 */
	private String _prefix = null;
	/** リクエストパラメータキーの完全な接頭語 */
	private String _nameprefix = null;

	/**
	 * デフォルトコンストラクタです.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListRow() {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#getNamePrefix()
	 */
	@Override
	public String getNamePrefix() {
		if (_nameprefix == null) {
			String namePrefix = null;
			if (getParent() != null) {
				StringBuilder prefixBuilder = new StringBuilder();
				prefixBuilder.append(getParent().getNamePrefix());
				if (isTemp()) {
					prefixBuilder.append("temp.");
				}
				namePrefix = prefixBuilder.toString();
			}
			_nameprefix = GStringUtils.nullToBlank(namePrefix);
		}
		return _nameprefix;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#getPrefix()
	 */
	@Override
	public String getPrefix() {
		if (_prefix == null) {
			String prefix = null;
			if (getParent() != null) {
				StringBuilder prefixBuilder = new StringBuilder();
				prefixBuilder.append(getParent().getPrefix());
				prefixBuilder.append(isTemp() ? "temp" : getRowIndex());
				prefixBuilder.append(".");
				prefix = prefixBuilder.toString();
			}
			_prefix = GStringUtils.nullToBlank(prefix);
		}
		return _prefix;
	}

	/**
	 * {@link GFQEListRow}インスタンスが隠し明細行であるかどうかを判定します.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public boolean isTemp() {
		return _isTemp;
	}

	/**
	 * {@link GFQEListRow}インスタンスが隠し明細行の有効/無効を設定します.
	 *
	 * @create 2023/10/25
	 * @param isTemp 隠し明細行の有効/無効
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTemp(boolean isTemp) {
		_isTemp = isTemp;
	}
}
