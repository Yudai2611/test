/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase;
import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * タブを表すUIアイテムです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0t
 */
public class GFQETab extends GUIContainerControlBase {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = 4642208180422606088L;

	/** 表示状態のタブの数. */
	private int _displaysize = 1;

	/** タブの表示名. */
	private String _label;

	/** 動的に追加可能な最大タブ数. */
	private String _size;

	/** タブUIコントロールリスト. */
	private List<List<GUIControl>> _tabControls = new ArrayList<List<GUIControl>>();

	/** 選択状態のタブのインデックス. */
	private int _tabSelected = 0;
	
	/** タブのインデックス. */
	private List<Integer>_tabIndexes = new ArrayList<Integer>();

	/**
	 * デフォルトコンストラクタです.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQETab() {
	}

	/**
	 * コンテナとして格納しているタブUIコントロールリストにUIコントロールを追加します.<br>
	 * リポジトリとは別の動的インスタンスとして格納します.<br>
	 * また、タブUIコントロールリスト内の各UIコントロールを識別するため、タブ毎にインデックスを割り当て<br>
	 * タブUIコントロールリスト内の各UIコントロールのIDにもインデックスを付加して格納します.
	 *
	 * @create 2023/10/25
	 * @see GUIContainerControlBase#addControl(GUIControl)
	 * @param control UIコントロール
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void addControl(GUIControl control) {
		super.addControl(control);
		int sizeInt = Integer.parseInt(_size);
		for (int i = 0; i < sizeInt; i++) {
			if (i >= _tabControls.size()) {
				_tabControls.add(new ArrayList<GUIControl>());
			}
			List<GUIControl> controls = _tabControls.get(i);
			GUIControl newControl = (GUIControl) control.createPracticalInstance();
			controls.add(newControl);
			((GVariableControl) newControl).setName(control.getId() + i);
			newControl.setId(control.getId() + i);

		}
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * タブの選択状態、表示数を初期状態に戻します.<br>
	 * また、タブUIコントロールリスト内のすべての子UIコントロールに対して、<br>
	 * {@link GUIControl#reset()}を呼び出しています.<br>
	 *
	 * @create 2023/10/25
	 * @see GUIControl#clear()
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void clear() {
		super.clear();
		_tabSelected = 0;
		_displaysize = 1;
		for (List<GUIControl> controls : _tabControls) {
			for (GUIControl control : controls) {
				control.clear();
			}
		}
	}

	/**
	 * 格納しているタブのUIコントロール内から、指定したidのUIコントロールを検索します.<br>
	 * コンテナとして格納している子UIコントロール内も検索します.<br>
	 * 該当するUIコントロールが存在しない場合は<code>null</code>を返します.
	 *
	 * @create 2023/10/25
	 * @see GUIContainerControlBase#findControl(String)
	 * @param id UIコントロールID
	 * @return UIコントロールオブジェクト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public GUIControl findControl(String id) {
		GUIControl findControl = super.findControl(id);
		if (findControl != null) {
			return findControl;
		}
		for (List<GUIControl> controls : _tabControls) {
			for (GUIControl control : controls) {
				if (id.equals(control.getId())) {
					return control;
				}
				GUIControl child = control.findControl(id);
				if (child != null) {
					return child;
				}
			}
		}
		return null;
	}

	/**
	 * 表示状態のタブの数を取得します.
	 *
	 * @create 2023/10/25
	 * @return 表示状態のタブの数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public int getDisplaysize() {
		return _displaysize;
	}

	/**
	 * タブの表示名を取得します.
	 *
	 * @create 2023/10/25
	 * @return タブの表示名
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public String getLabel() {
		return _label;
	}

	/**
	 * 動的に追加可能な最大タブ数を取得します.
	 *
	 * @create 2023/10/25
	 * @return 動的に追加可能な最大タブ数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * タブUIコントロールリストを取得します.
	 *
	 * @create 2023/10/25
	 * @return タブUIコントロールリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public List<List<GUIControl>> getTabControls() {
		return _tabControls;
	}

	/**
	 * 表示されているタブのインデックスを取得します.
	 *
	 * @create 2023/10/25
	 * @return タブのインデックスリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public List<Integer> getTabIndexes() {
		return _tabIndexes;
	}
	
	/**
	 * 選択状態のタブのインデックスを取得します.
	 *
	 * @create 2023/10/25
	 * @return 選択状態のタブのインデックス
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public int getTabSelected() {
		return _tabSelected;
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br>
	 * タブの選択状態、表示数を読み込みます.<br>
	 * タブUIコントロールリスト内のすべての子UIコントロールに対して、<br>
	 * {@link GUIControl#loadParameter(GParameter)}を呼び出しています.<br>
	 *
	 * @create 2023/10/25
	 * @see GUIControl#loadParameter(GParameter)
	 * @param parameter パラメータ
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		if (parameter.containsValueKey(getFullId() + ".selected")) {
			_tabSelected = parameter.getInteger(getFullId() + ".selected");
		}
		if (parameter.containsValueKey(getFullId() + ".displaysize")) {
			_displaysize = parameter.getInteger(getFullId() + ".displaysize");
		}
		_tabIndexes.clear();
		for (int i = 0; i < Integer.parseInt(_size); i++) {
			if (parameter.containsValueKey(getFullId() + ".index-" + i)) {
				_tabIndexes.add(parameter.getInteger(getFullId() + ".index-" + i));
				for (GUIControl control : _tabControls.get(i)) {
					control.setLabel(getLabel() + _tabIndexes.get(i));
				}
			}
		}
		for (List<GUIControl> controls : _tabControls) {
			for (GUIControl control : controls) {
				control.loadParameter(parameter);
			}
		}
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * タブUIコントロールリスト内のすべての子UIコントロールに対して、<br>
	 * {@link GUIControl#loadResultData(GResultData)}を呼び出しています.<br>
	 *
	 * @create 2023/10/25
	 * @see GUIControl#loadResultData(GResultData)
	 * @param data 結果セット
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		for (List<GUIControl> controls : _tabControls) {
			for (GUIControl control : controls) {
				control.loadResultData(data);
			}
		}
	}

	/**
	 * このコントロール及び子コントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * タブの選択状態、表示数を初期状態に戻します.<br>
	 * また、タブUIコントロールリスト内のすべての子UIコントロールに対して、<br>
	 * {@link GUIControl#reset()}を呼び出しています.<br>
	 *
	 * @create 2023/10/25
	 * @see GUIControl#reset()
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void reset() {
		super.reset();
		_tabSelected = 0;
		_displaysize = 1;
		for (int i = 0; i < _tabControls.size(); i++) {
			List<GUIControl> controls = _tabControls.get(i);
			for (GUIControl control : controls) {
				control.reset();
				((GVariableControl) control).setName(control.getId() + i);
				control.setId(control.getId() + i);
				((GVariableControl) control).setLabel(control.getLabel() + (i + 1));
			}
		}
	}

	/**
	 * 表示状態のタブの数を設定します.
	 *
	 * @create 2023/10/25
	 * @param displaysize 表示状態のタブの数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setDisplaysize(int displaysize) {
		_displaysize = displaysize;
	}

	/**
	 * タブの表示名を設定します.
	 *
	 * @create 2023/10/25
	 * @param label タブの表示名
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setLabel(String label) {
		_label = label;
	}

	/**
	 * 動的に追加可能な最大タブ数を設定します.
	 *
	 * @create 2023/10/25
	 * @param size 動的に追加可能な最大タブ数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setSize(String size) throws CloneNotSupportedException {
		_size = size;
	}

	/**
	 * タブUIコントロールリストを設定します.
	 *
	 * @create 2023/10/25
	 * @param tabControls タブUIコントロールリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTabControls(List<List<GUIControl>> tabControls) {
		_tabControls = tabControls;
	}

	/**
	 * 表示されているタブのインデックスを設定します.
	 *
	 * @create 2023/10/25
	 * @param tabIndexes タブのインデックスリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTabIndexes(List<Integer> tabIndexes) {
		_tabIndexes = tabIndexes;
	}
	
	/**
	 * 選択状態のタブのインデックスを設定します.
	 *
	 * @create 2023/10/25
	 * @param tabSelected 選択状態のタブのインデックス
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTabSelected(int tabSelected) {
		_tabSelected = tabSelected;
	}
}
