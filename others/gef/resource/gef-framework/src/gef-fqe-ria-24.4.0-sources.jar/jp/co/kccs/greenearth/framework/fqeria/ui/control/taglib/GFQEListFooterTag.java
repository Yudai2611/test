/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control.taglib;


import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQEListFooter;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListFooterTag;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * リストのフッターを表示するタグクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
@TargetUIComponent(GFQEListFooter.class)
public class GFQEListFooterTag extends GPListFooterTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 6614388595943144207L;

	/**
	 * デフォルトコンストラクタです. <br>
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListFooterTag() {
	}
}
