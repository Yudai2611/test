/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control.taglib;


import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQEListHeader;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListHeaderTag;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * リストのヘッダを表示するタグクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
@TargetUIComponent(GFQEListHeader.class)
public class GFQEListHeaderTag extends GPListHeaderTag {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = 6033038434062026604L;

	/**
	 * デフォルトコンストラクタです. <br>
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListHeaderTag() {
	}
}
