/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control.taglib;


import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;
import jakarta.servlet.jsp.tagext.TagSupport;
import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQEListRow;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListRow;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListRowTag;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListTag;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストの明細行を表示するタグクラスです. <br>
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
@TargetUIComponent(GFQEListRow.class)
public class GFQEListRowTag extends GPListRowTag {

	/**
	 * 隠し明細行のデフォルトのスタイルクラス名. <br>
	 * 
	 * @deprecated 内部処理制御用のため使用しないでください。
	 */
	private static final String DEFAULT_STYLECLASS_TEMPROW = "temprow";

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = 5695010086732051527L;

	/** 隠し明細行の判定フラグ. */
	private boolean _isTemp = false;

	/**
	 * デフォルトコンストラクタです. <br>
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListRowTag() {
	}

	/**
	 * 終了タグの標準処理です.<br>
	 *
	 * @create 2023/10/25
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public int doEndTag() throws JspException {
		GPListTag parent = (GPListTag) TagSupport.findAncestorWithClass(this, GPListTag.class);
		if (parent != null) {
			if (parent.getCurrentRowIndex() == parent.getRows().size() - 1) {
				GTagBuilder bodyTag = new GTagBuilder("tbody");
				GTagUtils.printOut(pageContext, bodyTag.createEndTagString());
			}
		}
		reset();
		return Tag.EVAL_PAGE;
	}

	/**
	 * TODO: [2011/08/25][yamashita]処理をすっきりさせる
	 *
	 * 開始タグの標準処理です.<br>
	 *
	 * @create 2023/10/25
	 * @see GPListRowTag#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public int doStartTag() throws JspException {
		GFQEListTag parent = (GFQEListTag) TagSupport.findAncestorWithClass(this, GFQEListTag.class);
		if (parent != null) {
			GListRow listRow = null;
			if (parent.getCurrentRowIndex() == -1) {
				GTagUtils.printOut(pageContext, "<tbody>");
				parent.setTempRow(true);
				listRow = parent.getTempListRow();
			} else {
				setRowIndex(parent.getCurrentRowIndex());
				listRow = parent.getRow(getRowIndex());
			}
			if (listRow != null) {
				load(listRow);
			}
			if (isVisible()) {
				return Tag.EVAL_BODY_INCLUDE;
			}
		}
		return Tag.SKIP_BODY;
	}

	/**
	 * デフォルトのスタイルシートのクラスを取得します.<br>
	 * 隠し明細行の場合、<code>"temprow"</code>を取得します.
	 *
	 * @create 2023/10/25
	 * @see GUIComponentBaseTag#getStyleclass()
	 * @return スタイルシートのクラス
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public String getStyleclass() {
		return _isTemp ? DEFAULT_STYLECLASS_TEMPROW : super.getStyleclass();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 以下の属性を読み込みます。<br>
	 * ・isTemp<br>
	 *
	 * @create 2023/10/25
	 * @see GPListRowTag#load(GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GFQEListRow listRow = (GFQEListRow) component;
		_isTemp = listRow.isTemp();
	}

	/**
	 * タグの状態をリセット(初期化)します. <br>
	 *
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#reset()
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void reset() {
		super.reset();
		_isTemp = false;
	}
}
