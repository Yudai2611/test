/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control.taglib;


import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.IterationTag;
import jakarta.servlet.jsp.tagext.Tag;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQEList;
import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQEListRow;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListTag;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * リストコントロールを表示するタグクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
@TargetUIComponent(GFQEList.class)
public class GFQEListTag extends GPListTag {

	/** 隠し明細行を評価しているかどうかを判定するフラグ. */
	private boolean _tempRow = false;

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = -3296769998560837210L;

	/** 動的に追加可能な最大行数. */
	private String _maxlistsize;

	/** 隠し明細行. */
	private GFQEListRow _tempListRow;

	/**
	 * デフォルトコンストラクタです. <br>
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListTag() {
	}

	/**
	 * type属性が<code>"hidden"</code>であるinput要素のXHTML文字列を生成します.<br>
	 * {@link GPListTag}の処理に加え、動的に追加可能な最大行数を値として保持する.<br>
	 * type属性が<code>"hidden"</code>であるinput要素を生成します.
	 *
	 * @create 2023/10/25
	 * @see GPListTag#createHiddenTagString()
	 * @return type属性が<code>"hidden"</code>であるinput要素のXHTML文字列
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	protected String createHiddenTagString() {
		StringBuilder xhtml = new StringBuilder();
		xhtml.append(super.createHiddenTagString());
		GTagBuilder maxlistsizeTag = new GTagBuilder("input");
		maxlistsizeTag.setAttribute("id", getFullId() + ".maxlistsize");
		maxlistsizeTag.setAttribute("name", getFullId() + ".maxlistsize");
		maxlistsizeTag.setAttribute("type", "hidden");
		maxlistsizeTag.setAttribute("value", _maxlistsize);
		maxlistsizeTag.setAttribute(GFrameworkUtils.getProperty(GUIComponentBaseTag.XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY),
			String.valueOf(false));
		xhtml.append(maxlistsizeTag.createTagString());
		return xhtml.toString();
	}

	/**
	 * ボディ評価後の処理です.<br>
	 * 所有している{@link GFQEListRow}の数だけ再評価します.
	 *
	 * @create 2023/10/25
	 * @see GPListTag#doAfterBody()
	 * @return {@link jakarta.servlet.jsp.tagext.IterationTag#EVAL_BODY_AGAIN}:再びBODYを評価します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public int doAfterBody() throws JspException {
		int returnCode = super.doAfterBody();
		if (returnCode == Tag.SKIP_BODY && !isTempRow()) {
			return IterationTag.EVAL_BODY_AGAIN;
		}
		return returnCode;
	}

	/**
	 * 隠し明細行を取得します.
	 *
	 * @create 2023/10/25
	 * @return _tempListRow 隠し明細行
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public GFQEListRow getTempListRow() {
		return _tempListRow;
	}

	/**
	 * 動的に追加可能な最大行数を取得します.
	 *
	 * @create 2023/10/25
	 * @return 動的に追加可能な最大行数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public String getMaxlistsize() {
		return _maxlistsize;
	}

	/**
	 * 隠し明細行となる{@link GFQEListRow}を評価しているかどうか判定します.
	 *
	 * @create 2023/10/25
	 * @return 隠し明細行の判定{true:隠し明細行 / false:通常明細行}
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public boolean isTempRow() {
		return _tempRow;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 以下の属性を読み込みます.<br>
	 * ・tempListRow,maxlistsize,id,labelvalue,labelid<br>
	 *
	 * @create 2023/10/25
	 * @see GPListTag#load(GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GFQEList list = (GFQEList) component;
		GFQEList repository = (GFQEList) list.getRepository();
		setTempListRow(list.getTempListRow());
		setMaxlistsize(evaluatePlaceholder(list.getMaxlistsize(), getMaxlistsize(),
			repository == null ? null : repository.getMaxlistsize(), list));
	}

	/**
	 * 隠し明細行を設定します.
	 *
	 * @create 2023/10/25
	 * @param tempListRow 隠し明細行
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTempListRow(GFQEListRow tempListRow) {
		_tempListRow = tempListRow;
	}

	/**
	 * 隠し明細行を設定します.
	 *
	 * @create 2023/10/25
	 * @param tempRow 隠し明細行
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTempRow(boolean tempRow) {
		_tempRow = tempRow;
	}

	/**
	 * 動的に追加可能な最大行数を設定します.
	 *
	 * @create 2023/10/25
	 * @param maxlistsize 動的に追加可能な最大行数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setMaxlistsize(String maxlistsize) {
		_maxlistsize = maxlistsize;
	}
}
