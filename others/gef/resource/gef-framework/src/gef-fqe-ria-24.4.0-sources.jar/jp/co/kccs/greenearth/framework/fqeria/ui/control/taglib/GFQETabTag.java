/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.fqeria.ui.control.taglib;

import java.util.List;
import java.util.Objects;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.IterationTag;
import jakarta.servlet.jsp.tagext.Tag;
import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQETab;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * タブを表示するタグクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.10.0
 */
@TargetUIComponent(GFQETab.class)
public class GFQETabTag extends GUIContainerControlBaseTag {

	/** 評価中のタブのインデックス */
	private int _currentTabindex = 0;

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = 7541445071741696154L;

	/** 表示状態のタブの数. */
	private int _displaysize;
	
	/** タブのインデックス. */
	private List<Integer>_tabIndexes;

	/** 動的に追加可能な最大タブ数. */
	private String _size;

	/** タブUIコントロールリスト. */
	private List<List<GUIControl>> _tabControls = null;

	/** 選択状態のタブのインデックス. */
	private int _tabSelected;

	/**
	 * デフォルトコンストラクタです.
	 *
	 * @create 2023/10/25
	 * @author oka
	 * @since 23.10.0
	 */
	public GFQETabTag() {
	}

	/**
	 * ボディ評価後の処理をします.<br>
	 * タブの表示領域を生成します.
	 *
	 * @create 2023/10/25
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doAfterBody()
	 * @return 終了コード
	 * @throws JspException JSP処理に失敗した場合
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public int doAfterBody() throws JspException {
		int sizeInt = Integer.parseInt(_size);
		if (_currentTabindex > -1) {
			GTagBuilder escapeTabTag = new GTagBuilder("div");
			GTagUtils.printOut(pageContext, escapeTabTag.createEndTagString());
		}
		_currentTabindex++;
		if (_currentTabindex < sizeInt) {
			GTagBuilder divAreaTag = new GTagBuilder("div");
			if (_currentTabindex < _displaysize) {
				divAreaTag.setAttribute("id", "tab-" + _currentTabindex);
			} else {
				divAreaTag.setAttribute("id", "escape_tab-" + _currentTabindex);
				divAreaTag.setAttribute("class", "hidden");
			}
			GTagUtils.printOut(pageContext, divAreaTag.createStartTagString());
			GTagBuilder divIndexAreaTag = new GTagBuilder("input");
			divIndexAreaTag.setAttribute("id", getFullId() + ".index-" + _currentTabindex);
			divIndexAreaTag.setAttribute("name", getFullId() + ".index-" + _currentTabindex);
			divIndexAreaTag.setAttribute("type", "hidden");
			if (_tabIndexes.size() == 0) {
				divIndexAreaTag.setAttribute("value", String.valueOf(_currentTabindex + 1));
			} else {
				divIndexAreaTag.setAttribute("value", _tabIndexes.get(_currentTabindex).toString());
			}
			GTagUtils.printOut(pageContext, divIndexAreaTag.createTagString());
			return IterationTag.EVAL_BODY_AGAIN;
		}
		return Tag.SKIP_BODY;
	}

	/**
	 * 終了タグの標準処理です.<br>
	 * タブの表示名や選択状態、表示数を保持するtype属性がhiddenとなるinput要素を生成します.<br>
	 * また、タブの表示領域を待避するための領域も生成します.<br>
	 *
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder divAreaTag = new GTagBuilder("div");
			GTagUtils.printOut(pageContext, divAreaTag.createEndTagString());
			GTagBuilder labelAreaTag = new GTagBuilder("div");
			labelAreaTag.setAttribute("id", "tablabel");
			labelAreaTag.setAttribute("class", "hidden");
			labelAreaTag.setInnerText(getLabel());
			GTagUtils.printOut(pageContext, labelAreaTag.createStartEndTagString(true));
			GTagBuilder displayAreaTag = new GTagBuilder("div");
			displayAreaTag.setAttribute("id", "display");
			displayAreaTag.setAttribute("class", "hidden");
			GTagBuilder selectedTag = new GTagBuilder("input");
			selectedTag.setAttribute("id", getFullId() + ".selected");
			selectedTag.setAttribute("name", getFullId() + ".selected");
			selectedTag.setAttribute("type", "hidden");
			selectedTag.setAttribute("value", String.valueOf(_tabSelected));
			GTagBuilder displaysizeTag = new GTagBuilder("input");
			displaysizeTag.setAttribute("id", getFullId() + ".displaysize");
			displaysizeTag.setAttribute("name", getFullId() + ".displaysize");
			displaysizeTag.setAttribute("type", "hidden");
			displaysizeTag.setAttribute("value", String.valueOf(_displaysize));
			displayAreaTag.setInnerText(selectedTag.createTagString() + displaysizeTag.createTagString());
			GTagUtils.printOut(pageContext, displayAreaTag.createStartEndTagString(false));
			GTagBuilder escapeAreaTag = new GTagBuilder("div");
			escapeAreaTag.setAttribute("id", "escape");
			escapeAreaTag.setAttribute("class", "hidden");
			GTagUtils.printOut(pageContext, escapeAreaTag.createStartEndTagString(false));
		}
		reset();
		return Tag.EVAL_PAGE;
	}

	/**
	 * 開始タグの標準処理です.<br>
	 * XHTML文字列を出力します.
	 *
	 * @create 2023/10/25
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 *         /
	 *         {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を処理します。
	 * @throws JspException {@link GFQETab}の取得・ロード、タグの書き込みに失敗した場合
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
			return Tag.EVAL_BODY_INCLUDE;
		}
		return Tag.SKIP_BODY;
	}

	/**
	 * XHTML文字列を生成します.<br>
	 * タブを選択する項目を生成します.
	 *
	 * @create 2023/10/25
	 * @return XHTML文字列
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		StringBuilder xhtml = new StringBuilder();
		int sizeInt = Integer.parseInt(_size);
		if (_currentTabindex == 0) {
			GTagBuilder scriptTag = new GTagBuilder("script");
			scriptTag.setAttribute("type", "text/javascript");
			scriptTag.setInnerText("$(function(){" + "$.gfqetabhandler.init('" + getFullId() + "');" + "});");
			xhtml.append(scriptTag.createStartEndTagString(false));
			GTagBuilder tabTag = new GTagBuilder("div");
			tabTag.setAttribute("id", getFullId());
			xhtml.append(tabTag.createStartTagString());
			GTagBuilder ul = new GTagBuilder("ul");
			StringBuilder list = new StringBuilder();
			for (int i = 0; i < _displaysize; i++) {
				GTagBuilder li = new GTagBuilder("li");
				GTagBuilder anchor = new GTagBuilder("a");
				anchor.setAttribute("href", "#tab-" + i);
				GTagBuilder span = new GTagBuilder("span");
				if (_tabIndexes.size() == 0) {
					span.setInnerText(getLabel() + (i + 1));
				} else {
					span.setInnerText(getLabel() + _tabIndexes.get(i));
				}				
				anchor.setInnerText(span.createStartEndTagString(true));
				li.setInnerText(anchor.createStartEndTagString(false));
				list.append(li.createStartEndTagString(false));
			}
			ul.setInnerText(list.toString());
			xhtml.append(ul.createStartEndTagString(false) + "\n");
			if (_currentTabindex != sizeInt) {
				GTagBuilder div = new GTagBuilder("div");
				div.setAttribute("id", "tab-" + _currentTabindex);
				xhtml.append(div.createStartTagString());
				GTagBuilder divIndexAreaTag = new GTagBuilder("input");
				divIndexAreaTag.setAttribute("id", getFullId() + ".index-" + _currentTabindex);
				divIndexAreaTag.setAttribute("name", getFullId() + ".index-" + _currentTabindex);
				divIndexAreaTag.setAttribute("type", "hidden");
				if (_tabIndexes.size() == 0) {
					divIndexAreaTag.setAttribute("value", String.valueOf(_currentTabindex + 1));
				} else {
					divIndexAreaTag.setAttribute("value", _tabIndexes.get(_currentTabindex).toString());
				}
				xhtml.append(divIndexAreaTag.createTagString());
			}
		}
		return xhtml.toString();
	}

	/**
	 * 表示状態のタブの数を取得します.
	 *
	 * @create 2023/10/25
	 * @return 表示状態のタブの数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public int getDisplaysize() {
		return _displaysize;
	}

	/**
	 * タブUIコントロールのリストから指定された名前の{@link GUIControl}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @see GUIContainerControlBaseTag#getControl(java.lang.String)
	 * @param id コントロールのID
	 * @return {@link GUIControl}オブジェクト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public GUIControl getControl(String id) {
		if (Objects.nonNull(_tabControls)) {
			List<GUIControl> controls = _tabControls.get(_currentTabindex);
			GUIControl control = null;
			for (GUIControl tempcontrol : controls) {
				if (tempcontrol != null && tempcontrol.getId() != null
					&& tempcontrol.getId().equals(id + _currentTabindex)) {
					control = tempcontrol;
					break;
				}
			}
			return control;
		}
		return super.getControl(id);
	}

	/**
	 * 評価中のタブのインデックスを取得します.
	 *
	 * @create 2023/10/25
	 * @return 評価中のタブのインデックス
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public int getCurrentTabindex() {
		return _currentTabindex;
	}

	/**
	 * 動的に追加可能な最大タブ数を取得します.
	 *
	 * @create 2023/10/25
	 * @return 動的に追加可能な最大タブ数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * タブUIコントロールリストを取得します.
	 *
	 * @create 2023/10/25
	 * @return タブUIコントロールリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public List<List<GUIControl>> getTabControls() {
		return _tabControls;
	}
	
	/**
	 * 表示されているタブのインデックスを取得します.
	 *
	 * @create 2023/10/25
	 * @return タブのインデックスリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public List<Integer> getTabIndexes() {
		return _tabIndexes;
	}

	/**
	 * 選択状態のタブのインデックスを取得します.
	 *
	 * @create 2023/10/25
	 * @return 選択状態のタブのインデックス
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public int getTabSelected() {
		return _tabSelected;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 以下の属性を読み込みます.<br>
	 * ・label,size,displaysize,tabSelected,tabControls<br>
	 *
	 * @create 2023/10/25
	 * @see GUIContainerControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GFQETab tab = (GFQETab) component;
		GFQETab repository = (GFQETab) tab.getRepository();
		setSize(evaluatePlaceholder(tab.getSize(), getSize(), repository == null ? null : repository.getSize(), tab));
		setTabSelected(tab.getTabSelected());
		setDisplaysize(tab.getDisplaysize());
		setTabControls(tab.getTabControls());
		setTabIndexes(tab.getTabIndexes());
	}

	/**
	 * タグの状態をリセット(初期化)します.
	 *
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#reset()
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	@Override
	public void reset() {
		super.reset();
		_currentTabindex = 0;
		_tabControls = null;
	}

	/**
	 * 評価中のタブのインデックスを設定します.
	 *
	 * @create 2023/10/25
	 * @param currentTabindex 評価中のタブのインデックス
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setCurrentTabindex(int currentTabindex) {
		_currentTabindex = currentTabindex;
	}

	/**
	 * 表示状態のタブの数を設定します.
	 *
	 * @create 2023/10/25
	 * @param displaysize 表示状態のタブの数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setDisplaysize(int displaysize) {
		_displaysize = displaysize;
	}

	/**
	 * 動的に追加可能な最大タブ数を設定します.
	 *
	 * @create 2023/10/25
	 * @param size 動的に追加可能な最大タブ数
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * タブUIコントロールリストを設定します.
	 *
	 * @create 2023/10/25
	 * @param tabControls タブUIコントロールリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTabControls(List<List<GUIControl>> tabControls) {
		_tabControls = tabControls;
	}

	/**
	 * 表示されているタブのインデックスを設定します.
	 *
	 * @create 2023/10/25
	 * @param tabIndexes タブのインデックスリスト
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTabIndexes(List<Integer> tabIndexes) {
		_tabIndexes = tabIndexes;
	}
	
	/**
	 * 選択状態のタブのインデックスを設定します.
	 *
	 * @create 2023/10/25
	 * @param tabSelected 選択状態のタブのインデックス
	 * @author KCCS oka
	 * @since 23.10.0
	 */
	public void setTabSelected(int tabSelected) {
		_tabSelected = tabSelected;
	}
}
