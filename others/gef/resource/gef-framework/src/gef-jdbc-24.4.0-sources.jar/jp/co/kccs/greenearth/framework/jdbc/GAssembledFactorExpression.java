/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

/**
 * {@link GExpressionFactor}の集合を組み立てて生成される式を表すクラスです.
 * 
 * @author KCCS T.Kitamura
 * @create 2013/06/20
 * @since 3.12.0
 */
public class GAssembledFactorExpression extends GReplaceExpression implements Cloneable {
	
	/** 条件式のルート要素 */
	private GExpressionFactor rootFactor = null;
	
	/**
	 * {@link GAssembledFactorExpression}を初期化します.
	 * 
	 * @author KCCS T.Kitamura
	 * @create 2013/06/21
	 * @since 3.12.0
	 */
	public GAssembledFactorExpression() {
	}
	
	/**
	 * 条件式のルート要素を取得します.
	 * 
	 * @return 条件式のルート要素
	 * @author KCCS T.Kitamura
	 * @create 2013/06/21
	 * @since 3.12.0
	 */
	public GExpressionFactor getRootFactor() {
		return rootFactor;
	}
	
	/**
	 * 条件式のルート要素を設定します.
	 * 
	 * @param rootFactor 条件式のルート要素
	 * @author KCCS T.Kitamura
	 * @create 2013/06/21
	 * @since 3.12.0
	 */
	public void setRootFactor(GExpressionFactor rootFactor) {
		this.rootFactor = rootFactor;
	}

	/**
	 * このインスタンスの状態を基に、常用インスタンス（クローン）を生成します.<br>
	 * 
	 * @return 常用インスタンス
	 * @author KCCS N.Nishimura
	 * @create 2014/01/17
	 * @since 3.13.0
	 * @throws CloneNotSupportedException 常用インスタンスの生成に失敗した場合
	 */
	@Override
	public GAssembledFactorExpression clone() throws CloneNotSupportedException {
		return (GAssembledFactorExpression) super.clone();
	}
}
