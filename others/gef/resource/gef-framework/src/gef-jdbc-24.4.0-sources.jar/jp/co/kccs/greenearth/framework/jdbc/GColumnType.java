/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.util.HashMap;
import java.util.Map;

/**
 * カラムのタイプを表すクラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/09
 * @since 3.12.0
 */
public class GColumnType {
	/** タイプの定数（VARCHAR） */
	public static final GColumnType VARCHAR = new GColumnType("VARCHAR");
	/** タイプの定数（CHAR） */
	public static final GColumnType CHAR = new GColumnType("CHAR");
	/** タイプの定数（LONGVARCHAR） */
	public static final GColumnType LONGVARCHAR = new GColumnType("LONGVARCHAR");
	/** タイプの定数（BOOLEAN） */
	public static final GColumnType BOOLEAN = new GColumnType("BOOLEAN");
	/** タイプの定数（NUMERIC） */
	public static final GColumnType NUMERIC = new GColumnType("NUMERIC");
	/** タイプの定数（BYTE） */
	public static final GColumnType BYTE = new GColumnType("BYTE");
	/** タイプの定数（SHORT） */
	public static final GColumnType SHORT = new GColumnType("SHORT");
	/** タイプの定数（INTEGER） */
	public static final GColumnType INTEGER = new GColumnType("INTEGER");
	/** タイプの定数（LONG） */
	public static final GColumnType LONG = new GColumnType("LONG");
	/** タイプの定数（FLOAT） */
	public static final GColumnType FLOAT = new GColumnType("FLOAT");
	/** タイプの定数（DOUBLE） */
	public static final GColumnType DOUBLE = new GColumnType("DOUBLE");
	/** タイプの定数（DATE） */
	public static final GColumnType DATE = new GColumnType("DATE");
	/** タイプの定数（TIMESTAMP） */
	public static final GColumnType TIMESTAMP = new GColumnType("TIMESTAMP");
	/** タイプの定数（BLOB） */
	public static final GColumnType BLOB = new GColumnType("BLOB");
	/** タイプの定数（CLOB） */
	public static final GColumnType CLOB = new GColumnType("CLOB");
	/** タイプの定数（BINARY） */
	public static final GColumnType BINARY = new GColumnType("BINARY");
	/** タイプの定数（TEXT） */
	public static final GColumnType TEXT = new GColumnType("TEXT");
	/** タイプの定数（RESULTSET） */
	public static final GColumnType RESULTSET = new GColumnType("RESULTSET");
	/** タイプの定数を保持するマップ */
	private static Map<String, GColumnType> typeMap = new HashMap<String, GColumnType>();
	/** タイプ名 */
	private String name;

	static {
		typeMap.put(VARCHAR.name, VARCHAR);
		typeMap.put(CHAR.name, CHAR);
		typeMap.put(LONGVARCHAR.name, LONGVARCHAR);
		typeMap.put(BOOLEAN.name, BOOLEAN);
		typeMap.put(NUMERIC.name, NUMERIC);
		typeMap.put(BYTE.name, BYTE);
		typeMap.put(SHORT.name, SHORT);
		typeMap.put(INTEGER.name, INTEGER);
		typeMap.put(LONG.name, LONG);
		typeMap.put(FLOAT.name, FLOAT);
		typeMap.put(DOUBLE.name, DOUBLE);
		typeMap.put(DATE.name, DATE);
		typeMap.put(TIMESTAMP.name, TIMESTAMP);
		typeMap.put(BLOB.name, BLOB);
		typeMap.put(CLOB.name, CLOB);
		typeMap.put(BINARY.name, BINARY);
		typeMap.put(TEXT.name, TEXT);
		typeMap.put(RESULTSET.name, RESULTSET);
	}

	/**
	 * カラムのタイプ名を指定して{@link GColumnType}を生成します.
	 * 
	 * @param name タイプ名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	protected GColumnType(String name) {
		this.name = name;
	}

	/**
	 * カラムのタイプを取得します.
	 * 
	 * @param name タイプ名
	 * @return タイプの列挙型
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public static GColumnType valueOf(String name) {
		if (typeMap.containsKey(name)) {
			return typeMap.get(name);
		} else {
			throw new IllegalArgumentException("This type is not existing. : " + name);
		}

	}
}
