/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

/**
 * 条件式を変換する際の例外を表すクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GConvertExpressionException extends RuntimeException {

    /** シリアルバージョンUID */
	private static final long serialVersionUID = -8347901274839258766L;

    /**
     * {@link GConvertExpressionException}を初期化します.
     * 
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GConvertExpressionException() {
		super();
	}

    /**
     * メッセージを指定して{@link GConvertExpressionException}を初期化します.
     * 
     * @param message メッセージ
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GConvertExpressionException(String message) {
		super(message);
	}
	
    /**
     * 原因を指定して{@link GConvertExpressionException}を初期化します.
     * 
     * @param cause 原因
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GConvertExpressionException(Throwable cause) {
		super(cause);
	}

    /**
     * メッセージと原因を指定して{@link GConvertExpressionException}を初期化します.
     * 
     * @param message メッセージ
     * @param cause 原因
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GConvertExpressionException(String message, Throwable cause) {
		super(message, cause);
	}
}
