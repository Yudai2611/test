/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;


/**
 * データベース接続情報を管理するためのインタフェースです。
 * <p>
 * 使用するRDBMSの種類、スキーマ、データソース名などのデータベース接続情報を一元管理するためのインタフェースです。
 * 各種データベース接続情報を参照したり、設定したりする機能を提供します。
 * <p>
 * このインタフェースのデフォルト実装はDIコンテナから取得することを想定しており、<br>
 * 各データベース接続情報はDI定義ファイル（ge-container-spring.xmlなど）からインジェクトされます。<br>
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GDatabase {

	/**
	 * データベース接続情報の管理名を取得します。
	 * <p>
	 * 初期情報として、DI定義ファイルのプロパティ名"name"で定義された値を保持しています。
	 *
	 * @return データベース接続情報の管理名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	// FIXME データベース名は、DI定義のid(name)属性値を使用しているようです。このデータベース名は必要ですか? 
	String getName();

	/**
	 * データベース接続情報の管理名を設定します。
	 *
	 * @param name データベース名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	// FIXME データベース名は、DI定義のid(name)属性値を使用しているようです。このデータベース名は必要ですか? 
	void setName(String name);

	/**
	 * データソース名を取得します。
	 * <p>
	 * データソースとはJDBCドライバー、接続先URL、ユーザーＩＤ、パスワードを意味し、<br>
	 * データソース名はこれらを管理するための名前です。<br>
	 * データソース名でge-dbconnect.xmlを参照しデータソースを取得します。<br>
	 * 初期情報として、DI定義ファイルのプロパティ名"dataSource"で定義された値を保持しています。
	 *
	 * @return データソース名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	String getDataSource();

	/**
	 * データソース名を設定します。
	 *
	 * @param dataSource データソース名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setDataSource(String dataSource);


	/**
	 * スキーマ名を取得します。
	 * <p>
	 * 初期情報として、DI定義ファイルのプロパティ名"schema"で定義された値を保持しています。
	 *
	 * @return スキーマ名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	String getSchema();

	/**
	 * スキーマ名を設定します。
	 *
	 * @param schema スキーマ名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setSchema(String schema);

	/**
	 * データベースの種類を取得します。
	 * <p>
	 * 初期情報として、DI定義ファイルのプロパティ名"dbType"で定義された値を保持しています。
	 *
	 * @return データベースの種類
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	String getDbType();

	/**
	 * データベースの種類を設定します。
	 * 
	 * @param dbType データベースの種類
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setDbType(String dbType);

}
