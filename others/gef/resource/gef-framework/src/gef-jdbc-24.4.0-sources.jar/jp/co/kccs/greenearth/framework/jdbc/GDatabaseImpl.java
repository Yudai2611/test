/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

/**
 * {@link GDatabase}インターフェースの実装クラスです.
 *
 * @author KCCS K.Fujita
 * @create 2012/10/11
 * @since 3.12.0
 */
public class GDatabaseImpl implements GDatabase {
	
	/** データベース名 */
	private String name = null;
	/** データソース */
	private String dataSource = null;
	/** スキーマ名 */
	private String schema = null;
	/** データベースタイプ */
	private String dbType = null;

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getDataSource() {
		return dataSource;
	}

	@Override
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public String getSchema() {
		return schema;
	}

	@Override
	public void setSchema(String schema) {
		this.schema = schema;
	}

	@Override
	public String getDbType() {
		return dbType;
	}

	@Override
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

}
