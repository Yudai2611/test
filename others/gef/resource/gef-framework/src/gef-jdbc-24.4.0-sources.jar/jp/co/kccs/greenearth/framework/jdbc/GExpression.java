/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

/**
 * 変換式を表すインタフェースです。
 * <p>
 * このインタフェースは変換式のルールを提供し、また変換式そのものを表します。
 * 変換式とは、記号等を使いながらルールに則って記述された文字列（SQL文の一部）です。<br>
 * ルールに則って変換式を記述することで、SQL文を構築する際に実行可能なSQL文へ変換します。
 * このことにより、柔軟なSQL文を構築することが可能になります。
 * <p>
 * 動的に変わる可能性のある値やサブクエリーを変換式でバインドすることができます。<br>
 * また、RDBMS製品に依存してしまう関数も変換式を使用することにより製品間の差異を吸収することができます。<br>
 * 基本的に{@link GQueryAssistants#exp(String, java.lang.Object...)}や{@link GQueryAssistants#expMap(String, java.util.List, java.util.Map)}など（オーバーロードメソッド）でインスタンスを生成します。
 * <p>
 * <b>以下ルールで変換式を記述してください</b>
 * <p>
 * <ul>
 * <li>値をバインドする<br>
 * SQL文中にバインド先を指定しておくことにより、その位置に対応する値をバインドします。<br>
 * バインドする値は{@link java.lang.Object}の可変長引数、または{@link java.lang.Object}のマップで指定します。<br>
 * 可変長引数の場合はバインド先を「?」で指定します。バインド先の登場順に可変長引数の順番が対応します。<br>
 * マップの場合はバインド先を「:マップのキー名」で指定します。<br>
 * <br>
 * <table border="1">
 * <tr bgcolor="cccccc"><td>&nbsp</td><td>使用例</td><td>変換後</td></tr>
 * <tr><td rowspan=3>可変長引数でバインドする</td><td>exp("column = ?", "15")</td><td>column = '15'</td></tr>
 * <tr><td>exp("column1 = ? AND column2 = ?", "15", "20")</td><td>column1 = '15' AND column2 = '20'</td></tr>
 * <tr><td>exp("column IN (?, ?)", "15", "20")</td><td>column IN ('15', '20')</td></tr>
 * <tr><td rowspan=2>マップでバインドする</td><td>exp("column1 = :key1 AND column2 = :key2", "15", "20")</td><td>column1 = '15' AND column2 = '20'</td></tr>
 * <tr><td>exp("column IN (:key1, :key2)", map)</td><td>column IN ('15', '20')'</td></tr>
 * </table>
 * <br>
 * <li>カラム名の論理名を使用する<br>
 * カラムの論理名を使ってSQL文を記述したい場合は「#」を付与します。<br>
 * カラムの論理名とは、エンティティー定義ファイルで定義している名前です。<br>
 * 論理名を使うことにより、物理名が変更された場合でもコードを書き換える必要がなくなります。<br>
 * <br>
 * <table border="1">
 * <tr bgcolor="cccccc"><td>使用例</td><td>変換後</td></tr>
 * <tr><td>exp("#logicalColumn = '15'")</td><td>physicalColumn = '15'</td></tr>
 * <tr><td>exp("#logicalColumn = '15' AND columnB IS NULL")</td><td>physicalColumn = '15' AND columnB IS NULL</td></tr>
 * </table>
 * <br>
 * </li>
 * <li>関数を使用する<br>
 * 関数はRDBMS製品によって書き方が異なります。<br>
 * SQL文に直接関数を記述することも可能ですが、変換式を使うことによりRDBMS製品を意識する必要がなくなります。<br>
 * $を付与した関数名使用します。<br>
 * <br>
 * <table border="1">
 * <tr bgcolor="cccccc"><td>使用例</td><td>変換後</td></tr>
 * <tr><td>exp("date = $CURRENT_DATE")</td>
 * <td>date = CURRENT DATE</td></tr>
 * <tr><td>exp("$RTRIM(ItemName)")</td>
 * <td>RTRIM(ItemName)</td></tr>
 * </table>
 * <br>
 * 以下の関数名が使用できます。これ以外の関数はSQL文にそのまま記述してください。<br>
 * <br>
 * <table border="1">
 * <tr bgcolor="cccccc"><td>関数名</td><td>用途</td></tr>
 * <tr><td>ABS</td><td>絶対値 (正値) を返す</td></tr>
 * <tr><td>UPPER</td><td>大文字に変換する</td></tr>
 * <tr><td>LOWER</td><td>小文字に変換する</td></tr>
 * <tr><td>TRIM</td><td>左右の空白文字を削除する</td></tr>
 * <tr><td>RTRIM</td><td>右の空白文字を削除する</td></tr>
 * <tr><td>LTRIM</td><td>左の空白文字を削除する</td></tr>
 * <tr><td>LENGTH</td><td>文字列の長さを求める</td></tr>
 * <tr><td>REPLACE</td><td>文字列を単語の単位で置換する</td></tr>
 * <tr><td>CONCAT</td><td><文字列を連結する/td></tr>
 * <tr><td>SUBSTR</td><td>部分文字列を取り出す</td></tr>
 * <tr><td>LOCATE</td><td>文字列内のある文字列の位置を返す</td></tr>
 * <tr><td>SQRT</td><td>平方根を求める</td></tr>
 * <tr><td>MOD</td><td>余りを求める</td></tr>
 * <tr><td>FLOOR</td><td>床関数</td></tr>
 * <tr><td>CURRENT_DATE</td><td>現在日付と時刻（年～秒）を戻す</td></tr>
 * <tr><td>CURRENT_TIMESTAMP</td><td>秒の小数部と「タイムゾーンを含む」日付と時間を戻す</td></tr>
 * <tr><td>NULLIF</td><td>NOT NULL or NULL で置換する</td></tr>
 * <tr><td>COALESCE</td><td>NULLでない最初の引数を返す</td></tr>
 * <tr><td>COUNT</td><td>レコードの件数を求める</td></tr>
 * <tr><td>AVG</td><td>平均値を求める</td></tr>
 * <tr><td>MAX</td><td>最大値を求める</td></tr>
 * <tr><td>MIN</td><td>最少値を求める</td></tr>
 * <tr><td>SUM</td><td>総計を求める</td></tr>
 * </table>
 * </li>
 * <br>
 * <li>サブクエリを使用する<br>
 * サブクエリを別途用意しておき、メインクエリにバインドすることができます。<br>
 * SQL文のバインド先を「:{QUERY}」で指定しておきます。<br>
 * <br>
 * <table border="1">
 * <tr bgcolor="cccccc"><td>使用例</td><td>変換後</td></tr>
 * <tr><td>GEntitySelect select = select("entity").fields("columnA").where("company = '15');<br>
 * exp("column IN :{QUERY}", querys(select));</td>
 * <td>column IN (SELECT columnA WHERE company = '15')</td></tr>
 * </table>
 * <br>
 * </li>
 * </ul>
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public interface GExpression {
}
