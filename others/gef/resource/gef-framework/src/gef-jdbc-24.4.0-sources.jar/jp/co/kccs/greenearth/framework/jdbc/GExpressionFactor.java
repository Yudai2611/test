/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.util.ArrayList;
import java.util.List;


/**
 * WHERE節構築時にnull値を考慮して検索条件を構築するクラスです。
 * <p>
 * WHERE節の検索条件を構築する際にバインドする値がnullであるかを判定し、その結果によって検索条件を構築する機能を提供します。<br>
 * このことにより、バインドする値がnullかどうかを事前に判定を行うことなく検索条件構築することができます。<br>
 * {@link GQueryAssistants#exp(GExpressionFactor, Object...)}や{@link GQueryAssistants#expMap(GExpressionFactor, java.util.Map)}と
 * 組み合わせて使用することを前提としています。
 * <p>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>バインドする値がnullの場合に検索条件を除外する</li>
 * <li>バインドする値がnullの場合に比較演算子をIS NULL（またはIS NOT NULL）に変換する</li>
 * </ol>
 * <p>
 * <b>検索条件の構築は以下のルールに従って行われます。</b><br>
 * <p>
 * 値をバインドする先は「?」または「:keyOfMap」で表します。<br>
 * 詳しくは{@link GExpression}を参照してください。<br>
 * 以降は「?」として説明します。
 * <p>
 * <ol>
 * <li>検索条件にバインドする値が<b>nullの場合</b><br>
 * 検索条件のバインド先が角括弧[]で囲まれているかどうかで変換ルールが異なります。<br>
 * <table border="1">
 * <tr bgcolor="cccccc"><td>&nbsp</td><td>変換前</td><td>変換後</td></tr>
 * <tr><td rowspan="3">角括弧なし</td><td>exp($("ItemCD = ?"), null)</td><td>ItemCD IS NULL</td></tr>
 * <tr><td>exp($("ItemCD <> ?"), null)</td><td>ItemCD IS NOT NULL</td></tr>
 * <tr><td>exp($("ItemCD LIKE ?"), null)</td><td>ItemCD LIKE null<br><b>nullに置換されるだけです。使用しないでください。</b></td></tr>
 * <tr><td rowspan="3">角括弧あり</td><td>exp($("ItemCD = [?]"), null)</td><td>検索条件からこの条件が除外されます</td></tr>
 * <tr><td>exp($("ItemCD <> [?]"), null)</td><td>検索条件からこの条件が除外されます</td></tr>
 * <tr><td>exp($("ItemCD LIKE [?]"), null)</td><td>検索条件からこの条件が除外されます</td></tr>
 * </table>
 * <br>
 * <li>検索条件にバインドする値が<b>nullでない場合</b><br>
 * 条件式は変換されません。<br>
 * <table border="1">
 * <tr bgcolor="cccccc"><td>&nbsp</td><td>変換前</td><td>変換後</td></tr>
 * <tr><td rowspan="1">角括弧なし</td><td>exp($("ItemCD = ?"), "value")</td><td>ItemCD = 'value'</td></tr>
 * <tr><td rowspan="1">角括弧あり</td><td>exp($("ItemCD = [?]"), "value")</td><td>ItemCD = 'value'</td></tr>
 * </table>
 * <br>
 * <li>検索条件内に複数のバインド先がある場合、一番最初のバインド先だけが判断の対象になります。<br>
 * 次のように"ItemNA"のバインド値がnullであれば、"UnitPrice"にバインドする値に関わらずこの検索条件は除外されます。<br>
 * <pre>$("ItemNA = [?] OR UnitPrice > [?]")</pre>
 * </ol>
 * <p>
 * <b>複数の検索条件をつなげる方法</b><br>
 * <p>
 * {@link #AND(String)}や{@link #OR(String)}などを使用することにより、複数の条件式をつなげることができます。<br>
 * 次ののような検索条件を考えてみます。<br>
 * <pre>
 * where(
 *    expMap(
 *       $("ItemCD = :item")
 *       .OR(
 *          NOT(
 *             $("CompanyCD = :[code]")
 *             .AND("ItemNA = :[name]")
 *          )
 *       ),
 *       paramMap
 *    )
 * )
 * </pre>
 * 全てのパラメータにnull以外の値が設定されていれば、生成されるWhere節は次のようになります。<br>
 * <pre>Where ItemCD = "item" OR (NOT (CompanyCD = "code" AND ItemNA = "name"))</pre>
 * 一方、対応するパラメータが全てnull値である場合は、最初の式の演算子がIS NULLに変わり、OR演算子以下の式は検索条件から除外されるため、次のようなWhere節が生成されます。<br>
 * <pre>Where ItemCD IS NULL</pre>
 * このように、{@link GExpressionFactor}のメソッドを組み合わせることで事前にバインドする値にnull判定を行うことなく検索条件構築することができます。<br>
 * <br>
 * @author KCCS K.Fujita
 * @create 2013/04/23
 * @since 3.12.0
 */
public class GExpressionFactor {
	
	/** 子階層の{@link GExpressionFactor} */
	private GExpressionFactor child = null;
	/** 兄弟階層の{@link GExpressionFactor}のリスト */
	private List<GExpressionFactor> siblings = new ArrayList<GExpressionFactor>();
	
	/** 条件式の文字列 */
	private String condition = null;
	/** 論理演算子の種類 */
	private Operator operator = null;
	
	/**
	 * 論理演算子を表す列挙型です。
	 * <ul>
	 * <li>{@link #AND} </li>
	 * <li>{@link #OR} </li>
	 * <li>{@link #NOT} </li>
	 * <li>{@link #$} </li>
	 * </ul> 
	 * <br>
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public enum Operator {
		/** 論理積（AND）を表します */
		AND(" AND "), 
		/** 論理和（OR）を表します */
		OR(" OR "), 
		/** 論理否定（NOT）を表します */
		NOT("NOT "), 
		/** 丸括弧を表します */
		$("");
		
		/** 論理演算子が表しているSQL */
		private String sql = null;
		
		/**
		 * 表現するオペレーター文字列を定義し、初期化します。
		 * 
		 * @param sql オペレーター文字列
		 * @author KCCS K.Fujita
		 * @create 2013/04/23
		 * @since 3.12.0
		 */
		Operator(String sql) {
			this.sql = sql;
		}
		
		/**
		 * この論理演算子が表しているオペレーター文字列を取得します。
		 * 
		 * @return オペレーター文字列
		 * @author KCCS K.Fujita
		 * @create 2013/04/23
		 * @since 3.12.0
		 */
		public String toOperatorString() {
			return sql;
		}
	}
	
	/////////////////////////
	/*   コンストラクタ   */
	/////////////////////////
	
	/**
	 * 条件式のみを指定し{@link GExpressionFactor}を初期化します。
	 * 
	 * @param condition 条件式
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor(String condition) {
		this.condition = condition;
		this.operator = Operator.$;
	}
	
	/**
	 * 条件式と論理演算子を指定し{@link GExpressionFactor}を初期化します。
	 * 
	 * @param condition 条件式
	 * @param operator 論理演算子
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor(String condition, Operator operator) {
		this.condition = condition;
		this.operator = operator;
	}
	
	/**
	 * 丸括弧で囲まれる条件式（{@link GExpressionFactor}）を指定し、{@link GExpressionFactor}を初期化します。
	 * 
	 * @param child 丸括弧で囲まれる条件式（{@link GExpressionFactor}）
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor(GExpressionFactor child) {
		this.child = child;
		this.operator = Operator.$;
	}
	
	/**
	 * 条件式（{@link GExpressionFactor}）とそれを囲む論理演算子を指定し、{@link GExpressionFactor}を初期化します。
	 * 
	 * @param child 条件式（{@link GExpressionFactor}）
	 * @param operator 条件式を囲む論理演算子
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor(GExpressionFactor child, Operator operator) {
		this.child = child;
		this.operator = operator;
	}
	
	////////////////////////////////////////
	/*    並列に接続される条件式の追加    */
	////////////////////////////////////////
	
	/**
	 * 論理演算子ANDを使用して1つの検索条件を接続します。
	 * <p>
	 * 次のように検索条件を接続します。<br>
	 * <pre>$("ItemCode = ?").<b>AND</b>("Unit = ?")</pre>
	 * {@link GExpressionFactor}を返却するため、さらに検索条件をつなげて記述することができます。
	 * <p>
	 * @param condition 検索条件
	 * <p>
	 * 1検索条件のみ渡すことができます。
	 * <pre>"Unit = ?"</pre>
	 * @return 検索条件が接続された{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor AND(String condition) {
		this.siblings.add(new GExpressionFactor(condition, Operator.AND));
		return this;
	}
	
	/**
	 * 論理演算子ANDを使用して複数の検索条件を接続します。
	 * <p>
	 * 次のように検索条件を接続します。<br>
	 * <p>$("ItemCode = ?").<b>AND</b>($("Unit = ?").OR($("Code = ?")))</pre>
	 * {@link GExpressionFactor}を返却するため、さらに検索条件をつなげて記述することができます。
	 * <p>
	 * @param condition 複数の検索条件
	 * <p>
	 * 下記のように{@link #$(String)}などで生成します。
	 * <pre>$("Unit = ?").OR("Code = ?")</pre>
	 * @return 検索条件が接続された{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor AND(GExpressionFactor condition) {
		this.siblings.add(new GExpressionFactor(condition, Operator.AND));
		return this;
	}
	
	/**
	 * 論理演算子ORを使用して1つの検索条件を接続します。
	 * <p>
	 * 次のように検索条件を接続します。<br>
	 * <pre>$("ItemCode = ?").<b>OR</b>("Unit = ?")</pre>
	 * {@link GExpressionFactor}を返却するため、さらに検索条件をつなげて記述することができます。
	 * <p>
	 * @param condition 検索条件
	 * <p>
	 * 1検索条件のみ渡すことができます。
	 * <pre>"Unit = ?"</pre>
	 * @return 検索条件が接続された{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor OR(String condition) {
		this.siblings.add(new GExpressionFactor(condition, Operator.OR));
		return this;
	}
	
	/**
	 * 論理演算子ORを使用して複数の検索条件を接続します。
	 * <p>
	 * 次のように検索条件を接続します。<br>
	 * <p>$("ItemCode = ?").<b>OR</b>($("Unit = ?").AND($("Code = ?")))</pre>
	 * {@link GExpressionFactor}を返却するため、さらに検索条件をつなげて記述することができます。
	 * <p>
	 * @param condition 複数の検索条件
	 * <p>
	 * 下記のように{@link #$(String)}などで生成します。
	 * <pre>$("Unit = ?").AND("Code = ?")</pre>
	 * @return 検索条件が接続された{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public GExpressionFactor OR(GExpressionFactor condition) {
		this.siblings.add(new GExpressionFactor(condition, Operator.OR));
		return this;
	}
	
	/////////////////////////////
	/*    アクセサメソッド    */
	/////////////////////////////
	
	/**
	 * 子階層の{@link GExpressionFactor}を取得します。
	 * 
	 * @return 子階層の{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public GExpressionFactor getChild() {
		return child;
	}

	/**
	 * 子階層の{@link GExpressionFactor}を設定します。
	 * 
	 * @param child 子階層の{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public void setChild(GExpressionFactor child) {
		this.child = child;
	}
	
	/**
	 * 兄弟階層の{@link GExpressionFactor}のリストを取得します。<br>
	 * なお、兄弟階層の情報を保持しているのはルート要素（兄弟階層の一番上の要素）のみで、それ以外の要素は兄弟階層の情報を持ちません。<br>
	 * 
	 * @return 兄弟階層の{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public List<GExpressionFactor> getSiblings() {
		return siblings;
	}

	/**
	 * 兄弟階層の{@link GExpressionFactor}のリストを設定します。
	 * 
	 * @param siblings 兄弟階層の{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public void setSiblings(List<GExpressionFactor> siblings) {
		this.siblings = siblings;
	}

	/**
	 * 条件式の文字列を取得します。
	 * 
	 * @return 条件式の文字列
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public String getCondition() {
		return condition;
	}

	/**
	 * 条件式の文字列を設定します。
	 * 
	 * @param condition 条件式の文字列
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public void setCondition(String condition) {
		this.condition = condition;
	}

	/**
	 * 論理演算子の種類を取得します。
	 * 
	 * @return 論理演算子の種類
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public Operator getOperator() {
		return operator;
	}

	/**
	 * 論理演算子の種類を設定します。
	 * 
	 * @param operator 論理演算子の種類
	 * @author KCCS K.Fujita
	 * @create 2013/06/14
	 * @since 3.12.0
	 */
	public void setOperator(Operator operator) {
		this.operator = operator;
	}
	
	/**
	 * 子階層の{@link GExpressionFactor}が設定されているか否かを取得します。
	 * 
	 * @return 子階層に{@link GExpressionFactor}が設定されていれば<code>true</code>。そうでなければ<code>false</code>。
	 * @author KCCS K.Fujita
	 * @create 2013/06/25
	 * @since 3.12.0
	 */
	public boolean hasChild() {
		return this.getChild() != null;
	}
	
}
