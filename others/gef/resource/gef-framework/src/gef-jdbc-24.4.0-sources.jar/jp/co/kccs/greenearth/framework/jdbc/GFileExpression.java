/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.io.File;


/**
 * ファイルで表される式を表すクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GFileExpression extends GReplaceExpression {

    /** ファイル */
	private File file = null;

    /**
     * {@link GFileExpression}を初期化します.
     * 
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GFileExpression() {
	}

    /**
     * ファイルを取得します.
     * 
     * @return ファイル
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public File getFile() {
		return file;
	}

    /**
     * ファイルを設定します.
     * 
     * @param file ファイル
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setFile(File file) {
		this.file = file;
	}
}
