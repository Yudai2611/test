/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

/**
 * 楽観的排他処理を利用して処理を実行する場合に発生する例外を表します.
 * 
 * @create 2012/11/16
 * @author hashimoto
 * @since 3.12.0
 */
public class GOptimisticLockException extends RuntimeException {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 8859448559152030687L;

    /** 排他チェック対象レコードが存在しない場合のエラー */
    public static final String EXCLUSIVE_CHECK_NO_DATA_EXCEPTION = "Target data didnot found.";

	/**
	 * {@link GOptimisticLockException}のインスタンスを生成します.
	 * 
	 * @create 2012/11/16
	 * @author hashimoto
	 * @since 3.12.0
	 */
	public GOptimisticLockException() {
		super(EXCLUSIVE_CHECK_NO_DATA_EXCEPTION);
	}

	/**
	 * エラーメッセージを設定し、{@link GOptimisticLockException}のインスタンスを生成します.
	 * 
	 * @param message エラーメッセージ
	 * @create 2012/11/16
	 * @author hashimoto
	 * @since 3.12.0
	 */
	public GOptimisticLockException(String message) {
		super(message);
	}
	
	/**
	 * エラー原因を設定し、{@link GOptimisticLockException}のインスタンスを生成します.
	 * 
	 * @param cause エラー原因
	 * @create 2012/11/16
	 * @author hashimoto
	 * @since 3.12.0
	 */
	public GOptimisticLockException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * エラーメッセージとエラー原因を設定し、{@link GOptimisticLockException}のインスタンスを生成します.
	 * 
	 * @param message エラーメッセージ
	 * @param cause エラー原因
	 * @create 2012/11/16
	 * @author hashimoto
	 * @since 3.12.0
	 */
	public GOptimisticLockException(String message, Throwable cause) {
		super(message, cause);
	}
}
