/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * SQLの構築および実行で共通に使用する機能を表すインタフェースです。
 * <p>
 * SQLを構築して実行する場合、SQLをそのまま実行する場合に関わらず、
 * 全てのクエリーに対して使用できるメソッドを提供するインタフェースです。
 * <p>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>管理IDを付与する</li>
 * <li>タイムアウト時間を設定する</li>
 * <li>検索、更新系のクエリーを実行する。</li>
 * </ol>
 * 
 * @param <S> 各種SQL操作クラス
 * @author KCCS kitamura
 * @create 2012/11/27
 * @since 3.12.0
 */
public interface GQuery<S extends GQuery<S>> {
	
	/**
	 * 管理ＩＤをSQLコメントとしてSQL文に付与します。
	 * <p>
	 * このメソッドを通じて管理IDをSQLコメントとしてSQL文に付与することができます。<br>
	 * <p>
	 * @param managementID 管理ＩＤ
	 * <p>
	 * "1234"を指定した場合、次のようにSQL文に付与されます。<br>
	 * <pre> UPDATE table SET column = "value" /&#8727 1234 &#8727/<pre>
	 * @return 管理ＩＤを設定したこのインスタンス自身
	 * @author KCCS N.Nishimura
	 * @create 2014/02/24
	 * @since 3.13.0
	 */
	S managementID(String managementID);
	
	/**
	 * タイムアウト時間を設定します。
	 * <p>
	 * このメソッドを通じてクエリー実行時のタイムアウト時間を設定できます。<br>
	 * 
	 * @param seconds タイムアウト時間（秒）
	 * @return タイムアウト時間を設定したこのインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	S queryTimeout(int seconds);
	
	/**
	 * クエリーを実行し実行結果を{@link GQueryResult}で取得します。
	 * <p>
	 * クエリーが検索か更新（登録、削除、更新）か分からない場合に、このメソッドで実行することができます。
	 * 
	 * @return クエリ実行結果
	 * @throws SQLException クエリの実行やリソースの解放に失敗した場合
	 * @author KCCS kitamura
	 * @create 2013/04/22
	 * @since 3.12.0
	 */
	GQueryResult nativeCall() throws SQLException;
	
	/**
	 * クエリーを実行し実行結果を{@link GQueryResult}で取得します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <p>
	 * このメソッドを使用することで、クエリーが検索か更新（登録、削除、更新）を意識せずに実行することができます。
	 * 
	 * @param connection コネクション
	 * @return クエリ実行結果
	 * @throws SQLException クエリの実行やリソースの解放に失敗した場合
	 * @author KCCS kitamura
	 * @create 2013/04/22
	 * @since 3.12.0
	 */
	GQueryResult nativeCall(Connection connection) throws SQLException;
	
	/**
	 * 受け取ったSQL例外が制約違反を表すものであった場合、gef-jdbc独自の例外に変換して返します。
	 * <p>
	 * バッチ実行した場合等に例外が入れ子になっていることがあり、一意制約違反が発生していても一意制約違反例外を キャッチできない場合があります。
	 * キャッチした例外から入れ子になっている例外を取り出し、本メソッドに渡すことで例外を最適化することができます。
	 * <P>
	 * 検査制約違反⇒{@link GCheckConstraintException}<br>
	 * 非NULL制約違反⇒{@link GNotNullConstraintException}<br>
	 * 一意制約違反⇒{@link GUniqueConstraintException}<br>
	 * 外部キー制約違反⇒{@link GForeignKeyConstraintException}<br>
	 * <p>
	 * 制約違反以外を表さないSQL例外が渡された場合は、渡された例外をそのまま返します。
	 * 
	 * @param e 判別するSQL例外
	 * @return フレームワーク独自例外または引数の例外そのもの
	 * @author KCCS K.Fujita
	 * @create 2013/06/06
	 * @since 3.12.0
	 */
	SQLException generalizeException(SQLException e);
	
	/**
	 * 各種設定を初期状態に戻します。
	 * <p>
	 * このインスタンス自身の設定を初期化します。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	void clear();
	
	/**
	 * 管理ＩＤを取得します。
	 * 
	 * @return 管理ＩＤ
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	String getManagementID();
	
	/**
	 * タイムアウト時間を取得します。
	 * 
	 * @return タイムアウト時間
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	int getQueryTimeout();
	
	/**
	 * データベース接続情報を取得します。
	 * 
	 * @return データベース接続情報
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	GDatabase getDatabase();
}
