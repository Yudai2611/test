/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.io.File;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.jdbc.GExpressionFactor.Operator;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectProcedure;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectSelect;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectUpdate;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityDelete;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityInsert;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityUpdate;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn.OrderType;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumnList;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam.ParamMode;

/**
 * SQL文の構築や実行のための機能を提供するクラスです。
 * <p>
 * gef-jdbcは「流れるようなインタフェース(FluentInterface)」の手法でコードが書けるよう設計されています。<br>
 * このクラスでは「流れるようなインタフェース」でコードを書く際に最初に呼び出すメソッドを提供します。<br>
 * また、SQL文の構築や実行を行う様々な場面で共通して使用できるメソッドも提供しています。
 * 全てのメソッドは静的インポートで使用してください。
 * <p>
 * 主に以下の機能を提供します。
 * <p>
 * ・SQL文を構築する場合に使用する機能
 * <ol type="1">
 * <li>SQL文構築機能を提供する{@link GEntitySelect}、{@link GEntityUpdate}、{@link GEntityDelete}、{@link GEntityInsert}を取得する。</li>
 * <li>カラムを修飾する</li>
 * <li>ソート順を指定する</li>
 * </ol>
 * <br>
 * <table border="1">
 * <tr>
 * <td>
 * <pre>GRecord record =
 *     select("entity", "ent")
 *         .fields(
 *             col("ent.columnA", "SUMVAL", FuncType.SUM)),
 *             col(exp("#ent.columnB)"))
 *             )
 *         .orderBy(desc("columnC"))
 *         .findRecord();</pre>
 * </td>
 * <td>
 * <pre><b>SELECT</b> SUM(ent.columnA) SUMVAL,
 *       ent.physicalColumnB
 *  <b>FROM</b> physicalTable ent
 *  <b>ORDER BY </b>columnC <b>DESC</b></pre>
 * </td>
 * </tr>
 * </table>
 * <p>
 * <br>
 * ・SQL文をそのまま実行する場合に使用する機能
 * <ol type="1">
 * <li>SQL文実行機能を提供する{@link GDirectSelect}、{@link GDirectUpdate}、{@link GDirectProcedure}を取得する。</li>
 * <li>SQL文を修飾する</li>
 * </ol>
 * <br>
 * <table border="1">
 * <tr>
 * <td>
 * <pre>GRecord record = 
 *     selectSql()
 *         .sql(exp("SELECT columnA FROM physicalTable WHERE columnB = ?", "15"))
 *         .findRecord();</pre>
 * </td>
 * <td><pre><b>SELECT</b> columnA 
 * <b>FROM</b> physicalTable
 *<b>WHERE</b> columnB = '15'</pre></td>
 * </tr>
 * </table>
 * <p>
 * @author KCCS kitamura
 * @create 2012/10/29
 * @since 3.12.0
 */
public class GQueryAssistants {
	
	/**
	 * SELECT文を構築します。
	 * <p>
	 * このメソッドを通じて{@link GEntitySelect}を取得することで、SELECT文の構築を開始することができます。<br>
	 * このクラスのメソッドや{@link GEntitySelect}のメソッド等を組み合わせてSELECT文を構築します。
	 * <p>
	 * このメソッドを使用するためにはエンティティー定義ファイルが必要です。<br>
	 * {@link GEntitySelect}にはエンティティー定義ファイルから読み込んだ定義情報がロードされています。
	 * 
	 * @param entityName エンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @return {@link GEntitySelect}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GEntitySelect select(String entityName) {
		return getCore().createEntityQuery(GEntitySelect.class, entityName, null);
	}
	
	/**
	 * SELECT文を構築します。
	 * <p>
	 * エンティティーに別名を付与する場合にこのメソッドを使用します。
	 * <p>
	 * このメソッドを通じて{@link GEntitySelect}を取得することで、SELECT文をの構築を開始することができます。<br>
	 * このクラスのメソッドや{@link GEntitySelect}のメソッド等を組み合わせてSELECT文を構築します。
	 * <p>
	 * このメソッドを使用するためにはエンティティー定義ファイルが必要です。<br>
	 * {@link GEntitySelect}にはエンティティー定義ファイルから読み込んだ定義情報がロードされています。
	 * 
	 * @param entityName エンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @param entityAlias 別名
	 * @return {@link GEntitySelect}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GEntitySelect select(String entityName, String entityAlias) {
		return getCore().createEntityQuery(GEntitySelect.class, entityName, entityAlias);
	}
	
	/**
	 * UPDATE文を構築します。
	 * <p>
	 * このメソッドを通じて{@link GEntityUpdate}を取得することで、UPDATE文の構築を開始することができます。<br>
	 * このクラスのメソッドや{@link GEntityUpdate}のメソッド等を組み合わせてUPDATE文を構築します。
	 * <p>
	 * このメソッドを使用するためにはエンティティー定義ファイルが必要です。<br>
	 * {@link GEntityUpdate}にはエンティティー定義ファイルから読み込んだ定義情報がロードされています。
	 * 
	 * @param entityName エンティティー名（エンティティー定義ファイルの名前から拡張子を除いたもの）
	 * @return {@link GEntityUpdate}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GEntityUpdate update(String entityName) {
		return getCore().createEntityQuery(GEntityUpdate.class, entityName, null);
	}
	
	/**
	 * DELETE文を構築します。
	 * <p>
	 * このメソッドを通じて{@link GEntityDelete}を取得することで、DELETE文の構築を開始することができます。<br>
	 * このクラスのメソッドや{@link GEntityDelete}のメソッド等を組み合わせてDELETE文を構築します。
	 * <p>
	 * このメソッドを使用するためにはエンティティー定義ファイルが必要です。<br>
	 * {@link GEntityDelete}にはエンティティー定義ファイルから読み込んだ定義情報がロードされています。
	 * 
	 * @param entityName エンティティー名（エンティティー定義ファイルの名前から拡張子を除いたもの）
	 * @return {@link GEntityDelete}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GEntityDelete delete(String entityName) {
		return getCore().createEntityQuery(GEntityDelete.class, entityName, null);
	}
	
	/**
	 * INSERT文を構築します。
	 * <p>
	 * このメソッドを通じて{@link GEntityInsert}を取得することで、INSERT文の構築を開始することができます。<br>
	 * このクラスのメソッドや{@link GEntityInsert}のメソッド等を組み合わせてINSERT文を構築します。
	 * <br>
	 * このメソッドを使用するためにはエンティティー定義ファイルが必要です。
	 * {@link GEntityInsert}にはエンティティー定義ファイルから読み込んだ定義情報がロードされています。<br>
	 * 
	 * @param entityName エンティティー名（エンティティー定義ファイルの名前から拡張子を除いたもの）
	 * @return {@link GEntityInsert}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GEntityInsert insert(String entityName) {
		return getCore().createEntityQuery(GEntityInsert.class, entityName, null);
	}
	
	/**
	 * SELECT文を直接実行します。
	 * <p>
	 * このメソッドを通じて{@link GDirectSelect}を取得することで、SELECT文を直接実行することができます。<br>
	 * このクラスのメソッドや{@link GDirectSelect}のメソッド等を組み合わせてSELECT文を実行します。
	 * 
	 * @return {@link GDirectSelect}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GDirectSelect selectSql() {
		return getCore().createDirectQuery(GDirectSelect.class);
	}

	/**
	 * SELECT文を直接実行します。
	 * <p>
	 * 独自実装をした{@link GDirectSelect}を使って実行するためのメソッドです。
	 * <p>
	 * このメソッドを通じて{@link GDirectSelect}を取得することで、SELECT文を直接実行することができます。<br>
	 * このクラスのメソッドや{@link GDirectSelect}のメソッド等を組み合わせてSELECT文を実行します。
	 * 
	 * @param componentName この名前でDIコンテナからインスタンスを取得します
	 * @return {@link GDirectSelect}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GDirectSelect selectSql(String componentName) {
		return getCore().createDirectQuery(componentName);
	}

	/**
	 * 更新系SQL文を直接実行します。
	 * <p>
	 * 更新系SQ文LとはINSERT文、UPDATE文、DELETE文です。<br>
	 * このメソッドを通じて{@link GDirectUpdate}を取得することで、更新系SQL文を直接実行することができます。<br>
	 * このクラスのメソッドや{@link GDirectUpdate}のメソッド等を組み合わせて更新系SQL文を実行します。
	 * 
	 * @return {@link GDirectUpdate}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GDirectUpdate updateSql() {
		return (GDirectUpdate) getCore().createDirectQuery(GDirectUpdate.class);
	}

	/**
	 * 更新系SQL文を直接実行します。
	 * <p>
	 * 独自実装した{@link GDirectUpdate}を使って実行するためのメソッドです。
	 * <p>
	 * 更新系SQLとはINSERT文、UPDATE文、DELETE文です。<br>
	 * 更新系SQLをそのまま実行する場合は、最初にこのメソッドを通じて{@link GDirectUpdate}を取得します。<br>
	 * このクラスのメソッドや{@link GDirectUpdate}のメソッド等を組み合わせて更新系SQL文を実行します。
	 * 
	 * @param componentName この名前でDIコンテナからインスタンスを取得します
	 * @return {@link GDirectUpdate}
	 * @author KCCS K.Fujita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GDirectUpdate updateSql(String componentName) {
		return (GDirectUpdate) getCore().createDirectQuery(componentName);
	}

	/**
	 * ストアドプロシージャ／ファンクションを直接実行します。
	 * <p>
	 * ストアドプロシージャ／ファンクションを直接実行する場合は、最初にこのメソッドを通じて{@link GDirectProcedure}を取得します。<br>
	 * このクラスのメソッドや{@link GDirectProcedure}のメソッド等を組み合わせてストアドプロシージャ／ファンクションを実行します。
	 * 
	 * @return {@link GDirectProcedure}
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	public static GDirectProcedure procedure() {
		return (GDirectProcedure) getCore().createDirectQuery(GDirectProcedure.class);
	}

	/**
	 * ストアドプロシージャ／ファンクションを直接実行します。
	 * <p>
	 * 独自実装した{@link GDirectProcedure}を使って実行するためのメソッドです。
	 * <p>
	 * ストアドプロシージャ／ファンクションを直接実行する場合は、最初にこのメソッドを通じて{@link GDirectProcedure}を取得します。<br>
	 * このクラスのメソッドや{@link GDirectProcedure}のメソッド等を組み合わせてストアドプロシージャ／ファンクションを実行します。
	 * 
	 * @param componentName この名前でDIコンテナからインスタンスを取得します
	 * @return {@link GDirectProcedure}
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	public static GDirectProcedure procedure(String componentName) {
		return (GDirectProcedure) getCore().createDirectQuery(componentName);
	}

	/**
	 * カラムを指定します。
	 * <p>
	 * エンティティー定義ファイルで定義されたカラムの論理名でカラムを指定します。
	 * 
	 * @param columnName カラムの論理名
	 * <p>
	 * エンティティーの別名を指定したい場合は {@code "entityAlias.column"} とします。
	 * @return SELECT文構築用のカラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumn col(String columnName) {
		return getCore().createSelectColumn(columnName);
	}

	/**
	 * 別名を付けてカラムを指定します。
	 * <p>
	 * このメソッドを使用するとカラムに対して別名を付けることができます。
	 * <p>
	 * エンティティー定義ファイルで定義されたカラムの論理名でカラムを指定します。<br>
	 * 
	 * @param columnName カラムの論理名
	 * <p>
	 * エンティティーの別名を指定したい場合は {@code "entityAlias.column"} とします。
	 * @param alias 別名
	 * @return 指定されたカラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumn col(String columnName, String alias) {
		return getCore().createSelectColumn(columnName, alias, (FuncType) null);
	}

	/**
	 * 関数を付与してカラムを指定します。
	 * <p>
	 * このメソッドを使用するとカラムに対して関数を付与することができます。
	 * <p>
	 * エンティティー定義ファイルで定義されたカラムの論理名でカラムを指定します。<br>
	 * <p>
	 * 「{@code col("column", FuncType.MAX)}」とした指定した場合、「{@code MAX(column)}」に変換されます。
	 * 
	 * @param columnName カラムの論理名<br>
	 * エンティティーの別名を指定したい場合は {@code "entityAlias.column"} とします。
	 * @param funcType 関数の種類を列挙型クラス{@link FuncType}から選んだ定数を指定します。
	 * @return 指定されたカラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumn col(String columnName, FuncType funcType) {
		return getCore().createSelectColumn(columnName, null, funcType);
	}
	
	/**
	 * カラムに別名と関数を付与してカラムを指定します。
	 * <p>
	 * このメソッドを使用するとカラムに別名をつけることでき、さらに関数を付与することができます。
	 * <p>
	 * エンティティー定義ファイルで定義されたカラムの論理名でカラムを指定します。<br>
	 * <p>
	 * 「{@code col("column", "alias", FuncType.MAX)}」と指定した場合、「{@code MAX(column) alias}」に変換されます。
	 * 
	 * @param columnName カラムの論理名<br>
	 * エンティティーの別名を指定したい場合は {@code "entityAlias.column"} とします。
	 * @param alias カラム別名
	 * @param func 関数の種類を列挙型クラス{@link FuncType}から選びます
	 * @return 指定されたカラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumn col(String columnName, String alias, FuncType func) {
		return getCore().createSelectColumn(columnName, alias, func);
	}

	/**
	 * 変換式を使用してカラムを指定します。
	 * <p>
	 * カラムに関数を付与したい場合などにこのメソッドを使用します。
	 * 
	 * @param exp {@link GExpression}
	 * <p>
	 * 次のように{@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。<br>
	 * {@code exp("$SUBSTR(#UnitPrice, 2, 2)")}<br>
	 * @return 指定されたカラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumn col(GExpression exp) {
		return getCore().createSelectColumn(exp);
	}

	/**
	 * 変換式を使用してカラムを指定します。
	 * <p>
	 * このメソッドを使用するとカラムに別名をつけることできます。
	 * <p>
	 * カラムに関数を付与したい場合などにこのメソッドを使用します。
	 * 
	 * @param exp {@link GExpression}
	 * <p>
	 * 次のように{@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。<br>
	 * {@code exp("$SUBSTR(#UnitPrice, 2, 2)")}<br>
	 * @param alias 別名
	 * @return 指定されたカラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumn col(GExpression exp, String alias) {
		return getCore().createSelectColumn(exp, alias);
	}
	
	/**
	 * 指定されたエンティティーが持つカラムを取得します。
	 * 
	 * @param entityName エンティティー名
	 * @return 指定されたエンティティーが持つカラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumnList cols(String entityName) {
		return getCore().createSelectColumnList(entityName);
	}
	
	/**
	 * エンティティーと結合先エンティティーが持つ全カラムを取得します。
	 * 
	 * @return エンティティーと結合先エンティティーが持つ全カラム
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GSelectColumnList colsAll() {
		return getCore().createSelectColumnList();
	}
	
	/**
	 * OrderBy節で昇順ソートするカラムを指定します。
	 * 
	 * エンティティー定義ファイルで定義されたカラムの論理名でカラムを指定します。
	 *
	 * @param colName カラムの論理名
	 * <p>
	 * エンティティーの別名を指定したい場合は {@code "entityAlias.column"} とします。
	 * @return 指定されたカラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public static GSelectColumn asc(String colName) {
		return getCore().createSelectColumn(colName, OrderType.ASC);
	}

	/**
	 * OrderBy節で昇順ソートするカラムを変換式で指定します。
	 * <p>
	 * カラムを独自に修飾したい場合などにこのメソッドを使用します。
	 * 
	 * @param exp 変換式
	 * <p>
	 * 次のように{@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。<br>
	 * {@code exp("$SUBSTR(#UnitPrice, 2, 2)")}<br>
	 * @return 指定されたカラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public static GSelectColumn asc(GExpression exp) {
		return getCore().createSelectColumn(exp, OrderType.ASC);
	}

	/**
	 * OrderBy節で昇順ソートするカラムを{@link GSelectColumn}で指定します。
	 * 
	 * サブクエリーで指定したい場合などに使用します。
	 * 
	 * @param column {@link GSelectColumn}
	 * <p>
	 * 次のように{@link #col(GExpression)}などで生成します。<br>
	 * {@code col(exp(":{QUERY}", querys(select)))}
	 * @return 指定されたカラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public static GSelectColumn asc(GSelectColumn column) {
		return getCore().createSelectColumn(column, OrderType.ASC);
	}

	/**
	 * OrderBy節で降順ソートするカラムを指定します。
	 * 
	 * エンティティー定義ファイルで定義されたカラムの論理名でカラムを指定します。
	 *
	 * @param colName カラムの論理名
	 * <p>
	 * エンティティーの別名を指定したい場合は {@code "entityAlias.column"} とします。
	 * @return 指定されたカラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public static GSelectColumn desc(String colName) {
		return getCore().createSelectColumn(colName, OrderType.DESC);
	}

	/**
	 * OrderBy節で降順ソートするカラムを変換式で指定します。
	 * <p>
	 * カラムを独自に修飾したい場合などにこのメソッドを使用します。
	 * 
	 * @param exp 変換式
	 * <p>
	 * 次のように{@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。<br>
	 * {@code exp("$SUBSTR(#UnitPrice, 2, 2)")}<br>
	 * @return 指定されたカラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public static GSelectColumn desc(GExpression exp) {
		return getCore().createSelectColumn(exp, OrderType.DESC);
	}
	
	/**
	 * OrderBy節で昇順ソートするカラムを{@link GSelectColumn}で指定します。
	 * 
	 * サブクエリーで指定したい場合などに使用します。
	 * 
	 * @param column {@link GSelectColumn}
	 * <p>
	 * 次のように{@link #col(GExpression)}などで生成します。<br>
	 * {@code col(exp(":{QUERY}", querys(select)))}
	 * @return 指定されたカラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public static GSelectColumn desc(GSelectColumn column) {
		return getCore().createSelectColumn(column, OrderType.DESC);
	}

	/**
	 * 変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文を変換したり値をバインドするために使用します。<br>
	 * バインドする値がない場合、または配列で渡したい場合はこのメソッドを使用します。
	 * <p>
	 * SQL文を構築する際に使用する場合は以下のように使用します<br>
	 * {@code exp("id = ?", "1")}<br>
	 * SQL文をそのまま実行する際に使用する場合は以下のように使用します<br>
	 * {@code exp("SELECT * FROM itemMaster WHERE id = ?", "1")}
	 * <p>
	 * 記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param source SQL文やSQL文の一部
	 * @param arrayParams バインドする値
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression exp(String source, Object... arrayParams) {
		return getCore().createExpression(source, null, arrayParams);
	}
	
	/**
	 * 変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する際、検索条件の値だけを変更して複数実行したい場合にこのメソッドを使用します。<br>
	 * バインドする値が異なるだけのSQL文をレコードの件数分実行できます。<br>
	 * {@code exp("SELECT * FROM itemMaster WHERE id = ?", valuesList)}
	 * <p>
	 * 記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param source SQL文
	 * @param arrayParamsList バインドする値のリスト
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression exp(String source, List<Object[]> arrayParamsList) {
		return getCore().createExpression(source, null, arrayParamsList);
	}
	
	/**
	 * 変換式（{@link GExpression}）を指定します。
	 * <p>
	 * サブクエリーを使用したい場合にこのメソッドを使用します。
	 * <p>
	 * SQL文を構築する際に使用する場合は以下のように使用します<br>
	 * {@code exp("id = ? AND itemName IN (:{QUERY})", subQuery, "1")}<br>
	 * SQL文をそのまま実行する際に使用する場合は以下のように使用します。<br>
	 * {@code exp("SELECT * FROM itemMaster WHERE id = ? AND itemName IN (:{QUERY})", subQuery, "1")}
	 * <p>
	 * 記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param source SQL文
	 * @param subQuery サブクエリーのリスト
	 * <p>
	 * {@link #querys(GSelect...)}で取得します。
	 * @param arrayParams バインドする値
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression exp(String source, List<GSelect<?>> subQuery, Object... arrayParams) {
		return getCore().createExpression(source, subQuery, arrayParams);
	}
	
	/**
	 * 変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する際、操作したいレコードが複数ある、かつサブクエリーを使用したい場合にこのメソッドを使用します。<br>
	 * バインドする値が異なるだけのSQL文をレコードの件数分実行できます。<br>
	 * {@code exp("SELECT * FROM itemMaster WHERE id = ? AND itemName IN (:{QUERY}))", subQuery, valuesList)}
	 * <p>
	 * 記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param source SQL文
	 * @param subQuery サブクエリーのリスト
	 * <p>
	 * {@link #querys(GSelect...)}で取得します。
	 * @param arrayParamsList バインドする値のリスト
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression exp(String source, List<GSelect<?>> subQuery, List<Object[]> arrayParamsList) {
		return getCore().createExpression(source, subQuery, arrayParamsList);
	}
	
	/**
	 * 変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する場合で、SQL文を外部ファイルで保持する場合に使用します。<br>
	 * 外部ファイルのSQL文に対して値をバインドすることもできます。
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param file ファイル
	 * @param arrayParams バインドする値
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression exp(File file, Object... arrayParams) {
		return getCore().createExpression(file, null, arrayParams);
	}
	
	/**
	 * 変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する場合で、SQL文を外部ファイルで保持している、かつ操作したいレコードが複数ある場合にこのメソッドを使用します。<br>
	 * 外部ファイルのSQL文に対して値をバインドできます。<br>
	 * バインドする値が異なるだけのSQL文をレコードの件数分実行できます。<br>
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param file ファイル
	 * @param arrayParamsList バインドする値のリスト
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression exp(File file, List<Object[]> arrayParamsList) {
		return getCore().createExpression(file, null, arrayParamsList);
	}
	
	/**
	 * 変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する場合で、SQL文を外部ファイルで保持しているかつサブクエリーを使用したい場合にこのメソッドを使用します。<br>
	 * 外部ファイルのSQL文に対して値とサブクエリーをバインドできます。
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param file ファイル
	 * @param subQuery サブクエリーのリスト
	 * <p>
	 * {@link #querys(GSelect...)}で取得します。
	 * @param arrayParams バインドする値
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression exp(File file, List<GSelect<?>> subQuery, Object... arrayParams) {
		return getCore().createExpression(file, subQuery, arrayParams);
	}
	
	/**
	 * 条件式（{@link GExpressionFactor}）とそこにバインドする値から変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文を構築する際、{@link GExpressionFactor}を使用したい場合にこのメソッドを使用します。
	 * <p>
	 * {@code exp(NOT("#im.CompanyCode = ?")), "15")}
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param condition {@link GExpressionFactor}
	 * <p>
	 * {@link #$(String)}や{@link #NOT(String)}で生成します。
	 * @param arrayParams バインドする値
	 * @return 変換式
	 * @author KCCS K.Fujita
	 * @create 2013/04/26
	 * @since 3.12.0
	 */
	public static GExpression exp(GExpressionFactor condition, Object...arrayParams) {
		return getCore().createExpression(condition, null, arrayParams);
	}
	
	/**
	 * 条件式（{@link GExpressionFactor}）とその中で使用されるサブクエリーのリスト、そこにバインドする値から変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文を構築する際、{@link GExpressionFactor}とサブクエリーを使用したい場合にこのメソッドを使用します。
	 * <p>
	 * {@code exp(NOT("#im.CompanyCode = ?").AND("#im.UnitPrice > ?"), querys(subQuery), "15", "20")}
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param condition {@link GExpressionFactor}
	 * <p>
	 * {@link #$(String)}や{@link #NOT(String)}で生成します。
	 * @param subQuery サブクエリーのリスト
	 * <p>
	 * {@link #querys(GSelect...)}で取得します。
	 * @param arrayParams バインドする値
	 * @return 変換式
	 * @author KCCS K.Fujita
	 * @create 2013/06/24
	 * @since 3.12.0
	 */
	public static GExpression exp(GExpressionFactor condition, List<GSelect<?>> subQuery, Object... arrayParams) {
		return getCore().createExpression(condition, subQuery, arrayParams);
	}
	
	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文を変換したり値をバインドするために使用します。<br>
	 * このメソッドはバインドする値をマップで渡すことができます。
	 * <p>
	 * SQL文を構築する際に使用する場合は以下のように使用します<br>
	 * {@code expMap("id = :keyOfMap", map)}
	 * SQL文をそのまま実行する際に使用する場合は以下のように使用します<br>
	 * {@code expMap("SELECT * FROM itemMaster WHERE id = :keyOfMap", map)}
	 * <p>
	 * 記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param source SQL文やSQL文の一部
	 * @param mapParams バインドする値のマップ
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression expMap(String source, Map<String, Object> mapParams) {
		return getCore().createMapExpression(source, null, mapParams);
	}
	
	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する際、検索条件の値だけを変更して複数実行したい場合にこのメソッドを使用します。<br>
	 * このメソッドはバインドする値をマップで渡すことができます。
	 * バインドする値が異なるだけのSQL文をリストの件数分実行できます。<br>
	 * {@code expMap("SELECT * FROM itemMaster WHERE id = :keyOfMap", mapList)}
	 * <p>
	 * 記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param source SQL文
	 * @param paramsMapList バインドする値のマップのリスト
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression expMap(String source, List<Map<String, Object>> paramsMapList) {
		return getCore().createMapExpression(source, null, paramsMapList);
	}
	
	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * サブクエリーを使用したい場合にこのメソッドを使用します。
	 * このメソッドはバインドする値をマップで渡すことができます。
	 * <p>
	 * SQL文を構築する際に使用する場合は以下のように使用します<br>
	 * {@code expMap("id = :keyOfMap AND itemName IN (:{QUERY})", subQuery, map)}<br>
	 * SQL文をそのまま実行する際に使用する場合は以下のように使用します。<br>
	 * {@code expMap("SELECT * FROM itemMaster WHERE id = :keyOfMap AND itemName IN (:{QUERY})", subQuery, map)}
	 * <p>
	 * 記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param source SQL文
	 * @param subQuery サブクエリーのリスト
	 * <p>
	 * {@link #querys(GSelect...)}で取得します。
	 * @param mapParams バインドする値のマップ
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression expMap(String source, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		return getCore().createMapExpression(source, subQuery, mapParams);
	}
	
	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する場合で、SQL文を外部ファイルで保持している場合に使用します。<br>
	 * 外部ファイルのSQL文に対して値をバインドできます。<br>
	 * このメソッドはバインドする値をマップで渡すことができます。
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param file ファイル
	 * @param mapParams バインドする値のマップ
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression expMap(File file, Map<String, Object> mapParams) {
		return getCore().createMapExpression(file, null, mapParams);
	}

	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する場合で、SQL文を外部ファイルで保持している、かつ操作したいレコードが複数ある場合にこのメソッドを使用します。<br>
	 * 外部ファイルのSQL文に対して値をバインドできます。<br>
	 * このメソッドはバインドする値をマップで渡すことができます。<br>
	 * バインドする値が異なるだけのSQL文をリストの件数分実行できます。
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param file ファイル
	 * @param mapParamsList バインドする値のマップのリスト
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression expMap(File file, List<Map<String, Object>> mapParamsList) {
		return getCore().createMapExpression(file, null, mapParamsList);
	}
	
	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文をそのまま実行する場合で、SQL文を外部ファイルで保持している、かつサブクエリ―を使用したい場合に使用します。<br>
	 * このメソッドはバインドする値をマップで渡すことができます。
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param file ファイル
	 * @param subQuery サブクエリーのリスト
	 * <p>
	 * {@link #querys(GSelect...)}で取得します。
	 * @param mapParams バインドする値のマップ
	 * @return 変換式
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static GExpression expMap(File file, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		return getCore().createMapExpression(file, subQuery, mapParams);
	}
	
	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文を構築する際、{@link GExpressionFactor}を使用したい場合にこのメソッドを使用します。
	 * このメソッドはバインドする値をマップで渡すことができます。
	 * <p>
	 * {@code expMap(NOT("#im.CompanyCode = :[code]")), paramMap)}
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param condition {@link GExpressionFactor}
	 * <p>
	 * {@link #$(String)}や{@link #NOT(String)}で生成します。
	 * @param mapParams バインドする値のマップ
	 * @return 変換式
	 * @author KCCS K.Fujita
	 * @create 2013/04/26
	 * @since 3.12.0
	 */
	public static GExpression expMap(GExpressionFactor condition, Map<String, Object> mapParams) {
		return getCore().createMapExpression(condition, null, mapParams);
	}

	/**
	 * マップを使用して変換式（{@link GExpression}）を指定します。
	 * <p>
	 * SQL文を構築する際、{@link GExpressionFactor}とサブクエリ―を使用したい場合にこのメソッドを使用します。
	 * このメソッドはバインドする値をマップで渡すことができます。
	 * <p>
	 * {@code expMap(NOT("#im.CompanyCode = :[code]").AND("#im.UnitPrice > :{QUERY}"), querys(subQuery), paramMap)}
	 * <p>
	 * バインド先に使用する記号の使い方などの詳細は{@link GExpression}を参照してください。
	 * 
	 * @param condition {@link GExpressionFactor}
	 * <p>
	 * {@link #$(String)}や{@link #NOT(String)}で生成します。
	 * @param subQuery サブクエリーのリスト
	 * <p>
	 * {@link #querys(GSelect...)}で取得します。
	 * @param mapParams バインドする値のマップ
	 * @return 変換式
	 * @author KCCS K.Fujita
	 * @create 2013/06/24
	 * @since 3.12.0
	 */
	public static GExpression expMap(GExpressionFactor condition, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		return getCore().createMapExpression(condition, subQuery, mapParams);
	}
	
	/**
	 * サブクエリーのリストを取得します。
	 * 
	 * @param subQuery サブクエリー
	 * <p>
	 * {@link #select(String)}や{@link #selectSql()}などで取得します。
	 * @return サブクエリーのリスト
	 * @author KCCS yamashita
	 * @create 2012/12/13
	 * @since 3.12.0
	 */
	public static List<GSelect<?>> querys(GSelect<?>... subQuery) {
		return getCore().createQueryList(subQuery);
	}
	
	/**
	 * 丸括弧で囲まれる条件式（{@link GExpressionFactor}）を作成します。<br>
	 * 主に、単純な条件式を作成する際に使用します。<br>
	 * <p>
	 * <pre>
	 * Example :<br>
	 *	<b>$</b>("ItemCode = ?").AND("Unit = ?")
	 * </pre>
	 * 詳細な使い方は{@link GExpressionFactor}を参照してください。
	 * 
	 * @param condition 丸括弧で囲まれる条件式
	 * @return 作成された{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public static GExpressionFactor $(String condition) {
		return getCore().createExpressionFactor(condition, Operator.$);
	}
	
	/**
	 * 丸括弧で囲まれる条件式（{@link GExpressionFactor}）を作成します。<br>
	 * 主に、複雑な条件式を作成する際に使用します。<br>
	 * <p>
	 * <pre>
	 * Example :<br>
	 *	<b>$</b>($("ItemCode = ?").OR($("Code = ?").AND("Index = ?"))).AND("Unit = ?")
	 * </pre>
	 * 詳細な使い方は{@link GExpressionFactor}を参照してください。
	 * 
	 * @param condition 丸括弧で囲まれる条件式（{@link GExpressionFactor}）
	 * @return 作成された{@link GExpressionFactor}
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public static GExpressionFactor $(GExpressionFactor condition) {
		return getCore().createExpressionFactor(condition, Operator.$);
	}
	
	/**
	 * 1つの検索条件をNOT演算子で囲みます。
	 * <p>
	 * 1つの検索条件をNOT演算子で囲みたい場合にこのメソッドを使用します。<br>
	 * 条件式（{@link GExpressionFactor}）を返却するため、次のようにさらに条件式をつなげて記述することができます。
	 * <p>
	 * <pre><b>NOT</b>("ItemCode = ?").AND("Unit = ?")</pre>
	 * {@link #exp(GExpressionFactor, Object...)}や{@link #expMap(GExpressionFactor, java.util.Map)}と
	 * 組み合わせて使用することを前提としています。<br>
	 * 詳細な使い方は{@link GExpressionFactor}を参照してください。
	 * 
	 * @param condition 検索条件
	 * <p>
	 * 1検索条件のみ渡すことができます。
	 * <pre>"ItemCode = ?"</pre>
	 * @return NOT演算子を適用した条件式
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public static GExpressionFactor NOT(String condition) {
		return getCore().createExpressionFactor(condition, Operator.NOT);
	}
	
	/**
	 * 複数の検索条件をNOT演算子で囲みます。
	 * <p>
	 * 複数の検索条件をNOT演算子で囲みたい場合にこのメソッドを使用します。<br>
	 * 条件式（{@link GExpressionFactor}）を返却するため、次のようにさらに条件式をつなげて記述することができます。
	 * <p>
	 * <pre><b>NOT</b>($("Code = ?").AND("Index = ?")).AND("Unit = ?")</pre>
	 * {@link #exp(GExpressionFactor, Object...)}や{@link #expMap(GExpressionFactor, java.util.Map)}と
	 * 組み合わせて使用することを前提としています。
	 * 詳細な使い方は{@link GExpressionFactor}を参照してください。
	 * <p>
	 * @param condition 複数の検索条件
	 * <p>
	 * 下記のように{@link #$(String)}などで生成します。
	 * <pre>$("Code = ?").AND("Index = ?")</pre>
	 * @return NOT演算子を適用した条件式
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	public static GExpressionFactor NOT(GExpressionFactor condition) {
		return getCore().createExpressionFactor(condition, Operator.NOT);
	}
	
	/**
	 * {@link GEntity}を取得します。
	 * <p>
	 * エンティティー定義ファイルから定義をロードした{@link GEntity}を返します。
	 * 
	 * @param entityName エンティティー名（エンティティー定義ファイルの名前から拡張子を除いたもの）
	 * @return エンティティー定義ファイルから定義をロードした{@link GEntity}
	 * @author KCCS kitamura
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static GEntity entity(String entityName) {
		return getCore().createEntity(entityName);
	}
	
	/**
	 * ストアドプロシージャ／ファンクションのパラメータを{@link GBindParam}で取得します。
	 * <p>
	 * このメソッドを使用してストアドプロシージャ／ファンクションに渡すパラメータを作成します。<br>
	 * パラメータはINモードのみ扱い、値と型を指定します。
	 * <p>
	 * @param value パラメータの値
	 * @param type パラメータの型
	 * <p>
	 * {@link GColumnType}の定数を使用します。
	 * @return {@link GBindParam}
	 * @author KCCS K.Fujita
	 * @create 2013/03/08
	 * @since 3.12.0
	 */
	public static GBindParam prm(Object value, GColumnType type) {
		return getCore().createBindParam(ParamMode.IN, value, type);
	}
	
	/**
	 * {@link GRecord}を取得します。
	 * <p>
	 * 空の{@link GRecord}を生成し返します。
	 * 
	 * @return 空の{@link GRecord}
	 * @author KCCS hashimoto
	 * @create 2012/11/12
	 * @since 3.12.0
	 */
	public static GRecord createRecord() {
		return getCore().createRecord();
	}
	
	/**
	 * ファイルを読み込んだ{@link File}を取得します。
	 * <p>
	 * ファイルにはSQL文を記述しておきます。<br>
	 * MVELを使用して記述することができます。
	 * 
	 * @param path ファイルパス
	 * @return ファイルを読み込んだ{@link File}
	 * @author KCCS yamashita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public static File file(String path) {
		return getCore().createFile(path);
	}

	/**
	 * {@link GQueryAssistantsCore}を取得します。
	 * 
	 * {@link GQueryAssistantsCore}をDIコンテナから取得して返します。
	 * 
	 * @return {@link GQueryAssistantsCore}
	 * @author KCCS kitamura
	 * @create 2013/03/27
	 * @since 3.12.0
	 */
	private static GQueryAssistantsCore getCore() {
		return GFrameworkUtils.getComponent(GQueryAssistantsCore.class.getName());
	}
}
