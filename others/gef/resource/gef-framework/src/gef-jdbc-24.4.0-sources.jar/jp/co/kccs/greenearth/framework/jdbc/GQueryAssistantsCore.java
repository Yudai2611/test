/*
 * Copyright 2013-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.commons.utils.GURIScheme;
import jp.co.kccs.greenearth.framework.jdbc.GExpressionFactor.Operator;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectQuery;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectQueryFactory;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQueryFactory;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn.OrderType;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumnList;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntityFactory;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam.ParamMode;

/**
 * SQL生成補助機能の共通機能を提供するクラスです.
 *
 * @author KCCS kitamura
 * @create 2012/10/29
 * @since 3.12.0
 */
public class GQueryAssistantsCore {
	
	/** ファイル読み取りの際にパスに付与するセパレータ */
	private static final String FILE_SEPARATOR = "/";
	/** {@link ThreadLocal}のインスタンス */
	private static ThreadLocal<GEntityQuery< ? >> queryKeeper = new ThreadLocal<GEntityQuery< ? >>();
	
	/** ファイル読み取りの際に使用する基本ルートパス */
	private String expFileRootDirectoryPath = null;
	/** エンティティ―生成用ファクトリ */
	private GEntityFactory entityFactory;
	
	/**
	 * {@link GQueryAssistantsCore}を初期化します.
	 * 
	 * @param expFileRootDirectoryPath ファイル読み取りの際に使用する基本ルートパス
	 * @param entityFactory エンティティ―生成用ファクト
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public GQueryAssistantsCore(String expFileRootDirectoryPath, GEntityFactory entityFactory) {
		this.expFileRootDirectoryPath = expFileRootDirectoryPath;
		this.entityFactory = entityFactory;
	}
	
	/**
	 * {@link GEntityQuery}のサブインターフェースのインスタンスを取得します.
	 * 
	 * @param <T> 取得するインスタンスの型（{@link GEntityQuery}のサブインターフェース）
	 * @param clazz 取得するインスタンスのクラス
	 * @param entityName エンティティー名
	 * @param entityAlias エンティティー別名
	 * @return {@link GEntityQuery}のサブインターフェースのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public <T extends GEntityQuery<?>> T createEntityQuery(Class<T> clazz, String entityName, String entityAlias) {
		T query = GEntityQueryFactory.getQuery(clazz, entityFactory.getEntity(entityName), entityAlias);
		queryKeeper.set(query);
		return query;
	}
	
	/**
	 * 指定されたエンティティ情報、カラム名から{@link GSelectColumn}のインスタンスを生成します.<br/>
	 * このメソッドで生成されたインスタンスはSelect節、GroupBy節で使用できます.<br/>
	 * 
	 * @param columnName カラム名
	 * @return Select節、GroupBy節で使用できる{@link GSelectColumn}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GSelectColumn createSelectColumn(String columnName) {
		return ((GEntitySelect) queryKeeper.get()).createSelectColumn(columnName);
	}
		
	/**
	 * 指定されたエンティティ情報、カラム名、カラム別名、関数の種類から{@link GSelectColumn}のインスタンスを生成します.<br/>
	 * このメソッドで生成されたインスタンスはSelect節で使用できます.<br/>
	 * 
	 * @param columnName カラム名
	 * @param alias カラム別名
	 * @param funcType 関数の種類
	 * @return Select節で使用できる{@link GSelectColumn}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GSelectColumn createSelectColumn(String columnName, String alias, FuncType funcType) {
		GSelectColumn vc = ((GEntitySelect) queryKeeper.get()).createSelectColumn(columnName);
		vc.setAlias(alias);
		vc.setFuncType(funcType);
		return vc;
	}
	
	/**
	 * 指定されたエンティティ情報と式から{@link GSelectColumn}のインスタンスを生成します.<br/>
	 * このメソッドで生成されたインスタンスはGroupBy節で使用できます.<br/>
	 * 
	 * @param exp 式
	 * @return GroupBy節で使用できる{@link GSelectColumn}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GSelectColumn createSelectColumn(GExpression exp) {
		return ((GEntitySelect) queryKeeper.get()).createSelectColumn(exp);
	}
		
	/**
	 * 指定されたエンティティ情報、式、カラム別名から{@link GSelectColumn}のインスタンスを生成します.<br/>
	 * このメソッドで生成されたインスタンスはSelect節で使用できます.<br/>
	 * 
	 * @param exp 式
	 * @param alias カラム別名
	 * @return Select節で使用できる{@link GSelectColumn}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GSelectColumn createSelectColumn(GExpression exp, String alias) {
		GSelectColumn vc = ((GEntitySelect) queryKeeper.get()).createSelectColumn(exp);
		vc.setAlias(alias);
		return vc;
	}
	
	/**
	 * 指定されたエンティティ情報、カラム名、ソート順から{@link GSelectColumn}のインスタンスを生成します.<br/>
	 * このメソッドで生成されたインスタンスはOrderBy節で使用できます.<br/>
	 * 
	 * @param columnName カラム名
	 * @param orderType ソート順
	 * @return OrderBy節で使用できる{@link GSelectColumn}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public GSelectColumn createSelectColumn(String columnName, OrderType orderType) {
		GEntitySelect select = (GEntitySelect) queryKeeper.get();
		for (GSelectColumn column : select.getSelectColumns()) {
			if (column.getAlias() != null && column.getAlias().equals(columnName)) {
				column.setOrderType(orderType);
				return column;
			}
		}
		GSelectColumn column = select.createSelectColumn(columnName);
		column.setOrderType(orderType);
		return column;
	}
	
	/**
	 * 指定されたエンティティ情報、式、ソート順から{@link GSelectColumn}のインスタンスを生成します.<br/>
	 * このメソッドで生成されたインスタンスはOrderBy節で使用できます.<br/>
	 * 
	 * @param exp 式
	 * @param orderType ソート順
	 * @return OrderBy節で使用できる{@link GSelectColumn}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	public GSelectColumn createSelectColumn(GExpression exp, OrderType orderType) {
		GSelectColumn vc = ((GEntitySelect) queryKeeper.get()).createSelectColumn(exp);
		vc.setOrderType(orderType);
		return vc;
	}
	
	/**
	 * ソート順が指定された{@link GSelectColumn}のインスタンスを生成します.
	 * 
	 * @param column {@link GSelectColumn}のインスタンス
	 * @param orderType ソート順
	 * @return 指定されたソート順に設定された{@link GSelectColumn}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public GSelectColumn createSelectColumn(GSelectColumn column, OrderType orderType) {
		column.setOrderType(orderType);
		return column;
	}
	
	/**
	 * 指定されたメインエンティティとその全てのサブエンティティが持つカラムのリストを生成します.
	 * 
	 * @return メインエンティティと全てのサブエンティティが持つカラムのリスト
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GSelectColumnList createSelectColumnList() {
		return ((GEntitySelect) queryKeeper.get()).createSelectColumnListAll();
	}
	
	/**
	 * 指定されたエンティティが持つカラムのリストを生成します.
	 * 
	 * @param select メインエンティティ
	 * @param entity カラムを取得するエンティティ
	 * @param entityAlias カラムを取得するエンティティの別名
	 * @return 指定されたエンティティが持つカラムのリスト
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GSelectColumnList createSelectColumnList(GEntitySelect select, GEntity entity, String entityAlias) {
		return select.createSelectColumnList(entity, entityAlias);
	}
	
	/**
	 * 指定されたエンティティが持つカラムのリストを生成します.
	 * 
	 * @param entityName カラムを取得するエンティティの名前
	 * @return 指定されたエンティティが持つカラムのリスト
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GSelectColumnList createSelectColumnList(String entityName) {
		return ((GEntitySelect) queryKeeper.get()).createSelectColumnList(entityName);
	}
	
	/**
	 * 指定された文字列、サブクエリのリストで{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param source SQL文字列
	 * @param subQueryList サブクエリのリスト
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	protected GStringExpression createExpression(String source, List<GSelect<?>> subQueryList) {
		if (GStringUtils.isEmpty(source)) {
			return null;
		}
		GStringExpression exp = new GStringExpression();
		exp.setSource(source);
		exp.setSubQueryList(subQueryList);
		return exp;
	}
	
	/**
	 * 指定された文字列、サブクエリ、バインドパラメータで{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param source SQL文字列
	 * @param subQuery サブクエリのリスト
	 * @param arrayParams バインドパラメータ（配列）
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createExpression(String source, List<GSelect<?>> subQuery, Object[] arrayParams) {
		GStringExpression exp = createExpression(source, subQuery);
		if (exp != null) {
			exp.setArrayParams(arrayParams);
		}
		return exp;
	}

	/**
	 * 指定された文字列、サブクエリ、バインドパラメータの配列で{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param source SQL文字列
	 * @param subQuery サブクエリのリスト
	 * @param arrayParamsList バインドパラメータ（配列）のリスト
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createExpression(String source, List<GSelect<?>> subQuery, List<Object[]> arrayParamsList) {
		GStringExpression exp = createExpression(source, subQuery);
		if (exp != null) {
			exp.setArrayParamsList(arrayParamsList);
		}
		return exp;
	}

	/**
	 * 指定された文字列、サブクエリ、バインドパラメータで{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param source SQL文字列
	 * @param subQuery サブクエリのリスト
	 * @param mapParams バインドパラメータ（マップ）
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createMapExpression(String source, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		GStringExpression exp = createExpression(source, subQuery);
		if (exp != null) {
			exp.setMapParams(mapParams);
		}
		return exp;
	}

	/**
	 * 指定された文字列とサブクエリのリスト、バインドパラメータのリストから{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param source SQL文字列
	 * @param subQueryList サブクエリのリスト
	 * @param arrayParamsMap バインドパラメータ（マップ）のリスト
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createMapExpression(String source, List<GSelect<?>> subQueryList, List<Map<String, Object>> arrayParamsMap) {
		GStringExpression exp = createExpression(source, subQueryList);
		if (exp != null) {
			exp.setMapParamsList(arrayParamsMap);
		}
		return exp;
	}

	/**
	 * 指定されたファイル、サブクエリから{@link GFileExpression}のインスタンスを生成します.
	 * 
	 * @param file ファイル
	 * @param subQuery サブクエリ
	 * @return 指定された情報から成る{@link GFileExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	protected GFileExpression createExpression(File file, List<GSelect<?>> subQuery) {
		GFileExpression exp = new GFileExpression();
		exp.setFile(file);
		exp.setSubQueryList(subQuery);
		return exp;
	}
	
	/**
	 * 指定されたファイル、サブクエリ、バインドパラメータから{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param file ファイル
	 * @param subQuery サブクエリ
	 * @param arrayParams バインドパラメータ（配列）
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createExpression(File file, List<GSelect<?>> subQuery, Object[] arrayParams) {
		GFileExpression exp = createExpression(file, subQuery);
		if (exp != null) {
			exp.setArrayParams(arrayParams);
		}
		return exp;
	}
	
	/**
	 * 指定されたファイル、サブクエリ、バインドパラメータから{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param file ファイル
	 * @param subQuery サブクエリ
	 * @param arrayParamsList バインドパラメータ（配列）のリスト
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createExpression(File file, List<GSelect<?>> subQuery, List<Object[]> arrayParamsList) {
		GFileExpression exp = createExpression(file, subQuery);
		if (exp != null) {
			exp.setArrayParamsList(arrayParamsList);
		}
		return exp;
	}
	
	/**
	 * 指定されたファイル、サブクエリ、バインドパラメータから{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param file ファイル
	 * @param subQuery サブクエリのリスト
	 * @param mapParams バインドパラメータ（マップ）
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createMapExpression(File file, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		GFileExpression exp = createExpression(file, subQuery);
		if (exp != null) {
			exp.setMapParams(mapParams);
		}
		return exp;
	}
	
	/**
	 * 指定されたファイル、サブクエリ、バインドパラメータから{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param file ファイル
	 * @param subQuery サブクエリのリスト
	 * @param arrayParamsMap バインドパラメータ（マップ）のリスト
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GExpression createMapExpression(File file, List<GSelect<?>> subQuery, List<Map<String, Object>> arrayParamsMap) {
		GFileExpression exp = createExpression(file, subQuery);
		if (exp != null) {
			exp.setMapParamsList(arrayParamsMap);
		}
		return exp;
	}

	/**
	 * 指定された{@link GExpressionFactor}、サブクエリ、バインドパラメータから{@link GAssembledFactorExpression}のインスタンスを生成します.
	 * 
	 * @param factor {@link GExpressionFactor}のインスタンス
	 * @param subQueryList サブクエリのリスト
	 * @return 指定された情報から成る{@link GAssembledFactorExpression}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/06/24
	 * @since 3.12.0
	 */
	protected GAssembledFactorExpression createExpression(GExpressionFactor factor, List<GSelect<?>> subQueryList) {
		if (factor == null) {
			return null;
		}
		GAssembledFactorExpression exp = new GAssembledFactorExpression();
		exp.setRootFactor(factor);
		exp.setSubQueryList(subQueryList);
		return exp;
	}

	/**
	 * 指定された{@link GExpressionFactor}、サブクエリ、バインドパラメータから{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param factor {@link GExpressionFactor}のインスタンス
	 * @param subQuery サブクエリのリスト
	 * @param arrayParams バインドパラメータ（配列）
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/06/24
	 * @since 3.12.0
	 */
	public GExpression createExpression(GExpressionFactor factor, List<GSelect<?>> subQuery, Object[] arrayParams) {
		GAssembledFactorExpression exp = createExpression(factor, subQuery);
		if (exp != null) {
			exp.setArrayParams(arrayParams);
		}
		return exp;
	}

	/**
	 * 指定された{@link GExpressionFactor}、サブクエリ、バインドパラメータから{@link GExpression}のインスタンスを生成します.
	 * 
	 * @param factor {@link GExpressionFactor}のインスタンス
	 * @param subQuery サブクエリのリスト
	 * @param mapParams バインドパラメータ（マップ）
	 * @return 指定された情報から成る{@link GExpression}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/06/24
	 * @since 3.12.0
	 */
	public GExpression createMapExpression(GExpressionFactor factor, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		GAssembledFactorExpression exp = createExpression(factor, subQuery);
		if (exp != null) {
			exp.setMapParams(mapParams);
		}
		return exp;
	}

	/**
	 * {@link GDirectQuery}のサブインターフェースのインスタンスを生成します.
	 * 
	 * @param <T> 生成するインスタンスの型（{@link GDirectQuery}のサブインターフェース）
	 * @param directQuery 生成するインスタンスのクラス名
	 * @return {@link GDirectQuery}のサブインターフェースのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public <T extends GDirectQuery<?>> T createDirectQuery(Class<T> directQuery) {
		return GDirectQueryFactory.getQuery(directQuery);
	}
	
	/**
	 * コンポーネント名を指定して{@link GDirectQuery}のサブインターフェースのインスタンスを生成します.
	 * 
	 * @param <T> 生成するインスタンスの型（{@link GDirectQuery}のサブインターフェース）
	 * @param componentName コンポーネント名
	 * @return {@link GDirectQuery}のサブインターフェースのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public <T extends GDirectQuery<?>> T createDirectQuery(String componentName) {
		return GDirectQueryFactory.getQuery(componentName);
	}
	
	/**
	 * サブクエリの配列をリストに変換します.
	 * 
	 * @param subQuery サブクエリの配列
	 * @return サブクエリのリスト
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public List<GSelect<?>> createQueryList(GSelect<?>... subQuery) {
		List<GSelect<?>> subQueryList = new ArrayList<GSelect<?>>();
		for (GSelect<?> select : subQuery) {
			subQueryList.add(select);
		}
		return subQueryList;
	}
	
	/**
	 * エンティティの名前を指定して{@link GEntity}のインスタンスを取得します.
	 * 
	 * @param entityName 取得したいエンティティの名前
	 * @return 実行するSQL文及びバインドする値が設定された{@link GEntity}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public GEntity createEntity(String entityName) {
		return entityFactory.getEntity(entityName);
	}
	
	/**
	 * 指定のファイルを{@link File}のインスタンスとして取得します.
	 * 
	 * @param path 取得したいファイルのパス
	 * @return {@link File}のインスタンス
	 * @author KCCS yamashita
	 * @create 2012/11/29
	 * @since 3.12.0
	 */
	public File createFile(String path) {
		StringBuilder pathBuilder = new StringBuilder();
		String rootPath = getExpressionFileRootPath();
		pathBuilder.append(rootPath);
		if (!rootPath.endsWith(FILE_SEPARATOR) && !path.startsWith(FILE_SEPARATOR)) {
			pathBuilder.append(FILE_SEPARATOR);
		}
		pathBuilder.append(path);
		
		URI uri = GFileUtils.createURI(pathBuilder.toString());
		return isArchived(uri) ? new GMultiSchemeFile(uri) : new File(uri);
	}
	
	/**
	 * ファイル読み取りの際に使用する基本ルートパスを取得します.
	 * 
	 * @return ファイル読み取りの際に使用する基本ルートパス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public String getExpressionFileRootPath() {
		return expFileRootDirectoryPath;
	}
	
	/**
	 * {@link GRecord}のインスタンスを生成します.
	 * 
	 * @return {@link GRecord}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public GRecord createRecord() {
		return new GRecordImpl();
	}
	
	/**
	 * 指定されたパラメータモードと型から{@link GBindParam}のインスタンスを生成します.
	 * 
	 * @param mode パラメータモード
	 * @param type 型
	 * @return 指定された情報から成る{@link GBindParam}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public GBindParam createBindParam(ParamMode mode, GColumnType type) {
		return new GBindParam(mode, type);
	}
	
	/**
	 * 指定されたパラメータモードと値、型から{@link GBindParam}のインスタンスを生成します.
	 * 
	 * @param mode パラメータモード
	 * @param value 値
	 * @param type 型
	 * @return 指定された情報から成る{@link GBindParam}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/11
	 * @since 3.12.0
	 */
	public GBindParam createBindParam(ParamMode mode, Object value, GColumnType type) {
		return new GBindParam(mode, value, type);
	}
	
	/**
	 * 与えられた条件式と論理演算子から{@link GExpressionFactor}のインスタンスを生成します.
	 * 
	 * @param condition 条件式（文字列）
	 * @param operator 論理演算子
	 * @return {@link GExpressionFactor}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/06/12
	 * @since 3.12.0
	 */
	public GExpressionFactor createExpressionFactor(String condition, Operator operator) {
		return new GExpressionFactor(condition, operator);
	}
	
	/**
	 * 与えられた条件式と論理演算子から{@link GExpressionFactor}のインスタンスを生成します.
	 * 
	 * @param factor 条件式（{@link GExpressionFactor}）
	 * @param operator 論理演算子
	 * @return {@link GExpressionFactor}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/06/12
	 * @since 3.12.0
	 */
	public GExpressionFactor createExpressionFactor(GExpressionFactor factor, Operator operator) {
		return new GExpressionFactor(factor, operator);
	}
	
	/**
	 * 指定URIのリソースは、アーカイブされるかどうかを判断します.<br>
	 * @param uri URIオブジェクト
	 * @return true:アーカイブされる、false:アーカイブされない（物理ファイル）
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private boolean isArchived(URI uri){
		return !GURIScheme.convert(uri.getScheme()).equals(GURIScheme.FILE);
	}
	
	/**
	 * {@link File}ファイルの拡張クラスです.<br>
	 * 
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private class GMultiSchemeFile extends File {
		private URI fileUri;
		/**
		 * GMultiSchemeFileのコンストラクターです.<br>
		 * 
		 * @create 2024/04/30
		 * @author KCSS yangfeng
		 * @since 24.4.0
		 */
		public GMultiSchemeFile(URI uri) {
			// GMultiSchemeFileは、Fileオブジェクトを作るわけではなく、凌ぎで利用します。
			// uriは、jarスキームのURIであれば、super(uri)が例外発生しますので、これを回避するため、""を渡します。
			super(uri.getScheme().equals("file") ? uri.getPath() : "");
			fileUri = uri;
		}
		@Override
		public URI toURI() {
			return fileUri;
		}
	}
}
