/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.framework.jdbc.sql.GResultSetEnhancer;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;

/**
 * {@link GQuery}を実装する基底クラスです.
 *
 * @param <S> 各種ＳＱＬ操作クラス
 * @author KCCS kitamura
 * @create 2012/11/08
 * @since 3.12.0
 */
public abstract class GQueryBase<S extends GQuery<S>> implements GQuery<S> {

	/** DB毎のExecuterを保持するマップ */
	private Map<String, GSQLExecuter> sqlExecuterMap;
	/** DB情報 */
	private GDatabase database;

	/** 管理ＩＤ */
	private String managmentID = null;
	/** ステートメントの実行を待つ時間（秒） */
	private int timeoutSeconds = -1;
	
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GQueryBase() {
	}

	/**
	 * コンストラクタ.
	 * 
	 * @param sqlExecuterMap DB毎のExecuterを保持するマップ
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GQueryBase(Map<String, GSQLExecuter> sqlExecuterMap) {
		this.sqlExecuterMap = sqlExecuterMap;
	}

	/**
	 * {@link GDatabase}を返します。
	 * 
	 * @return {@link GDatabase}
	 */
	@Override
	public GDatabase getDatabase() {
		return database;
	}

	/**
	 * DB情報を設定します.
	 * 
	 * @param database DB情報
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public void setDatabase(GDatabase database) {
		this.database = database;
	}
	
	@Override
	public String getManagementID() {
		return managmentID;
	}

	@Override
	public S managementID(String managmentID) {
		this.managmentID = managmentID;
		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}
	
	@Override
	public S queryTimeout(int seconds) {
		this.timeoutSeconds = seconds;
		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}

	@Override
	public int getQueryTimeout() {
		return this.timeoutSeconds;
	}

	@Override
	public void clear() {
		managmentID = null;
	}
	
	/**
	 * {@link GSQLExecuter}のインスタンスを取得します.
	 * 
	 * @return {@link GSQLExecuter}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/11/08
	 * @since 3.12.0
	 */
	public GSQLExecuter getSqlExecuter() {
		return sqlExecuterMap.get(database.getDbType());
	}

	/**
	 * 結果セットのプロキシを取得します.
	 * 
	 * @param resultset 結果セット
	 * @param connection コネクション
	 * @return ResultSetのプロキシ
	 * @author hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected ResultSet enhanceResultSet(ResultSet resultset, Connection connection) {
		GResultSetEnhancer invoker = new GResultSetEnhancer(resultset, connection);
		return (ResultSet) Proxy.newProxyInstance(ResultSet.class.getClassLoader(), new Class< ? >[] {ResultSet.class}, invoker);
	}
	
	/**
	 * クエリの実行結果とコネクションを関連付け、クエリの実行結果が解放される場合はコネクションも解放されるようにします.
	 * 
	 * @param queryResult 関連付けが行われるクエリ実行結果
	 * @param connection クエリ実行結果に関連付けられるコネクション
	 * @return 関連付けが行われた後のクエリ実行結果
	 * @author KCCS K.Fujita
	 * @create 2013/04/22
	 * @since 3.12.0
	 */
	protected GQueryResult enhanceQueryResult(final GQueryResult queryResult, final Connection connection) {
		return new GQueryResult() {
			@Override
			public boolean hasResultSet() {
				return queryResult.hasResultSet();
			}
			@Override
			public Statement getExecutedStatement() throws SQLException {
				return queryResult.getExecutedStatement();
			}
			@Override
			public void close() throws SQLException {
				try {
					queryResult.close();
				}
				finally {
					GJdbcConnectionManagerFactory.getInstance().close(connection);
				}
			}
		};
	}
	
	/**
	 * クエリの実行結果とコネクションを解放します.
	 * 
	 * @param queryResult 解放するクエリの実行結果
	 * @param connection 解放するコネクション
	 * @throws SQLException リソースの解放に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/04/22
	 * @since 3.12.0
	 */
	protected void close(GQueryResult queryResult, Connection connection) throws SQLException {
		try {
			if (queryResult != null) {
				queryResult.close();
			}
		}
		finally {
			GJdbcConnectionManagerFactory.getInstance().close(connection);
		}
	}
	
	/**
	 * クエリの実行結果を解放します.
	 * 
	 * @param queryResult クエリの実行結果
	 * @throws SQLException リソースの解放に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/04/22
	 * @since 3.12.0
	 */
	protected void close(GQueryResult queryResult) throws SQLException {
		if (queryResult != null) {
			queryResult.close();
		}
	}
	
	@Override
	public SQLException generalizeException(SQLException e) {
		return getSqlExecuter().handleException(e);
	}
	
}
