/*
 * Copyright 2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.io.File;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GExpressionFactor.Operator;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectProcedure;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectSelect;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectUpdate;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityDelete;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityInsert;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityUpdate;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn.OrderType;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumnList;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam.ParamMode;

/**
 * SQL生成補助機能の共通機能を提供するクラスです（インジェクション対応版）.
 * 
 * @create 2015/02/17
 * @author KCCS yamashita
 * @since 3.15.0
 */
public class GQueryBuilderImpl implements GQueryBuilder {

	/** {@link GQueryAssistantsCore}のインスタンス */
	private GQueryAssistantsCore _core;
	
	/**
	 * コンストラクタ.
	 * 
	 * @param core {@link GQueryAssistantsCore}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GQueryBuilderImpl(GQueryAssistantsCore core) {
		_core = core;
	}
	@Override
	public GEntity entity(String entityName) {
		return getCore().createEntity(entityName);
	}
	@Override
	public GEntitySelect select(String entityName) {
		return getCore().createEntityQuery(GEntitySelect.class, entityName, null);
	}
	@Override
	public GEntitySelect select(String entityName, String entityAlias) {
		return getCore().createEntityQuery(GEntitySelect.class, entityName, entityAlias);
	}
	@Override
	public GEntityUpdate update(String entityName) {
		return getCore().createEntityQuery(GEntityUpdate.class, entityName, null);
	}
	@Override
	public GEntityDelete delete(String entityName) {
		return getCore().createEntityQuery(GEntityDelete.class, entityName, null);
	}
	@Override
	public GEntityInsert insert(String entityName) {
		return getCore().createEntityQuery(GEntityInsert.class, entityName, null);
	}
	@Override
	public GDirectSelect selectSql() {
		return getCore().createDirectQuery(GDirectSelect.class);
	}
	@Override
	public GDirectSelect selectSql(String componentName) {
		return getCore().createDirectQuery(componentName);
	}
	@Override
	public GDirectUpdate updateSql() {
		return (GDirectUpdate) getCore().createDirectQuery(GDirectUpdate.class);
	}
	@Override
	public GDirectUpdate updateSql(String componentName) {
		return (GDirectUpdate) getCore().createDirectQuery(componentName);
	}
	@Override
	public GDirectProcedure procedure() {
		return (GDirectProcedure) getCore().createDirectQuery(GDirectProcedure.class);
	}
	@Override
	public GDirectProcedure procedure(String componentName) {
		return (GDirectProcedure) getCore().createDirectQuery(componentName);
	}
	@Override
	public GSelectColumn col(String columnName) {
		return getCore().createSelectColumn(columnName);
	}
	@Override
	public GSelectColumn col(String columnName, String alias) {
		return getCore().createSelectColumn(columnName, alias, (FuncType) null);
	}
	@Override
	public GSelectColumn col(String columnName, FuncType funcType) {
		return getCore().createSelectColumn(columnName, null, funcType);
	}
	@Override
	public GSelectColumn col(String columnName, String alias, FuncType func) {
		return getCore().createSelectColumn(columnName, alias, func);
	}
	@Override
	public GSelectColumn col(GExpression exp) {
		return getCore().createSelectColumn(exp);
	}
	@Override
	public GSelectColumn col(GExpression exp, String alias) {
		return getCore().createSelectColumn(exp, alias);
	}
	@Override
	public GSelectColumnList colsAll() {
		return getCore().createSelectColumnList();
	}
	@Override
	public GSelectColumnList cols(String entityName) {
		return getCore().createSelectColumnList(entityName);
	}
	@Override
	public GSelectColumn asc(String colName) {
		return getCore().createSelectColumn(colName, OrderType.ASC);
	}
	@Override
	public GSelectColumn asc(GExpression exp) {
		return getCore().createSelectColumn(exp, OrderType.ASC);
	}
	@Override
	public GSelectColumn asc(GSelectColumn column) {
		return getCore().createSelectColumn(column, OrderType.ASC);
	}
	@Override
	public GSelectColumn desc(String colName) {
		return getCore().createSelectColumn(colName, OrderType.DESC);
	}
	@Override
	public GSelectColumn desc(GExpression exp) {
		return getCore().createSelectColumn(exp, OrderType.DESC);
	}
	@Override
	public GSelectColumn desc(GSelectColumn column) {
		return getCore().createSelectColumn(column, OrderType.DESC);
	}
	@Override
	public GExpression exp(String source, Object... arrayParams) {
		return getCore().createExpression(source, null, arrayParams);
	}
	@Override
	public GExpression expMap(String source, Map<String, Object> mapParams) {
		return getCore().createMapExpression(source, null, mapParams);
	}
	@Override
	public GExpression exp(String source, List<GSelect<?>> subQuery, Object... arrayParams) {
		return getCore().createExpression(source, subQuery, arrayParams);
	}
	@Override
	public GExpression expMap(String source, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		return getCore().createMapExpression(source, subQuery, mapParams);
	}
	@Override
	public GExpression exp(String source, List<GSelect<?>> subQuery, List<Object[]> arrayParamsList) {
		return getCore().createExpression(source, subQuery, arrayParamsList);
	}
	@Override
	public GExpression exp(String source, List<Object[]> arrayParamsList) {
		return getCore().createExpression(source, null, arrayParamsList);
	}
	@Override
	public GExpression expMap(String source, List<Map<String, Object>> arrayParamsList) {
		return getCore().createMapExpression(source, null, arrayParamsList);
	}
	@Override
	public GExpression exp(File file, Object... arrayParams) {
		return getCore().createExpression(file, null, arrayParams);
	}
	@Override
	public GExpression expMap(File file, Map<String, Object> mapParams) {
		return getCore().createMapExpression(file, null, mapParams);
	}
	@Override
	public GExpression exp(File file, List<GSelect<?>> subQuery, Object... arrayParams) {
		return getCore().createExpression(file, subQuery, arrayParams);
	}
	@Override
	public GExpression expMap(File file, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		return getCore().createMapExpression(file, subQuery, mapParams);
	}
	@Override
	public GExpression exp(File file, List<Object[]> arrayParamsList) {
		return getCore().createExpression(file, null, arrayParamsList);
	}
	@Override
	public GExpression expMap(File file, List<Map<String, Object>> arrayParamsList) {
		return getCore().createMapExpression(file, null, arrayParamsList);
	}
	@Override
	public GExpression exp(GExpressionFactor condition, Object...arrayParams) {
		return getCore().createExpression(condition, null, arrayParams);
	}
	@Override
	public GExpression expMap(GExpressionFactor condition, Map<String, Object> mapParams) {
		return getCore().createMapExpression(condition, null, mapParams);
	}
	@Override
	public GExpression exp(GExpressionFactor condition, List<GSelect<?>> subQuery, Object... arrayParams) {
		return getCore().createExpression(condition, subQuery, arrayParams);
	}
	@Override
	public GExpression expMap(GExpressionFactor condition, List<GSelect<?>> subQuery, Map<String, Object> mapParams) {
		return getCore().createMapExpression(condition, subQuery, mapParams);
	}
	@Override
	public List<GSelect<?>> querys(GSelect<?>... subQuery) {
		return getCore().createQueryList(subQuery);
	}
	@Override
	public GRecord createRecord() {
		return getCore().createRecord();
	}
	@Override
	public GBindParam prm(Object value, GColumnType type) {
		return getCore().createBindParam(ParamMode.IN, value, type);
	}
	@Override
	public File file(String path) {
		return getCore().createFile(path);
	}
	@Override
	public GExpressionFactor $(String condition) {
		return getCore().createExpressionFactor(condition, Operator.$);
	}
	@Override
	public GExpressionFactor $(GExpressionFactor condition) {
		return getCore().createExpressionFactor(condition, Operator.$);
	}
	@Override
	public GExpressionFactor NOT(String condition) {
		return getCore().createExpressionFactor(condition, Operator.NOT);
	}
	@Override
	public GExpressionFactor NOT(GExpressionFactor condition) {
		return getCore().createExpressionFactor(condition, Operator.NOT);
	}
	
	/**
	 * {@link GQueryAssistantsCore}のインスタンスを取得します.
	 * 
	 * @return {@link GQueryAssistantsCore}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	private GQueryAssistantsCore getCore() {
		return _core;
	}
	
	/**
	 * {@link GQueryAssistantsCore}のインスタンスを設定します.
	 * 
	 * @param core {@link GQueryAssistantsCore}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	void setCore(GQueryAssistantsCore core) {
		_core = core;
	}
}
