/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.sql.SQLException;
import java.sql.Statement;

/**
 * クエリ―の実行結果である{@link Statement}を操作するインタフェースです。
 * <p>
 * {@link Statement}を直接扱うための機能を提供します。<br>
 * {@link Statement}を直接扱えるため、{@link Statement}から{@link java.sql.ResultSet}を取り出して、<br>
 * {@link ResultSet}を操作することもできます。
 * 
 * @author KCCS K.Fujita
 * @create 2013/01/25
 * @since 3.12.0
 */
public interface GQueryResult {
	
	/**
	 * クエリ―の実行結果である{@link Statement}が{@link java.sql.ResultSet}を保持しているかどうか判定します。
	 * 
	 * @return {@link java.sql.ResultSet}を保持している場合は{@code true}。そうでない場合は{@code false}。
	 * @author KCCS K.Fujita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	boolean hasResultSet();
	
	/**
	 * クエリ―の実行結果である{@link Statement}を取得します。
	 * 
	 * @return 処理実行後のステートメント
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	Statement getExecutedStatement() throws SQLException;
	
	/**
	 * {@link Statement}をクローズします。
	 * <p>
	 * このメソッドを通じて{@link Statement}をクローズすることができます。
	 * 
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	void close() throws SQLException;
}