/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.sql.SQLException;
import java.sql.Statement;

/**
 * {@link GQueryResult}インターフェースの実装クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2013/01/25
 * @since 3.12.0
 */
public class GQueryResultImpl implements GQueryResult {
	
	/** 実行結果が検索結果を保持するものであればtrue／そうでなければfalse */
	private boolean hasResultSet = false;
	
	/** 処理実行後のステートメント */
	private Statement statement = null;
	
	/**
	 * {@link GQueryResultImpl}インスタンスを生成します.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	public GQueryResultImpl() {
	}
	
	/**
	 * {@link GQueryResultImpl}インスタンスを生成します.
	 * 
	 * @param hasResultSet 実行結果が検索結果を保持するかどうか
	 * @param statement 処理実行後のステートメント
	 * @author KCCS K.Fujita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	public GQueryResultImpl(boolean hasResultSet, Statement statement) {
		this.hasResultSet = hasResultSet;
		this.statement = statement;
	}
	
	@Override
	public void close() throws SQLException {
		if (statement != null && !statement.isClosed()) {
			statement.close();
		}
	}
	
	@Override
	public boolean hasResultSet() {
		return hasResultSet;
	}
	
	@Override
	public Statement getExecutedStatement() throws SQLException {
		return statement;
	}
}
