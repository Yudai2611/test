/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.util.Date;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.commons.exception.GIllegalTypeException;

/**
 * 行を表すインタフェースです。
 * <p>
 * SQL操作をする際の基本単位です。<br>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>更新、登録などで使用する値を保持する</li>
 * <li>指定されたカラムの値を返す</li>
 * <li>指定されたカラムの値を指定された型で返す</li>
 * </ol>
 * <p>
 * {@link #getObject(String)}で値を取得する場合は、エンティティー定義のColumnタグ、type属性で指定した型で値が取得できます。<br>
 * type属性で指定する値とJavaの型の対応は下記の通りです。
 * <table border="1">
 * <tr bgcolor="#cccccc"><td>type属性</td><td>Javaの型</td></tr>
 * <tr><td>VARCHAR</td><td>String</td></tr>
 * <tr><td>CHAR</td><td>String</td></tr>
 * <tr><td>LONGVARCHAR</td><td>String</td></tr>
 * <tr><td>BOOLEAN</td><td>Boolean</td></tr>
 * <tr><td>NUMERIC</td><td>BigDecimal</td></tr>
 * <tr><td>INTEGER</td><td>int</td></tr>
 * <tr><td>LONG</td><td>long</td></tr>
 * <tr><td>FLOAT</td><td>float</td></tr>
 * <tr><td>DOUBLE</td><td>double</td></tr>
 * <tr><td>BYTE</td><td>byte</td></tr>
 * <tr><td>SHORT</td><td>short</td></tr>
 * <tr><td>DATE</td><td>java.sql.Timestamp</td></tr>
 * <tr><td>TIMESTAMP</td><td>java.sql.Timestamp</td></tr>
 * <tr><td>BLOB</td><td>Blob</td></tr>
 * <tr><td>CLOB</td><td>java.sql.Clob</td></tr>
 * <tr><td>BINARY</td><td>byte[]</td></tr>
 * <tr><td>TEXT</td><td>String</td></tr>
 * </table>
 * <p>
 * 型を指定して値を取得するメソッドの場合、キャストできないと{@link GIllegalTypeException}が発生します。<br>
 * 処理に応じて適切なメソッドを使い分けてください。
 * 
 * @author KCCS hashimoto
 * @create 2012/11/16
 * @since 3.12.0
 */
public interface GRecord extends Serializable{

	/**
	 * {@link Object}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * 
	 * @param columnName カラムの論理名
	 * @return 値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	Object getObject(String columnName);

	/**
	 * {@link Boolean}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Boolean}にキャストして返却します。<br>
	 * {@link Boolean}、{@link Number}、{@link String}
	 * 
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Boolean}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	Boolean getBoolean(String columnName);

	/**
	 * {@link Byte}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Byte}にキャストして返却します。<br>
	 * {@link Number}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Byte}の値
	 * @author KCCS hashimoto
	 * @create 2012/12/14
	 * @since 3.12.0
	 */
	Byte getByte(String columnName);

	/**
	 * {@link Short}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Short}にキャストして返却します。<br>
	 * {@link Number}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Short}の値
	 * @author KCCS hashimoto
	 * @create 2012/12/14
	 * @since 3.12.0
	 */
	Short getShort(String columnName);

	/**
	 * {@link Integer}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Integer}にキャストして返却します。<br>
	 * {@link Number}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Integer}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	Integer getInteger(String columnName);

	/**
	 * {@link Long}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Long}にキャストして返却します。<br>
	 * {@link Number}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Long}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	Long getLong(String columnName);

	/**
	 * {@link Float}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Float}にキャストして返却します。<br>
	 * {@link Number}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Float}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	Float getFloat(String columnName);

	/**
	 * {@link Double}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Double}にキャストして返却します。<br>
	 * {@link Number}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Double}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	Double getDouble(String columnName);

	/**
	 * {@link BigDecimal}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link BigDecimal}にキャストして返却します。<br>
	 * {@link Number}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link BigDecimal}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	BigDecimal getBigDecimal(String columnName);

	/**
	 * {@link String}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link String}にキャストして返却します。<br>
	 * {@link String}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link String}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	String getString(String columnName);

	/**
	 * {@link Date}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Date}にキャストして返却します。<br>
	 * {@link Date}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Date}の値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	Date getDate(String columnName);

	/**
	 * {@link Blob}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link Blob}にキャストして返却します。<br>
	 * {@link Blob}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Blob}の値
	 * @author KCCS hashimoto
	 * @create 2012/12/14
	 * @since 3.12.0
	 */
	Blob getBlob(String columnName);

	/**
	 * {@link java.sql.Clob}で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * 取得する値の型が下記である場合は、{@link java.sql.Clob}にキャストして返却します。<br>
	 * {@link java.sql.Clob}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link java.sql.Clob}の値
	 * @author KCCS hashimoto
	 * @create 2012/12/14
	 * @since 3.12.0
	 */
	Clob getClob(String columnName);
	
	/**
	 * バイト配列で値を取得します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、byte[]にキャストして返却します。<br>
	 * byte[]
	 * 
	 * @param columnName カラムの論理名
	 * @return バイト配列の値
	 * @author KCCS hashimoto
	 * @create 2012/12/14
	 * @since 3.12.0
	 */
	byte[] getBytes(String columnName);
	
	/**
	 * {@link InputStream}を取得します。
	 * <p>
	 * {@link Blob}から{@link InputStream}を取得します。<br>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link InputStream}にキャストして返却します。<br>
	 * {@link Blob}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link Blob}から取得した{@link InputStream}
	 * @author KCCS hashimoto
	 * @throws IOException ファイル操作時の例外
	 * @create 2012/12/14
	 * @since 3.12.0
	 */
	InputStream getBinaryStream(String columnName) throws IOException;

	/**
	 * {@link Reader}を取得します。
	 * <p>
	 * {@link java.sql.Clob}から{@link Reader}を取得します。<br>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 取得する値の型が下記である場合は、{@link InputStream}にキャストして返却します。<br>
	 * {@link java.sql.Clob}
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link java.sql.Clob}から取得した{@link Reader}
	 * @author KCCS hashimoto
	 * @throws IOException ファイル操作時の例外
	 * @create 2012/12/14
	 * @since 3.12.0
	 */
	Reader getCharacterReader(String columnName) throws IOException;
	
	/**
	 * カラムに値を設定します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * 
	 * @param columnName カラムの論理名
	 * @param value 設定値
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	void setObject(String columnName, Object value);
	
	/**
	 * カラムのマップを取得します。
	 * 
	 * このインスタンスが保持するカラムと値のマップを返します。
	 * 
	 * @return カラムのマップ
	 * @author KCCS hashimoto
	 * @create 2012/11/16
	 * @since 3.12.0
	 */
	GListMap<String, Object> getVariants();
}