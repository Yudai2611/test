/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Date;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.commons.collection.GListMapImpl;
import jp.co.kccs.greenearth.commons.exception.GIllegalTypeException;

/**
 * {@link GRecord}インターフェースの実装クラスです.
 * 
 * @author KCCS hashimoto
 * @create 2012/10/29
 * @since 3.12.0
 */
public class GRecordImpl implements GRecord {
	
	/** シリアルバージョンID */
	private static final long serialVersionUID = -7677588684010165357L;
	/** カラム情報と値を保持するマップ */
	private GListMap<String, Object> variants = new GListMapImpl<String, Object>();
//	private GQuery<?> query = null; // TODO
//
//	public GRecordImpl(GQuery<?> query) {
//		this.query = query;
//	}
//	
//	public GQuery<?> getQuery() {
//		return query;
//	}
//
//	public void setQuery(GQuery<?> query) {
//		this.query = query;
//	}

	@Override
	public GListMap<String, Object> getVariants() {
		return variants;
	}

	@Override
	public Object getObject(String columnName) {
		return variants.get(columnName);
	}

	@Override
	public void setObject(String columnName, Object value) {
		variants.put(columnName, value);
	}

	@Override
	public Boolean getBoolean(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Boolean) {
			return (Boolean) value;
		} else if (value instanceof Number) {
			Number num = (Number) value;
			return num.byteValue() == 0 ? false : true;
		} else if (value instanceof String) {
			String str = (String) value;
			return str.equals("0") ? false : true;
		} else {
			throw new GIllegalTypeException("This value cannot be cast to Boolean. :" + value);
		}
	}

	@Override
	public Byte getByte(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Byte) {
			return (Byte) value;
		}

		try {
			Number num = (Number) value;
			return num.byteValue();
		} catch (ClassCastException e) {
			throw new GIllegalTypeException("This value cannot be cast to Byte. :" + value);
		}

	}

	@Override
	public Short getShort(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Short) {
			return (Short) value;
		}

		try {
			Number num = (Number) value;
			return num.shortValue();
		} catch (ClassCastException e) {
			throw new GIllegalTypeException("This value cannot be cast to Short. :" + value);
		}
	}

	@Override
	public Integer getInteger(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Integer) {
			return (Integer) value;
		}

		try {
			Number num = (Number) value;
			return Integer.valueOf(num.intValue());
		} catch (ClassCastException e) {
			throw new GIllegalTypeException("This value cannot be cast to Integer. :" + value);
		}
	}

	@Override
	public Long getLong(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Long) {
			return (Long) value;
		}

		try {
			Number num = (Number) value;
			return num.longValue();
		} catch (ClassCastException e) {
			throw new GIllegalTypeException("This value cannot be cast to Long. :" + value);
		}
	}

	@Override
	public Float getFloat(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Float) {
			return (Float) value;
		}

		try {
			Number num = (Number) value;
			return num.floatValue();
		} catch (ClassCastException e) {
			throw new GIllegalTypeException("This value cannot be cast to Float. :" + value);
		}
	}

	@Override
	public Double getDouble(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Double) {
			return (Double) value;
		}

		try {
			Number num = (Number) value;
			return num.doubleValue();
		} catch (ClassCastException e) {
			throw new GIllegalTypeException("This value cannot be cast to Double. :" + value);
		}
	}

	@Override
	public BigDecimal getBigDecimal(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof BigDecimal) {
			return (BigDecimal) value;
		} else if (value instanceof Integer || value instanceof Long || value instanceof Short || value instanceof Byte) {
			long num = ((Number) value).longValue();
			return BigDecimal.valueOf(num);
		} else if (value instanceof Double || value instanceof Float) {
			double num = ((Number) value).doubleValue();
			return BigDecimal.valueOf(num);
		} else {
			throw new GIllegalTypeException("This value cannot be cast to BigDecimal. :" + value);
		}
	}

	@Override
	public String getString(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			return (String) value;
		} else {
			throw new GIllegalTypeException("This value cannot be cast to String. :" + value);
		}
	}

	@Override
	public Date getDate(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Date) {
			return (Date) value;
		} else {
			throw new GIllegalTypeException("This value cannot be cast to Date. :" + value);
		}
	}

	@Override
	public Blob getBlob(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Blob) {
			return (Blob) value;
		} else {
			throw new GIllegalTypeException("This value cannot be cast to Blob. :" + value);
		}
	}

	@Override
	public Clob getClob(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Clob) {
			return (Clob) value;
		} else {
			throw new GIllegalTypeException("This value cannot be cast to Clob. :" + value);
		}
	}

	@Override
	public InputStream getBinaryStream(String columnName) throws IOException {

		// 値を取得
		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Blob) {
			try {
				return ((Blob) value).getBinaryStream();
			} catch (SQLException e) {
				throw new IOException("BLOB access failed.", e);
			}
		} else {
			throw new GIllegalTypeException("This value cannot be cast to InputStream. :" + value);
		}
	}

	@Override
	public Reader getCharacterReader(String columnName) throws IOException {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof Clob) {
			try {
				return ((Clob) value).getCharacterStream();
			} catch (SQLException e) {
				throw new IOException("CLOB access failed.", e);
			}
		} else {
			throw new GIllegalTypeException("This value cannot be cast to Reader. :" + value);
		}
	}

	@Override
	public byte[] getBytes(String columnName) {

		Object value = variants.get(columnName);

		if (value == null) {
			return null;
		}

		if (value instanceof byte[]) {
			return (byte[]) value;
		} else {
			throw new GIllegalTypeException("This value cannot be cast to byte[]. :" + value);
		}
	}
}
