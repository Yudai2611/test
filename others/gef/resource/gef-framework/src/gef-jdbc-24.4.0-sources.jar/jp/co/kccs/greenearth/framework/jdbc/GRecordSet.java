/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 結果セットを操作するインタフェースです。
 * <p>
 * 結果セット（{@link java.sql.ResultSet}）をラップしています。<br>
 * 結果セットから直接{@link GRecord}を取得することができます。<br>
 * {@link java.sql.ResultSet}から1件づつ検索結果を取得できるため、メモリへの負担を軽減することができます。<br>
 * 処理後は必ず{@link #close()}を呼ぶ必要があります。
 * 
 * @author KCCS kitamura
 * @create 2012/11/08
 * @since 3.12.0
 */
public interface GRecordSet extends AutoCloseable {

	/**
	 * 結果セットより行を読み込みます。
	 * 
	 * @return 行が読み込めた場合は{@code true}。そうでない場合は{@code false}。
	 * @throws SQLException レコード読み込み時の例外
	 * @author KCCS kitamura
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	boolean next() throws SQLException;

	/**
	 * 結果セットより読み込んだ行を{@link GRecord}に変換して取得します。
	 * <p>
	 * {@link #next()}で行を読み込んでからこのメソッドを使用します。
	 * 
	 * @return {@link GRecord}に変換した検索結果行
	 * @throws SQLException レコード読み込み時の例外
	 * @author KCCS kitamura
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	GRecord getRecord() throws SQLException;

	/**
	 * 結果セットを取得します.
	 * 
	 * @create 2023/10/25
	 * @return
	 * @author yamashita
	 * @since 23.10.0
	 */
	ResultSet getResultSet();

	/**
	 * 結果セットをクローズします。
	 * 
	 * @throws SQLException クローズ実行時の例外
	 * @author KCCS kitamura
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	void close() throws SQLException;

	/**
	 * 結果セットがクローズされているか判定します。
	 * 
	 * @return クローズされている場合は{@code true}。そうでない場合は{@code false}。
	 * @throws SQLException 判定時の例外
	 * @author KCCS kitamura
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	boolean isClosed() throws SQLException;
}