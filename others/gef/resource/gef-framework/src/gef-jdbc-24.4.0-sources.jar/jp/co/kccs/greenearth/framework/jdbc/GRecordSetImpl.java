/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.jdbc.sql.GResultSetHandler;

/**
 * {@link GRecordSet}インターフェースの実装クラスです.
 *
 * @author KCCS hashimoto
 * @create 2012/12/17
 * @since 3.12.0
 */
public class GRecordSetImpl implements GRecordSet {

	/** 結果セット */
	private ResultSet resultSet = null;
	/** 結果セットハンドラー */
	private GResultSetHandler resultSetHandler = null;
	/** クエリ */
	private GQuery<?> query = null;
	/** レコード */
	private GRecord currentRecord = null;
	
	/**
	 * {@link GRecordSetImpl}のインスタンスを生成します.
	 * 
	 * @param query クエリ
	 * @param resultSetHandler 結果セットハンドラー
	 * @param resultSet 結果セット
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public GRecordSetImpl(GQuery<?> query, GResultSetHandler resultSetHandler, ResultSet resultSet) {
		this.query = query;
		this.resultSetHandler = resultSetHandler;
		this.resultSet = resultSet;
	}

	/**
	 * 結果セットを取得します.
	 * 
	 * @return 結果セット
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	@Override
	public ResultSet getResultSet() {
		return resultSet;
	}

	/**
	 * 結果セットを設定します.
	 * 
	 * @param resultSet 結果セット
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public void setResultSet(ResultSet resultSet) {
		this.resultSet = resultSet;
	}

	@Override
	public void close() throws SQLException {
		getResultSet().close();
	}

	@Override
	public boolean next() throws SQLException {
		boolean next = getResultSet().next();
		if (next) {
			currentRecord = resultSetHandler.createRecord(query, getResultSet());
		}
		return next;
	}

	@Override
	public GRecord getRecord() throws SQLException {
		return currentRecord;
	}

	@Override
	public boolean isClosed() throws SQLException {
		return getResultSet().isClosed();
	}

	@Override
	protected void finalize() throws Throwable {
		close();
		super.finalize();
	}
}