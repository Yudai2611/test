/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


/**
 * 置換対象となりうる文字列／ファイルで表現される式を表すクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public abstract class GReplaceExpression implements GExpression {

    /** 配列パラメータのリスト */
	protected List<Object[]> arrayParamsList = null;
    /** マップパラメータのリスト */
	protected List<Map<String, Object>> mapParamsList = null;
    /** サブクエリのリスト */
	protected List<GSelect<?>> subQueryList = new ArrayList<GSelect<?>>();

	/**
	 * 配列パラメータのリストを取得します.
	 * 
	 * @return 配列パラメータのリスト
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public List<Object[]> getArrayParamsList() {
		return arrayParamsList;
	}

	/**
	 * 配列パラメータをリストに設定します.<br/>
	 * 引数の配列パラメータがnullまたは要素数が0の場合はインスタンスの配列パラメータのリストをnullに設定し、
	 * 1つ以上の要素を持つ場合は配列パラメータリストの唯一の要素として設定します.<br/>
	 * 
	 * @param arrayParams 配列パラメータ
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setArrayParams(Object[] arrayParams) {
		if (arrayParams == null) {
			this.arrayParamsList = null;
		} else {
			List<Object[]> list = new LinkedList<Object[]>();
			list.add(arrayParams);
			this.arrayParamsList = list;
		}
	}

	/**
	 * 配列パラメータのリストを設定します.
	 * 
	 * @param arrayParamsList マップパラメータのリスト
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setArrayParamsList(List<Object[]> arrayParamsList) {
		this.arrayParamsList = arrayParamsList;
	}

	/**
	 * マップパラメータをリストに設定します.
	 * 引数のマップパラメータがnullまたは要素数が0の場合はインスタンスのマップパラメータのリストをnullに設定し、
	 * 1つ以上の要素を持つ場合はマップパラメータリストの唯一の要素として設定します.<br/>
	 * 
	 * @param mapParams マップパラメータのリスト
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setMapParams(Map<String, Object> mapParams) {
		if (mapParams == null || mapParams.size() == 0) {
			this.mapParamsList = null;
		} else {
			List<Map<String, Object>> list = new LinkedList<Map<String, Object>>();
			list.add(mapParams);
			this.mapParamsList = list;
		}
	}

	/**
	 *サブクエリのリストを設定します.
	 * 
	 * @param subQueryList サブクエリのリスト
     * @author KCCS K.Fujita
     * @create 2012/12/05
     * @since 3.12.0
	 */
	public void setSubQueryList(List<GSelect<?>> subQueryList) {
		this.subQueryList = subQueryList;
	}

	/**
	 * サブクエリのリストを取得します.
	 * 
	 * @return サブクエリのリスト
     * @author KCCS K.Fujita
     * @create 2012/12/05
     * @since 3.12.0
	 */
	public List<GSelect<?>> getSubQueryList() {
		return this.subQueryList;
	}

    /**
     * マップパラメータのリストを取得します.
     * 
     * @return マップパラメータのリスト
     * @author KCCS K.Fujita
     * @create 2012/12/05
     * @since 3.12.0
     */
	public List<Map<String, Object>> getMapParamsList() {
		return mapParamsList;
	}


    /**
     * マップパラメータのリストを設定します.
     * 
     * @param mapParamsList マップパラメータのリスト
     * @author KCCS K.Fujita
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setMapParamsList(List<Map<String, Object>> mapParamsList) {
		this.mapParamsList = mapParamsList;
	}
}
