/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * SELECT文を実行するインタフェースです。
 * <p>
 * このインタフェースは、SELECT文を構築して実行する／SELECT文をそのまま実行する、に関わらず、
 * SELECT文を実行するためのメソッドを提供します。<br>
 * また、SELECT文の実行結果を様々な種類の型で取得するためのメソッドも提供します。
 * <p>
 * 主に以下の機能を提供します。
 * <ol type="1">
 * <li>SELECT文を実行し、検索結果を{@link GRecord}で取得する</li>
 * <li>SELECT文を実行し、検索結果を{@link GRecord}のリストで取得する</li>
 * <li>SELECT文を実行し、検索結果を{@link ResultSet}で取得する</li>
 * <li>SELECT文を実行し、検索結果を{@link GRecordSet}で取得する</li>
 * <li>SELECT文を実行し、検索結果件数を取得する</li>
 * </ol>
 * 
 * @param <S> SELECT文を実行するクラス
 * @author KCCS hashimoto
 * @create 2012/12/17
 * @since 3.12.0
 */
public interface GSelect<S extends GSelect<S>> extends GQuery<S> {
	
	/**
	 * SELECT文を実行し、検索結果を{@link GRecord}で取得します。
	 * <p>
	 * 検索結果を1件の{@link GRecord}で取得したい場合にこのメソッドを使用します。<br>
	 * 検索結果が複数行である場合は1行目を{@link GRecord}にして返します（抽出順はDBに依存するため、必要であればOrderByを併用してください）。<br>
	 * 検索結果が0件の場合はNULLを返します。
	 * 
	 * @return 検索結果
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public GRecord findRecord() throws SQLException;
	
	/**
	 * SELECT文を実行し、検索結果を{@link GRecord}で取得します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <p>
	 * 検索結果を1件の{@link GRecord}で取得したい場合にこのメソッドを使用します。<br>
	 * 検索結果が複数行である場合は1行目を{@link GRecord}にして返します（抽出順はDBに依存するため、必要であればOrderByを併用してください）。<br>
	 * 検索結果が0件の場合はNULLを返します。
	 * 
	 * @param connection コネクション
	 * @return 検索結果
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public GRecord findRecord(Connection connection) throws SQLException;
	
	/**
	 * SELECT文を実行し、検索結果を{@link GRecord}のリストで取得します。
	 * <p>
	 * 検索結果を{@link GRecord}のリストで取得したい場合にこのメソッドを使用します。<br>
	 * リストに格納されている{@link GRecord}の順番はDBからの抽出順です（抽出順はDBに依存するため、必要であればOrderByを併用すること）.<br>
	 * 検索結果が0件の場合はサイズが0のリストを返します。
	 * 
	 * @return 検索結果
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/02
	 * @since 3.12.0
	 */
	List<GRecord> findList() throws SQLException;
	
	/**
	 * SELECT文を実行し、検索結果を{@link GRecord}のリストで取得します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <p>
	 * 検索結果を{@link GRecord}のリストで取得したい場合にこのメソッドを使用します。<br>
	 * リストに格納されている{@link GRecord}の順番はDBからの抽出順です（抽出順はDBに依存するため、必要であればOrderByを併用すること）.<br>
	 * 検索結果が0件の場合はサイズが0のリストを返します。
	 * 
	 * @param connection コネクション
	 * @return 検索結果
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/02
	 * @since 3.12.0
	 */
	List<GRecord> findList(Connection connection) throws SQLException;
	
	/**
	 * SELECT文を実行し、検索結果を{@link GRecordSet}で取得します。
	 * <p>
	 * 検索結果を{@link GRecordSet}で取得したい場合にこのメソッドを使用します。<br>
	 * 検索結果が0件の場合でも{@link GRecordSet}を返します。NULLにはなりません。
	 * 
	 * @return 検索結果
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/02
	 * @since 3.12.0
	 */
	GRecordSet findRecordSet() throws SQLException;
	
	/**
	 * SELECT文を実行し、検索結果を{@link GRecordSet}で取得します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <p>
	 * 検索結果を{@link GRecordSet}で取得したい場合にこのメソッドを使用します。<br>
	 * 検索結果が0件の場合でも{@link GRecordSet}を返します。NULLにはなりません。
	 * 
	 * @param connection コネクション
	 * @return 検索結果
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/02
	 * @since 3.12.0
	 */
	GRecordSet findRecordSet(Connection connection) throws SQLException;
	
	/**
	 * SELECT文を実行し、検索結果を{@link ResultSet}で取得します。
	 * <p>
	 * 検索結果を{@link ResultSet}で取得したい場合にこのメソッドを使用します。<br>
	 * {@link ResultSet}は呼び出し側で管理します。開放漏れにご注意ください。
	 * 
	 * @return 検索結果
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2013/02/08
	 * @since 3.12.0
	 */
	
	ResultSet findResultSet() throws SQLException;
	
	/**
	 * 検索結果を{@link ResultSet}で取得します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <p>
	 * 検索結果を{@link ResultSet}で取得したい場合にこのメソッドを使用します。<br>
	 * {@link ResultSet}は呼び出し側で管理します。開放漏れにご注意ください。
	 * 
	 * @param connection コネクション
	 * @return 検索結果
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2013/02/08
	 * @since 3.12.0
	 */
	ResultSet findResultSet(Connection connection) throws SQLException;
	
	/**
	 * 検索結果から範囲を指定して取得する.
	 * <p>
	 * 検索結果から行の範囲を指定して取得したい場合にこのメソッドを使用します。
	 * <p>
	 * {@link findList()}と組み合わせて使用します。<br>
	 * {@link findList()}以外と組み合わせても有効になりません。<br>
	 * 開始インデックスから取得する件数分の行を返します。<br>
	 * 抽出順はDBに依存します。必要であればOrderByを併用してください。<br>
	 * 
	 * @param startRowIndex 開始インデックス
	 * <p>
	 * 0から開始します。インデックスが検索結果の総件数より大きい場合は、得られる結果は0件になります。
	 * @param listSize 取得する件数
	 * <p>
	 * 検索結果の総件数が取得する件数に満たない場合は、検索結果をそのまま返します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/14
	 * @since 3.12.0
	 */
	S range(int startRowIndex, int listSize);
	
	/**
	 * SELECT文を構築します。
	 * 
	 * @return SQL断片
	 * @author KCCS K.Fujita
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	GSQLPiece createSelectStatement();
	
	/**
	 * 結果セットから{@link GRecord}を生成します。
	 * 
	 * @param resultSet 結果セット
	 * @return 結果セットから生成した{@link GRecord}
	 * @throws SQLException {@link GRecord}作成時の例外
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	GRecord createRecord(ResultSet resultSet) throws SQLException;

	/**
	 * 結果セットから{@link GRecord}のリストを生成します。
	 * <p>
	 * 結果セットから取得する行の範囲を指定して{@link GRecord}のリストを生成します。
	 * 
	 * @param resultSet 結果セット
	 * @param startRowIndex リストの作成を開始する結果セットの行数
	 * @param listSize 作成するリストのサイズ（取得する結果セットの行数）
	 * @return 結果セットから作成した{@link GRecord}のリスト
	 * @throws SQLException {@link GRecord}のリスト作成時の例外
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	List<GRecord> createRecordList(ResultSet resultSet, int startRowIndex, int listSize) throws SQLException;
	
	/**
	 * 結果セットから{@link GRecord}のリストを生成します。
	 * <p>
	 * 結果セットから取得する行の範囲を指定して{@link GRecord}のリストを生成します。
	 * 
	 * @param resultSet 結果セット
	 * @return 結果セットから作成した{@link GRecord}のリスト
	 * @throws SQLException {@link GRecord}のリスト作成時の例外
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 3.12.0
	 */
	List<GRecord> createRecordList(ResultSet resultSet) throws SQLException;

	/**
	 * 結果セットから{@link GRecordSet}を作成します。
	 * 
	 * @param resultSet 結果セット
	 * @return 結果セットから作成した{@link GRecordSet}
	 * @throws SQLException {@link GRecordSet}作成時の例外
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	GRecordSet createRecordSet(ResultSet resultSet) throws SQLException;
	
	/**
	 * 範囲指定の開始インデックスを取得します。
	 * <p>
	 * デフォルト値は0です。
	 *
	 * @return 開始インデックス
	 * @author KCCS K.Fujita
	 * @create 2012/10/14
	 * @since 3.12.0
	 */
	int getStartRowIndex();

	/**
	 * 検索結果の件数を取得します。
	 * <p>
	 * デフォルト値は-1です。
	 * 
	 * @return 検索結果の件数
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	int getListSize();

	/**
	 * SQLを実行し検索結果の件数を取得します。
	 * <p>
	 * COUNT(*)を使用したSELECT文を実行し、検索結果として返される行数を取得します。
	 *
	 * @return 検索結果の件数
	 * @throws SQLException SQL実行時の例外
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	int count() throws SQLException;

	/**
	 * SQLを実行し検索結果の件数を取得します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <p>
	 * COUNT(*)を使用したSELECT文を実行し、検索件数を取得します。
	 *
	 * @param connection コネクション
	 * @return 検索結果の件数
	 * @throws SQLException SQL実行時の例外
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	int count(Connection connection) throws SQLException;
}
