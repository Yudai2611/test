/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc;



/**
 * 文字列で表現される式を表すクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GStringExpression extends GReplaceExpression {

    /** ソース */
	private String source = null;

    /**
     * {@link GStringExpression}を初期化します.
     * 
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GStringExpression() {
	}


    /**
     * ソースを取得します.
     * 
     * @return ソース
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public String getSource() {
		return this.source;
	}


    /**
     * ソースを設定します.
     * 
     * @param source ソース
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setSource(String source) {
		this.source = source;
	}
	
}