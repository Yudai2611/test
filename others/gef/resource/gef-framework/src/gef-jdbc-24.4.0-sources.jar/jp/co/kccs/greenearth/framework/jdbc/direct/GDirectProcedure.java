/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;

/**
 * ストアドプロシージャ／ファンクションを実行するインタフェースです。
 * <p>
 * ストアドプロシージャ／ファンクションの実行機能とそれを補助する機能を提供します。<br>
 * また、様々な形式で戻り値を取得するための機能も提供します。<br>
 * 実行するストアドプロシージャ／ファンクションを指定するための機能はスーパーインタフェース{@link GDirectQuery}が提供します。
 * <p>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>ストアドプロシージャ／ファンクションを実行する</li>
 * <li>ストアドプロシージャ／ファンクションを実行して戻り値を取得する</li>
 * </ol>
 * <p>
 * 代表的な使用方法を下記に示します。 <br>
 * <br>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">ストアドプロシージャ／ファンクションを実行する</td></tr>
 * <tr>
 * <td><pre>
 * int count = procedure().sql("{call procedure()}").execute();
 * </pre></td>
 * <td><b>call</b> procedure();</td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">ストアドプロシージャ／ファンクションを実行し、戻り値を取得する</td></tr>
 * <tr>
 * <td><pre>
 * GBindParam returnPrm = new GBindParam(ParamMode.OUT, VARCHAR);
 * GBindParam outPrm = new GBindParam(ParamMode.OUT, VARCHAR);
 * GBindParam inoutPrm = new GBindParam(ParamMode.INOUT, 100, NUMERIC);
 * 
 * Object data = procedure().sql(exp("{? = call function(?, ?, ?)}", 
 * 			new Object[]{returnPrm, prm("15", VARCHAR), outPrm, inoutPrm}))
 * 			.executeData();
 * </code></td>
 * <td>null = <b>call</b> function(15, null, 100);</td>
 * </tr>
 * </table>
 * 
 * @author KCCS K.Fujita
 * @create 2012/12/25
 * @since 3.12.0
 */
public interface GDirectProcedure extends GDirectQuery<GDirectProcedure> {
	
	/**
	 * ストアドプロシージャ／ファンクションを実行し、更新された行数を返します。
	 * <p>
	 * 戻り値を返さないストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * 
	 * @return 更新された行数
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	int execute() throws SQLException;
	
	/**
	 * ストアドプロシージャ／ファンクションを実行し、更新された行数を返します。
	 * <p>
	 * 戻り値を返さないストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * <p>
	 * 引数の{@link Connection}は呼び出し側で管理してください。
	 * 
	 * @param connection コネクション
	 * @return 更新された行数
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	int execute(Connection connection) throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値を返します。
	 * <p>
	 * 戻り値を返すストアドプロシージャ／ファンクションの実行に使用して下さい。<br>
	 * 戻り値の型を指定したい場合、{@link GDirectProcedure#returnType(GColumnType)}を使用して下さい。<br>
	 * 
	 * @param <T> 戻り値の型
	 * @return ストアドファンクションの戻り値
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	<T> T executeData() throws SQLException;
	
	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値を返します。
	 * <p>
	 * 戻り値を返すストアドプロシージャ／ファンクションの実行に使用して下さい。<br>
	 * 戻り値の型を指定したい場合、{@link GDirectProcedure#returnType(GColumnType)}を使用して下さい。<br>
	 * <p>
	 * 引数の{@link Connection}は呼び出し側で管理してください。
	 * 
	 * @param <T> 戻り値の型
	 * @param connection コネクション
	 * @return ストアドファンクションの戻り値
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	<T> T executeData(Connection connection) throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として結果セットを返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * 
	 * @return 結果セット
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	ResultSet executeResultSet() throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として結果セットを返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * <p>
	 * 引数の{@link Connection}は呼び出し側で管理してください。
	 * 
	 * @param connection コネクション
	 * @return 結果セット
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	ResultSet executeResultSet(Connection connection) throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として{@link GRecordSet}を返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * 
	 * @return 検索結果（{@link GRecordSet}）
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	GRecordSet executeRecordSet() throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として{@link GRecordSet}を返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * <p>
	 * 引数の{@link Connection}は呼び出し側で管理してください。
	 * 
	 * @param connection コネクション
	 * @return 検索結果（{@link GRecordSet}）
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	GRecordSet executeRecordSet(Connection connection) throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として{@link GRecord}のリストを返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * 
	 * @return 検索結果（{@link GRecord}のリスト）
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	List<GRecord> executeList() throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として{@link GRecord}のリストを返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * <p>
	 * 引数の{@link Connection}は呼び出し側で管理してください。
	 * 
	 * @param connection コネクション
	 * @return 検索結果（{@link GRecord}のリスト）
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	List<GRecord> executeList(Connection connection) throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として1件の{@link GRecord}を返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * 
	 * @return 検索結果1件（{@link GRecord}）
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	GRecord executeRecord() throws SQLException;

	/**
	 * ストアドプロシージャ／ファンクションを実行し、その戻り値として1件の{@link GRecord}を返します。
	 * <p>
	 * 戻り値として検索結果を返すストアドプロシージャ／ファンクションの実行に使用して下さい。
	 * <p>
	 * 引数の{@link Connection}は呼び出し側で管理してください。
	 * 
	 * @param connection コネクション
	 * @return 検索結果1件（{@link GRecord}）
	 * @throws SQLException SQL例外
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	GRecord executeRecord(Connection connection) throws SQLException;
	
	/**
	 * ストアドプロシージャ／ファンクションの戻り値の型を指定します。
	 * <p>
	 * 必要であればメソッドチェーンで使用します。<br>
	 * {@link GColumnType}の定数で戻り値の型を指定します。<br>
	 * {@link GDirectProcedure#executeData()}または{@link GDirectProcedure#executeData(Connection)}と併せて使用して下さい．<br>
	 * このメソッドで戻り値の型を指定しなくても戻り値を取得することはできます。<br>
	 * <p>
	 * @param returnValueType 戻り値の型
	 * @return 戻り値が設定された{@link GDirectProcedure}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2013/03/04
	 * @since 3.12.0
	 */
	GDirectProcedure returnType(GColumnType returnValueType);
	
	/**
	 * 検索結果から範囲を指定して取得します。
	 * <p>
	 * {@link GDirectProcedure#executeList()}または{@link GDirectProcedure#executeList(Connection)}と併せて使用して下さい。<br>
	 * 抽出順はDBに依存します。<br>
	 * 開始インデックスの開始値は0です。
	 * 
	 * @param startRowIndex 検索結果の開始インデックス
	 * @param listSize 取得する検索結果の件数
	 * @return 範囲が指定されたこのインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	GDirectProcedure range(int startRowIndex, int listSize);
	
	//--------------------------resultSet---------------------------------
	
	/**
	 * 結果セットから{@link GRecord}を作成します。
	 * 
	 * @param resultSet 元となる結果セット
	 * @return 結果セットから作成した{@link GRecord}のインスタンス
	 * @throws SQLException {@link GRecord}作成時のSQL例外
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	GRecord createRecord(ResultSet resultSet) throws SQLException;
	
	/**
	 * 結果セットから{@link GRecord}のリストを作成します。
	 * 
	 * @param resultSet 元となる結果セット
	 * @param startRowIndex リストの作成を開始する結果セットの行数
	 * @param listSize 作成するリストのサイズ（取得する結果セットの行数）
	 * @return 結果セットから作成した{@link GRecord}のリスト
	 * @throws SQLException {@link GRecord}のリスト作成時のSQL例外
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	List<GRecord> createRecordList(ResultSet resultSet, int startRowIndex, int listSize) throws SQLException;

	/**
	 * 結果セットから{@link GRecordSet}を作成します。
	 * 
	 * @param resultSet 元となる結果セット
	 * @return 結果セットから作成した{@link GRecordSet}
	 * @throws SQLException {@link GRecordSet}作成時のSQL例外
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	GRecordSet createRecordSet(ResultSet resultSet) throws SQLException;
	
	/**
	 * 範囲指定で検索結果を取得する場合の開始インデックスを取得します。
	 * 
	 * @return 開始インデックス
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	int getStartRowIndex();
	
	/**
	 * 範囲指定で検索結果を取得する場合の検索結果の件数を取得します。
	 * 
	 * @return 検索結果の件数
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	int getListSize();
	
	/**
	 * ストアドプロシージャ／ファンクションの戻り値の型を取得します。
	 * 
	 * @return 戻り値の型
	 * @author KCCS K.Fujita
	 * @create 2013/03/04
	 * @since 3.12.0
	 */
	GColumnType getReturnType();
}
