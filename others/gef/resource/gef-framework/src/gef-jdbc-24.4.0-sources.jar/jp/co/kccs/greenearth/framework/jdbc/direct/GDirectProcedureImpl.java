/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GDatabase;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectSQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GDirectProcedure}インターフェースの実装クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/12/25
 * @since 3.12.0
 */
public class GDirectProcedureImpl extends GDirectQueryBase<GDirectProcedure> implements GDirectProcedure {

	/** 開始インデックス(範囲指定検索) */
	private int startRowIndex = 0;
	/** 取得件数(範囲指定検索) */
	private int listSize = -1;
	/** 戻り値の型 */
	private GColumnType returnType = null;
	
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GDirectProcedureImpl() {
	}
	
	/**
	 * コンストラクタ.
	 * 
	 * @param directSqlGeneratorMap {@link GDirectSQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param directResultSetHandlerMap {@link GDirectResultSetHandler}のマップ
	 * @param database データベース情報
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GDirectProcedureImpl(Map<String, GDirectSQLGenerator> directSqlGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GDirectResultSetHandler> directResultSetHandlerMap, GDatabase database) {
		super(directSqlGeneratorMap, sqlExecuterMap, directResultSetHandlerMap, database);
	}
	
	@Override
	public void clear() {
		startRowIndex = 0;
		listSize = -1;
		returnType = null;
	}

	@Override
	public int getStartRowIndex() {
		return startRowIndex;
	}

	@Override
	public int getListSize() {
		return listSize;
	}

	@Override
	public GDirectProcedure range(int startRowIndex, int listSize) {
		this.startRowIndex = startRowIndex;
		this.listSize = listSize;
		return this;
	}

	@Override
	public GDirectProcedure returnType(GColumnType returnType) {
		this.returnType = returnType;
		return this;
	}
	
	@Override
	public GColumnType getReturnType() {
		return this.returnType;
	}

	@Override
	public int execute() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return execute(connection);
		}
		finally {
			releaseConnection(connection);
		}
	}

	@Override
	public int execute(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
		return getSqlExecuter().callUpdate(connection, piece, getQueryTimeout());
	}

	@Override
	public <T> T executeData() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return executeData(connection);
		}
		finally {
			releaseConnection(connection);
		}
	}

	@Override
	public <T> T executeData(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
		return getSqlExecuter().callData(connection, piece, returnType, getQueryTimeout());
	}

	@Override
	public ResultSet executeResultSet() throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		try {
			connection = catchConnection();
			GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
			resultSet = getSqlExecuter().callQuery(connection, piece, getQueryTimeout());
			return enhanceResultSet(resultSet, connection);
		}
		catch (SQLException e) {
			close(resultSet);
			releaseConnection(connection);
			throw e;
		}
		catch (RuntimeException e) {
			close(resultSet);
			releaseConnection(connection);
			throw e;
		}
	}

	@Override
	public ResultSet executeResultSet(Connection connection) throws SQLException {
		ResultSet resultSet = null;
		try {
			GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
			resultSet = getSqlExecuter().callQuery(connection, piece, getQueryTimeout());
			return enhanceResultSet(resultSet, null);
		} catch (SQLException e) {
			close(resultSet);
			throw e;
		} catch (RuntimeException e) {
			close(resultSet);
			throw e;
		}
	}

	@Override
	public GRecordSet executeRecordSet() throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		GRecordSet recordset = null;
		try {
			connection = catchConnection();
			GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
			resultSet = getSqlExecuter().callQuery(connection, piece, getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, connection);
			recordset = createRecordSet(resultSet);
			return recordset;
		} catch (SQLException e) {
			close(resultSet, recordset);
			releaseConnection(connection);
			throw e;
		} catch (RuntimeException e) {
			close(resultSet, recordset);
			releaseConnection(connection);
			throw e;
		}
	}

	@Override
	public GRecordSet executeRecordSet(Connection connection) throws SQLException {
		ResultSet resultSet = null;
		GRecordSet recordset = null;
		try {
			GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
			resultSet = getSqlExecuter().callQuery(connection, piece, getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, null);
			recordset = createRecordSet(resultSet);
			return recordset;
		} catch (SQLException e) {
			close(resultSet, recordset);
			throw e;
		} catch (RuntimeException e) {
			close(resultSet, recordset);
			throw e;
		}
	}

	@Override
	public List<GRecord> executeList() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return executeList(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public List<GRecord> executeList(Connection connection) throws SQLException {
		// 開始行インデックスとリストサイズのチェック
		checkParam(startRowIndex, listSize);
		
		ResultSet resultSet = null;
		try {
			GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
			resultSet = getSqlExecuter().callQuery(connection, piece, getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, null);
			return createRecordList(resultSet, startRowIndex, listSize);
		} finally {
			close(resultSet);
		}
	}

	@Override
	public GRecord executeRecord() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return executeRecord(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public GRecord executeRecord(Connection connection) throws SQLException {
		ResultSet resultSet = null;
		try {
			GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
			resultSet = getSqlExecuter().callQuery(connection, piece, getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, null);
			
			// 結果が複数件得られても最初の1件のみ返す
			if (resultSet.next()) {
				return createRecord(resultSet);
			}
			return null;
		} finally {
			close(resultSet);
		}
	}

	@Override
	public GQueryResult nativeCall() throws SQLException {
		Connection connection = null;
		GQueryResult result = null;
		try {
			connection = catchConnection();
			result = nativeCall(connection);
			return enhanceQueryResult(result, connection);
		} catch (SQLException e) {
			close(result, connection);
			throw e;
		} catch (RuntimeException e) {
			close(result, connection);
			throw e;
		}
	}
	
	@Override
	public GQueryResult nativeCall(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createProcedureStatement(this);
		return getSqlExecuter().call(connection, piece, getQueryTimeout());
	}
	
	@Override
	public GRecord createRecord(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecord(this, resultSet);
	}

	@Override
	public List<GRecord> createRecordList(ResultSet resultSet, int startRowIndex, int listSize) throws SQLException {
		return getResultSetHandler().createRecordList(this, resultSet, startRowIndex, listSize);
	}

	@Override
	public GRecordSet createRecordSet(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecordSet(this, resultSet);
	}
}
