/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import jp.co.kccs.greenearth.framework.jdbc.GDatabase;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;

/**
 * SQL文の直接実行でSQL文を指定する機能を表すインタフェースです。
 * <p>
 * 実行するSQL文を指定する機能を提供します。<br>
 * またその他共通の補助機能を提供します。<br>
 * 指定したSQL文は{@link GSelect}、{@link GDirectProcedure}、{@link GDirectProcedure}のメソッドを使用します。
 * 
 * @param <S> SQL直接実行を表すインタフェース
 * @author KCCS hashimoto
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GDirectQuery<S extends GDirectQuery<S>> extends GQuery<S> {

	/**
	 * SQL文とバインドする値を指定します。
	 *
	 * @param sql SQL文
	 * <p>
	 * 値をバインドする場所は「?」で指定します。
	 * <pre>"UPDATE ItemMaster SET code = ? WHERE item = ?"</pre>
	 * @param bindParams バインドする値
	 * <p>
	 * Object[]の要素数はSQL文の「?」の個数と合わせてください。
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	S sql(String sql, Object... bindParams);

	/**
	 * 変換式で表されたSQL文を指定します。
	 *
	 * @param exp 変換式で表されたSQL文
	 * <p>
	 * {@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#expMap(String, java.util.Map)}などで生成します。
	 * <pre>exp("UPDATE ItemMaster SET code = :code WHERE item = :item", map)</pre>
	 * 
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	S sql(GExpression exp);

	/**
	 * 変換式で表されたSQL文を取得します。
	 * <p>
	 * デフォルト値はnullです。
	 *
	 * @return 変換式で表されたSQL文
	 * @author KCCS hashimoto
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	GExpression getSqlExpression();

	/**
	 * 実行するSQL文を取得します。
	 * <p>
	 * デフォルト値はnullです。
	 *
	 * @return SQL文
	 * @author KCCS hashimoto
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	String getSql();

	/**
	 * バインドする値を取得します。
	 * 
	 * SQL文を実行する際にバインドする値を取得します。<br>
	 * デフォルト値はnullです。
	 *
	 * @return バインドパラメータ
	 * @author KCCS hashimoto
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	Object[] getBindParameter();

	/**
	 * データベース接続情報を取得します。
	 * <p>
	 * データベース接続情報とは、DB接続先、スキーマ、ユーザ、パスワードです。<br>
	 * デフォルト値はエンティティー定義ファイルのdatabaseの値をキーとして<br>
	 * DIコンテナから取得したDB接続先、スキーマ、ユーザ、パスワードです。
	 * 
	 * @return database データベース接続情報
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	GDatabase getDatabase();

	/**
	 * 初期化します。
	 * <p>
	 * このインスタンス自身を初期化します。
	 * 
	 * @author KCCS kitamura
	 * @create 2013/04/17
	 * @since 3.12.0
	 */
	void init();
}
