/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.framework.jdbc.GDatabase;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQueryBase;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectSQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;

/**
 * {@link GDirectQuery}インターフェースを実装する基底クラスです.
 * 
 * @param <S> SQL直接実行を表すインターフェース
 * @author KCCS hashimoto
 * @create 2012/10/29
 * @since 3.12.0
 */
public abstract class GDirectQueryBase<S extends GDirectQuery<S>> extends GQueryBase<S> implements GDirectQuery<S> {

	/** SQL文 */
	protected String sql = null;
	/** バインドパラメータ */
	private Object[] bindParams = null;
	/** {@link GExpression}のインスタンス */
	private GExpression sqlExpression = null;
	/** {@link GDirectSQLGenerator}のマップ */
	private Map<String, GDirectSQLGenerator> directSqlGeneratorMap;
	/** {@link GDirectResultSetHandler}のマップ */
	private Map<String, GDirectResultSetHandler> directResultSetHandlerMap;
	
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GDirectQueryBase() {
	}

	/**
	 * コンストラクタ.
	 * 
	 * @param directSqlGeneratorMap {@link GDirectSQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param directResultSetHandlerMap {@link GDirectResultSetHandler}のマップ
	 * @param database データベース情報
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GDirectQueryBase(Map<String, GDirectSQLGenerator> directSqlGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GDirectResultSetHandler> directResultSetHandlerMap, GDatabase database) {
		super(sqlExecuterMap);
		this.directSqlGeneratorMap = directSqlGeneratorMap;
		this.directResultSetHandlerMap = directResultSetHandlerMap;
		setDatabase(database);
	}

	/**
	 * {@link GDirectSQLGenerator}のインスタンスを取得します.
	 * 
	 * @return {@link GDirectSQLGenerator}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GDirectSQLGenerator getSqlGenerator() {
		return directSqlGeneratorMap.get(getDatabase().getDbType());
	}

	/**
	 * {@link GResultSetHandler}のインスタンスを取得します.
	 * 
	 * @return {@link GResultSetHandler}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GResultSetHandler getResultSetHandler() {
		return directResultSetHandlerMap.get(getDatabase().getDbType());
	}
	
	/**
	 * 初期化します。
	 */
	@Override
	public void init() {
		// NOTE エンティティのデータベースタイプにより異なる実装を取得する必要がある
	}

	/**
	 * インスタンスを破棄します。
	 */
	@Override
	public void clear() {
		sql = null;
		bindParams = null;
		sqlExpression = null;
	}

	@Override
	public S sql(String sql, Object... bindParams) {
		this.sql = sql;
		this.bindParams = bindParams;

		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}

	@Override
	public S sql(GExpression exp) {
		this.sqlExpression = exp;

		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}

	@Override
	public GExpression getSqlExpression() {
		return sqlExpression;
	}

	@Override
	public String getSql() {
		return sql;
	}

	@Override
	public Object[] getBindParameter() {
		return bindParams;
	}

	/**
	 * コネクションを取得します.
	 * 
	 * @return コネクション
	 * @throws SQLException コネクションの取得に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected Connection catchConnection() throws SQLException {
		GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
		return dataSource.open(getDatabase().getDataSource());
	}

	/**
	 * コネクションを取得します.
	 * 
	 * @param dataSourceName データソース名
	 * @return コネクション
	 * @throws SQLException コネクションの取得に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected Connection catchConnection(String dataSourceName) throws SQLException {
		GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
		return dataSource.open(dataSourceName);
	}
	
	/**
	 * コネクションを解放します.
	 * 
	 * @param connection 解放するコネクション
	 * @throws SQLException 解放に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void releaseConnection(Connection connection) throws SQLException {
		GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
		dataSource.close(connection);
	}

	/**
	 * ステートメントをクローズします.
	 * 
	 * @param statement クローズするステートメント
	 * @throws SQLException クローズに失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void close(Statement statement) throws SQLException {
		if (statement != null && !statement.isClosed()) {
			statement.close();
		}
	}

	/**
	 * ステートメントと結果セットを解放します.
	 * 
	 * @param statement ステートメント
	 * @param resultSet 結果セット
	 * @throws SQLException リソースの解放に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void close(Statement statement, ResultSet resultSet) throws SQLException {
		try {
			close(resultSet);
		} finally {
			close(statement);
		}
	}

	/**
	 * 結果セットとレコードセットを解放します.
	 * 
	 * @param resultSet 解放する結果セット
	 * @param recordset 解放するレコードセット
	 * @throws SQLException リソースの解放に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void close(ResultSet resultSet, GRecordSet recordset) throws SQLException {
		try {
			close(recordset);
		} finally {
			close(resultSet);
		}
	}

	/**
	 * 結果セットを解放します.
	 * 
	 * @param resultSet 解放する結果セット
	 * @throws SQLException 結果セットの解放に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void close(ResultSet resultSet) throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
	}

	/**
	 * レコードセットを解放します.
	 * 
	 * @param recordSet 解放するレコードセット
	 * @throws SQLException レコードセットの解放に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void close(GRecordSet recordSet) throws SQLException {
		if (recordSet != null) {
			recordSet.close();
		}
	}

	/**
	 * 引数の整合性をチェックします.
	 * 
	 * @param startRowIndex 読み込み開始行
	 * @param listSize リストのサイズ
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void checkParam(int startRowIndex, int listSize) {
		if (startRowIndex < 0) {
			throw new IllegalArgumentException("This start index is invalid. :" + startRowIndex);
		}
		if (listSize < -1) {
			throw new IllegalArgumentException("This list size is invalid. :" + listSize);
		}
	}
}
