/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * SQL直接実行用クラスを取得する機能を提供するクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/28
 * @since 3.12.0
 */
public class GDirectQueryFactory {

	/**
	 * SQL直接実行用クラスを取得します.
	 * 
	 * @param <T> 各種SQL直接実行用クラス
	 * @param clazz 各種SQL直接実行用クラス
	 * @return SQL直接実行用クラスのインスタンス
	 * @author KCCS kitamura
	 * @create 2012/12/28
	 * @since 3.12.0
	 */
	public static <T extends GDirectQuery< ? >> T getQuery(Class<T> clazz) {
		T query = GFrameworkUtils.getComponent(clazz.getName());
		query.init();
		return query;
	}

	/**
	 * SQL直接実行用クラスを取得します.
	 * 
	 * @param <T> 各種SQL直接実行用クラス
	 * @param componentName コンポーネント名
	 * @return SQL直接実行用クラスのインスタンス
	 * @author KCCS kitamura
	 * @create 2012/12/28
	 * @since 3.12.0
	 */
	public static <T extends GDirectQuery< ? >> T getQuery(String componentName) {
		T query = GFrameworkUtils.getComponent(componentName);
		query.init();
		return query;
	}
}
