/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import jp.co.kccs.greenearth.framework.jdbc.GSelect;


/**
 * SELECT文を直接実行するためのインタフェースです。
 * <p>
 * このインタフェース独自のメソッドはありませんが、「流れるようなインタフェース」を実現するために必要なインタフェースです。<br>
 * 
 * 実行するSQL文を指定するための機能はスーパーインタフェース{@link GDirectQuery}が提供します。
 * 指定したSQL文はスーパーインタフェースの{@link GSelect}のメソッドを使用して実行します。
 * <p>
 * 代表的な使用方法を下記に示します。
 * <p>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">SELECT文をそのまま実行する</td></tr>
 * <tr>
 * <td>
 * <pre>
 * List&ltGRecord&gt recordList = 
 * 	selectSql()
 * 		.sql("SELECT columnA FROM ItemMaster WHERE code = ?", "15")
 * 		.findList();</pre>
 * </td>
 * <td><pre> <b>SELECT</b> columnA 
 *   <b>FROM</b> ItemMaster 
 *  <b>WHERE</b> code = '15';</pre></td>
 * </tr>
 * </table>
 * <p>
 * @author KCCS kitamura
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GDirectSelect extends GSelect<GDirectSelect>, GDirectQuery<GDirectSelect>  {
}
