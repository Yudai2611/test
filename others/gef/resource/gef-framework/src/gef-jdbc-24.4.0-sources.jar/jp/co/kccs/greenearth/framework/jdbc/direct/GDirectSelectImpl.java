/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GDatabase;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectSQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GDirectSelect}インターフェースを実装するクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/25
 * @since 3.12.0
 */
public class GDirectSelectImpl extends GDirectQueryBase<GDirectSelect> implements GDirectSelect {

	/** 範囲指定検索(開始インデックス) */
	private int startRowIndex = 0;
	/** 範囲指定検索(取得件数) */
	private int listSize = -1;
	
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GDirectSelectImpl() {
	}

	/**
	 * {@link GDirectSelectImpl}のインスタンスを取得します.
	 * 
	 * @param directSqlGeneratorMap {@link GDirectSQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param directResultSetHandlerMap {@link GDirectResultSetHandler}のマップ
	 * @param database データベース情報
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public GDirectSelectImpl(Map<String, GDirectSQLGenerator> directSqlGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GDirectResultSetHandler> directResultSetHandlerMap, GDatabase database) {
		super(directSqlGeneratorMap, sqlExecuterMap, directResultSetHandlerMap, database);
	}
	
	@Override
	public void clear() {
		startRowIndex = 0;
		listSize = -1;
	}

	@Override
	public ResultSet findResultSet() throws SQLException {
		
		Connection connection = null;
		ResultSet resultset = null;
		try {
			connection = catchConnection();
			GSQLPiece piece = createSelectStatement();
			resultset = this.executeQuery(connection, piece);
			// 結果セットのプロキシ生成
			return enhanceResultSet(resultset, connection);
		} catch (SQLException e) {
			close(resultset);
			releaseConnection(connection);
			throw e;
		} catch (RuntimeException e) {
			close(resultset);
			releaseConnection(connection);
			throw e;
		}
	}

	@Override
	public ResultSet findResultSet(Connection connection) throws SQLException {
		ResultSet resultset = null;
		try {
			GSQLPiece piece = createSelectStatement();
			resultset = this.executeQuery(connection, piece);
			// 結果セットのプロキシ生成
			return enhanceResultSet(resultset, null);
		} catch (SQLException e) {
			close(resultset);
			throw e;
		} catch (RuntimeException e) {
			close(resultset);
			throw e;
		}
	}

	@Override
	public GRecord findRecord() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return this.findRecord(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public GRecord findRecord(Connection connection) throws SQLException {
		ResultSet resultset = null;
		try {
			resultset = this.executeQuery(connection, createSelectStatement());
			resultset = enhanceResultSet(resultset, null);

			// 結果が複数件得られても最初の1件のみ返す
			if (resultset.next()) {
				return createRecord(resultset);
			}
			return null;
		} finally {
			close(resultset);
		}
	}

	@Override
	public List<GRecord> findList() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return this.findList(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public List<GRecord> findList(Connection connection) throws SQLException {

		ResultSet resultset = null;
		try {
			resultset = executeQuery(connection, createSelectStatement());
			resultset = enhanceResultSet(resultset, null);
			return createRecordList(resultset);
		} finally {
			close(resultset);
		}
	}

	@Override
	public GRecordSet findRecordSet() throws SQLException {

		Connection connection = null;
		ResultSet resultSet = null;
		GRecordSet recordset = null;
		try {
			connection = catchConnection();
			resultSet = executeQuery(connection, createSelectStatement());
			resultSet = enhanceResultSet(resultSet, connection);
			return createRecordSet(resultSet);
		} catch (SQLException e) {
			close(resultSet, recordset);
			releaseConnection(connection);
			throw e;
		} catch (RuntimeException e) {
			close(resultSet, recordset);
			releaseConnection(connection);
			throw e;
		}
	}

	@Override
	public GRecordSet findRecordSet(Connection connection) throws SQLException {

		ResultSet resultSet = null;
		GRecordSet recordset = null;
		try {
			resultSet = executeQuery(connection, createSelectStatement());
			resultSet = enhanceResultSet(resultSet, null);
			return createRecordSet(resultSet);
		} catch (SQLException e) {
			close(resultSet, recordset);
			throw e;
		} catch (RuntimeException e) {
			close(resultSet, recordset);
			throw e;
		}
	}
	
	@Override
	public GSQLPiece createSelectStatement() {
		return getSqlGenerator().createSelectStatement(this);
	}

	/**
	 * SQLを実行し結果セットを取得します.
	 * 
	 * @param connection コネクション
	 * @param piece 実行SQL文及びバインドパラメータが設定された{@link GSQLPiece}のインスタンス
	 * @return ResultSet
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	//TODO メソッド名を整理
	protected ResultSet executeQuery(Connection connection, GSQLPiece piece) throws SQLException {
		ResultSet resultset = null;
		try {
			return getSqlExecuter().executeQuery(connection, piece, getQueryTimeout());
		} catch (SQLException e) {
			close(resultset);
			throw e;
		} catch (RuntimeException e) {
			close(resultset);
			throw e;
		}
	}

	@Override
	public GQueryResult nativeCall() throws SQLException {

		Connection connection = null;
		GQueryResult result = null;
		try {
			connection = catchConnection();
			result = nativeCall(connection);
			return enhanceQueryResult(result, connection);
		} catch (SQLException e) {
			close(result, connection);
			throw e;
		} catch (RuntimeException e) {
			close(result, connection);
			throw e;
		}
	}

	@Override
	public GQueryResult nativeCall(Connection connection) throws SQLException {
		return getSqlExecuter().execute(connection, createSelectStatement(), getQueryTimeout());
	}

	// TODO : ユーテリティ化すべき
	/**
	 * 結果セットとレコードセットをクローズします.
	 * 
	 * @param resultSet 結果セット
	 * @param recordset レコードセット
	 * @throws SQLException クローズ時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/4
	 * @since 3.12.0
	 */
	protected void close(ResultSet resultSet, GRecordSet recordset) throws SQLException {
		try {
			close(recordset);
		} finally {
			close(resultSet);
		}
	}

	/**
	 * ステートメントと結果セットをクローズします.
	 * 
	 * @param statement ステートメント
	 * @param resultSet 結果セット
	 * @throws SQLException クローズ時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/4
	 * @since 3.12.0
	 */
	protected void close(Statement statement, ResultSet resultSet) throws SQLException {
		try {
			close(resultSet);
		} finally {
			close(statement);
		}
	}

	/**
	 * 結果セットをクローズします.
	 * 
	 * @param resultSet 結果セット
	 * @throws SQLException クローズ時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/4
	 * @since 3.12.0
	 */
	protected void close(ResultSet resultSet) throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
	}

	/**
	 * レコードセットをクローズします.
	 * 
	 * @param recordSet レコードセット
	 * @throws SQLException クローズ時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/4
	 * @since 3.12.0
	 */
	protected void close(GRecordSet recordSet) throws SQLException {
		if (recordSet != null) {
			recordSet.close();
		}
	}

	@Override
	public int getStartRowIndex() {
		return startRowIndex;
	}

	/**
	 * 検索結果の開始インデックスを設定します。
	 * 
	 * @param startRowIndex 開始インデックス
	 * @author KCCS K.Fujita
	 * @create 2012/10/14
	 * @since 3.12.0
	 */
	public void setStartRowIndex(int startRowIndex) {
		this.startRowIndex = startRowIndex;
	}

	@Override
	public int getListSize() {
		return listSize;
	}

	/**
	 * リストのサイズを設定します。
	 * 
	 * @param listSize リストのサイズ
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	public void setListSize(int listSize) {
		this.listSize = listSize;
	}

	@Override
	public GDirectSelect range(int startRowIndex, int listSize) {
		this.startRowIndex = startRowIndex;
		this.listSize = listSize;
		return this;
	}

	@Override
	public GRecord createRecord(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecord(this, resultSet);
	}

	@Override
	public List<GRecord> createRecordList(ResultSet resultSet, int startRowIndex, int listSize) throws SQLException {
		return getResultSetHandler().createRecordList(this, resultSet, startRowIndex, listSize);
	}
	
	@Override
	public List<GRecord> createRecordList(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecordList(this, resultSet);
	}

	@Override
	public GRecordSet createRecordSet(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecordSet(this, resultSet);
	}
	
	@Override
	public int count() throws SQLException {

		Connection connection = null;
		try {
			connection = catchConnection();
			return count(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public int count(Connection connection) throws SQLException {

		ResultSet resultset = null;
		try {
			resultset = executeQuery(connection, getSqlGenerator().createCountStatement(this));
			resultset = enhanceResultSet(resultset, null);
			if (resultset.next()) {
				return resultset.getInt(1);
			} else {
				return 0;
			}
		} finally {
			close(resultset);
		}
	}

}
