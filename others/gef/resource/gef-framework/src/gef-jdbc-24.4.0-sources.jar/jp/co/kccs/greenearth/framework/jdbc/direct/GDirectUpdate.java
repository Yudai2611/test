/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * INSERT文、UPDATE文、DELETE文を直接実行するインタフェースです。
 * <p>
 * SQL文の実行機能とそれを補助する機能を提供します。<br>
 * 実行するSQL文を指定するための機能はスーパーインタフェース{@link GDirectQuery}が提供します。
 * <p>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>1件のSQLを実行する</li>
 * <li>複数件のSQLを実行する</li>
 * </ol>
 * <p>
 * 代表的な使用方法を下記に示します。
 * <p>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">1件のSQLを実行する</td></tr>
 * <tr>
 * <td>
 * <pre>
 * int result = 
 * 	updateSql()
 * 		.sql("UPDATE ItemMaster SET code = ? WHERE item = ?", "15", "value"))
 * 		.execute();</pre>
 * </td>
 * <td><pre> <b>UPDATE</b> ItemMaster 
 *   <b>SET code = '15'
 *  <b>WHERE</b> item = 'value';</pre></td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">複数件のSQLを実行する</td></tr>
 * <tr>
 * <td>
 * <pre>
 * int result = 
 * 	updateSql()
 * 		.sql("UPDATE ItemMaster SET code = ? WHERE item = ?", valueList))
 * 		.executeBatch();</pre>
 * </td>
 * <td><pre> <b>UPDATE</b> ItemMaster 
 *   <b>SET code = '15'
 *  <b>WHERE</b> item = 'value1';
 * <b>UPDATE</b> ItemMaster 
 *   <b>SET code = '16'
 *  <b>WHERE</b> item = 'value2';
 *  ・・・</pre></td>
 * </tr>
 * </table>
 * <p>
 * @author KCCS kitamura
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GDirectUpdate extends GDirectQuery<GDirectUpdate> {
	
	/**
	 * SQL文とバインドする値を指定します。
	 * <p>
	 * 複数件のSQLを実行したい場合にこのメソッドを使用します。<br>
	 * 1つのSQL文に対して、異なる値をバインドして実行することができます。<br>
	 * {@link #executeBatch()}または{@link #executeBatch(Connection)}と組み合わせて使用してください。
	 * 
	 * @param sql SQL文
	 * <p>
	 * 値をバインドする場所は「?」で指定します。<br>
	 * "UPDATE ItemMaster SET code = ? WHERE item = ?"
	 * @param bindParams バインドする値
	 * <p>
	 * Object[]の要素数はSQL文の「?」の個数と合わせてください。
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	GDirectUpdate sql(String sql, List<Object[]> bindParams);
	
	/**
	 * 1件のSQLを実行します。
	 * 
	 * @return 処理件数
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	int execute() throws SQLException;
	
	/**
	 * 1件のSQLを実行します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * 
	 * @param connection コネクション
	 * @return 処理件数
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	int execute(Connection connection) throws SQLException;

	/**
	 * 複数件のSQLをバッチ実行します。
	 * <p>
	 * 途中でエラーが発生した場合はその時点で例外をスローし、後続の操作は実行しません。<br>
	 * 正常に終了した操作までコミットします。<br>
	 * <p>
	 * {@link #batchSize(int)}でバッチサイズを指定してください。<br>
	 * バッチサイズの指定を省略した場合、全件を一括で実行します。<br>
	 * 
	 * @return トータル処理件数
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	int executeBatch() throws SQLException;

	/**
	 * 複数件のSQLをバッチ実行します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <P>
	 * 途中でエラーが発生した場合はその時点で例外をスローし、後続の操作は実行しません.<br>
	 * 正常に終了した操作までコミットします。
	 * <p>
	 * {@link #batchSize(int)}でバッチサイズを指定してください。<br>
	 * ※バッチサイズの指定を省略した場合、全件を一括で実行します。<br>
	 * 
	 * @param connection コネクション
	 * @return トータル処理件数
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	int executeBatch(Connection connection) throws SQLException;
	
	/**
	 * バインドする値を取得します。
	 * 
	 * {@link #sql(String, List)}で設定したバインドする値を取得します。<br>
	 * デフォルト値はnullです。
	 * 
	 * @return バインドする値のリスト
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	List<Object[]> getBindParameterList();
	
	/**
	 * バッチサイズを指定します。
	 * <p>
	 * バッチ実行で使用するバッチサイズを指定します。<br>
	 * 100件のSQL操作でバッチサイズを20とした場合、20件毎にまとめて実行するため、DBアクセス回数は5回です。<br>
	 * <br>
	 * 指定したバッチサイズの件数分、実行するSQLをメモリ上に保持します。
	 * 処理件数とメモリ容量の兼ね合いにより、{@link java.lang.OutOfMemoryError}が発生する可能性がありますので、<br>
	 * メモリ容量に合わせた値を指定してください。<br>
	 * 指定を省略した場合のデフォルト値は0であり、全件を一括で実行します。<br>
	 * 
	 * @param batchSize バッチサイズ
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	GDirectUpdate batchSize(int batchSize);
}
