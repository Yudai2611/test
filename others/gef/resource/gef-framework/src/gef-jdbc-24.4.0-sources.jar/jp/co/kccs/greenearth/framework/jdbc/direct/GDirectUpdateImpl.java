/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.framework.jdbc.GDatabase;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.direct.sql.GDirectSQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GDirectUpdate}インターフェースの実装クラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/27
 * @since 3.12.0
 */
public class GDirectUpdateImpl extends GDirectQueryBase<GDirectUpdate> implements GDirectUpdate {

	/** バッチサイズ */
	private int batchSize = 0;
	/** バインドパラメータのリスト */
	private List<Object[]> bindParamsList = null;
	
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GDirectUpdateImpl() {
	}

	/**
	 * コンストラクタ.
	 * 
	 * @param directSqlGeneratorMap {@link GDirectSQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param directResultSetHandlerMap {@link GDirectResultSetHandler}のマップ
	 * @param database データベース情報
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GDirectUpdateImpl(Map<String, GDirectSQLGenerator> directSqlGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GDirectResultSetHandler> directResultSetHandlerMap, GDatabase database) {
		super(directSqlGeneratorMap, sqlExecuterMap, directResultSetHandlerMap, database);
	}
	
	@Override
	public void clear() {
		batchSize = 0;
		bindParamsList = null;
	}

	@Override
	public GDirectUpdate batchSize(int batchSize) {
		this.batchSize = batchSize;
		return this;
	}

	@Override
	public GDirectUpdate sql(String sql, List<Object[]> bindParams) {
		this.sql = sql;
		this.bindParamsList = bindParams;
		return this;
	}

	@Override
	public List<Object[]> getBindParameterList() {
		return bindParamsList;
	}

	/**
	 * GConnectionManagerを返します。
	 * 
	 * @return GConnectionManager
	 */
	protected GConnectionManager getConnectionManager() {
		return GConnectionManager.getInstance();
	}

	/**
	 * execute.
	 * <br />
	 * このメソッドは、{@link #execute(Connection)}をラップして、コネクション取得とトランザクション制御を行っている。
	 * @see #execute(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int execute() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return this.execute(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public int execute(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createUpdateStatement(this);
		return getSqlExecuter().executeUpdate(connection, piece, getQueryTimeout());
	}

	/**
	 * executeBatch.
	 * <br />
	 * このメソッドは、{@link #executeBatch(Connection)}をラップしてコネクション取得とトランザクション制御を行っている。
	 * 
	 * @see #executeBatch(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int executeBatch() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection();
			return this.executeBatch(connection);
		} catch (RuntimeException e) {
			throw e;
		} catch (SQLException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public int executeBatch(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createBatchUpdateStatement(this);
		return getSqlExecuter().executeBatchUpdate(connection, piece, batchSize, getQueryTimeout());
	}

	/**
	 * nativeCall.
	 * <br />
	 * このメソッドは、{@link #nativeCall(Connection)}をラップして、コネクション取得とトランザクション制御を行っている。
	 * 
	 * @see #nativeCall(Connection)
	 * @return {@link GQueryResult}のインスタンス
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public GQueryResult nativeCall() throws SQLException {
		Connection connection = null;
		GQueryResult result = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			result = nativeCall(connection);
			return enhanceQueryResult(result, connection);
		} catch (RuntimeException e) {
			try {
				close(result);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		} catch (SQLException e) {
			try {
				close(result);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		}
	}

	@Override
	public GQueryResult nativeCall(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createUpdateStatement(this);
		return getSqlExecuter().execute(connection, piece, getQueryTimeout());
	}
	
}
