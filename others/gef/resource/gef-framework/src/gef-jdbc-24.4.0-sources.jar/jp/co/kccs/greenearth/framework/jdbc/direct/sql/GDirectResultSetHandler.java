/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordImpl;
import jp.co.kccs.greenearth.framework.jdbc.sql.GResultSetHandlerBase;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * SQL直接実行で取得した結果セットを操作する際に処理を振り分ける機能を提供するクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/07
 * @since 3.12.0
 */
public class GDirectResultSetHandler extends GResultSetHandlerBase {

	/**
	 * {@link GDirectResultSetHandler}のインスタンスを生成します.
	 * 
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/12/07
	 * @since 3.12.0
	 */
	public GDirectResultSetHandler(GSQLTypeHandler handler) {
		setTypeHandler(handler);
	}

	@Override
	public GRecord createRecord(GQuery<?> query, ResultSet resultSet) throws SQLException {
		if (resultSet == null) {
			return null;
		}

		GRecord record = new GRecordImpl();

		ResultSetMetaData metaData = resultSet.getMetaData();
		int columnCount = metaData.getColumnCount();
		for (int i = 0; i < columnCount; i++) {
			int colIndex = i + 1;
			String key = metaData.getColumnLabel(colIndex);

			// 取得項目の値がnullの場合はnullを設定する
			if (resultSet.getObject(colIndex) == null) {
				record.setObject(key, null);
				continue;
			}
			record.setObject(key, getTypeHandler().getValue(resultSet, colIndex, null));
		}

		return record;
	}
}
