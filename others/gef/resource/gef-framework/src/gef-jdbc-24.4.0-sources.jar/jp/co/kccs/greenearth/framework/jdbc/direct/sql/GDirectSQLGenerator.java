/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectProcedure;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectSelect;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectUpdate;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * SQL直接実行用SQLを生成するインタフェースです。
 *
 * @author KCCS kitamura
 * @create 2012/12/09
 * @since 3.12.0
 */
public interface GDirectSQLGenerator {
	
	/**
	 * 検索SQLを生成します。
	 * 
	 * @param select SQL構築のための要素
	 * @return SQL断片
	 * @author KCCS hashimoto
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	GSQLPiece createSelectStatement(GDirectSelect select);
	
	/**
	 * 更新系SQL（更新、登録、削除）を生成します。
	 * 
	 * @param update SQL構築のための要素
	 * @return SQL断片
	 * @author KCCS hashimoto
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	GSQLPiece createUpdateStatement(GDirectUpdate update);
	
	/**
	 * 一括実行用更新系SQL（更新、登録、削除）を生成します。
	 * 
	 * @param update SQL構築のための要素
	 * @return SQL断片
	 * @author KCCS hashimoto
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	GSQLPiece createBatchUpdateStatement(GDirectUpdate update);
	
	/**
	 * ストアドプロシージャ／ファンクション呼び出しを生成します。
	 * 
	 * @param procedure 呼び出し構築のための要素
	 * @return SQL断片
	 * @author KCCS hashimoto
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	GSQLPiece createProcedureStatement(GDirectProcedure procedure);

	/**
	 * 検索結果の件数を取得するSQLを生成します。
	 *
	 * @param select 検索用エンティティー
	 * @return SQL断片
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	GSQLPiece createCountStatement(GDirectSelect select);
}
