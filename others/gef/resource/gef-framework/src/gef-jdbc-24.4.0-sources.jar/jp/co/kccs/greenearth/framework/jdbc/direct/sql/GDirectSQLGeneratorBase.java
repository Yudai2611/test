/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectProcedure;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectSelect;
import jp.co.kccs.greenearth.framework.jdbc.direct.GDirectUpdate;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GDirectSQLGenerator}インターフェースの実装基底クラスです.
 *
 * @author KCCS kitamura
 * @create 2012/12/09
 * @since 3.12.0
 */
public abstract class GDirectSQLGeneratorBase implements GDirectSQLGenerator {

	/** {@link GExpressionConverter}のインスタンス */
	public GExpressionConverter expConverter = null;
	/** {@link GClauseGenerator}のインスタンス */
	public GLimitPartGenerator limitPartGenerator = null;

	/**
	  * {@link GDirectSQLGeneratorBase}のインスタンスを生成します.
	  * 
	  * @param expConverter {@link GExpressionConverter}のインスタンス
	  * @param limitPartGenerator {@link GLimitPartGenerator}のインスタンス
	  * @author KCCS hashimoto
	  * @create 2012/12/04
	  * @since 3.12.0
	  */
	public GDirectSQLGeneratorBase(GExpressionConverter expConverter, GLimitPartGenerator limitPartGenerator) {
		this.expConverter = expConverter;
		this.limitPartGenerator = limitPartGenerator;
	}
	
	@Override
	public GSQLPiece createSelectStatement(GDirectSelect select) {
        GSQLPiece sqlPiece = null;
		if (select.getSql() != null) {
		    sqlPiece = new GSQLPiece(select.getSql(), GBindParam.toBindParams(select.getBindParameter()));
		}
		else {
			GExpression exp = select.getSqlExpression();
			sqlPiece = expConverter.convertExpression(select, exp);
		}
		
		GSQLPiece limitPiece = limitPartGenerator.createLimitClause(select);
		sqlPiece.appendSql(limitPiece.getSql());
		
		// 管理ＩＤ付与
        return decolateManagementID(sqlPiece, select.getManagementID());
	}
	
	@Override
	public GSQLPiece createUpdateStatement(GDirectUpdate update) {
        GSQLPiece sqlPiece = null;
		if (update.getSql() != null) {
		    sqlPiece = new GSQLPiece(update.getSql(), GBindParam.toBindParams(update.getBindParameter()));
		}
		else {
			GExpression exp = update.getSqlExpression();
			sqlPiece =  expConverter.convertExpression(update, exp);
		}

        // 管理ＩＤ付与
        return decolateManagementID(sqlPiece, update.getManagementID());
	}
	
	@Override
	public GSQLPiece createBatchUpdateStatement(GDirectUpdate update) {
        GSQLPiece sqlPiece = null;
		if (update.getSql() != null) {
		    sqlPiece = new GSQLPiece(update.getSql(), GBindParam.toBindParamsList(update.getBindParameterList()));
		}
		else {
			GExpression exp = update.getSqlExpression();
			sqlPiece = expConverter.convertBatchExpression(update, exp);
		}

		// 管理ＩＤ付与
		return decolateManagementID(sqlPiece, update.getManagementID());
	}

	@Override
	public GSQLPiece createProcedureStatement(GDirectProcedure procedure) {
		GSQLPiece sqlPiece = null;
		if (procedure.getSql() != null) {
			sqlPiece = new GSQLPiece(procedure.getSql(), GBindParam.toBindParams(procedure.getBindParameter()));
		}
		else {
			GExpression exp = procedure.getSqlExpression();
			sqlPiece = expConverter.convertExpression(procedure, exp);
		}

		// 管理ＩＤ付与
		return decolateProcedureManagementID(sqlPiece, procedure.getManagementID());
	}

	@Override
	public GSQLPiece createCountStatement(GDirectSelect select) {

		GSQLPiece sqlpiece = createSelectStatement(select);

		// SQL断片から取得したSQL文を「SELECT COUNT(*) (...) COUNT_LIST」に囲まれる
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT COUNT(*) ").append("FROM ").append("( ");
		sqlBuilder.append(sqlpiece.getSql()).append(" ");
		sqlBuilder.append(" ) ").append("COUNT_LIST ");

		// 件数取得のSQLをSQL断片に設定
		sqlpiece.setSql(sqlBuilder.toString());
		return sqlpiece;
	}

	/**
	 * 管理ＩＤを付与します.
	 * 
	 * @param piece 管理ＩＤを付与するSQL
	 * @param managementID 管理ＩＤ
	 * @return 管理IDが装飾されたSQL
	 * @author KCCS hashimoto
	 * @create 2013/02/06
	 * @since 3.12.0
	 */
	protected GSQLPiece decolateManagementID(GSQLPiece piece, String managementID) {
		if (piece != null && piece.getSql() != null && managementID != null) {
			String sql = piece.getSql();
			sql = sql + " /* " + managementID + " */"; 
			piece.setSql(sql);
        }
		return piece;
	}

	/**
	 * ストアドプロシージャ／ファンクションを実行し、管理ＩＤを付与します.
	 *
	 * @param piece  管理ＩＤを付与するSQL
	 * @param managementID 管理ＩＤ
	 * @return 管理IDが装飾されたSQL
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	protected abstract GSQLPiece decolateProcedureManagementID(GSQLPiece piece, String managementID);
}
