/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;

/**
 * {@link GDirectSQLGeneratorMySQLBase}をMySQL8.0用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GDirectSQLGeneratorMySQL8_0 extends GDirectSQLGeneratorMySQLBase {

	/**
	 * {@link GDirectSQLGeneratorMySQL8_0}のインスタンスを生成します.
	 *
	 * @param expConverter       {@link GExpressionConverter}のインスタンス
	 * @param limitPartGenerator {@link GLimitPartGenerator}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GDirectSQLGeneratorMySQL8_0(GExpressionConverter expConverter, GLimitPartGenerator limitPartGenerator) {
		super(expConverter, limitPartGenerator);
	}
}
