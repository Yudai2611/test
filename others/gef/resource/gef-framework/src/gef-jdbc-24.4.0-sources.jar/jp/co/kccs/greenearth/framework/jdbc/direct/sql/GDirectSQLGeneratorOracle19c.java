/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;

/**
 * {@link GDirectSQLGeneratorOracleBase}をOracle19c用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GDirectSQLGeneratorOracle19c extends GDirectSQLGeneratorOracleBase {

	/**
	 * {@link GDirectSQLGeneratorOracle19c}のインスタンスを生成します.
	 *
	 * @param expConverter       {@link GExpressionConverter}のインスタンス
	 * @param limitPartGenerator {@link GLimitPartGenerator}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GDirectSQLGeneratorOracle19c(GExpressionConverter expConverter, GLimitPartGenerator limitPartGenerator) {
		super(expConverter, limitPartGenerator);
	}
}
