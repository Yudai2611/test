/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GDirectSQLGeneratorBase}をOracle用に基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public abstract class GDirectSQLGeneratorOracleBase extends GDirectSQLGeneratorBase {

	/**
	 * {@link GDirectSQLGeneratorOracleBase}のインスタンスを生成します.
	 *
	 * @param expConverter       {@link GExpressionConverter}のインスタンス
	 * @param limitPartGenerator {@link GLimitPartGenerator}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GDirectSQLGeneratorOracleBase(GExpressionConverter expConverter, GLimitPartGenerator limitPartGenerator) {
		super(expConverter, limitPartGenerator);
	}

	/**
	 * ストアドプロシージャ／ファンクションを実行し、管理ＩＤを付与します.
	 * 
	 * @param piece 管理ＩＤを付与するSQL
	 * @param managementID 管理ＩＤ
	 * @return 管理IDが装飾されたSQL
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	protected GSQLPiece decolateProcedureManagementID(GSQLPiece piece, String managementID) {
		return super.decolateManagementID(piece, managementID);
	}
}
