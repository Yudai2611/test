/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;

/**
 * {@link GDirectSQLGeneratorBase}をPostgreSQL13.2用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GDirectSQLGeneratorPostgreSQL13_2 extends GDirectSQLGeneratorPostgreSQLBase {

	/**
	 * {@link GDirectSQLGeneratorPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @param expConverter       {@link GExpressionConverter}のインスタンス
	 * @param limitPartGenerator {@link GLimitPartGenerator}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GDirectSQLGeneratorPostgreSQL13_2(GExpressionConverter expConverter, GLimitPartGenerator limitPartGenerator) {
		super(expConverter, limitPartGenerator);
	}
}
