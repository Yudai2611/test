/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.direct.sql;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;

/**
 * カラムのタイプにより処理を振り分ける機能を提供するクラスです.
 * 
 * @author KCCS kitamura
 * @create 2013/01/09
 * @since 3.12.0
 */
public class GDirectTypeHandler {

	/**
	 * 結果セットより指定のカラムの値を取得します.
	 * 
	 * @param resultSet 結果セット
	 * @param key 取得するカラムの名前
	 * @param type カラムのタイプ
	 * @return 結果セットから取得した値
	 * @throws SQLException 値の取得に失敗した場合
	 * @author KCCS kitamura
	 * @create 2013/01/09
	 * @since 3.12.0
	 */
	public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
		return null;
	}

	/**
	 * ストアドファンクション、ストアドプロシージャの実行結果を取得します.
	 * 
	 * @param cs {@link CallableStatement}のインスタンス
	 * @param index インデックス
	 * @param param バインドパラメータ
	 * @return 実行結果の値
	 * @throws SQLException 値の取得に失敗した場合
	 * @author KCCS kitamura
	 * @create 2013/01/09
	 * @since 3.12.0
	 */
	public Object getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
		return null;
	}

	/**
	 * {@link PreparedStatement}にパラメータをバインドします.
	 * 
	 * @param ps 値のバインド先となる{@link PreparedStatement}のインスタンス
	 * @param index バインドする項目のインデックス
	 * @param param バインドする値
	 * @throws SQLException パラメータのバインドに失敗した場合
	 * @author KCCS kitamura
	 * @create 2013/01/09
	 * @since 3.12.0
	 */
	public void bindValue(PreparedStatement ps, int index, GBindParam param) throws SQLException {
	}

	/**
	 * {@link CallableStatement}にパラメータをバインドします.
	 * 
	 * @param cs 値のバインド先となる{@link CallableStatement}のインスタンス
	 * @param index バインドする項目のインデックス
	 * @param param バインドする値
	 * @throws SQLException パラメータのバインドに失敗した場合
	 * @author KCCS kitamura
	 * @create 2013/01/09
	 * @since 3.12.0
	 */
	public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
	}

}
