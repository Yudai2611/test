/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;


/**
 * INSERT文、UPDATE文、DELETE文を実行するインタフェースです。
 * <p>
 * INSERT文、UPDATE文、DELETE文を実行するための機能を提供するインタフェースです。<br>
 * このインタフェースで提供しているメソッドを使用することで、{@link GEntityDelete}、{@link GEntityInsert}、{@link GEntityUpdate}で構築したSQLを実行することができます。<br>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>1件のSQLを実行する</li>
 * <li>複数件のSQLを実行する</li>
 * <li>複数件のSQLをバッチ実行する</li>
 * </ol>
 * <p>
 * 複数件のSQLを実行する方法は{@link #executeList()}、{@link #executeBatch()}の2種類あります。<br>
 * 下記の基準でどちらを使用するか選択してください。
 * <p>
 * <ul>
 * <li>{@link #executeList()}<br>
 * 1件毎にDBへアクセスしますので大量件数の場合にパフォーマンスが劣化する可能性があります。<br>
 * 1件毎に処理するため、メモリを消費しません。
 * </li>
 * <li>{@link #executeBatch()}<br>
 * 指定するバッチサイズ毎にDBへアクセスしますので、アクセス回数を調整できパフォーマンス向上が見込めます。<br>
 * ただしメモリ上にバッチサイズ分SQLを保持しますので、メモリを消費します。
 * </li>
 * </ul>
 * 
 * @param <S> SQL構築エンティティー
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
// TODO クラス名の見直し
public interface GEntityCUD<S extends GEntityCUD<S>> extends GEntityQuery<S> {
	
	/**
	 * 1件のSQLを実行します。
	 * 
	 * @return 正常に操作された行数
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	int execute() throws SQLException;
	
	/**
	 * 1件のSQLを実行します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * 
	 * @param connection コネクション
	 * @return 正常に操作された行数
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	int execute(Connection connection) throws SQLException;
	
	/**
	 * 複数件のSQLを実行します。
	 * <p>
	 * 途中でエラーが発生した場合はその時点で例外をスローし、後続の行は実行しません。<br>
	 * 処理が正常に終了した行までコミットします。
	 * 
	 * @return 正常に操作された行数
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	int executeList() throws SQLException;
	
	/**
	 * 複数件のSQLを実行します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <p>
	 * 途中でエラーが発生した場合はその時点で例外をスローし、後続の行は実行しません.<br>
	 * 処理が正常に終了した行までコミットします。
	 * 
	 * @param connection コネクション
	 * @return 正常に操作された行数
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	int executeList(Connection connection) throws SQLException;
	
	/**
	 * 複数件のSQLをバッチ実行します。
	 * <p>
	 * 途中でエラーが発生した場合はその時点で例外をスローし、後続の操作は実行しません。<br>
	 * 正常に終了した操作までコミットします。<br>
	 * <p>
	 * {@link #batchSize(int)}でバッチサイズを指定してください。<br>
	 * バッチサイズの指定を省略した場合、全件を一括で実行します。<br>
	 * 
	 * @return 正常に操作された行数
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	int executeBatch() throws SQLException;
	
	/**
	 * 複数件のSQLをバッチ実行します。
	 * <p>
	 * このメソッドは呼び出し側で管理している{@link Connection}を渡すことができます。
	 * <P>
	 * 途中でエラーが発生した場合はその時点で例外をスローし、後続の操作は実行しません.<br>
	 * 正常に終了した操作までコミットします。
	 * <p>
	 * {@link #batchSize(int)}でバッチサイズを指定してください。<br>
	 * ※バッチサイズの指定を省略した場合、全件を一括で実行します。<br>
	 * 
	 * @param connection コネクション
	 * @return 正常に操作された行数
	 * @throws SQLException SQL実行時に発生する例外
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	int executeBatch(Connection connection) throws SQLException;
	
	/**
	 * バッチサイズを指定します。
	 * <p>
	 * バッチ実行で使用するバッチサイズを指定します。<br>
	 * 100件のSQL操作でバッチサイズを20とした場合、20件毎にまとめて実行するため、DBアクセス回数は5回です。<br>
	 * <br>
	 * 指定したバッチサイズの件数分、実行するSQLをメモリ上に保持します。
	 * 処理件数とメモリ容量の兼ね合いにより、{@link java.lang.OutOfMemoryError}が発生する可能性がありますので、<br>
	 * メモリ容量に合わせた値を指定してください。<br>
	 * 指定を省略した場合のデフォルト値は0であり、全件を一括で実行します。<br>
	 * 
	 * @param batchSize バッチサイズ
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	S batchSize(int batchSize);
	
	/**
	 * 操作対象行を1行取得します。
	 * 
	 * 操作対象が1行の場合にこのメソッドを使用します。
	 * 
	 * @return 1行レコード
	 * @author KCCS hashimoto
	 * @create 2013/2/22
	 * @since 3.12.0
	 */
	GRecord getTargetRecord();
	
	/**
	 * 操作対象行のリストを取得します。
	 * 
	 * 操作対象が複数行の場合にこのメソッドを使用します。
	 * 
	 * @return 行レコードのリスト
	 * @author KCCS hashimoto
	 * @create 2013/2/22
	 * @since 3.12.0
	 */
	List<GRecord> getTargetRecordList();
}
