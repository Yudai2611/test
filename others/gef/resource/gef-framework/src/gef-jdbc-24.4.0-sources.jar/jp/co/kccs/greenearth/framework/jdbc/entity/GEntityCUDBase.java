/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.commons.collection.GListMapImpl;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GXmlDomEntityFactory;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntityResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntitySQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;

// TODO 名前の見直し
/**
 * 更新系のSQL操作機能を提供する基底クラスです.
 * 
 * @param <S> SQL操作エンティティー
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public abstract class GEntityCUDBase<S extends GEntityCUD<S>> extends GEntityQueryBase<S> implements GEntityCUD<S> {

	/** 更新対象レコード */
	private GRecord targetRecord = null;
	/** 更新対象レコードのリスト */
	private List<GRecord> targetRecordList = null;
	/** null値項目排除判定フラグ */
	private boolean excludesNullFlg = false;
	/** 排除項目名配列 */
	private String[] excludes = null;
	/** 指定項目名配列 */
	private String[] includes = null;
	/** 一括更新のサイズ */
	protected int batchSize = 0;
	/** エンティティー定義で楽観的排他が設定されているかを表す */
	private boolean isExclusiveOfEntity = false;
	/** SQL構築で楽観的排他が必要かを表す */
	private boolean needExclusiveForSQLBuild = false;

	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GEntityCUDBase() {
	}
	
	/**
	 * コンストラクタ.
	 * 
	 * @param entitySQLGeneratorMap {@link GEntitySQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param entityResultSetHandlerMap {@link GEntityResultSetHandler}のマップ
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GEntityCUDBase(Map<String, GEntitySQLGenerator> entitySQLGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GEntityResultSetHandler> entityResultSetHandlerMap) {
		super(entitySQLGeneratorMap, sqlExecuterMap, entityResultSetHandlerMap);
	}

	/**
	 * NULL項目を除外してレコードを操作するよう設定します.
	 * 
	 * @return SQL操作エンティティー
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public S excludesNull() {
		this.excludesNullFlg = true;

		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}

	/**
	 * NULL項目を除外する設定がされているか判定します.
	 * 
	 * @return 判定結果（true:設定あり／false:設定なし）
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public boolean isExcludesNull() {
		return this.excludesNullFlg;
	}

	/**
	 * 引数で指定した項目を除外してレコードを操作するよう設定します.
	 * 
	 * @param excludes レコードから除外する項目
	 * @return SQL操作エンティティー
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public S excludes(String... excludes) {
		this.excludes = excludes;

		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}

	/**
	 * レコードから除外する項目を取得します.
	 * 
	 * @return レコードから除外する項目
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public String[] getExcludes() {
		return this.excludes;
	}

	/**
	 * 引数で指定した項目のみで構成したレコードを操作するよう設定します.
	 * 
	 * @param includes レコードを構成する項目
	 * @return SQL操作エンティティー
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public S includes(String... includes) {
		this.includes = includes;

		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}

	/**
	 * レコードの内指定された項目を取得します.
	 * 
	 * @return レコードから除外する項目
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public String[] getIncludes() {
		return this.includes;
	}

	/**
	 * 楽観的排他を使用するかどうかを取得します.
	 * 
	 * @return 楽観的排他の使用（<code>true</code>:設定あり／<code>false<code>:設定なし）
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public boolean isExclusive() {
		return needExclusiveForSQLBuild() && isExclusiveOfEntity;
	}
	
	/**
	 * 楽観的排他を使用するかどうかを設定します.
	 * 
	 * @param isExclusive 楽観的排他の使用（<code>true</code>:設定する／<code>false<code>:設定しない）
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public void setExclusive(boolean isExclusive) {
		this.isExclusiveOfEntity = isExclusive;
	}

	/**
	 * 楽観的排他を使用しないよう設定します.
	 * 
	 * @return 楽観的排他を使用しないよう設定されたSQL操作エンティティ
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public S nonexclusive() {
		this.isExclusiveOfEntity = false;
		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}

	/**
	 * 更新対象となる項目を取得します.<br/>
	 * 返却する{@link GListMap}は、{@link GEntity#getColumns()}の複製（シャロウコピー）となります。<br/>
	 * ※Entityリポジトリ({@link GXmlDomEntityFactory})のキャッシュが不整合になるため、要素内の{@link GColumn}は変更してはいけません。<br/>
	 * excludesが指定された場合、excludesで指定された項目以外を複製します。<br/>
	 * includesが指定された場合、includesで指定された項目を複製します。<br/>
	 * excludesとincludesの両方を指定した場合、例外を送出します。<br/>
	 * 
	 * [補足]<br/>
	 * 排他機能が有効化されている場合、excludesまたはincludesにて排他項目を除外した場合(アプリ側で意図的に除外)でも、排他項目を自動的に追加します。<br/>
	 * 排他項目が含まれる場合、自動挿入は致しません。<br/>
	 * <br/>
	 * @return 操作対象項目のマップ
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	public GListMap<String, GColumn> getUpdateColumns() {
		if (getExcludes() != null && getIncludes() != null) {
			throw new IllegalArgumentException("Excludes and Includes are specified simultaneously.");
		}
		GListMap<String, GColumn> shallowCopy = new GListMapImpl<String, GColumn>();
		shallowCopy.putAll(getEntity().getColumns());
		if (getExcludes() != null) {
			// Columnsに影響を与えないよう別インスタンスを用意する
			GListMap<String, GColumn> copiedColumn = new GListMapImpl<String, GColumn>();
			List<String> nameList = Arrays.asList(getExcludes());

			for (Map.Entry<String, GColumn> entrySet : shallowCopy.entrySet()) {
				if (!nameList.contains(entrySet.getKey())) {
					copiedColumn.put(entrySet.getKey(), entrySet.getValue());
				}
			}
			return copiedColumn;
		} else if (getIncludes() != null) {
			// Entity内のColumnsに影響を与えないよう別インスタンスを用意する
			GListMap<String, GColumn> copiedColumn = new GListMapImpl<String, GColumn>();
			List<String> nameList = Arrays.asList(getIncludes());

			for (String includeColumnName : nameList) {
				if (shallowCopy.containsKey(includeColumnName)) {
					copiedColumn.put(includeColumnName , shallowCopy.get(includeColumnName));
				} else {
					throw new IllegalStateException("This column does not exist. :" + includeColumnName);
				}
			}
			return copiedColumn;
		}
		return shallowCopy;
	}

	/**
	 * {@inheritDoc}
	 */
	public S batchSize(int batchSize) {
		this.batchSize = batchSize;

		@SuppressWarnings("unchecked")
		S s = (S) this;
		return s;
	}
	
	@Override
	public GRecord getTargetRecord() {
		return this.targetRecord;
	}
	
	/**
	 * 更新対象を設定します.
	 * 
	 * @param record 更新対象
     * @author KCCS hashimoto
     * @create 2013/2/22
     * @since 3.12.0
	 */
	public void setTargetRecord(GRecord record) {
		this.targetRecord = record;
	}

	@Override
	public List<GRecord> getTargetRecordList() {
		return this.targetRecordList;
	}
	
	/**
	 * 更新対象のリストを設定します.
	 * 
	 * @param records 更新対象のリスト
     * @author KCCS hashimoto
     * @create 2013/2/22
     * @since 3.12.0
	 */
	public void setTargetRecordList(List<GRecord> records) {
		this.targetRecordList = records;
	}

	@Override
	public void clear() {
		excludesNullFlg = false;
		excludes = null;
		includes = null;
		batchSize = 0;
		targetRecord = null;
		targetRecordList = null;
		needExclusiveForSQLBuild = false;
		super.clear();
	}

	/**
	 * Connectionを返します。
	 * 
	 * @param dataSourceName データソース名
	 * @return Connection
	 * @throws SQLException SQL例外
	 */
	protected Connection catchConnection(String dataSourceName) throws SQLException {
		GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
		return dataSource.open(dataSourceName);
	}

	/**
	 * Connectionを切断します。
	 * 
	 * @param connection Connection
	 * @throws SQLException SQL例外
	 */
	protected void releaseConnection(Connection connection) throws SQLException {
		GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
		dataSource.close(connection);
	}
	
	/**
	 * SQL構築での楽観的排他要否を設定します.
	 * 
	 * @param need 楽観的排他要否（<code>true</code>:必要／<code>false<code>:不要）
	 * @author KCCS hashimoto
	 * @create 2015/02/13
	 * @since 3.15.0
	 */
	protected void setExclusiveForSQLBuild(boolean need) {
		this.needExclusiveForSQLBuild = need;
	}

	/**
	 * SQL構築での楽観的排他要否を取得します.
	 * 
	 * @return 楽観的排他要否（<code>true</code>:必要／<code>false<code>:不要）
	 * @author KCCS hashimoto
	 * @create 2015/02/13
	 * @since 3.15.0
	 */
	protected boolean needExclusiveForSQLBuild() {
		return needExclusiveForSQLBuild;
	}
}
