/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * DELETE文を構築するインタフェースです。
 * <p>
 * DELETE文を構築するために必要なメソッドを提供します。<br>
 * このインタフェースで提供しているメソッドを組み合わせて使用することで、直接SQLを記述することなくDELETE文を構築することができます。<br>
 * <p>
 * 主に以下の操作が実現できます。<br>
 * <ol type="1">
 * <li>主キーを検索条件に利用して1行を削除する</li>
 * <li>ユニークキーを検索条件に利用して1行を削除する</li>
 * <li>任意の検索条件で削除する</li>
 * <li>主キーまたはユニークキーを検索条件に利用して複数行を削除する</li>
 * </ol>
 * <p>
 * 構築したDELETE文はスーパーインタフェース{@link GEntityCUD}、または{@link GQuery}のメソッドを使用して実行します。<br>
 * 削除対象テーブルの定義はエンティティー定義ファイルとして作成しておく必要があります。
 * <p>
 * 代表的な使用方法を下記に示します。
 * <p>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">主キーを検索条件に利用して1行を削除する</td></tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     delete("entity")
 *         .wherePK(record)
 *         .execute();</pre>
 * </td>
 * <td><pre><b>DELETE</b> <b>FROM</b> physicalTable
 *      <b>WHERE</b> columnPK = 'value1';</pre></td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">ユニークキーを検索条件に利用して1行を削除する</td></tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     delete("entity")
 *         .whereUK("uniqueKey", record)
 *         .execute();</pre>
 * </td>
 * <td><pre><b>DELETE</b> <b>FROM</b> physicalTable
 *      <b>WHERE</b> columnUNQ = 'value1';</pre></td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">任意の検索条件で削除する</td></tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     delete("entity")
 *         .where(exp("columnA = ?", "value1"))
 *         .execute();</pre>
 * </td>
 * <td>
 * <pre><b>DELETE</b> <b>FROM</b> physicalTable
 *      <b>WHERE</b> columnA = 'value1';</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">主キーまたはユニークキーを検索条件に利用して複数行を削除する</tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     delete("entity")
 *         .wherePK(recordList)
 *         .executeList();</pre>
 * </td>
 * <td><pre> <b>DELETE</b> <b>FROM</b> physicalTable
 *       <b>WHERE</b> columnPK = 'value1';
 * <b>DELETE</b> <b>FROM</b> physicalTable
 *       <b>WHERE</b> columnPK = 'value2';
 * ・・・</pre>
 * </td>
 * </tr>
 * </table>
 * 
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public interface GEntityDelete extends GEntityCUD<GEntityDelete> {
	
	/**
	 * WHERE節を主キーを検索条件として構築します。
	 * <p>
	 * 主キーを検索条件に利用して1行を削除する場合にこのメソッドを使用します。<br>
	 * 主キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 定義されていない場合は{@link IllegalStateException}が発生します。
	 * <p>
	 * 構築したDELETE文の実行は{@link #execute()}を使用してください。
	 * 
	 * @param record 1行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityDelete wherePK(GRecord record);
	
	/**
	 * WHERE節を主キーを検索条件として構築します。
	 * <p>
	 * 主キーを検索条件に利用して複数の行を削除する場合にこのメソッドを使用します。<br>
	 * 主キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 定義されていない場合は{@link IllegalStateException}が発生します。
	 * <p>
	 * 構築したDELETE文の実行は{@link #executeList()}や{@link #executeBatch()}を使用してください。
	 * 
	 * @param recordList 複数行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityDelete wherePK(List<GRecord> recordList);
	
	/**
	 * WHERE節をユニークキーを検索条件として構築します。
	 * <p>
	 * ユニークキーを検索条件として1行を削除する場合にこのメソッドを使用します。
	 * <p>
	 * ユニークキーの名前はエンティティー定義ファイルに定義されている名前です。<br>
	 * ユニークキーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 定義されていない場合は{@link IllegalStateException}が発生します。
	 * <p>
	 * 構築したDELETE文の実行は{@link #execute()}を使用してください。
	 * 
	 * @param uniqueKeyName ユニークキーの名前
	 * @param record 1行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityDelete whereUK(String uniqueKeyName, GRecord record);
	
	/**
	 * WHERE節をユニークキーを検索条件として構築します。
	 * <p>
	 * ユニークキーを検索条件として複数の行を削除する場合にこのメソッドを使用します。
	 * <p>
	 * ユニークキーの名前はエンティティー定義ファイルに定義されている名前です。<br>
	 * ユニークキーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 定義されていない場合は{@link IllegalStateException}が発生します。
	 * <p>
	 * 構築したDELETE文の実行は{@link #executeList()}や{@link #executeBatch()}を使用してください。
	 * 
	 * @param uniqueKeyName ユニークキーの名前
	 * @param recordList 複数行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityDelete whereUK(String uniqueKeyName, List<GRecord> recordList);
	
	/**
	 * WHERE節を任意の検索条件で構築します。
	 * <p>
	 * このメソッドを使用する場合、楽観的排他は有効になりません。<br>
	 * （更新対象が複数行になる可能性があるため。）
	 * <p>
	 * 構築したDELETE文の実行は{@link #execute()}を使用してください。
	 * 
	 * @param exp 任意の検索条件
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	GEntityDelete where(GExpression exp);
	
	/**
	 * 楽観的排他を無効にします。
	 * <p>
	 * エンティティー定義ファイルで楽観的排他が有効に設定されている場合でも、<br>
	 * このメソッドを使用することにより楽観的排他を無効にすることができます。
	 * 
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityDelete nonexclusive();
	
	/**
	 * 楽観的排他が有効かどうか判定します。
	 * 
	 * @return 楽観的排他が有効である場合は{@code true}。そうでない場合は{@code false}。
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	boolean isExclusive();
	
	/**
	 * WHERE節の検索条件を取得します。
	 * 
	 * @return WHERE節の検索条件
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GExpression getWhereExpression();
}