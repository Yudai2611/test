/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntityResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntitySQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GEntityDelete}インターフェースの実装クラスです.
 *
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public class GEntityDeleteImpl extends GEntityCUDBase<GEntityDelete> implements GEntityDelete {

	/** Where節 */
	private GExpression whereExpression = null;

	/**
	 * デフォルトコンストラクタ.
	 *
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GEntityDeleteImpl() {
	}

	/**
	 * コンストラクタ.
	 *
	 * @param entitySQLGeneratorMap {@link GEntitySQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param entityResultSetHandlerMap {@link GEntityResultSetHandler}のマップ
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GEntityDeleteImpl(Map<String, GEntitySQLGenerator> entitySQLGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GEntityResultSetHandler> entityResultSetHandlerMap) {
		super(entitySQLGeneratorMap, sqlExecuterMap, entityResultSetHandlerMap);
	}

	@Override
	public void init(GEntity entity, String entityAlias) {
		super.init(entity, entityAlias);
		this.loadExclusiveKeyFromEntity();
	}

	@Override
	public void clear() {
		whereExpression = null;
		super.clear();
		this.loadExclusiveKeyFromEntity();
	}

	/**
	 * 楽観的排他フラグをエンティティーから取得し初期化します.
	 * @author KCCS Hashimoto
	 * @create 2015/2/12
	 * @since 3.15.0
	 */
	private void loadExclusiveKeyFromEntity() {
		super.setExclusive(getEntity().getExclusiveKey() != null);
	}

	@Override
	public GEntityDelete where(GExpression exp) {
		super.setExclusiveForSQLBuild(false);
		this.whereExpression = exp;
		return this;
	}

	@Override
	public GEntityDelete wherePK(GRecord record) {
		setTargetRecord(record);
		super.setExclusiveForSQLBuild(true);
		this.whereExpression = new GPKWhereExpression(true);
		return this;
	}

	@Override
	public GEntityDelete wherePK(List<GRecord> recordList) {
		setTargetRecordList(recordList);
		super.setExclusiveForSQLBuild(true);
		this.whereExpression = new GPKWhereExpression(true);
		return this;
	}

	@Override
	public GEntityDelete whereUK(String uniqueKeyName, GRecord record) {
		setTargetRecord(record);
		super.setExclusiveForSQLBuild(true);
		this.whereExpression = new GUKWhereExpression(uniqueKeyName, true);
		return this;
	}

	@Override
	public GEntityDelete whereUK(String uniqueKeyName, List<GRecord> recordList) {
		setTargetRecordList(recordList);
		super.setExclusiveForSQLBuild(true);
		this.whereExpression = new GUKWhereExpression(uniqueKeyName, true);
		return this;
	}

	@Override
	public GExpression getWhereExpression() {
		return this.whereExpression;
	}

	@Override
	public int execute(Connection connection) throws SQLException {
		int result = getSqlExecuter().executeUpdate(connection, createDeleteStatement(), getQueryTimeout());
		// 楽観的排他設定ありで削除件数が0件の場合は例外をスロー
		if (isExclusive() && result == 0) {
			throw new GOptimisticLockException();
		}
		return result;
	}

	@Override
	public int executeList(Connection connection) throws SQLException {
		int result = 0;
		for (GRecord record : getTargetRecordList()) {
			setTargetRecord(record);
			result += execute(connection);
		}
		return result;
	}

	@Override
	public int executeBatch(Connection connection) throws SQLException {
		int result = getSqlExecuter().executeBatchUpdate(connection, createBatchDeleteStatement(), batchSize, getQueryTimeout());
		// 楽観的排他設定ありで削除されたデータ件数が更新対象レコード件数より少ない場合は例外をスロー
		if (isExclusive() && result != getTargetRecordList().size()) {
			throw new GOptimisticLockException();
		}
		return result;
	}

	@Override
	public GQueryResult nativeCall(Connection connection) throws SQLException {
		return getSqlExecuter().execute(connection, createDeleteStatement(), getQueryTimeout());
	}

	/**
	 * 削除用ステートメントを取得します.
	 *
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定した{@link GSQLPiece}
	 * @author KCCS hashimoto
	 * @create 2013/01/31
	 * @since 3.12.0
	 */
	protected GSQLPiece createDeleteStatement() {
		return getSqlGenerator().createDeleteStatement(this);
	}

	/**
	 * 一括削除用ステートメントを取得します.
	 *
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定した{@link GSQLPiece}
	 * @author KCCS hashimoto
	 * @create 2013/01/31
	 * @since 3.12.0
	 */
	protected GSQLPiece createBatchDeleteStatement() {
		return getSqlGenerator().createBatchDeleteStatement(this);
	}

	/**
	 * GConnectionManagerを返します。
	 *
	 * @return GConnectionManager
	 */
	protected GConnectionManager getConnectionManager() {
		return GConnectionManager.getInstance();
	}

	/**
	 * execute.
	 * <br />
	 * このメソッドは、{@link #execute(Connection)}をラップし、コネクション取得とトランザクション制御を行っている。
	 *
	 * @see #execute(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int execute() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return execute(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * executeList.
	 * <br />
	 * このメソッドは、{@link #executeList(Connection)}をラップし、コネクション取得とトランザクション制御を行っている。
	 *
	 * @see #executeList(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int executeList() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return executeList(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * executeBatch.
	 * <br />
	 * このメソッドは、{@link #executeBatch(Connection)}をラップし、コネクション取得とトランザクション制御を行う。
	 *
	 * @see #executeBatch(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int executeBatch() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return executeBatch(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * nativeCall.
	 * <br />
	 * このメソッドは、{@link #nativeCall(Connection)}をラップし、コネクション取得とトランザクション制御を行っている。
	 *
	 * @see #nativeCall(Connection)
	 * @return {@link GQueryResult}のインスタンス
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public GQueryResult nativeCall() throws SQLException {
		Connection connection = null;
		GQueryResult result = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());

			result = nativeCall(connection);

			return enhanceQueryResult(result, connection);
		} catch (RuntimeException e) {
			try {
				close(result);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		} catch (SQLException e) {
			try {
				close(result);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		}
	}
}
