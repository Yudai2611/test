/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.util.List;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;

/**
 * INSERT文を構築するインタフェースです。
 * <p>
 * INSERT文を構築するために必要なメソッドを提供します。<br>
 * このインタフェースで提供しているメソッドを組み合わせて使用することで、直接SQLを記述することなくINSERT文を構築することができます。<br>
 * <p>
 * 主に以下の操作が実現できます。<br>
 * <ol type="1">
 * <li>1行を登録する</li>
 * <li>複数行を登録する</li>
 * <li>INSERT...SELECTで登録する</li>
 * </ol>
 * <p>
 * 構築したINSERT文はスーパーインタフェース{@link GEntityCUD}、または{@link GQuery}のメソッドを使用して実行します。<br>
 * 登録対象テーブルの定義はエンティティー定義ファイルとして作成しておく必要があります。
 * <p>
 * 代表的な使用方法を下記に示します。
 * <p>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">1行を登録する</td></tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     insert("entity")
 *         .values(record)
 *         .execute();</pre>
 * </td>
 * <td>
 * <pre><b>INSERT</b> <b>INTO</b> physicalTable(columnA, columnB) 
 *     <b>VALUES</b> ('valueA', 'valueB');</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">複数行を登録する</tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     insert("entity")
 *         .values(recordList)
 *         .executeList();</pre>
 * </td>
 * <td>
 * <pre> <b>INSERT</b> <b>INTO</b> physicalTable (columnA, columnB)
 *     <b>VALUES</b> ('valueA1', 'valueB1');
 * <b>INSERT</b> <b>INTO</b> physicalTable (columnA, columnB)
 *     <b>VALUES</b> ('valueA2', 'valueB2');
 * ・・・</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">INSERT...SELECT文を使用するINSERT文を構築する</td></tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     insert("entity")
 *         .values(select("subEntity"))
 *         .execute();</pre>
 * </td>
 * <td>
 *     <pre><b>INSERT</b> <b>INTO</b> physicalTable (columnA, columnB)
 *     <b>SELECT</b> columnA, columnB <b>FROM</b> subPhysicalTable;</pre>
 * </td>
 * </tr>
 * </table>
 * 
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public interface GEntityInsert extends GEntityCUD<GEntityInsert> {

	/**
	 * VALUES節を構築します。
	 * <p>
	 * 引数のレコードからINSERT文のVALUES節を構築します。<br>
	 * 1行を登録する場合にこのメソッドを使用します。
	 * <p>
	 * 構築したINSERT文の実行は{@link #execute()}を使用してください。
	 * 
	 * @param record 1行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityInsert values(GRecord record);

	/**
	 * VALUES節を構築します。
	 * <p>
	 * 引数のレコードからINSERT文のVALUES節を構築します。<br>
	 * 複数行を登録する場合にこのメソッドを使用します。
	 * <p>
	 * 構築したINSERT文の実行は{@link #executeList()}や{@link #executeBatch()}を使用してください。
	 * 
	 * @param recordList 複数行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityInsert values(List<GRecord> recordList);

	/**
	 * INSERT...SELECT文のSELECT節を構築します。
	 * <p>
	 * 引数のSELECT文でINSERT...SELECT文の中のSELECT文を構築します。
	 * 
	 * @param select INSERT...SELECT文の中のSELECT文
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityInsert values(GSelect<?> select);

	/**
	 * 指定したカラムでINSERT文を構築します。<br>
	 * カラムはエンティティー定義ファイルに定義する論理名で指定します。
	 * <p>
	 * {@link #excludes(String...)}と組み合わせて使用することはできません。<br>
	 * 使用した場合は{@link IllegalArgumentException}が発生します。
	 * 
	 * @param includes カラムの論理名
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GEntityInsert includes(String... includes);
	
	/**
	 * 指定したカラム以外でINSERT文を構築します。<br>
	 * カラムはエンティティー定義ファイルに定義する論理名で指定します。
	 * <p>
	 * {@link #includes(String...)}と組み合わせて使用することはできません。<br>
	 * 使用した場合は{@link IllegalArgumentException}が発生します。
	 * 
	 * @param excludes カラムの論理名
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GEntityInsert excludes(String... excludes);
	
	/**
	 * 値がNULLであるカラムが存在する場合は、そのカラム以外でINSERT文を構築します。<br>
	 * <p>
	 * {@link #executeBatch()}または{@link #executeBatch(java.sql.Connection)}を組み合わせて使用することはできません。<br>
	 * 使用した場合は{@link IllegalArgumentException}が発生します。
	 * 
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GEntityInsert excludesNull();
	
	/**
	 * 値がNULLであるカラムを除外するかどうかを判定します。
	 * 
	 * @return 値がNULLであるカラムを除外する場合は{@code true}。そうでない場合は{@code false}。
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	boolean isExcludesNull();

	/**
	 * INSERT文構築で使用するカラムを取得します。
	 * <p>
	 * {@link #includes(String...)}、{@link #excludes(String...)}、{@link #excludesNull()}の設定を考慮したカラムを返します。
	 * 
	 * @return カラムのマップ
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GListMap<String, GColumn> getUpdateColumns();
}