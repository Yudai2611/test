/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntityResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntitySQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GEntityInsert}インターフェースの実装クラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public class GEntityInsertImpl extends GEntityCUDBase<GEntityInsert> implements GEntityInsert {

	/** 検索結果レコード登録用の検索情報 */
    private GSelect<?> select = null;
	
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GEntityInsertImpl() {
	}

	/**
	 * コンストラクタ.
	 * 
	 * @param entitySQLGeneratorMap {@link GEntitySQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param entityResultSetHandlerMap {@link GEntityResultSetHandler}のマップ
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
    public GEntityInsertImpl(Map<String, GEntitySQLGenerator> entitySQLGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GEntityResultSetHandler> entityResultSetHandlerMap) {
    	super(entitySQLGeneratorMap, sqlExecuterMap, entityResultSetHandlerMap);
	}
	
	@Override
	public void clear() {
		select = null;
		super.clear();
	}

	@Override
	public GEntityInsert values(GRecord record) {
		setTargetRecord(record);
		return this;
	}

	@Override
	public GEntityInsert values(List<GRecord> recordList) {
		setTargetRecordList(recordList);
		return this;
	}

	@Override
	public GEntityInsert values(GSelect<?> select) {
		this.select = select;
		return this;
	}

	@Override
	public int execute(Connection connection) throws SQLException {
		return getSqlExecuter().executeUpdate(connection, createInsertStatement(), getQueryTimeout());
	}

	@Override
	public int executeList(Connection connection) throws SQLException {
		int result = 0;
		for (GRecord record : getTargetRecordList()) {
			setTargetRecord(record);
			result += execute(connection);
		}
		return result;
	}

	@Override
	public int executeBatch(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createBatchInsertStatement(this);
		return getSqlExecuter().executeBatchUpdate(connection, piece, batchSize, getQueryTimeout());
	}
	
	@Override
	public GQueryResult nativeCall(Connection connection) throws SQLException {
		return getSqlExecuter().execute(connection, createInsertStatement(), getQueryTimeout());
	}

	/**
	 * 登録用ステートメントを取得します.
	 * 
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定したSQL断片
	 * @author KCCS hashimoto
	 * @create 2013/01/31
	 * @since 3.12.0
	 */
	protected GSQLPiece createInsertStatement() {
        if (select != null) {
        	return getSqlGenerator().createSelectInsertStatement(this, select);
        } else {
        	return getSqlGenerator().createInsertStatement(this);
        }
	}
	
	/**
	 * GConnectionManagerを返します。
	 * 
	 * @return GConnectionManager
	 */
	protected GConnectionManager getConnectionManager() {
		return GConnectionManager.getInstance();
	}
	
	/**
	 * execute.
	 * <br />
	 * このメソッドは、{@link #execute(Connection)}をラップし、コネクション取得とトランザクション制御を行っている。
	 * 
	 * @see #execute(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int execute() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return execute(connection);
		} finally {
			releaseConnection(connection);
		}
	}
	
	/**
	 * executeList.
	 * <br />
	 * このメソッドは、{@link #executeList(Connection)}をラップし、コネクション取得とトランザクション制御を行っている。
	 * 
	 * @see #executeList(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int executeList() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return executeList(connection);
		} finally {
			releaseConnection(connection);
		}
	}
	
	/**
	 * executeBatch.
	 * <br />
	 * このメソッドは、{@link #executeBatch(Connection)}をラップし、コネクション取得とトランザクション制御を行う。
	 * 
	 * @see #executeBatch(Connection)
	 * @return 処理件数
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public int executeBatch() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return executeBatch(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * nativeCall.
	 * <br />
	 * このメソッドは、{@link #nativeCall(Connection)}をラップし、コネクション取得とトランザクション制御を行っている。
	 * 
	 * @see #nativeCall(Connection)
	 * @return {@link GQueryResult}のインスタンス
	 * @throws SQLException SQL実行時例外
	 * @author KCCS kitamura
	 * @create 2012/12/27
	 * @since 3.12.0
	 */
	@Override
	public GQueryResult nativeCall() throws SQLException {
		Connection connection = null;
		GQueryResult result = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			
			result = nativeCall(connection);
			
			return enhanceQueryResult(result, connection);
		} catch (RuntimeException e) {
			try {
				close(result);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		} catch (SQLException e) {
			try {
				close(result);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		}
	}
}
