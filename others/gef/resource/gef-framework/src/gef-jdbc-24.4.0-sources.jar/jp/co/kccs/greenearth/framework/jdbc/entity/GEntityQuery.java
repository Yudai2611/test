/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;

/**
 * SQL構築で使用するエンティティーを管理するインタフェースです。
 * <p>
 * SQLを構築するためにはエンティティー定義を読み込んだエンティティーが必要です。<br>
 * このインタフェースではエンティティーを管理するための機能を提供します。
 * <p>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>エンティティを保持し、提供する。</li>
 * <li>エンティティに別名を付与する</li>
 * <li>エンティティを初期化する</li>
 * </ol>
 * 
 * @param <S> 各種SQL操作エンティティー
 * @author KCCS kitamura
 * @create 2012/12/11
 * @since 3.12.0
 */
public interface GEntityQuery<S extends GEntityQuery<S>> extends GQuery<S> {

	/**
	 * エンティティーを取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイルからロードされたエンティティー定義です。
	 * 
	 * @return {@link GEntity}
	 * @author KCCS kitamura
	 * @create 2012/12/11
	 * @since 3.12.0
	 */
	GEntity getEntity();
	
	/**
	 * エンティティーの別名を取得します。
	 * <p>
	 * デフォルト値はNULLです。
	 * 
	 * @return エンティティーの別名
	 * @author KCCS kitamura
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	String getEntityAlias();
	
	/**
	 * エンティティーの別名を設定します。
	 * 
	 * @param entityAlias エンティティーの別名
	 * @author KCCS kitamura
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	void setEntityAlias(String entityAlias);
	
	/**
	 * 初期化します。
	 * <p>
	 * このインスタンス自身を初期化します。
	 * 
	 * @param entity エンティティー
	 * @param entityAlias エンティティーの別名
	 * @author KCCS kitamura
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	void init(GEntity entity, String entityAlias);

	/**
	 * カラムを{@link GColumn}をとして取得します。
	 * <p>
	 * エンティティー定義ファイルの定義から{@link GColumn}を返します。
	 * エンティティー定義ファイルに定義するカラムの論理名で指定します。<br>
	 * 
	 * @param columnName カラムの論理名
	 * @return {@link GColumn}
	 * @author KCCS kitamura
	 * @create 2012/12/11
	 * @since 3.12.0
	 */
	GColumn lookupColumn(String columnName);
}