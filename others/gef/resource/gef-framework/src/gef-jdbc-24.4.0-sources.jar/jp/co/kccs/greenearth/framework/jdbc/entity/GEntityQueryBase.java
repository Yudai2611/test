/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GQueryBase;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntityResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntitySQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;

/**
 * {@link GEntityQuery}を実装する基底クラスです.
 * 
 * @param <S> 各種ＳＱＬ操作エンティティー
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public abstract class GEntityQueryBase<S extends GEntityQuery<S>> extends GQueryBase<S> implements GEntityQuery<S> {

	/** {@link GEntity}のインスタンス */
	private GEntity entity = null;
	/** メインエンティティ別名 */
	private String entityAlias = null;
	/** {@link GEntitySQLGenerator}のインスタンス */
	private Map<String, GEntitySQLGenerator> entitySQLGeneratorMap;
	/** {@link GEntityResultSetHandler}のインスタンス */
	private Map<String, GEntityResultSetHandler> entityResultSetHandlerMap;
	
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GEntityQueryBase() {
	}
	
	/**
	 * コンストラクタ.
	 * 
	 * @param entitySQLGeneratorMap {@link GEntitySQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param entityResultSetHandlerMap {@link GEntityResultSetHandler}のマップ
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GEntityQueryBase(Map<String, GEntitySQLGenerator> entitySQLGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GEntityResultSetHandler> entityResultSetHandlerMap) {
		super(sqlExecuterMap);
		this.entitySQLGeneratorMap = entitySQLGeneratorMap;
		this.entityResultSetHandlerMap = entityResultSetHandlerMap;
	}
	
	/**
	 * {@link GEntitySQLGenerator}のインスタンスを取得します.
	 * 
	 * @return {@link GEntitySQLGenerator}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GEntitySQLGenerator getSqlGenerator() {
		return entitySQLGeneratorMap.get(getDatabase().getDbType());
	}
	
	/**
	 * {@link GEntityResultSetHandler}のインスタンスを取得します.
	 * 
	 * @return {@link GEntityResultSetHandler}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GResultSetHandler getResultSetHandler() {
		return entityResultSetHandlerMap.get(getDatabase().getDbType());
	}
	
	@Override
	public GEntity getEntity() {
		return this.entity;
	}
	
	@Override
	public String getEntityAlias() {
		return this.entityAlias;
	}

	@Override
	public void setEntityAlias(String entityAlias) {
		this.entityAlias = entityAlias;
	}

	/**
	 * 初期化します。
	 * 
	 * @param entity {@link GEntity}
	 * @param entityAlias エンティティのエイリアス
	 */
	@Override
	public void init(GEntity entity, String entityAlias) {
		// NOTE エンティティのデータベースタイプにより異なる実装を取得する必要がある
		this.setEntity(entity);
		setDatabase(entity.getDatabase());
		this.entityAlias = entityAlias;
	}

	/**
	 * クリア。
	 */
	@Override
	public void clear() {
		super.clear();
		init(entity, entityAlias);
	}

	@Override
	public GColumn lookupColumn(String columnName) {
		GColumn column = null;
		if (getEntity().getColumns().containsKey(columnName)) {
			column = getEntity().getColumns().get(columnName);
		}

		if (column == null) {
			throw new IllegalStateException("This column does not exist. :" + columnName);
		}
		return column;
	}

	/**
	 * エンティティーを設定します.
	 * 
	 * @param entity エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected void setEntity(GEntity entity) {
		this.entity = entity;
	}

	/**
	 * ステートメントをクローズします.
	 * 
	 * @param statement クローズするステートメント
	 * @throws SQLException ステートメントクローズ時の例外
	 * @author hashimoto
	 * @create 2012/11/12
	 * @since 3.12.0
	 */
	protected void close(Statement statement) throws SQLException {
		if (statement != null) {
			statement.close();
		}
	}
}
