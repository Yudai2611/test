/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntityFactory;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GRepositoryException;

/**
 * エンティティのインスタンスを取得するファクトリクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GEntityQueryFactory {

    /**
     * エンティティのインスタンスを取得します.
     * 
     * @param clazz 取得するエンティティの型
     * @param entityId エンティティID
     * @param entityAlias エンティティ別名
     * @param <T> 各種SQL操作エンティティー
     * @return エンティティのインスタンス
     * @throws GRepositoryException リポジトリ例外
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	@Deprecated
	public static <T extends GEntityQuery<?>> T getQuery(Class<T> clazz, String entityId, String entityAlias) throws GRepositoryException {
		GEntityFactory factory = GEntityFactory.Factory.getInstance();
		GEntity entity = factory.getEntity(entityId);
		return getQuery(clazz, entity, entityAlias);
	}
	
	/**
	 * エンティティを使用するクエリのインスタンスを取得します.
	 * 
	 * @param clazz 取得するエンティティの型
	 * @param entityId エンティティID
	 * @param <T> 各種SQL操作エンティティー
	 * @return エンティティのインスタンス
	 * @throws GRepositoryException リポジトリ例外
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
	 */
	@Deprecated
	public static <T extends GEntityQuery<?>> T getQuery(Class<T> clazz, String entityId) throws GRepositoryException {
		return getQuery(clazz, entityId, null);
	}
	
    /**
     * エンティティを使用するクエリのインスタンスを取得します.
     * 
     * @param clazz 取得するエンティティの型
     * @param entity エンティティ
     * @param entityAlias エンティティ別名
     * @param <T> 各種SQL操作エンティティー
     * @return エンティティのインスタンス
     * @throws GRepositoryException リポジトリ例外
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public static <T extends GEntityQuery<?>> T getQuery(Class<T> clazz, GEntity entity, String entityAlias) throws GRepositoryException {
		T query = GFrameworkUtils.getComponent(clazz.getName());
		if (query.getEntity() == null) {
			query.init(entity, entityAlias);
		}
		return query;
	}
	
	/**
	 * エンティティを使用するクエリのインスタンスを取得します.
	 * 
	 * @param clazz 取得するエンティティの型
	 * @param entity エンティティ
	 * @param <T> 各種SQL操作エンティティー
	 * @return エンティティのインスタンス
	 * @throws GRepositoryException リポジトリ例外
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
	 */
	@Deprecated
	public static <T extends GEntityQuery<?>> T getQuery(Class<T> clazz, GEntity entity) throws GRepositoryException {
		return getQuery(clazz, entity, null);
	}
}
