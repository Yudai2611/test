/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.util.List;

import jp.co.kccs.greenearth.commons.collection.GPair;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;

/**
 * SELECT文を構築するインタフェースです。
 * <p>
 * SELECT文を構築するために必要なメソッドを提供します。<br>
 * このインタフェースで提供しているメソッドを組み合わせて使用することで、直接SQLを記述することなくSELECT文を構築することができます。<br>
 * <p>
 * 主に以下の操作が実現できます。<br>
 * <ol type="1">
 * <li>主キーを検索条件として検索する</li>
 * <li>ユニークキーを検索条件として検索する</li>
 * <li>任意の条件を検索条件として検索する</li>
 * <li>テーブルを結合して検索する</li>
 * <li>ORDER BYを使用して検索する</li>
 * <li>GROUP BYを使用して検索する</li>
 * <li>UNIONを使用して検索する</li>
 * </ol>
 * <p>
 * 構築したSELECT文はスーパーインタフェース{@link GSelect}、または{@link GQuery}のメソッドを使用して実行します。<br>
 * 検索対象テーブルの定義はエンティティー定義ファイルとして作成しておく必要があります。
 * <p>
 * 代表的な使用方法を下記に示します。
* <p>
 * <table border="1">
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">主キーを検索条件として検索する</td></tr>
 * <tr>
 * <td>
 * <pre>GRecord record =
 *     select("entity")
 *         .wherePK("value")
 *         .findRecord();</pre>
 * </td>
 * <td>
 * <pre><b>SELECT</b> columnPK, columnUNQ, columnA
 *  <b>FROM</b> physicalTable
 * <b>WHERE</b> columnPK = 'value';</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">ユニークキーを検索条件として検索する</td></tr>
 * <tr>
 * <td>
 * <pre>GRecord record = 
 *     select("entity")
 *         .whereUK("uniqueKey", "value")
 *         .findRecord();</pre>
 * </td>
 * <td>
 * <pre><b>SELECT</b> columnPK, columnUNQ, columnA
 *  <b>FROM</b> physicalTable
 * <b>WHERE</b> columnUNQ = 'value';</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">任意の条件を検索条件として検索する</td></tr>
 * <tr>
 * <td>
 * <pre>List&ltGRecord&gt recordList =
 *     select("entity")
 *         .where(exp("columnA = ?", "value00"))
 *         .findList();</pre>
 * </td>
 * <td>
 * <pre><b>SELECT</b> columnPK, columnUNQ, columnA
 *  <b>FROM</b> physicalTable
 * <b>WHERE</b> columnA = 'value00';</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">テーブルを結合して検索する</td></tr>
 * <tr>
 * <td><pre>List&ltGRecord&gt recordList =
 *     select("entity", "en1")
 *         .innerJoinFK("foreignKey", "en2")
 *         .findList();</pre>
 * </td>
 * <td>
 * <pre><b>SELECT</b> en1.columnPK, en1.columnUNQ, en1.columnA, en2.column1, en2.column2
 * <b>FROM</b> physicalTable en1 <b>INNER</b> <b>JOIN</b> anotherTable en2
 *   <b>ON</b> en1.columnA = en2.column1;</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">ORDER BYを使用して検索する</td></tr>
 * <tr>
 * <td>
 * <pre>List&ltGRecord&gt recordList =
 *     select("entity")
 *         .where(exp("columnA = ?", "value00"))
 *         .orderBy(asc("columnA"))
 *         .findList();</pre>
 * </td>
 * <td>
 * <pre><b>SELECT</b> columnPK, columnUNQ, columnA
 *  <b>FROM</b> physicalTable
 * <b>WHERE</b> columnA = 'value00'
 * <b>ORDER BY</b> columnA <b>ASC</b>;</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">GROUP BYを使用して検索する</td></tr>
 * <tr>
 * <td>
 * <pre>List&ltGRecord&gt recordList =
 *     select("entity")
 *         .fields(col("columnA", FuncType.MAX))
 *         .where(exp("columnA = ?", "value00"))
 *         .groupBy("columnA")
 *         .findList();</pre>
 * </td>
 * <td>
 * <pre><b>SELECT</b> MAX(columnA)
 *  <b>FROM</b> physicalTable
 * <b>WHERE</b> columnA = 'value00'
 * <b>GROUP BY</b> columnA;</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">UNIONを使用して検索する</td></tr>
 * <tr>
 * <td><pre> GEntitySelect select1 = select("entity1").wherePK("value"));
 * GEntitySelect select2 = select("entity2").wherePK("value"));
 * 
 * List&ltGRecord&gt recordList = select1.union(select2).findList();</pre>
 * </td>
 * <td><pre><b>SELECT</b> columnPK, columnA
 *  <b>FROM</b> physicalTable1
 * <b>WHERE</b> columnPK = 'value'
 *<b>UNION</b> 
 *<b>SELECT</b> columnPK, columnA
 *  <b>FROM</b> physicalTable2
 * <b>WHERE</b> columnPK = 'value';</pre>
 * </td>
 * </tr>
 * </table>
 * 
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public interface GEntitySelect extends GSelect<GEntitySelect>, GEntityQuery<GEntitySelect> {
	
	/**
	 * DISTINCTオプションを付与します。
	 * 
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/12/12
	 * @since 3.12.0
	 */
	GEntitySelect distinct();
	
	/**
	 * SELECT節のカラムを指定します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義する論理名で指定します。
	 * 
	 * @param selectColumns SELECT節に指定するカラムの論理名
	 * <p>
	 * エンティティー別名を使用する場合は {@code "alias.column"} とします。<br>
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/10
	 * @since 3.12.0
	 */
	GEntitySelect fields(String... selectColumns);
	
	/**
	 * SELECT節のカラムを指定します。
	 * <p>
	 * {@link GSelectColumn}でカラムを指定することで、別名や関数を付与したカラムの使用が可能になります。
	 * 
	 * @param selectColumns SELECT節に指定するカラム（{@link GSelectColumn}）
	 * <p>
	 * {@link GQueryAssistants#col(String)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/10
	 * @since 3.12.0
	 */
	GEntitySelect fields(GSelectColumn... selectColumns);
	
	/**
	 * SELECT節のカラムを指定します。
	 * <p>
	 * {@link GSelectColumnList}でカラムを指定することで、別名や関数を付与することが可能になり、カラムを一括して指定することが可能になります。
	 *
	 * @param selectColumns SELECT節に指定するカラムのリスト（{@link GSelectColumnList}）
	 * <p>
	 * {@link GQueryAssistants#colsAll}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/10
	 * @since 3.12.0
	 */
	GEntitySelect fields(GSelectColumnList selectColumns);
	
	/**
	 * 外部キーを使用して内部結合します。
	 * <p>
	 * このメソッドを通じて内部結合をすることができます。<br>
	 * <p>
	 * 外部キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 外部キーが定義されていない場合や結合条件となる値の数が異なる場合は{@link IllegalStateException}が発生します。
	 * 
	 * @param foreignKey エンティティー定義ファイルで定義された外部キー名
	 * @param params 結合条件にバインドする値
	 * <p>
	 * この引数を使うためには下記のようにエンティティー定義ファイルで結合条件でバインドパラメータを使用するよう設定されている必要があります。<br>
	 * 値の個数と順番はエンティティ―定義ファイルに合わせてください。<br>
	 * <table border="1">
	 * <tr><td><pre>
	 * ...
	 * {@literal <}JoinColumn srcName="ItemCode" <b>bindParameter</b>="true"/{@literal >}
	 * ...
	 * </pre></td></tr>
	 * </table>
	 * <p>
	 * 次のような結合条件を構築したい場合に使用します。この引数は?にバインドする値です。
	 * <pre> WHERE tableA a INNER JOIN tableB b ON a.column1 = b.column1
	 *  AND a.column2 = ?</pre>
	 * 
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect innerJoinFK(String foreignKey, Object... params);
	
	/**
	 * 外部キーを使用して内部結合します。
	 * <p>
	 * このメソッドを通じて内部結合をした上で、結合先エンティティーに別名を付けることができます。
	 * <p>
	 * 外部キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 外部キーが定義されていない場合や結合条件となる値の数が異なる場合は{@link IllegalStateException}が発生します。
	 * <p>
	 * このメソッドを通じて結合先エンティティーに別名を付けることができます。
	 * 
	 * @param forigenKey エンティティー定義ファイルで定義された外部キー名
	 * @param entityAlias 結合先エンティティーの別名
	 * @param params 結合条件となる値
	 * <p>
	 * 下記のように結合条件でバインドパラメータを使用するようエンティティー定義ファイルで設定されている場合に使用します。<br>
	 * 値の個数と順番はエンティティ―定義ファイルに合わせてください。<br>
	 * <table border="1">
	 * <tr><td><pre>
	 * ...
	 * {@literal <}JoinColumn srcName="ItemCode" <b>bindParameter</b>="true"/{@literal >}
	 * ...
	 * </pre></td></tr>
	 * </table>
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect innerJoinFK(String forigenKey, String entityAlias, Object... params);
	
	/**
	 * エンティティーを指定して内部結合します。
	 * <p>
	 * このメソッドを通じて結合先エンティティーと結合条件を指定することができます。<br>
	 * <p>
	 * 結合先エンティティーはエンティティー定義ファイルを作成しておく必要があります。
	 * 
	 * @param entityId 結合先のエンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @param exp 結合条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect innerJoin(String entityId, GExpression exp);
	
	/**
	 * エンティティーを指定して内部結合します。
	 * <p>
	 * このメソッドを通じて結合先エンティティーと結合条件を指定することができます。<br>
	 * また結合先エンティティーに別名を付けることができます。
	 * <p>
	 * 結合先エンティティーはエンティティー定義ファイルを作成しておく必要があります。<br>
	 * 
	 * @param entityId 結合先のエンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @param entityAlias 結合先のエンティティー別名
	 * @param exp 結合条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect innerJoin(String entityId, String entityAlias, GExpression exp);
	
	/**
	 * 外部キーを使用して左外部結合します。
	 * <p>
	 * このメソッドを通じて左外部結合をすることができます。<br>
	 * <p>
	 * 外部キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 外部キーが定義されていない場合や検索条件となる値の数が異なる場合は{@link IllegalStateException}が発生します。
	 * 
	 * @param foreignKey 外部キー
	 * @param params 結合条件となる値
	 * <p>
	 * 下記のように結合条件でバインドパラメータを使用するようエンティティー定義ファイルで設定されている場合に使用します。<br>
	 * 値の個数と順番はエンティティ―定義ファイルに合わせてください。<br>
	 * <table border="1">
	 * <tr><td><pre>
	 * ...
	 * {@literal <}JoinColumn srcName="ItemCode" <b>bindParameter</b>="true"/{@literal >}
	 * ...
	 * </pre></td></tr>
	 * </table>
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect leftOuterJoinFK(String foreignKey, Object... params);
	
	/**
	 * 外部キーを使用して左外部結合します。
	 * <p>
	 * このメソッドを通じて左外部結合をすることができ、さらに結合先テーブルに別名をつけることができます。<br>
	 * <p>
	 * 外部キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 外部キーが定義されていない場合や検索条件となる値の数が異なる場合は{@link IllegalStateException}が発生します。
	 * 
	 * @param forigenKey 外部キー
	 * @param entityAlias 結合先のエンティティー別名
	 * @param params 結合条件となる値
	 * <p>
	 * 下記のように結合条件でバインドパラメータを使用するようエンティティー定義ファイルで設定されている場合に使用します。<br>
	 * 値の個数と順番はエンティティ―定義ファイルに合わせてください。<br>
	 * <table border="1">
	 * <tr><td><pre>
	 * ...
	 * {@literal <}JoinColumn srcName="ItemCode" <b>bindParameter</b>="true"/{@literal >}
	 * ...
	 * </pre></td></tr>
	 * </table>
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect leftOuterJoinFK(String forigenKey, String entityAlias, Object... params);
	
	/**
	 * エンティティーを指定して左外部結合します。
	 * <p>
	 * このメソッドを通じて結合先エンティティーと結合条件を指定することができます。<br>
	 * <p>
	 * 結合先エンティティーはエンティティー定義ファイルを作成しておく必要があります。
	 * 
	 * @param entityId 結合先のエンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @param exp 結合条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect leftOuterJoin(String entityId, GExpression exp);
	
	/**
	 * エンティティーを指定して左外部結合します。
	 * <p>
	 * このメソッドを通じて結合先エンティティーと結合条件を指定することができ、さらに結合先テーブルに別名をつけることができます。<br>
	 * <p>
	 * 結合先エンティティーはエンティティー定義ファイルを作成しておく必要があります。<br>
	 * 
	 * @param entityId 結合先のエンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @param entityAlias 結合先のエンティティー別名
	 * @param exp 結合条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect leftOuterJoin(String entityId, String entityAlias, GExpression exp);
	
	/**
	 * 外部キーを使用して右外部結合します。
	 * <p>
	 * このメソッドを通じて右外部結合をすることができます。<br>
	 * <p>
	 * 外部キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 外部キーが定義されていない場合や検索条件となる値の数が異なる場合は{@link IllegalStateException}が発生します。
	 * 
	 * @param foreignKey 外部キー
	 * @param params 結合条件となる値
	 * <p>
	 * 下記のように結合条件でバインドパラメータを使用するようエンティティー定義ファイルで設定されている場合に使用します。<br>
	 * 値の個数と順番はエンティティ―定義ファイルに合わせてください。<br>
	 * <table border="1">
	 * <tr><td><pre>
	 * ...
	 * {@literal <}JoinColumn srcName="ItemCode" <b>bindParameter</b>="true"/{@literal >}
	 * ...
	 * </pre></td></tr>
	 * </table>
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect rightOuterJoinFK(String foreignKey, Object... params);
	
	/**
	 * 外部キーを使用して右外部結合します。
	 * <p>
	 * このメソッドを通じて左外部結合をすることができ、さらに結合先テーブルに別名をつけることができます。<br>
	 * <p>
	 * 外部キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 外部キーが定義されていない場合や検索条件となる値の数が異なる場合は{@link IllegalStateException}が発生します。
	 * 
	 * @param forigenKey 外部キー
	 * @param entityAlias エンティティー別名
	 * @param params 結合条件となる値
	 * <p>
	 * 下記のように結合条件でバインドパラメータを使用するようエンティティー定義ファイルで設定されている場合に使用します。<br>
	 * 値の個数と順番はエンティティ―定義ファイルに合わせてください。<br>
	 * <table border="1">
	 * <tr><td><pre>
	 * ...
	 * {@literal <}JoinColumn srcName="ItemCode" <b>bindParameter</b>="true"/{@literal >}
	 * ...
	 * </pre></td></tr>
	 * </table>
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect rightOuterJoinFK(String forigenKey, String entityAlias, Object... params);
	
	/**
	 * 結合条件式を使用して右外部結合します。
	 * <p>
	 * このメソッドを通じて結合先エンティティーと結合条件を指定することができます。<br>
	 * <p>
	 * 結合先エンティティーはエンティティー定義ファイルを作成しておく必要があります。
	 * 
	 * @param entityId 結合先のエンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @param exp 結合条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect rightOuterJoin(String entityId, GExpression exp);
	
	/**
	 * 結合条件式を使用して右外部結合します。
	 * <p>
	 * このメソッドを通じて結合先エンティティーと結合条件を指定することができ、さらに結合先テーブルに別名をつけることができます。<br>
	 * <p>
	 * 結合先エンティティーはエンティティー定義ファイルを作成しておく必要があります。
	 * 
	 * @param entityId 結合先のエンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @param entityAlias 結合先のエンティティー別名
	 * @param exp 結合条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	GEntitySelect rightOuterJoin(String entityId, String entityAlias, GExpression exp);
	
	/**
	 * WHERE節を主キーを検索条件として構築します。
	 * <p>
	 * 主キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 値の個数と順番はエンティティ―定義ファイルでの定義に合わせてください。<br>
	 * 主キーが定義されていない場合やカラム数と値の数が異なる場合は{@link IllegalStateException}が発生します。<br>
	 *
	 * @param primaryKeyParams 検索条件となる値
	 * <p>
	 * 主キーが複合キーの場合は {@code "value1", 999} のように複数の値を渡します。
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntitySelect wherePK(Object... primaryKeyParams);
	
	/**
	 * WHERE節をユニークキーを検索条件として構築します。
	 * <p>
	 * ユニークキーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 値の個数と順番はエンティティ―定義ファイルでの定義に合わせてください。<br>
	 * ユニークキーが定義されていない場合やカラム数と値の数が異なる場合は{@link IllegalStateException}が発生します。<br>
	 *
	 * @param uniqueKeyName エンティティ―定義ファイルに定義されているユニークキー名
	 * @param uniqueKeyParams 検索条件となる値
	 * <p>
	 * ユニークキーが複合キーの場合は {@code "value1", 999} のように複数の値を渡します。
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntitySelect whereUK(String uniqueKeyName, Object... uniqueKeyParams);
	
	/**
	 * WHERE節を任意の検索条件で構築します。
	 *
	 * @param exp 検索条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	GEntitySelect where(GExpression exp);
	
	/**
	 * GroupBy節を構築します。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義した論理名で指定します。
	 * 
	 * @param columnNames カラムの論理名
	 * <p>
	 * エンティティー別名を使用する場合は {@code "alias.column"} とします。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GEntitySelect groupBy(String... columnNames);
	
	/**
	 * {@link GSelectColumn}を使ってGROUP BY節を構築します。
	 * <p>
	 * {@link GSelectColumn}を使用することで、別名や関数を付与したカラムの使用が可能になります。
	 * <p>
	 * カラムはエンティティー定義ファイルに定義した論理名で指定します。
	 * 
	 * @param columns {@link GSelectColumn}
	 * <p>
	 * {@link GQueryAssistants#col(String)}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GEntitySelect groupBy(GSelectColumn... columns);
	
	/**
	 * HAVING節を構築します。
	 * 
	 * @param exp HAVING節で使用する条件
	 * <p>
	 * {@link GQueryAssistants#exp(String, Object...)}などを使用して生成します
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GEntitySelect having(GExpression exp);
	
	/**
	 * {@link GSelectColumn}を使ってORDER BY節を構築します。
	 * 
	 * @param order カラム
	 * <p>
	 * {@link GQueryAssistants#asc(String)}などを使用して生成します
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GEntitySelect orderBy(GSelectColumn... order);
	
	/**
	 * 集合演算子UNIONでSELECT文を結合することができます。<br>
	 * {@link GEntitySelect}または{@link GDirectSelect}を結合することができます。
	 * 
	 * @param select UNIONで結合する{@link GSelect}
	 * <p>
	 * {@link GQueryAssistants#select(String)}、{@link GQueryAssistants#selectSql()}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS yamashita
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	GEntitySelect union(GSelect<?> select);
	
	/**
	 * 集合演算子UNION AllでSELECT文を結合することができます。<br>
	 * {@link GEntitySelect}または{@link GDirectSelect}を結合することができます。
	 * 
	 * @param select UnionAllで結合する{@link GSelect}
	 * <p>
	 * {@link GQueryAssistants#select(String)}、{@link GQueryAssistants#selectSql()}などを使用して生成します。
	 * @return このインスタンス自身
	 * @author KCCS yamashita
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	GEntitySelect unionAll(GSelect<?> select);
	
	/**
	 * ForUpdate節を付与します。
	 *
	 * @return このインスタンス自身
	 * @author hashimoto
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	GEntitySelect forUpdate();
	
	/**
	 * ForUpdate節をNOWAITオプションで付与します。
	 *
	 * @return このインスタンス自身
	 * @author hashimoto
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	GEntitySelect forUpdateNoWait();
	
	/**
	 * ForUpdate節をWAITオプションで付与します。
	 *
	 * @param time 待ち時間（秒）
	 * @return このインスタンス自身
	 * @author hashimoto
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	GEntitySelect forUpdate(int time);

	/**
	 * 初期化します。
	 * <p>
	 * このインスタンス自身の設定を初期化します。
	 * 
	 * @param entity エンティティ
	 * @param entityAlias エンティティ別名
	 * @author KCCS kitamura
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	void init(GEntity entity, String entityAlias);
	
	/**
	 * エンティティー別名を取得します。
	 * 
	 * @return エンティティー別名
	 * @author KCCS kitamura
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	String getEntityAlias();
	
	/**
	 * エンティティー別名を設定します。
	 * 
	 * @param entityAlias エンティティー別名
	 * @author KCCS kitamura
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	void setEntityAlias(String entityAlias);
	
	/**
	 * SELECT節のカラムを取得します。
	 * 
	 * @return SELECT節に設定されているカラム
	 * @author KCCS K.Fujita
	 * @create 2012/10/10
	 * @since 3.12.0
	 */
	GSelectColumnList getSelectColumns();
	
	/**
	 * 結合情報のリストを取得します。
	 * 
	 * @return 結合情報のリスト
	 * @author KCCS K.Fujita
	 * @create 2012/10/30
	 * @since 3.12.0
	 */
	List<GJoinData> getJoinList();
	
	/**
	 * WHERE節の条件式を取得します。
	 * 
	 * @return WHERE節の条件式
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	GExpression getWhereExpression();
	
	/**
	 * グループ化カラムを取得します。
	 *
	 * @return カラムのリスト
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	List<GSelectColumn> getGroupColumns();
	
	/**
	 * HAVING節の検索条件を取得します。
	 *
	 * @return Having節の検索条件
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GExpression getHavingExpression();
	
	/**
	 * ORDER BY節で使用するカラムを取得します。
	 * 
	 * @return OrderBy節で使用するカラム
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	List<GSelectColumn> getOrderColumns();
	
	/**
	 * UNIONでつなぎ合わせるSELECT文のリストを取得します。
	 * 
	 * @return UNIONでつなぎ合わせるSELECT文のリスト
	 * @author KCCS yamashita
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	List<GPair<GSelect<?>, Boolean>> getUnionList();
	
	/**
	 * ForUpdateの待機時間を取得します。
	 *
	 * @return 待機時間（秒）
	 * @author hashimoto
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	int getWaitTime();
	
	/**
	 * DISTINCTオプションが指定されているかどうか判定します。
	 * 
	 * @return DISTINCTオプションが指定されてる場合は{@code true}。そうでない場合は{@code false}。
	 * @author KCCS K.Fujita
	 * @create 2012/12/12
	 * @since 3.12.0
	 */
	boolean isDistinct();

	/**
	 * ForUpdateを付与するかどうか判定します。
	 *
	 * @return ForUpdateを付与する場合は{@code true}。そうでない場合は{@code false}。
	 * @author hashimoto
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	boolean isForUpdate();

	/**
	 * ForUpdateのオプションがNOWAITであるかどうか判定します。
	 *
	 * @return ForUpdateのオプションがNOWAITである場合は{@code true}。そうでない場合は{@code false}。
	 * @author hashimoto
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	boolean isNoWait();
	
	/**
	 * SELECT節に指定するカラムを{@link GSelectColumn}として生成します。
	 * 
	 * エンティティー定義ファイルに定義したカラムの論理名を渡します。
	 * 
	 * @param columnName カラムの論理名
	 * @return 抽出カラム情報
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumn createSelectColumn(String columnName);
	
	/**
	 * SELECT節に指定するカラムを{@link GSelectColumn}として生成します。
	 * <p>
	 * カラムにエンティティーの別名を付与することができます。
	 * 
	 * @param entityAlias エンティティー別名
	 * @param column {@link GColumn}
	 * @return 検索項目
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumn createSelectColumn(String entityAlias, GColumn column);
	
	/**
	 * SELECT節に指定するカラムを{@link GSelectColumn}として生成します。
	 * 
	 * @param exp {@link GExpression}
	 * @return 検索項目
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumn createSelectColumn(GExpression exp);
	
	/**
	 * SELECT節に指定するカラムのリストを{@link GSelectColumnList}として生成します。
	 * <p>
	 * このエンティティー自身のカラムがリストされます。
	 * 
	 * @return 抽出するカラムのリスト
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList createSelectColumnList();
	
	/**
	 * SELECT節に指定するカラムのリストを{@link GSelectColumnList}として生成します。
	 * <p>
	 * 指定したエンティティーのカラムがリストされます。
	 * 
	 * @param entityName  エンティティー名（エンティティー定義ファイル名から拡張子を除いたもの）
	 * @return 抽出するカラムのリスト
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList createSelectColumnList(String entityName);
	
	/**
	 * SELECT節に指定するカラムのリストを{@link GSelectColumnList}として生成します。
	 * <p>
	 * 指定したエンティティーのカラムがリストされます。
	 * 
	 * @param entity エンティティー
	 * @param entityAlias エンティティー別名
	 * @return 抽出するカラムのリスト
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList createSelectColumnList(GEntity entity, String entityAlias);
	
	/**
	 * SELECT節に指定するカラムのリストを{@link GSelectColumnList}として生成します。
	 * <p>
	 * このエンティティー自身とこのエンティティーに紐づく全てのサブエンティティーのカラムがリストされます。
	 * 
	 * @return 抽出するカラムのリスト
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList createSelectColumnListAll();
}