/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.collection.GPair;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntityFactory;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GForeignKey;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntityResultSetHandler;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GEntitySQLGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLExecuter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GEntitySelect}インターフェースの実装クラスです.
 *
 * @create 2012/10/11
 * @author KCCS K.Fujita
 * @since 3.12.0
 */
public class GEntitySelectImpl extends GEntityQueryBase<GEntitySelect> implements GEntitySelect {
	
	//--------------------Join節-------------------------
	/** 結合情報のリスト */
	private List<GJoinData> joinList = new LinkedList<GJoinData>();

	//--------------------Select節--------------------
	/** Select節に設定する項目 */
	private GSelectColumnList selectColumns = createSelectColumnList();
	/** Distinctオプション付与フラグ */
	private boolean distinctFlag = false;
	
	//--------------------Where節--------------------
	/** Where節の検索条件 */
	private GExpression whereExpression = null;
	
	//--------------------GroupBy節--------------------
	/** グループ化カラム */
	private List<GSelectColumn> groupColumns = new ArrayList<GSelectColumn>();

	//--------------------Having節--------------------
	/** Having節の検索条件 */
	private GExpression havingExpression = null;

	//--------------------OrderBy節--------------------
	/** ソート項目のリスト */
	private List<GSelectColumn> orderColumns = new ArrayList<GSelectColumn>();

	//--------------------ForUpdate節--------------------
	/** ForUpdate付与判定フラグ */
	private boolean forUpdateFlg = false;
	/** nowait付与判定フラグ */
	private boolean noWaiteFlg = false;
	/** wait時間 */
	private int waitTime = -1;

	//--------------------Rang節 --------------------
	/** 範囲指定検索(開始インデックス) */
	private int startRowIndex = 0;
	/** 範囲指定検索(取得件数) */
	private int listSize = -1;
	
	//--------------------Union節 --------------------
	/** ユニオン項目のリスト */
	private List<GPair<GSelect<?>, Boolean>> unionList = new ArrayList<GPair<GSelect<?>, Boolean>>();

	/** {@link GEntityFactory}のインスタンス */
	private GEntityFactory entityFactory;

	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2015/02/24
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	@Deprecated
	public GEntitySelectImpl() {
	}
	
	/**
	 * コンストラクタ.
	 * 
	 * @param entitySQLGeneratorMap {@link GEntitySQLGenerator}のマップ
	 * @param sqlExecuterMap {@link GSQLExecuter}のマップ
	 * @param entityResultSetHandlerMap {@link GEntityResultSetHandler}のマップ
	 * @param entityFactory {@link GEntityFactory}のインスタンス
	 * @create 2015/02/17
	 * @author KCCS yamashita
	 * @since 3.15.0
	 */
	public GEntitySelectImpl(Map<String, GEntitySQLGenerator> entitySQLGeneratorMap, Map<String, GSQLExecuter> sqlExecuterMap, Map<String, GEntityResultSetHandler> entityResultSetHandlerMap, GEntityFactory entityFactory) {
    	super(entitySQLGeneratorMap, sqlExecuterMap, entityResultSetHandlerMap);
    	this.entityFactory = entityFactory;
    }

	@Override
	public void init(GEntity entity, String entityAlias) {
		super.init(entity, entityAlias);
		this.selectColumns = createSelectColumnList(entity, entityAlias);
	}
	
	@Override
	public void clear() {
		joinList.clear();
		selectColumns.clear();
		whereExpression = null;
		groupColumns.clear();
		havingExpression = null;
		orderColumns.clear();
		startRowIndex = 0;
		listSize = -1;
		forUpdateFlg = false;
		noWaiteFlg = false;
		waitTime = -1;
		super.clear();
	}

	// -----------------Join節---------------------------

	@Override
	public List<GJoinData> getJoinList() {
		return joinList;
	}

	/**
	 * 結合情報のリストを設定します.
	 *
	 * @param joinList 結合情報のリスト
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	public void setJoinList(List<GJoinData> joinList) {
		this.joinList = joinList;
	}
	
	@Override
	public GEntitySelect innerJoinFK(String foreignKey, Object... params) {
		return innerJoinFK(foreignKey, null, params);
	}
	
	@Override
	public GEntitySelect innerJoinFK(String foreignKey, String entityAlias, Object... params) {
		addJoinList(JoinType.INNER_JOIN, foreignKey, entityAlias, params);
		return this;
	}

	@Override
	public GEntitySelect innerJoin(String entityId, GExpression exp) {
		return innerJoin(entityId, null, exp);
	}

	@Override
	public GEntitySelect innerJoin(String entityId, String entityAlias, GExpression exp) {
		addJoinList(JoinType.INNER_JOIN, entityId, entityAlias, exp);
		return this;
	}
	
	@Override
	public GEntitySelect leftOuterJoinFK(String foreignKey, Object... params) {
		return leftOuterJoinFK(foreignKey, null, params);
	}

	@Override
	public GEntitySelect leftOuterJoinFK(String foreignKey, String entityAlias, Object... params) {
		addJoinList(JoinType.LEFT_OUTER_JOIN, foreignKey, entityAlias, params);
		return this;
	}

	@Override
	public GEntitySelect leftOuterJoin(String entityId, GExpression exp) {
		return leftOuterJoin(entityId, null, exp);
	}

	@Override
	public GEntitySelect leftOuterJoin(String entityId, String entityAlias, GExpression exp) {
		addJoinList(JoinType.LEFT_OUTER_JOIN, entityId, entityAlias, exp);
		return this;
	}
	
	@Override
	public GEntitySelect rightOuterJoinFK(String foreignKey, Object... params) {
		return rightOuterJoinFK(foreignKey, null, params);
	}

	@Override
	public GEntitySelect rightOuterJoinFK(String foreignKey, String entityAlias, Object... params) {
		addJoinList(JoinType.RIGHT_OUTER_JOIN, foreignKey, entityAlias, params);
		return this;
	}

	@Override
	public GEntitySelect rightOuterJoin(String entityId, GExpression exp) {
		return rightOuterJoin(entityId, null, exp);
	}

	@Override
	public GEntitySelect rightOuterJoin(String entityId, String entityAlias, GExpression exp) {
		addJoinList(JoinType.RIGHT_OUTER_JOIN, entityId, entityAlias, exp);
		return this;
	}

	/**
	 * 結合情報を追加します.
	 *
	 * @param joinType 結合の種類
	 * @param foreignKeyName 外部キー名
	 * @param entityAlias エンティティー別名
	 * @param bindParams バインドパラメータの配列
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected void addJoinList(JoinType joinType, String foreignKeyName, String entityAlias, Object[] bindParams) {
		String ownerTableAlias = null;
		GEntity entity = null;
		if (foreignKeyName.contains(".")) {
			String[] fks = foreignKeyName.split("\\."); 
			ownerTableAlias = fks[0];
			foreignKeyName = fks[1];
			
			for (GJoinData joinData : joinList) {
				if (ownerTableAlias.equals(joinData.getJoinEntityAlias())) {
					entity = joinData.getJoinEntity();
					break;
				}
			}
			if (entity == null) {
				throw new IllegalArgumentException("Entity related with the specified alias does not exist. : " + ownerTableAlias);
			}
		}
		else {
			ownerTableAlias = getEntityAlias();
			entity = getEntity();
		}
		
		GForeignKey foreignKey = entity.getForeignKeys().get(foreignKeyName);
		this.joinList.add(createJoinData(joinType, ownerTableAlias, foreignKey, entityAlias, bindParams));
		
		//SELECT節に全カラムを追加
		this.selectColumns.adds(createSelectColumnList(foreignKey.getReferenceEntity(), entityAlias));
	}
	
	/**
	 * 結合情報のリストを追加します.
	 *
	 * @param joinType 結合種類
	 * @param entityId エンティティーID
	 * @param exp 検索条件
	 * @param entityAlias 別名
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected void addJoinList(JoinType joinType, String entityId, String entityAlias, GExpression exp) {
		GEntity entity = entityFactory.getEntity(entityId);
		this.joinList.add(createJoinData(joinType, entity, entityAlias, exp));
		
		//SELECT節に全カラムを追加
		this.selectColumns.adds(createSelectColumnList(entity, entityAlias));
	}

	// -----------------Select節---------------------------

	@Override
	public GSelectColumnList getSelectColumns() {
		return selectColumns; // TODO クローンのリストを返すように修正
	}

	@Override
	public GEntitySelect fields(GSelectColumnList selectColumns) {
		this.selectColumns = selectColumns;
		return this;
	}

	@Override
	public GEntitySelect fields(String... selectColumns) {
		this.selectColumns.clear();
		for (String columnName : selectColumns) {
			GSelectColumn vc = createSelectColumn(columnName);
			this.selectColumns.add(vc);
		}
		return this;
	}

	@Override
	public GEntitySelect fields(GSelectColumn... selectColumns) {
		this.selectColumns.clear();
		for (GSelectColumn vc : selectColumns) {
			this.selectColumns.add(vc);
		}
		
		return this;
	}
	
	@Override
	public GEntitySelect distinct() {
		this.distinctFlag = true;
		return this;
	}
	
	@Override
	public boolean isDistinct() {
		return this.distinctFlag;
	}
	
	// -----------------Where節---------------------------

	@Override
	public GExpression getWhereExpression() {
		return this.whereExpression;
	}

	@Override
	public GEntitySelect where(GExpression exp) {
		this.whereExpression = exp;
		return this;
	}

	@Override
	public GEntitySelect wherePK(Object... primaryKeyParams) {
		this.whereExpression = new GPKWhereExpression(primaryKeyParams);
		return this;
	}

	@Override
	public GEntitySelect whereUK(String uniqueKeyName, Object... uniqueKeyParams) {
		this.whereExpression = new GUKWhereExpression(uniqueKeyName, uniqueKeyParams);
		return this;
	}

	// -----------------GroupBy節---------------------------

	@Override
	public List<GSelectColumn> getGroupColumns() {
		return this.groupColumns;
	}

	@Override
	public GEntitySelect groupBy(String... columnNames) {
		for (String columnName : columnNames) {
			GSelectColumn vc = createSelectColumn(columnName);
			groupColumns.add(vc);
		}
		return this;
	}

	@Override
	public GEntitySelect groupBy(GSelectColumn... vcolumns) {
		for (GSelectColumn vc : vcolumns) {
			groupColumns.add(vc);
		}
		return this;
	}

	// -----------------Having節---------------------------
	@Override
	public GExpression getHavingExpression() {
		return havingExpression;
	}

	@Override
	public GEntitySelect having(GExpression exp) {
		this.havingExpression = exp;
		return this;
	}

	// -----------------OrderBy節---------------------------

	@Override
	public List<GSelectColumn> getOrderColumns() {
		return orderColumns;
	}

	@Override
	public GEntitySelect orderBy(GSelectColumn... columns) {
		for (GSelectColumn vc : columns) {
			this.orderColumns.add(vc);
		}
		return this;
	}

	// -----------------ForUpdate節---------------------------
	@Override
	public GEntitySelect forUpdate() {
		this.forUpdateFlg = true;
		this.waitTime = -1;
		this.noWaiteFlg = false;
		return this;
	}

	@Override
	public GEntitySelect forUpdateNoWait() {
		this.forUpdateFlg = true;
		this.waitTime = -1;
		this.noWaiteFlg = true;
		return this;
	}

	@Override
	public GEntitySelect forUpdate(int time) {
		this.forUpdateFlg = true;
		this.waitTime = time;
		this.noWaiteFlg = false;
		return this;
	}

	@Override
	public boolean isForUpdate() {
		return this.forUpdateFlg;
	}

	@Override
	public boolean isNoWait() {
		return this.noWaiteFlg;
	}

	@Override
	public int getWaitTime() {
		return this.waitTime;
	}

	// -----------------Rang節---------------------------

	@Override
	public int getStartRowIndex() {
		return startRowIndex;
	}

	/**
	 * 検索結果の開始インデックスを設定します.
	 *
	 * @param startRowIndex 開始インデックス
	 * @author KCCS K.Fujita
	 * @create 2012/10/14
	 * @since 3.12.0
	 */
	public void setStartRowIndex(int startRowIndex) {
		this.startRowIndex = startRowIndex;
	}

	@Override
	public int getListSize() {
		return listSize;
	}

	/**
	 * 取得できる検索結果の件数を設定します.
	 *
	 * @param listSize 取得できる検索結果の件数
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	public void setListSize(int listSize) {
		this.listSize = listSize;
	}

	@Override
	public GEntitySelect range(int startRowIndex, int listSize) {
		this.startRowIndex = startRowIndex;
		this.listSize = listSize;
		return this;
	}

	/**
	 * Connectionを返します。
	 * 
	 * @param dataSourceName データソース名
	 * @return Connection
	 * @throws SQLException SQL例外
	 */
	protected Connection catchConnection(String dataSourceName) throws SQLException {
		GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
		return dataSource.open(dataSourceName);
	}

	/**
	 * Connectionを切断します。
	 * 
	 * @param connection Connection
	 * @throws SQLException SQL例外
	 */
	protected void releaseConnection(Connection connection) throws SQLException {
		GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
		dataSource.close(connection);
	}
	
	//------------------------------find---------------------------------------

	@Override
	public List<GRecord> findList() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return findList(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public List<GRecord> findList(Connection connection) throws SQLException {

		ResultSet resultSet = null;
		try {
			resultSet = getSqlExecuter().executeQuery(connection, createSelectStatement(), getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, null);
			return createRecordList(resultSet);
		} finally {
			close(resultSet);
		}
	}

	@Override
	public GRecordSet findRecordSet() throws SQLException {

		Connection connection = null;
		ResultSet resultSet = null;
		
		try {
			connection = catchConnection(getDatabase().getDataSource());
			resultSet = getSqlExecuter().executeQuery(connection, createSelectStatement(), getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, connection);
			return createRecordSet(resultSet);
		} catch (SQLException e) {
			try {
				close(resultSet);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		} catch (RuntimeException e) {
			try {
				close(resultSet);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		}
	}

	@Override
	public GRecordSet findRecordSet(Connection connection) throws SQLException {

		ResultSet resultSet = null;
		
		try {
			resultSet = getSqlExecuter().executeQuery(connection, createSelectStatement(), getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, null);
			return createRecordSet(resultSet);
		} catch (SQLException e) {
			close(resultSet);
			throw e;
		} catch (RuntimeException e) {
			close(resultSet);
			throw e;
		}
	}

	@Override
	public ResultSet findResultSet() throws SQLException {

		Connection connection = null;
		ResultSet resultSet = null;
		
		try {
			connection = catchConnection(getDatabase().getDataSource());
			resultSet = getSqlExecuter().executeQuery(connection, createSelectStatement(), getQueryTimeout());
			return enhanceResultSet(resultSet, connection);
		} catch (SQLException e) {
			try {
				close(resultSet);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		} catch (RuntimeException e) {
			try {
				close(resultSet);
			} finally {
				releaseConnection(connection);
			}
			throw e;
		}
	}

	@Override
	public ResultSet findResultSet(Connection connection) throws SQLException {

		ResultSet resultSet = null;
		
		try {
			resultSet = getSqlExecuter().executeQuery(connection, createSelectStatement(), getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, null);
			return resultSet;
		} catch (SQLException e) {
			close(resultSet);
			throw e;
		} catch (RuntimeException e) {
			close(resultSet);
			throw e;
		}
	}

	@Override
	public GRecord findRecord() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return findRecord(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public GRecord findRecord(Connection connection) throws SQLException {
		ResultSet resultSet = null;
		try {
			resultSet = getSqlExecuter().executeQuery(connection, createSelectStatement(), getQueryTimeout());
			resultSet = enhanceResultSet(resultSet, null);

			// 結果が複数件得られても最初の1件のみ返す
			if (resultSet.next()) {
				return createRecord(resultSet);
			}
			return null;
		} finally {
			close(resultSet);
		}
	}

	@Override
	public GQueryResult nativeCall() throws SQLException {
		Connection connection = null;
		GQueryResult result = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			result = nativeCall(connection);
			return enhanceQueryResult(result, connection);
		} catch (SQLException e) {
			close(result, connection);
			throw e;
		} catch (RuntimeException e) {
			close(result, connection);
			throw e;
		}
	}

	@Override
	public GQueryResult nativeCall(Connection connection) throws SQLException {

		return getSqlExecuter().execute(connection, createSelectStatement(), getQueryTimeout());
	}

	/**
	 * SQLの実行情報を取得します.
	 * 
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定したSLQ断片
	 * @author KCCS hashimoto
	 * @create 2012/02/01
	 * @since 3.12.0
	 */
	@Override
	public GSQLPiece createSelectStatement() {
		return getSqlGenerator().createSelectStatement(this);
		
	}

	@Override
	public int count() throws SQLException {
		Connection connection = null;
		try {
			connection = catchConnection(getDatabase().getDataSource());
			return count(connection);
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public int count(Connection connection) throws SQLException {
		GSQLPiece piece = getSqlGenerator().createCountStatement(this);
		return getSqlExecuter().executeCount(connection, piece, getQueryTimeout());
	}

	//-------------------------others---------------------------------------
	
	/**
	 * 外部キーを用いて結合を行う場合の結合情報（{@link GForeignKeyJoinData}）を生成します.
	 * 
	 * @param joinType 結合タイプ
	 * @param srcEntityAlias ソースエンティティの別名
	 * @param foreignKey 外部キー
	 * @param refEntityAlias 参照エンティティの別名
	 * @param bindParams バインドパラメータ
	 * @return 外部キーを用いて結合を行う場合の結合情報（{@link GForeignKeyJoinData}）
	 * @author KCCS kitamura
	 * @create 2012/10/03
	 * @since 3.12.0
	 */
	protected GForeignKeyJoinData createJoinData(JoinType joinType, String srcEntityAlias, GForeignKey foreignKey, String refEntityAlias, Object[] bindParams) {
		return new GForeignKeyJoinData(joinType, srcEntityAlias, foreignKey, refEntityAlias, bindParams);
	}
	
	/**
	 * 結合条件式を用いて結合を行う場合の結合情報（{@link GExpressionJoinData}）を生成します.
	 * 
	 * @param joinType 結合タイプ
	 * @param refEntity 参照エンティティ
	 * @param refEntityAlias 参照エンティティのエイリアス
	 * @param expression 条件式
	 * @return  結合条件式を用いて結合を行う場合の結合情報（{@link GExpressionJoinData}）
	 * @author KCCS kitamura
	 * @create 2012/10/03
	 * @since 3.12.0
	 */
	protected GExpressionJoinData createJoinData(JoinType joinType, GEntity refEntity, String refEntityAlias, GExpression expression) {
		return new GExpressionJoinData(joinType, refEntity, refEntityAlias, expression);
	}

	@Override
	public GColumn lookupColumn(String columnName) {
		String[] colNames = columnName.split("\\.");
		String entityAlias = null;
		if (colNames.length > 1) {
			entityAlias = colNames[0];
			columnName = colNames[1];
		}

		GColumn column = null;
		if (entityAlias == null) {
			// エイリアスの指定がなければ、すべてのエンティティの中から一致する項目名の項目を探す(最初に見つかったカラムが優先)
			if (getEntity().getColumns().containsKey(columnName)) {
				column = getEntity().getColumns().get(columnName);
			} else {
				for (GJoinData joinData : getJoinList()) {
					GEntity entity = joinData.getJoinEntity();
					if (entity.getColumns().containsKey(columnName)) {
						column = entity.getColumns().get(columnName);
						break;
					}
				}
			}
		} else {
			// エイリアスの指定があれば、そのエイリアスに該当するエンティティの中から一致する項目名の項目を探す
			if (entityAlias.equals(getEntityAlias())) { // メインエンティティ
				GEntity entity = getEntity();
				column = entity.getColumns().get(columnName);
			} else { // サブエンティティ
				for (GJoinData joinData : getJoinList()) {
					if (entityAlias.equals(joinData.getJoinEntityAlias())) {
						GEntity entity = joinData.getJoinEntity();
						column = entity.getColumns().get(columnName);
						break;
					}
				}
			}
		}

		if (column == null) {
			throw new IllegalStateException("This column does not exist. :" + columnName);
		}
		return column;
	}

	@Override
	public GSelectColumn createSelectColumn(String columnName) {
		String[] colNames = columnName.split("\\.");
		String entityAlias = null;
		if (colNames.length > 1) {
			entityAlias = colNames[0];
		}

		GColumn column = lookupColumn(columnName);

		return new GSelectColumnImpl(entityAlias, column);
	}
	
	@Override
	public GSelectColumn createSelectColumn(String entityAlias, GColumn column) {
		return new GSelectColumnImpl(entityAlias, column);
	}

	@Override
	public GSelectColumn createSelectColumn(GExpression exp) {
		return new GSelectColumnImpl(exp);
	}

	@Override
	public GSelectColumnList createSelectColumnListAll() {
		GSelectColumnList selectColumns = createSelectColumnList(getEntity(), getEntityAlias());
		List<GJoinData> joinList = getJoinList();
		for (GJoinData joinData : joinList) {
			selectColumns.adds(createSelectColumnList(joinData.getJoinEntity(), joinData.getJoinEntityAlias()));
		}
		return selectColumns;
	}

	@Override
	public GSelectColumnList createSelectColumnList(String entityName) {
		if (entityName.equals(getEntityAlias())) {
			// メインエイリアス
			return createSelectColumnList(getEntity(), getEntityAlias());
		}
		else {
			for (GJoinData joinData : getJoinList()) {
				if (entityName.equals(joinData.getJoinEntityAlias())) {
					// サブエイリアス
					return createSelectColumnList(joinData.getJoinEntity(), joinData.getJoinEntityAlias());
				}
			}
		}
		
		GEntity entity = entityFactory.getEntity(entityName);
		
		if (getEntity().getName().equals(entity.getName())) {
			// メインテーブル名
			return createSelectColumnList(getEntity(), null);
		}
		else {
			for (GJoinData joinData : getJoinList()) {
				if (joinData.getJoinEntity().getName().equals(entity.getName())) {
					// サブテーブル名
					return createSelectColumnList(joinData.getJoinEntity(), null);
				}
			}
		}
		
		throw new IllegalArgumentException("This alias does not exist. : " + entityName);
	}

	@Override
	public GSelectColumnList createSelectColumnList(GEntity entity, String entityAlias) {
		GSelectColumnList selectColumns = createSelectColumnList();
		Iterator<GColumn> itr = entity.getColumns().iterator();
		while (itr.hasNext()) {
			GColumn column = itr.next();
			GSelectColumn vc = createSelectColumn(entityAlias, column);
			selectColumns.add(vc);
		}
		return selectColumns;
	}

	@Override
	public GSelectColumnList createSelectColumnList() {
		return new GSelectColumnListImpl(this);
	}

	/**
	 * ステートメントと結果セットをクローズします.
	 *
	 * @param statement クローズするステートメント
	 * @param resultSet クローズする結果セット
	 * @throws SQLException クローズに失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected void close(Statement statement, ResultSet resultSet) throws SQLException {
		try {
			close(resultSet);
		} finally {
			close(statement);
		}
	}

	/**
	 * 結果セットをクローズします.
	 *
	 * @param resultSet クローズする結果セット
	 * @throws SQLException 結果セットのクローズに失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected void close(ResultSet resultSet) throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
	}

	@Override
	public GEntitySelect union(GSelect<?> select) {
		addUnion(select, false);
		return this;
	}

	@Override
	public GEntitySelect unionAll(GSelect<?> select) {
		addUnion(select, true);
		return this;
	}

	/**
	 * ユニオン項目のリストに新しい項目を追加します。
	 * 
	 * @param select Unionで結合する情報を保持する{@link GEntitySelect}
	 * @param unionAllFlg <code>true</code>ならUnion All／<code>false</code>ならUnion
	 * @author yamashita
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	protected void addUnion(GSelect<?> select, boolean unionAllFlg) {
		this.unionList.add(new GPair<GSelect<?>, Boolean>(select, unionAllFlg));
	}

	@Override
	public List<GPair<GSelect<?>, Boolean>> getUnionList() {
		return this.unionList;
	}

	@Override
	public GRecord createRecord(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecord(this, resultSet);
	}

	@Override
	public List<GRecord> createRecordList(ResultSet resultSet, int startRowIndex, int listSize) throws SQLException {
		return getResultSetHandler().createRecordList(this, resultSet, startRowIndex, listSize);
	}
	
	@Override
	public List<GRecord> createRecordList(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecordList(this, resultSet);
	}

	@Override
	public GRecordSet createRecordSet(ResultSet resultSet) throws SQLException {
		return getResultSetHandler().createRecordSet(this, resultSet);
	}
}
