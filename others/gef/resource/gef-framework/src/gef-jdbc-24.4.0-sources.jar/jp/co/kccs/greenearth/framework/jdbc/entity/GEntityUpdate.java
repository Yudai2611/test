/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.util.List;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;

/**
 * UPDATE文を構築するインタフェースです。
 * <p>
 * UPDATE文を構築するために必要なメソッドを提供します。<br>
 * このインタフェースで提供しているメソッドを組み合わせて使用することで、直接SQLを記述することなくUPDATE文を構築することができます。<br>
  * <p>
 * 主に以下の操作が実現できます。<br>
 * <ol type="1">
 * <li>主キーを検索条件に利用して1行を更新する</li>
 * <li>ユニークキーを検索条件に利用して1行を更新する</li>
 * <li>任意の条件で更新する</li>
 * <li>主キーまたはユニークキーを検索条件に利用して複数行を更新する</li>
 * </ol>
 * <p>
 * 構築したUPDATE文はスーパーインタフェース{@link GEntityCUD}、または{@link GQuery}のメソッドを使用して実行します。<br>
 * 更新対象テーブルの定義はエンティティー定義ファイルとして作成しておく必要があります。
 * <p>
 * 代表的な使用方法を下記に示します。
 * <p>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">主キーを検索条件に利用して1行を更新する</td></tr>
 * <tr>
 * <td><pre>int count =
 *     update("entity")
 *         .set(record)
 *         .wherePK()
 *         .execute();</pre>
 * </td>
 * <td><pre><b>UPDATE</b> physicalTable
 *   <b>SET</b> columnPK = 'value1',
 *       columnB = 'value2'
 * <b>WHERE</b> columnPK = 'value1';</pre></td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">ユニークキーを検索条件に利用して1行を更新する</td></tr>
 * <tr>
 * <td><pre>int count =
 *     update("entity")
 *         .set(record)
 *         .whereUK("uniqueKey")
 *         .execute();</pre>
 * </td>
 * <td><pre><b>UPDATE</b> physicalTable
 *   <b>SET</b> columnUNQ = 'value1',
 *       columnB = 'value2'
 * <b>WHERE</b> columnUNQ = 'value1';</pre></td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">任意の検索条件で更新する</td></tr>
 * <tr>
 * <td><pre>int count =
 *     update("entity")
 *         .set(record)
 *         .where(exp("columnA = ?", "value00"))
 *         .execute();</pre>
 * </td>
 * <td>
 * <pre><b>UPDATE</b> physicalTable
 *   <b>SET</b> columnA = 'value1',
 *       columnB = 'value2'
 * <b>WHERE</b> columnA = 'value00';</pre>
 * </td>
 * </tr>
 * <tr bgcolor="#cccccc"><td colspan="2">主キーまたはユニークキーを検索条件に利用して複数行を更新する</td></tr>
 * <tr>
 * <td>
 * <pre>int count =
 *     update("entity")
 *         .set(recordList)
 *         .wherePK()
 *         .executeList();</pre>
 * </td>
 * <td><pre><b>UPDATE</b> physicalTable
 *   <b>SET</b> columnPK = 'value1',
 *       columnB = 'value2'
 * <b>WHERE</b> columnPK = 'value1';
 *<b>UPDATE</b> physicalTable
 *   <b>SET</b> columnPK = 'value3',
 *       columnB = 'value4'
 * <b>WHERE</b> columnPK = 'value3';
 * ・・・</pre>
 * </td>
 * </tr>
 * </table>
 * <br>
 * 
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public interface GEntityUpdate extends GEntityCUD<GEntityUpdate> {

	/**
	 * SET節を構築します。
	 * <p>
	 * 1行を更新する場合にこのメソッドを使用します。
	 * <p>
	 * 構築したUPDATE文の実行は{@link #execute()}を使用してください。
	 * 
	 * @param record 1行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityUpdate set(GRecord record);

	/**
	 * SET節を構築します。
	 * <p>
	 * 複数件のUPDATE文を更新する場合にこのメソッドを使用します。
	 * <p>
	 * UPDATE文の検索条件は主キーあるいはユニークキーである必要があります。<br>
	 * {@link #wherePK()}または{@link #whereUK(String)}と組み合わせて使用してください。
	 * 引数の複数行レコードが1行づつUPDATE文にバインドされます。<p>
	 * <br>
	 * 
	 * 構築したUPDATE文の実行は{@link #executeList()}や{@link #executeBatch()}を使用してください。
	 * 
	 * @param recordList 複数行レコード
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityUpdate set(List<GRecord> recordList);

	/**
	 * WHERE節を主キーを検索条件として構築します。
	 * <p>
	 * 主キーを検索条件に利用して1行を更新する場合にこのメソッドを使用します。<br>
	 * 主キーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 定義されていない場合は{@link IllegalStateException}が発生します。
	 * 
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	GEntityUpdate wherePK();

	/**
	 * WHERE節をユニークキーを検索条件として構築します。
	 * <p>
	 * ユニークキーを検索条件に利用して1行を更新する場合にこのメソッドを使用します。<br>
	 * ユニークキーの名前はエンティティー定義ファイルに定義する名前です。<br>
	 * ユニークキーはエンティティー定義ファイルで定義しておく必要があります。<br>
	 * 定義されていない場合は{@link IllegalStateException}が発生します。
	 *
	 * @param uniqueKeyName ユニークキーの名前
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2013/01/30
	 * @since 3.12.0
	 */
	GEntityUpdate whereUK(String uniqueKeyName);

	/**
	 * WHERE節を任意の検索条件で構築します。
	 * <p>
	 * このメソッドを使用する場合、楽観的排他は有効になりません。<br>
	 * （更新対象が複数行になる可能性があるため。）
	 * 
	 * @param exp 任意の検索条件
	 * @return このインスタンス自身
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	GEntityUpdate where(GExpression exp);

	/**
	 * 指定したカラムでUPDATE文を構築します。
	 * <p>
	 * エンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * <p>
	 * {@link #excludes(String...)}と組み合わせて使用することはできません。<br>
	 * 使用した場合は{@link IllegalArgumentException}が発生します。
	 * <p>
	 * 楽観的排他が有効の場合、排他処理で使用するカラムはこのメソッドでの指定に関わらず必ず更新対象に含めます。
	 * 
	 * @param includes カラムの論理名
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GEntityUpdate includes(String... includes);

	/**
	 * 指定したカラム以外でUPDATE文を構築します。
	 * <p>
	 * エンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * <p>
	 * {@link #includes(String...)}と組み合わせて使用することはできません。<br>
	 * 使用した場合は{@link IllegalArgumentException}が発生します。
	 * <p>
	 * 楽観的排他が有効の場合、このメソッドでの指定に関わらず排他処理で使用するカラムは必ず更新対象に含めます。
	 * 
	 * @param excludes カラムの論理名
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GEntityUpdate excludes(String... excludes);
	
	/**
	 * 値がNULLであるカラムが存在する場合は、そのカラム以外でUPDATE文を構築します。<br>
	 * <p>
	 * {@link #executeBatch()}または{@link #executeBatch(java.sql.Connection)}を組み合わせて使用することはできません。<br>
	 * 使用した場合は{@link IllegalArgumentException}が発生します。
	 * <p>
	 * 楽観的排他が有効の場合、このメソッドでの指定に関わらず排他処理で使用するカラムは必ず更新対象に含めます。
	 * 
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GEntityUpdate excludesNull();
	
	/**
	 * 楽観的排他を無効にします。
	 * <p>
	 * エンティティー定義ファイルで楽観的排他が有効に設定されている場合でも、<br>
	 * このメソッドを使用することにより楽観的排他を無効にすることができます。
	 * 
	 * @return このインスタンス自身
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GEntityUpdate nonexclusive();

	/**
	 * 値がNULLであるカラムを除外するかどうか判定します。
	 * 
	 * @return 値がNULLであるカラムを除外する場合は{@code true}。そうでない場合は{@code false}。
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	boolean isExcludesNull();
	
	/**
	 * 楽観的排他が有効かどうか判定します。
	 * 
	 * @return 楽観的排他が有効である場合は{@code true}。そうでない場合は{@code false}。
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	boolean isExclusive();

	/**
	 * UPDATE文構築で使用するカラムを取得します。
	 * <p>
	 * {@link #includes(String...)}、{@link #excludes(String...)}、{@link #excludesNull()}の設定を考慮したカラムを返します。
	 * 
	 * @return カラムのマップ
	 * @author KCCS hashimoto
	 * @create 2012/11/02
	 * @since 3.12.0
	 */
	GListMap<String, GColumn> getUpdateColumns();
	
	/**
	 * WHERE節に設定された検索条件を取得します。
	 * 
	 * @return 検索条件
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	GExpression getWhereExpression();
}