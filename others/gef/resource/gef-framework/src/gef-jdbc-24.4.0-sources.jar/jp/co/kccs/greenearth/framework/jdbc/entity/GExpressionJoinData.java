/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;

/**
 * 結合条件式を用いて結合を行う場合に用いる結合情報を表すクラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2013/03/29
 * @since 3.12.0
 */
public class GExpressionJoinData extends GJoinDataBase implements GJoinData {
	/** 結合条件式 */
	private GExpression expression;
	
	/**
	 * 結合条件式を用いて結合を行う場合の{@link GJoinData}のインスタンスを生成します.
	 * 
	 * @param joinType 結合の種類
	 * @param joinEntity 結合するエンティティ
	 * @param joinEntityAlias 結合するエンティティの別名
	 * @param expression 結合条件式
	 * @author KCCS fujtia
	 * @create 2013/03/09
	 * @since 3.12.0
	 */
	public GExpressionJoinData(JoinType joinType, GEntity joinEntity, String joinEntityAlias, GExpression expression) {
		super(joinType, joinEntity, joinEntityAlias);
		this.expression = expression;
	}

	/**
	 * 結合条件式を取得します.
	 * 
	 * @return 結合条件式
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public GExpression getExpression() {
		return this.expression;
	}

	/**
	 * 結合条件式を設定します.
	 * 
	 * @param expression 結合条件式
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public void setExpression(GExpression expression) {
		this.expression = expression;
	}
}
