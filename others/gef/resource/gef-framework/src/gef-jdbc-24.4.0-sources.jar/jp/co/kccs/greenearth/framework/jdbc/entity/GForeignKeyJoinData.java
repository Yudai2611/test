/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GForeignKey;

/**
 * 外部キーを用いて結合を行う場合に用いる結合情報を表すクラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2013/03/29
 * @since 3.12.0
 */
public class GForeignKeyJoinData extends GJoinDataBase implements GJoinData {
	
	/** メインエンティティの別名 */
	private String mainEntityAlias;
	/** 外部キー */
	private GForeignKey foreignKey;
	/** バインドパラメータ */
	private Object[] bindParams;
	
	/**
	 * 外部キーを用いて結合を行う場合の{@link GJoinData}のインスタンスを生成します.
	 * 
	 * @param joinType 結合の種類
	 * @param mainEntityAlias メインエンティティの別名
	 * @param foreignKey 外部キー
	 * @param joinEntityAlias 結合するエンティティの別名
	 * @param bindParams バインドパラメータ
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public GForeignKeyJoinData(JoinType joinType, String mainEntityAlias, GForeignKey foreignKey, String joinEntityAlias, Object[] bindParams) {
		super(joinType, foreignKey.getReferenceEntity(), joinEntityAlias);
		this.mainEntityAlias = mainEntityAlias;
		this.foreignKey = foreignKey;
		this.bindParams = bindParams;
	}

	/**
	 * メインエンティティの別名を取得します.
	 * 
	 * @return メインエンティティの別名
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public String getMainEntityAlias() {
		return this.mainEntityAlias;
	}

	/**
	 * メインエンティティの別名を設定します.
	 * 
	 * @param mainEntityAlias メインエンティティの別名
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public void setMainEntityAlias(String mainEntityAlias) {
		this.mainEntityAlias = mainEntityAlias;
	}

	/**
	 * 外部キーを取得します.
	 * 
	 * @return 外部キー
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public GForeignKey getForeignKey() {
		return this.foreignKey;
	}

	/**
	 * 外部キーを設定します.
	 * 
	 * @param foreignKey 外部キー
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public void setForeignKey(GForeignKey foreignKey) {
		this.foreignKey = foreignKey;
	}

	/**
	 * バインドパラメータを取得します.
	 * 
	 * @return バインドパラメータ
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public Object[] getBindParams() {
		return this.bindParams;
	}

	/**
	 * バインドパラメータを設定します.
	 * 
	 * @param bindParams バインドパラメータ
	 * @author KCCS fujtia
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public void setBindParams(Object[] bindParams) {
		this.bindParams = bindParams;
	}
}
