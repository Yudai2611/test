/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;

/**
 * 結合情報を表すインタフェースです。
 * 
 * @author KCCS kitamura
 * @create 2012/10/09
 * @since 3.12.0
 */
public interface GJoinData {

	/**
	 * 結合種類。
	 * <ol>
	 * <li>{@link #INNER_JOIN}</li>
	 * <li>{@link #LEFT_OUTER_JOIN}</li>
	 * <li>{@link #RIGHT_OUTER_JOIN}</li>
	 * </ol>
	 * 
	 * @author KCCS fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public enum JoinType {
		/** 内部結合 */
		INNER_JOIN("INNER JOIN"),
		/** 左外部結合 */
		LEFT_OUTER_JOIN("LEFT OUTER JOIN"),
		/** 右外部結合 */
		RIGHT_OUTER_JOIN("RIGHT OUTER JOIN");

		/** 結合の種類 */
		private String phrase;

		/**
		 * 結合の種類を設定するコンストラクタです。
		 * 
		 * @param phrase 結合の種類
		 * @author KCCS K.Fujita
		 * @create 2012/10/09
		 * @since 3.12.0
		 */
		JoinType(String phrase) {
			this.phrase = phrase;
		}

		/**
		 * 結合の種類を取得します。
		 * 
		 * @return 結合の種類
		 * @author KCCS fujita
		 * @create 2012/10/09
		 * @since 3.12.0
		 */
		public String getPhrase() {
			return phrase;
		}
	}

	/**
	 * 結合先エンティティーを取得します。
	 * 
	 * @return 結合先エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GEntity getJoinEntity();

	/**
	 * 結合先エンティティーを設定します。
	 * 
	 * @param refEntity 結合先エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setJoinEntity(GEntity refEntity);

	/**
	 * 結合先エンティティーの別名を取得します。
	 * 
	 * @return 結合先エンティティーの別名
	 * @author KCCS fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	String getJoinEntityAlias();

	/**
	 * 結合先エンティティーの別名を設定します。
	 * 
	 * @param refEntityAlias 結合先エンティティーの別名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setJoinEntityAlias(String refEntityAlias);

	/**
	 * 結合の種類を取得します。
	 * 
	 * @return 結合の種類
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	JoinType getJoinType();

	/**
	 * 結合の種類を設定します。
	 * 
	 * @param joinType 結合の種類
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setJoinType(JoinType joinType);
}