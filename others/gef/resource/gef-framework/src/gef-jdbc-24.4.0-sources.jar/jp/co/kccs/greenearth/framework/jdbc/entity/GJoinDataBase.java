/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;


/**
 * {@link GJoinData}を実装する基底クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2013/03/29
 * @since 3.12.0
 */
public abstract class GJoinDataBase implements GJoinData {
	
	/** 結合の種類 */
	protected JoinType joinType;
	/** 結合するエンティティ */
	protected GEntity joinEntity;
	/** 結合するエンティティの別名 */
	protected String joinEntityAlias;
	
	/**
	 * {@link GJoinDataBase}を初期化します.
	 * 
	 * @param joinType 結合の種類
	 * @param joinEntity サブエンティティ
	 * @param joinEntityAlias サブエンティティの別名
	 * @author KCCS K.Fujita
	 * @create 2013/03/29
	 * @since 3.12.0
	 */
	protected GJoinDataBase(JoinType joinType, GEntity joinEntity, String joinEntityAlias) {
		this.joinType = joinType;
		this.joinEntity = joinEntity;
		this.joinEntityAlias = joinEntityAlias;
	}

	@Override
	public JoinType getJoinType() {
		return this.joinType;
	}

	@Override
	public void setJoinType(JoinType joinType) {
		this.joinType = joinType;
	}
	
	@Override
	public GEntity getJoinEntity() {
		return joinEntity;
	}

	@Override
	public void setJoinEntity(GEntity joinEntity) {
		this.joinEntity = joinEntity;
	}
	
	@Override
	public String getJoinEntityAlias() {
		return this.joinEntityAlias;
	}

	@Override
	public void setJoinEntityAlias(String joinEntityAlias) {
		this.joinEntityAlias = joinEntityAlias;
	}

}
