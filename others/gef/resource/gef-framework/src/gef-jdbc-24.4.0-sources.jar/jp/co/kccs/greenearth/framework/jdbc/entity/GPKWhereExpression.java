/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;

/**
 * 主キーで検索する際の検索条件を表すクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GPKWhereExpression implements GExpression {
	
	/** 主キーのパラメータ群 */
	private Object[] primaryKeys = null;
	/** 検索条件の指定にGRecordを使用するかどうかを表す */
	private boolean useRecord = false;
	
	/**
	 * {@link GPKWhereExpression}を初期化します.
	 * 
	 * @param primaryKeys 主キーのパラメータ群
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GPKWhereExpression(Object[] primaryKeys) {
		this.primaryKeys = primaryKeys;
	}
	
	/**
	 * {@link GPKWhereExpression}を初期化します.
	 * 
	 * @param useRecord 検索条件の指定にGRecordを使用する場合は<code>true</code>／使用しない場合は<code>false</code>
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GPKWhereExpression(boolean useRecord) {
		this.useRecord = useRecord;
	}
	
	/**
	 * 主キーのパラメータ群を取得します.
	 * 
	 * @return 主キーのパラメータ群
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public Object[] getPrimaryKeys() {
		return primaryKeys;
	}

	/**
	 * 主キーのパラメータ群を設定します.
	 * 
	 * @param primaryKeys 主キーのパラメータ群
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setPrimaryKeys(Object[] primaryKeys) {
		this.primaryKeys = primaryKeys;
	}
	
	/**
	 * 検索条件の指定にGRecordを使用するか否かを取得します.
	 * 
	 * @return 検索条件の指定にGRecordを使用する場合は<code>true</code>／使用しない場合は<code>false</code>
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public boolean isUseRecord() {
		return useRecord;
	}
	
	/**
	 * 検索条件の指定にGRecordを使用するか否かを設定します.
	 * 
	 * @param useRecord 検索条件の指定にGRecordを使用する場合は<code>true</code>／使用しない場合は<code>false</code>
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setUseRecord(boolean useRecord) {
		this.useRecord = useRecord;
	}

}
