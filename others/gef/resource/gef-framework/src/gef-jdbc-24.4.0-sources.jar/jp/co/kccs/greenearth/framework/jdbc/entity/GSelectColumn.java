/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;

/**
 * SELECT文構築で使用するカラムを表すインタフェースです。
 * <p>
 * SELECT文を構築する際にカラムを扱いやすくするよう{@ GColumn}をラップするためのインタフェースです。<br>
 * {@ GColumn}はエンティティー定義から定義がロードされたカラムを表しますが、このカラムにエンティティーの別名や関数を付与することができます。<br>
 * SELECT文のSELECT節、ORDER BY節、GROUP BY節でのカラムの構築に使用します。
 * 
 * @author KCCS kitamura
 * @create 2012/12/01
 * @since 3.12.0
 */
public interface GSelectColumn {

	/**
	 * ソート順を表す列挙型。
	 * <ol>
	 * <li>{@link #ASC}</li>
	 * <li>{@link #DESC}</li>
	 * </ol>
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public enum OrderType {
		/** 昇順 */
		ASC,
		/** 降順 */
		DESC;
	}

	/**
	 * カラムの別名を取得します。
	 * <p>
	 * デフォルト値はNULLです。
	 * 
	 * @return カラムの別名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	String getAlias();

	/**
	 * カラムの別名を設定します。
	 * 
	 * @param alias カラムの別名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setAlias(String alias);

	/**
	 * カラムに設定されている関数のタイプを取得します。
	 * <P>
	 * 列挙型{@link FuncType}から選択された関数のタイプが設定されています。<br>
	 * デフォルト値はNULLです。
	 * 
	 * @return カラムに設定されている関数
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	FuncType getFuncType();

	/**
	 * カラムに関数のタイプを設定します。
	 * <p>
	 * SQL構築の際に、ここで設定された関数のタイプから判断しカラムに関数を付与します。
	 * 
	 * @param funcType カラムに設定する関数
	 * <p>
	 * 列挙型{@link FuncType}から関数のタイプを選択してください。
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setFuncType(FuncType funcType);

	/**
	 * カラムとして設定された{@link GExpression}を取得します。
	 * <p>
	 * デフォルト値はNULLです。
	 * 
	 * @return カラムとして設定された{@link GExpression}
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	GExpression getExpression();

	/**
	 * カラムとして{@link GExpression}を設定します。
	 * 
	 * @param exp カラムとして使用する{@link GExpression}
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	void setExpression(GExpression exp);

	/**
	 * ORDER BY節で使用するソート順を取得します。
	 * <p>
	 * 列挙型{@link OrderType}から選択されたソート順のタイプが設定されています。<br>
	 * デフォルト値はNULLです。
	 * 
	 * @return ソート順
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	OrderType getOrderType();

	/**
	 * ORDER BY節で使用するソート順を設定します。
	 * <p>
	 * 列挙型{@link OrderType}からソート順のタイプを選択してください。
	 * 
	 * @param orderType ソート順
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	void setOrderType(OrderType orderType);

	/**
	 * エンティティー別名を設定します。
	 * <p>
	 * このカラムを保持するエンティティーの別名を取得します。
	 * 
	 * @param entityAlias エンティティー別名
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	void setEntityAlias(String entityAlias);

	/**
	 * エンティティーの別名を取得します。
	 * <p>
	 * このカラムを保持するエンティティーの別名を取得します。
	 * デフォルト値はNULLです。
	 * 
	 * @return エンティティーの別名
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	String getEntityAlias();

	/**
	 * {@link GColumn}を設定します。
	 * 
	 * @param column カラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	void setColumn(GColumn column);

	/**
	 * {@link GColumn}を取得します。
	 * <p>
	 * このインスタンスに保持している{@link GColumn}を返します。
	 * デフォルト値はNULLです。
	 * 
	 * @return カラム
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	GColumn getColumn();

	/**
	 * 結果セットからカラムを取得するためのキーを取得します。
	 * <p>
	 * 結果セットからカラムを取得するためにはキーが必要であり、このメソッドを通じてそのキーを取得します。<br>
	 * このインスタンスに保持している{@link GColumn}のカラム名がキーになります。<br>
	 * ただし、{@link GColumn}に別名が付けられている場合は別名をキーとします。
	 * 
	 * @return カラム名または別名
	 * @author KCCS K.Fujita
	 * @create 2012/11/01
	 * @since 3.12.0
	 */
	String getResultSetKey();
	
	/**
	 * {@link GSelectColumn}が保持するカラムのデータ型を取得します。
	 * <p>
	 * @return {@link GSelectColumn}のカラムのデータ型
	 * @author Hashimoto
	 * @create 2016/02/16
	 * @since 3.17.0
	 */
	GColumnType getType();

	/**
	 * {@link Golumn}が保持するカラムのデータ型を取得します。
	 * 
	 * @return {@link Golumn}のカラムのデータ型
	 * @author Hashimoto
	 * @create 2016/02/16
	 * @since 3.17.0
	 */
	GColumnType getColumnType();
}