/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;

/**
 * {@link GSelectColumn}インターフェースの実装クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/11
 * @since 3.12.0
 */
public class GSelectColumnImpl implements GSelectColumn {

	/** エンティティー別名 */
	private String entityAlias = null;
	/** カラム情報 */
	private GColumn column = null;
	/** 項目別名 */
	private String alias = null;
	/** カラムに設定されている関数 */
	private FuncType func = null;
	/** ＳＱＬ情報 */
	private GExpression exp = null;
	/** ソート順 */
	private OrderType order = null;

	/**
	  * {@link GSelectColumnImpl}のインスタンスを生成します.
	  * 
	  * @param entityAlias エンティティー別名
	  * @param column カラム情報
	  * @author KCCS fuzita
	  * @create 2012/12/04
	  * @since 3.12.0
	  */
	public GSelectColumnImpl(String entityAlias, GColumn column) {
		this.entityAlias = entityAlias;
		this.column = column;
	}

	/**
	  * {@link GSelectColumnImpl}のインスタンスを生成します.
	  * 
	  * @param exp カラム情報が設定された{@link GExpression}のインスタンス
	  * @author KCCS fuzita
	  * @create 2012/12/04
	  * @since 3.12.0
	  */
	public GSelectColumnImpl(GExpression exp) {
		this.exp = exp;
	}

	@Override
	public String getAlias() {
		return alias;
	}

	@Override
	public void setAlias(String alias) {
		this.alias = alias;
	}

	@Override
	public FuncType getFuncType() {
		return func;
	}

	@Override
	public void setFuncType(FuncType func) {
		this.func = func;
	}

	@Override
	public GExpression getExpression() {
		return this.exp;
	}

	@Override
	public void setExpression(GExpression exp) {
		this.exp = exp;
	}

	@Override
	public OrderType getOrderType() {
		return order;
	}

	@Override
	public void setOrderType(OrderType order) {
		this.order = order;
	}

	@Override
	public String getEntityAlias() {
		return entityAlias;
	}

	@Override
	public void setEntityAlias(String entityAlias) {
		this.entityAlias = entityAlias;
	}

	@Override
	public GColumn getColumn() {
		return column;
	}

	@Override
	public void setColumn(GColumn column) {
		this.column = column;
	}

	@Override
	public String getResultSetKey() {
		if (getAlias() != null) {
			return getAlias();
		} else if (getColumn() != null) {
			return getColumn().getName();
		} else {
			throw new IllegalStateException("Column alias need to be specified.");
		}
	}
	
	/**
	 * {@link GSelectColumn}が保持するカラムのデータ型を取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、Columnタグのtype属性の値であり、<br>
	 * {@link GColumnType}の定数で設定されたものです。<br>
	 * 
	 * COUNT関数が指定された場合には、NUMERIC型を固定で返します。<br>
	 * これは日付型など、数値型以外のカラムにCOUNT関数を付与した場合に、
	 * エラーとなるのを回避し、数値型で値を返却するための実装です。<br>
	 * 
	 * @return {@link GSelectColumn}のカラムのデータ型
	 * @author Hashimoto
	 * @create 2016/02/16
	 * @since 3.17.0
	 */
	@Override
	public GColumnType getType() {
		return FuncType.COUNT.equals(getFuncType()) ? GColumnType.NUMERIC : getColumnType();
	}
	
	/**
	 * {@link Golumn}が保持するカラムのデータ型を取得します。<br>
	 * <p>
	 * {@link Golumn}からデータ型を直接取得します。<br>
	 * {@link Golumn}がnullの場合は、nullを返却します。<br>
	 * 
	 * @return {@link GSelectColumn}のカラムのデータ型
	 * @author Hashimoto
	 * @create 2016/02/16
	 * @since 3.17.0
	 */
	@Override
	public GColumnType getColumnType() {
		return column == null ? null : column.getType();
	}
}
