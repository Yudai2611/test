/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.util.List;
import java.util.Set;

import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;

/**
 * SELECT文構築で使用するカラムのリスト表すインタフェースです。
 * 
 * このインタフェースは{@link GSelectColumn}をリストするための機能を提供します。
 * {@link GSelectColumn}をリストすることでカラムを一括して扱うことができるようになります。
 * 
 * @author KCCS kitamura
 * @create 2012/12/01
 * @since 3.12.0
 */
public interface GSelectColumnList extends List<GSelectColumn> {
	
	/**
	 * {@link GSelectColumn}を生成してリストに追加します。
	 * <p>
	 * エンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * 指定したカラムの論理名から{@link GSelectColumn}を生成しリストに追加します。
	 * 
	 * @param columns カラムの論理名
	 * @return このインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList adds(String... columns);
	
	/**
	 * {@link GSelectColumn}をリストに追加します。
	 * 
	 * @param vcolumns 追加するカラム
	 * @return このインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList adds(GSelectColumn... vcolumns);
	
	/**
	 * {@link GSelectColumnList}をリストに追加します。
	 * 
	 * @param lists 追加するカラムリスト
	 * @return このインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList adds(GSelectColumnList... lists);
	
	/**
	 * リストからカラムを削除します。
	 * <p>
	 * <p>
	 * カラム名はエンティティー定義ファイルに定義するカラムの論理名で指定しまが、別名が付けられている場合は別名を指定します。
	 * 
	 * @param keys 削除するカラム名
	 * @return このインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList removes(String... keys);
	
	/**
	 * カラムに別名を設定します。
	 * <p>
	 * カラム名はエンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * 
	 * @param columnName カラムの論理名
	 * @param alias カラムの別名
	 * @return このインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList set(String columnName, String alias);
	
	/**
	 * カラムに関数を設定します。
	 * <p>
	 * カラム名はエンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * 
	 * @param columnName カラムの論理名
	 * @param funcType 関数のタイプ
	 * <p>
	 * 列挙型{@link FuncType}から関数のタイプを選択してください。
	 * @return このインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList set(String columnName, FuncType funcType);
	
	/**
	 * カラムに別名と関数を設定します。
	 * <p>
	 * カラム名はエンティティー定義ファイルに定義するカラムの論理名で指定します。
	 * 
	 * @param columnName カラム名
	 * @param alias 別名
	 * @param funcType 関数のタイプ
	 * <p>
	 * 列挙型{@link FuncType}から関数のタイプを選択してください。
	 * @return このインスタンス自身
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumnList set(String columnName, String alias, FuncType funcType);
	
	/**
	 * リストを初期化します。
	 * 
	 * リストを空の状態に戻します。
	 * 
	 * @see java.util.List#clear()
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	@Override
	void clear();
	
	/**
	 * カラムを取得します。
	 * <p>
	 * カラム名はエンティティー定義ファイルに定義するカラムの論理名で指定しまが、別名が付けられている場合は別名を指定します。
	 * 
	 * @param columnName カラム名
	 * @return カラム
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	GSelectColumn get(Object columnName);

	/**
	 * カラムがリストに含まれているかどうかを調べます。
	 * <p>
	 * カラム名はエンティティー定義ファイルに定義するカラムの論理名で指定しまが、別名が付けられている場合は別名を指定します。
	 * 
	 * @param columnName カラム名
	 * @return リストにカラムが含まれている場合は{@code true}. そうでない場合は{@code false}.
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	boolean containsKey(Object columnName);

	/**
	 * カラム名のセットを取得します。
	 * 
	 * @return カラム名のセット
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	Set<String> keySet();
}