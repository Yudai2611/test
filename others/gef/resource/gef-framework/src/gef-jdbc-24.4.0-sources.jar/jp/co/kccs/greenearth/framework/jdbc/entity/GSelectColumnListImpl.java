/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;

/**
 * {@link GSelectColumnList}インターフェースの実装クラスです.
 *
 * @author KCCS K.Fujita
 * @create 2012/10/11
 * @since 3.12.0
 */
public class GSelectColumnListImpl extends LinkedList<GSelectColumn> implements GSelectColumnList {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = -6405577011624232732L;

	/**
	 * 検索で使用するカラムを格納するマップ.<br/>
	 * キー : カラム名、値 : 検索で使用するカラム（{@link GSelectColumn}）<br/>
	 */
	private Map<String, GSelectColumn> nameMap = new HashMap<String, GSelectColumn>();
	
	/** エンティティー情報 */
	private GEntitySelect ve = null;
	
	/**
	 * 参照するエンティティーを指定して{@link GSelectColumnListImpl}を初期化します.
	 * 
	 * @param ve 参照するエンティティー
	 * @author KCCS kitamura
	 * @create 2012/12/01
	 * @since 3.12.0
	 */
	public GSelectColumnListImpl(GEntitySelect ve) {
		this.ve = ve;
	}

	// --------------------オリジナルメソッド-------------------------------------

	@Override
	public GSelectColumn get(Object columnName) {
		return nameMap.get(columnName);
	}

	@Override
	public boolean containsKey(Object columnName) {
		return nameMap.containsKey(columnName);
	}

	@Override
	public Set<String> keySet() {
		return nameMap.keySet();
	}
	
	@Override
	public GSelectColumnList adds(String... columns) {
		for (String col : columns) {
			add(ve.createSelectColumn(col));
		}
		return this;
	}

	@Override
	public GSelectColumnList adds(GSelectColumn... vcolumns) {
		for (GSelectColumn vc : vcolumns) {
			add(vc);
		}
		return this;
	}
	
	@Override
	public GSelectColumnList adds(GSelectColumnList... lists) {
		for (GSelectColumnList list : lists) {
			for (GSelectColumn vc : list) {
				add(vc);
			}
		}
		return this;
	}
	
	@Override
	public GSelectColumnList removes(String... keys) {
		for (String key : keys) {
			GSelectColumn vc = nameMap.get(key);
			this.remove(vc);
		}
		return this;
	}
	
	@Override
	public GSelectColumnList set(String columnName, String alias) {
		GSelectColumn vc = nameMap.get(columnName);
		vc.setAlias(alias);
		return this;
	}
	
	@Override
	public GSelectColumnList set(String columnName, FuncType funcType) {
		GSelectColumn vc = nameMap.get(columnName);
		vc.setFuncType(funcType);
		return this;
	}
	
	@Override
	public GSelectColumnList set(String columnName, String alias, FuncType funcType) {
		GSelectColumn vc = nameMap.get(columnName);
		vc.setAlias(alias);
		vc.setFuncType(funcType);
		return this;
	}

	// ------------------------Listインターフェース実装-----------------------------------

	@Override
	public boolean add(GSelectColumn e) {
		String key = e.getResultSetKey();
		if (nameMap.containsKey(key)) {
			return false;
		}
		boolean result = super.add(e);
		if (result) {
			nameMap.put(key, e);
		}
		return result;
	}

	@Override
	public void add(int index, GSelectColumn element) {
		if (nameMap.containsKey(element.getResultSetKey())) {
			return;
		}
		super.add(index, element);
		nameMap.put(element.getResultSetKey(), element);
	}

	@Override
	public boolean addAll(Collection< ? extends GSelectColumn> c) {
		Map<String, GSelectColumn> addMap = new HashMap<String, GSelectColumn>();
		for (GSelectColumn vc : c) {
			if (nameMap.containsKey(vc.getResultSetKey())) {
				return false;
			}
			addMap.put(vc.getResultSetKey(), vc);
		}

		boolean result = super.addAll(c);
		if (result) {
			nameMap.putAll(addMap);
		}
		return result;
	}

	@Override
	public boolean addAll(int index, Collection< ? extends GSelectColumn> c) {
		Map<String, GSelectColumn> addMap = new HashMap<String, GSelectColumn>();
		for (GSelectColumn vc : c) {
			if (nameMap.containsKey(vc.getResultSetKey())) {
				return false;
			}
			addMap.put(vc.getResultSetKey(), vc);
		}

		boolean result = super.addAll(index, c);
		if (result) {
			nameMap.putAll(addMap);
		}
		return result;
	}

	@Override
	public void clear() {
		nameMap.clear();
		super.clear();
	}

	@Override
	public boolean remove(Object o) {
		if (!(o instanceof GSelectColumn)) {
			return false;
		}

		GSelectColumn vc = (GSelectColumn) o;
		boolean result = super.remove(o);
		if (result) {
			nameMap.remove(vc.getResultSetKey());
		}
		return result;
	}

	@Override
	public GSelectColumn remove(int index) {
		GSelectColumn vc = super.remove(index);
		if (vc != null) {
			nameMap.remove(vc.getResultSetKey());
		}
		return vc;
	}

	@Override
	public boolean removeAll(Collection< ? > c) {
		for (Object object : c) {
			if (!(c instanceof GSelectColumn)) {
				return false;
			}
			GSelectColumn vc = (GSelectColumn) object;
			if (!nameMap.containsKey(vc.getResultSetKey())) {
				return false;
			}
		}

		boolean result = super.removeAll(c);
		if (result) {
			for (Object object : c) {
				GSelectColumn vc = (GSelectColumn) object;
				nameMap.remove(vc.getResultSetKey());
			}
		}
		return result;
	}

	@Override
	public boolean retainAll(Collection< ? > c) {
		throw new UnsupportedOperationException("Not Supporeted.");
	}

	@Override
	public GSelectColumn set(int index, GSelectColumn element) {
		GSelectColumn before = super.set(index, element);
		nameMap.remove(before.getResultSetKey());
		nameMap.put(element.getResultSetKey(), element);
		return before;
	}

	@Override
	public List<GSelectColumn> subList(int fromIndex, int toIndex) {
		throw new UnsupportedOperationException("Not Supporeted.");
	}
}
