/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;

/**
 * ユニークキーで検索する際の検索条件を表すクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GUKWhereExpression implements GExpression {
	
	/** ユニークキー名 */
	private String uniqueKeyName = null;
	/** ユニークキーのパラメータ群 */
	private Object[] uniqueKeys = null;
	/** 検索条件の指定にGRecordを使用するかどうかを表す */
	private boolean useRecord = false;
	
	/**
	 * {@link GUKWhereExpression}を初期化します.
	 * 
	 * @param uniqueKeyName ユニークキー名
	 * @param uniqueKeys ユニークキーのパラメータ群
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUKWhereExpression(String uniqueKeyName, Object[] uniqueKeys) {
		this.uniqueKeyName = uniqueKeyName;
		this.uniqueKeys = uniqueKeys;
	}
	
	/**
	 * {@link GUKWhereExpression}を初期化します.
	 * 
	 * @param uniqueKeyName ユニークキー名
	 * @param useRecord 検索条件の指定にGRecordを使用する場合は<code>true</code>／使用しない場合は<code>false</code>
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUKWhereExpression(String uniqueKeyName, boolean useRecord) {
		this.uniqueKeyName = uniqueKeyName;
		this.useRecord = useRecord;
	}
	
	/**
	 * ユニークキー名を取得します.
	 * 
	 * @return ユニークキー名
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public String getUniqueKeyName() {
		return uniqueKeyName;
	}
	
	/**
	 * ユニークキー名を設定します.
	 * 
	 * @param uniqueKeyName ユニークキー名
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setUniqueKeyName(String uniqueKeyName) {
		this.uniqueKeyName = uniqueKeyName;
	}
	
	/**
	 * ユニークキーのパラメータ群を取得します.
	 * 
	 * @return ユニークキーのパラメータ群
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public Object[] getUniqueKeys() {
		return uniqueKeys;
	}
	
	/**
	 * ユニークキーのパラメータ群を設定します.
	 * 
	 * @param uniqueKeys ユニークキーのパラメータ群
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setUniqueKeys(Object[] uniqueKeys) {
		this.uniqueKeys = uniqueKeys;
	}
	
	/**
	 * 検索条件の指定にGRecordを使用するか否かを取得します.
	 * 
	 * @return 検索条件の指定にGRecordを使用する場合は<code>true</code>／使用しない場合は<code>false</code>
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public boolean isUseRecord() {
		return useRecord;
	}
	
	/**
	 * 検索条件の指定にGRecordを使用するか否かを設定します.
	 * 
	 * @param useRecord 検索条件の指定にGRecordを使用する場合は<code>true</code>／使用しない場合は<code>false</code>
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setUseRecord(boolean useRecord) {
		this.useRecord = useRecord;
	}
}
