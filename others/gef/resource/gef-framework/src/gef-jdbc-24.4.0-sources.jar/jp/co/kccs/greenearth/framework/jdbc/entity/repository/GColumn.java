/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;

/**
 * カラムを表すインタフェースです。
 * <p>
 * エンティティー定義ファイルからColumnタグの定義がロードされたカラムを提供するためのインタフェースです。<br>
 * このインタフェースを使用することで、カラムの各種設定を操作できるようになります。<br>
 * ロードされた定義を参照したり、上書きしたりすることができます。
 * 
 * @author KCCS fujita
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GColumn {

	/** 関数の種類を持つ列挙型クラスです。
	 * <ul>
	 * <li>{@link #MAX} </li>
	 * <li>{@link #MIN} </li>
	 * <li>{@link #SUM} </li>
	 * <li>{@link #AVG} </li>
	 * <li>{@link #COUNT} </li>
	 * </ul> 
	 * @author KCCS fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	public enum FuncType {

		/** MAXを表す定数 */
		MAX("MAX"),
		/** MINを表す定数 */
		MIN("MIN"),
		/** SUMを表す定数 */
		SUM("SUM"),
		/** AVGを表す定数 */
		AVG("AVG"),
		/** COUNTを表す定数 */
		COUNT("COUNT");

		/** 関数名 */
		private String funcName;

		/**
		 * 列挙型のコンストラクタです。
		 * 
		 * @param funcName 関数タイプ名
		 * @author KCCS fujita
		 * @create 2012/10/09
		 * @since 3.12.0
		 */
		private FuncType(String funcName) {
			this.funcName = funcName;
		}

		/**
		 * 関数名を取得します。
		 * 
		 * @return 関数名
		 * @author KCCS fujita
		 * @create 2012/10/09
		 * @since 3.12.0
		 */
		public String getFuncName() {
			return funcName;
		}

		/**
		 * 関数名を設定します。
		 * 
		 * @param funcName 関数名
		 * @author KCCS fujita
		 * @create 2012/10/09
		 * @since 3.12.0
		 */
		public void setType(String funcName) {
			this.funcName = funcName;
		}
	}
	
	/**
	 * このカラムを保持するエンティティーを取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイルからロードされたエンティティー定義です。
	 * 
	 * @return エンティティー
	 * @author KCCS fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GEntity getEntity();

	/**
	 * このカラムを保持するエンティティーを設定します。
	 * 
	 * @param entity エンティティー
	 * @author KCCS fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setEntity(GEntity entity);

	/**
	 * カラムの論理名を取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、Columnタグのname属性の値です。
	 * 
	 * @return カラムの論理名
	 * @author KCCS fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	String getName();

	/**
	 * カラムの論理名を設定します。
	 * 
	 * @param name カラムの論理名
	 * @author KCCS fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setName(String name);

	/**
	 * カラムの物理名を取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、ColumnタグのphyName属性の値です。
	 * 
	 * @return カラムの物理名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	String getPhyName();

	/**
	 * カラムの物理名を設定します。
	 * 
	 * @param phyName カラムの物理名
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setPhyName(String phyName);

	/**
	 * カラムのデータ型を取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、Columnタグのtype属性の値です。<br>
	 * データ型は{@link GColumnType}の定数から選択され設定されたものです。
	 * 
	 * @return カラムのデータ型
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	GColumnType getType();

	/**
	 * カラムのデータ型を設定します。
	 * 
	 * {@link GColumnType}の定数からデータ型を選択し設定してください。
	 * 
	 * @param type カラムのデータ型
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	void setType(GColumnType type);

	/**
	 * カラムのバイト数を取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、Columnタグのsize属性の値です。
	 * 
	 * @return バイト数
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	int getSize();

	/**
	 * カラムのバイト数を設定します。
	 * 
	 * @param size バイト数
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	void setSize(int size);

	/**
	 * 小数点以下の桁数を取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、Columnタグのscale属性の値です。
	 * 
	 * @return 小数点以下の桁数
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	int getScale();
	
	/**
	 * 小数点以下の桁数を設定します。
	 * 
	 * @param scale 小数点以下の桁数
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	void setScale(int scale);
	
	/**
	 * 楽観的排他で使用するカラムに指定されているかどうか判定します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、ColumnタグのexclusiveKey属性の値で判定します。<br>
	 * exclusiveKey属性は文字列"true"または"false"が設定可能です。<br>
	 * exclusiveKey属性が省略されている場合は{@code false}を返します。
	 * 
	 * @return {@code true}が設定されている場合は{@code true}. そうでない場合は{@code false}.
	 * @author KCCS hashimoto
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	boolean isExclusiveKey();
	
	/**
	 * 楽観的排他で使用するカラムに指定します。
	 * 
	 * @param exclusion 指定する場合は{@code true}. そうでない場合は{@code false}.
	 * @author KCCS hashimoto
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void setExclusiveKey(boolean exclusion);
	
	/**
	 * 自動生成する値のタイプを取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイル、Columnタグのgenerate属性の値です。
	 * 下記のいずれかが設定されています（デフォルト）。
	 * "RandomID"、"RegisteredDate"、"UpdatedDate"、"ExclusiveKey"
	 * 
	 * @return タイプ
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	String getGenerateType();
	
	/**
	 * 自動生成する値のタイプを設定します。
	 * 
	 * デフォルトでは下記のいずれかが設定可能です。
	 * "RandomID"、"RegisteredDate"、"UpdatedDate"、"ExclusiveKey"
	 * （{@link GSQLPartsGenerator}の実装でタイプを追加することも可能です）。
	 * 
	 * @param generateType タイプ
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	void setGenerateType(String generateType);
}