/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;

/**
 * {@link GColumn}インターフェースの実装クラスです.
 *
 * @author KCCS K.Fujita
 * @create 2012/10/11
 * @since 3.12.0
 */
public class GColumnImpl implements GColumn {

	/** エンティティ */
	private GEntity entity = null;
	/** カラム名 */
	private String name = null;
	/** カラムの物理名 */
	private String phyName = null;
	/** カラムのデータ型 */
	private GColumnType type = null;
	/** カラムが許容するデータサイズ */
	private int size;
	/** データのスケール */
	private int scale;
	/** 排他項目設定 */
	private boolean exclusion;
	/** 自動生成タイプ */
	private String generate;

	/**
	 * {@link GColumnImpl}のインスタンスを生成します.
	 *
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public GColumnImpl() {
	}
	
	@Override
	public GEntity getEntity() {
		return entity;
	}

	@Override
	public void setEntity(GEntity entity) {
		this.entity = entity;
	}

	/**
	 * カラム名を取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#getName()
	 * @return カラム名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * カラム名を設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#setName(java.lang.String)
	 * @param name カラム名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * カラムの物理名を取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#getPhyName()
	 * @return カラムの物理名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public String getPhyName() {
		return phyName;
	}

	/**
	 * カラムの物理名を設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#setPhyName(java.lang.String)
	 * @param phyName カラムの物理名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public void setPhyName(String phyName) {
		this.phyName = phyName;
	}

	/**
	 * カラムのデータ型を取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#getType()
	 * @return カラムのデータ型
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public GColumnType getType() {
		return type;
	}

	/**
	 * カラムのデータ型を設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#setType(java.lang.String)
	 * @param type カラムのデータ型
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public void setType(GColumnType type) {
		this.type = type;
	}

	/**
	 * 許容するデータサイズを取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#getSize()
	 * @return 許容するデータサイズ
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public int getSize() {
		return size;
	}

	/**
	 * 許容するデータサイズを設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#setSize(int)
	 * @param size 許容するデータサイズ
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * データのスケールを取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#getScale()
	 * @return データのスケール
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public int getScale() {
		return scale;
	}

	/**
	 * データのスケールを設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#setScale(int)
	 * @param scale データのスケール
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public void setScale(int scale) {
		this.scale = scale;
	}
	/**
	 * 排他項目設定を取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#isExclusiveKey()
	 * @return 排他項目の場合：true／排他項目でない場合：false
	 * @author KCCS hashimoto
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public boolean isExclusiveKey() {
		return exclusion;
	}

	/**
	 * 排他項目設定を設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#setExclusiveKey(java.lang.String)
	 * @param exclusion 排他項目設定
	 * @author KCCS hashimoto
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Override
	public void setExclusiveKey(boolean exclusion) {
		this.exclusion = exclusion;
	}
	
	/**
	 * 自動生成項目を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#getGenerateType()
	 * @return 自動生成項目
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	@Override
	public String getGenerateType() {
		return generate;
	}
	
	/**
	 * 自動生成項目を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn#setGenerateType(java.lang.String)
	 * @param generate - 自動生成項目
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	@Override
	public void setGenerateType(String generate) {
		this.generate = generate;
	}
}
