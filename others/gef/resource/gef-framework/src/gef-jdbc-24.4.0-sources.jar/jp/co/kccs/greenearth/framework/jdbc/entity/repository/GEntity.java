/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import java.util.Map;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.framework.jdbc.GDatabase;

/**
 * エンティティーを表すインタフェースです。
 * <p>
 * 基本的にエンティティー定義ファイルから定義がロードされたエンティティーを提供するためのインタフェースです。<br>
 * このインタフェースを使用することで、エンティティーの各種定義を操作できるようになります。<br>
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/19
 * @since 3.12.0
 */
public interface GEntity {
	
	/**
	 * エンティティー名を取得します。
	 *
	 * @return エンティティー名（エンティティー定義ファイルの名前から拡張子を除いたもの）
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	String getName();
	
	/**
	 * データベース接続情報を取得します。
	 * <p>
	 * データベース接続情報とは、管理名、使用するRDBMSの種類、スキーマ、データソース名です。<br>
	 * デフォルト値はエンティティー定義ファイルのdatabaseの値をキーとしてDIコンテナから取得した値です。
	 * 
	 * @return データベース情報
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	GDatabase getDatabase();
	
	/**
	 * データベース接続情報を設定します。
	 * <p>
	 * データベース接続情報とは、管理名、使用するRDBMSの種類、スキーマ、データソース名です。<br>
	 * 
	 * @param database データベース情報
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void setDatabase(GDatabase database);
	
	/**
	 * エンティティーの物理名（物理テーブル名）を取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイルのphyNameの値です。
	 * 
	 * @return エンティティーの物理名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	String getPhyName();
	
	/**
	 * エンティティーの物理名（物理テーブル名）を設定します。
	 * 
	 * @param phyName エンティティーの物理名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void setPhyName(String phyName);

	/**
	 * カラムを取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイルのColumnsの値です。
	 *
	 * @return カラム
	 * @author KCCS fujtia
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	GListMap<String, GColumn> getColumns();
	
	/**
	 * カラムを設定します。
	 * 
	 * @param columns カラム
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void setColumns(GListMap<String, GColumn> columns);
	
	/**
	 * 主キーを取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイルのPrimaryKeyの値です。
	 *
	 * @return 主キー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	GPrimaryKey getPrimaryKey();
	
	/**
	 * 主キーを設定します。
	 *
	 * @param primaryKey 主キー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void setPrimaryKey(GPrimaryKey primaryKey);
	
	/**
	 * ユニークキーを取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイルのUniqueKeysの値です。
	 *
	 * @return ユニークキー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	Map<String, GUniqueKey> getUniqueKeys();
	
	/**
	 * ユニークキーを設定します。
	 *
	 * @param uniqueKeys ユニークキー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void setUniqueKeys(Map<String, GUniqueKey> uniqueKeys);
	
	/**
	 * 外部キーを取得します。
	 * <p>
	 * デフォルト値はエンティティー定義ファイルのForeignKeysの値です。
	 *
	 * @return 外部キー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	Map<String, GForeignKey> getForeignKeys();
	
	/**
	 * 外部キーを設定します。
	 *
	 * @param foreignKeys 外部キー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void setForeignKeys(Map<String, GForeignKey> foreignKeys);
	
	/**
	 * 楽観的排他に使用するカラムを取得します。
	 * <p>
	 * エンティティー定義ファイルのカラム定義でexclusiveKey="true"となっているカラムを取得します。
	 *
	 * @return 楽観的排他に使用するカラム
	 * @author KCCS hashimoto
	 * @create 2012/11/26
	 * @since 3.12.0
	 */
	GColumn getExclusiveKey();
}