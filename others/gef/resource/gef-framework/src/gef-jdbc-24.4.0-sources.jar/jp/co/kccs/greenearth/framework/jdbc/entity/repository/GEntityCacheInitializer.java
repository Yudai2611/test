/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.listener.GFrameworkListener;

/**
 * エンティティ定義ファイルを読み込み、キャッシュ化する機能を提供するクラスです.
 *
 * @author KCCS K.Fujita
 * @create 2012/10/23
 * @since 3.12.0
 */
public class GEntityCacheInitializer implements GFrameworkListener {

	/** ロガー */
	private static final Log LOGGER = LogFactory.getLog(GEntityCacheInitializer.class);
	/** {@link GEntityFactory}のインスタンス */
	private GEntityFactory entityFactory;

	/**
	 * {@link GEntityCacheInitializer}インスタンスを生成します.
	 *
	 * @param entityFactory {@link GEntityFactory}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/17
	 * @since 3.12.0
	 */
	public GEntityCacheInitializer(GEntityFactory entityFactory) {
		this.entityFactory = entityFactory;
	}

	@Override
	public void frameworkDestroyed() {
		entityFactory.clearCache();
	}

	@Override
	public void frameworkInitialized() {
		String cacheType = GFrameworkUtils.getProperty("geframe.db.Entity.Cache", GEntityFactory.USED);

		if (GEntityFactory.INIT.equals(cacheType)) {
			try {
				// 全エンティティファイルの読み込み・キャッシュ化
				entityFactory.cacheAllEntities();
			} catch (GRepositoryException gre) {
				LOGGER.error("Failed to cache some entity. ", gre);
				throw new IllegalStateException("Failed to cache some entity. ", gre);
			}
		}
	}

}
