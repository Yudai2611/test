/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;
import jp.co.kccs.greenearth.commons.listener.BootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializableAdapter;
import jp.co.kccs.greenearth.commons.priority.GPriority;

/**
 * {@link GEntityCacheInitializer}を{@link GBootstrapInitializable}にアダプトします.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@BootstrapInitializable(bootOn = false)
@Priority(GPriority.NORMAL)
public class GEntityCacheInitializerAdapter extends GBootstrapInitializableAdapter {
	public GEntityCacheInitializerAdapter(GBootstrapConfiguration configuration) {
		super(configuration, new GEntityCacheInitializer((GEntityFactory) configuration.getParameters().get("entityFactory")));
	}
	public GEntityCacheInitializerAdapter(GEntityFactory entityFactory) {
		super(new GEntityCacheInitializer(entityFactory));
	}
	public GEntityCacheInitializerAdapter() {
		super(new GEntityCacheInitializer(null));
	}


	public GEntityCacheInitializerAdapter(GBootstrapConfiguration configuration, GEntityFactory entityFactory) {
		super(configuration, new GEntityCacheInitializer(entityFactory));
	}
}
