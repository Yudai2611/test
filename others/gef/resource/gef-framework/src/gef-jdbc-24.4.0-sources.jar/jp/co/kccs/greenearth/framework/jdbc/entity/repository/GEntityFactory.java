/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;


/**
 * エンティティーを管理するインタフェースです。
 * <p>
 * {@link GEntity}を生成し、提供するためインタフェースです。<br>
 * {@link GEntity}はエンティティー定義ファイルからロードされた定義を保持します。<br>
 * キャッシュを利用して{@link GEntity}を管理することもできます。
 * <p>
 * 主に以下の機能を提供します。<br>
 * <ol type="1">
 * <li>{@link GEntity}を生成する</li>
 * <li>{@link GEntity}をキャッシュする</li>
 * <li>キャッシュをクリアする</li>
 * </ol>
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/19
 * @since 3.12.0
 */
public interface GEntityFactory {

	/** キャッシュを使用しない */
	final String NONE = "none";
	/** 一度読み込んだエンティティはキャッシュされる */
	final String USED = "used";
	/** アプリケーション起動時に全てキャッシュされる */
	final String INIT = "init";

	/**
	 * エンティティー定義を{@link GEntity}として取得します。
	 * <p>
	 * {@link GEntity}はエンティティー定義ファイルからロードされた定義を保持しています。<br>
	 * エンティティー定義ファイルが存在しない場合は{@link GRepositoryException}が発生します。
	 *
	 * @param id エンティティー名（エンティティー定義ファイル「XXXX.entity」のXXXX部）
	 * @return エンティティー
	 * @throws GRepositoryException 定義ファイルの読み込みに失敗した時
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	GEntity getEntity(String id) throws GRepositoryException;

	/**
	 * 全エンティティー定義をキャッシュします。
	 * <p>
	 * 本メソッドを呼び出した時点で全エンティティー定義を読み込みキャッシュします。<br>
	 * ge-framework.propertiesの「geframe.db.Entity.Cache」でエンティティー定義をキャッシュするか設定できます。<br>
	 * 「geframe.db.Entity.Cache=none」で設定されている場合はキャッシュされません.
	 * 
	 * @throws GRepositoryException 定義情報の読み込みに失敗した時
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void cacheAllEntities() throws GRepositoryException;

	/**
	 * キャッシュされているエンティティー定義をキャッシュから削除します。
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	void clearCache();

	/**
	 * ファクトリーを生成するクラスです。
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	@Deprecated
	public static class Factory {

		/**
		 * {@link GEntityFactory}のインスタンスを取得します。
		 * 
		 * @return DI定義から取得した{@link GEntityFactory}
		 * @author KCCS K.Fujita
		 * @create 2012/10/19
		 * @since 3.12.0
		 */
		@Deprecated
		public static GEntityFactory getInstance() {
			return (GEntityFactory) GFrameworkUtils.getComponent(GEntityFactory.class.getName());
		}
	}
}
