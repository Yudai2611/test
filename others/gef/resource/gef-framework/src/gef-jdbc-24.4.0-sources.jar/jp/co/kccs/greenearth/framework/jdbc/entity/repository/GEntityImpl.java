/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.commons.collection.GListMapImpl;
import jp.co.kccs.greenearth.framework.jdbc.GDatabase;

/**
 * {@link GEntity}インターフェースの実装クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/29
 * @since 3.12.0
 */
public class GEntityImpl implements GEntity {

	/** 名前 */
	private String name = null;
	/** データベース情報 */
	private GDatabase database = null;
	/** エンティティの物理名 */
	private String phyName = null;
	/** カラム */
	private GListMap<String, GColumn> columns = new GListMapImpl<String, GColumn>();
	/** プライマリキー */
	private GPrimaryKey primaryKey = null;
	/** ユニークキー */
	private Map<String, GUniqueKey> uniqueKeys = new HashMap<String, GUniqueKey>();
	/** 外部キー */
	private Map<String, GForeignKey> foreignKeys = new HashMap<String, GForeignKey>();
	
	/**
	 * コンストラクタ.
	 * 
	 * @param name エンティティー名
	 * @author KCCS K.Fujita
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GEntityImpl(String name) {
		this.name = name;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public GDatabase getDatabase() {
		return database;
	}

	@Override
	public void setDatabase(GDatabase database) {
		this.database = database;
	}

	@Override
	public String getPhyName() {
		return this.phyName;
	}

	@Override
	public void setPhyName(String phyName) {
		this.phyName = phyName;
	}

	@Override
	public GListMap<String, GColumn> getColumns() {
		return this.columns;
	}

	@Override
	public void setColumns(GListMap<String, GColumn> columns) {
		this.columns = columns;
	}

	@Override
	public GPrimaryKey getPrimaryKey() {
		return this.primaryKey;
	}

	@Override
	public void setPrimaryKey(GPrimaryKey primaryKey) {
		this.primaryKey = primaryKey;
	}

	@Override
	public Map<String, GUniqueKey> getUniqueKeys() {
		return this.uniqueKeys;
	}

	@Override
	public void setUniqueKeys(Map<String, GUniqueKey> uniqueKeys) {
		this.uniqueKeys = uniqueKeys;
	}

	@Override
	public Map<String, GForeignKey> getForeignKeys() {
		return this.foreignKeys;
	}

	@Override
	public void setForeignKeys(Map<String, GForeignKey> foreignKeys) {
		this.foreignKeys = foreignKeys;
	}

	@Override
	public GColumn getExclusiveKey() {
		Iterator<GColumn> itr = this.getColumns().iterator();
		while (itr.hasNext()) {
			GColumn column = itr.next();

			// 排他項目として設定された項目の項目名を抜き出す
			if (column.isExclusiveKey()) {
				return column;
			}
		}

		return null;
	}

}
