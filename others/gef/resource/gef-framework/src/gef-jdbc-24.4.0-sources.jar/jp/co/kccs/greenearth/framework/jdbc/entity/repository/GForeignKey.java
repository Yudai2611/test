/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import java.util.List;

/**
 * 外部キーを表すインタフェースです。
 *
 * @author KCCS fujtia
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GForeignKey {

	/**
	 * エンティティーを取得します。
	 *
	 * @return エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract GEntity getEntity();

	/**
	 * エンティティーを設定します。
	 *
	 * @param entity エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract void setEntity(GEntity entity);

	/**
	 * 外部キー名を取得します。
	 *
	 * @return 外部キー名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract String getName();

	/**
	 * 外部キー名を設定します。
	 *
	 * @param name 外部キー名
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract void setName(String name);

	/**
	 * 参照先エンティティーを取得します。
	 *
	 * @return 参照先エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract GEntity getReferenceEntity();

	/**
	 * 参照先エンティティーを設定します。
	 *
	 * @param referenceEntity 参照先エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract void setReferenceEntity(GEntity referenceEntity);

	/**
	 * 結合で使用するカラムのリストを取得します。
	 *
	 * @return 結合で使用するカラムのリスト
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract List<GJoinColumn> getJoinColumns();

	/**
	 * 結合で使用するカラムのリストを設定します。
	 *
	 * @param joinColumns 結合で使用するカラムのリスト
	 * @author KCCS K.Fujita
	 * @create 2012/10/19
	 * @since 3.12.0
	 */
	public abstract void setJoinColumns(List<GJoinColumn> joinColumns);

}