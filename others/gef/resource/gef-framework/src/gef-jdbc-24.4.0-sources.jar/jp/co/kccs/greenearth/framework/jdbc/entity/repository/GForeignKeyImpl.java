/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link GForeignKey}インターフェースの実装クラスです.
 *
 * @author KCCS K.Fujita
 * @create 2012/10/11
 * @since 3.12.0
 */
public class GForeignKeyImpl implements GForeignKey {

	/** エンティティ */
	private GEntity entity = null;
	/** 外部キー名 */
	private String name = null;
	/** 参照先エンティティ */
	private GEntity referenceEntity = null;
	/** 結合カラム情報 */
	private List<GJoinColumn> joinColumns = new ArrayList<GJoinColumn>();

	@Override
	public GEntity getEntity() {
		return entity;
	}

	@Override
	public void setEntity(GEntity entity) {
		this.entity = entity;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public GEntity getReferenceEntity() {
		return referenceEntity;
	}

	@Override
	public void setReferenceEntity(GEntity referenceEntity) {
		this.referenceEntity = referenceEntity;
	}

	@Override
	public List<GJoinColumn> getJoinColumns() {
		return joinColumns;
	}

	@Override
	public void setJoinColumns(List<GJoinColumn> joinColumns) {
		this.joinColumns = joinColumns;
	}
}
