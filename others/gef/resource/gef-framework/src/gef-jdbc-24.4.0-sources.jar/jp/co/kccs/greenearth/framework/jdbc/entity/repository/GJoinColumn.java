/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

/**
 * 結合で使用するカラムを表すインタフェースです。
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/11
 * @since 3.12.0
 */
public interface GJoinColumn {

	/**
	 * 外部キーを取得します。
	 * 
	 * @return 外部キー
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract GForeignKey getForeignKey();

	/**
	 * 外部キーを設定します。
	 * 
	 * @param foreignKey 外部キー
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract void setForeignKey(GForeignKey foreignKey);

	/**
	 * 参照元エンティティーのカラムを取得します。
	 * 
	 * @return 参照元エンティティーのカラム
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract GColumn getSourceColumn();

	/**
	 * 参照元エンティティーのカラムを設定します。
	 * 
	 * @param sourceColumn 参照元エンティティーのカラム
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract void setSourceColumn(GColumn sourceColumn);

	/**
	 * 参照先エンティティーのカラムを取得します。
	 * 
	 * @return 参照先エンティティーのカラム
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract GColumn getReferenceColumn();

	/**
	 * 参照先エンティティーのカラムを設定します。
	 * 
	 * @param referenceColumn 参照先エンティティーのカラム
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract void setReferenceColumn(GColumn referenceColumn);

	/**
	 * 結合の条件値を取得します。
	 * 
	 * @return 結合の条件値
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract String getConstValue();

	/**
	 * 結合の条件値を設定します。
	 * 
	 * @param constValue 結合の条件値
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract void setConstValue(String constValue);

	/**
	 * バインドパラメータの使用可否を判定します。
	 * 
	 * @return バインドパラメータが使用可の場合は{@code true}. そうでない場合は{@code false}.
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract boolean isUseBindParameter();

	/**
	 * パラメータバインドの使用可否を設定します。
	 * 
	 * @param useBindParameter パラメータバインドが使用可の場合は{@code true}. そうでない場合は{@code false}.
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract void setUseBindParameter(boolean useBindParameter);

	/**
	 * IsNullの使用可否を判定します。
	 * 
	 * @return IsNullが使用可の場合は{@code true}. そうでない場合は{@code false}.
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract boolean getIsNull();

	/**
	 * IsNullの使用可否を設定します。
	 * 
	 * @param isNull IsNullが使用可の場合は{@code true}. そうでない場合は{@code false}.
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	public abstract void setIsNull(boolean isNull);
}