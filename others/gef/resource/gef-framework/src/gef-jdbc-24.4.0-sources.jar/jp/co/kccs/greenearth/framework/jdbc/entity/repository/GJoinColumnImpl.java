/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

/**
 * {@link GJoinColumn}インターフェースの実装クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/11
 * @since 3.12.0
 */
public class GJoinColumnImpl implements GJoinColumn {

	/** 外部キー */
	private GForeignKey foreignKey = null;
	/** 参照元エンティティのカラム */
	private GColumn sourceColumn = null;
	/** 参照先エンティティのカラム */
	private GColumn referenceColumn = null;
	/** 結合の条件値（固定値） */
	private String constValue = null;
	/** 固定値としてIsNullを指定するか否か */
	private boolean isNull = false;
	/** バインドパラメータの可否 */
	private boolean useBindParameter = false;

	@Override
	public GForeignKey getForeignKey() {
		return foreignKey;
	}

	@Override
	public void setForeignKey(GForeignKey foreignKey) {
		this.foreignKey = foreignKey;
	}

	@Override
	public GColumn getSourceColumn() {
		return sourceColumn;
	}

	@Override
	public void setSourceColumn(GColumn sourceColumn) {
		this.sourceColumn = sourceColumn;
	}

	@Override
	public GColumn getReferenceColumn() {
		return referenceColumn;
	}

	@Override
	public void setReferenceColumn(GColumn referenceColumn) {
		this.referenceColumn = referenceColumn;
	}

	@Override
	public String getConstValue() {
		return constValue;
	}

	@Override
	public void setConstValue(String constValue) {
		this.constValue = constValue;
	}

	@Override
	public boolean isUseBindParameter() {
		return useBindParameter;
	}

	@Override
	public void setUseBindParameter(boolean useBindParameter) {
		this.useBindParameter = useBindParameter;
	}

	@Override
	public boolean getIsNull() {
		return isNull;
	}

	@Override
	public void setIsNull(boolean isNull) {
		this.isNull = isNull;
	}
}
