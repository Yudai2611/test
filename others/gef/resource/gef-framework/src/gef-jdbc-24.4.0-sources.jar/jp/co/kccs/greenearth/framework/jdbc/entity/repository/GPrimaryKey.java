/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import java.util.List;

/**
 * 主キーを表すインタフェースです。
 *
 * @author KCCS K.Fujita
 * @create 2012/10/18
 * @since 3.12.0
 */
public interface GPrimaryKey {

	/**
	 * エンティティーを取得します。
	 *
	 * @return エンティティー
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	public abstract GEntity getEntity();

	/**
	 * エンティティーを設定します。
	 *
	 * @param entity エンティティ
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	public abstract void setEntity(GEntity entity);

	/**
	 * 参照カラムのリストを設定します。
	 *
	 * @return 参照カラムのリスト
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	public abstract List<GColumn> getReferenceColumns();

	/**
	 * 参照カラムのリストを設定します。
	 *
	 * @param referenceColumns 参照カラムのリスト
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	public abstract void setReferenceColumns(List<GColumn> referenceColumns);

}