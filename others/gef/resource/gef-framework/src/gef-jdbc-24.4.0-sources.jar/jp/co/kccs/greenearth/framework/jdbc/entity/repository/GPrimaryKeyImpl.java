/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link GPrimaryKey}インターフェースの実装クラスです.
 *
 * @author KCCS K.Fujita
 * @create 2012/10/19
 * @since 3.12.0
 */
public class GPrimaryKeyImpl implements GPrimaryKey {

	/** エンティティ */
	private GEntity entity = null;
	/** 参照カラム */
	private List<GColumn> referenceColumns = new ArrayList<GColumn>();

	@Override
	public GEntity getEntity() {
		return entity;
	}

	@Override
	public void setEntity(GEntity entity) {
		this.entity = entity;
	}

	@Override
	public List<GColumn> getReferenceColumns() {
		return referenceColumns;
	}

	@Override
	public void setReferenceColumns(List<GColumn> referenceColumns) {
		this.referenceColumns = referenceColumns;
	}

}
