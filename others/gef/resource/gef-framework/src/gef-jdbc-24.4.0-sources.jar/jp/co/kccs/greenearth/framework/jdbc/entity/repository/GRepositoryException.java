/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

/**
 * リポジトリに関する例外を表します.
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/29
 * @since 3.12.0
 */
public class GRepositoryException extends RuntimeException {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 5115843763035923956L;

	/**
	 * {@link GRepositoryException}のインスタンスを生成します.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GRepositoryException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GRepositoryException}のインスタンスを生成します.
	 * 
	 * @param message 例外メッセージ
	 * @author KCCS K.Fujita
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GRepositoryException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GRepositoryException}のインスタンスを生成します.
	 * 
	 * @param cause 発生原因となった例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GRepositoryException(Throwable cause) {
		super(cause);
	}

	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GRepositoryException}のインスタンスを生成します.
	 * 
	 * @param message 例外メッセージ
	 * @param cause 発生原因となった例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public GRepositoryException(String message, Throwable cause) {
		super(message, cause);
	}
}
