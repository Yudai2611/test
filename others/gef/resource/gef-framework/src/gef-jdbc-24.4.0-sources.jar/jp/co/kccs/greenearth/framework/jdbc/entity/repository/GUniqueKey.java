/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

/**
 * ユニークキーを表すインタフェースです。
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/22
 * @since 3.12.0
 */
public interface GUniqueKey extends GPrimaryKey {

	/**
	 * ユニークキー名を取得します。
	 * 
	 * @return ユニークキー名
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	public abstract String getName();

	/**
	 * ユニークキー名を設定します。
	 * 
	 * @param name ユニークキー名
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	public abstract void setName(String name);

}