/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

/**
 * {@link GUniqueKey}インターフェースの実装クラスです.
 *
 * @author KCCS K.Fujita
 * @create 2012/10/18
 * @since 3.12.0
 */
public class GUniqueKeyImpl extends GPrimaryKeyImpl implements GUniqueKey {

	/** ユニークキー名 */
	private String name = null;

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}
}
