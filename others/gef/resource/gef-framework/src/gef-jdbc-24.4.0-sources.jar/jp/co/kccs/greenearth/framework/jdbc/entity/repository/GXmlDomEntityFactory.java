/*
 * Copyright 2013-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.repository;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.xml.GDomUtils;
import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GDatabase;

/**
 * DOMを使用してXMLファイルからエンティティを生成するクラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/18
 * @since 3.12.0
 */
public class GXmlDomEntityFactory implements GEntityFactory {

	/** エンティティのキャッシュを配置するプール */
	Map<String, GEntity> entityPool = new ConcurrentHashMap<String, GEntity>();
	/** 外部キー用エンティティのキャッシュを配置するプール */
	Map<String, GEntity> foreignKeyentityPool = new ConcurrentHashMap<String, GEntity>();

	/** エンティティ定義ファイルのルートディレクトリのパス */
	private String entityRootDirectoryPath = null;
	/** エンティティ定義ファイルの拡張子 */
	private final String entityExtension = "entity";

	
	/**
	 * ルートパス配下にある全てのEntityファイルをキャッシュします。<br/></br>
	 * 
	 * @throws GRepositoryException 定義ファイルの読み込みに失敗した時
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	@Override
	public void cacheAllEntities() throws GRepositoryException {
		GFileUtils.listFileNamesFrom(entityRootDirectoryPath).stream().forEach(name -> {
			if (name.endsWith("." + entityExtension)) {
				getEntity0(name.substring(0, (name.length() - entityExtension.length() - 1)));
			}
		});
	}

	@Override
	public void clearCache() {
		entityPool.clear();
	}

	/**
	 * エンティティの定義情報を読み込み、エンティティオブジェクトを返します。
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntityFactory#getEntity(java.lang.String)
	 * @param name 取得するエンティティの名前
	 * @return エンティティ
	 * @throws GRepositoryException 定義情報の読み込みに失敗したとき
	 * @author KCCS hashimoto
	 * @create 2012/10/16
	 * @since 3.12.0
	 */
	@Override
	public GEntity getEntity(String name) throws GRepositoryException {	//TODO メソッド名が不適切
		foreignKeyentityPool.clear();
		return getEntity0(name);
	}

	/**
	 * エンティティの定義情報を読み込み、エンティティオブジェクトを返します。
	 *
	 * @see jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntityFactory#getEntity(java.lang.String)
	 * @param name 取得するエンティティの名前
	 * @return エンティティ
	 * @throws GRepositoryException 定義情報の読み込みに失敗したとき
	 * @author KCCS K.Fujita
	 * @create 2012/10/16
	 * @since 3.12.0
	 */
	protected GEntity getEntity0(String name) throws GRepositoryException {	//TODO メソッド名が不適切
		String cacheType = GFrameworkUtils.getProperty("geframe.db.Entity.Cache", USED);

		// エンティティのキャッシュ設定がnoneでもusedでもinitでもない時
		if (!NONE.equals(cacheType) && !USED.equals(cacheType) && !INIT.equals(cacheType)) {
			throw new MissingResourceException("The setting of entity cache is wrong. : " + cacheType, "ge-framwork",
				"geframe.db.Entity.Cache");
		}
		
		if (name == null) {
			throw new GRepositoryException("The specified entity name is a null value.");
		}

		if (USED.equals(cacheType) || INIT.equals(cacheType)) {
			// プールにあればそれを返す
			if (entityPool.containsKey(name)) {
				return entityPool.get(name);
			}
		}

		String path = entityRootDirectoryPath + "/" + name + "." + entityExtension;
		Document dom = createDocument(path);
		Element element = dom.getDocumentElement();
		if (element == null || !"Entity".equals(element.getTagName())) {
			throw new IllegalArgumentException("This entity XML file require <Entity> Element. : " + path);
		}
		GEntity entity = loadEntity(name, element);

		if (USED.equals(cacheType) || INIT.equals(cacheType)) {
			entityPool.put(name, entity);
		}
		return entity;
	}

	/**
	 * XMLファイルの定義情報を読み込み、新しく生成したエンティティに詰め込んで返します。
	 * 
	 * @param entityName エンティティー名
	 * @param entityEl XMLファイルから読み込んだエンティティ要素
	 * @return エンティティ
	 * @throws GRepositoryException 定義情報の読み込みに失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/10/11
	 * @since 3.12.0
	 */
	protected GEntity loadEntity(String entityName, Element entityEl) throws GRepositoryException {
		GEntity entity = createEntity(entityName);
		foreignKeyentityPool.put(entityName, entity);

		// attr:phyName
		String phyName = GStringUtils.blankToNull(entityEl.getAttribute("phyName"));
		entity.setPhyName(phyName);

		// attr:database
		String databaseName = GStringUtils.blankToNull(entityEl.getAttribute("database"));
		GDatabase database = GFrameworkUtils.getComponent(databaseName);
		entity.setDatabase(database);

		// elem:Columns
		NodeList columnsNodeList = entityEl.getElementsByTagName("Columns");
		if (columnsNodeList != null && columnsNodeList.getLength() > 0) {
			Element columnsEl = (Element) columnsNodeList.item(0);
			NodeList columnsChildren = columnsEl.getChildNodes();
			int columnsChildrenCount = columnsChildren.getLength();
			for (int i = 0; i < columnsChildrenCount; i++) {
				Node columnsChild = columnsChildren.item(i);
				if (columnsChild.getNodeType() == Node.ELEMENT_NODE && "Column".equals(columnsChild.getNodeName())) {
					GColumn column = loadColumn((Element) columnsChild, entity);
					entity.getColumns().put(column.getName(), column);
				}
			}
		}

		// elem:PrimaryKey
		NodeList primaryKeyNodeList = entityEl.getElementsByTagName("PrimaryKey");
		if (primaryKeyNodeList != null && primaryKeyNodeList.getLength() > 0) {
			Element primaryKeyEl = (Element) primaryKeyNodeList.item(0);
			GPrimaryKey primaryKey = loadPrimaryKey(primaryKeyEl, entity);
			entity.setPrimaryKey(primaryKey);
		}

		// elem:UniqueKeys
		NodeList uniqueKeysNodeList = entityEl.getElementsByTagName("UniqueKeys");
		if (uniqueKeysNodeList != null && uniqueKeysNodeList.getLength() > 0) {
			Element uniqueKeysEl = (Element) uniqueKeysNodeList.item(0);
			NodeList uniqueKeysChildren = uniqueKeysEl.getChildNodes();
			int uniqueKeysChildrenCount = uniqueKeysChildren.getLength();
			for (int i = 0; i < uniqueKeysChildrenCount; i++) {
				Node uniqueKeysChild = uniqueKeysChildren.item(i);
				if (uniqueKeysChild.getNodeType() == Node.ELEMENT_NODE
					&& "UniqueKey".equals(uniqueKeysChild.getNodeName())) {
					GUniqueKey uniqueKey = loadUniqueKey((Element) uniqueKeysChild, entity);
					entity.getUniqueKeys().put(uniqueKey.getName(), uniqueKey);
				}
			}
		}

		// elem:ForeignKeys
		NodeList foreignKeysNodeList = entityEl.getElementsByTagName("ForeignKeys");
		if (foreignKeysNodeList != null && foreignKeysNodeList.getLength() > 0) {
			Element foreignKeysEl = (Element) foreignKeysNodeList.item(0);
			NodeList foreignKeysChildren = foreignKeysEl.getChildNodes();
			int foreignKeysChildrenCount = foreignKeysChildren.getLength();
			for (int i = 0; i < foreignKeysChildrenCount; i++) {
				Node foreignKeysChild = foreignKeysChildren.item(i);
				if (foreignKeysChild.getNodeType() == Node.ELEMENT_NODE
					&& "ForeignKey".equals(foreignKeysChild.getNodeName())) {
					GForeignKey foreignKey = loadForeignKey((Element) foreignKeysChild, entity);
					entity.getForeignKeys().put(foreignKey.getName(), foreignKey);
				}
			}
		}

		return entity;
	}

	/**
	 * 指定されたリソースを読み込み、{@link Document}型のオブジェクトを返します。
	 * 
	 * @param resourceName リソース名
	 * @return {@link Document}型のインスタンス
	 * @throws GRepositoryException リソースの読み込みに失敗した時
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	public Document createDocument(String resourceName) throws GRepositoryException {
		Document dom = null;
		try {
			URL url = GFileUtils.getResource(resourceName);
			if (url == null) {
				throw new GRepositoryException("This entity file does not exist. : " + resourceName);
			}
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			dom = db.parse(url.toString());
		} catch (ParserConfigurationException e) {
			throw new GRepositoryException("A serious configuration error occured.", e);
		} catch (SAXException e) {
			throw new GRepositoryException(
				"A DocumentBuilder could not be created which satisfies the configuration requested.", e);
		} catch (IOException e) {
			throw new GRepositoryException("Any I/O error has occured.", e);
		}
		return dom;
	}

	/**
	 * カラムに関する定義情報を読み込み、カラムオブジェクトを返します。
	 *
	 * @param columnEl カラムに関する定義情報
	 * @param entity エンティティに関する定義情報
	 * @return カラムオブジェクト
	 * @throws GRepositoryException リポジトリに関する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GColumn loadColumn(Element columnEl, GEntity entity) throws GRepositoryException {
		GColumn column = createColumn();
		column.setEntity(entity);

		String name = GStringUtils.blankToNull(columnEl.getAttribute("name"));
		String phyName = GStringUtils.blankToNull(columnEl.getAttribute("phyName"));

		// attr:name
		column.setName(name);

		// attr:phyname
		if (phyName == null || "".equals(phyName)) {
			column.setPhyName(name);
		} else {
			column.setPhyName(phyName);
		}

		// attr:type
		String type = GStringUtils.blankToNull(columnEl.getAttribute("type")).toUpperCase(Locale.ENGLISH);
		column.setType(GColumnType.valueOf(type));

		// attr:size
		column.setSize(GDomUtils.getIntAttr(columnEl, "size", -1));

		// attr:scale
		column.setScale(GDomUtils.getIntAttr(columnEl, "scale", -1));

		// attr:exclusiveKey
		column.setExclusiveKey(GBooleanUtils.toBoolean(columnEl.getAttribute("exclusiveKey"), false));

		// attr:generate
		column.setGenerateType(GStringUtils.blankToNull(columnEl.getAttribute("generate")));

		return column;
	}

	/**
	 * プライマリキーに関する定義情報を読み込み、プライマリキーオブジェクトを返します。
	 *
	 * @param primaryKeyEl プライマリキーに関する定義情報
	 * @param entity エンティティ
	 * @return プライマリキー
	 * @throws GRepositoryException リポジトリに関する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GPrimaryKey loadPrimaryKey(Element primaryKeyEl, GEntity entity) throws GRepositoryException {
		GPrimaryKey primaryKey = createPrimaryKey();
		primaryKey.setEntity(entity);
		NodeList primaryKeyChildren = primaryKeyEl.getChildNodes();
		int primaryKeyChildrenCount = primaryKeyChildren.getLength();
		for (int i = 0; i < primaryKeyChildrenCount; i++) {
			Node primaryKeyChild = primaryKeyChildren.item(i);
			if (primaryKeyChild.getNodeType() == Node.ELEMENT_NODE
				&& "ReferenceColumn".equals(primaryKeyChild.getNodeName())) {
				Element referenceColumnEl = (Element) primaryKeyChild;
				// attr:refName
				String refName = GStringUtils.blankToNull(referenceColumnEl.getAttribute("refName"));
				GColumn column = entity.getColumns().get(refName);
				if (column == null) {
					throw new GRepositoryException("This column does not exist. : " + refName);
				}
				primaryKey.getReferenceColumns().add(column);
			}
		}
		return primaryKey;
	}

	/**
	 * ユニークキーに関する定義情報を読み込み、ユニークキーオブジェクトを返します.
	 * 
	 * @param uniqueKeyEl ユニークキーに関する定義情報
	 * @param entity エンティティ
	 * @return ユニークキー
	 * @throws GRepositoryException リポジトリに関する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GUniqueKey loadUniqueKey(Element uniqueKeyEl, GEntity entity) throws GRepositoryException {
		GUniqueKey uniqueKey = createUniqueKey();
		uniqueKey.setEntity(entity);
		// attr:name
		uniqueKey.setName(GStringUtils.blankToNull(uniqueKeyEl.getAttribute("name")));

		NodeList uniqueKeyChildren = uniqueKeyEl.getChildNodes();
		int uniqueKeyChildrenCount = uniqueKeyChildren.getLength();
		for (int i = 0; i < uniqueKeyChildrenCount; i++) {
			Node uniqueKeyChild = uniqueKeyChildren.item(i);
			if (uniqueKeyChild.getNodeType() == Node.ELEMENT_NODE
				&& "ReferenceColumn".equals(uniqueKeyChild.getNodeName())) {
				Element referenceColumnEl = (Element) uniqueKeyChild;
				// attr:refName
				String refName = GStringUtils.blankToNull(referenceColumnEl.getAttribute("refName"));
				GColumn column = entity.getColumns().get(refName);
				if (column == null) {
					throw new GRepositoryException("This column does not exist. : " + refName);
				}
				uniqueKey.getReferenceColumns().add(column);
			}
		}
		return uniqueKey;
	}

	/**
	 * 外部キーに関する定義情報を読み込み、外部キーオブジェクトを返します.
	 * 
	 * @param foreignKeyEl 外部キーに関する定義情報
	 * @param entity エンティティ
	 * @return 外部キー
	 * @throws GRepositoryException リポジトリに関する例外
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GForeignKey loadForeignKey(Element foreignKeyEl, GEntity entity) throws GRepositoryException {
		GForeignKey foreignKey = createForeignKey();
		foreignKey.setEntity(entity);
		// attr:name
		foreignKey.setName(GStringUtils.blankToNull(foreignKeyEl.getAttribute("name")));
		// attr:refEntity
		String refEntityName = GStringUtils.blankToNull(foreignKeyEl.getAttribute("refEntity"));
		GEntity refEntity = null;
		if (foreignKeyentityPool.containsKey(refEntityName)) {
			refEntity = foreignKeyentityPool.get(refEntityName);
		} else {
			refEntity = getEntity0(refEntityName);
		}
		foreignKey.setReferenceEntity(refEntity);

		NodeList foreignKeyChildren = foreignKeyEl.getChildNodes();
		int foreignKeyChildrenCount = foreignKeyChildren.getLength();
		for (int i = 0; i < foreignKeyChildrenCount; i++) {
			Node foreignKeyChild = foreignKeyChildren.item(i);
			if (foreignKeyChild.getNodeType() == Node.ELEMENT_NODE
				&& "JoinColumn".equals(foreignKeyChild.getNodeName())) {
				// elem:JoinColumn
				GJoinColumn joinColumn = createJoinColumn();
				Element joinColumnEl = (Element) foreignKeyChild;
				// attr:srcName
				if (joinColumnEl.hasAttribute("srcName")) {
					String srcColumnName = GStringUtils.blankToNull(joinColumnEl.getAttribute("srcName"));
					GColumn srcColumn = entity.getColumns().get(srcColumnName);
					if (srcColumn == null) {
						throw new GRepositoryException("No such source column. : " + srcColumnName);
					}
					joinColumn.setSourceColumn(srcColumn);
				}
				// attr:refName
				if (joinColumnEl.hasAttribute("refName")) {
					String refColumnName = GStringUtils.blankToNull(joinColumnEl.getAttribute("refName"));
					GColumn refColumn = refEntity.getColumns().get(refColumnName);
					if (refColumn == null) {
						throw new GRepositoryException("No such reference column. : " + refColumnName);
					}
					joinColumn.setReferenceColumn(refColumn);
				}
				// attr:constValue
				if (joinColumnEl.hasAttribute("constValue")) {
					joinColumn.setConstValue(GStringUtils.blankToNull(joinColumnEl.getAttribute("constValue")));
				}
				// attr:isNull
				if (joinColumnEl.hasAttribute("isNull")) {
					joinColumn.setIsNull(GDomUtils.getBooleanAttr(joinColumnEl, "isNull"));
				}
				// attr:bindParameter
				if (joinColumnEl.hasAttribute("bindParameter")) {
					joinColumn.setUseBindParameter(GDomUtils.getBooleanAttr(joinColumnEl, "bindParameter"));
				}
				foreignKey.getJoinColumns().add(joinColumn);
			}
		}
		return foreignKey;
	}

	/**
	 * {@link GEntity}インターフェースの実装クラスのインスタンスを新規生成します
	 * 
	 * @param entityName エンティティ名
	 * @return {@link GEntity}インターフェースの実装クラス
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GEntity createEntity(String entityName) {
		return new GEntityImpl(entityName);
	}

	/**
	 * {@link GColumn}インターフェースの実装クラスのインスタンスを新規生成します.
	 * 
	 * @return {@link GColumn}インターフェースの実装クラスのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GColumn createColumn() {
		return new GColumnImpl();
	}

	/**
	 * {@link GPrimaryKey}インタフェースの実装クラスのインスタンス
	 * 
	 * @return {@link GPrimaryKey}インタフェースの実装クラスのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GPrimaryKey createPrimaryKey() {
		return new GPrimaryKeyImpl();
	}

	/**
	 * {@link GUniqueKey}インターフェースの実装クラスを新規生成します.
	 * 
	 * @return {@link GUniqueKey}インターフェースの実装クラスのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GUniqueKey createUniqueKey() {
		return new GUniqueKeyImpl();
	}

	/**
	 * {@link GForeignKey}インターフェースの実装クラスのインスタンスを新規作成します.
	 * 
	 * @return {@link GForeignKey}インターフェースの実装クラスのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GForeignKey createForeignKey() {
		return new GForeignKeyImpl();
	}

	/**
	 * {@link GJoinColumn}インターフェースの実装クラスのインスタンスを新規作成します
	 * 
	 * @return {@link GJoinColumn}インターフェースの実装クラスのインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/18
	 * @since 3.12.0
	 */
	protected GJoinColumn createJoinColumn() {
		return new GJoinColumnImpl();
	}

	/**
	 * エンティティ定義ファイルのルートディレクトリのパスを取得します.
	 * 
	 * @return エンティティ定義ファイルのルートディレクトリのパス
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	public String getEntityRootDirectoryPath() {
		return this.entityRootDirectoryPath;
	}

	/**
	 * エンティティ定義ファイルのルートディレクトリのパスを設定します.
	 * 
	 * @param entityRootDirectoryPath エンティティ定義ファイルのルートディレクトリのパス
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	public void setEntityRootDirectoryPath(String entityRootDirectoryPath) {
		this.entityRootDirectoryPath = entityRootDirectoryPath;
	}

}
