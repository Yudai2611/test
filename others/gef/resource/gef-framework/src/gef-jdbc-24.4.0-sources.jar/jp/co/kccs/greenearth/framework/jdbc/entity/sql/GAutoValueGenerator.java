/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * 値を自動生成するインタフェースです。
 *
 * @author KCCS kitamura
 * @create 2012/12/10
 * @since 3.12.0
 */
public interface GAutoValueGenerator {
	
	/**
	 * 登録のVALUE節を生成します。
	 * <p>
	 * 自動生成が指定されているカラムの値を自動生成します。
	 * 
	 * @param column カラム
	 * @param record 登録対象レコード
	 * @return SQL断片
	 * @author KCCS K.Fujita
	 * @create 2012/12/10
	 * @since 3.12.0
	 */
	GSQLPiece createValue4ValuesClause(GColumn column, GRecord record);
	
	/**
	 * 更新のSET節を生成します。
	 * <p>
	 * 自動生成が指定されているカラムの値を自動生成します。
	 * 
	 * @param column カラム
	 * @param record 更新対象レコード
	 * @return SQL断片
	 * @author KCCS K.Fujita
	 * @create 2012/12/10
	 * @since 3.12.0
	 */
	GSQLPiece createValue4SetClause(GColumn column, GRecord record);
}
