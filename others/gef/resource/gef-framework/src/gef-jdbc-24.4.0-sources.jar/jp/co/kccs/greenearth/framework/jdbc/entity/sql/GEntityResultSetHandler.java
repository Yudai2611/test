/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordImpl;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.sql.GResultSetHandlerBase;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * エンティティーを利用して取得した結果セットを操作する際に処理を振り分ける機能を提供するクラスです.
 *
 * @author KCCS kitamura
 * @create 2012/12/07
 * @since 3.12.0
 */
public class GEntityResultSetHandler extends GResultSetHandlerBase {

	/**
	 * {@link GEntityResultSetHandler}のインスタンスを生成します.
	 * 
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/12/07
	 * @since 3.12.0
	 */
	public GEntityResultSetHandler(GSQLTypeHandler handler) {
		setTypeHandler(handler);
	}

	@Override
	public GRecord createRecord(GQuery<?> query, ResultSet resultSet) throws SQLException {

		if (resultSet == null) {
			return null;
		}
		
		if (!(query instanceof GEntitySelect)) {
			throw new IllegalArgumentException("query argment is not " + GEntitySelect.class.getName() + ".");
		}
		GEntitySelect select = (GEntitySelect) query;

		GRecord record = new GRecordImpl();

		for (int i = 0; i < select.getSelectColumns().size(); i++) {
			int colIndex = i + 1;
			String key = select.getSelectColumns().get(i).getResultSetKey();

			// 取得項目の値がnullの場合はnullを設定する
			if (resultSet.getObject(colIndex) == null) {
				record.setObject(key, null);
				continue;
			}

			GColumnType type = select.getSelectColumns().get(i).getType();
			record.setObject(key, getTypeHandler().getValue(resultSet, colIndex, type));
		}

		return record;
	}
}
