/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * {@link GEntityResultSetHandlerMySQLBase}をMySQL8.0用に実装するクラスです.
 *
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GEntityResultSetHandlerMySQL8_0 extends GEntityResultSetHandlerMySQLBase {

	/**
	 * {@link GEntityResultSetHandlerMySQL8_0}のインスタンスを生成します.
	 * 
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GEntityResultSetHandlerMySQL8_0(GSQLTypeHandler handler) {
		super(handler);
	}
}
