/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * {@link GEntityResultSetHandler}をMySQL用に実装する基底クラスです.
 *
 * @author KCCS hashimoto
 * @create 2016/05/11
 * @since 3.18.0
 */
public abstract class GEntityResultSetHandlerMySQLBase extends GEntityResultSetHandler {

	/**
	 * {@link GEntityResultSetHandlerMySQLBase}のインスタンスを生成します.
	 * 
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	public GEntityResultSetHandlerMySQLBase(GSQLTypeHandler handler) {
		super(handler);
	}
	
}
