/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * {@link GEntityResultSetHandlerOracleBase}をOracle19c用に実装するクラスです.
 *
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GEntityResultSetHandlerOracle19c extends GEntityResultSetHandlerOracleBase {

	/**
	 * {@link GEntityResultSetHandlerOracle19c}のインスタンスを生成します.
	 * 
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GEntityResultSetHandlerOracle19c(GSQLTypeHandler handler) {
		super(handler);
	}
}
