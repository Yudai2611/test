/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * {@link GEntityResultSetHandler}をOracle用に実装する基底クラスです.
 *
 * @author KCCS hashimoto
 * @create 2016/08/30
 * @since 3.19.0
 */
public abstract class GEntityResultSetHandlerOracleBase extends GEntityResultSetHandler {

	/**
	 * {@link GEntityResultSetHandlerOracleBase}のインスタンスを生成します.
	 * 
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public GEntityResultSetHandlerOracleBase(GSQLTypeHandler handler) {
		super(handler);
	}
}
