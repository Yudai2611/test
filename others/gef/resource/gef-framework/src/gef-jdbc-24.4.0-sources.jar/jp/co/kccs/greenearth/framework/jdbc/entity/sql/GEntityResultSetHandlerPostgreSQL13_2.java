/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * {@link GEntityResultSetHandlerPostgreSQLBase}をPostgreSQL13.2用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GEntityResultSetHandlerPostgreSQL13_2 extends GEntityResultSetHandlerPostgreSQLBase {

	/**
	 * {@link GEntityResultSetHandlerPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GEntityResultSetHandlerPostgreSQL13_2(GSQLTypeHandler handler) {
		super(handler);
	}
}
