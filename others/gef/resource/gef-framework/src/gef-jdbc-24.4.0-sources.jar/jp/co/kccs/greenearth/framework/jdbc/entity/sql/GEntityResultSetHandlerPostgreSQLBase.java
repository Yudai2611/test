/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLTypeHandler;

/**
 * {@link GEntityResultSetHandler}をPostgreSQL用に実装する基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public abstract class GEntityResultSetHandlerPostgreSQLBase extends GEntityResultSetHandler {

	/**
	 * {@link GEntityResultSetHandlerPostgreSQLBase}のインスタンスを生成します.
	 *
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GEntityResultSetHandlerPostgreSQLBase(GSQLTypeHandler handler) {
		super(handler);
	}
}
