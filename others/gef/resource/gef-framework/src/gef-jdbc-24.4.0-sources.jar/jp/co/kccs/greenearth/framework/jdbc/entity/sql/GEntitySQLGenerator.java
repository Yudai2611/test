/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityDelete;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityInsert;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityUpdate;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * エンティティーを使用してSQLを生成するインタフェースです。
 * 
 * @author KCCS K.Fujita
 * @create 2012/10/08
 * @since 3.12.0
 */
public interface GEntitySQLGenerator {

	// -------------------------select---------------------------------------

	/**
	 * 検索用SQLを生成します。
	 * 
	 * @param select 検索用エンティティー
	 * @return SQL断片
	 * @author KCCS K.Fujita
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	GSQLPiece createSelectStatement(GEntitySelect select);

	/**
	 * 検索結果の件数を取得するSQLを生成します。
	 * 
	 * @param select 検索用エンティティー
	 * @return SQL断片
	 * @author KCCS K.Fujita
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	GSQLPiece createCountStatement(GEntitySelect select);

	// -------------------------insert---------------------------------------

	/**
	 * 登録用SQLを生成します。
	 * 
     * @param insert 登録用エンティティー
	 * @return SQL断片
	 * @author KCCS hashimoto
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	GSQLPiece createInsertStatement(GEntityInsert insert);

    /**
     * 一括登録用SQLを生成します。
     * 
     * @param insert 登録用エンティティー
     * @return SQL断片
     * @author KCCS hashimoto
     * @create 2012/10/08
     * @since 3.12.0
     */
    GSQLPiece createBatchInsertStatement(GEntityInsert insert);

	/**
	 * 検索結果登録用SQLを生成します。
	 * 
	 * @param insert 登録用エンティティー
	 * @param select 検索用エンティティー
	 * @return SQL断片
	 * @author KCCS yamashita
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	GSQLPiece createSelectInsertStatement(GEntityInsert insert, GSelect<?> select);

	// -------------------------update---------------------------------------

    /**
     * 更新用SQLを生成します。
     * 
     * @param update 更新用エンティティー
     * @return SQL断片
     * @author KCCS hashimoto
     * @create 2013/2/22
     * @since 3.12.0
     */
	GSQLPiece createUpdateStatement(GEntityUpdate update);

	/**
	 * 一括更新用SQLを生成します。
	 * 
	 * @param update 更新用エンティティー
	 * @return SQL断片
	 * @author KCCS hashimoto
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	GSQLPiece createBatchUpdateStatement(GEntityUpdate update);

	// -------------------------delete---------------------------------------

    /**
     * 削除用SQLを生成します。
     * 
     * @param delete 削除用エンティティー
     * @return SQL断片
     * @author KCCS hashimoto
     * @create 2013/2/22
     * @since 3.12.0
     */
	GSQLPiece createDeleteStatement(GEntityDelete delete);

	/**
	 * 一括削除用SQLを生成します。
	 * 
	 * @param delete 削除用エンティティー
	 * @return SQL断片
	 * @author KCCS hashimoto
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	GSQLPiece createBatchDeleteStatement(GEntityDelete delete);
}