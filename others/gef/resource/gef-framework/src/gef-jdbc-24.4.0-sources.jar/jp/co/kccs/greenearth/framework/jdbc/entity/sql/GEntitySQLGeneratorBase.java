/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.collection.GListMap;
import jp.co.kccs.greenearth.commons.collection.GListMapImpl;
import jp.co.kccs.greenearth.commons.collection.GPair;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityCUD;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityDelete;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityInsert;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityUpdate;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumnList;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GRoutingExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GEntitySQLGenerator}を実装する基底クラスです.
 * 
 * @author KCCS yamashita
 * @create 2012/12/20
 * @since 3.12.0
 */
public abstract class GEntitySQLGeneratorBase implements GEntitySQLGenerator {

	/** {@link GSQLPartsGenerator}のインスタンス */
	public GSQLPartsGenerator sqlPartsGenerator = null;
	/** {@link GExpressionConverter}のインスタンス */
	public GExpressionConverter expConverter = null;
	/** {@link GJoinPartGenerator}のインスタンス */
	protected GJoinPartGenerator joinPartGenerator = null;
	/** {@link GClauseGenerator}のインスタンス */
	public GLimitPartGenerator limitPartGenerator = null;

	/**
	 * {@link GEntitySQLGeneratorBase}のインスタンスを生成します.
	 * 
	 * @param columnPartGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @param expConverter {@link GExpressionConverter}のインスタンス
	 * @param joinPartGenerator {@link GJoinPartGenerator}のインスタンス
	 * @author KCCS yamashita
	 * @create 2012/12/20
	 * @since 3.12.0
	 */
    public GEntitySQLGeneratorBase(GSQLPartsGenerator columnPartGenerator, 
    								GRoutingExpressionConverter expConverter, 
    								GJoinPartGenerator joinPartGenerator,
    								GLimitPartGenerator limitPartGenerator) {
		this.sqlPartsGenerator = columnPartGenerator;
		this.expConverter = expConverter;
        this.joinPartGenerator = joinPartGenerator;
        this.limitPartGenerator = limitPartGenerator;
	}
    
	// -------------------------select---------------------------------------

	/**
	 * 検索SQLの実行情報を生成します.
	 * 
	 * @param select 検索先テーブル情報、検索要領を保持するエンティティ
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	@Override
	public GSQLPiece createSelectStatement(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new LinkedList<GBindParam>();

		// SELECT
		GSQLPiece selectPiece = createSelectClause(select);
		sql.append(selectPiece.getSql());
		parameter.addAll(asList(selectPiece.getParameter()));

		// FROM
		GSQLPiece fromPiece = createFromClause(select);
		sql.append(" ").append(fromPiece.getSql());
		parameter.addAll(asList(fromPiece.getParameter()));

		// JOIN
		if (select.getJoinList() != null && select.getJoinList().size() > 0) {
			GSQLPiece piece = createJoinClause(select);
			sql.append(" ").append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}

		// Where
		if (select.getWhereExpression() != null) {
			GSQLPiece piece = createWhereClause(select, select.getWhereExpression());
			if (piece != null) {
				sql.append(" ").append(piece.getSql());
				parameter.addAll(asList(piece.getParameter()));
			}
		}

		// Group By
		if (select.getGroupColumns() != null && select.getGroupColumns().size() > 0) {
			GSQLPiece groupByPiece = createGroupByClause(select);
			sql.append(" ").append(groupByPiece.getSql());
			parameter.addAll(asList(groupByPiece.getParameter()));
		}

		// Having
		if (select.getHavingExpression() != null) {
			GSQLPiece piece = createHavingClause(select);
			sql.append(" ").append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}

		// Union
		for (GPair<GSelect<?>, Boolean> pair : select.getUnionList()) {
			GSQLPiece piece = createUnionClause(pair.getFirst(), pair.getSecond());
			sql.append(" ").append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}

		// ORDER BY
		if (select.getOrderColumns() != null && select.getOrderColumns().size() > 0) {
			GSQLPiece piece = createOrderByClause(select);
			sql.append(" ").append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}

		// FORUPDATE
		GSQLPiece forUpdatePiece = createForUpdateClause(select);
		sql.append(forUpdatePiece.getSql());
		parameter.addAll(asList(forUpdatePiece.getParameter()));
		
		// Limit
		GSQLPiece limitPiece = createLimitClause(select);
		sql.append(limitPiece.getSql());
		parameter.addAll(asList(limitPiece.getParameter()));

		// 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
		return decorateManagementID(piece, select.getManagementID());
	}

	@Override
	public GSQLPiece createCountStatement(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		StringBuilder endSql = new StringBuilder();
		List<Object> parameter = new LinkedList<Object>();

		boolean hasGroupByClause = select.getGroupColumns() != null && select.getGroupColumns().size() > 0;
		boolean hasUnionClause = select.getUnionList() != null && select.getUnionList().size() > 0;

		if (hasGroupByClause || select.isDistinct() || hasUnionClause) {
			// SELECT COUNT(*) FROM (
			sql.append("SELECT COUNT(*) ").append("FROM ").append("( ");

			if (hasGroupByClause && !select.isDistinct() && select.getUnionList().isEmpty()) {
				// SELECT 1
				sql.append("SELECT ").append("1").append(" ");
			} else if (select.isDistinct() || !select.getUnionList().isEmpty()) {
				GSQLPiece selectPiece = createSelectClause(select);
				sql.append(selectPiece.getSql()).append(" ");
				parameter.addAll(asList(selectPiece.getParameter()));
			}

			// 末尾
			endSql.append(" ) ").append("COUNT_LIST");
		} else {
			// SELECT COUNT(*)
			sql.append("SELECT COUNT(*) ");
		}

		// FROM
		GSQLPiece fromPiece = createFromClause(select);
		sql.append(fromPiece.getSql());
		parameter.addAll(asList(fromPiece.getParameter()));

		// JOIN
		if (select.getJoinList() != null && select.getJoinList().size() > 0) {
			GSQLPiece piece = createJoinClause(select);
			sql.append(" ").append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}

		// Where
		if (select.getWhereExpression() != null) {
			GSQLPiece piece = createWhereClause(select, select.getWhereExpression());
			if (piece != null) {
				sql.append(" ").append(piece.getSql());
				parameter.addAll(asList(piece.getParameter()));
			}
		}

		// Group By
		if (select.getGroupColumns() != null && select.getGroupColumns().size() > 0) {
			GSQLPiece groupByPiece = createGroupByClause(select);
			sql.append(" ").append(groupByPiece.getSql());
			parameter.addAll(asList(groupByPiece.getParameter()));
		}

		// Having
		if (select.getHavingExpression() != null) {
			GSQLPiece piece = createHavingClause(select);
			sql.append(" ").append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}

		// Union
		for (GPair<GSelect<?>, Boolean> pair : select.getUnionList()) {
			GSQLPiece piece = createUnionClause(pair.getFirst(), pair.getSecond());
			sql.append(" ").append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}

		// FORUPDATE
		GSQLPiece forUpdatePiece = createForUpdateClause(select);
		sql.append(forUpdatePiece.getSql());
		parameter.addAll(asList(forUpdatePiece.getParameter()));

		// 末尾
		sql.append(endSql);

		// 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
		return decorateManagementID(piece, select.getManagementID());
	}

	/**
	 * Select節のSQL断片を生成します.
	 * 
	 * @param select SELECT節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @return SELECT節のSQLとバインドパラメータを保持する{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	protected GSQLPiece createSelectClause(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new ArrayList<GBindParam>();
		sql.append("SELECT").append(" ");
		
		if (select.isDistinct()) {
			sql.append("DISTINCT").append(" ");
		}

		StringBuilder columnsSQL = new StringBuilder();
		GSelectColumnList scolumns = select.getSelectColumns();
		for (GSelectColumn sc : scolumns) {
			
			// FIXME GSelectColumnのentityAliasがnull
//			if (null == sc.getEntityAlias() && null != select.getEntityAlias()) {
//				sc.setEntityAlias(select.getEntityAlias());
//			}
			
			columnsSQL.append(",").append(" ");
			GSQLPiece piece = sqlPartsGenerator.createColumn4SelectClause(select, sc);
			columnsSQL.append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}
		columnsSQL.delete(0, 2); // 最初の","を削除

		sql.append(columnsSQL);

		return new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
	}

	/**
	 * From節のSQL断片を生成します.
	 * 
	 * @param query クエリー
	 * @return From節のSQLとバインドパラメータを保持する{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/21
	 * @since 3.12.0
	 */
	protected GSQLPiece createFromClause(GEntityQuery< ? > query) {
		StringBuilder sql = new StringBuilder();
		sql.append("FROM").append(" ");
		sql.append(sqlPartsGenerator.createTableName(query.getEntity(), query.getEntityAlias()));
		
		return new GSQLPiece(sql.toString());
	}

	/**
	 * Join節のSQL断片を生成します.
	 * 
	 * @param select 結合情報のリストを保持した{@link GEntitySelect}のインスタンス
	 * @return Join節のSQLとバインドパラメータを保持する{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/21
	 * @since 3.12.0
	 */
	protected GSQLPiece createJoinClause(GEntitySelect select) {
		GSQLPiece piece = new GSQLPiece();
		
		List<GJoinData> joinList = select.getJoinList();
		for (GJoinData joinData : joinList) {
			GSQLPiece joinPiece = joinPartGenerator.createJoinClause(select, joinData);
			piece.appendSql(" ");
			piece.appendSql(joinPiece.getSql());
			List<GBindParam> parameter = piece.getParameter() != null ? asList(piece.getParameter()) : new LinkedList<GBindParam>();
			parameter.addAll(asList(joinPiece.getParameter()));
			piece.setParameter(parameter.toArray(new GBindParam[parameter.size()]));
		}
		piece.deleteSql(0, 1);	// 最初の" "を削除
		return piece;
	}

	/**
	 * Where節のSQL断片を生成します.
	 * 
	 * @param query Where節の付与対象となるSQLを設定した{@link GEntityQuery}のインスタンス
	 * @param exp 条件式
	 * @return Where節のSQLとバインドパラメータを保持する{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected GSQLPiece createWhereClause(GEntityQuery<?> query, GExpression exp) {
		StringBuilder sql = new StringBuilder();
		GSQLPiece piece = expConverter.convertExpression(query, exp);
		if (GStringUtils.isEmpty(piece.getSql())) {
			return null;
		}
		sql.append("WHERE").append(" ").append(piece.getSql());
		return new GSQLPiece(sql.toString(), piece.getParameter());
	}

	/**
	 * GroupBy節のSQL断片を生成します. <br/>
	 * GROUP BY句に指定できる項目：カラム名、集計関数（MAX, MIN, AVGなど<br/>
	 * GroupBy句で列の別名を使用することはできません.<br/>
	 * 
	 * @param select GroupBy節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @return GroupBy節のSQLとバインドパラメータを保持する{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected GSQLPiece createGroupByClause(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new ArrayList<GBindParam>();
		List<GSelectColumn> groupingColumns = select.getGroupColumns();
		for (GSelectColumn sc : groupingColumns) {
			sql.append(",").append(" ");
			GSQLPiece piece = sqlPartsGenerator.createColumn4GroupByClause(select, sc);
			sql.append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}
		final String gpstr = "GROUP BY " + sql.substring(2);		// 最初の", "を削除
		return new GSQLPiece(gpstr, (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
	}

	/**
	 * Having節のSQL断片を生成します.
	 * 
	 * @param select Having節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @return Having節のSQLとバインドパラメータを保持する{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected GSQLPiece createHavingClause(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		sql.append("HAVING").append(" ");
		GExpression exp = select.getHavingExpression();
		GSQLPiece piece = expConverter.convertExpression(select, exp);
		sql.append(piece.getSql());

		return new GSQLPiece(sql.toString(), piece.getParameter());
	}

	/**
	 * OrderBy節のSQL断片を生成します.
	 * 
	 * @param select OrderBy節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @return OrderBy節のSQLとバインドパラメータを保持する{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected GSQLPiece createOrderByClause(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new ArrayList<GBindParam>();
		List<GSelectColumn> columns = select.getOrderColumns();
		for (GSelectColumn column : columns) {
			sql.append(", ");
			GSQLPiece piece = sqlPartsGenerator.createColumn4OrderByClause(select, column);
			sql.append(piece.getSql());
			parameter.addAll(asList(piece.getParameter()));
		}
		final String obstr = "ORDER BY " + sql.substring(2);
		return new GSQLPiece(obstr, (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()])); // 最初の", "を削除
	}
	
	/**
	 * LIMIT/OFFSET(FETCH)節のSQL断片を生成します.
	 * 
	 * @param select LIMIT/OFFSET(FETCH)節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @return ForUpdate節を付与したSQLを設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	protected GSQLPiece createLimitClause(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		GSQLPiece piece = limitPartGenerator.createLimitClause(select);
		sql.append(piece.getSql());
		return new GSQLPiece(sql.toString());
	}

	/**
	 * ForUpdate節のSQL断片を生成します.
	 * 
	 * @param select ForUpdate節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @return ForUpdate節を付与したSQLを設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected abstract GSQLPiece createForUpdateClause(GEntitySelect select);

	/**
	 * UNION節のSQL断片を生成します.
	 * 
	 * @param select UNIONで付与するSQL及びバインドする値を設定した{@link GEntitySelect}のインスタンス
	 * @param unionAllFlg UNION ALL使用フラグ（true:UNION ALLを使用する／false:UNION
	 *            ALLを使用しない）
	 * @return UNIONで付与するSQL及びバインドする値を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS yamashita
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	public GSQLPiece createUnionClause(GSelect<?> select, boolean unionAllFlg) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new LinkedList<GBindParam>();
		
		sql.append("UNION").append(" ");
		if (unionAllFlg) {
			sql.append("ALL").append(" ");
		}

		GSQLPiece selectPiece = select.createSelectStatement();
		sql.append(selectPiece.getSql());
		parameter.addAll(asList(selectPiece.getParameter()));
		
		return new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
	}

	// -------------------------insert---------------------------------------

	@Override
	public GSQLPiece createInsertStatement(GEntityInsert insert) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new LinkedList<GBindParam>();

		// INSERT
		GSQLPiece insertPiece = createInsertClause();
		sql.append(insertPiece.getSql()).append(" ");
		parameter.addAll(asList(insertPiece.getParameter()));

		// 更新項目の選定
		GListMap<String, GColumn> columns = insert.getUpdateColumns();
		if (insert.isExcludesNull()) {
			columns = excludeNullColumns(columns, insert.getTargetRecord());
		}

		// INTO カラム
		GSQLPiece intoPiece = createIntoClause(insert, columns);
		sql.append(intoPiece.getSql()).append(" ");
		parameter.addAll(asList(intoPiece.getParameter()));

		// VALUES
		GSQLPiece valuesPiece = createValuesClause(insert, columns, insert.getTargetRecord());
		sql.append(valuesPiece.getSql());
		parameter.addAll(asList(valuesPiece.getParameter()));

        // 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
        return decorateManagementID(piece, insert.getManagementID());
	}
	
	@Override
	public GSQLPiece createBatchInsertStatement(GEntityInsert insert) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new LinkedList<GBindParam>();
		
		// INSERT
		GSQLPiece insertPiece = createInsertClause();
		sql.append(insertPiece.getSql()).append(" ");
		parameter.addAll(asList(insertPiece.getParameter()));

		// 登録項目の選定
		GListMap<String, GColumn> columns = insert.getUpdateColumns();
		if (insert.isExcludesNull()) {
			throw new IllegalArgumentException("ExcludesNull cannot be specified.");
		}

		// INTO カラム
		GSQLPiece intoPiece = createIntoClause(insert, columns);
		sql.append(intoPiece.getSql()).append(" ");
		parameter.addAll(asList(intoPiece.getParameter()));

		// VALUES
		GSQLPiece valuesPiece = createValuesClause(insert, columns, insert.getTargetRecordList());
		sql.append(valuesPiece.getSql());
		parameter.addAll(asList(valuesPiece.getParameter()));

        // 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), valuesPiece.getParameterList());
		return decorateManagementID(piece, insert.getManagementID());
	}

	@Override
	public GSQLPiece createSelectInsertStatement(GEntityInsert insert, GSelect<?> select) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new LinkedList<GBindParam>();

		// INSERT
		GSQLPiece insertPiece = createInsertClause();
		sql.append(insertPiece.getSql()).append(" ");
		parameter.addAll(asList(insertPiece.getParameter()));

		// 更新項目の選定
		GListMap<String, GColumn> columns = insert.getUpdateColumns();

		// INTO カラム
		GSQLPiece intoPiece = createIntoClause(insert, columns);
		sql.append(intoPiece.getSql()).append(" ");
		parameter.addAll(asList(intoPiece.getParameter()));

		// SELECT
		GSQLPiece selectPiece = select.createSelectStatement();
		sql.append(selectPiece.getSql());
		parameter.addAll(asList(selectPiece.getParameter()));

		// 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
		return decorateManagementID(piece, insert.getManagementID());
	}

	/**
	 * INSERT文用のSQL断片を生成します.
	 * 
	 * @return INSERT文用のSQL断片を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected GSQLPiece createInsertClause() {
		return new GSQLPiece("INSERT");
	}

	/**
	 * INTO句のSQL断片を生成します.
	 * 
	 * @param insert 登録対象テーブルのエンティティー情報を設定した{@link GEntityInsert}のインスタンス
	 * @param columns 登録対象テーブルの項目情報を保持するマップ
	 * @return INTO句のSQL断片を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected GSQLPiece createIntoClause(GEntityInsert insert, GListMap<String, GColumn> columns) {
		StringBuilder sql = new StringBuilder();

		sql.append("INTO").append(" ");
		sql.append(sqlPartsGenerator.createTableName(insert.getEntity(), null)).append(" ");

		StringBuilder columnsSQL = new StringBuilder();
		for (GColumn column : columns.values()) {
			columnsSQL.append(",");
			columnsSQL.append(sqlPartsGenerator.createColumn4IntoClause(column));
		}
		columnsSQL.delete(0, 1); // 最初の","を削除
		sql.append("(").append(columnsSQL).append(")");

		return new GSQLPiece(sql.toString());
	}

	/**
	 * VALUE句のSQL断片を生成します.
	 * 
	 * @param insert 登録対象テーブルのエンティティー情報を設定した{@link GEntityInsert}のインスタンス
	 * @param columns 登録対象テーブルの項目情報を保持するマップ
	 * @param record VALUE句にバインドする値
	 * @return VALUE句のSQL断片及びバインドする値を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	protected GSQLPiece createValuesClause(GEntityInsert insert, GListMap<String, GColumn> columns, GRecord record) {
		List<GBindParam> parameter = new ArrayList<GBindParam>();

		StringBuilder sql = new StringBuilder();
		for (int i = 0; i < columns.size(); i++) {
			GColumn column = columns.get(i);

			GSQLPiece piece = sqlPartsGenerator.createColumn4ValuesClause(column, record);
			// SQL
			sql.append(",").append(piece.getSql());
			// バインドパラメータ
			if (piece.getParameter() != null) {
				parameter.addAll(Arrays.asList(piece.getParameter()));
			}
		}
		sql.delete(0, 1); // 最初の","を削除

		GBindParam[] params = (GBindParam[]) parameter.toArray(new GBindParam[0]);
		return new GSQLPiece("VALUES (" + sql.toString() + ")", params);
	}

	/**
	 * VALUE句のSQL断片を生成します.
	 * 
	 * @param insert 登録対象テーブルのエンティティー情報を設定した{@link GEntityInsert}のインスタンス
	 * @param columns 登録対象テーブルの項目情報を保持するマップ
	 * @param records VALUE句にバインドする値のリスト
	 * @return VALUE句のSQL断片及びバインドする値を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/10/09
	 * @since 3.12.0
	 */
	protected GSQLPiece createValuesClause(GEntityInsert insert, GListMap<String, GColumn> columns,
		List<GRecord> records) {

		// まずはSQL作成
		StringBuilder sql = new StringBuilder();
		for (int i = 0; i < columns.size(); i++) {
			GColumn column = columns.get(i);

			GSQLPiece piece = sqlPartsGenerator.createColumn4ValuesClause(column, records.get(0));
			// SQL
			sql.append(",").append(piece.getSql());
		}

		sql.delete(0, 1); // 最初の","を削除

		// バインドパラメータ作成
		List<GBindParam[]> parameterForList = new ArrayList<GBindParam[]>();
		for (GRecord record : records) {
			List<GBindParam> parameter = new ArrayList<GBindParam>();
			for (int i = 0; i < columns.size(); i++) {
				GColumn column = columns.get(i);

				GSQLPiece piece = sqlPartsGenerator.createColumn4ValuesClause(column, record);

				// バインドパラメータ
				if (piece.getParameter() != null) {
					parameter.addAll(Arrays.asList(piece.getParameter()));
				}
			}
			GBindParam[] paramArray = (GBindParam[]) parameter.toArray(new GBindParam[0]);
			parameterForList.add(paramArray);
		}

		return new GSQLPiece("VALUES (" + sql.toString() + ")", parameterForList);
	}

	// -------------------------update---------------------------------------
	
	/**
	 *　更新SQLの実行情報を生成します.
	 * 
	 * @param update 更新先テーブル情報、更新要領を保持するエンティティ
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	@Override
	public GSQLPiece createUpdateStatement(GEntityUpdate update) {
		List<GBindParam> parameter = new LinkedList<GBindParam>();
		StringBuilder sql = new StringBuilder();

		// 楽観的排他が利用される場合は排他キーを退避させておく
		List<GRecord> backupGRecordList = null;
		if (update.isExclusive()) {
			backupGRecordList = saveExclusiveKey(update, update.getTargetRecord());
		}

		// UPDATE
		sql.append(createUpdateClause(update).getSql());

		// SET
		GSQLPiece setpiece = createSetClause(update, update.getTargetRecord());
		sql.append(setpiece.getSql());
		parameter.addAll(asList(setpiece.getParameter()));

		// WHERE
		if (update.getWhereExpression() != null) {
			GSQLPiece piece = createWhereClause(update, update.getWhereExpression());
			if (piece != null) {
				//楽観的排他の条件追加
				if (update.isExclusive()) {
					piece = decorateExclusiveCondition(piece, update, backupGRecordList.get(0));
				}
				
				sql.append(" ").append(piece.getSql());
				parameter.addAll(asList(piece.getParameter()));
			}
		}

		// 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
		return decorateManagementID(piece, update.getManagementID());
	}
	
	/**
	 * 楽観的排他の検索条件を追加します.
	 * 
	 * @param piece SQL断片
	 * @param query エンティティー情報
	 * @return 楽観的排他の検索条件を追加されたSQL断片
	 * @author KCCS hashimoto
	 * @create 2013/02/25
	 * @since 3.12.0
	 */
	private GSQLPiece decorateExclusiveSQL(GSQLPiece piece, GEntityCUD< ? > query) {
		GColumn exclusiveKey = query.getEntity().getExclusiveKey();
		
		// 条件追加
		StringBuilder sql = new StringBuilder(piece.getSql());
		String exclusiveColumnName = this.sqlPartsGenerator.createColumnFullName(query, exclusiveKey, query.getEntityAlias());
		
		sql.insert("WHERE ".length(), "(");
		sql.append(")").append(" AND").append(" ");
		sql.append("(");
		sql.append(exclusiveColumnName).append(" = ").append("?").append(" OR").append(" ");
		sql.append(exclusiveColumnName).append(" IS NULL").append(" ");
		sql.append("AND").append(" ").append("?").append(" IS NULL");
		sql.append(")");
		piece.setSql(sql.toString());
		
		return piece;
	}
	
	/**
	 * 楽観的排他の場合に検索条件を追加します.
	 * 
	 * @param piece Where節のSQL断片
	 * @param query エンティティー情報
	 * @param record SQLにバインドする値を保持するレコード
	 * @return 楽観的排他の条件が追加されたSQL断片
	 * @author KCCS hashimoto
	 * @create 2013/02/25
	 * @since 3.12.0
	 */
	private GSQLPiece decorateExclusiveCondition(GSQLPiece piece, GEntityCUD< ? > query, GRecord record) {
		GColumn exclusiveKey = query.getEntity().getExclusiveKey();
		String exclusiveKeyValue = record.getString(exclusiveKey.getName());

		// パラメータ追加
		GBindParam[] copy = Arrays.copyOf(piece.getParameter(), piece.getParameter().length + 2);
		copy[copy.length - 2] = GBindParam.create(exclusiveKeyValue, exclusiveKey.getType());
		copy[copy.length - 1] = GBindParam.create(exclusiveKeyValue, exclusiveKey.getType());
		piece.setParameter(copy);
		
		// 条件追加
		piece = decorateExclusiveSQL(piece, query);
		
		return piece;
	}
	
	/**
	 * 楽観的排他の場合に検索条件を追加します.
	 * 
	 * @param piece Where句のSQL断片
	 * @param query エンティティー情報
	 * @param recordList SQLにバインドする値を保持するレコード
	 * @return 楽観的排他の条件が追加されたSQL断片
	 * @author KCCS hashimoto
	 * @create 2013/02/25
	 * @since 3.12.0
	 */
	protected GSQLPiece decorateBatchExclusiveCondition(GSQLPiece piece, GEntityCUD< ? > query, final List<GRecord> recordList) {
		GColumn exclusiveKey = query.getEntity().getExclusiveKey();
		
		// パラメータ追加
		List<GBindParam[]> bindParamsList = piece.getParameterList();
		for (int i = 0; i < recordList.size(); i++) {
			GRecord record = recordList.get(i);
			GBindParam[] bindParams = bindParamsList.get(i);
			
			GBindParam[] copy = Arrays.copyOf(bindParams, bindParams.length + 2);
			copy[copy.length - 2] = GBindParam.create(record.getObject(exclusiveKey.getName()), exclusiveKey.getType());
			copy[copy.length - 1] = GBindParam.create(record.getObject(exclusiveKey.getName()), exclusiveKey.getType());
			bindParamsList.set(i, copy);
		}
		
		// 条件追加
		piece = decorateExclusiveSQL(piece, query);
		
		return piece;
	}

	 /**
	 * 一括で単一レコードを更新するSQLの実行情報を生成します.
	 *
	 * @param update 更新先テーブル情報、更新要領を保持するエンティティ
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	@Override
	public GSQLPiece createBatchUpdateStatement(GEntityUpdate update) {
		if (update.isExcludesNull()) {
			throw new IllegalArgumentException("ExcludesNull cannot be specified.");
		}

		StringBuilder sql = new StringBuilder();
		List<List<GBindParam>> parameterList = new LinkedList<List<GBindParam>>();

		// 楽観的排他が利用された場合のために排他キーを退避させておく
		List<GRecord> backupGRecordList = null;
		if (update.isExclusive()) {
			backupGRecordList = saveExclusiveKey(update, update.getTargetRecordList());
		}
		
		// UPDATE
		sql.append(createUpdateClause(update).getSql());

		// SET
		GSQLPiece setpiece = null;
		for (GRecord record : update.getTargetRecordList()) {
			setpiece = createSetClause(update, record);
			parameterList.add(asList(setpiece.getParameter()));
		}
		// どのバインドパラメータでSQLを生成しても同じものになるので、ループ最終で生成されたSQLを採用する
		sql.append(setpiece.getSql());
		
		// WHERE
		if (update.getWhereExpression() != null) {
			GSQLPiece wherepiece = createBatchWhereClause(update, update.getWhereExpression());
			//楽観的排他の条件追加
			if (update.isExclusive()) {
				wherepiece = decorateBatchExclusiveCondition(wherepiece, update, backupGRecordList);
			}
			
			sql.append(" ").append(wherepiece.getSql());
			for (int i = 0; i < parameterList.size(); i++) {
				parameterList.get(i).addAll(asList(wherepiece.getParameterList().get(i)));
			}
		}
		
		GSQLPiece piece = new GSQLPiece(sql.toString());
		for (List<GBindParam> list : parameterList) {
			piece.addParameter(list.toArray(new GBindParam[list.size()]));
		}

		// 管理ＩＤ付与
		return decorateManagementID(piece, update.getManagementID());
	}

	/**
	 * UPDATE文用の文字列を生成します.
	 * 
	 * @param update 更新対象テーブルのエンティティー情報を設定した{@link GEntityUpdate}のインスタンス
	 * @return UPDATE文用のSQL断片を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected GSQLPiece createUpdateClause(GEntityUpdate update) {

		StringBuilder sql = new StringBuilder();

		// UPDATE
		sql.append("UPDATE").append(" ");
		sql.append(sqlPartsGenerator.createTableName(update.getEntity(), null)).append(" ");

		return new GSQLPiece(sql.toString());
	}

	/**
	 * Set節のSQL断片を生成します.
	 * 
	 * @param update 更新対象テーブルのエンティティー情報を設定した{@link GEntityUpdate}のインスタンス
	 * @param record SET句にバインドする値
	 * @return SET句のSQL断片及びバインドする値を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/11/06
	 * @since 3.12.0
	 */
	protected GSQLPiece createSetClause(GEntityUpdate update, GRecord record) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new ArrayList<GBindParam>();

		// 更新項目の選定
		GListMap<String, GColumn> columns = update.getUpdateColumns();
		if (update.isExcludesNull()) {
			columns = excludeNullColumns(columns, record);
		}
		
		addExclusiveKeyColumn(update, columns);

		for (int i = 0; i < columns.size(); i++) {
			GColumn column = columns.get(i);

			GSQLPiece piece = sqlPartsGenerator.createColumn4SetClause(update, column, record);
			// SQL
			sql.append(",").append(piece.getSql());
			// バインドパラメータ
			if (piece.getParameter() != null) {
				parameter.addAll(Arrays.asList(piece.getParameter()));
			}
		}

		sql.delete(0, 1); // 最初の","を削除

		// SETを付与
		StringBuilder setApendedSql = new StringBuilder();
		setApendedSql.append("SET").append(" ");
		setApendedSql.append(sql);

		GBindParam[] params = (GBindParam[]) parameter.toArray(new GBindParam[0]);

		return new GSQLPiece(setApendedSql.toString(), params);
	}
	
	/**
	 * 排他キーのカラム情報を追加します.
	 * 
	 * @param update 更新用エンティティ
	 * @param columns カラム情報マップ
	 * @create 2015/02/06
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	private void addExclusiveKeyColumn(GEntityUpdate update, GListMap<String, GColumn> columns) {
		if (update.isExclusive()) {
			GColumn exclusiveKey = update.getEntity().getExclusiveKey();
			if (!columns.containsKey(exclusiveKey.getName())) {
				columns.put(exclusiveKey.getName(), exclusiveKey);
			}
		}
	}
	
	/**
	 * 一括更新用のWhere節を生成します.
	 * 
	 * @param query クエリー情報
	 * @param exp 条件式
	 * @return 一括更新用のWhere節
	 * @author KCCS hashimoto
	 * @create 2012/11/06
	 * @since 3.12.0
	 */
	protected GSQLPiece createBatchWhereClause(GEntityQuery<?> query, GExpression exp) {
		StringBuilder sql = new StringBuilder();
		sql.append("WHERE").append(" ");
		GSQLPiece piece = expConverter.convertBatchExpression(query, exp);
		sql.append(piece.getSql());
		return new GSQLPiece(sql.toString(), piece.getParameterList());
	}

	// -------------------------delete---------------------------------------
	
	/**
	 * 削除SQLの実行情報を生成します.
	 * 
	 * @param delete 削除先テーブル情報、削除要領を保持するエンティティ
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
    @Override
    public GSQLPiece createDeleteStatement(GEntityDelete delete) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new LinkedList<GBindParam>();

		// DELETE
		sql.append("DELETE");

		// FROM
		GSQLPiece fromPiece = createFromClause(delete);
		sql.append(" ").append(fromPiece.getSql());
		parameter.addAll(asList(fromPiece.getParameter()));

		// WHERE
		if (delete.getWhereExpression() != null) {
			GSQLPiece piece = createWhereClause(delete, delete.getWhereExpression());
			if (piece != null) {
				//楽観的排他の条件追加
				if (delete.isExclusive()) {
					piece = decorateExclusiveCondition(piece, delete, delete.getTargetRecord());
				}
				
				sql.append(" ").append(piece.getSql());
				parameter.addAll(asList(piece.getParameter()));
			}
		}

		// 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
		return decorateManagementID(piece, delete.getManagementID());
    }

	/**
	 * 一括で単一レコードを削除するSQLの実行情報を生成します.
	 * 
	 * @param delete 削除先テーブル情報、削除要領を保持するエンティティ
	 * @return 実行SQL及び実行SQLに対応して編集したバインド変数を設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
    @Override
	public GSQLPiece createBatchDeleteStatement(GEntityDelete delete) {
		StringBuilder sql = new StringBuilder();

		// DELETE
		sql.append("DELETE");

		// FROM
		GSQLPiece fromPiece = createFromClause(delete);
		sql.append(" ").append(fromPiece.getSql());

		// WHERE
		List<GBindParam[]> paramsList = null;
		if (delete.getWhereExpression() != null) {
			GSQLPiece wherepiece = createBatchWhereClause(delete, delete.getWhereExpression());
			//楽観的排他の条件追加
			if (delete.isExclusive()) {
				wherepiece = decorateBatchExclusiveCondition(wherepiece, delete, delete.getTargetRecordList());
			}
			
			sql.append(" ").append(wherepiece.getSql());
			paramsList = wherepiece.getParameterList();
		}

		// 管理ＩＤ付与
		GSQLPiece piece = new GSQLPiece(sql.toString(), paramsList);
		return decorateManagementID(piece, delete.getManagementID());
	}

	// -------------------------others---------------------------------------

	/**
	 * 値がNULLで設定されている項目はSQL文から排除するよう設定します.
	 * 
	 * @param columns テーブルの項目情報を保持するマップ
	 * @param record SQL文にバインドする値
	 * @return 値がNULLで設定されている項目を排除した、テーブルの項目情報を保持するマップ
	 * @author KCCS hashimoto
	 * @create 2012/12/26
	 * @since 3.12.0
	 */
	protected GListMap<String, GColumn> excludeNullColumns(GListMap<String, GColumn> columns, GRecord record) {

		GListMap<String, GColumn> copiedColumn = new GListMapImpl<String, GColumn>();

		for (Map.Entry<String, GColumn> entrySet : columns.entrySet()) {
			if (record.getObject(entrySet.getKey()) != null) {
				copiedColumn.put(entrySet.getKey(), entrySet.getValue());
			}
		}

		return copiedColumn;
	}

	/**
	 * 配列をリストに変換します.<br/>
	 * 変換には{@link Arrays#asList(Object...)}を使用します.<br/>
	 * 
	 * @param <T> 任意の型
	 * @param array 配列
	 * @return 配列より変換されたリスト
	 * @author KCCS hashimoto
	 * @create 2012/12/26
	 * @since 3.12.0
	 */
	@SafeVarargs
	protected static <T> List<T> asList(T... array) {
		if (array == null) {
			return new ArrayList<T>();
		}
		return new ArrayList<T>(Arrays.asList(array));
	}

	
	/**
	 * SQL断片に管理ＩＤを付与します.
	 * 
	 * @param piece 管理ＩＤを付与するSQL断片
	 * @param managementID 管理ＩＤ
	 * @return 管理IDが装飾されたSQL断片
	 * @author KCCS hashimoto
	 * @create 2013/02/06
	 * @since 3.12.0
	 */
	protected GSQLPiece decorateManagementID(GSQLPiece piece,
			String managementID) {
		if (piece != null && piece.getSql() != null && managementID != null) {
			String sql = piece.getSql();
			sql = sql + " /* " + managementID + " */";
			piece.setSql(sql);
		}
		return piece;
	}
	
	/**
	 * 排他キーを退避します.
	 * 
	 * @param update 排他キーを保持するエンティティー
	 * @param record 退避する排他キーを保持するレコード
	 * @return 退避した排他キーを保持するレコードのリスト
	 * @author KCCS hashimoto
	 * @create 2013/02/06
	 * @since 3.12.0
	 */
	private List<GRecord> saveExclusiveKey(GEntityUpdate update, final GRecord record) {
		List<GRecord> list = new LinkedList<GRecord>();
		list.add(record);
		return saveExclusiveKey(update, list);
	}
	
	/**
	 * 排他キーを退避します.
	 * 
	 * @param update 排他キーを保持するエンティティー
	 * @param recordList 退避する排他キーを保持するレコードのリスト
	 * @return 退避した排他キーを保持するレコードのリスト
	 * @author KCCS hashimoto
	 * @create 2013/02/06
	 * @since 3.12.0
	 */
	private List<GRecord> saveExclusiveKey(GEntityUpdate update, final List<GRecord> recordList) {
		List<GRecord> savedList = new LinkedList<GRecord>();
		GColumn exclusiveKey = update.getEntity().getExclusiveKey();
		for (GRecord record : recordList) {
			GRecord copyRecord = GQueryAssistants.createRecord();
			copyRecord.setObject(exclusiveKey.getName(),
					record.getString(exclusiveKey.getName()));
			savedList.add(copyRecord);
		}
		return savedList;
	}
}
