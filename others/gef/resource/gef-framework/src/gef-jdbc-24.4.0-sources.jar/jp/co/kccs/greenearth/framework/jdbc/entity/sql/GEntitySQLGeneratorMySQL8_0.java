/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GRoutingExpressionConverter;

/**
 * {@link GEntitySQLGeneratorMySQLBase}をMySQL8.0用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GEntitySQLGeneratorMySQL8_0 extends GEntitySQLGeneratorMySQLBase {
	
	/**
	 * {@link GEntitySQLGeneratorMySQL8_0}のインスタンスを生成します.
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @param expConverterFactory {@link GRoutingExpressionConverter}のインスタンス
	 * @param joinPartGenerator {@link GJoinPartGenerator}のインスタンス
	 * @author okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
    public GEntitySQLGeneratorMySQL8_0(GSQLPartsGenerator sqlPartsGenerator, 
    								GRoutingExpressionConverter expConverterFactory, 
    								GJoinPartGenerator joinPartGenerator,
    								GLimitPartGenerator limitPartGenerator) {
    	super(sqlPartsGenerator, expConverterFactory, joinPartGenerator, limitPartGenerator);
	}
}
