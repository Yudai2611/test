/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GRoutingExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GEntitySQLGenerator}をMySQL用に実装する基底クラスです.
 * 
 * @author KCCS hashimoto
 * @create 2016/05/11
 * @since 3.18.0
 */
public class GEntitySQLGeneratorMySQLBase extends GEntitySQLGeneratorBase {
	
	/** 最大行数 */
//	private final int MAXSIZE = Integer.MAX_VALUE;
	
	/**
	 * {@link GEntitySQLGeneratorMySQLBase}のインスタンスを生成します.
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @param expConverterFactory {@link GRoutingExpressionConverter}のインスタンス
	 * @param joinPartGenerator {@link GJoinPartGenerator}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
    public GEntitySQLGeneratorMySQLBase(GSQLPartsGenerator sqlPartsGenerator, 
    								GRoutingExpressionConverter expConverterFactory, 
    								GJoinPartGenerator joinPartGenerator,
    								GLimitPartGenerator limitPartGenerator) {
    	super(sqlPartsGenerator, expConverterFactory, joinPartGenerator, limitPartGenerator);
	}
	
	@Override
	protected GSQLPiece createForUpdateClause(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		if (select.isForUpdate()) {
			sql.append(" FOR UPDATE");
			if (select.isNoWait()) {
				sql.append(" NOWAIT");
			}
		}
		return new GSQLPiece(sql.toString());
	}
}
