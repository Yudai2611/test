/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GRoutingExpressionConverter;

/**
 * {@link GEntitySQLGeneratorOracleBase}をOracle19c用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GEntitySQLGeneratorOracle19c extends GEntitySQLGeneratorOracleBase {
	
	/**
	 * {@link GEntitySQLGeneratorOracle19c}のインスタンスを生成します.
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @param expConverterFactory {@link GRoutingExpressionConverter}のインスタンス
	 * @param joinPartGenerator {@link GJoinPartGenerator}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
    public GEntitySQLGeneratorOracle19c(GSQLPartsGenerator sqlPartsGenerator, 
    								GRoutingExpressionConverter expConverterFactory, 
    								GJoinPartGenerator joinPartGenerator,
    								GLimitPartGenerator limitPartGenerator) {
    	super(sqlPartsGenerator, expConverterFactory, joinPartGenerator, limitPartGenerator);
	}
}
