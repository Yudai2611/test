/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GRoutingExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GEntitySQLGenerator}をOracle用に実装する基底クラスです.
 * 
 * @author KCCS hashimoto
 * @create 2016/08/30
 * @since 3.19.0
 */
public abstract class GEntitySQLGeneratorOracleBase extends GEntitySQLGeneratorBase {
	
	/**
	 * {@link GEntitySQLGeneratorOracleBase}のインスタンスを生成します.
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @param expConverterFactory {@link GRoutingExpressionConverter}のインスタンス
	 * @param joinPartGenerator {@link GJoinPartGenerator}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
    public GEntitySQLGeneratorOracleBase(GSQLPartsGenerator sqlPartsGenerator, 
    								GRoutingExpressionConverter expConverterFactory, 
    								GJoinPartGenerator joinPartGenerator,
    								GLimitPartGenerator limitPartGenerator) {
    	super(sqlPartsGenerator, expConverterFactory, joinPartGenerator, limitPartGenerator);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public GSQLPiece createForUpdateClause(GEntitySelect select) {

		StringBuilder sql = new StringBuilder();

		if (select.isForUpdate()) {
			sql.append(" FOR UPDATE");
			if (select.isNoWait()) {
				sql.append(" NOWAIT");
			} else if (select.getWaitTime() > -1) {
				sql.append(" WAIT " + select.getWaitTime());
			}
		}
		return new GSQLPiece(sql.toString());
	}
}
