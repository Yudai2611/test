/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GRoutingExpressionConverter;

/**
 * {@link GEntitySQLGeneratorPostgreSQLBase}をPostgreSQL13.2用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GEntitySQLGeneratorPostgreSQL13_2 extends GEntitySQLGeneratorPostgreSQLBase {

	/**
	 * {@link GEntitySQLGeneratorPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @param expConverterFactory {@link GRoutingExpressionConverter}のインスタンス
	 * @param joinPartGenerator {@link GJoinPartGenerator}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
    public GEntitySQLGeneratorPostgreSQL13_2(GSQLPartsGenerator sqlPartsGenerator,
											 GRoutingExpressionConverter expConverterFactory,
											 GJoinPartGenerator joinPartGenerator,
											 GLimitPartGenerator limitPartGenerator) {
    	super(sqlPartsGenerator, expConverterFactory, joinPartGenerator, limitPartGenerator);
	}
}
