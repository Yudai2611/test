/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.sql.GLimitPartGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GRoutingExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GEntitySQLGenerator}をPostgreSQL用に実装する基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GEntitySQLGeneratorPostgreSQLBase extends GEntitySQLGeneratorBase {

	/**
	 * {@link GEntitySQLGeneratorPostgreSQLBase}のインスタンスを生成します.
	 *
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @param expConverterFactory {@link GRoutingExpressionConverter}のインスタンス
	 * @param joinPartGenerator {@link GJoinPartGenerator}のインスタンス
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
    public GEntitySQLGeneratorPostgreSQLBase(GSQLPartsGenerator sqlPartsGenerator,
											 GRoutingExpressionConverter expConverterFactory,
											 GJoinPartGenerator joinPartGenerator,
											 GLimitPartGenerator limitPartGenerator) {
    	super(sqlPartsGenerator, expConverterFactory, joinPartGenerator, limitPartGenerator);
	}

	@Override
	protected GSQLPiece createForUpdateClause(GEntitySelect select) {
		StringBuilder sql = new StringBuilder();
		if (select.isForUpdate()) {
			sql.append(" FOR UPDATE");
			if (select.isNoWait()) {
				sql.append(" NOWAIT");
			}
		}
		return new GSQLPiece(sql.toString());
	}
	
}
