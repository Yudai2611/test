/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GExpressionJoinData;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GExpressionJoinData}を元に、JOIN句を生成する{@link GJoinPartGenerator}実装です。
 * 
 * @author KCCS kitamura
 * @since 3.12.0
 * @create 2013/07/25
 */
public class GExpressionJoinPartGenerator implements GJoinPartGenerator {

	/** {@link GSQLPartsGenerator} */
	private GSQLPartsGenerator sqlPartsGenerator;
	/** {@link GExpressionConverter} */
	private GExpressionConverter expConverter;

	/**
	 * {@link GExpressionJoinPartGenerator}を初期化します。
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}インスタンス
	 * @param expConverter {@link GExpressionConverter}インスタンス
	 * @author KCCS kitamura
	 * @since 2013/07/25
	 */
	public GExpressionJoinPartGenerator(GSQLPartsGenerator sqlPartsGenerator, GExpressionConverter expConverter) {
		this.sqlPartsGenerator = sqlPartsGenerator;
		this.expConverter = expConverter;
	}

	@Override
	public GSQLPiece createJoinClause(GEntitySelect select, GJoinData joinData) {
		GExpressionJoinData expJoinData = (GExpressionJoinData) joinData;

		StringBuilder sql = new StringBuilder();
		
		// 結合の種類
		sql.append(joinData.getJoinType().getPhrase()).append(" ");
		// 結合するエンティティ
		sql.append(sqlPartsGenerator.createTableName(joinData.getJoinEntity(), joinData.getJoinEntityAlias())).append(" ");
		// 結合条件
		sql.append("ON ");
		GSQLPiece piece = expConverter.convertExpression(select, expJoinData.getExpression());
		piece.insertSql(0, sql.toString());
		
		return piece;
	}

	/**
	 * 配列をリストに変換します.<br/>
	 * 変換には{@link Arrays#asList(Object...)}を使用します.<br/>
	 * 
	 * @param <T> 任意の型
	 * @param array 配列
	 * @return 配列より変換されたリスト
	 * @author KCCS hashimoto
	 * @create 2012/12/26
	 * @since 3.12.0
	 */
	@SafeVarargs
	protected static <T> List<T> asList(T... array) {
		if (array == null) {
			return new ArrayList<T>();
		}
		return new ArrayList<T>(Arrays.asList(array));
	}

}
