/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GForeignKeyJoinData;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GJoinColumn;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GForeignKeyJoinData}を元に、JOIN句を生成する{@link GJoinPartGenerator}実装です。
 * 
 * @author KCCS kitamura
 * @since 3.12.0
 * @create 2013/07/25
 */
public class GForeignKeyJoinPartGenerator implements GJoinPartGenerator {

	/** {@link GSQLPartsGenerator} */
	private GSQLPartsGenerator sqlPartsGenerator;

	/**
	 * {@link GForeignKeyJoinPartGenerator}を初期化します。
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}
	 * @author KCCS kitamura
	 * @since 2013/07/25
	 */
	public GForeignKeyJoinPartGenerator(GSQLPartsGenerator sqlPartsGenerator) {
		this.sqlPartsGenerator = sqlPartsGenerator;
	}

	@Override
	public GSQLPiece createJoinClause(GEntitySelect select, GJoinData joinData) {
		GForeignKeyJoinData fkJoinData = (GForeignKeyJoinData) joinData;

		StringBuilder sql = new StringBuilder();
		
		// 結合の種類
		sql.append(joinData.getJoinType().getPhrase()).append(" ");
		// 結合するエンティティ
		sql.append(sqlPartsGenerator.createTableName(joinData.getJoinEntity(), joinData.getJoinEntityAlias())).append(" ");
		// 結合条件
		sql.append("ON ");
		GSQLPiece piece = createJoinCondition(select, fkJoinData);
		piece.insertSql(0, sql.toString());
		
		return piece;
	}
	
	/**
	 * SQL断片に外部キーの情報から取得できる結合条件を生成します。
	 * 
	 * @param select 検索系クエリ
	 * @param joinData 外部キーを使用する場合の結合情報（{@link GForeignKeyJoinData}）
	 * @return 結合条件が追加されたSQL断片
	 * @author KCCS K.Fujita
	 * @create 2013/03/29
	 * @since 3.12.0
	 */
	protected GSQLPiece createJoinCondition(GEntitySelect select, GForeignKeyJoinData joinData) {
		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new LinkedList<GBindParam>();

		StringBuilder whereSQL = new StringBuilder();
		int paramIndex = 0;
		Object[] joinDataParams = joinData.getBindParams();

		for (GJoinColumn joinColumn : joinData.getForeignKey().getJoinColumns()) {
			whereSQL.append(" AND ");

			GColumn srcColumn = joinColumn.getSourceColumn();
			GColumn refColumn = joinColumn.getReferenceColumn();
			// <JoinColumn srcName="CompanyCode" refName="CompanyCode" />
			if (srcColumn != null && refColumn != null) { 
				// 左辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, srcColumn, joinData.getMainEntityAlias()));
				whereSQL.append(" = ");
				// 右辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, refColumn, joinData.getJoinEntityAlias()));
			}
			// <JoinColumn srcName="CompanyCode" bindParameter="true" />
			else if (srcColumn != null && refColumn == null && joinColumn.isUseBindParameter()) {
				// 左辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, srcColumn, joinData.getMainEntityAlias()));
				// 右辺
				if (joinDataParams[paramIndex] != null) {
					whereSQL.append(" = ?");
					parameter.add(GBindParam.create(joinDataParams[paramIndex], srcColumn.getType()));
				} else {
					whereSQL.append(" IS NULL");
				}
				paramIndex++;
			}
			// <JoinColumn refName="CompanyCode" bindParameter="true" />
			else if (srcColumn == null && refColumn != null && joinColumn.isUseBindParameter()) {
				// 左辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, refColumn, joinData.getJoinEntityAlias()));
				// 右辺
				if (joinDataParams[paramIndex] != null) {
					whereSQL.append(" = ?");
					parameter.add(GBindParam.create(joinDataParams[paramIndex], refColumn.getType()));
				} else {
					whereSQL.append(" IS NULL");
				}
				paramIndex++;
			}
			// <JoinColumn srcName="CompanyCode" constValue="Value" />
			else if (srcColumn != null && refColumn == null && joinColumn.getConstValue() != null) {
				// 左辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, srcColumn, joinData.getMainEntityAlias()));
				whereSQL.append(" = ");
				// 右辺
				whereSQL.append(joinColumn.getConstValue());
			}
			// <JoinColumn refName="CompanyCode" constValue="Value" />
			else if (srcColumn == null && refColumn != null && joinColumn.getConstValue() != null) {
				// 左辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, refColumn, joinData.getJoinEntityAlias()));
				whereSQL.append(" = ");
				// 右辺
				whereSQL.append(joinColumn.getConstValue());
			}
			// <JoinColumn srcName="CompanyCode" isNull="true"/>
			else if (srcColumn != null && refColumn == null && joinColumn.getIsNull()) {
				// 左辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, srcColumn, joinData.getMainEntityAlias()));
				// 右辺
				whereSQL.append(" IS NULL ");
			}
			// <JoinColumn refName="CompanyCode" isNull="true"/>
			else if (srcColumn == null && refColumn != null && joinColumn.getIsNull()) {
				// 左辺
				whereSQL.append(sqlPartsGenerator.createColumnFullName(select, refColumn, joinData.getJoinEntityAlias()));
				// 右辺
				whereSQL.append(" IS NULL ");
			}
		}
		whereSQL.delete(0, 5); // 最初の" AND "を削除
		sql.append(whereSQL);
		
		return new GSQLPiece(sql.toString(), parameter.toArray(new GBindParam[parameter.size()]));
	}

	/**
	 * 配列をリストに変換します.<br/>
	 * 変換には{@link Arrays#asList(Object...)}を使用します.<br/>
	 * 
	 * @param <T> 任意の型
	 * @param array 配列
	 * @return 配列より変換されたリスト
	 * @author KCCS hashimoto
	 * @create 2012/12/26
	 * @since 3.12.0
	 */
	@SafeVarargs
	protected static <T> List<T> asList(T... array) {
		if (array == null) {
			return new ArrayList<T>();
		}
		return new ArrayList<T>(Arrays.asList(array));
	}

}
