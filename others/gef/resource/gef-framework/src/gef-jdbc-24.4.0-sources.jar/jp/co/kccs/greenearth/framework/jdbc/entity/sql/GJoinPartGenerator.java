/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * JOIN句を生成するインタフェースです。
 * 
 * @author KCCS kitamura
 * @since 3.12.0
 * @create 2013/07/25
 */
public interface GJoinPartGenerator {

	/**
	 * JOIN句のSQL断片を生成します。
	 * 
	 * @param select 検索用エンティティー
	 * @param joinData 結合条件
	 * @return SQL断片
	 * @author KCCS kitamura
	 * @since 2013/07/25
	 */
	GSQLPiece createJoinClause(GEntitySelect select, GJoinData joinData);
}
