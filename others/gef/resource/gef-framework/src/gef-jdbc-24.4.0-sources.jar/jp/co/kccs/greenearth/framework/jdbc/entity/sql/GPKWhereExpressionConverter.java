/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityCUD;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.GPKWhereExpression;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GPrimaryKey;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GPKWhereExpression}をSQL断片に変換する機能を提供します.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GPKWhereExpressionConverter implements GExpressionConverter {
	
	/** {@link GSQLPartsGenerator}のインスタンス */
    public GSQLPartsGenerator sqlPartsGenerator = null;
    
    /**
     * {@link GPKWhereExpressionConverter}を初期化します.
     * 
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
     */
    public GPKWhereExpressionConverter() {
	}
    
    /**
     * {@link GSQLPartsGenerator}のインスタンスを設定します.
     * 
     * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setSqlPartsGenerator(GSQLPartsGenerator sqlPartsGenerator) {
		this.sqlPartsGenerator = sqlPartsGenerator;
	}
	
	@Override
	public GSQLPiece convertExpression(GQuery< ? > query, GExpression exp) {
		GEntityQuery<?> entityQuery = (GEntityQuery<?>) query;
		GPKWhereExpression pkExp = (GPKWhereExpression) exp;
		
		validatePrimaryKeyDefined(entityQuery); // 定義チェック
		GPrimaryKey primaryKey = entityQuery.getEntity().getPrimaryKey();
			
		// パラメータの抽出
		Object[] params = null;
		if (entityQuery instanceof GEntityCUD<?> && pkExp.isUseRecord()) {
			GRecord record = ((GEntityCUD<?>) entityQuery).getTargetRecord();
			params = extractPrimaryKeyParameter(entityQuery, record);
		}
		else {
			params = pkExp.getPrimaryKeys();
		}
		validatePrimaryKeyParameter(entityQuery, params);
		
		// Where句の生成
		StringBuilder whereSQL = new StringBuilder();
		List<GBindParam> bindParamList = new LinkedList<GBindParam>();
		List<GColumn> primaryKeyColumns = primaryKey.getReferenceColumns();
		for (int i = 0; i < primaryKeyColumns.size(); i++) {
			GColumn primaryKeyColumn = primaryKeyColumns.get(i);
			whereSQL.append(" AND").append(" ");
			whereSQL.append(this.sqlPartsGenerator.createColumnFullName(entityQuery, primaryKeyColumn, entityQuery.getEntityAlias()));
			whereSQL.append(" = ").append("?");
			bindParamList.add(GBindParam.create(params[i], primaryKeyColumn.getType()));
		}
		whereSQL.delete(0, 5); // 最初の"AND "を削除
		StringBuilder sql = new StringBuilder();
		sql.append(whereSQL);

		return new GSQLPiece(sql.toString(), (GBindParam[]) bindParamList.toArray(new GBindParam[bindParamList.size()]));
	}
	
	@Override
	public GSQLPiece convertBatchExpression(GQuery< ? > query, GExpression exp) {
		GEntityCUD<?> entityQuery = (GEntityCUD<?>) query;
		
		validatePrimaryKeyDefined(entityQuery); // 定義チェック
		GPrimaryKey primaryKey = entityQuery.getEntity().getPrimaryKey();
		
		// パラメータ抽出
		List<GBindParam[]> bindParamsList = new LinkedList<GBindParam[]>();
		List<GRecord> recordList = entityQuery.getTargetRecordList();
		for (GRecord record : recordList) {
			Object[] params = extractPrimaryKeyParameter(entityQuery, record);
			
			validatePrimaryKeyParameter(entityQuery, params);
			
			GBindParam[] bindParams = GBindParam.toBindParams(params);
//			List<GBindParam> bindParamList = new ArrayList<GBindParam>();
//			for (GBindParam bindParam : bindParams) {
//				bindParamList.add(bindParam);
//			}
			bindParamsList.add(bindParams);
		}
		
		// Where句の生成
		StringBuilder whereSQL = new StringBuilder();
		List<GColumn> primaryKeyColumns = primaryKey.getReferenceColumns();
		for (int i = 0; i < primaryKeyColumns.size(); i++) {
			GColumn primaryKeyColumn = primaryKeyColumns.get(i);
			whereSQL.append(" AND").append(" ");
			whereSQL.append(this.sqlPartsGenerator.createColumnFullName(entityQuery, primaryKeyColumn, entityQuery.getEntityAlias()));
			whereSQL.append(" = ").append("?");
		}
		whereSQL.delete(0, 5); // 最初の"AND "を削除
		StringBuilder sql = new StringBuilder();
		sql.append(whereSQL);
		
//		GSQLPiece piece = new GSQLPiece(sql.toString());
//		for (List<GBindParam> list : bindParamsList) {
//			piece.addParameter(list.toArray(new GBindParam[list.size()]));
//		}
//		
//		return piece;
		return new GSQLPiece(sql.toString(), bindParamsList);
	}
	
	/**
	 * 指定されたクエリの主キー項目のパラメータをレコードから抽出します.
	 * 
	 * @param query クエリ
	 * @param record レコード
	 * @return 主キー項目のパラメータ
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected Object[] extractPrimaryKeyParameter(GEntityQuery< ? > query, GRecord record) {
		List<GColumn> primaryKeyColumns = query.getEntity().getPrimaryKey().getReferenceColumns();
		List<Object> list = new ArrayList<Object>();
		for (GColumn primaryKeyColumn : primaryKeyColumns) {
			list.add(record.getObject(primaryKeyColumn.getName()));
		}
		return list.toArray();
	}
	
	
	/**
	 * 渡されたパラメータ配列が主キー検索のパラメータとして適切かどうかを検査します.<br/>
	 * パラメータ配列のサイズが指定されたエンティティに定義されている主キーの項目数と
	 * 
	 * @param query クエリ
	 * @param params 主キーのパラメータ
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected void validatePrimaryKeyParameter(GEntityQuery<?> query, Object[] params) {
		// 定義チェック
		this.validatePrimaryKeyDefined(query);
		
		// NULLチェック
		this.checkPKIsNull(params);

		// 指定のキー項目数とパラメータ数が同じであるかチェック。
		List<GColumn> primaryKeyColumns = query.getEntity().getPrimaryKey().getReferenceColumns();
		if (primaryKeyColumns.size() != params.length) {
			throw new IllegalArgumentException("The number of column and the number of parameter are different.");
		}
	}
	
	/**
	 * エンティティに主キーが定義されているかチェックします.<br/>
	 * 主キーが定義されていない場合、{@link IllegalStateException}がスローされます.<br/>
	 * 
	 * @param query クエリ
	 * @throws IllegalStateException 主キーが定義されていない場合の例外
	 * @author hashimoto
	 * @create 2012/11/12
	 * @since 3.12.0
	 */
	protected void validatePrimaryKeyDefined(GEntityQuery<?> query) throws IllegalStateException {
		// エンティティーよりＰＫ情報を取り出す
		GPrimaryKey primaryKey = query.getEntity().getPrimaryKey();

		// 指定されたプライマリーキーが定義されていない場合は例外をスローする
		if (primaryKey == null || primaryKey.getReferenceColumns().size() == 0) {
			throw new IllegalStateException("Primary key is not defined in Entity.");
		}
	}
	
	/**
	 * パラメータ配列にnullが含まれていないかチェックします.<br/>
	 * 1つ以上null値が含まれている場合、{@link IllegalArgumentException}がスローされます.<br/>
	 * 
	 * @param primaryKeyParams パラメータ配列
	 * @throws IllegalArgumentException 値がnullの場合の例外
	 * @author hashimoto
	 * @create 2012/11/12
	 * @since 3.12.0
	 */
	protected void checkPKIsNull(Object... primaryKeyParams) throws IllegalArgumentException {
		// nullの項目がある場合は例外をスローする
		for (Object primaryKeyParam : primaryKeyParams) {
			if (primaryKeyParam == null) {
				throw new IllegalArgumentException("Primary key does not allow Null values.");
			}
		}
	}
}
