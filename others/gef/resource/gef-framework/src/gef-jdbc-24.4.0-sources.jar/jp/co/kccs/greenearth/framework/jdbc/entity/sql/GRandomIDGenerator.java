/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.UUID;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * 自動生成タイプが "RandomID" の際のSQLとパラメータを生成するクラスです.
 * 
 * @create 2012/12/09
 * @author KCCS K.Fujita
 * @since 3.12.0
 */
public class GRandomIDGenerator implements GAutoValueGenerator {

	@Override
	public GSQLPiece createValue4ValuesClause(GColumn column, GRecord record) {
		String genaratedValue = createRandomID();
		GBindParam[] params = {GBindParam.create(genaratedValue,
				column.getType()) };
		setGenaratedValueToRecord(column.getName(), genaratedValue, record);
		return new GSQLPiece("?", params);
	}

	@Override
	public GSQLPiece createValue4SetClause(GColumn column, GRecord record) {
		return null;
	}

	/**
	 * ランダムに採番したＩＤ（UUID）を生成します.
	 * 
	 * @return ランダムに採番したＩＤ（32桁）
	 * @author KCCS hashimoto
	 * @create 2014/08/19
	 * @since 3.12.0
	 */
	private String createRandomID() {
		return UUID.randomUUID().toString().replaceAll("-", ""); // 32桁ID
	}

	/**
	 * ランダムに採番したＩＤ（UUID）をGRecordにセットします.
	 * 
	 * @param columnName UUIDをセットする項目名
	 * @param genaratedValue 生成したUUID
	 * @param record 自動生成項目を含む{@link GRecord}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2014/08/19
	 * @since 3.12.0
	 */
	private void setGenaratedValueToRecord(String columnName,
			String genaratedValue, GRecord record) {
		record.setObject(columnName, genaratedValue);
	}
}
