/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * 自動生成タイプが "RegisteredDate" の際のSQLとパラメータを生成するクラスです.
 * 
 * @create 2012/12/09
 * @author KCCS K.Fujita
 * @since 3.12.0
 */
public class GRegisteredDateGenerator implements GAutoValueGenerator {

	/** {@link GFunctionGenerator}のインスタンス */
	public GFunctionGenerator funcGenerator = null;

	/**
	 * クラスフィールドに{@link GFunctionGenerator}のインスタンスを設定します.
	 * 
	 * @param funcGenerator {@link GFunctionGenerator}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/12/10
	 * @since 3.12.0
	 */
	public void setFunctionGenerator(GFunctionGenerator funcGenerator) {
		this.funcGenerator = funcGenerator;
	}

	@Override
	public GSQLPiece createValue4ValuesClause(GColumn column, GRecord record) {
		String sql = funcGenerator.createFunction("CURRENT_TIMESTAMP", new String[] {});
		return new GSQLPiece(sql);
	}

	@Override
	public GSQLPiece createValue4SetClause(GColumn column, GRecord record) {
		return null;
	}
}
