/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.Map;

import jp.co.kccs.greenearth.commons.exception.GClassNotFoundRuntimeException;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * JOIN句生成処理を{@link GJoinData}の型にあった適切な{@link GJoinPartGenerator}にルーティングする{@link GJoinPartGenerator}実装です。
 * 
 * @author KCCS kitamura
 * @since 3.12.0
 * @create 2013/07/25
 */
public class GRoutingJoinPartGenerator implements GJoinPartGenerator {

	/** ルーティング制御テーブル */
	private Map<String, GJoinPartGenerator> generators;

	/**
	 * ルーティング制御テーブルを指定して、{@link GRoutingJoinPartGenerator}を初期化します。
	 * 
	 * @param generators ルーティング制御テーブル
	 * @author KCCS kitamura
	 * @since 3.12.0
	 * @create 2013/07/25
	 */
	public GRoutingJoinPartGenerator(Map<String, GJoinPartGenerator> generators) {
		this.generators = generators;
	}
	
	@Override
	public GSQLPiece createJoinClause(GEntitySelect select, GJoinData joinData) {
		String key = joinData.getClass().getName();
		if (!this.generators.containsKey(key)) {
			throw new GClassNotFoundRuntimeException(key +  " bean is not found.");
		}
		return this.generators.get(key).createJoinClause(select, joinData);
		
	}

}
