/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityUpdate;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * カラム関連部分のSQL断片を生成するインタフェースです。
 * 
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public interface GSQLPartsGenerator {

	/**
	 * SELECT文の抽出カラム部分を生成します。
	 * 
	 * @param select 検索用エンティティー
	 * @param column 抽出カラム
	 * @return SQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	GSQLPiece createColumn4SelectClause(GEntitySelect select, GSelectColumn column);

	/**
	 * GroupByで使用するカラム部分を生成します。
	 * 
	 * @param select 検索用エンティティー
	 * @param column カラム
	 * @return SQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	GSQLPiece createColumn4GroupByClause(GEntitySelect select, GSelectColumn column);

	/**
	 * OrderByで使用するカラム部分を生成します。
	 * 
	 * @param select 検索用エンティティー
	 * @param column カラム
	 * @return SQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	GSQLPiece createColumn4OrderByClause(GEntitySelect select, GSelectColumn column);

	/**
	 * カラム名を生成します。
	 * 
	 * @param query エンティティー
	 * @param column カラム
	 * @param entityAlias 別名
	 * @return カラム名
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	String createColumnFullName(GEntityQuery< ? > query, GColumn column, String entityAlias);

	/**
	 * SET節で使用するカラム部分を生成します。
	 * 
	 * @param update 更新用エンティティ
	 * @param column 更新カラム
	 * @param record SQL文にバインドする値
	 * @return SET句のSQL断片及びバンドする値を設定した{@link GSQLPiece}
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	GSQLPiece createColumn4SetClause(GEntityUpdate update, GColumn column, GRecord record);

	/**
	 * INTO節で使用するカラム部分を生成します。
	 * 
	 * @param column 登録カラム
	 * @return カラム名
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	String createColumn4IntoClause(GColumn column);

	/**
	 * VALUE節で使用するカラム部分を生成します。
	 * 
	 * @param column 登録カラム
	 * @param record SQL文にバインドする値
	 * @return SQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	GSQLPiece createColumn4ValuesClause(GColumn column, GRecord record);
	
	/**
	 * SQLで使用できるよう最適化したテーブル名を生成します。
	 * 
	 * @param entity エンティティ
	 * @param entityAlias エイリアス
	 * @return 最適化したテーブル名
	 * @author KCCS hashimoto
	 * @create 2013/2/25
	 * @since 3.12.0
	 */
	String createTableName(GEntity entity, String entityAlias);

}
