/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityUpdate;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn.OrderType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn.FuncType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator;
import jp.co.kccs.greenearth.framework.jdbc.sql.GReservedWordEscaper;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GSQLPartsGenerator}インターフェースの実装クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/11/30
 * @since 3.12.0
 */
public class GSQLPartsGeneratorImpl implements GSQLPartsGenerator {

	/** {@link GFunctionGenerator}のインスタンス */
	public GFunctionGenerator funcGenerator = null;
	/** {@link GExpressionConverter}のインスタンス */
	public GExpressionConverter expConverter = null;
	/** {@link GAutoValueGenerator}のインスタンスを保持するマップ */
	protected Map<String, GAutoValueGenerator> generatorMap = new HashMap<String, GAutoValueGenerator>();
    /** {@link GReservedWordEscaper}のインスタンス */
    public GReservedWordEscaper reservedWordEscaper = null;

	/**
	 * GColumnPartGeneratorBaseのインスタンスを生成します.
	 * 
	 * @author KCCS hashimoto
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	public GSQLPartsGeneratorImpl() {
	}

	/**
	 * GColumnPartGeneratorBaseのインスタンスを生成します.
	 * 
	 * @param map {@link GAutoValueGenerator}のインスタンスを保持するマップ
     * @param reservedWordEscaper {@link GReservedWordEscaper}のインスタンスを保持するマップ
	 * @author KCCS K.Fujita
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	public GSQLPartsGeneratorImpl(Map<String, GAutoValueGenerator> map, GReservedWordEscaper reservedWordEscaper) {
	    this.reservedWordEscaper = reservedWordEscaper;
		generatorMap.putAll(map);
	}

	/**
	 * {@GFunctionGenerator}のインスタンスを設定します.
	 * 
	 * @param funcGenerator {@link GFunctionGenerator}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	public void setFunctionGenerator(GFunctionGenerator funcGenerator) {
		this.funcGenerator = funcGenerator;
	}

	/**
	 * {@link GExpressionConverter}のインスタンスを設定します.
	 * 
	 * @param expConverter {@link GExpressionConverter}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	public void setExpressionConverter(GExpressionConverter expConverter) {
		this.expConverter = expConverter;
	}

	@Override
	public String createColumnFullName(GEntityQuery< ? > query, GColumn column, String entityAlias) {
		StringBuilder columnsSQL = new StringBuilder();
		if (entityAlias != null) {
			entityAlias = reservedWordEscaper.escapeReservedWord(entityAlias);
			columnsSQL.append(entityAlias).append(".");
		} else {
			GEntity entity = column.getEntity();
			columnsSQL.append(createTableName(entity, null)).append(".");
		}
		String escapedColumnName = reservedWordEscaper.escapeReservedWord(column.getPhyName());
		columnsSQL.append(escapedColumnName);
		return columnsSQL.toString();
	}

	@Override
	public GSQLPiece createColumn4SelectClause(GEntitySelect select, GSelectColumn sc) {

		StringBuilder sql = new StringBuilder();
		List<GBindParam> parameter = new ArrayList<GBindParam>();
		// 項目名指定
		if (sc.getColumn() != null) {
			String fullName = createColumnFullName(select, sc.getColumn(), sc.getEntityAlias());
			sql.append(createColumnWithFunc(select, sc, fullName));
		}
		// 式指定
		else {
			GExpression exp = sc.getExpression();
			GSQLPiece piece = expConverter.convertExpression(select, exp);
			sql.append(piece.getSql());
			GBindParam[] bindParams = piece.getParameter();
			if (bindParams != null && bindParams.length > 0) {
				parameter.addAll(Arrays.asList(bindParams));
			}
		}

		// 列別名の付与
		String columnAlias = sc.getResultSetKey();
		columnAlias = reservedWordEscaper.escapeReservedWord(columnAlias);
		sql.append(" AS ").append(columnAlias);

		return new GSQLPiece(sql.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
	}

	@Override
	public GSQLPiece createColumn4GroupByClause(GEntitySelect select, GSelectColumn sc) {
		StringBuilder columnsSQL = new StringBuilder();
		List<GBindParam> parameter = new ArrayList<GBindParam>();
		// 項目名指定
		if (sc.getColumn() != null) {
			columnsSQL.append(createColumnFullName(select, sc.getColumn(), sc.getEntityAlias()));
		}
		// 式指定
		else {
			GExpression exp = sc.getExpression();
			GSQLPiece piece = expConverter.convertExpression(select, exp);
			columnsSQL.append(piece.getSql());
			GBindParam[] bindParams = piece.getParameter();
			if (bindParams != null && bindParams.length > 0) {
				parameter.addAll(Arrays.asList(bindParams));
			}

		}
		return new GSQLPiece(columnsSQL.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
	}

	@Override
	public GSQLPiece createColumn4OrderByClause(GEntitySelect select, GSelectColumn sc) {
		StringBuilder columnsSQL = new StringBuilder();
		List<GBindParam> parameter = new ArrayList<GBindParam>();
		if (sc.getAlias() != null) { // エイリアス指定
			columnsSQL.append(reservedWordEscaper.escapeReservedWord(sc.getAlias()));
		} else if (sc.getColumn() != null) { // 項目名指定
			String fullName = createColumnFullName(select, sc.getColumn(), sc.getEntityAlias());
			columnsSQL.append(createColumnWithFunc(select, sc, fullName));
		} else { // 式指定
			GExpression exp = sc.getExpression();
			GSQLPiece piece = expConverter.convertExpression(select, exp);
			columnsSQL.append(piece.getSql());
			GBindParam[] bindParams = piece.getParameter();
			if (bindParams != null && bindParams.length > 0) {
				parameter.addAll(Arrays.asList(bindParams));
			}
		}

		columnsSQL.append(" ");
		columnsSQL.append(sc.getOrderType() == OrderType.ASC ? "ASC" : "DESC");

		return new GSQLPiece(columnsSQL.toString(), (GBindParam[]) parameter.toArray(new GBindParam[parameter.size()]));
	}

	@Override
	public String createColumn4IntoClause(GColumn column) {
		String columnName = column.getPhyName();
		columnName = reservedWordEscaper.escapeReservedWord(columnName);
		return columnName;
	}

	@Override
	public GSQLPiece createColumn4ValuesClause(GColumn column, GRecord record) {
		// 自動生成項目対応
		String generateType = column.getGenerateType();
		if (generatorMap.containsKey(generateType)) {
			GAutoValueGenerator generator = generatorMap.get(generateType);
			GSQLPiece piece = generator.createValue4ValuesClause(column, record);
			if (piece != null) {
				return piece;
			}
		}

		StringBuilder sql = new StringBuilder();
		sql.append('?');
		Object value = record.getObject(column.getName());
		GBindParam[] params = {GBindParam.create(value, column.getType())};
		return new GSQLPiece(sql.toString(), params);
	}

	@Override
	public GSQLPiece createColumn4SetClause(GEntityUpdate update, GColumn column, GRecord record) {
		StringBuilder sql = new StringBuilder();
		sql.append(reservedWordEscaper.escapeReservedWord(column.getPhyName())).append("="); // 予約語のエスケープ

		// 自動生成項目対応
		String generateType = column.getGenerateType();
		if (update.isExclusive() && column.isExclusiveKey()) {
			generateType = "ExclusiveKey";
		}
		if (generatorMap.containsKey(generateType)) {
			GAutoValueGenerator generator = generatorMap.get(generateType);
			GSQLPiece piece = generator.createValue4SetClause(column, record);
			if (piece != null) {
				return new GSQLPiece(sql.append(piece.getSql()).toString(), piece.getParameter());
			}
		}

		sql.append("?");
		
		Object value = record.getObject(column.getName());
		GBindParam[] params = {GBindParam.create(value, column.getType())};
		return new GSQLPiece(sql.toString(), params);
	}
	
	@Override
	public String createTableName(GEntity entity, String entityAlias) {

		StringBuilder tableName = new StringBuilder();
		tableName.append(entity.getDatabase().getSchema()).append(".");
		tableName.append(reservedWordEscaper.escapeReservedWord(entity.getPhyName()));

		if (entityAlias != null) {
			tableName.append(" ").append(reservedWordEscaper.escapeReservedWord(entityAlias));
		}

		return tableName.toString();
	}
	

	/**
	 * カラムに関数を付与します.
	 * 
	 * @param select 検索用エンティティー
	 * @param sc カラム情報
	 * @param fullName ｴｲﾘｱｽを含むカラム名
	 * @return 関数化した文字列
	 * @author KCCS K.Fujita
	 * @create 2012/11/30
	 * @since 3.12.0
	 */
	protected String createColumnWithFunc(GEntitySelect select, GSelectColumn sc, String fullName) {
		FuncType funcType = sc.getFuncType();
		if (funcType == null) {
			// GroupByが指定されている場合は、必ずMAX関数を指定する
			if (select.getGroupColumns() != null && select.getGroupColumns().size() > 0) {
				funcType = FuncType.MAX;
			} else {
				return fullName;
			}
		}
		return funcGenerator.createFunction(funcType.getFuncName(), new String[] {fullName});
	}
}
