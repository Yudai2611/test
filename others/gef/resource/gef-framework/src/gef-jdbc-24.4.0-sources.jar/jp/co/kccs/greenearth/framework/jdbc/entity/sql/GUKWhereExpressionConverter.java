/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.entity.sql;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityCUD;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.GUKWhereExpression;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GUniqueKey;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam;
import jp.co.kccs.greenearth.framework.jdbc.sql.GExpressionConverter;
import jp.co.kccs.greenearth.framework.jdbc.sql.GSQLPiece;

/**
 * {@link GUKWhereExpression}をSQL断片に変換する機能を提供します.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public class GUKWhereExpressionConverter implements GExpressionConverter {
	
	/** {@link GSQLPartsGenerator}のインスタンス */
	public GSQLPartsGenerator sqlPartsGenerator = null;

	/**
	 * {@link GUKWhereExpressionConverter}を初期化します.
	 * 
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUKWhereExpressionConverter() {
	}

	/**
	 * {@link GSQLPartsGenerator}のインスタンスを設定します.
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setSqlPartsGenerator(GSQLPartsGenerator sqlPartsGenerator) {
		this.sqlPartsGenerator = sqlPartsGenerator;
	}
	
	@Override
	public GSQLPiece convertExpression(GQuery< ? > query, GExpression exp) {
		GEntityQuery<?> entityQuery = (GEntityQuery<?>) query;
		GUKWhereExpression ukExp = (GUKWhereExpression) exp;
		
		validateUniqueKeyDefined(entityQuery, ukExp.getUniqueKeyName()); // 定義チェック
		GUniqueKey uniqueKey = entityQuery.getEntity().getUniqueKeys().get(ukExp.getUniqueKeyName());

		// パラメータの抽出
		Object[] params = null;
		if (ukExp.isUseRecord()) {
			GRecord record = ((GEntityCUD<?>) entityQuery).getTargetRecord();
			params = extractUniqueKeyParameter(entityQuery, ukExp.getUniqueKeyName(), record);
		}
		else {
			params = ukExp.getUniqueKeys();
		}
		validateUniqueKeyParameter(entityQuery, params, uniqueKey.getName());
		
		// Where句の生成
		StringBuilder whereSQL = new StringBuilder();
		List<GBindParam> bindParamList = new LinkedList<GBindParam>();
		List<GColumn> uniqueKeyColumns = uniqueKey.getReferenceColumns();
		for (int i = 0; i < uniqueKeyColumns.size(); i++) {
			GColumn uniqueKeyColumn = uniqueKeyColumns.get(i);
			whereSQL.append(" AND").append(" ");
			whereSQL.append(this.sqlPartsGenerator.createColumnFullName(entityQuery, uniqueKeyColumn, entityQuery.getEntityAlias()));
			if (params[i] != null) {
				whereSQL.append(" = ").append("?");
				bindParamList.add(GBindParam.create(params[i], uniqueKeyColumn.getType()));
			}
			else {
				whereSQL.append(" ").append("IS NULL");
			}
		}
		whereSQL.delete(0, 5); // 最初の"AND "を削除
		StringBuilder sql = new StringBuilder();
		sql.append(whereSQL);
		
		return new GSQLPiece(sql.toString(), (GBindParam[]) bindParamList.toArray(new GBindParam[bindParamList.size()]));
	}
	
	@Override
	public GSQLPiece convertBatchExpression(GQuery< ? > query, GExpression exp) {
		GEntityCUD<?> entityQuery = (GEntityCUD<?>) query;
		GUKWhereExpression ukExp = (GUKWhereExpression) exp;
		
		validateUniqueKeyDefined(entityQuery, ukExp.getUniqueKeyName()); // 定義チェック
		GUniqueKey uniqueKey = entityQuery.getEntity().getUniqueKeys().get(ukExp.getUniqueKeyName());
		
		// パラメータ抽出
		List<GBindParam[]> bindParamsList = new LinkedList<GBindParam[]>();
		List<GRecord> recordList = entityQuery.getTargetRecordList();
		for (GRecord record : recordList) {
			Object[] params = extractUniqueKeyParameter(entityQuery, uniqueKey.getName(), record);
			
			validateUniqueKeyParameter(entityQuery, params, uniqueKey.getName());
			// ユニークキーがNULLでないかチェックする
			for (GColumn uniqueKeyParam : uniqueKey.getReferenceColumns()) {
				if (record.getObject(uniqueKeyParam.getName()) == null) {
					throw new IllegalArgumentException("Unique key does not allow Null values.");
				}
			}
			
			GBindParam[] bindParams = GBindParam.toBindParams(params);
//			List<GBindParam> bindParamList = new ArrayList<GBindParam>();
//			for (GBindParam bindParam : bindParams) {
//				bindParamList.add(bindParam);
//			}
			bindParamsList.add(bindParams);
		}
		
		// Where句の生成
		StringBuilder whereSQL = new StringBuilder();
		List<GColumn> uniqueKeyColumns = uniqueKey.getReferenceColumns();
		for (int i = 0; i < uniqueKeyColumns.size(); i++) {
			GColumn uniqueKeyColumn = uniqueKeyColumns.get(i);
			whereSQL.append(" AND").append(" ");
			whereSQL.append(this.sqlPartsGenerator.createColumnFullName(entityQuery, uniqueKeyColumn, entityQuery.getEntityAlias()));
			whereSQL.append(" = ").append("?");
		}
		whereSQL.delete(0, 5); // 最初の"AND "を削除
		StringBuilder sql = new StringBuilder();
		sql.append(whereSQL);
		
//		GSQLPiece piece = new GSQLPiece(sql.toString());
//		for (List<GBindParam> list : bindParamsList) {
//			piece.addParameter(list.toArray(new GBindParam[list.size()]));
//		}
//		
//		return piece;
		return new GSQLPiece(sql.toString(), bindParamsList);
	}
	
	/**
	 * ユニークキーが定義されているかかチェックします.
	 * 
	 * @param query クエリ
	 * @param uniqueKeyName ユニークキー名
	 * @throws IllegalStateException ユニークキーが定義されていない場合の例外
	 * @author hashimoto
	 * @create 2012/11/12
	 * @since 3.12.0
	 */
	protected void validateUniqueKeyDefined(GEntityQuery<?> query, String uniqueKeyName) throws IllegalStateException {
		GUniqueKey uniqueKey = query.getEntity().getUniqueKeys().get(uniqueKeyName);
		if (uniqueKey == null) {
			throw new IllegalStateException("This unique key is not defined in Entity. :" + uniqueKeyName);
		}
	}
	
	/**
	 * 指定されたユニークキーの項目数と渡されたパラメータの数が一致するかどうか検査します.<br/>
	 * 一致しない場合、{@link IllegalArgumentException}がスローされます.<br/>
	 * 
	 * @param query ユニークキーが指定されたクエリ
	 * @param params ユニークキーのパラメータ
	 * @param uniqueKeyName ユニークキー名
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected void validateUniqueKeyParameter(GEntityQuery<?> query, Object[] params, String uniqueKeyName) {
		List<GColumn> uniqueKeyColumns = query.getEntity().getUniqueKeys().get(uniqueKeyName).getReferenceColumns();
		if (uniqueKeyColumns.size() != params.length) {
			throw new IllegalArgumentException("The number of column and the number of parameter are different.");
		}
	}
	
	/**
	 * 指定されたクエリのユニークキー項目のパラメータをレコードから抽出します.
	 * 
	 * @param query ユニークキーが指定されたクエリ
	 * @param uniqueKeyName ユニークキー名
	 * @param record 値を抽出するレコード
	 * @return ユニークキー項目のパラメータ
	 * @author KCCS K.Fujita
	 * @create 2012/10/22
	 * @since 3.12.0
	 */
	protected Object[] extractUniqueKeyParameter(GEntityQuery< ? > query, String uniqueKeyName, GRecord record) {
		List<GColumn> uniqueKeyColumns = query.getEntity().getUniqueKeys().get(uniqueKeyName).getReferenceColumns();
		List<Object> list = new ArrayList<Object>();
		for (GColumn uniqueKeyColumn : uniqueKeyColumns) {
			list.add(record.getObject(uniqueKeyColumn.getName()));
		}
		return list.toArray();
	}

}
