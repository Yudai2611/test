/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * データベース上のカラムを表現するためのアノテーションです.<br/>
 * <pre>
 * Example :<br/>
 * 	<code>@Column(name = "ItemCD")</code>
 * 	public String getItemCD() {
 * 	    return itemCD;
 * 	}
 * </pre>
 * @author KCCS yamashita
 * @create 2012/11/05
 * @since 3.12.0
 */
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {

	/**
	 * カラム名を指定する属性です.<br/>
	 * 
	 * @return
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	String name() default "";
}
