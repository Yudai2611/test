/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * カラム（{@link Column}）に対するO/Rマッピング機能を表すインタフェースです。
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public interface GColumnPropertyMapper {

	/**
	 * {@link GRecord}に関連付けられたカラム名を取得します。
	 * 
	 * @return {@link GRecord}に関連付けられたカラム名
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	String getMappedColumnName();
	
	/**
	 * 指定したドメインモデルの対応するメンバ（{@link GColumnPropertyMapper#getMappedColumnName()}）の値を{@link GRecord}に設定します。
	 * 
	 * @param record レコード
	 * @param model ドメインモデル
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	void map(GRecord record, Object model);
	
	/**
	 * 指定した値をドメインモデルの対応するメンバ（{@link GColumnPropertyMapper#getMappedColumnName()}）に設定します。
	 * 
	 * @param model ドメインモデル
	 * @param value 値
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	void map(Object model, Object value);
	
	/**
	 * {@link GRecord}に関連付けられたカラム名を設定します。
	 * 
	 * @param mappedName {@link GRecord}に関連付けられたカラム名
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	void setMappedColumnName(String mappedName);
	
	/**
	 * ドメインモデルのメンバのプロパティから型を取得します。
	 * 
	 * @return 型
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	Class<?> getPropertyType();
}