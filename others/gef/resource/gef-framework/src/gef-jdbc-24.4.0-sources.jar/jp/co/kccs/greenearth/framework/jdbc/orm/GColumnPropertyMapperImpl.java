/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.beans.PropertyDescriptor;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * {@link GColumnPropertyMapper}の実装クラスです.<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public class GColumnPropertyMapperImpl extends GPropertyMapperBase implements GColumnPropertyMapper {
	
	/** {@link GRecord}に関連付けられたカラム名. */
	private String mappedColumnName;
	
	/**
	 * {@link GColumnPropertyMapperImpl}のインスタンスを生成します.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @param propertyDescriptor プロパティ
	 * @param columnName 項目名
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GColumnPropertyMapperImpl(Class<?> clazz, PropertyDescriptor propertyDescriptor, String columnName) {
		super(clazz, propertyDescriptor);
		this.mappedColumnName = columnName;
	}

	/**
	 * {@link GRecord}に関連付けられたカラム名を取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GColumnPropertyMapper#getMappedColumnName()
	 * @return {@link GRecord}に関連付けられたカラム名
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	@Override
	public String getMappedColumnName() {
		return this.mappedColumnName;
	}

	/**
	 * 指定したドメインモデルの対応するメンバ（{@link GColumnPropertyMapper#getMappedColumnName()}）の値を{@link GRecord}に設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GColumnPropertyMapper#map(jp.co.kccs.greenearth.framework.jdbc.GRecord, java.lang.Object)
	 * @param record レコード
	 * @param model ドメインモデル
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	@Override
	public void map(GRecord record, Object model) {
		Object value = readField(model);
		record.setObject(getMappedColumnName(), value);
	}

	/**
	 * 指定した値をドメインモデルの対応するメンバ（{@link GColumnPropertyMapper#getMappedColumnName()}）に設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GColumnPropertyMapper#map(java.lang.Object, java.lang.Object)
	 * @param model ドメインモデル
	 * @param value 値
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	@Override
	public void map(Object model, Object value) {
		writeField(model, value);
	}

	/**
	 * {@link GRecord}に関連付けられたカラム名を設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GColumnPropertyMapper#setMappedColumnName(java.lang.String)
	 * @param columnName {@link GRecord}に関連付けられたカラム名
	 * @author KCCS yamashita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	@Override
	public void setMappedColumnName(String columnName) {
		this.mappedColumnName = columnName;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Class<?> getPropertyType() {
		return super.getPropertyDescriptor().getPropertyType();
	}
}
