/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;


import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;

/**
 * DTO（Data Transfer Object）に対するO/Rマッピング機能を表すインタフェースです。
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public interface GDTOMapper {

	/**
	 * {@link GORMapper#mapDTOIterate(GRecordSet, GIterationCallBack)}を参照。
	 * 
	 * @param <T> DTOの型
	 * @param recordSet 結果セット
	 * @param callBack コールバック
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> void iterate(GRecordSet recordSet, GIterationCallBack<T> callBack);
	
	/**
	 * {@link GORMapper#mapDTOSingle(Class, GRecord)}を参照。
	 * 
	 * @param clazz DTOの型
	 * @param record レコード
	 * @return DTO
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	Object map(Class<?> clazz, GRecord record);
	
	/**
	 * 指定したドメインモデルの各カラムフィールド（{@link Column}が定義されたフィールド）の値をそれぞれ対応する{@link GRecord}のカラムにマッピングします。
	 * 
	 * @param record レコード
	 * @param model ドメインモデル
	 * @author KCCS K.Fujita
	 * @create 2013/03/26
	 * @since 3.12.0
	 */
	void map(GRecord record, Object model);
}