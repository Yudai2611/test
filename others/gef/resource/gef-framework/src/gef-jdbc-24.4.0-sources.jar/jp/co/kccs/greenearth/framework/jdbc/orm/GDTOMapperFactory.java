/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * {@link GDTOMapper}インスタンスを生成するためのクラスです.<br/>
 *
 * @author KCCS yamashita
 * @create 2012/12/01
 * @since 3.12.0
 */
public class GDTOMapperFactory {

	/** プロパティ名を使用したマッピングの使用可否 */
	private boolean usePropertyNameBind = false;
	/** {@link GDTOMapper}のキャッシュ. */
	private Map<Class<?>, GDTOMapper> dtoMapperPool = new ConcurrentHashMap<Class<?>, GDTOMapper>();

	/**
	 * {@link GDTOMapperFactory}のインスタンスを初期化します.
	 *
	 * @author KCCS K.Fujita
	 * @create 2013/02/15
	 * @since 3.12.0
	 */
	public GDTOMapperFactory() {

	}

	/**
	 * {@link GDTOMapper}を取得します.<br/>
	 *
	 * @param clazz ドメインモデルの型（キャッシュキー）
	 * @return {@link GDTOMapper}インスタンス
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GDTOMapper getMaper(Class<?> clazz) {
		if (!dtoMapperPool.containsKey(clazz)) {
			GDTOMapper mapper = new GDTOMapperImpl(clazz, usePropertyNameBind);
			dtoMapperPool.put(clazz, mapper);
		}
		return dtoMapperPool.get(clazz);
	}

	/**
	 * プロパティ名を使用したマッピングの使用可否を設定します.
	 *
	 * @param usePropertyNameBind プロパティ名を使用したマッピングの使用可否
	 * @author KCCS K.Fujita
	 * @create 2013/02/15
	 * @since 3.12.0
	 */
	public void setUsePropertyNameBind(boolean usePropertyNameBind) {
		this.usePropertyNameBind = usePropertyNameBind;
	}

	/**
	 * プロパティ名を使用したマッピングの使用可否を取得します.
	 *
	 * @return プロパティ名を使用したマッピングの使用可否
	 * @author KCCS K.Fujita
	 * @create 2013/02/15
	 * @since 3.12.0
	 */
	public boolean getUsePropertyNameBind() {
		return this.usePropertyNameBind;
	}
}
