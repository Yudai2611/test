/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.commons.exception.GIllegalAccessRuntimeException;
import jp.co.kccs.greenearth.commons.exception.GSQLRuntimeException;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;

/**
 * {@link GDTOMapper}の実装クラスです.<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public class GDTOMapperImpl implements GDTOMapper {

	/** プロパティ名を使用したマッピングの使用可否 */
	private boolean usePropertynameBind = false;
	/** DTOの型. */
	private Class<?> clazz = null;
	/** {@link GColumnPropertyMapper}のキャッシュ. */
	private List<GColumnPropertyMapper> propertyMappers = new LinkedList<GColumnPropertyMapper>();
	
	/**
	 * {@link GDTOMapperImpl}を生成します.<br/>
	 * 
	 * @param clazz DTOの型
	 * @param usePropertyNameBind プロパティ名を使用したマッピングの使用可否
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GDTOMapperImpl(Class<?> clazz, boolean usePropertyNameBind) {
		this.clazz = clazz;
		this.usePropertynameBind = usePropertyNameBind;
		
		BeanInfo beanInfo = getBeanInfo(clazz);
		for (PropertyDescriptor propertyDescriptor : beanInfo.getPropertyDescriptors()) {
			Method readMethod = propertyDescriptor.getReadMethod();
			if (readMethod == null) {
				continue;
			}
			
			if (readMethod.isAnnotationPresent(Column.class)) {
				String mappedColumnName = readMethod.getAnnotation(Column.class).name();
				propertyMappers.add(createPropertyMapper(clazz, propertyDescriptor, mappedColumnName));
			} else if (this.usePropertynameBind) {
				String mappedColumnName = propertyDescriptor.getName();
				propertyMappers.add(createPropertyMapper(clazz, propertyDescriptor, mappedColumnName));
			}
		}
	}

	/**
	 * DTOの型に対してイントロスペクションを行い、BeanInfoを取得します.
	 * 
	 * @param clazz DTOの型
	 * @return DTOの型の{@link BeanInfo}
	 * @author KCCS K.Fujita
	 * @create 2013/03/19
	 * @since 3.12.0
	 */
	private BeanInfo getBeanInfo(Class<?> clazz) {
		try {
			return Introspector.getBeanInfo(clazz, Object.class);
		} catch (IntrospectionException e) {
			throw new GIntrospectionRuntimeException(e);
		}
	}

	/**
	 * {@link GORMapper#mapDTOIterate(GRecordSet, GIterationCallBack)}を参照.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GDTOMapper#iterate(jp.co.kccs.greenearth.framework.jdbc.GRecordSet, jp.co.kccs.greenearth.framework.jdbc.orm.GIterationCallBack)
	 * @param <T> DTOの型
	 * @param recordSet 結果セット
	 * @param callBack コールバックメソッド
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> void iterate(GRecordSet recordSet, GIterationCallBack<T> callBack) {
		GIterationContext iterationContext = new GIterationContextImpl();
		boolean next = false;
		try {
			while (!iterationContext.isExit()) {
				next = recordSet.next();
				if (!next) {
					break;
				}
				GRecord record = recordSet.getRecord();
				Object model = map(clazz, record);
				callBack.iterate((T) model, iterationContext);
				if (!next) {
					iterationContext.setExit(true);
				}
			}
		} catch (SQLException e) {
			throw new GSQLRuntimeException(e);
		}
	}

	/**
	 * {@link GORMapper#mapDTOSingle(Class, GRecord)}を参照.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GDTOMapper#map(java.lang.Class, jp.co.kccs.greenearth.framework.jdbc.GRecord)
	 * @param clazz DTOの型
	 * @param record レコード
	 * @return DTO
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public Object map(Class<?> clazz, GRecord record) {
		Object model = createInstance(clazz);
		for (GColumnPropertyMapper mapper : propertyMappers) {
			String columnName = mapper.getMappedColumnName();
			if (record.getVariants().keySet().contains(columnName)) {
				mapper.map(model, GValueOfRecordGetterFactory.getInstance().get(mapper.getPropertyType()).get(record, mapper.getMappedColumnName()));
			}
		}
		return model;
	}
	
	/**
	 * 指定したDTOの各カラムフィールド（{@link Column}が定義されたフィールド）の値をそれぞれ対応する{@link GRecord}のカラムにマッピングします.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GDTOMapper#map(jp.co.kccs.greenearth.framework.jdbc.GRecord, java.lang.Object)
	 * @param record レコード
	 * @param model DTO
	 * @author KCCS K.Fujita
	 * @create 2013/03/26
	 * @since 3.12.0
	 */
	@Override
	public void map(GRecord record, Object model) {
		for (GColumnPropertyMapper mapper : propertyMappers) {
			mapper.map(record, model);
		}
	}
	
	/**
	 * {@link GColumnPropertyMapper}を生成します.<br/>
	 * 
	 * @param clazz DTOの型
	 * @param propertyDescriptor プロパティ
	 * @param columnName 項目名
	 * @return {@link GColumnPropertyMapper}インスタンス
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected GColumnPropertyMapper createPropertyMapper(Class<?> clazz, PropertyDescriptor propertyDescriptor, String columnName) {
		return new GColumnPropertyMapperImpl(clazz, propertyDescriptor, columnName);
	}

	/**
	 * 指定したクラス（DTOの型）の新しいインスタンスを生成します.<br/>
	 * 
	 * @param clazz DTOの型
	 * @return 新しいインスタンス
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	private Object createInstance(Class<?> clazz) {
		Object newInstance;
		try {
			newInstance = clazz.newInstance();
		} catch (InstantiationException e) {
			throw new GIllegalAccessRuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new GIllegalAccessRuntimeException(e);
		}
		return newInstance;
	}
}
