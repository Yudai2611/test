/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

/**
 * イントロスペクション中の実行時例外を表します.
 * 
 * @author KCCS yamashita
 * @create 2013/01/29
 * @since 3.12.0
 */
public class GIntrospectionRuntimeException extends RuntimeException {
	
	/** シリアルバージョンID. */
	private static final long serialVersionUID = -4164821644129048490L;

	/**
	 * メッセージを指定して{@link GIntrospectionRuntimeException}を初期化します.
	 * 
	 * @param message メッセージ
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GIntrospectionRuntimeException(String message) {
        super(message);
    }
	
	/**
	 * 原因を指定して{@link GIntrospectionRuntimeException}を初期化します.
	 * 
	 * @param cause 原因
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GIntrospectionRuntimeException(Throwable cause) {
		super(cause);
	}

	/**
	 * メッセージと原因を指定して{@link GIntrospectionRuntimeException}を初期化します.
	 * 
	 * @param message メッセージ
	 * @param cause 原因
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GIntrospectionRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

}
