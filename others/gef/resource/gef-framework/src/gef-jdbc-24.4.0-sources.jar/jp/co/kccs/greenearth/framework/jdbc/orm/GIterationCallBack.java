/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;


/**
 * 反復型のO/Rマッピング機能※において、ドメインモデル生成時にコールバックされるインタフェースです。
 * <p>
 * ※<br>
 * ・{@link GORMapper#mapIterate(jp.co.kccs.greenearth.framework.jdbc.repository.GEntity, jp.co.kccs.greenearth.framework.jdbc.GRecordSet, GIterationCallBack)}<br>
 * ・{@link GORMapper#mapDTOIterate(jp.co.kccs.greenearth.framework.jdbc.GRecordSet, GIterationCallBack)}
 * 
 * @param <T> ドメインモデルの型
 * @author KCCS yamashita
 * @create 2012/12/03
 * @since 3.12.0
 */
public interface GIterationCallBack<T> {

	/**
	 * O/Rマッピング機能において、ドメインモデル（1件）が生成される度に通知されるコールバックメソッドです。
	 * <p>
	 * {@link GIterationContext#isExit()}を{@code true}にすることで、後続のO/Rマッピング処理は終了します。
	 * 
	 * @param model ドメインモデル
	 * @param context コンテキスト
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void iterate(T model, GIterationContext context);
}
