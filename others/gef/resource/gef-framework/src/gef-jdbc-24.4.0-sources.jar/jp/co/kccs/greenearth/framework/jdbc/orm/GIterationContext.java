/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

/**
 * 問い合わせ結果への処理を終了するかどうかを表すインタフェースです。
 * 
 * @author KCCS yamashita
 * @create 2012/12/05
 * @since 3.12.0
 */
public interface GIterationContext {

	/**
	 * 処理を終了するかどうかを判定します。
	 * 
	 * @return 処理を終了する場合は{@code true}。 そうでない場合は{@code false}。
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	boolean isExit();

	/**
	 * 処理終了フラグを設定します。
	 * <p>
	 * {@link GIterationCallBack#iterate(Object, GIterationContext)}メソッド内で本メソッドで{@code true}に設定すると後続の処理は終了されます。
	 * 
	 * @param exit 処理を終了する場合は{@code true}。 そうでない場合は{@code false}。
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void setExit(boolean exit);
}
