/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;


/**
 * {@link GIterationContext}の実装クラスです.<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/12/03
 * @since 3.12.0
 */
public class GIterationContextImpl implements GIterationContext {

	/** 処理継続フラグ. */
	protected boolean exit;

	/**
	 * 処理を継続するかどうかを判定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GIterationContext#isExit()
	 * @return 処理を終了する場合は{@literal true} / 処理を終了しない場合は{@literal false}
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public boolean isExit() {
		return exit;
	}

	/**
	 * 処理継続フラグを設定します.<br/>
	 * {@link GIterationCallBack#iterate(Object, GIterationContext)}の処理中に本プロパティを{@literal true}に設定した場合、後続の処理は終了します。<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GIterationContext#setExit(boolean)
	 * @param exit 処理継続フラグ
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public void setExit(boolean exit) {
		this.exit = exit;
	}
}
