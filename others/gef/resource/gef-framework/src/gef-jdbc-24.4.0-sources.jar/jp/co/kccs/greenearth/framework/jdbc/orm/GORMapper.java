/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;

/**
 * O/Rマッピング機能を提供するインタフェースです。
 * <p>
 * O/Rマッピングを実現するためのメソッドを提供します。
 * このインタフェースを通して、O/Rマッピング機能を使用することができます。<br>
 * <p>
 * マッピング方式として、エンティティー定義を必要とするエンティティーマッピング方式と<br>
 * エンティティー定義を必要としないDTOマッピング方式を提供します。<br>
 * また、マッピング方法として、Single、Multiple、Iterate の3方法を提供します。<br>
 * マッピング方式とマッピング方法を組み合わせることで、様々なO/Rマッピングを実現できます。<br>
 * <ul></ul>
 * <b>【マッピング方式】</b>
 * <ul>
 * <li><b>エンティティーマッピング</b><br>
 * エンティティーマッピングとは、エンティティー定義を使用して検索結果（レコード）からJavaオブジェクト（ドメインモデル）へ値を移送する方式です。<br>
 * 更新処理用にドメインモデルからレコードへの値の移送も可能です。<br>
 * 複数エンティティーを結合させたドメインモデルとマッピングすることすることもできます。<br>
 * エンティティーの結合行が一対一、一対多、多対一の関連に対応しています。<br>
 * <li><b>DTOマッピング</b><br>
 * DTOマッピングとは、エンティティー定義を使用せずに検索結果（レコード）からJavaオブジェクト（DTO）へ直接値を移送する方式です。<br>
 * 更新処理用にDTOからレコードへの値の移送も可能です。<br>
 * DTOは必ず1テーブルを表します。テーブルの結合はできません。<br>
 * </ul>
 * 
 * <b>【マッピング方法】</b><br>
 * <ul>
 * <li><b>Single</b><br>
 * 1件のJavaオブジェクトに対して1行のレコードをマッピングします。<br>
 * <li><b>Multiple</b><br>
 * 複数件のJavaオブジェクトに対して複数行のレコードをマッピングします。<br>
 * <li><b>Iterate</b><br>
 * 複数件のJavaオブジェクトに対して複数行のレコードをマッピングします。<br>
 * マッピング対象を1レコードずつメモリに読み込むことができるため、大量件数を処理することができます。<br>
 * </ul>
 * <p>
 * O/Rマッピングをするためには、エンティティーマッピングの場合はドメインモデルクラス、DTOマッピングの場合はDTOクラスが必要です。<br>
 * 以下にその作成方法を示します。
 * <p>
 * <b>【エンティティーマッピングの場合のドメインモデルクラス作成方法】</b>
 * <br>
 * <ol>
 * <li>ドメインモデルのクラスを宣言します。<br>
 * クラス宣言に{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity}アノテーションを付与します。<br>
 * 必要であればkeyType属性にキータイプを指定します。<br>
 * キータイプは列挙型{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity.KeyType}から選択してください。<br>
 * キータイプを指定することで一意となるカラムを指定することができます。<br>
 * {@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity.KeyType#UNIQUE}を指定した場合は、keyName属性にユニークキー名も指定します。<br>
 * キータイプが{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity.KeyType#PRIMARY}の場合はエンティティー定義に主キーが、{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity.KeyType#UNIQUE}の場合はエンティティー定義にユニークキーが定義されている必要があります。<br>
 * <table border="1">
 * <td>
 * <pre> {@literal @Entity}(keyType=KeyType.UNIQUE, keyName="UniqueItem")
 * public class ItemMaster {
 * ...</pre>
 * </td>
 * </table>
 * <br>
 * <li>マッピングする値を保持するフィールドを宣言し、フィールドに対するgetterを宣言します。<br>
 * このgetterに{@link Column}アノテーションを付与し、name属性にエンティティーのカラム名を指定します。<br>
 * setterは定義されている必要がありますが、アノテーションは必要ありません。<br>
 * <br>
 * <table border="1">
 * <td>
 * <pre> private String code;
 * ...
 * {@literal @Column}(name = "code")
 * public String getCode() {           
 * ...</pre>
 * </td>
 * </table>
 * <br>
 * <li>他のエンティティーを関連づけたい場合に、他のエンティティーに関連づけるフィールドには関連を表すアノテーションを付与します。<br>
 * フィールドの関連を表すアノテーションは（{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.OneToOne}、{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.OneToMany}、{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.ManyToOne}）のいずれかです。<br>
 * アノテーションの属性で結合方法を指定します。<br>
 * foreignKey属性は結合する外部キー名を指定します。外部キー名はエンティティー定義で定義しておく必要があります。<br>
 * joinType属性は結合方法（内部結合、左外部結合など）を指定します。結合方法は列挙型{@link jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType}から選択してください。<br>
 * mappedAlias属性は結合先エンティティーの別名を指定します。<br>
 * <br>
 * <table border="1">
 * <td>
 * <pre> private UnitMaster unitMaster;
 * ...
 * {@literal @ManyToOne}(foreignKey="ItemFK", joinType=JoinType.INNER_JOIN, mappedAlias="item")
 * public UnitMaster getUnitMaster() {
 * ...</pre>
 * </td>
 * </table>
 * </ol>
 * <br>
 * <ul>
 * <li>多対多で結合されたエンティティーに対するO/Rマッピングはサポートしていません。<br>
 * <li>{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity}や{@link Column}が指定されていないドメインモデルおよびフィールドは、O/Rマッピング機能の対象外となります。<br>
 * <li>キータイプが{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity.KeyType#PRIMARY}の場合には主キー項目、キータイプが{@link jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity.KeyType#UNIQUE}の場合にはユニークキー項目が、クエリのSELECT節に含まれている必要があります。<br>
 *     また、結合されたエンティティの値をドメインモデルに移送する場合、結合されたエンティティの項目も、クエリのSELECT節に含まれている必要があります。
 * <li>{@link GEntityMapperFactory}のプロパティ"usePropertyNameBind"を{@code true}に設定すると、
 * {@link Column}アノテーションを省略することができます。<br>
 * ただしフィールド名とエンティティーのカラム名が同じである必要があります。<br>
 * また、アクセサメソッド（getterやsetter）そのものを省略することはできません。</li>
 * </ul>
 * <b>【DTOマッピングの場合のDTOクラス作成方法】</b>
 * <p>
 * <ol>
 * <li>DTOのクラスを宣言宣言します。</li>
 * <li>マッピングする値を保持するフィールドを宣言し、フィールドに対するgetterを宣言します。<br>
 * このgetterに{@link Column}アノテーションを付与し、name属性にエンティティーのカラム名を指定します。<br>
 * setterは定義されている必要がありますが、アノテーションは必要ありません。<br>
 * <br>
 * <table border="1">
 * <td>
 * <pre> private String code;
 * ...
 * {@literal @Column}(name = "code")
 * public String getCode() {           
 * ...</pre>
 * </td>
 * </table>
 * <br>
 * </ol>
 * <br>
 * <ul>
 * <li>{@link Column}が指定されていないフィールドは、O/Rマッピング機能の対象外となります。<br></li>
 * <li>{@link GDTOMapperFactory}のプロパティ"usePropertyNameBind"を{@code true}に設定すると、
 * {@link Column}アノテーションを省略することができます。<br>
 * ただしフィールド名とテーブルカラム名が同じである必要があります。<br>
 * また、アクセサメソッド（getterやsetter）そのものを省略することはできません。</li>
 * </ul>
 * <br>
 * <p>
 * 代表的な使用方法を下記に示します。<br>
 * {@link GORMapper}を利用して、検索で得たレコードの値をJavaオブジェクトに移送する例です。<br>
 * <br>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">「マッピング方式：エンティティーマッピング、マッピング方法：Multiple」</td></tr>
 * <tr>
 * <td>
 * <pre> List{@literal <GRecord>} input = 
 *	mapper.buildQuery(select("ItemMaster"), ItemMaster.class)
 *		.orderBy(asc("ItemCD"))
 *		.findlist();
 *
 * List{@literal <ItemMaster>} result = 
 * 	mapper.mapMultiple(select, ItemMaster.class, input);</pre>
 * </td>
 * </tr>
 * </table>
 * <br>
 * <table border="1">
 * <tr bgcolor="#cccccc"><td colspan="2">「マッピング方式：DTOマッピング、マッピング方法：Single」</td></tr>
 * <tr>
 * <td>
 * <pre> GRecord input = 
 *	mapper.buildQuery(select("ItemMaster"), ItemMaster.class)
 *		.findRecord();
 *
 * ItemMaster result = 
 *	mapper.mapDTOSingle(ItemMaster.class, input);</pre>
 * </td>
 * </tr>
 * </table>
 * 
 * @author KCCS yamashita
 * @create 2012/11/20
 * @since 3.12.0
 */
public interface GORMapper {

	/**
	 * {@link GORMapper}インスタンスを生成するためのクラスです。<br>
	 * 
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	static class Factory {
		/**
		 * {@link GORMapper}インスタンスを取得します。<br>
		 * 
		 * @return {@link GORMapper}インスタンス
		 * @author KCCS yamashita
		 * @create 2013/01/30
		 * @since 3.12.0
		 */
		public static GORMapper getInstance() {
			return GFrameworkUtils.getComponent(GORMapper.class.getName());
		}
	}

	/**
	 * 検索結果として取得した1行を表す{@link GRecord}を、1件のドメインモデルに変換することができます。
	 * 
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}
	 * <p>
	 * {@link #buildQuery(GEntitySelect, Class)}や{@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#select(String)}などで生成します。
	 * @param clazz ドメインモデルのClassオブジェクト
	 * <p>
	 * ItemMaster.class の形式で渡します
	 * @param record 1行レコード
	 * @return ドメインモデル
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> T mapSingle(GEntitySelect select, Class<T> clazz, GRecord record);

	/**
	 * 複数行の検索結果を1件のドメインモデルに変換します。
	 * <p>
	 * 検索結果として取得した複数行を表す{@link GRecord}を、1件のドメインモデルに変換することができます。
	 * ドメインモデルが複数作成される場合、先頭要素の1件を返却します。<br>
	 * 抽出順はDBに依存しますので、必要であればORDER BYを使って検索結果を取得してください。
	 * 
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}
	 * <p>
	 * {@link #buildQuery(GEntitySelect, Class)}や{@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#select(String)}などで生成します。
	 * @param clazz ドメインモデルのClassオブジェクト
	 * <p>
	 * ItemMaster.class の形式で渡します
	 * @param recordList {@link GRecord}のリスト
	 * @return ドメインモデル
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> T mapSingle(GEntitySelect select, Class<T> clazz, List<GRecord> recordList);

	/**
	 * 1件のドメインモデルを、1行を表す{@link GRecord}に変換することができます。
	 * <p>
	 * {@link GRecord}に変換する際、エンティティーの結合は解決しません。<br>
	 * ドメインモデルの{@link Column}が定義されたフィールドの値を対応する{@link GRecord}のカラムにマッピングします。
	 * 
	 * @param <T> ドメインモデルの型
	 * @param entity エンティティ
	 * <p>
	 * {@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#entity(String)}を生成します。
	 * @param model ドメインモデル
	 * @return {@link GRecord}
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> GRecord mapSingle(GEntity entity, T model);

	/**
	 * 検索結果として取得した複数行を表す{@link GRecord}を、複数件のドメインモデルに変換することができます。
	 * 
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}
	 * <p>
	 * {@link #buildQuery(GEntitySelect, Class)}や{@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#select(String)}などで生成します。
	 * @param clazz ドメインモデルの型
	 * <p>
	 * ItemMaster.class の形式で渡します
	 * @param recordList {@link GRecord}のリスト
	 * @return ドメインモデルのリスト
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> List<T> mapMultiple(GEntitySelect select, Class<T> clazz, List<GRecord> recordList);

	/**
	 * 複数件のドメインモデルを、複数行を表す{@link GRecord}に変換することができます。
	 * <p>
	 * {@link GRecord}に変換する際、エンティティーの結合は解決しません。<br>
	 * ドメインモデルの{@link Column}が定義されたフィールドの値を対応する{@link GRecord}のカラムにマッピングします。<br>
	 * <pre>
	 * Example :<br>
	 *	List{@literal <ItemMaster>} input = ...
	 *	List{@literal <GRecord>} result = mapper.mapMultiple(entity("ItemMaster"), input);
	 * </pre>
	 * 
	 * @param <T> ドメインモデルの型
	 * @param entity エンティティー
	 * <p>
	 * {@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#entity(String)}を生成します。
	 * @param modelList ドメインモデルのリスト
	 * @return {@link GRecord}のリスト
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> List<GRecord> mapMultiple(GEntity entity, List<T> modelList);

	/**
	 * 検索結果である{@link GRecordSet}から1行づつ取り出し、ドメインモデルに変換し取得します。
	 * <p>
	 * 複数行のレコードから複数件のJavaオブジェクトに変換します。<br>
	 * このメソッドでは1行ずつメモリに読み込むため、大量件数をメモリへの負荷なく処理することができます。<br>
	 * {@link GRecordSet}の件数が多く、{@link java.util.List}への復元が（メモリ使用量やパフォーマンス上の観点などで）困難な場合に使用します。<br>
	 * <p>
	 * このメソッドを呼ぶことで{@link GRecordSet}の取得行分ループします。<br>
	 * ループする度にコールバックメソッド（{@link GIterationCallBack#iterate(Object, GIterationContext)}）を呼び出します。<br>
	 * このコールバックメソッド内でドメインモデルを扱うことができますので、必要なビジネスロジックを記述してください。<br>
	 * なお、コールバックメソッド内で{@link GIterationContext#isExit()}を明示的に{@literal true}にすることで、ループを終了させることができます。<br>
	 * <p>
	 * {@link GRecordSet}のカーソル解放などの後処理は、呼び出し元で明示的に行う必要がありますのでご注意下さい。<br>
	 * 以下に使用例を示します。
	 * <p>
	 * <pre>
	 * GEntitySelect select = select("ItemMaster");
	 * GRecordSet result = select.findRecordSet();
	 * String name = null;
	 * try {
	 * 	mapper.mapIterate(select, result, new GIterationCallBack{@literal <ItemMaster>}() {
	 * 		{@literal @Override}
	 * 		public void iterate(ItemMaster itemMaster, GIterationContext context) {
	 * 			// ここからは独自ロジックを記述してください
	 * 			if (itemMaster.getItem().equals("A")) {
	 * 				code = itemMaster.getName();
	 * 				context.setExit(true);    // ループを終了させます
	 * 				return;
	 * 			}
	 * 		}
	 * 	});
	 * } finally {
	 *     if (result != null) {
	 *         result.close();
	 *     }
	 * }</pre>
	 * 
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}
	 * @param recordSet {@link GRecordSet}
	 * @param callBack コールバックメソッド
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> void mapIterate(GEntitySelect select, GRecordSet recordSet, GIterationCallBack<T> callBack);

// TODO: [2013/01/29][yamashita] 将来採用する可能性があるため一旦、コメントにしておく
//	<T> void mapAutoCloseIterate(GVirtualEntity ve, GRecordSet recordSet, GIterationCallBack<T> callBack);	
// TODO: [2013/01/29][yamashita] 将来採用する可能性があるため一旦、コメントにしておく
//	<T> void mapDTOAutoCloseIterate(GRecordSet recordSet, GIterationCallBack<T> callBack);

	/**
	 * 検索結果として取得した1行を表す{@link GRecord}を、1件のDTOに変換することができます。
	 * 
	 * @param <T> DTOの型
	 * @param clazz  DTOのClassオブジェクト
	 * <p>
	 * ItemMaster.class の形式で渡します
	 * @param record {@link GRecord}
	 * @return DTO
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> T mapDTOSingle(Class<T> clazz, GRecord record);

	/**
	 * 1件のDTOを、1行を表す{@link GRecord}に変換することができます。
	 * 
	 * @param <T> DTOの型
	 * @param model DTO
	 * @return {@link GRecord}
	 * @author KCCS K.Fujita
	 * @create 2013/03/26
	 * @since 3.12.0
	 */
	<T> GRecord mapDTOSingle(T model);

	/**
	 * 検索結果として取得した複数行を表す{@link GRecord}を、複数件のDTOに変換することができます。<br>
	 * {@link GRecord}1件に対しDTOは1件作成されます。
	 * 
	 * @param <T> DTO
	 * @param clazz DTOのClassオブジェクト
	 * <p>
	 * ItemMaster.class の形式で渡します
	 * @param recordList {@link GRecord}のリスト
	 * @return DTOのリスト
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> List<T> mapDTOMultiple(Class<T> clazz, List<GRecord> recordList);

	/**
	 * 複数件のDTOを、複数行を表す{@link GRecord}に変換することができます。
	 * 
	 * @param <T> DTOの型
	 * @param modelList DTOのリスト
	 * @return {@link GRecord}のリスト
	 * @author KCCS K.Fujita
	 * @create 2013/03/26
	 * @since 3.12.0
	 */
	<T> List<GRecord> mapDTOMultiple(List<T> modelList);

	/**
	 * 検索結果である{@link GRecordSet}から1行づつ取り出し、DTOに変換し取得します。
	 * <p>
	 * 複数行のレコードから複数件のJavaオブジェクトに変換します。<br>
	 * このメソッドでは1行ずつメモリに読み込むため、大量件数をメモリへの負荷なく処理することができます。<br>
	 * {@link GRecordSet}の件数が多く、{@link java.util.List}への復元が（メモリ使用量やパフォーマンス上の観点などで）困難な場合に使用します。<br>
	 * <p>
	 * このメソッドを呼ぶことで{@link GRecordSet}の取得行分ループします。<br>
	 * ループする度にコールバックメソッド（{@link GIterationCallBack#iterate(Object, GIterationContext)}）を呼び出します。<br>
	 * このコールバックメソッド内でDTOを扱うことができますので、必要なビジネスロジックを記述してください。<br>
	 * なお、コールバックメソッド内で{@link GIterationContext#isExit()}を明示的に{@literal true}にすることで、ループを終了させることができます。<br>
	 * <p>
	 * {@link GRecordSet}のカーソル解放などの後処理は、呼び出し元で明示的に行う必要がありますのでご注意下さい。<br>
	 * 以下に使用例を示します。
	 * <pre>
	 * GEntitySelect select = select("ItemMaster");
	 * GRecordSet result = select.findRecordSet();
	 * String name = null;
	 * try {
	 * 	mapper.mapIterate(select, result, new GIterationCallBack{@literal <ItemMaster>}() {
	 * 		{@literal @Override}
	 * 		public void iterate(ItemMaster itemMaster, GIterationContext context) {
	 * 			// ここからは独自ロジックを記述してください
	 * 			if (itemMaster.getItem().equals("A")) {
	 * 				code = itemMaster.getName();
	 * 				context.setExit(true);    // ループを終了させます
	 * 				return;
	 * 			}
	 * 		}
	 * 	});
	 * } finally {
	 *     if (result != null) {
	 *         result.close();
	 *     }
	 * }</pre>
	 * @param <T> DTOの型
	 * @param recordSet {@link GRecordSet}
	 * @param callBack コールバックメソッド
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> void mapDTOIterate(GRecordSet recordSet, GIterationCallBack<T> callBack);

	/**
	 * ドメインモデルからSELECT節とJOIN節を構築します。
	 * <p>
	 * ドメインモデルで定義されたフィールドと結合条件から、SELECT文のSELECT節とJOIN節を構築することができます。<br>
	 * そのため、SELECT節やJOIN節の指定を省略することができます。<br>
	 * またWHERE節は構築しないため、独自に構築することができます。
	 * <p>
	 * {@link jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType#RIGHT_OUTER_JOIN}はサポートしません。<br>
	 * このメソッドで構築されたSELECT文にソート条件等を付与する場合、カラム別名が使用できないため、 "テーブル名（テーブル別名）．カラム名" の形式で完全修飾名を指定するようにして下さい。
	 * 
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}
	 * <p>
	 * {@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#select(String)}で生成します。
	 * @param clazz ドメインモデルの型
	 * <p>
	 * ItemMaster.class の形式で渡します
	 * @return {@link GEntitySelect}
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> GEntitySelect buildQuery(GEntitySelect select, Class<T> clazz);
	
	/**
	 * 
	 * ドメインモデルからSELECT節を構築します。
	 * <p>
	 * ドメインモデルで定義されたフィールドから、SELECT文のSELECT節を構築することができます。<br>
	 * そのため、SELECT節の指定を省略することができます。<br>
	 * またJOIN節やWHERE節は構築しないため、独自に構築することができます。
	 * 
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}
	 * <p>
	 * {@link jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants#select(String)}で生成します。
	 * @param clazz ドメインモデルのClassオブジェクト
	 * <p>
	 * ItemMaster.class の形式で渡します
	 * @return {@link GEntitySelect}
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> GEntitySelect buildFields(GEntitySelect select, Class<T> clazz);
}
