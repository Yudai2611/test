/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GCollectionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordImpl;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.GEntityMapper;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.GEntityMapperFactory;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.GMappingContext;

/**
 * {@link GORMapper}の実装クラスです.<br/>
 * 
 * @author KCCS R.Yamashita
 * @create 2012/11/07
 * @since 3.12.0
 */
public class GORMapperImpl implements GORMapper {

	/** {@link GEntityMapperFactory}のインスタンス */
	GEntityMapperFactory entityMapperFactory;
	/** {@link GDTOMapperFactory}のインスタンス */
	GDTOMapperFactory dtoMapperFactory;
	
	/**
	 * {@link GORMapperImpl}のインスタンスを生成します.<br/>
	 * 
	 * @param entityMapperFactory {@link GEntityMapperFactory}のインスタンス
	 * @param dtoMapperFactory {@link GDTOMapperFactory}のインスタンス
	 * @author KCCS R.Yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GORMapperImpl(GEntityMapperFactory entityMapperFactory, GDTOMapperFactory dtoMapperFactory) {
		this.entityMapperFactory = entityMapperFactory;
		this.dtoMapperFactory = dtoMapperFactory;
	}

	/**
	 * 指定したドメインモデルを解析し、クエリ（{@link GEntitySelect}）の抽出項目（{@link GEntitySelect#getSelectColumns()}）および条件項目（{@link GEntitySelect#getJoinList()}）を自動構築します.<br/>
	 * ※{@link jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType#RIGHT_OUTER_JOIN}はサポートしません。<br/>
	 * ※このメソッドで自動構築されたクエリに対してソート条件を設定する場合、カラム別名を使用することが難しいため、 "テーブル名（テーブル別名）．項目名" の形式の完全修飾名を指定するようにして下さい。<br>
	 * <br/>
	 * <pre>
	 * Example :<br/>
	 *	GORMapper mapper = GORMapper.Factory.getInstance();
	 *	List{@literal <GRecord>} result = mapper.buildQuery(select("ItemMaster"), ItemMaster.class)
	 *				.orderBy(
	 *					asc("ItemMaster.ItemCD")
	 *				)
	 *				.findlist();
	 * </pre>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GORMapper#buildQuery(jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect, java.lang.Class)
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}インスタンス
	 * @param clazz ドメインモデルの型
	 * @return {@link GEntitySelect}インスタンス
	 * @author KCCS R.Yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public <T> GEntitySelect buildQuery(GEntitySelect select, Class<T> clazz) {
		GEntity entity = select.getEntity();
		GEntityMapper mapper = entityMapperFactory.getMapper(clazz, entity);
		return mapper.buildSelect(select);
	}

	/**
	 * 指定したドメインモデルを解析し、クエリ（{@link GEntitySelect}）の抽出項目（{@link GEntitySelect#getSelectColumns()}）を自動構築します.<br/>
	 * <pre>
	 * Example :<br/>
	 *	GEntitySelect select = select("ItemMaster").innerJoinFK("UNITMASTER_FK", "unit");
	 *	List{@literal <GRecord>} result = mapper.buildFields(select, ItemMaster.class)
	 *				.findList();
	 * </pre>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.GORMapper#buildFields(jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect, java.lang.Class)
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}インスタンス
	 * @param clazz ドメインモデルの型
	 * @return ドメインモデル
	 * @author KCCS R.Yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public <T> GEntitySelect buildFields(GEntitySelect select, Class<T> clazz) {
		GEntity entity = select.getEntity();
		GEntityMapper mapper = entityMapperFactory.getMapper(clazz, entity);
		return mapper.buildSelectFields(select);
	}

	@Override
	public <T> void mapIterate(GEntitySelect select, GRecordSet recordSet, GIterationCallBack<T> callBack) {
		if (recordSet == null || callBack == null) {
			return;
		}
		GMappingContext context = new GMappingContext();
		GEntityMapper mapper = entityMapperFactory.getMapper(getGenericType(callBack.getClass()), select.getEntity());
	 	mapper.iterate(select, recordSet, context, callBack);
	}

	@Override
	public <T> List<T> mapMultiple(GEntitySelect select, Class<T> clazz, List<GRecord> recordList) {
		if (recordList == null || recordList.isEmpty()) {
			return new ArrayList<T>();
		}
		GRecord metaR = recordList.get(0);
		if (metaR == null) {
			return new ArrayList<T>();
		}
	 	GMappingContext context = new GMappingContext();
	 	GEntityMapper mapper = entityMapperFactory.getMapper(clazz, select.getEntity());
	 	@SuppressWarnings("unchecked")
		List<T> result = (List<T>) mapper.map(select, recordList, null, context);
		return result;
	}

	@Override
	public <T> List<GRecord> mapMultiple(GEntity entity, List<T> modelList) {
		List<GRecord> result = new ArrayList<GRecord>();
		if (GCollectionUtils.isEmpty(modelList)) {
			return result;
		}
		for (T model : modelList) {
			GRecord record = mapSingle(entity, model);
			result.add(record);
		}
		return result;
	}

	@Override
	public <T> T mapSingle(GEntitySelect select, Class<T> clazz, GRecord record) {
		if (record == null) {
			return null;
		}
		List<GRecord> recordList = new ArrayList<GRecord>();
		recordList.add(record);
		List<T> tList = mapMultiple(select, clazz, recordList);
		if (tList.isEmpty()) {
			return null;
		}
		return tList.get(0);
	}

	@Override
	public <T> T mapSingle(GEntitySelect select, Class<T> clazz, List<GRecord> recordList) {
		List<T> result = mapMultiple(select, clazz, recordList);
		return result.isEmpty() ? null : result.get(0);
	}

	@Override
	public <T> GRecord mapSingle(GEntity entity, T model) {
		if (model == null) {
			return null;
		}
		GEntityMapper mapper = entityMapperFactory.getMapper(model.getClass(), entity);
		GRecord record = createRecord();;
		mapper.map(record, model);
		return record;
	}

	@Override
	public <T> void mapDTOIterate(GRecordSet recordSet, GIterationCallBack<T> callBack) {
		if (recordSet == null || callBack == null) {
			return;
		}
		GDTOMapper mapper = dtoMapperFactory.getMaper(getGenericType(callBack.getClass()));
	 	mapper.iterate(recordSet, callBack);
	}

	@Override
	public <T> List<T> mapDTOMultiple(Class<T> clazz, List<GRecord> recordList) {
		List<T> result = new ArrayList<T>();
		if (recordList == null || recordList.isEmpty()) {
			return result;
		}
		GRecord metaR = recordList.get(0);
		if (metaR == null) {
			return result;
		}
		for (GRecord record : recordList) {
			T t = mapDTOSingle(clazz, record);
			if (t != null) {
				result.add(t);
			}
		}
		return result;
	}

	@Override
	public <T> List<GRecord> mapDTOMultiple(List<T> modelList) {
		List<GRecord> result = new ArrayList<GRecord>();
		if (GCollectionUtils.isEmpty(modelList)) {
			return result;
		}
		for (T model : modelList) {
			GRecord record = mapDTOSingle(model);
			result.add(record);
		}
		return result;
	}

	@Override
	public <T> T mapDTOSingle(Class<T> clazz, GRecord record) {
		if (record == null) {
			return null;
		}
		GDTOMapper mapper = dtoMapperFactory.getMaper(clazz);
	 	@SuppressWarnings("unchecked")
		T t = (T) mapper.map(clazz, record);
	 	return t;
	}

	@Override
	public <T> GRecord mapDTOSingle(T model) {
		if (model == null) {
			return null;
		}
//		GDTOMapper mapper = GDTOMapperFactory.getMapper(model.getClass());
		GDTOMapper mapper = dtoMapperFactory.getMaper(model.getClass());
		GRecord record = createRecord();
		mapper.map(record, model);
		return record;
	}

	// TODO: [2013/01/29][yamashita] 将来採用する可能性があるため一旦、コメントにしておく
//	@Override
//	public <T> void mapAutoCloseIterate(GVirtualEntity virtualEntity, GRecordSet recordSet, GIterationCallBack<T> callBack) {
//		try {
//			mapIterate(virtualEntity, recordSet, callBack);
//		} finally {
//			if (recordSet != null) {
//				try {
//					recordSet.close();
//				} catch (SQLException e) {
//					throw new GORMappingRuntimeException();
//				}
//			}
//		}
//	}
	
	// TODO: [2013/01/29][yamashita] 将来採用する可能性があるため一旦、コメントにしておく
//	@Override
//	public <T> void mapDTOAutoCloseIterate(GRecordSet recordSet, GIterationCallBack<T> callBack) {
//		try {
//			mapDTOIterate(recordSet, callBack);
//		} finally {
//			if (recordSet != null) {
//				try {
//					recordSet.close();
//				} catch (SQLException e) {
//					throw new GORMappingRuntimeException(e);
//				}
//			}
//		}
//	}

//	/**
//	 * エンティティ（{@link GEntity}）に定義された結合先エンティティの関連に基づいて、{@link GEntitySelect}の結合条件を構築します.<br/>
//	 * ※{@link JoinType#RIGHT_OUTER_JOIN}はサポートしません。<br/>
//	 * 
//	 * @param select {@link GEntitySelect}インスタンス
//	 * @param mapper {@link GEntityMapper}インスタンス
//	 * @param context マッピングコンテキスト
//	 * @author KCCS R.Yamashita
//	 * @create 2013/01/29
//	 * @since 3.12.0
//	 */
//	protected void buildJoinClause(GEntitySelect select, GEntityMapper mapper, GEntityMappingContext context) {
//		for (GRelationPropertyMapper relationMapper : mapper.getRelationPropertyMappers()) {
//			validateJoinType(relationMapper.getJoinType());
//			if (JoinType.INNER_JOIN.equals(relationMapper.getJoinType())) {
//				select.innerJoinFK(createForeignKeyName(relationMapper, context), createEntityAlias(relationMapper, context));
//			} else if (JoinType.LEFT_OUTER_JOIN.equals(relationMapper.getJoinType())) {
//				select.leftOuterJoinFK(createForeignKeyName(relationMapper, context), createEntityAlias(relationMapper, context));
//			} else {
//				continue;
//			}
//			context.pushTargetRelationMapper(relationMapper);
//			GEntityMapper refEntityMapper = GEntityMapperFactory.getMapper(relationMapper.getMappedType(), relationMapper.getForeignKey().getReferenceEntity());
//			buildJoinClause(select, refEntityMapper, context);
//			context.popTargetRelationMapper();
//		}
//	}

//	/**
//	 * 結合先エンティティ名を生成します.<br/>
//	 * 
//	 * @param mapper {@link GRelationPropertyMapper}インスタンス
//	 * @param context マッピングコンテキスト
//	 * @return 結合先エンティティ名
//	 * @author KCCS R.Yamashita
//	 * @create 2013/01/28
//	 * @since 3.12.0
//	 */
//	protected String createForeignKeyName(GRelationPropertyMapper mapper, GEntityMappingContext context) {
//		StringBuilder foreignKeyNameBuilder = new StringBuilder();
//		GRelationPropertyMapper parentMapper = context.peekTargetRelationMapper();
//		if (parentMapper != null) {
//			foreignKeyNameBuilder.append(parentMapper.getMappedAlias()).append(".");
//		}
//		return foreignKeyNameBuilder.append(mapper.getForeignKey().getName()).toString();
//	}

	/**
	 * 指定したドメインモデルの型より、定義されている総称型を取得します.<br/>
	 * 
	 * @param <T> ドメインモデルの型
	 * @param clazz ドメインモデルの型
	 * @return 定義された総称型
	 * @author KCCS R.Yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	@SuppressWarnings("unchecked")
	protected <T> Class<T> getGenericType(Class<?> clazz) {
		Type type = clazz.getGenericInterfaces()[0];
		if (!(type instanceof ParameterizedType)) {
			throw new IllegalArgumentException("The model type is not specified.");
		}
		return (Class<T>) ((ParameterizedType) type).getActualTypeArguments()[0];
	}

//	/**
//	 * 結合タイプを検証します.<br/>
//	 * 結合タイプが{@link JoinType#RIGHT_OUTER_JOIN}の場合、例外をスローします.<br/>
//	 * 
//	 * @param joinType 結合タイプ
//	 * @author KCCS R.Yamashita
//	 * @create 2013/01/28
//	 * @since 3.12.0
//	 */
//	protected void validateJoinType(JoinType joinType) {
//		if (JoinType.RIGHT_OUTER_JOIN.equals(joinType)) {
//			throw new UnsupportedOperationException("right outer join is not supported.");
//		}
//	}
	
	/**
	 * {@link GRecord}のインスタンスを生成します.
	 * 
	 * @return {@link GRecord}のインスタンス
	 * @author KCCS R.Yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	protected GRecord createRecord() {
		return new GRecordImpl();
	}
}
