/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

/**
 * Javaオブジェクトの{@link Object}型の値と、{@link GRecord}のObject型の値とを変換する機能を提供します.
 * 
 * フレームワークがデフォルトで使用するマッパーです。
 *
 * @author hashimoto
 * @since 3.17.0
 */
public class GObjectTypeMapper implements GTypeMapper<Object, Object> {

	@Override
	public Object read(Object result) {
		return result;
	}

	@Override
	public Object write(Object value) {
		return value;
	}
}
