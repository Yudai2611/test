/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.exception.GIllegalAccessRuntimeException;

/**
 * O/Rマッピングに必要な共通機能を提供する基底クラスです.<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public abstract class GPropertyMapperBase {

	/** の更新可能な値の型を表す. */
	private static final List<Class<?>> CANNOT_WRITE_FIELD_TYPES = new ArrayList<Class<?>>();
	static {
		CANNOT_WRITE_FIELD_TYPES.add(byte.class);
		CANNOT_WRITE_FIELD_TYPES.add(short.class);
		CANNOT_WRITE_FIELD_TYPES.add(int.class);
		CANNOT_WRITE_FIELD_TYPES.add(long.class);
		CANNOT_WRITE_FIELD_TYPES.add(float.class);
		CANNOT_WRITE_FIELD_TYPES.add(double.class);
		CANNOT_WRITE_FIELD_TYPES.add(char.class);
		CANNOT_WRITE_FIELD_TYPES.add(boolean.class);
	}
	/** プロパティ. */
	protected PropertyDescriptor propertyDescriptor;
	/** ドメインモデルの型. */
	protected Class<?> clazz;

	/**
	 * {@link GPropertyMapperBase}を初期化します.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @param propertyDescriptor プロパティ
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GPropertyMapperBase(Class<?> clazz, PropertyDescriptor propertyDescriptor) {
		this.clazz = clazz;
		this.propertyDescriptor = propertyDescriptor;
	}

	/**
	 * ドメインモデルの対応するメンバに値を更新できるかどうかを判定します.<br/>
	 * 
	 * @param p プロパティ（{@link PropertyDescriptor}）
	 * @param value 設定する値
	 * @return 更新できる場合は<code>true</code> / 更新できない場合は<code>false</code>
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	private boolean canWriteField(PropertyDescriptor p, Object value) {
		if (value != null) {
			return true;
		}
		Class<?> clazz = p.getWriteMethod().getParameterTypes()[0];
		return !CANNOT_WRITE_FIELD_TYPES.contains(clazz);
	}

	/**
	 * ドメインモデルの対応するメンバの値を取得します.<br/>
	 * 
	 * @param model ドメインモデル
	 * @return 値
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@SuppressWarnings("unchecked")
	public Object readField(Object model) {
		try {
			Object value = propertyDescriptor.getReadMethod().invoke(model, (Object[]) null);
			return GTypeMapperFactory.Factory.getInstance().get(propertyDescriptor.getPropertyType()).read(value);
		} catch (IllegalAccessException e) {
			throw new GIllegalAccessRuntimeException(e);
		} catch (InvocationTargetException e) {
			throw new GIllegalAccessRuntimeException(e);
		}
	}

	/**
	 * ドメインモデルの対応するメンバの値を更新します.<br/>
	 * 
	 * @param model ドメインモデル
	 * @param value 値
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@SuppressWarnings("unchecked")
	public void writeField(Object model, Object value) {
		if (!canWriteField(propertyDescriptor, value)) {
			return;
		}
		try {
			Object convertedValue = GTypeMapperFactory.Factory.getInstance().get(propertyDescriptor.getPropertyType()).write(value);
			propertyDescriptor.getWriteMethod().invoke(model, convertedValue);
		} catch (IllegalAccessException e) {
			throw new IllegalStateException("Could not update value of property[" + propertyDescriptor.getName() + "]. ", e);
		} catch (InvocationTargetException e) {
			throw new IllegalStateException("Could not update value of property[" + propertyDescriptor.getName() + "]. ", e);
		} catch (RuntimeException e) {
			throw new IllegalStateException("Could not update value of property[" + propertyDescriptor.getName() + "]. ", e);
		}
	}

	/**
	 * ドメインモデルの対応するメンバのプロパティ（{@link PropertyDescriptor}）を取得します.<br/>
	 * 
	 * @return プロパティ（{@link PropertyDescriptor}）
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public PropertyDescriptor getPropertyDescriptor() {
		return this.propertyDescriptor;
	}

	/**
	 * ドメインモデルの対応するメンバのプロパティ（{@link PropertyDescriptor}）を設定します.<br/>
	 * 
	 * @param p プロパティ（{@link PropertyDescriptor}）
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public void setPropertyDescriptor(PropertyDescriptor p) {
		this.propertyDescriptor = p;
	}
}
