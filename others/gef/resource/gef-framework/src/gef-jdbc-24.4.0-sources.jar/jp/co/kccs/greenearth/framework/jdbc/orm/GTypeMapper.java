/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

/**
 * 任意の型の、Javaオブジェクトの値と{@link GRecord}の値とを相互変換するためのインターフェースです.
 *
 * @param <R> Javaオブジェクトの値の型
 * @param <W> GRecordの値の型
 * @author hashimoto
 * @since 3.17.0
 */
public interface GTypeMapper<R, W> {

	/**
	 * Javaオブジェクトから取得した値を、GRecordに設定する値に変換します.
	 *
	 * @param result Javaオブジェクトから取得した値
	 * @return GRecordに設定する値
	 */
	W read(R result);

	/**
	 * GRecordから取得した値を、Javaオブジェクトに設定する値に変換します.
	 *
	 * @param value GRecordから取得した値
	 * @return Javaオブジェクトに設定する値
	 */
	R write(W value);
}
