/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;


import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GTypeMapper}インスタンスを生成するファクトリーのインターフェースです.
 *
 * @author hashimoto
 * @create 2016/02/20
 * @since 3.17.0
 */
public interface GTypeMapperFactory {
	
	/**
	 * {@link GTypeMapperFactory}インスタンスを生成するためのクラスです。<br>
	 * 
	 * @author hashimoto
	 * @create 2016/02/20
	 * @since 3.17.0
	 */
	static class Factory {
		/**
		 * {@link GTypeMapperFactory}インスタンスを取得します。<br>
		 * 
		 * @return {@link GTypeMapperFactory}インスタンス
		 * @author hashimoto
		 * @create 2016/02/20
		 * @since 3.17.0
		 */
		public static GTypeMapperFactory getInstance() {
			return GFrameworkUtils.getComponent(GTypeMapperFactory.class.getName());
		}
	}
	
	/**
	 * {@link GTypeMapperFactory}インスタンスを取得します。<br>
	 * 
	 * @param clazz ドメインモデルの型
	 * @return {@link GTypeMapper}のインスタンス
	 * @author hashimoto
	 * @create 2016/02/20
	 * @since 3.17.0
	 */
	@SuppressWarnings("rawtypes")
	public GTypeMapper get(Class<?> clazz);

	/**
	 * {@link GTypeMapperFactory}インスタンスを取得します。<br>
	 * 
	 * @param name ドメインモデルの型の完全修飾名
	 * @return {@link GTypeMapper}のインスタンス
	 * @author hashimoto
	 * @create 2016/02/20
	 * @since 3.17.0
	 */
	@SuppressWarnings("rawtypes")
	public GTypeMapper get(String name);

}