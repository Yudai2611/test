/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.util.Map;

/**
 * {@link GTypeMapperFactory}のデフォルト実装クラスです.<br>
 *
 * @author hashimoto
 * @create 2016/02/20
 * @since 3.17.0
 */
public class GTypeMapperFactoryImpl implements GTypeMapperFactory {

	/** {@link GTypeMapper}を保持するマップ */
	@SuppressWarnings("rawtypes")
	Map<String, GTypeMapper> mappers = null;
	/** デフォルトで使用するマッパー*/
	private GTypeMapper<Object, Object> defaultTypeMapper = new GObjectTypeMapper();
	
	/**
	 * {@link GTypeMapperFactoryImpl}のインスタンスを生成します.<br>
	 * 
	 * @param mappers マッパーのマップ
	 * @author hashimoto
	 * @create 2016/02/20
	 * @since 3.17.0
	 */
	@SuppressWarnings("rawtypes")
	public GTypeMapperFactoryImpl(Map<String, GTypeMapper> mappers) {
		this.mappers = mappers;
	}
	
	/**
	 * {@link GTypeMapper}のインスタンスを取得します.<br>
	 * 
	 * @param clazz Javaオブジェクトのクラス
	 * @return {@link GTypeMapper}のインスタンス
	 * @author hashimoto
	 * @create 2016/02/20
	 * @since 3.17.0
	 */
	@SuppressWarnings("rawtypes")
	public GTypeMapper get(Class<?> clazz) {
		return get(clazz.getName());
	}

	/**
	 * {@link GTypeMapper}のインスタンスを取得します.<br>
	 * 
	 * @param name Javaオブジェクトの完全修飾名
	 * @return {@link GTypeMapper}のインスタンス
	 * @author hashimoto
	 * @create 2016/02/20
	 * @since 3.17.0
	 */
	@SuppressWarnings("rawtypes")
	public GTypeMapper get(String name) {
		if (mappers == null) {
			return defaultTypeMapper;
		}
		return mappers.containsKey(name) ? mappers.get(name) : defaultTypeMapper;
	}
}
