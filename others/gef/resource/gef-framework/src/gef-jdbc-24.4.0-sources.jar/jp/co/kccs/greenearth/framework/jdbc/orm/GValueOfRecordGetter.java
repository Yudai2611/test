/*
 * Copyright 2016-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.util.Date;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * 型を指定して値を取得するためインタフェースです.
 * 
 * @param <T> 指定する型
 * @author KCCS hashimoto
 * @create 2016/09/30
 * @since 3.19.0
 */
public interface GValueOfRecordGetter<T> {

	/**
	 * {@link GRecord}から指定された型で値を取得します.
	 * 
	 * @param record 値の取得先となる{@link GRecord}のインスタンス
	 * @param columnName 値を取得するカラム名
	 * @return {@link GRecord}のインスタンスから取得した値
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	T get(GRecord record, String columnName);

	/**
	 * {@link GRecord}から{@link Object}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GObjectValueGetter implements GValueOfRecordGetter<Object> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Object get(GRecord record, String columnName) {
			return record.getObject(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Boolean}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GBooleanValueGetter implements GValueOfRecordGetter<Boolean> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Boolean get(GRecord record, String columnName) {
			return record.getBoolean(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Byte}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GByteValueGetter implements GValueOfRecordGetter<Byte> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Byte get(GRecord record, String columnName) {
			return record.getByte(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Short}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GShortValueGetter implements GValueOfRecordGetter<Short> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Short get(GRecord record, String columnName) {
			return record.getShort(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Integer}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GIntegerValueGetter implements GValueOfRecordGetter<Integer> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Integer get(GRecord record, String columnName) {
			return record.getInteger(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Long}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GLongValueGetter implements GValueOfRecordGetter<Long> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Long get(GRecord record, String columnName) {
			return record.getLong(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Float}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GFloatValueGetter implements GValueOfRecordGetter<Float> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Float get(GRecord record, String columnName) {
			return record.getFloat(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Double}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GDoubleValueGetter implements GValueOfRecordGetter<Double> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Double get(GRecord record, String columnName) {
			return record.getDouble(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link BigDecimal}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GBigDecimalValueGetter implements GValueOfRecordGetter<BigDecimal> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public BigDecimal get(GRecord record, String columnName) {
			return record.getBigDecimal(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link String}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GStringValueGetter implements GValueOfRecordGetter<String> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public String get(GRecord record, String columnName) {
			return record.getString(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link Date}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GDateValueGetter implements GValueOfRecordGetter<Date> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Date get(GRecord record, String columnName) {
			return record.getDate(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link java.sql.Blob}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GBlobValueGetter implements GValueOfRecordGetter<Blob> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Blob get(GRecord record, String columnName) {
			return record.getBlob(columnName);
		}
	}

	/**
	 * {@link GRecord}から{@link java.io.InputStream}で値を取得するクラスです.
	 *
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public class GInputStreamValueGetter implements GValueOfRecordGetter<InputStream> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public InputStream get(GRecord record, String columnName) {
			try {
				return record.getBinaryStream(columnName);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * {@link GRecord}から{@link java.sql.Clob}で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GClobValueGetter implements GValueOfRecordGetter<Clob> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Clob get(GRecord record, String columnName) {
			return record.getClob(columnName);
		}
	}

	/**
	 * {@link GRecord}からbyte配列で値を取得するクラスです.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public class GBytesValueGetter implements GValueOfRecordGetter<byte[]> {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public byte[] get(GRecord record, String columnName) {
			return record.getBytes(columnName);
		}
	}
}
