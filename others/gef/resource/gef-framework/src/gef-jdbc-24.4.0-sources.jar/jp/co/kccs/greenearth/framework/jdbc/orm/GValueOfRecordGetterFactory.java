/*
 * Copyright 2016-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm;

import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * {@link GValueOfRecordGetter}を生成するファクトリークラスです.<br>
 *
 * @author KCCS hashimoto
 * @create 2016/09/30
 * @since 3.19.0
 */
public class GValueOfRecordGetterFactory {

	/** GVirtualEntityFactoryの唯一のインスタンス. */
	private static GValueOfRecordGetterFactory instance = null;
	/** {@link GValueOfRecordGetter}を保持するマップ */
	private Map<String, GValueOfRecordGetter<?>> getters = new HashMap<String, GValueOfRecordGetter<?>>();
	/** デフォルトで使用する{@link GValueOfRecordGetter}*/
	private GValueOfRecordGetter<Object> defaultGetter = new GValueOfRecordGetter.GObjectValueGetter();
	
	/**
	 * {@link GValueOfRecordGetterFactory}のインスタンスを生成します.<br>
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	private GValueOfRecordGetterFactory() {
		getters.put(Boolean.class.getName(), new GValueOfRecordGetter.GBooleanValueGetter());
		getters.put(boolean.class.getName(), new GValueOfRecordGetter.GBooleanValueGetter());
		getters.put(Byte.class.getName(), new GValueOfRecordGetter.GByteValueGetter());
		getters.put(byte.class.getName(), new GValueOfRecordGetter.GByteValueGetter());
		getters.put(Short.class.getName(), new GValueOfRecordGetter.GShortValueGetter());
		getters.put(short.class.getName(), new GValueOfRecordGetter.GShortValueGetter());
		getters.put(Integer.class.getName(), new GValueOfRecordGetter.GIntegerValueGetter());
		getters.put(int.class.getName(), new GValueOfRecordGetter.GIntegerValueGetter());
		getters.put(Long.class.getName(), new GValueOfRecordGetter.GLongValueGetter());
		getters.put(long.class.getName(), new GValueOfRecordGetter.GLongValueGetter());
		getters.put(Float.class.getName(), new GValueOfRecordGetter.GFloatValueGetter());
		getters.put(float.class.getName(), new GValueOfRecordGetter.GFloatValueGetter());
		getters.put(Double.class.getName(), new GValueOfRecordGetter.GDoubleValueGetter());
		getters.put(double.class.getName(), new GValueOfRecordGetter.GDoubleValueGetter());
		getters.put(BigDecimal.class.getName(), new GValueOfRecordGetter.GBigDecimalValueGetter());
		getters.put(String.class.getName(), new GValueOfRecordGetter.GStringValueGetter());
		getters.put(Date.class.getName(), new GValueOfRecordGetter.GDateValueGetter());
		getters.put(Blob.class.getName(), new GValueOfRecordGetter.GBlobValueGetter());
		getters.put(InputStream.class.getName(), new GValueOfRecordGetter.GInputStreamValueGetter());
		getters.put(Clob.class.getName(), new GValueOfRecordGetter.GClobValueGetter());
	}

	
	/**
	 * {@link GValueOfRecordGetterFactory}のインスタンスを生成します.<br>
	 * 
	 * @return GValueOfRecordGetterFactory
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public static synchronized GValueOfRecordGetterFactory getInstance() {
		if (instance == null) {
			instance = new GValueOfRecordGetterFactory();
		}
		return instance;
	}
	
	/**
	 * 型に応じた{@link GValueOfRecordGetter}を取得します.<br>
	 * 
	 * @param clazz 取得する値の型
	 * @return {@link GValueOfRecordGetter}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public GValueOfRecordGetter<?> get(Class<?> clazz) {
		return  get(clazz.getName());
	}
	
	/**
	 * 型に応じた{@link GValueOfRecordGetter}を取得します.<br>
	 * 
	 * @param name 取得する値の型の名前
	 * @return {@link GValueOfRecordGetter}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	public GValueOfRecordGetter<?> get(String name) {
		return getters.containsKey(name) ? getters.get(name) : defaultGetter;
	}
}
