/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;


import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * データベース上のテーブルを表現するためのアノテーションです.<br/>
 * <pre>
 * Example :<br/>
 * 	<code>@Entity(keyType=KeyType.PRIMARY)</code>
 * 	public class ItemMaster {
 * 	   ...
 * 	}
 * </pre>
 * 
 * @author KCCS yamashita
 * @create 2012/11/07
 * @since 3.12.0
 */
@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Entity {

	/**
	 * エンティティを一意に識別するための方法を定義するための属性です.<br/>
	 * {@link KeyType#PRIMARY}を指定した場合、エンティティのプライマリキーを利用します。<br/>
	 * {@link KeyType#UNIQUE}を指定した場合、エンティティのユニークキーを利用します。<br/>
	 * 
	 * @return
	 * @author KCCS yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	KeyType keyType() default KeyType.PRIMARY;
	
	/**
	 * {@link KeyType#UNIQUE}を指定した場合、ユニークキー名を定義するための属性です.<br/>
	 * <br/>
	 * <pre>
	 * Example（プライマリキー指定） :<br/>
	 * 	<code>@Entity(keyType=KeyType.PRIMARY)</code>
	 * 	public class ItemMaster {
	 * 	   ...
	 * 	}
	 *
	 * Example（ユニークキー指定） :<br/>
	 * 	<code>@Entity(keyType=KeyType.UNIQUE, keyName="キー名")</code>
	 * 	public class ItemMaster {
	 * 	   ...
	 * 	}
	 * </pre>
	 * 
	 * @return
	 * @author KCCS yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	String keyName() default "";

	/**
	 * 指定可能なキータイプ（{@link Entity#keyType()}）を定義します.<br/>
	 * <ul>
	 * <li>{@link #PRIMARY} </li>
	 * <li>{@link #UNIQUE} </li>
	 * </ul> 
	 * @author KCCS yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	public static enum KeyType {
		/** 
		 * O/Rマッピング機能において、問い合わせ結果の{@link jp.co.kccs.greenearth.framework.jdbc.GRecord}一覧をドメインモデルへマップする際に、該当するレコード（{@link jp.co.kccs.greenearth.framework.jdbc.GRecord}）を一意に識別するための検索キーとして<b>プライマリキー（{@link jp.co.kccs.greenearth.framework.jdbc.repository.GEntity#getPrimaryKey()}）</b>を利用します.<br/>
		 */
		PRIMARY,
		/** 
		 * O/Rマッピング機能において、問い合わせ結果の{@link jp.co.kccs.greenearth.framework.jdbc.GRecord}一覧をドメインモデルへマップする際に、該当するレコード（{@link jp.co.kccs.greenearth.framework.jdbc.GRecord}）を一意に識別するための検索キーとして<b>ユニークキー（{@link jp.co.kccs.greenearth.framework.jdbc.repository.GEntity#getUniqueKeys()}）</b>を利用します.<br/>
		 */
		UNIQUE
	}
}
