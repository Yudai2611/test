/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.orm.GIterationCallBack;

/**
 * エンティティー（データベースのレコード）に対してのO/Rマッピング機能を表すインタフェースです。
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public interface GEntityMapper {
	
	/**
	 * 検索用のSQLを構築します。
	 * 
	 * @param select エンティティー
	 * @return SQLが構築された引数のインスタンス
	 * @create 2014/09/12
	 * @author KCCS kitamura
	 * @since 3.12.0
	 */
	GEntitySelect buildSelect(GEntitySelect select);
	
	/**
	 * 検索用のSQLの抽出カラムを構築します。
	 * 
	 * @param select エンティティー
	 * @return SQLが構築された引数のインスタンス
	 * @create 2014/09/12
	 * @author KCCS kitamura
	 * @since 3.12.0
	 */
	GEntitySelect buildSelectFields(GEntitySelect select);
	
	/**
	 * エンティティーに定義された結合先エンティティーの関連に基づいて、{@link Entity}の結合条件を構築します。
	 * <p>
	 * ※{@link JoinType#RIGHT_OUTER_JOIN}はサポートしません.<br>
	 * 
	 * @param select エンティティー
	 * @param context マッピングコンテキスト
	 * @author KCCS R.Yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void buildJoinClause(GEntitySelect select, GMappingContext context);
	
	/**
	 * {@link GORMapper#mapIterate(GEntitySelect, GRecordSet, GIterationCallBack}を参照。
	 * 
	 * @param <T> ドメインモデルの型
	 * @param select エンティティー
	 * @param recordSet 結果セット
	 * @param context マッピングコンテキスト
	 * @param callBack コールバック
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	<T> void iterate(GEntitySelect select, GRecordSet recordSet, GMappingContext context, GIterationCallBack<T> callBack);
	
	/**
	 * 指定したドメインモデルの各カラムフィールド（{@link jp.co.kccs.greenearth.framework.jdbc.orm.Column}が定義されたフィールド）の値をそれぞれ対応する{@link GRecord}のカラムにマッピングします。
	 * 
	 * @param record レコード
	 * @param model ドメインモデル
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void map(GRecord record, Object model);
	
	/**
	 * {@link GRecord}一覧を基にドメインモデル一覧を構築します。
	 * <p>
	 * ドメインモデルインスタンスは、{@link GRecord}一覧より{@link Entity#keyType()}で集約された単位で生成されます。
	 * 
	 * @param select エンティティー
	 * @param recordList レコード一覧
	 * @param parentRecord 親レコード
	 * @param context マッピングコンテキスト
	 * @return ドメインモデル一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	List<?> map(GEntitySelect select, List<GRecord> recordList, GRecord parentRecord, GMappingContext context);
}