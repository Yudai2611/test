/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;

/**
 * {@link GEntityMapper}インスタンスを生成するためのクラスです.<br/>
 *
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public class GEntityMapperFactory {

	/** プロパティ名を使用したマッピングの使用可否 */
	private boolean usePropertyNameBind;
	/** {@link GEntityMapper}のキャッシュ. */
	private Map<Class<?>, GEntityMapper> entityMapperPool = new ConcurrentHashMap<Class<?>, GEntityMapper>();

	/**
	 * {@link GEntityMapperFactory}のインスタンスを初期化します.
	 *
	 * @author KCCS K.Fujita
	 * @create 2013/02/15
	 * @since 3.12.0
	 */
	public GEntityMapperFactory() {
	}

	/**
	 * {@link GEntityMapper}インスタンスを取得します.<br/>
	 *
	 * @param clazz ドメインモデルの型（キャッシュキー）
	 * @param entity エンティティ
	 * @return {@link GEntityMapper}インスタンス
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GEntityMapper getMapper(Class<?> clazz, GEntity entity) {
		if (!entityMapperPool.containsKey(clazz)) {
			GEntityMapper mapper = new GEntityMapperImpl(clazz, entity, this);
			entityMapperPool.put(clazz, mapper);
		}
		return entityMapperPool.get(clazz);
	}
	/**
	 * プロパティ名を使用したマッピングの使用可否を設定します.
	 *
	 * @param usePropertyNameBind プロパティ名を使用したマッピングの使用可否
	 * @author KCCS K.Fujita
	 * @create 2013/02/15
	 * @since 3.12.0
	 */
	public void setUsePropertyNameBind(boolean usePropertyNameBind) {
		this.usePropertyNameBind = usePropertyNameBind;
	}

	/**
	 * プロパティ名を使用したマッピングの使用可否を取得します.
	 *
	 * @return プロパティ名を使用したマッピングの使用可否
	 * @author KCCS K.Fujita
	 * @create 2013/02/15
	 * @since 3.12.0
	 */
	public boolean getUsePropertyNameBind() {
		return this.usePropertyNameBind;
	}
}
