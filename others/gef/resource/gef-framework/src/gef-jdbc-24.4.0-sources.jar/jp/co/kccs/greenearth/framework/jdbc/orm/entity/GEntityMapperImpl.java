/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.kccs.greenearth.commons.exception.GSQLRuntimeException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.GSelectColumnList;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GForeignKey;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GJoinColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GPrimaryKey;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GUniqueKey;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.GColumnPropertyMapper;
import jp.co.kccs.greenearth.framework.jdbc.orm.GColumnPropertyMapperImpl;
import jp.co.kccs.greenearth.framework.jdbc.orm.GIntrospectionRuntimeException;
import jp.co.kccs.greenearth.framework.jdbc.orm.GIterationCallBack;
import jp.co.kccs.greenearth.framework.jdbc.orm.GIterationContext;
import jp.co.kccs.greenearth.framework.jdbc.orm.GIterationContextImpl;
import jp.co.kccs.greenearth.framework.jdbc.orm.GValueOfRecordGetterFactory;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity.KeyType;

/**
 * {@link GEntityMapper}の実装クラスです.<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public class GEntityMapperImpl implements GEntityMapper {
	
	/** 
	 * 結合先エンティティのエイリアス名構築の際に利用するセパレータを表します.<br/> 
	 * 例えば、同一エンティティを結合した場合、エンティティのエイリアスが重複しないように、エイリアス名に特定のルールを設けることで問題を回避します。<br/>
	 * 特定のルールとは、結合先エンティティのエイリアス名のプレフィックスに結合元全てのエンティティエイリアス名をセパレータにより連結し、これを名前とします。<br/>
	 * 本セパレータは、この際利用するものとなります。<br/>
	 * <br/>
	 * <pre>
	 * 【例】
	 * X、Y、Zエンティティが直列に結合されている場合のZエンティティのエイリアスを示す（セパレータは"$"）。
	 * エイリアス・・・X$Y$Z
	 * </pre>
	 */
	static final String ALIAS_SEPARATOR = "$";
	
	/** ドメインモデルの型. */
	private Class<?> clazz = null;
	/** エンティティ. */
	private GEntity entity = null;
	/** {@link GColumnPropertyMapper}のプール. */
	private List<GColumnPropertyMapper> propertyMappers = new LinkedList<GColumnPropertyMapper>();
	/** {@link GRelationPropertyMapper}のプール. */
	private List<GRelationPropertyMapper> relationPropertyMappers = new LinkedList<GRelationPropertyMapper>();
	/** {@link GEntityMapperFactory}. */
	private GEntityMapperFactory entityMapperFactory;

	/**
	 * {@link GEntityMapperImpl}のインスタンスを生成します.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @param entity エンティティ
	 * @param entityMapperFactory マッパファクトリ(Entity)
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GEntityMapperImpl(Class<?> clazz, GEntity entity, GEntityMapperFactory entityMapperFactory) {
		this.clazz = clazz;
		this.entity = entity;
		this.entityMapperFactory = entityMapperFactory;
		
		BeanInfo beanInfo = getBeanInfo(clazz);
		for (PropertyDescriptor propertyDescriptor : beanInfo.getPropertyDescriptors()) {
			Method readMethod = propertyDescriptor.getReadMethod();
			if (readMethod == null) {
				continue;
			}
			
			if (readMethod.isAnnotationPresent(Column.class)) {
				String mappedColumnName = readMethod.getAnnotation(Column.class).name();
				propertyMappers.add(createPropertyMapper(clazz, propertyDescriptor, mappedColumnName));
			} else if (this.entityMapperFactory.getUsePropertyNameBind()) {
				String mappedColumnName = propertyDescriptor.getName();
				if (entity.getColumns().containsKey(mappedColumnName)) {
					propertyMappers.add(createPropertyMapper(clazz, propertyDescriptor, mappedColumnName));
				}
			}
			
			if (readMethod.isAnnotationPresent(OneToOne.class)) {
				relationPropertyMappers.add(new GOneToOnePropertyMapper(clazz, propertyDescriptor, entity, entityMapperFactory));
			} else if (readMethod.isAnnotationPresent(OneToMany.class)) {
				relationPropertyMappers.add(new GOneToManyPropertyMapper(clazz, propertyDescriptor, entity, entityMapperFactory));
			} else if (readMethod.isAnnotationPresent(ManyToOne.class)) {
				relationPropertyMappers.add(new GManyToOnePropertyMapper(clazz, propertyDescriptor, entity, entityMapperFactory));
			} else if (readMethod.isAnnotationPresent(ManyToMany.class)) {
				throw new UnsupportedOperationException("The \"many to many\" relation (@" + ManyToMany.class.getSimpleName() + ") is not supported.");
			}
		}
	}

	/**
	 * ドメインモデルに対してイントロスペクションを行い、BeanInfoを取得します.
	 * 
	 * @param clazz ドメインモデルの型
	 * @return ドメインモデルの{@link BeanInfo}
	 * @author KCCS K.Fujita
	 * @create 2013/03/19
	 * @since 3.12.0
	 */
	private BeanInfo getBeanInfo(Class<?> clazz) {
		try {
			return Introspector.getBeanInfo(clazz, Object.class);
		} catch (IntrospectionException e) {
			throw new GIntrospectionRuntimeException(e);
		}
	}

	@Override
	public GEntitySelect buildSelect(GEntitySelect select) {
		GMappingContext context = new GMappingContext();
		buildJoinClause(select, context);
		select = buildSelectFields(select);
		return select;
	}

	@Override
	public GEntitySelect buildSelectFields(GEntitySelect select) {
		List<GSelectColumn> selectColumns = new ArrayList<GSelectColumn>();
		GEntity entity = select.getEntity();
		String alias = select.getEntityAlias();
		selectColumns.addAll(select.createSelectColumnList(entity, alias)); // main エンティティ
		for (GJoinData joinData : select.getJoinList()) {
			GEntity refEntity = joinData.getJoinEntity();
			String refAlias = joinData.getJoinEntityAlias();
			selectColumns.addAll(select.createSelectColumnList(refEntity, refAlias));
		}
		
		Map<String, String> columnAliasMap = new HashMap<String, String>();
		int seq = 0;
		for (GSelectColumn vc : selectColumns) {
			StringBuilder aliasBuilder = new StringBuilder();
			String entityAlias = vc.getEntityAlias();
			if (entityAlias != null) {
				if (!entityAlias.equals(select.getEntityAlias()) && !GStringUtils.isEmpty(entityAlias)) { // mainエンティティカラムのエイリアスには、リレーション用セパレータを付加しない。
					aliasBuilder.append(entityAlias).append(ALIAS_SEPARATOR);
				}
			}
			String columnName = vc.getColumn().getName();
			aliasBuilder.append(columnName);
			String fullAlias = aliasBuilder.toString();
			String shortAlias = columnName + String.format("%03d", ++seq);
			columnAliasMap.put(fullAlias, shortAlias);
			vc.setAlias(shortAlias);
		}
		GSelectColumnList cols = select.createSelectColumnList();
		cols.addAll(selectColumns);
		select.fields(cols);
		
		InvocationHandler invoker = new GEntitySelectHandler(select, columnAliasMap);
		return (GEntitySelect) Proxy.newProxyInstance(GEntitySelect.class.getClassLoader(), new Class< ? >[] {GEntitySelect.class}, invoker);
	}
	
	/**
	 * {@link GEntitySelect}用のハンドラー.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2013/03/19
	 * @since 3.12.0
	 */
	public class GEntitySelectHandler implements InvocationHandler {	// TODO protected
		
		/** {@link GEntitySelect}のインスタンス */
		public GEntitySelect select;
		/** エイリアスのマップ */
		public Map<String, String> columnAliasMap;

		/**
		 * コンストラクタ.
		 * 
		 * @param select {@link GEntitySelect}のインスタンス
		 * @param columnAliasMap エイリアスのマップ
		 * @author KCCS K.Fujita
		 * @create 2013/03/19
		 * @since 3.12.0
		 */
		public GEntitySelectHandler(GEntitySelect select, Map<String, String> columnAliasMap) {
			this.select = select;
			this.columnAliasMap = columnAliasMap;
		}

		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			return method.invoke(select, args);
		}
	}

	@Override
	public void buildJoinClause(GEntitySelect select, GMappingContext context) {
		for (GRelationPropertyMapper relationMapper : this.getRelationPropertyMappers()) {
			validateJoinType(relationMapper.getJoinType());
			if (JoinType.INNER_JOIN.equals(relationMapper.getJoinType())) {
				select.innerJoinFK(createForeignKeyName(relationMapper, context), createEntityAlias(context, relationMapper.getMappedAlias()));
			} else if (JoinType.LEFT_OUTER_JOIN.equals(relationMapper.getJoinType())) {
				select.leftOuterJoinFK(createForeignKeyName(relationMapper, context), createEntityAlias(context, relationMapper.getMappedAlias()));
			} else {
				continue;
			}
			context.pushTargetRelationMapper(relationMapper);
			GEntityMapper refEntityMapper = entityMapperFactory.getMapper(relationMapper.getMappedType(), relationMapper.getForeignKey().getReferenceEntity());
			refEntityMapper.buildJoinClause(select, context);
			context.popTargetRelationMapper();
		}
	}

	/**
	 * 結合タイプを検証します.<br/>
	 * 結合タイプが{@link JoinType#RIGHT_OUTER_JOIN}の場合、例外をスローします.<br/>
	 * 
	 * @param joinType 結合タイプ
	 * @author KCCS R.Yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	private void validateJoinType(JoinType joinType) {
		if (JoinType.RIGHT_OUTER_JOIN.equals(joinType)) {
			throw new UnsupportedOperationException("right outer join is not supported.");
		}
	}

	/**
	 * 結合先エンティティ名を生成します.<br/>
	 * 
	 * @param mapper {@link GRelationPropertyMapper}インスタンス
	 * @param context マッピングコンテキスト
	 * @return 結合先エンティティ名
	 * @author KCCS R.Yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	private String createForeignKeyName(GRelationPropertyMapper mapper, GMappingContext context) {
		StringBuilder foreignKeyNameBuilder = new StringBuilder();
		GRelationPropertyMapper parentMapper = context.peekTargetRelationMapper();
		if (parentMapper != null) {
			foreignKeyNameBuilder.append(parentMapper.getMappedAlias()).append(".");
		}
		return foreignKeyNameBuilder.append(mapper.getForeignKey().getName()).toString();
	}

	/**
	 * {@link GORMapper#mapIterate(GEntity, GRecordSet, GIterationCallBack)}を参照.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GEntityMapper#iterate(jp.co.kccs.greenearth.framework.jdbc.GRecordSet, jp.co.kccs.greenearth.framework.jdbc.orm.entity.GMappingContext, jp.co.kccs.greenearth.framework.jdbc.orm.GIterationCallBack)
	 * @param <T> ドメインモデルの型
	 * @param select {@link GEntitySelect}のインスタンス
	 * @param recordSet 結果セット
	 * @param context マッピングコンテキスト
	 * @param callBack コールバック
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public <T> void iterate(GEntitySelect select, GRecordSet recordSet, GMappingContext context, GIterationCallBack<T> callBack) {
		final List<String> keyNames = extractKeyColumnNames(context); // 集約キー名の導出
		GIterationContext iterationContext = new GIterationContextImpl();
		GRecord previousRecord = null;
		GRecord currentRecord = null;
		GRecord nextRecord = null;
		boolean next = false;
		try {
			List<GRecord> tmpRecordList = new ArrayList<GRecord>();
			while (!iterationContext.isExit()) {
				currentRecord = nextRecord == null ? recordSet.getRecord() : nextRecord;
				previousRecord = currentRecord;
				context.createAndPutModel(clazz, extractKeyValues(select, currentRecord, keyNames, context)); // mainモデルを集約し、プール
				List<Object> previousKey = extractKeyValues(select, previousRecord, keyNames, context);
				Object model = context.createAndGetModel(clazz, previousKey);
				if (model == null) {
					next = recordSet.next();
					nextRecord = next ? recordSet.getRecord() : null;
					continue;
				}
				tmpRecordList.add(currentRecord);
				while (next) {
					next = recordSet.next();
					if (!next) {
						break;
					}
					currentRecord = recordSet.getRecord();
					List<Object> currentKey = extractKeyValues(select, currentRecord, keyNames, context);
					if (currentKey != null && !currentKey.equals(previousKey)) {
						nextRecord = currentRecord;
						break;
					}
					tmpRecordList.add(currentRecord);
					previousRecord = currentRecord;
					previousKey = extractKeyValues(select, previousRecord, keyNames, context);
				}
				for (GRecord record : tmpRecordList) {
					for (GColumnPropertyMapper mapper : propertyMappers) {
						String columnName = mapper.getMappedColumnName();
						Object value = getRecordValue(select, record, columnName, mapper.getPropertyType());
						if (value != null) {
							mapper.map(model, value);
						}
					}
					for (GRelationPropertyMapper mapper : relationPropertyMappers) {
						mapper.map(select, model, tmpRecordList, record, context);
					}
				}
				
				@SuppressWarnings("unchecked")
				T modelT = (T) model;
				callBack.iterate(modelT, iterationContext);
				tmpRecordList.clear();
				context.clear(clazz);
				if (!next) {
					iterationContext.setExit(true);
				}
			}
		} catch (SQLException e) {
			throw new GSQLRuntimeException(e);
		}
	}

	/**
	 * 指定したドメインモデルの各カラムフィールド（{@link Column}が定義されたフィールド）の値をそれぞれ対応する{@link GRecord}のカラムにマッピングします.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GEntityMapper#map(jp.co.kccs.greenearth.framework.jdbc.GRecord, java.lang.Object)
	 * @param record レコード
	 * @param model ドメインモデル
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public void map(GRecord record, Object model) {
		for (GColumnPropertyMapper mapper : propertyMappers) {
			mapper.map(record, model);
		}
	}

	/**
	 * {@link GRecord}一覧を基にドメインモデル一覧を構築します.<br/>
	 * ドメインモデルインスタンスは、{@link GRecord}一覧より{@link Entity#keyType()}で集約された単位で生成されます。<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GEntityMapper#map(java.util.List, jp.co.kccs.greenearth.framework.jdbc.GRecord, jp.co.kccs.greenearth.framework.jdbc.orm.entity.GMappingContext)
	 * @param select {@link GEntitySelect}のインスタンス
	 * @param recordList レコード一覧
	 * @param parentRecord 親レコード
	 * @param context マッピングコンテキスト
	 * @return ドメインモデル一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public List<?> map(GEntitySelect select, List<GRecord> recordList, GRecord parentRecord, GMappingContext context) {
		final List<String> fkNames = extractForeignKeyColumnNames(context); // join key の導出
		List<Object> result = new ArrayList<Object>();
		Set<Object> temp = new LinkedHashSet<Object>(); // 重複なし＆順序保持
		final List<String> keyNames = extractKeyColumnNames(context); // 集約キー名の導出
		for (GRecord record : recordList) {
			Object model = context.createAndGetModel(clazz, extractKeyValues(select, record, keyNames, context));
			if (model == null) {
				continue;
			}
			if (parentRecord != null && !matchForeignKey(select, parentRecord, record, keyNames, fkNames, context)) {
				continue;
			}
			if (!temp.add(model)) {
				continue;
			}
			for (GColumnPropertyMapper mapper : propertyMappers) {
				String columnName = createColumnAlias(context, mapper.getMappedColumnName());
				Object value = getRecordValue(select, record, columnName, mapper.getPropertyType());
				if (value != null) {
					mapper.map(model, value);
				}
			}
			for (GRelationPropertyMapper mapper : relationPropertyMappers) {
				mapper.map(select, model, recordList, record, context);
			}
		}
		result.addAll(temp);
		return result;
	}

	/**
	 * {@link GRelationPropertyMapper}の一覧を取得します.<br/>
	 * 
	 * @return {@link GRelationPropertyMapper}の一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public List<GRelationPropertyMapper> getRelationPropertyMappers() {
		return relationPropertyMappers;
	}

	/**
	 * {@link GColumnPropertyMapper}インスタンスを生成します.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @param propertyDescriptor プロパティ
	 * @param columnName 項目名
	 * @return {@link GColumnPropertyMapper}インスタンス
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected GColumnPropertyMapper createPropertyMapper(Class<?> clazz, PropertyDescriptor propertyDescriptor, String columnName) {
		return new GColumnPropertyMapperImpl(clazz, propertyDescriptor, columnName);
	}

	/**
	 * {@link GMappingContext}を基に処理対象の外部キー（{@link GForeignKey}）を特定し、結合キー項目名の一覧を抽出します.<br/>
	 * 
	 * @param context マッピングコンテキスト
	 * @return 結合キー項目名の一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected List<String> extractForeignKeyColumnNames(GMappingContext context) {
		List<String> fkNames = new ArrayList<String>();
		GRelationPropertyMapper mapper = context.peekTargetRelationMapper();
		if (mapper == null) {
			return fkNames;
		}
		GForeignKey fk = mapper.getForeignKey();
		if (fk == null) {
			return fkNames;
		}
		for (GJoinColumn joinColumn : fk.getJoinColumns()) {
			GColumn referenceColumn = joinColumn.getReferenceColumn();
			if (referenceColumn == null) {
				continue;
			}
			GColumn sourceColumn = joinColumn.getSourceColumn();
			if (sourceColumn == null) {
				continue;
			}
			fkNames.add(createColumnAlias(context, referenceColumn.getName()));
		}
		return fkNames;
	}

	/**
	 * 指定した結合キー項目名の一覧を基に、{@link GRecord}より該当する値をそれぞれ抽出します.<br/>
	 * 
	 * @param select {@link GEntitySelect}のインスタンス
	 * @param record レコード
	 * @param fkNames 結合キー項目名の一覧
	 * @param context {@link GMappingContext}のインスタンス
	 * @return 結合キー項目値の一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected List<Object> extractForeignKeyValues(GEntitySelect select, GRecord record, List<String> fkNames, GMappingContext context) {
		List<Object> fkValues = new ArrayList<Object>();
		for (int i = 0; i < fkNames.size(); i++) {
			String fkName = fkNames.get(i);
			Object value = getRecordValue(select, record, fkName);
			fkValues.add(value);
		}
		return fkValues;
	}
	
	/**
	 * レコードの値を取得します.
	 * 
	 * @param select {@link GEntitySelect}のインスタンス
	 * @param record レコード
	 * @param columnName カラム名
	 * @return レコードの値
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected Object getRecordValue(GEntitySelect select, GRecord record, final String columnName) {
		return getRecordValue(select, record, columnName, Object.class);
	}
	
	/**
	 * レコードの値を取得します.
	 * 
	 * @param select {@link GEntitySelect}のインスタンス
	 * @param record レコード
	 * @param columnName カラム名
	 * @param clazz 取得する値の型
	 * @return レコードの値
	 * @author KCCS hashimoto
	 * @create 2016/09/30
	 * @since 3.19.0
	 */
	protected Object getRecordValue(GEntitySelect select, GRecord record, final String columnName, Class<?> clazz) {
		Map<String, String> columnAliasMap = null;
		if (Proxy.isProxyClass(select.getClass())) {
			InvocationHandler handler = Proxy.getInvocationHandler(select);
			if (handler instanceof GEntitySelectHandler) {
				columnAliasMap = ((GEntitySelectHandler) handler).columnAliasMap;
			}
		}

		if (columnAliasMap != null && columnAliasMap.keySet().contains(columnName)) {
			String shortName = columnAliasMap.get(columnName);
			return GValueOfRecordGetterFactory.getInstance().get(clazz).get(record, shortName);
		} else if (record.getVariants().keySet().contains(columnName)) {
			return GValueOfRecordGetterFactory.getInstance().get(clazz).get(record, columnName);
		}
		return null;
	}

	/**
	 * {@link GMappingContext}を基に、エンティティの集約キー項目名の一覧を抽出します.<br/>
	 * 集約キー項目は、{@link Entity#keyType()}で定義した内容により決定されます。<br/>
	 * 
	 * @param context マッピングコンテキスト
	 * @return 集約キー項目名の一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected List<String> extractKeyColumnNames(GMappingContext context) {
		Entity entityMeta = clazz.getAnnotation(Entity.class);
		List<GColumn> columnList = null;
		if (KeyType.PRIMARY.equals(entityMeta.keyType())) {
			GPrimaryKey pk = entity.getPrimaryKey();
			if (pk == null) {
				throw new IllegalArgumentException("The primary key is not defined.");
			}
			columnList = pk.getReferenceColumns();
		} else {
			final String uniqueKeyName = entityMeta.keyName();
			if (GStringUtils.isEmpty(uniqueKeyName)) {
				throw new IllegalArgumentException("The unique key is not defined. key : " + uniqueKeyName);
			}
			GUniqueKey uk = entity.getUniqueKeys().get(uniqueKeyName);
			if (uk == null) {
				throw new IllegalArgumentException("The unique key is not found. key : " + uniqueKeyName);
			}
			columnList = uk.getReferenceColumns();
		}
		if (columnList.isEmpty()) {
			throw new IllegalArgumentException("The key (primary key or unique key) is not defined.");
		}
		List<String> pkNames = new ArrayList<String>();
		for (GColumn pkColumn : columnList) {
			pkNames.add(createColumnAlias(context, pkColumn.getName()));
		}
		return pkNames;
	}

	/**
	 * 指定した集約キー項目名の一覧を基に、{@link GRecord}より該当する値をそれぞれ抽出します.<br/>
	 * 
	 * @param select {@link GEntitySelect}のインスタンス
	 * @param record レコード
	 * @param keyNames 集約キー項目名の一覧
	 * @param context {@link GMappingContext}のインスタンス
	 * @return 集約キー項目値の一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected List<Object> extractKeyValues(GEntitySelect select, GRecord record, List<String> keyNames, GMappingContext context) {
		List<Object> keyValues = new ArrayList<Object>();
		if (record == null) {
			return keyValues;
		}
		for (String keyName : keyNames) {
			Object o = getRecordValue(select, record, keyName);
			if (o != null) {
				keyValues.add(o);
			}
		}
		return keyValues;
	}

	/**
	 * カレントレコードが、親レコードと結合されている（結合レコード）かどうかを判定します.<br/>
	 * 結合レコードとは、外部キーより抽出した共通の値（結合キー項目値）を、カレントレコードおよび親レコードがそれぞれ保持することを表します。<br/>
	 * 結合レコードの場合、O/Rマッピングの処理対象とし、後続の処理においてドメインモデルへのマッピングを続行します。<br/>
	 * また、null値での結合を判定するために、集約キー項目値（プライマリキーまたはユニークキーの値）がnull以外の場合、かつカレントレコードおよび親レコードの結合キー項目値がそれぞれnull値であれば、結合レコードであると判定します。<br/>
	 * 上記以外は全て結合対象外と判断し、O/Rマッピングは実行しません。<br/>
	 * 
	 * @param select {@link GEntitySelect}のインスタンス
	 * @param parentRecord 親レコード
	 * @param currentRecord カレントレコード
	 * @param keyNames 集約キー項目値の一覧
	 * @param fkNames 結合キー項目値の一覧
	 * @param context マッピングコンテキスト
	 * @return 結合されている場合は{@literal true} / 結合されていない場合は{@literal false}
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected boolean matchForeignKey(GEntitySelect select, GRecord parentRecord, GRecord currentRecord, final List<String> keyNames, List<String> fkNames, GMappingContext context) {
		List<Object> currentFkValues = extractForeignKeyValues(select, currentRecord, fkNames, context);
		List<Object> parentFkValues = extractForeignKeyValues(select, parentRecord, fkNames, context);
		List<Object> keyValues = extractKeyValues(select, currentRecord, keyNames, context);
		return !keyValues.isEmpty() && parentFkValues.equals(currentFkValues);	// PKがnullは、結合先データ無しと判断する。PKが!nullは、結合キーがnullでも該当データありと判断する（nullデータも結合する）。
	}
	
	/**
	 * カラム名のエイリアスを生成します.<br/>
	 * 
	 * @param context マッピングコンテキスト
	 * @param columnName カラム名
	 * @return エイリアス付きカラム名
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	private String createColumnAlias(GMappingContext context, String columnName) {
		String entityAlias = createEntityAlias(context, columnName);
		if (GStringUtils.isEmpty(entityAlias)) {
			return columnName;
		}
		return entityAlias;
	}
	
	/**
	 * エンティティ名のエイリアスを生成します.<br/>
	 * 
	 * @param context マッピングコンテキスト
	 * @param columnName 項目名
	 * @return エイリアス付きエンティティ名
	 * @author KCCS K.Fujita
	 * @create 2013/09/13
	 * @since 3.12.0
	 */
	private String createEntityAlias(GMappingContext context, String columnName) {
		StringBuilder aliasBuilder = new StringBuilder();
		for (GRelationPropertyMapper ownerMapper : context.getTargetRelationMapperStack()) {
			aliasBuilder.append(ownerMapper.getMappedAlias()).append(ALIAS_SEPARATOR);
		}
		return aliasBuilder.append(columnName).toString();
	}
	
}
