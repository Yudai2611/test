/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.beans.PropertyDescriptor;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GForeignKey;

/**
 * 多対一関係を持つデータモデルに対してO/Rマッピング機能を提供します.<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public class GManyToOnePropertyMapper extends GRelationPropertyMapperBase {

	/**
	 * {@link GManyToOnePropertyMapper}インスタンスを生成します.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @param propertyDescriptor プロパティ
	 * @param entity エンティティ
	 * @param entityMapperFactory マッパファクトリ(Entity)
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GManyToOnePropertyMapper(Class<?> clazz, PropertyDescriptor propertyDescriptor, GEntity entity, GEntityMapperFactory entityMapperFactory) {
		super(clazz, propertyDescriptor, entity, entityMapperFactory);
		ManyToOne annotation = propertyDescriptor.getReadMethod().getAnnotation(ManyToOne.class);
		JoinType joinType = annotation.joinType();
		String foreignKeyName = annotation.foreignKey();
		GForeignKey foreignKey = getForeignKey(entity, foreignKeyName);
		String mappedAlias = annotation.mappedAlias();
		init(propertyDescriptor.getReadMethod(), joinType, foreignKey, mappedAlias);
	}

	/**
	 * 多対一関係を表す{@link GRecord}一覧をドメインモデルへマッピングします.<br/>
	 * マップするドメインモデルには、{@link ManyToOne}アノテーションを定義しておく必要があります。<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapperBase#map(GEntitySelect, java.lang.Object, java.util.List, jp.co.kccs.greenearth.framework.jdbc.GRecord, jp.co.kccs.greenearth.framework.jdbc.orm.entity.GMappingContext)
	 * @param select {@link GEntitySelect}インスタンス
	 * @param model ドメインモデル
	 * @param recordList {@link GRecord}一覧
	 * @param parentRecord 親レコード
	 * @param context マッピングコンテキスト
	 * @return ドメインモデル一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public List<?> map(GEntitySelect select, Object model, List<GRecord> recordList, GRecord parentRecord, GMappingContext context) {
		List<?> relationModel = super.map(select, model, recordList, parentRecord, context);
		if (!relationModel.isEmpty()) {
			writeField(model, relationModel.get(0));
		}
		return relationModel;
	}
}
