/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.commons.exception.GIllegalAccessRuntimeException;

/**
 * {@link GEntityMapper}を使用したO/Rマッピングを遂行するために必要なコンテキストです.<br/>
 * 主に、以下の機能を提供します。<br/>
 * ・ドメインモデルインスタンスのキャッシュ<br/>
 * ・関連エンティティの階層構造の保持<br/>
 * ・エンティティに関連付けられたO/Rマッパインスタンスの管理<br/>
 * など<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public class GMappingContext {
	
	/** ドメインモデルインスタンスのプール. */
	Map<Class<?>, Map<List<Object>, Object>> modelContext = new ConcurrentHashMap<Class<?>, Map<List<Object>, Object>>();
	/** {@link GRelationPropertyMapper}のスタック（現在処理中の（関連エンティティの）階層も表す）. */
	LinkedList<GRelationPropertyMapper> targetRelationMapperStack = new LinkedList<GRelationPropertyMapper>();
	
	/**
	 * コンストラクタ.
	 * 
	 * @author KCCS kitamura
	 * @create 2012/11/25
	 * @since 3.12.0
	 */
	public GMappingContext() {
	}
	
	/**
	 * ドメインモデルのインスタンスキャッシュをクリアします.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public void clear(Class<?> clazz) {
		Map<List<Object>, Object> modelMap = modelContext.get(clazz);
		if (modelMap != null) {
			modelMap.clear();
		}
	}

	// TODO 名前を見直せないか？
	/**
	 * ドメインモデルのインスタンスを取得します.<br/>
	 * キャッシュが存在しない場合、インスタンスをキャッシュします。<br/>
	 * 
	 * @param clazz ドメインモデルの型（キャッシュ第1キー）
	 * @param key キー（キャッシュ第2キー）
	 * @return ドメインモデルのインスタンス
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public Object createAndGetModel(Class<?> clazz, List<Object> key) {
		createAndPutModel(clazz, key);
		return modelContext.get(clazz).get(key);
	}

	/**
	 * {@link GRelationPropertyMapper}のスタックを取得します.<br/>
	 * 
	 * @return {@link GRelationPropertyMapper}のスタック
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public LinkedList<GRelationPropertyMapper> getTargetRelationMapperStack() {
		return targetRelationMapperStack;
	}

	/**
	 * {@link GRelationPropertyMapper}のスタックの最後の要素を取得します.<br/>
	 * 
	 * @return {@link GRelationPropertyMapper}のスタックの最後の要素を
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GRelationPropertyMapper peekTargetRelationMapper() {
		if (targetRelationMapperStack.isEmpty()) {
			return null;
		}
		return targetRelationMapperStack.getLast();
	}

	/**
	 * {@link GRelationPropertyMapper}のスタックの最後の要素を削除します.<br/>
	 * 
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public void popTargetRelationMapper() {
		if (targetRelationMapperStack.isEmpty()) {
			return;
		}
		targetRelationMapperStack.removeLast();
	}

	/**
	 * {@link GRelationPropertyMapper}のスタックに追加します.<br/>
	 * 
	 * @param mapper {@link GRelationPropertyMapper}
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public void pushTargetRelationMapper(GRelationPropertyMapper mapper) {
		targetRelationMapperStack.addLast(mapper);
	}

	// TODO 名前を見直せないか？
	/**
	 * ドメインモデルのインスタンスを生成およびキャッシュします.<br/>
	 * 
	 * @param clazz ドメインモデルの型（キャッシュ第1キー）
	 * @param key キー（キャッシュ第2キー）
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public void createAndPutModel(Class<?> clazz, List<Object> key) {
		if (!modelContext.containsKey(clazz)) {
			modelContext.put(clazz, new ConcurrentHashMap<List<Object>, Object>());
		}
		if (key == null || key.isEmpty()) {
			return;
		}
		Map<List<Object>, Object> modelMap = modelContext.get(clazz);
		if (!modelMap.containsKey(key)) {
			Object newT = createInstance(clazz);
			modelMap.put(key, newT);
		}
	}

	/**
	 * ドメインモデルのインスタンスを生成します.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @return ドメインモデルのインスタンス
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	private Object createInstance(Class<?> clazz) {
		Object newInstance;
		try {
			newInstance = clazz.newInstance();
		} catch (InstantiationException e) {
			throw new GIllegalAccessRuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new GIllegalAccessRuntimeException(e);
		}
		return newInstance;
	}
	
//	/**
//	 * カラム別名の完全版と短縮版を管理するマップを取得します。<br/>
//	 * 
//	 * @return カラム別名の完全版と短縮版を管理するマップ
//	 * @author KCCS K.Fujita
//	 * @create 2013/09/06
//	 * @since 3.12.0
//	 */
//	public Map<String, String> getColumnAliasMap() {
//		return columnAliasMap;
//	}
//
//	/**
//	 * カラム別名の完全版と短縮版を管理するマップを設定します。<br/>
//	 * 
//	 * @param columnAliasMap カラム別名の完全版と短縮版を管理するマップ
//	 * @author KCCS K.Fujita
//	 * @create 2013/09/06
//	 * @since 3.12.0
//	 */
//	public void setColumnAliasMap(Map<String, String> columnAliasMap) {
//		this.columnAliasMap = columnAliasMap;
//	}


}
