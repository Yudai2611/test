/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GForeignKey;

/**
 * 関連エンティティー（結合されたエンティティー）に対するO/Rマッピング機能を表すインタフェースです。
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public interface GRelationPropertyMapper {

	/**
	 * 外部キーを取得します。
	 * 
	 * @return 外部キー
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	GForeignKey getForeignKey();
	
	/**
	 * 結合タイプを取得します。
	 * 
	 * @return 結合タイプ
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	JoinType getJoinType();
	
	/**
	 * 関連付けられた結合先エンティティーのエイリアス名を取得します。
	 * 
	 * @return 関連付けられた結合先エンティティーのエイリアス名
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	String getMappedAlias();
	
	/**
	 * 関連付けられたドメインモデルの型を取得します。
	 * 
	 * @return 関連付けられたドメインモデルの型
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	Class<?> getMappedType();
	
	/**
	 * {@link GRecord}のリストに基づいて、指定したドメインモデルに結合された配下のドメインモデルの該当するメンバに値を設定します。
	 * 
	 * @param select 検索情報が設定された{@link GEntitySelect}
	 * @param model ドメインモデル
	 * @param recordList {@link GRecord}のリスト
	 * @param parentRecord 親レコード
	 * @param context マッピングコンテキスト
	 * @return 結合された配下のドメインモデルのリスト
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	List<?> map(GEntitySelect select, Object model, List<GRecord> recordList, GRecord parentRecord, GMappingContext context);
	
	/**
	 * 外部キーを設定します。
	 * 
	 * @param foreignKey 外部キー
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void setForeignKey(GForeignKey foreignKey);
	
	/**
	 * 結合タイプを設定します。
	 * 
	 * @param joinType 結合タイプ
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void setJoinType(JoinType joinType);
	
	/**
	 * 関連付けられた結合先エンティティーのエイリアス名を設定します。
	 * 
	 * @param mappedAlias 関連付けられた結合先エンティティーのエイリアス名
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void setMappedAlias(String mappedAlias);
	
	/**
	 * 関連付けられたドメインモデルの型を設定します。
	 * 
	 * @param mappedType 関連付けられたドメインモデルの型
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	void setMappedType(Class<?> mappedType);
}