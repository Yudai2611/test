/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GEntity;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GForeignKey;
import jp.co.kccs.greenearth.framework.jdbc.orm.GPropertyMapperBase;

/**
 * {@link GRelationPropertyMapper}の基底クラスです.<br/>
 * 
 * @author KCCS yamashita
 * @create 2012/11/25
 * @since 3.12.0
 */
public abstract class GRelationPropertyMapperBase extends GPropertyMapperBase implements GRelationPropertyMapper {

	/** 外部キー. */
	private GForeignKey foreignKey;
	/** 結合タイプ. */
	private JoinType joinType;
	/** 関連付けられた結合先エンティティのエイリアス名. */
	private String mappedAlias;
	/** 関連付けられたドメインモデルの型. */
	private Class<?> mappedType;
	/** {@link GEntityMapperFactory}. */
	private GEntityMapperFactory entityMapperFactory;

	/**
	 * {@link GRelationPropertyMapperBase}を初期化します.<br/>
	 * 
	 * @param clazz ドメインモデルの型
	 * @param propertyDescriptor プロパティ
	 * @param entity エンティティ
	 * @param entityMapperFactory マッパファクトリ(Entity)
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	public GRelationPropertyMapperBase(Class<?> clazz, PropertyDescriptor propertyDescriptor, GEntity entity, GEntityMapperFactory entityMapperFactory) {
		super(clazz, propertyDescriptor);
		this.entityMapperFactory = entityMapperFactory;
	}

	/**
	 * {@link GRecord}一覧に基づいて、指定したドメインモデルに結合された配下のドメインモデルの該当するメンバに値を設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#map(GEntitySelect, java.lang.Object, java.util.List, jp.co.kccs.greenearth.framework.jdbc.GRecord, jp.co.kccs.greenearth.framework.jdbc.orm.entity.GMappingContext)
	 * @param select {@link GEntitySelect}インスタンス
	 * @param model ドメインモデル
	 * @param recordList {@link GRecord}一覧
	 * @param parentRecord 親レコード
	 * @param context マッピングコンテキスト
	 * @return 結合された配下のドメインモデル一覧
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public List<?> map(GEntitySelect select, Object model, List<GRecord> recordList, GRecord parentRecord, GMappingContext context) {
		context.pushTargetRelationMapper(this);
		GEntityMapper mapper = entityMapperFactory.getMapper(getMappedType(), getForeignKey().getReferenceEntity());
		List<?> relationModel = (List<?>) mapper.map(select, recordList, parentRecord, context);
		context.popTargetRelationMapper();
		return relationModel;
	}

	/**
	 * 外部キーを取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#getForeignKey()
	 * @return 外部キー
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public GForeignKey getForeignKey() {
		return this.foreignKey;
	}

	/**
	 * 結合タイプを取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#getJoinType()
	 * @return 結合タイプ
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public JoinType getJoinType() {
		return this.joinType;
	}

	/**
	 * 関連付けられた結合先エンティティのエイリアス名を取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#getMappedAlias()
	 * @return 関連付けられた結合先エンティティのエイリアス名
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public String getMappedAlias() {
		return this.mappedAlias;
	}

	/**
	 * 関連付けられたドメインモデルの型を取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#getMappedType()
	 * @return 関連付けられたドメインモデルの型
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public Class<?> getMappedType() {
		return mappedType;
	}

	/**
	 * 外部キーを設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#setForeignKey(jp.co.kccs.greenearth.framework.jdbc.entity.repository.GForeignKey)
	 * @param foreignKey 外部キー
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public void setForeignKey(GForeignKey foreignKey) {
		this.foreignKey = foreignKey;
	}

	/**
	 * 結合タイプを設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#setJoinType(jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType)
	 * @param joinType 結合タイプ
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public void setJoinType(JoinType joinType) {
		this.joinType = joinType;
	}

	/**
	 * 関連付けられた結合先エンティティのエイリアス名を設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#setMappedAlias(java.lang.String)
	 * @param mappedAlias 関連付けられた結合先エンティティのエイリアス名
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public void setMappedAlias(String mappedAlias) {
		this.mappedAlias = mappedAlias;
	}

	/**
	 * 関連付けられたドメインモデルの型を設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.orm.entity.GRelationPropertyMapper#setMappedType(java.lang.Class)
	 * @param mappedType 関連付けられたドメインモデルの型
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	@Override
	public void setMappedType(Class<?> mappedType) {
		this.mappedType = mappedType;
	}

	/**
	 * 指定したエンティティから外部キーを取得します.<br/>
	 * 
	 * @param entity エンティティ
	 * @param foreignKeyName 外部キー名
	 * @return 外部キー
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected GForeignKey getForeignKey(GEntity entity, String foreignKeyName) {
		GForeignKey fk = entity.getForeignKeys().get(foreignKeyName);
		if (fk == null) {
			throw new IllegalArgumentException("The foreign key is not specified. entity name : " + entity.getPhyName() + " foreign key : " + foreignKeyName);
		}
		return fk;
	}

	/**
	 * {@link GRelationPropertyMapper}インスタンスを初期化します.<br/>
	 * 
	 * @param method メソッド
	 * @param joinType 結合タイプ
	 * @param foreignKey 外部キー
	 * @param mappedAlias 関連付けられたエンティティのエイリアス名
	 * @author KCCS yamashita
	 * @create 2013/01/29
	 * @since 3.12.0
	 */
	protected void init(Method method, JoinType joinType, GForeignKey foreignKey, String mappedAlias) {
		Class<?> mappedType = null;
		if (method.getReturnType().equals(List.class)) {
			mappedType = (Class<?>) ((ParameterizedType) method.getGenericReturnType()).getActualTypeArguments()[0];
		} else {
			mappedType = (Class<?>) method.getReturnType();
		}
		if (JoinType.RIGHT_OUTER_JOIN.equals(joinType)) {
			throw new UnsupportedOperationException("right outer join is not supported.");
		}
		
		if (GStringUtils.isEmpty(mappedAlias)) {
			throw new IllegalArgumentException("The alias (mapped alias) is not defined.");
		}
		this.foreignKey = foreignKey;
		this.mappedAlias = mappedAlias;
		this.mappedType = mappedType;
		this.joinType = joinType;
	}
}
