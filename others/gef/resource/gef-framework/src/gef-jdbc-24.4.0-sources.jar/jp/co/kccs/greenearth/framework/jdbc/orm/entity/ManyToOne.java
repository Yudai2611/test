/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.orm.entity;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData.JoinType;


/**
 * データベース上のテーブル関連において、多対一の関係（参照関係）を表現するためのアノテーションです.<br/>
 * <pre>
 * Example :<br/>
 *	<code>@ManyToOne(foreignKey="UNITFK", joinType=JoinType.INNER_JOIN, mappedAlias="un")</code>
 *	public UnitMaster getUnitMaster() {
 *		return _unitMaster;
 *	}
 * </pre>
 * 
 * @author KCCS yamashita
 * @create 2012/11/05
 * @since 3.12.0
 */
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface ManyToOne {
	
	/**
	 * 外部キー名を定義するための属性です.<br/>
	 * 
	 * @return
	 * @author KCCS yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	String foreignKey() default "";
	
	/**
	 * 結合タイプを定義するための属性です.<br/>
	 * 
	 * @return
	 * @author KCCS yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	JoinType joinType() default JoinType.INNER_JOIN;
	
	/**
	 * 結合先エンティティのエイリアス名を定義するための属性です.<br/>
	 * 
	 * @return
	 * @author KCCS yamashita
	 * @create 2013/01/28
	 * @since 3.12.0
	 */
	String mappedAlias() default "";
}
