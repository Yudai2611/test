/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link BindParam}の集合を表します.
 * 
 * @create 2016/02/19
 * @author yamashita
 * @since 3.17.0
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface BindParams {

	/**
	 * バインドパラメータの型を設定します.
	 *
	 * @create 2016/02/19
	 * @author yamashita
	 * @since 3.17.0
	 */
	BindParam[] value() default {};
}