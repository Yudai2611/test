/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.kccs.greenearth.framework.jdbc.GAssembledFactorExpression;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GExpressionFactor;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GExpressionFactor.Operator;
import jp.co.kccs.greenearth.framework.jdbc.GReplaceExpression;

/**
 * {@link GAssembledFactorExpression}を文字列に変換する機能を提供するクラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2013/06/21
 * @since 3.12.0
 */
public class GAssembledFactorExpressionConverter extends GReplaceExpressionConverterBase {
	
	/** 等価演算子 */
	private static final String OPERATOR_EQUAL = "=";
	/** 不等価演算子 */
	private static final String OPERATOR_NOT_EQUAL = "<>";
	/** IS NULL演算子 */
	private static final String IS_NULL = " IS NULL";
	/** IS NOT NULL演算子 */
	private static final String IS_NOT_NULL = " IS NOT NULL";
	
	/** 等価演算子を抽出する正規表現 */
	private static final String REG_EQUAL = "[^<>]=";
	/** 等価演算子を抽出するパターン */
	private static final Pattern PTN_EQUAL = Pattern.compile(REG_EQUAL);
	/** 不等価演算子を抽出する正規表現 */
	private static final String REG_NOT_EQUAL = "<>";
	/** 不等価演算子を抽出するパターン */
	private static final Pattern PTN_NOT_EQUAL = Pattern.compile(REG_NOT_EQUAL);
	
	/** 角括弧の付与されていない名前付きパラメータを抽出する正規表現*/
	private static final String REG_NON_BRACKETED_NAMED_PLACE_HOLDER = "(:[a-zA-Z0-9_%]+(?=[\\s\\)\\+\\-\\*\\/\\=\\<\\>\\,\\!]{1})|:[a-zA-Z0-9_%]+(?=$))";
	/** 角括弧の付与されていない名前付きパラメータを抽出するパターン */
	private static final Pattern PTN_NON_BRACKETED_NAMED_PLACE_HOLDER = Pattern.compile(REG_NON_BRACKETED_NAMED_PLACE_HOLDER);
	/** 角括弧の付与された名前付きパラメータを抽出する正規表現*/
	private static final String REG_BRACKETED_NAMED_PLACE_HOLDER = "(:\\[[a-zA-Z0-9_%]+\\](?=[\\s\\)\\+\\-\\*\\/\\=\\<\\>\\,\\!]{1})|:\\[[a-zA-Z0-9_%]+\\](?=$))";
	/** 角括弧の付与された名前付きパラメータを抽出するパターン*/
	private static final Pattern PTN_BRACKETED_NAMED_PLACE_HOLDER = Pattern.compile(REG_BRACKETED_NAMED_PLACE_HOLDER);
	
	/** 角括弧の付与されていないプレースホルダを抽出する正規表現 */
	private static final String REG_PLACEHOLDER = "\\?";
	/** 角括弧の付与されていないプレースホルダを抽出するパターン */
	private static final Pattern PTN_PLACEHOLDER = Pattern.compile(REG_PLACEHOLDER);
	/** 角括弧の付与されたプレースホルダを抽出する正規表現 */
	private static final String REG_BRACKETED_PLACE_HOLDER = "\\[\\?\\]";
	/** 角括弧の付与されたプレースホルダを抽出するパターン */
	private static final Pattern PTN_BRACKETED_PLACE_HOLDER = Pattern.compile(REG_BRACKETED_PLACE_HOLDER);

	/** 角括弧の開始を抽出する正規表現 */
	private static final String REG_BRACKETS_OPEN = "\\[";
	/** 角括弧の終了を抽出する正規表現 */
	private static final String REG_BRACKETS_CLOSE = "\\]";
	
	/**
	 * {@link GAssembledFactorExpressionConverter}のインスタンスを生成します.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2013/06/21
	 * @since 3.12.0
	 */
	public GAssembledFactorExpressionConverter() {
	}

	/**
	 * {@link GExpression}で表現された条件等からSQL断片を生成します.
	 * 
	 * @param query クエリ
	 * @param exp 式
	 * @return SQL断片
	 * @author KCCS N.Nishimura
	 * @create 2014/01/17
	 * @since 3.13.0
	 */
	@Override
	public GSQLPiece convertExpression(GQuery< ? > query, GExpression exp) {
		GAssembledFactorExpression afExp = (GAssembledFactorExpression) exp;

		// GExpressionが持つ配列パラメータが直接操作されるため、クローンを生成
		GAssembledFactorExpression tempExp = null;
		try {
			tempExp = afExp.clone();
		} catch (CloneNotSupportedException e) {
			throw new IllegalStateException(e);
		}
		GSQLPiece piece = super.convertExpression(query, tempExp);
		return piece;
	}
	
	@Override
	protected String createSource(GReplaceExpression exp) {
		return parse((GAssembledFactorExpression) exp);
	}
	
	/**
	 * {@link GAssembledFactorExpression}が表現する条件式の文字列を生成します.
	 * 
	 * @param exp 条件式
	 * @return 表現されている条件式の文字列
	 * @author KCCS K.Fujita
	 * @create 2013/06/21
	 * @since 3.12.0
	 */
	protected String parse(GAssembledFactorExpression exp) {
		if (exp.getMapParamsList() != null) {
			if (exp.getMapParamsList().size() > 1) {
				throw new UnsupportedOperationException(GAssembledFactorExpression.class.getName() + " does not support Batch Update.");
			}
			Map<String, Object> map = exp.getMapParamsList().get(0);
			return parseMapFactor(exp.getRootFactor(), map);
		}
		if (exp.getArrayParamsList() != null) {
			if (exp.getArrayParamsList().size() > 1) {
				throw new UnsupportedOperationException(GAssembledFactorExpression.class.getName() + " does not support Batch Update.");
			}
			Object[] array = exp.getArrayParamsList().get(0);
			ParseArrayFactorContext context = new ParseArrayFactorContext();
			String expStr = parseArrayFactor(exp.getRootFactor(), array, context);
			
			// 除去した条件のパラメータを間引く
			exp.setArrayParams(removeUnnecessaryNullElements(array, context));
			
			return expStr;
		}
		throw new IllegalArgumentException("Parameters are not set.");
	}
	
	//---------------------MAP-----------------------------
	
	/**
	 * 引数で指定されたパラメータを使用する場合の、{@link GExpressionFactor}が表現するSQLを生成します.<br/>
	 * 
	 * @param rootFactor 式のルートとなる条件式
	 * @param paramMap パラメータ（マップ）
	 * @return 条件式が表すSQL
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	protected String parseMapFactor(GExpressionFactor rootFactor, Map<String, Object> paramMap) {
		StringBuilder sb = new StringBuilder();
		
		if (rootFactor.hasChild()) {	// 子階層
			String childSql = parseMapFactor(rootFactor.getChild(), paramMap);
			if (!childSql.isEmpty()) {
				sb.append(rootFactor.getOperator().toOperatorString()).append("(").append(childSql).append(")");
			}
		}
		else {
			String condition = rootFactor.getCondition();
			String name = extractPlaceHolderName(condition);
			Object value = paramMap.get(name);
			if (value instanceof GBindParam) {
				value = ((GBindParam) value).getValue();
			}
			if (name != null && value == null) {
				if (hasNonBracketedNamedPlaceHolder(condition)) {
					if (hasEqualOperator(condition)) {
						String columnName = rootFactor.getCondition().substring(0, rootFactor.getCondition().indexOf(OPERATOR_EQUAL));
						condition = columnName + IS_NULL;
					}
					else if (hasNotEqualOperator(condition)) {
						String columnName = rootFactor.getCondition().substring(0, rootFactor.getCondition().indexOf(OPERATOR_NOT_EQUAL));
						condition = columnName + IS_NOT_NULL;
					}
					appendCondition(sb, condition, rootFactor.getOperator(), sb);
				}
				// 消える場合の註釈
			}
			else {
				appendCondition(sb, condition, rootFactor.getOperator(), sb);
			}
		}
		
		for (GExpressionFactor sibling : rootFactor.getSiblings()) {	// 兄弟階層
			sb.append(parseMapSiblingFactor(sibling, paramMap, sb.toString()));
		}
		
		// 角括弧を取り除く
		if (hasBracketedNamedPlaceHolder(sb)) {
			return removeBracketsFromNamedPlaceHolder(sb.toString());
		}
		
		return sb.toString();
	}
	
	/**
	 * 兄弟階層の条件式のSQLを生成します.<br/>
	 * <br/>
	 * @param factor {@link GExpressionFactor}のインスタンス
	 * @param paramMap パラメータ（マップ）
	 * @param before それまでに生成されているSQL
	 * @return 兄弟階層の条件式のSQL
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	private String parseMapSiblingFactor(GExpressionFactor factor, Map<String, Object> paramMap, CharSequence before) {
		StringBuilder sb = new StringBuilder();

		if (factor.hasChild()) {	// 子階層
			String childSql = parseMapFactor(factor.getChild(), paramMap);
			if (!childSql.isEmpty()) {
				if (before.length() != 0) {
					sb.append(factor.getOperator().toOperatorString());
				}
				sb.append("(").append(childSql).append(")");
			}
		}
		else {
			String condition = factor.getCondition();
			String name = extractPlaceHolderName(condition);
			Object value = paramMap.get(name);
			if (value instanceof GBindParam) {
				value = ((GBindParam) value).getValue();
			}
			if (name != null && value == null) {
				if (hasNonBracketedNamedPlaceHolder(condition)) {
					if (hasEqualOperator(condition)) {
						String columnName = factor.getCondition().substring(0, factor.getCondition().indexOf(OPERATOR_EQUAL));
						condition = columnName + IS_NULL;
					}
					else if (hasNotEqualOperator(condition)) {
						String columnName = factor.getCondition().substring(0, factor.getCondition().indexOf(OPERATOR_NOT_EQUAL));
						condition = columnName + IS_NOT_NULL;
					}
					appendCondition(sb, condition, factor.getOperator(), before);
				}
				// 消える場合の註釈
			}
			else {
				appendCondition(sb, condition, factor.getOperator(), before);
			}
		}
		
		return sb.toString();
	}
	
	/**
	 * 条件式より名前付きパラメータの名前を取り出します.<br/>
	 * 条件式内に複数の名前付きパラメータが使用されている場合も最初の1つのみ取り出します.<br/>
	 * <br/>
	 * @param condition 条件式
	 * @return 名前付きパラメータの名前
	 * @author KCCS K.Fujita
	 * @create 2013/04/27
	 * @since 3.12.0
	 */
	private String extractPlaceHolderName(CharSequence condition) {
		if (condition == null) {
			return null;
		}
		
		Matcher paramMatcher = PTN_NON_BRACKETED_NAMED_PLACE_HOLDER.matcher(condition);
		if (paramMatcher.find()) {
			String paramedName = paramMatcher.group(0).replaceAll("%", "");
			return paramedName.substring(1);	//名前付きパラメータからコロンを除く
		}
		
		Matcher bracketedParamMatcher = PTN_BRACKETED_NAMED_PLACE_HOLDER.matcher(condition);
		if (bracketedParamMatcher.find()) {
			String paramedName = bracketedParamMatcher.group(0).replaceAll("%", "");
			return paramedName.substring(2, paramedName.length() - 1);	//名前付きパラメータからコロンと角括弧を除く
		}

		return null;
	}
	
	/**
	 * 条件式が角括弧で囲まれた名前付きパラメータを持つかどうかを検査します.<br/>
	 * <br/>
	 * @param condition 条件式
	 * @return 角括弧で囲まれた名前付きパラメータを持つならば<code>true</code>／持たなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/04/23
	 * @since 3.12.0
	 */
	private boolean hasBracketedNamedPlaceHolder(CharSequence condition) {
		return condition != null && PTN_BRACKETED_NAMED_PLACE_HOLDER.matcher(condition).find();
	}
	
	/**
	 * 条件式が角括弧で囲まれていない名前付きパラメータを持つかどうかを検査します.<br/>
	 * 
	 * @param condition 条件式
	 * @return 角括弧で囲まれていない名前付きパラメータを持つならば<code>true</code>／持たなければ<code>false</code>
	 * @author KCCS K.FUjita
	 * @create 2013/06/25
	 * @since 3.12.0
	 */
	private boolean hasNonBracketedNamedPlaceHolder(CharSequence condition) {
		return condition != null && PTN_NON_BRACKETED_NAMED_PLACE_HOLDER.matcher(condition).find();
	}
	
	/**
	 * 条件式の名前付きパラメータより角括弧を除去します.<br/>
	 * <br/>
	 * @param expStr 角括弧を除去する条件式
	 * @return 角括弧が除去された条件式
	 * @author KCCS K.Fujita
	 * @create 2013/04/25
	 * @since 3.12.0
	 */
	private String removeBracketsFromNamedPlaceHolder(String expStr) {
		return expStr.replaceAll(REG_BRACKETS_OPEN, "").replaceAll(REG_BRACKETS_CLOSE, "");
	}
	
	//---------------------Array-----------------------------
	
	/**
	 * 引数で指定されたパラメータを使用する場合の、{@link GExpressionFactor}が表現するSQLを生成します.<br/>
	 * <br/>
	 * @param rootFactor 式のルートとなる条件式
	 * @param paramArray パラメータ（配列）
	 * @param context インデックス情報
	 * @return この条件式が表現するSQL
	 * @author KCCS K.Fujita
	 * @create 2013/06/04
	 * @since 3.12.0
	 */
	protected String parseArrayFactor(GExpressionFactor rootFactor, Object[] paramArray, ParseArrayFactorContext context) {
		StringBuilder sb = new StringBuilder();
		
		if (rootFactor.hasChild()) {	// 子階層
			String childSql = parseArrayFactor(rootFactor.getChild(), paramArray, context);
			if (!childSql.isEmpty()) {
				sb.append(rootFactor.getOperator().toOperatorString()).append("(").append(childSql).append(")");
			}
		}
		else {
			String condition = rootFactor.getCondition();
			boolean hasPlaceHolder = hasPlaceHolder(condition);
			Object value = null;
			if (hasPlaceHolder) {
				context.increment();
				value = paramArray[context.getCurrentIndex()];
				if (value instanceof GBindParam) {
					value = ((GBindParam) value).getValue();
				}
			}
			if (hasPlaceHolder && value == null) {
				if (hasNonBracketedPlaceHolder(condition)) {
					if (hasEqualOperator(condition)) {
						String columnName = rootFactor.getCondition().substring(0, rootFactor.getCondition().indexOf(OPERATOR_EQUAL));
						condition = columnName + IS_NULL;
						context.memorize();
					}
					else if (hasNotEqualOperator(condition)) {
						String columnName = rootFactor.getCondition().substring(0, rootFactor.getCondition().indexOf(OPERATOR_NOT_EQUAL));
						condition = columnName + IS_NOT_NULL;
						context.memorize();
					}
					appendCondition(sb, condition, rootFactor.getOperator(), sb);
				}
				else {
					// 消える場合の註釈
					context.memorize();
				}
			}
			else {
				appendCondition(sb, condition, rootFactor.getOperator(), sb);
			}
		}
		
		for (GExpressionFactor sibling: rootFactor.getSiblings()) {		// 兄弟階層
			sb.append(parseArraySiblingFactor(sibling, sb.toString(), paramArray, context));
		}
		
		// 角括弧を取り除く
		if (hasBracketedPlaceHolder(sb)) {
			return removeBracketsFromPlaceHolders(sb.toString());
		}
		
		return sb.toString();
	}

	/**
	 * 兄弟階層の条件式のSQLを生成します.<br/>
	 * <br/>
	 * @param factor 条件式の要素
	 * @param before それまでに生成されているSQL
	 * @param context インデックス情報
	 * @param paramArray パラメータ（配列）
	 * @return 兄弟階層の条件式のSQL
	 * @author KCCS K.Fujita
	 * @create 2013/06/04
	 * @since 3.12.0
	 */
	private String parseArraySiblingFactor(GExpressionFactor factor, CharSequence before, Object[] paramArray, ParseArrayFactorContext context) {
		StringBuilder sb = new StringBuilder();
		
		if (factor.hasChild()) {	// 子階層
			String childSql = parseArrayFactor(factor.getChild(), paramArray, context);
			if (!childSql.isEmpty()) {
				if (before.length() != 0) {
					sb.append(factor.getOperator().toOperatorString());
				}
				sb.append("(").append(childSql).append(")");
			}
		}
		else {
			String condition = factor.getCondition();
			boolean hasPlaceHolder = hasPlaceHolder(condition);
			Object value = null;
			if (hasPlaceHolder) {
				context.increment();
				value = paramArray[context.getCurrentIndex()];
				if (value instanceof GBindParam) {
					value = ((GBindParam) value).getValue();
				}
			}
			if (hasPlaceHolder && value == null) {
				if (hasNonBracketedPlaceHolder(condition)) {
					if (hasEqualOperator(condition)) {
						String columnName = condition.substring(0, factor.getCondition().indexOf(OPERATOR_EQUAL));
						condition = columnName + IS_NULL;
						context.memorize();
					}
					else if (hasNotEqualOperator(condition)) {
						String columnName = condition.substring(0, factor.getCondition().indexOf(OPERATOR_NOT_EQUAL));
						condition = columnName + IS_NOT_NULL;
						context.memorize();
					}
					appendCondition(sb, condition, factor.getOperator(), before);
				}
				else {
					// 消える場合の註釈
					context.memorize();
				}
			}
			else {
				appendCondition(sb, condition, factor.getOperator(), before);
			}
		}
		
		return sb.toString();
	}
	
	/**
	 * 条件式にプレースホルダが1つ以上あるかどうかを検査します.<br/>
	 * 
	 * @param condition 条件式
	 * @return 1つ以上のプレースホルダを角括弧で囲まれていれば<code>true</code>／囲まれていなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/05/21
	 * @since 3.12.0
	 */
	private boolean hasPlaceHolder(CharSequence condition) {
		return condition != null && PTN_PLACEHOLDER.matcher(condition).find();
	}
	
	/**
	 * 条件式に角括弧で囲まれたプレースホルダが1つ以上あるかどうかを検査します.<br/>
	 * 
	 * @param condition 条件式
	 * @return 1つ以上の角括弧で囲まれたプレースホルダを持つならば<code>true</code>／持たなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/05/21
	 * @since 3.12.0
	 */
	private boolean hasBracketedPlaceHolder(CharSequence condition) {
		return condition != null && PTN_BRACKETED_PLACE_HOLDER.matcher(condition).find();
	}

	/**
	 * 条件式が角括弧で囲まれていないプレースホルダを持つどうかを検査します.<br/>
	 * 
	 * @param condition 条件式
	 * @return 条件式が角括弧で囲まれていないプレースホルダを持つならば<code>true</code>／持たなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/06/25
	 * @since 3.12.0
	 */
	private boolean hasNonBracketedPlaceHolder(CharSequence condition) {
		return hasPlaceHolder(condition) && !hasBracketedPlaceHolder(condition);
	}
	
	/**
	 * SQLのプレースホルダより角括弧を除去します.<br/>
	 * 
	 * @param sql 角括弧を除去するSQL
	 * @return 角括弧が除去されたSQL
	 * @author KCCS K.Fujita
	 * @create 2013/05/21
	 * @since 3.12.0
	 */
	private String removeBracketsFromPlaceHolders(String sql) {
		return sql.replaceAll(REG_BRACKETED_PLACE_HOLDER, "?");
	}
	
	/**
	 * 配列の要素から不要になったnull値を除去します.
	 * 
	 * @param array 不要な要素を取り除く対象のパラメータ配列
	 * @param context 削除対象のインデックス情報を保持するコンテキスト
	 * @return 不要なnull値が取り除かれたパラメータ配列
	 * @author KCCS K.Fujita
	 * @create 2013/05/21
	 * @since 3.12.0
	 */
	private Object[] removeUnnecessaryNullElements(Object[] array, ParseArrayFactorContext context) {
		List<Object> list = new ArrayList<Object>(Arrays.asList(array));
		List<Integer> deleteIndexes = context.getMemories();
		
		// 削除対象インデックスを降順にソート
		Collections.sort(deleteIndexes);
		Collections.reverse(deleteIndexes);
		
		// リストから削除対象インデックスの要素を削除
		for (int target : deleteIndexes) {
			list.remove(target);
		}
		
		if (list.size() != 0) {
			return list.toArray(new Object[]{list.size()});
		} else {
			// 要素数が0の場合、toArray()メソッドでは要素としてnullを持つ配列が返されるため、
			// 空の配列を新しく生成する
			return new Object[]{};
		}
	}
	
	/**
	 * {@link GAssembledFactorExpression}の変換で使用されるコンテキスト情報を保持するクラスです.<br/>
	 * 
	 * @author KCCS K.Fujita
	 * @create 2013/05/21
	 * @since 3.12.0
	 */
	final class ParseArrayFactorContext {
		/** 現在のインデックス */
		int currentIndex = -1;
		/** 記憶したインデックスのリスト */
		List<Integer> targets = new ArrayList<Integer>();
		
		/**
		 * {@link ParseArrayFactorContext}のインスタンスを生成します.
		 * 
		 * @author KCCS K.Fujita
		 * @create 2013/05/21
		 * @since 3.12.0
		 */
		private ParseArrayFactorContext() {
		}
		
		/**
		 * 現在のインデックスを1増加させます.
		 * 
		 * @author KCCS K.Fujita
		 * @create 2013/05/21
		 * @since 3.12.0
		 */
		private void increment() {
			this.currentIndex++;
		}
		
		/**
		 * 現在のインデックスを取得します.
		 * 
		 * @return 現在のインデックス
		 * @author KCCS K.Fujita
		 * @create 2013/05/21
		 * @since 3.12.0
		 */
		private int getCurrentIndex() {
			return this.currentIndex;
		}
		
		/**
		 * 記憶したインデックスのリストを取得します.
		 * 
		 * @return 記憶したインデックスのリスト
		 * @author KCCS K.Fujita
		 * @create 2013/06/14
		 * @since 3.12.0
		 */
		private List<Integer> getMemories() {
			return this.targets;
		}
		
		/**
		 * 現在のインデックスを記憶します.
		 * 
		 * @author KCCS K.Fujita
		 * @create 2013/06/14
		 * @since 3.12.0
		 */
		private void memorize() {
			targets.add(currentIndex);
		}
	}
	
	//---------------------共通-----------------------------
	
	/**
	 * 条件式をStringBuilderに結合します.<br/>
	 * <br/>
	 * @param sb 文字列を結合するStringBuilder
	 * @param condition 条件式
	 * @param operator 論理演算子
	 * @param before それまでに生成された文字シーケンス
	 * @return このExpが持つ条件式が結合された StringBuilder
	 * @author KCCS K.Fujita
	 * @create 2013/04/25
	 * @since 3.12.0
	 */
	private StringBuilder appendCondition(StringBuilder sb, String condition, GExpressionFactor.Operator operator, CharSequence before) {
		if (Operator.NOT.equals(operator) || before.length() != 0) {
			sb.append(operator.toOperatorString());
		}
		return sb.append(condition);
	}
	
	/**
	 * 条件式に等価演算子が含まれているかどうか検査します.<br/>
	 * <br/>
	 * @param condition 条件式
	 * @return 条件式に等価演算子が含まれていれば<code>true</code>／含まれていなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/04/25
	 * @since 3.12.0
	 */
	private boolean hasEqualOperator(CharSequence condition) {
		return condition != null && PTN_EQUAL.matcher(condition).find();
	}
	
	/**
	 * 条件式に不等価演算子が含まれているかどうか検査します.<br/>
	 * <br/>
	 * @param condition 条件式
	 * @return 条件式に不等価演算子が含まれていれば<code>true</code>／含まれていなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/04/25
	 * @since 3.12.0
	 */
	private boolean hasNotEqualOperator(CharSequence condition) {
		return condition != null && PTN_NOT_EQUAL.matcher(condition).find();
	}
}
