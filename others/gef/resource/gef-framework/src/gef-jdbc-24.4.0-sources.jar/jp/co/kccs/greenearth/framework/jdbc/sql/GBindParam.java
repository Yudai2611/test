/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;

/**
 * SQLにバインドする値の情報を保持するクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/09
 * @since 3.12.0
 */
public class GBindParam {

	/** バインドする値 */
	private Object value;
	/** バインドする値の型 */
	private GColumnType type;
	/** パラメータモード */
	private ParamMode mode;
	
	/**
	 * パラメータモードの列挙型
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	public enum ParamMode {
		/** INモードを表します */
		IN, 
		/** OUTモードを表します */
		OUT, 
		/** INOUTモードを表します */
		INOUT;
	}
	

    /**
     * 値のみを指定して{@link GBindParam}のインスタンスを生成します.
     * 
     * @param value パラメータの値
     * @return 値のみ指定された{@link GBindParam}のインスタンス
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public static GBindParam create(Object value) {
		return create(value, null);
	}
	

    /**
     * 値と型を指定して{@link GBindParam}のインスタンスを生成します.<br/>
     * 値が{@link GBindParam}型もしくはそのサブタイプでない場合、{@link ParamMode}がINの{@link GBindParam}のインスタンスを生成します.<br/>
     * 
     * @param value パラメータの値
     * @param type パラメータの型
     * @return 値と型が指定された{@link GBindParam}のインスタンス
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public static GBindParam create(Object value, GColumnType type) {
		if (value instanceof GBindParam) {
			return (GBindParam) value;
		}
		else {
			return new GBindParam(ParamMode.IN, value, type);
		}
	}

    /**
     * {@link Object}の配列で表されたパラメータを{@link GBindParam}の配列に変換します.
     * 
     * @param parameter {@link Object}の配列で表されたパラメータ
     * @return {@link GBindParam}の配列
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public static GBindParam[] toBindParams(Object[] parameter) {
		if (parameter != null) {
			GBindParam[] params = new GBindParam[parameter.length];
			for (int i = 0; i < parameter.length; i++) {
				params[i] = GBindParam.create(parameter[i]);
			}
			return params;
		} else {
			return null;
		}
	}

    /**
     * {@link Object}の配列のリストで表されたパラメータを{@link GBindParam}の配列のリストに変換します.
     * 
     * @param parameter {@link Object}の配列のリストで表されたパラメータ
     * @return {@link GBindParam}の配列のリスト
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public static List<GBindParam[]> toBindParamsList(List<Object[]> parameter) {
		List<GBindParam[]> list = new LinkedList<GBindParam[]>();
		for (Object[] params : parameter) {
			GBindParam[] bindParams = toBindParams(params);
			if (bindParams != null) {
				list.add(bindParams);
			}
		}
		return list;
	}

	/**
	 * {@link GBindParam}のインスタンスを生成します.
	 * 
	 * @param value バインドする値
	 * @author KCCS kitamura
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public GBindParam(Object value) {
		this.value = value;
	}

	/**
	 * バインドする値、バインドする値の型を設定します.
	 * 
	 * @param value バインドする値
	 * @param type バインドする値の型
	 * @author KCCS kitamura
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public GBindParam(Object value, GColumnType type) {
		this.value = value;
		this.type = type;
	}
	
	/**
	 * パラメータモードと型を指定して{@link GBindParam}のインスタンスを生成します.
	 * 
	 * @param mode パラメータモード
	 * @param type 型
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	public GBindParam(ParamMode mode, GColumnType type) {
		this.mode = mode;
		this.type = type;
	}
	
	/**
	 * パラメータモードと値、型を指定して{@link GBindParam}のインスタンスを生成します.
	 * 
	 * @param mode パラメータモード
	 * @param value 値
	 * @param type 型
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	public GBindParam(ParamMode mode, Object value, GColumnType type) {
		this.value = value;
		this.mode = mode;
		this.type = type;
	}

	/**
	 * バインドする値の型を設定します.
	 * 
	 * @param type バインドする値の型
	 * @author KCCS kitamura
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public void setType(GColumnType type) {
		this.type = type;
	}

	/**
	 * バインドする値を設定します.
	 * 
	 * @param value バインドする値
	 * @author KCCS kitamura
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public void setValue(Object value) {
		this.value = value;
	}

	/**
	 * バインドする値の型を取得します.
	 * 
	 * @return バインドする値の型
	 * @author KCCS kitamura
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public GColumnType getType() {
		return this.type;
	}

	/**
	 * バインドする値を取得します.
	 * 
	 * @param <T> 返却する値の型
	 * @return バインドする値
	 * @author KCCS kitamura
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public <T> T getValue() {
		@SuppressWarnings("unchecked")
		T t = (T) value;
		return t;
	}
	
	/**
	 * パラメータモードを取得します.
	 * 
	 * @return パラメータモード
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	public ParamMode getParamMode() {
		return mode;
	}
	
	/**
	 * パラメータモードを設定します.
	 * 
	 * @param mode パラメータモード
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	public void setParamMode(ParamMode mode) {
		this.mode = mode;
	}
}
