/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.List;

/**
 * SQL実行時のバインドパラメータを任意の型・値に変換するためのインタフェースです.
 *
 * @author yamashita
 * @create 2016/2/19
 * @since 3.17.0
 */
public interface GBindParamConverter {

	/**
	 * 指定されたバインドパラメータを任意の型・値に変換します.
	 *
	 * @param param バインドパラメータ
	 * @return バインドパラメータ
	 * @author yamashita
	 * @create 2016/2/19
	 * @since 3.17.0
	 */
	GBindParam convert(GBindParam param);

	/**
	 * コンバーターに関連付けられたバインドパラメータの型の集合を取得します.
	 *
	 * @return バインドパラメータの型の集合
	 * @create 2016/02/19
	 * @author yamashita
	 * @since 3.17.0
	 */
	List<BindParam> getBindParams();
}
