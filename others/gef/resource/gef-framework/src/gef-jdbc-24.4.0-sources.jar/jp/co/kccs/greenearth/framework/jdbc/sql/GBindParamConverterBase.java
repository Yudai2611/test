/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * {@link GBindParamConverter}の基底クラスです.
 *
 * @author kobayashi
 * @create 2016/2/20
 * @since 3.17.0
 */
public abstract class GBindParamConverterBase implements GBindParamConverter {

	/**
	 *
	 * {@inheritDoc}
	 *
	 */
	@Override
	public GBindParam convert(GBindParam param) {
		return param;
	}

	/**
	 *
	 * {@inheritDoc}
	 *
	 */
	@Override
	public List<BindParam> getBindParams() {
		List<BindParam> list = new ArrayList<BindParam>();
		for (Annotation a : getClass().getDeclaredAnnotations()) {
			Class<?> type = a.annotationType();
			if (type.equals(BindParam.class)) {
				list.add((BindParam) a);
			} else if (type.equals(BindParams.class)) {
				list.addAll(Arrays.asList(((BindParams) a).value()));
			}
		}
		if (list.size() == 0) {
			throw new IllegalStateException("It is necessary to specify the BindParams annotation.");
		}
		return list;
	}
}
