/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;


/**
 * {@link GBindParamConverter}のファクトリを表します.
 *
 * @author yamashita
 * @create 2016/2/19
 * @since 3.17.0
 */
public interface GBindParamConverterFactory {

	/**
	 * 指定した値に対応するコンバーターを取得します.<br/>
	 *
	 * @param value 型
	 * @return {@link GBindParamConverter}インスタンス
	 * @author yamashita
	 * @create 2016/02/19
	 * @since 3.17.0
	 */
	GBindParamConverter getConverter(Object value);

	/**
	 * 指定した値に対応するコンバーターを取得します.<br/>
	 *
	 * @param type 型
	 * @return {@link GBindParamConverter}インスタンス
	 * @author yamashita
	 * @create 2016/02/19
	 * @since 3.17.0
	 */
	GBindParamConverter getConverter(Class<?> type);
}
