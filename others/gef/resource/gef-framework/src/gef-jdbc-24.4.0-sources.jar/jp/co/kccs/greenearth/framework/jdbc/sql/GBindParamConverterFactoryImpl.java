/*
 * Copyright 2016-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * {@link GBindParamConverter}のファクトリクラスです.
 * <br/>
 * <br/>
 * 【コンバーターの取得について】<br/>
 *  指定されたバインドパラメータの型に対応するコンバーターを取得します。<br/>
 *  各種コンバーターのクラスアノテーション（{@link BindParam}または{@link BindParams}）には、予めバインドパラメータの型を宣言しておく必要があります。<br/>
 *  <br/>
 *  指定されたバインドパラメータの型に対応するコンバーターが存在しない場合、バインドパラメータの継承関係にある全てのクラスおよびインタフェースを探索し、<br/>
 *  それに関連付けられたコンバーターを取得します。<br/>
 *  <br/>
 *  例: 以下のようなコンバーターが設定されている状態で、バインドパラメータにInteger型の値を指定した場合、HogeConverterを取得します。<br/>
 *  
 *  <pre>
 *  [converter]
 *  {@code @BindParam(Number.class)}
 *  class HogeConverter {
 *  ...
 *  }
 *  
 *  [sample]
 *  public static void main(String[] args) {
 *  	...	
 *  	GBindParamConverter converter = factory.getConverter(Integer.parseInt("10"));
 *  	...
 *  }
 *  </pre>
 *  
 * @author yamashita
 * @create 2016/2/19
 * @since 3.17.0
 */
public class GBindParamConverterFactoryImpl implements GBindParamConverterFactory {

	/** コンバータのリスト */
	List<? extends GBindParamConverter> converters;
	/** コンバータのキャッシュ */
	Map<Class<?>, GBindParamConverter> converterCache = new ConcurrentHashMap<Class<?>, GBindParamConverter>();

	/**
	 * コンストラクタ.
	 *
	 * @param converterList コンバータのリスト
	 * @author yamashita
	 * @create 2016/02/19
	 * @since 3.17.0
	 */
	public GBindParamConverterFactoryImpl(List<? extends GBindParamConverter> converterList) {
		this.converters = converterList;
	}

	/**
	 * 
	 * {@inheritDoc}
	 *
	 */
	@Override
	public GBindParamConverter getConverter(Object value) {
		return getConverter(value == null ? (Class<?>) null : value.getClass());
	}

	/**
	 * 
	 * {@inheritDoc}
	 *
	 */
	@Override
	public GBindParamConverter getConverter(Class<?> type) {
		if (type == null) {
			type = Null.class;
		}
		if (converterCache.containsKey(type)) {
			return converterCache.get(type);
		}
		Map<Class<?>, Class<?>> genealogyClasses = getGenealogyClasses(type);
		for (GBindParamConverter converter : converters) {
			List<BindParam> params = converter.getBindParams();
			for (BindParam param : params) {
				if (genealogyClasses.containsKey(param.value())) {
					converterCache.put(type, converter);
					return converterCache.get(type);
				}
			}
		}
		return null;
	}

	/**
	 * 指定した型と継承関係にある全てのスーパークラス、インタフェースを返却します.<br/>
	 *
	 * @param type 型
	 * @return 型一覧マップ
	 * @create 2016/02/19
	 * @author yamashita
	 * @since 3.17.0
	 */
	protected Map<Class<?>, Class<?>> getGenealogyClasses(Class<?> type) {
		Map<Class<?>, Class<?>> map = new HashMap<Class<?>, Class<?>>();
		map.put(type, type);
		Class<?>[] interfaces = type.getInterfaces();
		for (Class<?> interfaceClass : interfaces) {
			map.putAll(getGenealogyClasses(interfaceClass));
		}
		Class<?> superClass = type.getSuperclass();
		if (superClass == null) {
			return map;
		}
		map.put(superClass, superClass);
		map.putAll(getGenealogyClasses(superClass));
		return map;
	}

	/**
	 * NULLに対応するためのクラス.
	 *
	 * @create 2016/02/19
	 * @author yamashita
	 * @since 3.17.0
	 */
	static class Null {
		
		/**
		 * コンストラクタ.
		 *
		 * @author yamashita
		 * @create 2016/02/19
		 * @since 3.17.0
		 */
		public Null() {
		}
	}
}
