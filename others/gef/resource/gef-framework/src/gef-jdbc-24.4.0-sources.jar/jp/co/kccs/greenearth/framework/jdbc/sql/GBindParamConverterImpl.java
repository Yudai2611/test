/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.io.InputStream;
import java.io.Reader;
import java.util.Date;

import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParamConverterFactoryImpl.Null;


/**
* {@link GBindParamConverter}のデフォルト実装クラスです.
*
* @author yamashita
* @create 2016/2/19
* @since 3.17.0
*/
@BindParams({
	@BindParam(String.class),
	@BindParam(Boolean.class),
	@BindParam(Date.class),
	@BindParam(Number.class),
	@BindParam(InputStream.class),
	@BindParam(Reader.class),
	@BindParam(byte[].class),
	@BindParam(Null.class)
})
public class GBindParamConverterImpl extends GBindParamConverterBase {
}
