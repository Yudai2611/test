/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.SQLException;

/**
 * 制約違反一般を表す例外クラスです。<br/>
 * 
 * @author KCCS K.Fujita
 * @create 2012/12/05
 * @since 3.12.0
 */
public abstract class GConstraintViolationException extends SQLException {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 3000754203574433708L;

	/**
	 * {@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException() {
		super();
	}

	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException(String reason) {
		super(reason);
	}

	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException(String reason, String sqlState) {
		super(reason, sqlState);
	}

	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @param vendorCode データベースベンダー固有の例外コード
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException(String reason, String sqlState, int vendorCode) {
		super(reason, sqlState, vendorCode);
	}

	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException(Throwable cause) {
		super(cause);
	}

	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException(String reason, Throwable cause) {
		super(reason, cause);
	}

	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException(String reason, String sqlState, Throwable cause) {
		super(reason, sqlState, cause);
	}

	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @param vendorCode データベースベンダー固有の例外コード
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GConstraintViolationException(String reason, String sqlState, int vendorCode, Throwable cause) {
		super(reason, sqlState, vendorCode, cause);
	}
}
