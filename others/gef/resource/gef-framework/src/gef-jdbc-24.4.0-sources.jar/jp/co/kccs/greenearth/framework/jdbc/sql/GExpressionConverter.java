/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;

/**
 * 変換式をSQL断片に変換するインタフェースです。
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public interface GExpressionConverter {
	
    /**
     * SQL構築要素と修飾式をSQL断片へ変換します。
     * 
     * @param query SQL構築要素
     * @param exp 変換式
     * @return SQL断片
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	GSQLPiece convertExpression(GQuery<?> query, GExpression exp);
	
	/**
     * SQL構築要素と修飾式をSQL断片へ変換します（バッチ実行用）。
	 * 
     * @param query SQL構築要素
     * @param exp 変換式
	 * @return SQL断片
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
	 */
	GSQLPiece convertBatchExpression(GQuery<?> query, GExpression exp);
}
