/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * 関数を生成するインタフェースです。
 * 
 * @author KCCS K.Fujita
 * @create 2012/11/20
 * @since 3.12.0
 */
public interface GFunctionGenerator {

	/**
	 * 関数を生成します。
	 * 
	 * @param funcName 関数名
	 * @param args 関数化に必要な要素
	 * @return 関数化した文字列
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	String createFunction(String funcName, String[] args);

}
