/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.HashMap;
import java.util.Map;

/**
 * {@link GFunctionGenerator}を実装する基底クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/11/20
 * @since 3.12.0
 */
public abstract class GFunctionGeneratorBase implements GFunctionGenerator {

	/** 関数マップ（key:関数名、value:関数を表すクラス） */
	protected Map<String, GFunctionGenerator> funcMap = new HashMap<String, GFunctionGenerator>();

	/**
	 * {@link GFunctionGeneratorBase}のインスタンスを初期化し、デフォルトの関数マップを登録します.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public GFunctionGeneratorBase() {
		/* 一般関数 */
		funcMap.put("ABS", new GAbsFunctionGenerator());
		funcMap.put("UPPER", new GUpperFunctionGenerator());
		funcMap.put("LOWER", new GLowerFunctionGenerator());
		funcMap.put("TRIM", new GTrimFunctionGenerator());
		funcMap.put("RTRIM", new GRTrimFunctionGenerator());
		funcMap.put("LTRIM", new GLTrimFunctionGenerator());
		funcMap.put("LENGTH", new GLengthFunctionGenerator());
		funcMap.put("REPLACE", new GReplaceFunctionGenerator());
		funcMap.put("CONCAT", new GConcatFunctionGenerator());
		funcMap.put("SUBSTR", new GSubStrFunctionGenerator());
		funcMap.put("LOCATE", new GLocateFunctionGenerator());
		funcMap.put("SQRT", new GSqrtFunctionGenerator());
		funcMap.put("MOD", new GModFunctionGenerator());
		funcMap.put("FLOOR", new GFloorFunctionGenerator());
		funcMap.put("CURRENT_DATE", new GCurrentDateFunctionGenerator());
		funcMap.put("CURRENT_TIMESTAMP", new GCurrentTimeStampFunctionGenerator());
		funcMap.put("NULLIF", new GNullIfFunctionGenerator());
		funcMap.put("COALESCE", new GCoalesceFunctionGenerator());

		/* 集約関数 */
		funcMap.put("AVG", new GAvgFunctionGenerator());
		funcMap.put("COUNT", new GCountFunctionGenerator());
		funcMap.put("MAX", new GMaxFunctionGenerator());
		funcMap.put("MIN", new GMinFunctionGenerator());
		funcMap.put("SUM", new GSumFunctionGenerator());
	}

	/**
	 * {@link GFunctionGeneratorBase}のインスタンスを初期化し、独自定義された関数マップを追加登録します.
	 * 
	 * @param orignFuncMap 独自定義関数のマップ（key:関数名、value:関数を表すクラス）
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public GFunctionGeneratorBase(Map<String, GFunctionGenerator> orignFuncMap) {
		this();
		/* 独自定義関数 */
		funcMap.putAll(orignFuncMap);
	}

	@Override
	public String createFunction(String funcName, String[] args) {
		if (funcMap.containsKey(funcName)) {
			return funcMap.get(funcName).createFunction(funcName, args);
		}
		return null;
	}

	/**
	 * ABS関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GAbsFunctionGenerator implements GFunctionGenerator {

		/**
		 * ABS関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args ABS関数へ渡す引数
		 * @return ABS関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "ABS(" + args[0] + ")";
		}
	}

	/**
	 * UPPER関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GUpperFunctionGenerator implements GFunctionGenerator {

		/**
		 * UPPER関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args UPPER関数へ渡す引数
		 * @return UPPER関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "UPPER(" + args[0] + ")";
		}
	}

	/**
	 * LOWER関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GLowerFunctionGenerator implements GFunctionGenerator {

		/**
		 * LOWER関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args LOWER関数へ渡す引数
		 * @return LOWER関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "LOWER(" + args[0] + ")";
		}
	}

	/**
	 * TRIM関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GTrimFunctionGenerator implements GFunctionGenerator {

		/**
		 * TRIM関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args TRIM関数へ渡す引数
		 * @return RTRIM関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/21
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "TRIM(" + args[0] + ")";
		}
	}

	/**
	 * RTRIM関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GRTrimFunctionGenerator implements GFunctionGenerator {

		/**
		 * RTRIM関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args RTRIM関数へ渡す引数
		 * @return RTRIM関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "RTRIM(" + args[0] + ")";
		}
	}

	/**
	 * LTRIM関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GLTrimFunctionGenerator implements GFunctionGenerator {

		/**
		 * LTRIM関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args LTRIM関数へ渡す引数
		 * @return LTRIM関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "LTRIM(" + args[0] + ")";
		}
	}

	/**
	 * LENGTH関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GLengthFunctionGenerator implements GFunctionGenerator {

		/**
		 * LENGTH関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args LENGTH関数へ渡す引数
		 * @return LENGTH関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "LENGTH(" + args[0] + ")";
		}
	}

	/**
	 * REPLACE関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GReplaceFunctionGenerator implements GFunctionGenerator {

		/**
		 * REPLACE関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args REPLACE関数へ渡す引数
		 * @return REPLACE関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "REPLACE(" + args[0] + ", " + args[1] + ", " + args[2] + ")";
		}
	}

	/**
	 * CONCAT関数を生成するジェネレータです.
	 * 
	 * @create 2012/11/20
	 * @author KCCS K.Fujita
	 * @since 3.12.0
	 */
	public class GConcatFunctionGenerator implements GFunctionGenerator {

		/**
		 * CONCAT関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args CONCAT関数へ渡す引数
		 * @return CONCAT関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "CONCAT(" + args[0] + "," + args[1] + ")";
		}
	}

	/**
	 * SUBSTR関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GSubStrFunctionGenerator implements GFunctionGenerator {

		/**
		 * SUBSTR関数のSQL文を生成します。 引数が3つの場合と2つの場合のオーバーロードを提供します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args SUBSTR関数へ渡す引数
		 * @return SUBSTR関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			if (args.length >= 3) {
				return "SUBSTR(" + args[0] + ", " + args[1] + ", " + args[2] + ")";
			}
			return "SUBSTR(" + args[0] + ", " + args[1] + ")";
		}
	}

	/**
	 * LOCATE関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GLocateFunctionGenerator implements GFunctionGenerator {

		/**
		 * LOCATE関数のSQL文を生成します。 引数が3つの場合と2つの場合のオーバーロードを提供します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args LOCATE関数へ渡す引数
		 * @return LOCATE関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/21
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			if (args.length >= 3) {
				return "LOCATE(" + args[0] + ", " + args[1] + ", " + args[2] + ")";
			}
			return "LOCATE(" + args[0] + ", " + args[1] + ")";
		}
	}

	/**
	 * SQRT関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GSqrtFunctionGenerator implements GFunctionGenerator {

		/**
		 * SQRT関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args SQRT関数へ渡す引数
		 * @return SQRT関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "SQRT(" + args[0] + ")";
		}
	}

	/**
	 * MOD関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GModFunctionGenerator implements GFunctionGenerator {

		/**
		 * MOD関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args MOD関数へ渡す引数
		 * @return MOD関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "MOD(" + args[0] + ", " + args[1] + ")";
		}
	}

	/**
	 * FLOOR関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GFloorFunctionGenerator implements GFunctionGenerator {

		/**
		 * FLOOR関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args FLOOR関数へ渡す引数
		 * @return FLOOR関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "FLOOR(" + args[0] + ")";
		}
	}

	/**
	 * CURRENT_DATE関数を生成するジェネレータです.
	 * 
	 * @create 2012/11/20
	 * @author KCCS K.Fujita
	 * @since 3.12.0
	 */
	public class GCurrentDateFunctionGenerator implements GFunctionGenerator {
		/**
		 * CURRENT_DATE関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args CURRENT_DATE関数へ渡す引数
		 * @return CURRENT_DATE関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "CURRENT_DATE";
		}
	}

	/**
	 * CURRENT_TIMESTAMP関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GCurrentTimeStampFunctionGenerator implements GFunctionGenerator {

		/**
		 * CURRENT_TIMESTAMP関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args CURRENT_TIMESTAMP関数へ渡す引数
		 * @return CURRENT_TIMESTAMP関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "CURRENT_TIMESTAMP";
		}
	}

	/**
	 * NULLIF関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GNullIfFunctionGenerator implements GFunctionGenerator {

		/**
		 * NULLIF関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args NULLIF関数へ渡す引数
		 * @return NULLIF関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "NULLIF(" + args[0] + "," + args[1] + ")";
		}
	}

	/**
	 * COALESCE関数を生成するジェネレータです.
	 * 
	 * @author KCCS S.Miwa
	 * @create 2016/9/1
	 * @since 3.19.0
	 */
	public class GCoalesceFunctionGenerator implements GFunctionGenerator {

		/**
		 * COALESCE関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args COALESCE関数へ渡す引数
		 * @return COALESCE関数のSQL
		 * @author KCCS S.Miwa
		 * @create 2016/9/1
		 * @since 3.19.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			StringBuilder sql = new StringBuilder();
			sql.append("COALESCE(");
			for (String arg : args) {
				sql.append(arg).append(", ");
			}
			sql.delete(sql.length() - 2, sql.length());
			sql.append(")");
			return sql.toString();
		}
	}

	/**
	 * AVG関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GAvgFunctionGenerator implements GFunctionGenerator {

		/**
		 * AVG関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args AVG関数へ渡す引数
		 * @return AVG関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "AVG(" + args[0] + ")";
		}
	}

	/**
	 * COUNT関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GCountFunctionGenerator implements GFunctionGenerator {

		/**
		 * COUNT関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args COUNT関数へ渡す引数
		 * @return COUNT関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "COUNT(" + args[0] + ")";
		}
	}

	/**
	 * MAX関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GMaxFunctionGenerator implements GFunctionGenerator {

		/**
		 * MAX関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args MAX関数へ渡す引数
		 * @return MAX関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "MAX(" + args[0] + ")";
		}
	}

	/**
	 * MIN関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GMinFunctionGenerator implements GFunctionGenerator {

		/**
		 * MIN関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args MIN関数へ渡す引数
		 * @return MIN関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "MIN(" + args[0] + ")";
		}
	}

	/**
	 * SUM関数を生成するジェネレータです.
	 * 
	 * @author KCCS K.Fujita
	 * @create 2012/11/20
	 * @since 3.12.0
	 */
	public class GSumFunctionGenerator implements GFunctionGenerator {

		/**
		 * SUM関数のSQL文を生成します。
		 * 
		 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GFunctionGenerator#createFunction(java.lang.String, java.lang.String[])
		 * @param funcName 関数名
		 * @param args SUM関数へ渡す引数
		 * @return SUM関数のSQL
		 * @author KCCS K.Fujita
		 * @create 2012/11/20
		 * @since 3.12.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			return "SUM(" + args[0] + ")";
		}
	}
}
