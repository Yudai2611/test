/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GFunctionGeneratorMySQLBase}をMySQL8.0用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GFunctionGeneratorMySQL8_0 extends GFunctionGeneratorMySQLBase {
	
	/**
	 * {@link GFunctionGeneratorMySQL8_0}のインスタンスを構築します.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GFunctionGeneratorMySQL8_0() {
		super();
	}
	
	/**
	 * {@link GFunctionGeneratorMySQL8_0}のインスタンスを構築し、関数マップに独自定義関数を追加登録します.
	 * 
	 * @param orignFuncMap 独自定義関数のマップ（key:関数名、value:関数を表すクラス）
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GFunctionGeneratorMySQL8_0(Map<String, GFunctionGenerator> orignFuncMap) {
		super(orignFuncMap);
	}
}
