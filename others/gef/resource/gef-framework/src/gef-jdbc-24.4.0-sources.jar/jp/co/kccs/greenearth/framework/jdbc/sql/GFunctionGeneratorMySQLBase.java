/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GFunctionGeneratorBase}をMySQL用に実装する基底クラスです.
 * 
 * @author KCCS Hashimoto
 * @create 2016/05/11
 * @since 3.18.0
 */
public abstract class GFunctionGeneratorMySQLBase extends GFunctionGeneratorBase {
	
	/**
	 * {@link GFunctionGeneratorMySQLBase}のインスタンスを構築します.
	 * 
	 * @author KCCS Hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	public GFunctionGeneratorMySQLBase() {
		super();
	}
	
	/**
	 * {@link GFunctionGeneratorMySQLBase}のインスタンスを構築し、関数マップに独自定義関数を追加登録します.
	 * 
	 * @param orignFuncMap 独自定義関数のマップ（key:関数名、value:関数を表すクラス）
	 * @author KCCS Hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	public GFunctionGeneratorMySQLBase(Map<String, GFunctionGenerator> orignFuncMap) {
		this();
		funcMap.putAll(orignFuncMap);
	}
}
