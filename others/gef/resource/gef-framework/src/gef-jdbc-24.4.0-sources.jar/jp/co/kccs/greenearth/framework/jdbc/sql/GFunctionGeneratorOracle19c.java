/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GFunctionGeneratorOracleBase}をOracle19c用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GFunctionGeneratorOracle19c extends GFunctionGeneratorOracleBase {

	/**
	 * {@link GFunctionGeneratorOracle19c}のインスタンスを構築し、関数マップをOracle19c用に更新します.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GFunctionGeneratorOracle19c() {
		super();
	}

	/**
	 * {@link GFunctionGeneratorOracle19c}のインスタンスを構築し、関数マップに独自定義関数を追加登録します.
	 * 
	 * @param orignFuncMap 独自定義関数のマップ（key:関数名、value:関数を表すクラス）
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GFunctionGeneratorOracle19c(Map<String, GFunctionGenerator> orignFuncMap) {
		super(orignFuncMap);
	}
}
