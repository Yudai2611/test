/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GFunctionGeneratorBase}をOracle用に実装する基底クラスです.
 * 
 * @author KCCS Hashimoto
 * @create 2016/08/30
 * @since 3.19.0
 */
public abstract class GFunctionGeneratorOracleBase extends GFunctionGeneratorBase {

	/**
	 * {@link GFunctionGeneratorOracleBase}のインスタンスを構築し、関数マップをOracle用に更新します.
	 * 
	 * @author KCCS Hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public GFunctionGeneratorOracleBase() {
		super();
		funcMap.put("LOCATE", new GLocateFunctionGenerator());
	}

	/**
	 * {@link GFunctionGeneratorOracleBase}のインスタンスを構築し、関数マップに独自定義関数を追加登録します.
	 * 
	 * @param orignFuncMap 独自定義関数のマップ（key:関数名、value:関数を表すクラス）
	 * @author KCCS Hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public GFunctionGeneratorOracleBase(Map<String, GFunctionGenerator> orignFuncMap) {
		this();
		funcMap.putAll(orignFuncMap);
	}

	/**
	 * Oracle用のLOCATE関数を生成するジェネレータです.
	 * 
	 * @author KCCS Hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public class GLocateFunctionGenerator implements GFunctionGenerator {

		/**
		 * Oracle用のLOCATE関数のSQL文を生成します. 引数が4つの場合、3つの場合、2つの場合のオーバーロードを提供します.
		 * 
		 * @param funcName 関数名
		 * @param args LOCATE関数へ渡す引数
		 * @return Oracle用のLOCATE関数のSQL文
		 * @author KCCS Hashimoto
		 * @create 2016/08/30
		 * @since 3.19.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			if (args.length >= 4) {
				return "INSTR(" + args[1] + ", " + args[0] + ", " + args[2] + ", " + args[3] + ")";
			} else if (args.length == 3) {
				return "INSTR(" + args[1] + ", " + args[0] + ", " + args[2] + ")";
			}
			return "INSTR(" + args[1] + ", " + args[0] + ")";
		}
	}
}
