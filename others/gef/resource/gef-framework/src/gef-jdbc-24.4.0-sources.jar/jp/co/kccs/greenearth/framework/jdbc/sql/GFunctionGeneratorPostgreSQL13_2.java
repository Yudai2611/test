/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GFunctionGeneratorPostgreSQLBase}をPostgreSQL13.2用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GFunctionGeneratorPostgreSQL13_2 extends GFunctionGeneratorPostgreSQLBase {

	/**
	 * {@link GFunctionGeneratorPostgreSQL13_2}のインスタンスを構築します.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GFunctionGeneratorPostgreSQL13_2() {
		super();
	}

	/**
	 * {@link GFunctionGeneratorPostgreSQL13_2}のインスタンスを構築し、関数マップに独自定義関数を追加登録します.
	 *
	 * @param orignFuncMap 独自定義関数のマップ（key:関数名、value:関数を表すクラス）
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GFunctionGeneratorPostgreSQL13_2(Map<String, GFunctionGenerator> orignFuncMap) {
		super(orignFuncMap);
	}
}
