/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GFunctionGeneratorBase}をMySQL用に実装する基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public abstract class GFunctionGeneratorPostgreSQLBase extends GFunctionGeneratorBase {

	/**
	 * {@link GFunctionGeneratorPostgreSQLBase}のインスタンスを構築します.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GFunctionGeneratorPostgreSQLBase() {
		super();
		funcMap.put("LOCATE", new GLocateFunctionGenerator());
	}
	
	/**
	 * {@link GFunctionGeneratorPostgreSQLBase}のインスタンスを構築し、関数マップに独自定義関数を追加登録します.
	 * 
	 * @param orignFuncMap 独自定義関数のマップ（key:関数名、value:関数を表すクラス）
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GFunctionGeneratorPostgreSQLBase(Map<String, GFunctionGenerator> orignFuncMap) {
		this();
		funcMap.putAll(orignFuncMap);
	}

	/**
	 * PostgreSQL用のLOCATE関数を生成するジェネレータです.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public class GLocateFunctionGenerator implements GFunctionGenerator {

		/**
		 * PostgreSQL用のLOCATE関数のSQL文を生成します. 引数が2つの場合のオーバーロードを提供します.
		 *
		 * @param funcName 関数名
		 * @param args LOCATE関数へ渡す引数
		 * @return PostgreSQL用のLOCATE関数のSQL文
		 * @author KCSS
		 * @create 2021/09/30
		 * @since 21.9.0
		 */
		@Override
		public String createFunction(String funcName, String[] args) {
			if (args.length >= 3) {
				StringBuffer sb = new StringBuffer();
				sb.append("(CASE ")
							.append("POSITION( ").append(args[0])
									.append(" IN SUBSTR(").append(args[1]).append(", ").append(args[2]).append(")")
							.append(") ")
					.append("WHEN ")
							.append("0 ")
					.append("THEN ")
							.append("0 ")
					.append("ELSE ")
							.append("(POSITION(").append(args[0])
									.append(" IN SUBSTR(").append(args[1]).append(", ").append(args[2]).append(")")
							.append(") + ").append(args[2]).append(" - 1) ")
					.append("END)");
				return sb.toString();
			}
			return "POSITION( " + args[0] + " IN " + args[1] + " )";
		}
	}
}
