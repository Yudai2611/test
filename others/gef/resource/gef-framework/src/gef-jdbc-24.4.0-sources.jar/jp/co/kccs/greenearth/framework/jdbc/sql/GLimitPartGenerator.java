/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import jp.co.kccs.greenearth.framework.jdbc.GSelect;

/**
 * 句を生成するインタフェースです。
 * 
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public interface GLimitPartGenerator {

	/**
	 * LIMIT/OFFSET(FETCH)句を生成します。
	 * 
	 * @param select ｸｴﾘ
	 * @return SQL断片
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	GSQLPiece createLimitClause(GSelect< ? > select);
	
}
