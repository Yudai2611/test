package jp.co.kccs.greenearth.framework.jdbc.sql;

import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;

/**
 * {@link GLimitPartGenerator}を実装する基底クラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public abstract class GLimitPartGeneratorBase implements GLimitPartGenerator {
	
	/**
	 * 引数の整合性をチェックします.
	 * 
	 * @param select {@link GEntitySelect}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	protected void validate(GSelect< ? > select) {
		
		if (select.getStartRowIndex() < 0) {
			throw new IllegalArgumentException("This start index is invalid. :" + select.getStartRowIndex());
		}
		if (select.getListSize() < -1) {
			throw new IllegalArgumentException("This list size is invalid. :" + select.getListSize());
		}
	}
	
	/**
	 * LIMIT節のSQL断片を生成します.
	 * 
	 * @param select LIMIT/OFFSET節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @param sql SQL文を格納する{@link StringBuilder}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	protected abstract void appendLimitSQLString(GSelect< ? > select, StringBuilder sql);

	/**
	 * LIMIT節のSQL断片を生成します.
	 * 
	 * @param select LIMIT/OFFSET節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @return LIMIT/OFFSET節を付与したSQLを設定した{@link GSQLPiece}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	public GSQLPiece createLimitClause(GSelect< ? > select) {
		
		validate(select);
		
		StringBuilder sql = new StringBuilder();
		if (select.getListSize() > -1 || select.getStartRowIndex() > 0) {
			appendLimitSQLString(select, sql);
		}
		return new GSQLPiece(sql.toString());
	}

}
