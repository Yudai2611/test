/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * {@link GLimitPartGeneratorMySQLBase}をMySQL8.0用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GLimitPartGeneratorMySQL8_0 extends GLimitPartGeneratorMySQLBase {
	
	/**
	 * {@link GLimitPartGeneratorMySQL8_0}のインスタンスを構築します.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GLimitPartGeneratorMySQL8_0() {
		super();
	}

}
