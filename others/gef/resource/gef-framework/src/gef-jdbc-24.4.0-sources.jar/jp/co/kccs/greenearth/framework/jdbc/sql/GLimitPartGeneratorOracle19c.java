/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * {@link GLimitPartGeneratorOracleBase}をOracle19c用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GLimitPartGeneratorOracle19c extends GLimitPartGeneratorOracleBase {
	
	/**
	 * {@link GLimitPartGeneratorOracle19c}のインスタンスを構築します.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GLimitPartGeneratorOracle19c() {
		super();
	}

}
