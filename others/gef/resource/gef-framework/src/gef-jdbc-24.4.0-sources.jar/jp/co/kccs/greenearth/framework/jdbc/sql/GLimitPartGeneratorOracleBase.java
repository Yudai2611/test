/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;

/**
 * {@link GLimitPartGeneratorOracleBase}をOracle用に実装する基底クラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GLimitPartGeneratorOracleBase extends GLimitPartGeneratorBase {

	/**
	 * LIMIT節のSQL断片を生成します.
	 * 
	 * @param select LIMIT/OFFSET節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @param sql SQL文を格納する{@link StringBuilder}のインスタンス
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	protected void appendLimitSQLString(GSelect< ? > select, StringBuilder sql) {
		//OFFSET
		if (select.getStartRowIndex() > 0) {
			sql.append(" OFFSET " + select.getStartRowIndex() + " ROWS");
		}
		//FETCH
		if (select.getListSize() > -1) {
			sql.append(" ");
			sql.append("FETCH FIRST " + select.getListSize() + " ROWS ONLY");
		}
	}
}
