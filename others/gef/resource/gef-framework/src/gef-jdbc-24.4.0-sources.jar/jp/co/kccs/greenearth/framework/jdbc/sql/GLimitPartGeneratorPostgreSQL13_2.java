/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * {@link GLimitPartGeneratorPostgreSQLBase}をPostgreSQL13.2用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GLimitPartGeneratorPostgreSQL13_2 extends GLimitPartGeneratorPostgreSQLBase {

	/**
	 * {@link GLimitPartGeneratorPostgreSQL13_2}のインスタンスを構築します.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GLimitPartGeneratorPostgreSQL13_2() {
		super();
	}

}
