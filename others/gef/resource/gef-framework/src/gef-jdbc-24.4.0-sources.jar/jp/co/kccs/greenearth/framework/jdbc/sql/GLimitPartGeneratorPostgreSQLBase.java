/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;

/**
 * {@link GLimitPartGeneratorPostgreSQLBase}をPostgreSQL用に実装する基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GLimitPartGeneratorPostgreSQLBase extends GLimitPartGeneratorBase {

	/** 最大行数 */
	private final int MAXSIZE = Integer.MAX_VALUE;
	
	/**
	 * LIMIT節のSQL断片を生成します.
	 * 
	 * @param select LIMIT/OFFSET節の付与対象となるSQLを設定した{@link GEntitySelect}のインスタンス
	 * @param sql SQL文を格納する{@link StringBuilder}のインスタンス
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	protected void appendLimitSQLString(GSelect< ? > select, StringBuilder sql) {
		//LIMIT
		if (select.getListSize() > -1) {
			sql.append(" LIMIT " + select.getListSize());
		} else {
			sql.append(" LIMIT " + MAXSIZE);
		}
		//OFFSET !!LIMITなしでOFFSETのみの指定は不可（PostgreSQL仕様）!!
		if (select.getStartRowIndex() > 0) {
			sql.append(" ");
			sql.append("OFFSET " + select.getStartRowIndex());
		}
	}
}
