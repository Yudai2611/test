/*
 * Copyright 2013-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import org.mvel2.templates.CompiledTemplate;
import org.mvel2.templates.TemplateCompiler;
import org.mvel2.templates.TemplateRuntime;

import jp.co.kccs.greenearth.commons.utils.GCollectionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GConvertExpressionException;
import jp.co.kccs.greenearth.framework.jdbc.GFileExpression;
import jp.co.kccs.greenearth.framework.jdbc.GReplaceExpression;

/**
 * MVEL形式のファイルを文字列に変換する機能を提供するクラスです.
 * 
 * @author KCCS yamashita
 * @create 2012/12/05
 * @since 3.12.0
 * 
 */
public class GMVELFileExpressionConverter extends GReplaceExpressionConverterBase {

    /** エンコーディング */
	private String encoding = null;
    /** コンパイル済みテンプレートのキャッシュ */
	private Map<String, CompiledTemplate> templateCache = new ConcurrentHashMap<String, CompiledTemplate>();

    /**
     * {@link GMVELFileExpressionConverter}を初期化します.
     * 
     * @param encoding エンコーディング
     * @author KCCS yamashita
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GMVELFileExpressionConverter(String encoding) {
		this.setEncoding(encoding);
	}

	@Override
	protected String createSource(GReplaceExpression exp) {
		return parse((GFileExpression) exp);
	}

    /**
     * ファイルを解析し、ファイルに記述されている文字列を返します.
     * 
     * @param exp ファイルを表す式
     * @return ファイルに記述されている文字列
     * @author KCCS yamashita
     * @create 2012/12/05
     * @since 3.12.0
     */
	protected String parse(GFileExpression exp) {
		File file = exp.getFile();
		List<Map<String, Object>> mapParamsList = exp.getMapParamsList();
		Map<String, Object> vars = !GCollectionUtils.isEmpty(mapParamsList) ? mapParamsList.get(0) : null;
		String path = file.toURI().toString();
		if (!templateCache.containsKey(path)) {
			char[] chars = null;
			try {
				chars = GFileUtils.readCharArray(file, encoding);
			} catch (GResourceAccessException e) {
				throw new GConvertExpressionException("Template file read failed. path : " + path, e);
			}
			CompiledTemplate template = TemplateCompiler.compileTemplate(new String(chars).trim());
			templateCache.put(path, template);
		}
		CompiledTemplate compiled = templateCache.get(path);
		return GCollectionUtils.isEmpty(vars) ? (String) TemplateRuntime.execute(compiled) : (String) TemplateRuntime.execute(compiled, vars);
	}

    /**
     * エンコーディングを取得します.
     * 
     * @return エンコーディング
     * @author KCCS yamashita
     * @create 2012/12/05
     * @since 3.12.0
     */
	public String getEncoding() {
		return encoding;
	}

    /**
     * エンコーディングを設定します.
     * 
     * @param encoding エンコーディング
     * @author KCCS yamashita
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}
	
    /**
     * コンパイル済みテンプレートのキャッシュを全て削除します.
     * 
     * @author KCCS yamashita
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void clear() {
		if (templateCache != null) {
			templateCache.clear();
		}
	}
}
