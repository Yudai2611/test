/*
 * Copyright 2013-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.kccs.greenearth.commons.utils.GCollectionUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GReplaceExpression;
import jp.co.kccs.greenearth.framework.jdbc.GSelect;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntityQuery;
import jp.co.kccs.greenearth.framework.jdbc.entity.repository.GColumn;
import jp.co.kccs.greenearth.framework.jdbc.entity.sql.GSQLPartsGenerator;

/**
 * {@link GReplaceExpression}をSQL断片に変換する機能を提供する基底クラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 */
public abstract class GReplaceExpressionConverterBase implements GExpressionConverter {
	
	/** 文字列リテラルを抽出する正規表現 */
	private static final String REG_LITERAL = "('[^']*(('{2})*[^']*)*')";
	/** 文字列リテラルを抽出するパターン */
	private static final Pattern PTN_LITERAL = Pattern.compile(REG_LITERAL);
	/** カラムを抽出する正規表現 */
	private static final String REG_COL = "(#[a-zA-Z0-9_\\.\\$]+(?=[\\s\\)\\+\\-\\*\\/\\=\\<\\>\\,\\!]{1})|#[a-zA-Z0-9_\\.\\$]+(?=$))";
	/** カラムを抽出するパターン */
	private static final Pattern PTN_COL = Pattern.compile(REG_COL);
	/** 文字列リテラル置換の目印を抽出する正規表現 */
	private static final String REG_MARK = "%%%%[0-9]+";
	/** 文字列リテラル置換の目印を抽出するパターン */
	private static final Pattern PTN_MARK = Pattern.compile(REG_MARK);
	/** ()を抽出する正規表現 */
	private static final String REG_PARENTHESIS = "((\\$[a-zA-Z_]+)*\\([^\\(\\)]*\\))";
	/** ()を抽出するパターン */
	private static final Pattern PTN_PARENTHESIS = Pattern.compile(REG_PARENTHESIS);
	/** 仮想関数を抽出する正規表現 */
	private static final String REG_FUNC = "((?<=\\$)[a-zA-Z_]+(?=\\())";
	/** 仮想関数を抽出するパターン */
	private static final Pattern PTN_FUNC = Pattern.compile(REG_FUNC);
	/** バインドパラメータのプレースホルダを抽出する正規表現 */
	private static final String REG_BINDPARAM = "\\?";
	/** バインドパラメータのプレースホルダを抽出するパターン */
	private static final Pattern PTN_BINDPARAM = Pattern.compile(REG_BINDPARAM);
	/** パラメータ記号を抽出する正規表現 */
	private static final String REG_PARAM = "(:[a-zA-Z0-9_%]+(?=[\\s\\)\\+\\-\\*\\/\\=\\<\\>\\,\\!]{1})|:[a-zA-Z0-9_%]+(?=$))";
	/** パラメータ記号を抽出するパターン */
	private static final Pattern PTN_PARAM = Pattern.compile(REG_PARAM);
	/** サブクエリ記号を抽出する正規表現 */
	private static final String REG_SUBQUERY = ":\\{QUERY}";
	/** サブクエリ記号を抽出するパターン */
	private static final Pattern PTN_SUBQUERY = Pattern.compile(REG_SUBQUERY);
	/** スキーマ記号を抽出する正規表現 */
	private static final String REG_SCHEMA = ":\\{SCHEMA}";
	/** スキーマ記号を抽出するパターン */
	private static final Pattern PTN_SCHEMA = Pattern.compile(REG_SCHEMA);
	/** LIKEのワイルドカード % */
	private static final String PERCENT = "%";
	/** LIKEのワイルドカード _ */
	private static final String UNDERSCORE = "_";
	/** ワイルドカード の配列 */
	private static final String[] WILDCARDS = {PERCENT, UNDERSCORE};
	/** コメントを抽出する正規表現 */
	private static final String REG_COMMENT = "--.*?(\r\n|\n)|\\/\\*.*?\\*\\/";
	/** コメントを抽出するパターン */
	private static final Pattern PTN_COMMENT = Pattern.compile(REG_COMMENT, Pattern.DOTALL);
	
	/** {@link GSQLPartsGenerator}のインスタンス */
	private GSQLPartsGenerator sqlPartsGenerator = null;
	/** {@link GFunctionGenerator}のインスタンス */
	private GFunctionGenerator funcGenerator = null;
	
	/**
	 * {@link GReplaceExpressionConverterBase}を初期化します.
	 * 
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GReplaceExpressionConverterBase() {
	}
	
	/**
	 * {@link GSQLPartsGenerator}のインスタンスを設定します.
	 * 
	 * @param sqlPartsGenerator {@link GSQLPartsGenerator}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setSqlPartsGenerator(GSQLPartsGenerator sqlPartsGenerator) {
		this.sqlPartsGenerator = sqlPartsGenerator;
	}
	
	/**
	 * {@link GFunctionGenerator}のインスタンスを設定します.
	 * 
	 * @param funcGenerator {@link GFunctionGenerator}のインスタンス
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public void setFunctionGenerator(GFunctionGenerator funcGenerator) {
		this.funcGenerator = funcGenerator;
	}
	
	/**
	 * 式が表現している文字列を生成します.
	 * 
	 * @param exp 式
	 * @return 式が表現している文字列
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	protected abstract String createSource(GReplaceExpression exp);

	
	/**
	 * {@link GExpression}で表現された条件等からSQL断片を生成します.
	 * 
	 * @param query クエリ
	 * @param exp 式
	 * @return SQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GSQLPiece convertExpression(GQuery< ? > query, GExpression exp) {
		GReplaceExpression repexp = (GReplaceExpression) exp;
		String sql = createSource(repexp);
		
		//コメントを抽出し、"@@@数字@@"に置換
		Map<String, String> replacedComments = new HashMap<String, String>();
		sql = replaceString(sql, replacedComments, PTN_COMMENT.matcher(sql), "@");
		
		// 文字リテラルを抽出し、"%%%数字%%"に置換
		Map<String, String> replacedLiterals = new HashMap<String, String>();
		GSQLPiece piece = new GSQLPiece(replaceString(sql, replacedLiterals, PTN_LITERAL.matcher(sql), "%"));
		
		// 関数名を置換
		piece = replaceFunc(piece);

		// 項目名を置換 // TODO Entity依存
		if (query instanceof GEntityQuery<?>) {
			piece = replaceColumnName((GEntityQuery<?>) query, piece);
		}

		// バインドパラメータのマッピング
		piece = replaceBindParam(repexp, piece);

		// サブクエリを置換
		piece = replaceSubQuery(repexp.getSubQueryList(), piece);

		// スキーマ名を置換 
		piece = replaceSchema(query, piece);

		// 文字列リテラルを戻す
		String restoredSql = restoreString(piece.getSql(), replacedLiterals);

		// コメントを戻す
		restoredSql = restoreString(restoredSql, replacedComments);

		return new GSQLPiece(restoredSql, piece.getParameterList());
	}
	
	@Override
	public GSQLPiece convertBatchExpression(GQuery< ? > query, GExpression exp) {
		// TODO バッチの場合とシングルの場合で処理を分割する
		return convertExpression(query, exp);
	}
	
	/**
	 * 文字列リテラルを"%%%%"へ置換します.
	 * SQL断片にコメントを使用する場合は以下のメソッドを使用してください。<br/>
	 * {@link GReplaceExpressionConverterBase#replaceString(String, Map, Matcher, String)}<br/>
	 * {@link GReplaceExpressionConverterBase#restoreString(String, Map)}
	 * 
	 * @param sql SQL文
	 * @param escapeLiterals 置換された文字列リテラルを格納するリスト
	 * @return 文字列リテラルが置換されたSQL文
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	protected String escapeStringLiteral(String sql, List<String> escapeLiterals) {
		Matcher matcherLiteral = PTN_LITERAL.matcher(sql);
		int position = 0;
		StringBuilder replaceBuf = new StringBuilder();
		int index = 0;
		while (matcherLiteral.find()) {
			String before = sql.substring(position, matcherLiteral.start(0));
			replaceBuf.append(before).append("%%%%" + index++);
			escapeLiterals.add(matcherLiteral.group(0));
			position = matcherLiteral.end(0);
		}
		String after = sql.substring(position, sql.length());
		return replaceBuf.append(after).toString();
	}
	
	/**
	 * 文字列リテラルを"%%%%"で置換される以前の状態へ戻します.
	 * SQL断片にコメントを使用する場合は以下のメソッドを使用してください。<br/>
	 * {@link GReplaceExpressionConverterBase#replaceString(String, Map, Matcher, String)}<br/>
	 * {@link GReplaceExpressionConverterBase#restoreString(String, Map)}
	 * 
	 * @param piece SQL断片
	 * @param escapeLiterals 置換された文字列リテラルのリスト
	 * @return 文字列リテラルが置換される以前の状態へ戻されたSQL断片
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	protected String unescapeStringLiteral(GSQLPiece piece, List<String> escapeLiterals) {
		String replace = piece.getSql();
		Matcher matcherRep = PTN_MARK.matcher(replace);
		int position2 = 0;
		StringBuilder replaced = new StringBuilder();
		while (matcherRep.find()) {
			String before = replace.substring(position2, matcherRep.start(0));
			String mark = matcherRep.group(0);
			int num = Integer.parseInt(mark.replaceAll("%%%%", ""));
			replaced.append(before).append(escapeLiterals.get(num));
			position2 = matcherRep.end(0);
		}
		String after2 = replace.substring(position2, replace.length());
		replaced.append(after2);
		
		return replaced.toString();
	}
	
	/**
	 * パターンにマッチした文字列を置換します.
	 * 
	 * @param sql SQL文
	 * @param replacedStrings 置換されたコメントを格納するマップ
	 * @param matcherString 置換されたコメントを格納するマップ
	 * @param replaceChar 置換時に使用する文字
	 * @return コメントが置換されたSQL文
	 * @author mikazura
	 * @create 2017/03/09
	 * @since 3.19.2
	 */
	protected String replaceString (String sql, Map<String, String> replacedStrings, Matcher matcherString, String replaceChar) {
		// ﾊﾟﾀｰﾝにﾏｯﾁした文字列をﾌﾟﾚｰｽﾎﾙﾀﾞ文字列に置換する。（replaceChar="@"ならば、"@@@数字@@"に置換）
		// 複数ﾏｯﾁする場合は、"@@@0@@"、"@@@1@@"、と数字をｲﾝｸﾘﾒﾝﾄして置換する
		// 置換前の文字列はｷｬｯｼｭしておき、後処理で元に戻す（"@@@0@@"は「戻す場所」を示すﾌﾟﾚｰｽﾎﾙﾀﾞの役割を担う）
		// 元のsql文字列に"@@@数字@@"が含まれる場合、元に戻す処理が失敗する（同じﾌﾟﾚｰｽﾎﾙﾀﾞが複数になるため）
		// そのため、sql文字列に"@@@数字@@"という文字列が含まれるか調べ、含まれる場合は数字を抽出しておく
		// ﾌﾟﾚｰｽﾎﾙﾀﾞ文字列は、"@@@0@@"、"@@@1@@"と数字をｲﾝｸﾘﾒﾝﾄして生成するが、あらかじめ抽出した数字はｽｷｯﾌﾟすることで重複を防ぐ
		StringBuilder regBuilder = new StringBuilder();
		regBuilder.append(replaceChar);
		regBuilder.append("+[0-9]+|[0-9]+");
		regBuilder.append(replaceChar);
		regBuilder.append("+|");
		regBuilder.append(replaceChar);
		regBuilder.append("+[0-9]+");
		regBuilder.append(replaceChar);
		regBuilder.append("+");
		
		String reg = regBuilder.toString();
		Matcher matcherScope = Pattern.compile(reg, Pattern.DOTALL).matcher(sql);
		List<String> skipNumList = new ArrayList<String>();
		while (matcherScope.find()) {
			String group = matcherScope.group();
			skipNumList.add(group.replaceAll("[^0-9]", ""));
		}
		
		int position = 0;
		StringBuilder replaceBuf = new StringBuilder();
		int index = 0;
		while (matcherString.find()) {
			String before = sql.substring(position, matcherString.start(0));
			// 数字が重複する場合はｽｷｯﾌﾟして重複を防ぐ
			while (skipNumList.contains(String.valueOf(index))) {
				index++;
			}
			StringBuilder builder = new StringBuilder();
			builder.append(replaceChar);
			builder.append(replaceChar);
			builder.append(replaceChar);
			builder.append(index++);
			builder.append(replaceChar);
			builder.append(replaceChar);
			String replaceStr = builder.toString();
			
			replaceBuf.append(before).append(replaceStr);
			replacedStrings.put(replaceStr, matcherString.group(0));
			position = matcherString.end(0);
		}
		String after = sql.substring(position, sql.length());
		return replaceBuf.append(after).toString();
	}

	/**
	 * 文字列を置換される以前の状態へ戻します.
	 * 
	 * @param sql 置換対象の文字列
	 * @param escapeString 置換された文字列のマップ
	 * @return 文字列リテラルが置換される以前の状態へ戻された文字列
     * @author KCCS mikazura
     * @create 2017/03/09
     * @since 3.19.2
	 */
	protected String restoreString(String sql, Map<String, String> escapeString) {
		String replace = sql;
		for (String key : escapeString.keySet()) {
			replace = replace.replace(key, escapeString.get(key));
		}
		return replace;
	}

    /**
     * SQL断片内の仮想関数を関数に置換します.
     * 
     * @param piece 置換対象のSQL断片
     * @return 仮想関数置換後のSQL断片
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	protected GSQLPiece replaceFunc(GSQLPiece piece) {
		String reg = "%+[0-9]+|[0-9]+%+|%+[0-9]+%+";
		Matcher matcher = Pattern.compile(reg, Pattern.DOTALL).matcher(piece.getSql());
		List<String> skipNumList = new ArrayList<String>();
		while (matcher.find()) {
			String group = matcher.group();
			skipNumList.add(group.replaceAll("[^0-9]", ""));
		}
		
		// $関数スコープと()スコープの抽出
		Matcher matcherScope = PTN_PARENTHESIS.matcher(piece.getSql());
		Map<String, String> scopeMap = new LinkedHashMap<String, String>();
		String replaced = piece.getSql();
		int index = 0;
		while (matcherScope.find()) {
			String group = matcherScope.group();
			while (skipNumList.contains(String.valueOf(index))) {
				index++;
			}
			// 文字リテラルの置き換えに使用する%%%%(%4つ)と区別するために、%5つを利用する。
			String key = "%%%%%" + index++;
			scopeMap.put(key, group);
			replaced = matcherScope.replaceFirst(key);
			matcherScope.reset(replaced);
		}

		// スコープのうち、$関数のみ加工して戻す
		List<String> keyList = new ArrayList<String>(scopeMap.keySet());
		for (int i = keyList.size() - 1; i >= 0; i--) {
			String key = keyList.get(i);
			String scope = scopeMap.get(key);
			Matcher matcherFunc = PTN_FUNC.matcher(scope);
			if (matcherFunc.find()) {
				String funcName = matcherFunc.group();
				String argsStr = scope.substring(("$" + funcName + "(").length());
				argsStr = argsStr.substring(0, argsStr.length() - ")".length());
				String[] args = "".equals(argsStr) ? new String[] {} : argsStr.split(",");
				String function = funcGenerator.createFunction(funcName, args);
				scope = function == null ? scope : function;
			}

			replaced = replaced.replaceFirst(key, Matcher.quoteReplacement(scope));
		}
		return new GSQLPiece(replaced, piece.getParameter());
	}

    /**
     * SQL断片内の論理カラム名を物理カラム名に置換します.
     * 
     * @param query クエリ
     * @param piece 置換対象のSQL断片
     * @return カラム名置換後のSQL断片
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	protected GSQLPiece replaceColumnName(GEntityQuery<?> query, GSQLPiece piece) {
		String sql = piece.getSql();
		Matcher matcherCol = PTN_COL.matcher(sql);
		int position = 0;
		StringBuilder replaced = new StringBuilder();
		while (matcherCol.find()) {
			String matchStr = matcherCol.group(0);
			String before = sql.substring(position, matcherCol.start());
			replaced.append(before); // 項目が見つかるまでの文字列を追加
			String colName = matchStr.substring("#".length());
			
			String entityAlias = null;
			String[] splitColName = colName.split("\\.", 2);
			if (splitColName.length > 1) { // テーブル別名指定がある場合
				entityAlias = splitColName[0];
			}
			GColumn column = query.lookupColumn(colName);
			String columnFullName = sqlPartsGenerator.createColumnFullName(query, column, entityAlias);
			if (columnFullName != null) {
				replaced.append(columnFullName);
			} else {
				// 置換対象のカラムが定義されているEntity内に見つからなかった場合
				replaced.append(matchStr);
			}
			position = matcherCol.end();
		}
		String after = sql.substring(position, sql.length());
		replaced.append(after);
		return new GSQLPiece(replaced.toString(), piece.getParameter());
	}

    /**
     * SQL断片内のサブクリ記号（:{QUERY}）を指定されたサブクエリに置換します.
     * 
     * @param subQuery サブクエリ
     * @param piece 置換対象のSQL断片
     * @return 置換後のSQL断片
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	protected GSQLPiece replaceSubQuery(List<GSelect<?>> subQuery, GSQLPiece piece) {
		String sql = piece.getSql();
		Matcher matcherCol = PTN_SUBQUERY.matcher(sql);
		int position = 0;
		StringBuilder replaced = new StringBuilder();
		int subQueryCount = -1;
		List<List<GBindParam>> paramsList = new ArrayList<List<GBindParam>>();
		if (!GCollectionUtils.isEmpty(piece.getParameterList())) {
			for (int i = 0; i < piece.getParameterList().size(); i++) {
				paramsList.add(new ArrayList<GBindParam>());
			}
		}
		else {
			paramsList.add(new ArrayList<GBindParam>());
		}
		
		boolean match = false;
		int bindCount = -1;
		while (matcherCol.find()) {
			subQueryCount++;
			match = true;
			String before = sql.substring(position, matcherCol.start());
			replaced.append(before); // 項目が見つかるまでの文字列を追加
			GSelect<?> subSelect = subQuery.get(subQueryCount);
			bindCount = addBindParam(paramsList, bindCount, piece, before);
			// SQL自動生成実行の場合
			GSQLPiece subQueryPiece = subSelect.createSelectStatement();
			replaced.append("(");
			replaced.append(subQueryPiece.getSql());
			replaced.append(")");
			GBindParam[] subQueryParams = subQueryPiece.getParameter();
			if (subQueryParams != null && subQueryParams.length > 0) {
				for (List<GBindParam> list : paramsList) {
					list.addAll(Arrays.asList(subQueryParams));
				}
			}
			position = matcherCol.end();
		}
		String after = sql.substring(position, sql.length());
		if (after.length() > 0) {
			addBindParam(paramsList, bindCount, piece, after);
		}
		replaced.append(after);
		
		// バインドパラメータを積める
		GSQLPiece returnPiece = new GSQLPiece(replaced.toString());
		if (match) {
			for (List<GBindParam> list : paramsList) {
				returnPiece.addParameter((GBindParam[]) list.toArray(new GBindParam[list.size()]));
			}
		}
		else {
			returnPiece.setParameter(piece.getParameterList());
		}
		return returnPiece;
	}

    /**
     * バインドパラメータのリストのリストに新しい要素を追加します.
     * 
     * @param bindParamsList バインドパラメータのリストのリスト
     * @param index 新しく追加する要素のインデックス
     * @param piece 新しく追加する要素を保持するSQL断片
     * @param str SQL文
     * @return 新しく追加された要素のインデックス
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	private int addBindParam(List<List<GBindParam>> bindParamsList, int index, GSQLPiece piece, String str) {
		List<GBindParam[]> parameterList = piece.getParameterList();
		if (GCollectionUtils.isEmpty(parameterList)) {
			return index;
		}
		Matcher matcherParam = PTN_BINDPARAM.matcher(str);
		while (matcherParam.find()) {
			index++;
			for (int i = 0; i < bindParamsList.size(); i++) {
				bindParamsList.get(i).add(parameterList.get(i)[index]);
			}
		}
		return index;
	}

	/**
	 * 配列が多次元配列であるかどうかを判定します.
	 * 
	 * @param arrays 対象の配列
	 * @return 配列が多次元配列であれば<code>true</code>、一次元配列であれば<code>false</code>
	 * @create 2012/12/11
	 * @author KCCS K.Fujita
	 * @since 3.12.0
	 */
	private boolean isMultiDimensionalArray(List<Object[]> arrays) {
		if (GCollectionUtils.isEmpty(arrays)) {
			return false;
		}
		
		for (Object obj : arrays.get(0)) {
			if (obj instanceof Object[]) {
				return true;
			}
		}
		return false;
	}
	
    /**
     * SQL断片の各バインドパラメータを置換します.
     * 
     * @param exp 式
     * @param piece 置換元となるSQL断片
     * @return 各バインドパラメータ置換後のSQL断片
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	protected GSQLPiece replaceBindParam(GReplaceExpression exp, GSQLPiece piece) {
		/* バインドパラメータの指定に配列を使用する場合 */
		if (exp.getArrayParamsList() != null) {
			return replaceArrayBindParam(exp.getArrayParamsList(), piece);
		}
		/* バインドパラメータの指定にマップを使用する場合 */
		else if (exp.getMapParamsList() != null) {
			return replaceMapBindParam(exp.getMapParamsList(), piece);
		}
		else {
			return new GSQLPiece(piece.getSql());
		}
	}
	
	/**
	 * バインドパラメータの値に従い、SQL断片の保持するSQLやバインドパラメータを置換します.
	 * 
	 * @param paramArrays バインドパラメータ（配列）
	 * @param piece 置換対象のSQL断片
	 * @return 置換後のSQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	protected GSQLPiece replaceArrayBindParam(List<Object[]> paramArrays, GSQLPiece piece) {
		String sql = piece.getSql();

		// バインドパラメータが2次元配列になっていなければ置換処理は行わない
		if (!isMultiDimensionalArray(paramArrays)) {
			return new GSQLPiece(sql, GBindParam.toBindParamsList(paramArrays));
		}
		
		Matcher matcherParam = PTN_BINDPARAM.matcher(sql);
		int position = 0;
		int index = 0;
		StringBuilder replaced = new StringBuilder();
		Object[] paramZero = paramArrays.get(0); // 最初の要素でSQLを組み立てる
		while (matcherParam.find()) {
			String before = sql.substring(position, matcherParam.start() + 1);
			replaced.append(before); // 項目が見つかるまでの文字列を追加
			
			// 引数として配列が渡されていたら、"?"を配列の要素数と同じまで増やす
			if (paramZero[index] instanceof Object[]) {
				for (int i = 0; i < ((Object[]) paramZero[index]).length - 1; i++) {
					replaced.append(",?");
				}
			}
			position = matcherParam.end();
			index++;
		}
		String after = sql.substring(position, sql.length());
		replaced.append(after);
		
		GSQLPiece returnPiece = new GSQLPiece(replaced.toString());
		
		// 2次元配列を1次元配列に直す
		for (Object[] params : paramArrays) {
			List<Object> replacedParamList = new ArrayList<Object>();
			for (int i = 0; i < params.length; i++) {
				if (params[i] instanceof Object[]) {
					Object[] array = (Object[]) params[i];
					for (int j = 0; j < array.length; j++) {
						replacedParamList.add(array[j]);
					}
				} else {
					replacedParamList.add(params[i]);
				}
			}
			returnPiece.addParameter(GBindParam.toBindParams(replacedParamList.toArray(new Object[0])));
		}
		
		return returnPiece;
	}

	/**
	 * バインドパラメータの値に従い、SQL断片の保持するSQLやバインドパラメータを置換します.
	 * 
	 * @param paramMaps バインドパラメータ（マップ）
	 * @param piece 置換対象のSQL断片
	 * @return バインドパラメータ置換後のSQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	protected GSQLPiece replaceMapBindParam(List<Map<String, Object>> paramMaps, GSQLPiece piece) {
		String sql = piece.getSql();
		if (GCollectionUtils.isEmpty(paramMaps)) {
			return new GSQLPiece(sql); 
		}
		
		// バインド変数の作成
		Matcher matcherParam = PTN_PARAM.matcher(sql);
		int position = 0;
		StringBuilder replaced = new StringBuilder();
		List<List<GBindParam>> paramsList = new ArrayList<List<GBindParam>>();
		for (int i = 0; i < paramMaps.size(); i++) {
			paramsList.add(new ArrayList<GBindParam>());
		}
		while (matcherParam.find()) {
			String matchStr = matcherParam.group(0);
			String paramName = matchStr.substring(":".length());
			
			String before = sql.substring(position, matcherParam.start());
			replaced.append(before); // 項目が見つかるまでの文字列を追加
			replaced.append(editQuestion(paramName, paramMaps));
			
			editParams(paramName, paramMaps, paramsList, replaced);
			
			position = matcherParam.end();
		}
		String after = sql.substring(position, sql.length());
		replaced.append(after);
		
		// バインドパラメータを積める
		GSQLPiece returnPiece = new GSQLPiece(replaced.toString());
		for (List<GBindParam> list : paramsList) {
			returnPiece.addParameter((GBindParam[]) list.toArray(new GBindParam[list.size()]));
		}
		return returnPiece;
	}
	
	/**
	 * LIKE節のワイルドカード文字をエスケープします.
	 * 
	 * @param value - エスケープ処理の対象文字列
	 * @return エスケープされた後の文字列
	 * @create 2012/11/28
	 * @author KCCS kitamura
	 * @since 3.12.0
	 */
	protected String escapeLike(String value) {
		value = value.replaceAll("/", "//");
		value = value.replaceAll(PERCENT, "/%");
		value = value.replaceAll(UNDERSCORE, "/_");
		return value;
	}
	
	/**
	 * SQL断片内のスキーマ記号（:{SCHEMA}）を指定されたクエリが参照するスキーマ名に置換します.
	 * 
	 * @param query クエリ
	 * @param piece 置換対象のSQL断片
	 * @return GSQLPiece スキーマ名置換後のSQL断片
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	protected GSQLPiece replaceSchema(GQuery<?> query, GSQLPiece piece) {
		String schema = query.getDatabase().getSchema();
		
		String sql = piece.getSql();
		Matcher matcherCol = PTN_SCHEMA.matcher(sql);
		int position = 0;
		StringBuilder replaced = new StringBuilder();
		
		while (matcherCol.find()) {
			String before = sql.substring(position, matcherCol.start());
			replaced.append(before); // 項目が見つかるまでの文字列を追加
			replaced.append(schema);
			position = matcherCol.end();
		}
		
		String after = sql.substring(position, sql.length());
		replaced.append(after);
		
		// バインドパラメータを積める
		GSQLPiece returnPiece = new GSQLPiece(replaced.toString());
		returnPiece.setParameter(piece.getParameterList());
		
		return returnPiece;
	}

	/**
	 * バインド先を表す?の文字列を編集します.
	 * 
	 * @param paramName - バインド先名
	 * @param paramMaps - バインドパラメータを保持するマップのリスト
	 * @return バインド先を表す?の文字列
	 * @create 2016/3/23
	 * @author hashimoto
	 * @since 3.17.1
	 */
	protected String editQuestion(String paramName, List<Map<String, Object>> paramMaps) {
		// 要素が配列の場合
		Map<String, Object> paramMapZero = paramMaps.get(0);
		if (paramMapZero.get(paramName) instanceof Object[]) {
			StringBuilder questions = new StringBuilder();
			Object[] parameters = (Object[]) paramMapZero.get(paramName);
			for (int i = 0; i < parameters.length; i++) {
				questions.append(",?");
			}
			questions.delete(0, 1);
			return questions.toString();
		}
		// 要素が配列でない場合
		return "?";
	}

	/**
	 * バインドパラメータを編集します.
	 * 
	 * @param paramName - バインド先名
	 * @param paramMaps - バインドパラメータを保持するマップのリスト
	 * @param paramsList - マップから詰替えたバインドパラメータのリスト
	 * @param replaced - SQL文字列
	 * @create 2016/3/23
	 * @author hashimoto
	 * @since 3.17.1
	 */
	protected void editParams(String paramName, List<Map<String, Object>> paramMaps, List<List<GBindParam>> paramsList, StringBuilder replaced) {
		if ((paramName.charAt(0) == (UNDERSCORE.charAt(0)) || 
				paramName.charAt(paramName.length() - 1) == (UNDERSCORE.charAt(0)))
				|| (paramName.charAt(0) == (PERCENT.charAt(0)) || paramName
						.charAt(paramName.length() - 1) == (PERCENT.charAt(0)))) {
			editLikeSQL(paramName, paramMaps, paramsList, replaced);
			return;
		}
		
		// バインド変数の加工
		for (int index = 0; index < paramMaps.size(); index++) {
			Map<String, Object> paramMap = paramMaps.get(index);
			Object param = paramMap.get(paramName);
			if (param == null) {
				throw new IllegalArgumentException("This bind parameter[" + paramName + "] does not exist. ");
			}

			if (param instanceof Object[]) { // パラメータが配列の場合
				Object[] parameters = (Object[]) param;
				for (int i = 0; i < parameters.length; i++) {
					paramsList.get(index).add(GBindParam.create(parameters[i]));
				}
			} else { // パラメータが配列でない場合
				paramsList.get(index).add(GBindParam.create(param));
			}
		}
	}

	/**
	 * LIKE条件のSQLとバインドパラメータを編集します.
	 * 
	 * @param paramName - バインド先名
	 * @param paramMaps - バインドパラメータを保持するマップのリスト
	 * @param paramsList - マップから詰替えたバインドパラメータのリスト
	 * @param replaced - SQL文字列
	 * @create 2016/3/23
	 * @author hashimoto
	 * @since 3.17.1
	 */
	protected void editLikeSQL(String paramName, List<Map<String, Object>> paramMaps, List<List<GBindParam>> paramsList, StringBuilder replaced) {
		String keyOfMap = removeWildcard(paramName);
		boolean needEscape = false;
		// バインド変数の加工
		for (int index = 0; index < paramMaps.size(); index++) {
			Map<String, Object> paramMap = paramMaps.get(index);
			Object p = paramMap.get(keyOfMap);
			GBindParam param = null;
			String likeValue = null;
			Object value =  null;
			
			if (p instanceof GBindParam) {
				param = (GBindParam) p;
				//注 ここで扱う値は{@link GBindParamConverter}で変換しません（制限事項です）
				value = param.getValue();
			} else {
				value = paramMap.get(keyOfMap);
			}

			if (value == null) {
				throw new IllegalArgumentException("This column does not exist. :" + paramName);
			}
			likeValue = value.toString();
			
			// パラメータの加工
			if (likeValue.contains(UNDERSCORE) || likeValue.contains(PERCENT)) {
				needEscape = true;
				likeValue = escapeLike(likeValue); // エスケープ
			}
			
			for (String wildcard : WILDCARDS) {
				char wildcardChar = wildcard.charAt(0);
				if (paramName.charAt(0) == wildcardChar) {
					likeValue = wildcardChar + likeValue;
				}
				if (paramName.charAt(paramName.length() - 1) == wildcardChar) {
					likeValue = likeValue + wildcardChar;
				}
			}
			
			if (param != null) {
				param.setValue(likeValue);
			} else {
				param = GBindParam.create(likeValue);
			}
			paramsList.get(index).add(param);
		}

		if (needEscape) {
			// SQLの加工
			replaced.append(" ESCAPE '/'");
		}
	}

	/**
	 * マップに引き当てるためのキーを生成するため、バインド先名から前後のワイルドカードを除去します.
	 * 
	 * @param paramName - バインド先名
	 * @return バインド先名から前後のワイルドカードを除去した文字列
	 * @create 2016/5/19
	 * @author hashimoto
	 * @since 3.18.0
	 */
	protected String removeWildcard(String paramName) {
		if (GStringUtils.isNullOrEmpty(paramName)) {
			return paramName;
		}
		
		StringBuilder edit = new StringBuilder(paramName);
		removeFirst(edit);
		removeLast(edit);
		return edit.toString();
	}
	
	/**
	 * バインド先名から先頭のワイルドカードを除去します.
	 * 
	 * @param paramName - バインド先名
	 * @create 2016/5/19
	 * @author hashimoto
	 * @since 3.18.0
	 */
	protected void removeFirst(StringBuilder paramName) {
		remove(paramName, 0);
	}
	
	/**
	 * バインド先名から末尾のワイルドカードを除去します.
	 * 
	 * @param paramName - バインド先名
	 * @create 2016/5/19
	 * @author hashimoto
	 * @since 3.18.0
	 */
	protected void removeLast(StringBuilder paramName) {
		remove(paramName, paramName.length() - 1);
	}
	
	
	/**
	 * バインド先名から指定されたインデックスのワイルドカードを除去します.
	 * 
	 * @param paramName - バインド先名
	 * @param index - インデックス
	 * @create 2016/5/19
	 * @author hashimoto
	 * @since 3.18.0
	 */
	protected void remove(StringBuilder paramName, int index) {
		if (paramName == null) {
			return;
		}
		for (String wildcard : WILDCARDS) {
			if (paramName.charAt(index) == wildcard.charAt(0)) {
				paramName.deleteCharAt(index);
				break;
			}
		}
	}
}
