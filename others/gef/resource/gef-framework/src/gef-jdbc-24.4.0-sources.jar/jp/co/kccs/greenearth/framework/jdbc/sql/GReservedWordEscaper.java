/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * 予約語をエスケープするインタフェースです。
 * 
 * @author KCCS kitamura
 * @create 2012/12/17
 * @since 3.12.0
 */
public interface GReservedWordEscaper {

	/**
	 * 予約語をエスケープします。
	 * 
	 * @param word 処理対象文字列
	 * @return 予約語をエスケープした文字列
	 * @author KCCS kitamura
	 * @create 2012/12/17
	 * @since 3.12.0
	 */
	String escapeReservedWord(String word);
}
