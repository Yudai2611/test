/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * {@link GReservedWordEscaper}をMySQL用に実装する基底クラスです.
 *
 * @author KCCS hashimoto
 * @create 2016/05/11
 * @since 3.18.0
 */
public abstract class GReservedWordEscaperMySQLBase implements GReservedWordEscaper {

	/** MySQLにおける引用符 */
	private static final char QUOTE_MARK = '`';
	/** 予約語を保持するセット */
	private Set<String> reservedWordsSet;

	/**
	 * {@link GReservedWordEscaperMySQLBase}のインスタンスを生成します.
	 * 
	 * @param reservedWords 予約語
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	public GReservedWordEscaperMySQLBase(String[] reservedWords) {
		reservedWordsSet = new HashSet<String>(Arrays.asList(reservedWords));
	}

	/**
	 * 予約語をエスケープします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.jdbc.sql.GReservedWordEscaper#escapeReservedWord(java.lang.String)
	 * @param word 文字列
	 * @return 予約語をエスケープした文字列
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	@Override
	public String escapeReservedWord(String word) {
		if (reservedWordsSet.contains(word.toUpperCase(Locale.ENGLISH))) {
			return QUOTE_MARK + word + QUOTE_MARK;
		} else {
			return word;
		}
	}
}
