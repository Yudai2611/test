/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * {@link GReservedWordEscaper}をOracle用に実装する基底クラスです.
 *
 * @author KCCS Hashimoto
 * @create 2016/08/30
 * @since 3.19.0
 */
public abstract class GReservedWordEscaperOracleBase implements GReservedWordEscaper {

	/** Oracleにおける引用符 */
	private static final char QUOTE_MARK = '\"';
	/** 予約語を保持するセット */
	private Set<String> reservedWordsSet;

	/**
	 * {@link GReservedWordEscaperOracleBase}のインスタンスを生成します.
	 * 
	 * @param reservedWords 予約語
	 * @author KCCS Hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public GReservedWordEscaperOracleBase(String[] reservedWords) {
		reservedWordsSet = new HashSet<String>(Arrays.asList(reservedWords));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String escapeReservedWord(String word) {
		if (reservedWordsSet.contains(word.toUpperCase(Locale.ENGLISH))) {
			return QUOTE_MARK + word + QUOTE_MARK;
		} else {
			return word;
		}
	}
}
