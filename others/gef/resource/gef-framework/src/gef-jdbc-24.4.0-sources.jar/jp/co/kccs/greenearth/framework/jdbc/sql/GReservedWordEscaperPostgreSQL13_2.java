/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * PostgreSQL13.2用に予約語をエスケープする機能を提供するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GReservedWordEscaperPostgreSQL13_2 extends GReservedWordEscaperPostgreSQLBase {

	/** PostgreSQL13.2における予約語 */
	private static final String[] RESERVED_WORDS;

	static{
		RESERVED_WORDS = new String[]{"ALL", "ANALYSE", "ANALYZE", "AND", "ANY", "ARRAY", "AS", "ASC", "ASYMMETRIC",
				"AUTHORIZATION", "BINARY", "BOTH", "CASE", "CAST", "CHECK", "COLLATE", "COLLATION", "COLUMN",
				"CONCURRENTLY", "CONSTRAINT", "CREATE", "CROSS", "CURRENT_CATALOG", "CURRENT_DATE", "CURRENT_ROLE",
				"CURRENT_SCHEMA", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "DEFAULT", "DEFERRABLE", "DESC",
				"DISTINCT", "DO", "ELSE", "END", "EXCEPT", "FALSE", "FETCH", "FOR", "FOREIGN", "FREEZE", "FROM", "FULL",
				"GRANT", "GROUP", "HAVING", "ILIKE", "IN", "INITIALLY", "INNER", "INTERSECT", "INTO", "IS", "ISNULL",
				"JOIN", "LATERAL", "LEADING", "LEFT", "LIKE", "LIMIT", "LOCALTIME", "LOCALTIMESTAMP", "NATURAL", "NOT",
				"NOTNULL", "NULL", "OFFSET", "ON", "ONLY", "OR", "ORDER", "OUTER", "OVERLAPS", "PLACING", "PRIMARY",
				"REFERENCES", "RETURNING", "RIGHT", "SELECT", "SESSION_USER", "SIMILAR", "SOME", "SYMMETRIC", "TABLE",
				"TABLESAMPLE", "THEN", "TO", "TRAILING", "TRUE", "UNION", "UNIQUE", "USER", "USING", "VARIADIC",
				"VERBOSE", "WHEN", "WHERE", "WINDOW", "WITH"
		};
	}

	/**
	 * {@link GReservedWordEscaperPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GReservedWordEscaperPostgreSQL13_2(){
		super(RESERVED_WORDS);
	}
}
