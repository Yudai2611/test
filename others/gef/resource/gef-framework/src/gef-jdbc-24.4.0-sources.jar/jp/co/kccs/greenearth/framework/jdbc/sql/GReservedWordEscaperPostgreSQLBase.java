/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * {@link GReservedWordEscaper}をPostgreSQL用に実装する基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GReservedWordEscaperPostgreSQLBase implements GReservedWordEscaper {

	/** PostgreSQLにおける引用符 */
	private static char QUOTE_MARK = '\"';
	/** 予約語を保持するセット */
	private Set<String> reservedWordsSet;

	/**
	 * {@link GReservedWordEscaperPostgreSQLBase}のインスタンスを生成します.
	 *
	 * @param reservedWords 予約語
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GReservedWordEscaperPostgreSQLBase(String[] reservedWords){
		this.reservedWordsSet = new HashSet<>(Arrays.asList(reservedWords));
	}

	@Override
	public String escapeReservedWord(String word) {

		if (reservedWordsSet.contains(word.toUpperCase(Locale.ENGLISH))){
			return QUOTE_MARK + word + QUOTE_MARK;
		}
		return word;
	}
}
