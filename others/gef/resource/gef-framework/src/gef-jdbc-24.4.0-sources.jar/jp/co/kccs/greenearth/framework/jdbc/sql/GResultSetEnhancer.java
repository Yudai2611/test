/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;

/**
 * 結果セットをクローズすると結果セット、ステートメント、コネクションを連動してクローズする機能を提供するクラスです.
 * 
 * @author KCCS hashimoto
 * @create 2012/12/09
 * @since 3.12.0
 */
public class GResultSetEnhancer implements InvocationHandler {

	/** 結果セット */
	private ResultSet resultset = null;
	/** コネクション */
	private Connection connection = null;

	/**
	 * GResultSetEnhancerのインスタンスを生成します.
	 * 
	 * @param resultset 結果セット
	 * @param connection コネクション
	 * @author KCCS hashimoto
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public GResultSetEnhancer(ResultSet resultset, Connection connection) {
		this.resultset = resultset;
		this.connection = connection;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if ("close".equals(method.getName())) {
			close();
			return null;
		} else {
			
			try {
				return method.invoke(resultset, args);
			}
			catch (InvocationTargetException e) {
				throw e.getTargetException();
			}
		}
	}

	/**
	 * ResultSet、Statement、Connectionをcloseします.
	 * 
	 * @throws SQLException close実行時の例外
	 * @author KCCS hashimoto
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public void close() throws SQLException {

		if (this.resultset == null) {
			return;
		}

		Statement statement = null;
		try {
			statement = resultset.getStatement();
		} finally {
			try {
				resultset.close();
			} finally {
				if (statement != null) {
					try {
						statement.close();
					} finally {
						if (connection != null) {
							GJdbcConnectionManager dataSource = GJdbcConnectionManagerFactory.getInstance();
							dataSource.close(connection);
						}
					}
				}
			}
		}
	}
}
