/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;

/**
 * 結果セットから取り出した値をどのような形式で加工するかを振り分けるインタフェースです。
 * 
 * @author KCCS kitamura
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GResultSetHandler {

	/**
	 * 結果セットから{@link GRecord}を作成します。
	 * 
	 * @param query クエリーを構成する要素
	 * @param resultSet 結果セット
	 * @return 結果セットから作成した{@link GRecord}
	 * @throws SQLException {@link GRecord}作成時の例外
	 * @author KCCS hashimoto
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	GRecord createRecord(GQuery<?> query, ResultSet resultSet) throws SQLException;

	/**
	 * 結果セットから{@link GRecord}のリストを作成します。
	 * 
	 * @param query クエリーを構成する要素
	 * @param resultSet 結果セット
	 * @param startRowIndex リストの作成を開始する結果セットの行数
	 * @param listSize 作成するリストのサイズ（取得する結果セットの行数）
	 * @return 結果セットから作成した{@link GRecord}のリスト
	 * @throws SQLException {@link GRecord}のリスト作成時の例外
	 * @author KCCS fujtia
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	List<GRecord> createRecordList(GQuery<?> query, ResultSet resultSet, int startRowIndex, int listSize) throws SQLException;
	
	/**
	 * 結果セットから{@link GRecord}のリストを作成します。
	 * 
	 * @param query クエリーを構成する要素
	 * @param resultSet 結果セット
	 * @return 結果セットから作成した{@link GRecord}のリスト
	 * @throws SQLException {@link GRecord}のリスト作成時の例外
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	List<GRecord> createRecordList(GQuery<?> query, ResultSet resultSet) throws SQLException;

	/**
	 * 結果セットから{@link GRecordSet}を作成し取得する。
	 * 
	 * @param query クエリーを構成する要素
	 * @param resultSet 結果セット
	 * @return 結果セットから作成した{@link GRecordSet}
	 * @throws SQLException {@link GRecordSet}作成時の例外
	 * @author KCCS hashimoto
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	GRecordSet createRecordSet(GQuery<?> query, ResultSet resultSet) throws SQLException;
}
