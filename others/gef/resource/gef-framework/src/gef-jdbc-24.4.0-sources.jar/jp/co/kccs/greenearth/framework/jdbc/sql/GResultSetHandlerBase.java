/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.GQuery;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSet;
import jp.co.kccs.greenearth.framework.jdbc.GRecordSetImpl;

/**
 * {@link GResultSetHandler}を実装する基底クラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/11/8
 * @since 3.12.0
 */
public abstract class GResultSetHandlerBase implements GResultSetHandler {

	/** {@link GSQLTypeHandler}のインスタンス */
	private GSQLTypeHandler typeHandler = null;

	/**
	 * クラスフィールドに設定されている{@link GSQLTypeHandler}のインスタンスを取得します.
	 * 
	 * @return クラスフィールドに設定されている{@link GSQLTypeHandler}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public GSQLTypeHandler getTypeHandler() {
		return typeHandler;
	}

	/**
	 * クラスフィールドに{@link GSQLTypeHandler}のインスタンスを設定します.
	 * 
	 * @param handler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public void setTypeHandler(GSQLTypeHandler handler) {
		this.typeHandler = handler;
	}

	@Override
	public GRecordSet createRecordSet(GQuery<?> query, ResultSet resultSet) throws SQLException {
		return new GRecordSetImpl(query, this, resultSet);
	}
	
	/**
	 * 結果セットから{@link GRecord}のリストを作成する.
	 * 
	 * 取得レンジに基づいて、結果セットのレコード件数分のリストを作成する。<br>
	 * クエリ発行時に取得レンジを考慮せず検索しているため。<br>
	 * 引数のResultSetがNullの場合は、Nullを返す。<br>
	 * 検索結果が0件の場合は、空のリストを返す。<br>
	 * 
	 * @param query クエリ
	 * @param resultSet 結果セット
	 * @param startRowIndex リストの作成を開始する結果セットの行数
	 * @param listSize 作成するリストのサイズ（取得する結果セットの行数）
	 * @return 結果セットから作成した{@link GRecord}のリスト
	 * @throws SQLException {@link GRecord}のリスト作成時の例外
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	public List<GRecord> createRecordList(GQuery<?> query, ResultSet resultSet, int startRowIndex, int listSize) throws SQLException {
		if (resultSet == null) {
			return null;
		}
		List<GRecord> list = new ArrayList<GRecord>();
		int currentIndex = 0;
		while (resultSet.next() && (list.size() < listSize || listSize == -1)) {
			if (startRowIndex <= currentIndex) {
				list.add(createRecord(query, resultSet));
			}
			currentIndex++;
		}
		return list;
	}
	/**
	 * 結果セットから{@link GRecord}のリストを作成する.
	 * 
	 * 取得レンジは考慮せず、結果セットのレコード件数分のリストを作成する。<br>
	 * クエリ発行時に取得レンジを考慮して検索しているため。<br>
	 * 引数のResultSetがNullの場合は、Nullを返す。<br>
	 * 検索結果が0件の場合は、空のリストを返す。<br>
	 * 
	 * @param query クエリ
	 * @param resultSet 結果セット
	 * @return 結果セットから作成した{@link GRecord}のリスト
	 * @throws SQLException {@link GRecord}のリスト作成時の例外
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	@Override
	public List<GRecord> createRecordList(GQuery<?> query, ResultSet resultSet) throws SQLException {
		if (resultSet == null) {
			return null;
		}
		List<GRecord> list = new ArrayList<GRecord>();
		while (resultSet.next()) {
			list.add(createRecord(query, resultSet));
		}
		return list;
	}
}
