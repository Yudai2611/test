/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GExpression;
import jp.co.kccs.greenearth.framework.jdbc.GQuery;

/**
 * SQL式生成処理を{@link GExpression}の型にあった適切な{@link GExpressionConverter}にルーティングする{@link GExpressionConverter}実装です。
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 * 
 */
public class GRoutingExpressionConverter implements GExpressionConverter {

    /** ルーティング制御テーブル */
	private Map<String, GExpressionConverter> converters;


    /**
     * ルーティング制御テーブルを指定して、{@link GRoutingExpressionConverter}を初期化します.
     * 
     * @param converters ルーティング制御テーブル
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GRoutingExpressionConverter(Map<String, GExpressionConverter> converters) {
		this.converters = converters;
	}

	/**
	 * 指定された{@link GExpression}のConverterを取得します.
	 * 
	 * @param exp Converterを取得する{@link GExpression}
	 * @return 指定された{@link GExpression}のConverter
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GExpressionConverter get(GExpression exp) {
		String key = exp.getClass().getName();
		return converters.containsKey(key) ? converters.get(key) : null;
	}

	@Override
	public GSQLPiece convertExpression(GQuery< ? > query, GExpression exp) {
		return get(exp).convertExpression(query, exp);
	}

	@Override
	public GSQLPiece convertBatchExpression(GQuery< ? > query, GExpression exp) {
		return get(exp).convertBatchExpression(query, exp);
	}
}
