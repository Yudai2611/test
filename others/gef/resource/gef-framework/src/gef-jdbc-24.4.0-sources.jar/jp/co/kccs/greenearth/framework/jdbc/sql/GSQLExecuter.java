package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;

/**
 * 構築したSQLを実行するインタフェースです。
 *
 * @author KCCS kitamura
 * @create 2012/11/08
 * @since 3.12.0
 */
public interface GSQLExecuter {

	/**
	  * 検索系SQLを実行します。
	  * 
	  * @param connection コネクション
	  * @param piece SQL断片
	  * @param timeoutSeconds タイムアウト時間
	  * @return 結果セット
	  * @throws SQLException SQL実行時の例外
	  * @author KCCS hashimoto
	  * @create 2012/11/08
	  * @since 3.12.0
	  */
	ResultSet executeQuery(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException;

	/**
	  * 更新系SQLを実行します。
	  * <p>
	  * 更新系SQLとは登録、更新、削除のSQLです。
	  * 
	  * @param connection コネクション
	  * @param piece SQL断片
	  * @param timeoutSeconds タイムアウト時間（秒）
	  * @return 更新件数
	  * @throws SQLException SQL実行時の例外
	  * @author KCCS hashimoto
	  * @create 2012/11/08
	  * @since 3.12.0
	  */
	int executeUpdate(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException;

	/**
	  * 検索結果件数取得SQLを実行します。
	  * 
	  * @param connection コネクション
	  * @param piece SQL断片
	  * @param timeoutSeconds タイムアウト時間（秒）
	  * @return 検索結果件数
	  * @throws SQLException SQL実行時の例外
	  * @author KCCS hashimoto
	  * @create 2012/11/08
	  * @since 3.12.0
	  */
	int executeCount(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException;

	/**
	  * 更新系SQLを一括実行します。
	  * <p>
	  * 更新系SQLとは登録、更新、削除のSQLです。
	  * 
	  * @param connection コネクション
	  * @param piece SQL断片
	  * @param timeoutSeconds タイムアウト時間（秒）
	  * @param batchSize 一括更新のサイズ
	  * @return トータル更新件数
	  * @throws SQLException SQL実行時の例外
	  * @author KCCS hashimoto
	  * @create 2012/11/08
	  * @since 3.12.0
	  */
	int executeBatchUpdate(Connection connection, GSQLPiece piece, int timeoutSeconds, int batchSize) throws SQLException;
	
	/**
	 * SQLを実行します。
	 * <p>
	 * 実行するSQLが検索系か更新系か分からない場合に利用します。
	 * 
	 * @param connection コネクション
	 * @param piece SQL断片
	 * @param timeoutSeconds タイムアウト時間
	 * @return 実行結果
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS K.Fujita
	 * @create 2012/02/01
	 * @since 3.12.0
	 */
	GQueryResult execute(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException;
	
	
	/**
	  * ストアドプロシージャ／ストアドファンクションを実行します。
	  * 
	  * @param connection コネクション
	  * @param piece SQL断片
	  * @param timeoutSeconds タイムアウト時間（秒）
	  * @return 更新された行数
	  * @throws SQLException SQL実行時の例外
	  * @author KCCS K.Fujita
	  * @create 2012/12/25
	  * @since 3.12.0
	  */
	int callUpdate(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException;
	
	/**
	  *  ストアドプロシージャ／ストアドファンクションを実行します。
	  * 
	  * @param <T> T 戻り値の型
	  * @param connection コネクション
	  * @param piece SQL断片
	  * @param returnType 戻り値の型
	  * @param timeoutSeconds タイムアウト時間（秒）
	  * @return 指定された型の戻り値
	  * @throws SQLException SQL実行時の例外
	  * @author KCCS K.Fujita
	  * @create 2012/12/25
	  * @since 3.12.0
	  */
	<T> T callData(Connection connection, GSQLPiece piece, GColumnType returnType, int timeoutSeconds) throws SQLException;
	
	/**
	  * ストアドプロシージャ／ストアドファンクションを実行します。
	  * 
	  * @param connection コネクション
	  * @param piece SQL断片
	  * @param timeoutSeconds タイムアウト時間（秒）
	  * @return 結果セット
	  * @throws SQLException SQL実行時の例外
	  * @author KCCS K.Fujita
	  * @create 2012/12/25
	  * @since 3.12.0
	  */
	ResultSet callQuery(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException;
	
	/**
	 * ストアドプロシージャ／ストアドファンクションを実行します。
	 * 
	 * @param connection コネクション
	 * @param piece SQL断片
	 * @param timeoutSeconds タイムアウト時間
	 * @return クエリの実行結果
	 * @throws SQLException SQL実行時の例外
	 * @author KCCS K.Fujita
	 * @create 2013/01/25
	 * @since 3.12.0
	 */
	GQueryResult call(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException;
	
	/**
	 * 例外を適切な型に振り分けます。
	 * <p>
	 * 受け取ったSQL例外が制約違反を表す例外であった場合、フレームワークの独自例外を返します。<br>
	 * 制約違反以外を表すSQL例外が渡された場合は、渡されたSQL例外をそのまま返します。
	 * <p>
	 * 検査制約違反⇒{@link GCheckConstraintException}<br>
	 * 非NULL制約違反⇒{@link GNotNullConstraintException}<br>
	 * 一意制約違反⇒{@link GUniqueConstraintException}<br>
	 * 外部キー制約違反⇒{@link GForeignKeyConstraintException}
	 * 
	 * @param e 判別するSQL例外
	 * @return フレームワークの独自例外またはSQL例外
	 * @author KCCS K.Fujita
	 * @create 2013/06/06
	 * @since 3.12.0
	 */
	SQLException handleException(SQLException e);
}
