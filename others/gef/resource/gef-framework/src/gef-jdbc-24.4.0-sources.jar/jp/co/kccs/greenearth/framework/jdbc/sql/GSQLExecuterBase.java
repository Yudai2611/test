/*
 * Copyright 2013-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.BatchUpdateException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResult;
import jp.co.kccs.greenearth.framework.jdbc.GQueryResultImpl;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam.ParamMode;


/**
 * {@link GSQLExecuter}を実装する基底クラスです.
 *
 * @author KCCS kitamura
 * @create 2012/11/08
 * @since 3.12.0
 */
public abstract class GSQLExecuterBase implements GSQLExecuter {
	/** タイムアウト時間 */
	private int queryTimeout;
	/** 型ハンドラ. */
	public GSQLTypeHandler typeHandler = null;
	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GSQLExecuter.class);
	/** コンバータ生成ファクトリ. */
	private GBindParamConverterFactory converterFactory;
	/** コメントを抽出する正規表現 */
	private static final String REG_COMMENT = "--.*?(\r\n|\n)|\\/\\*.*?\\*\\/";
	/** コメントを抽出するパターン */
	private static final Pattern PTN_COMMENT = Pattern.compile(REG_COMMENT, Pattern.DOTALL);

	/**
	 * {@link GSQLExecuterBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	@Deprecated
	public GSQLExecuterBase(GSQLTypeHandler typeHandler) {
		this(typeHandler, -1);
	}

	/**
	 * {@link GSQLExecuterBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param converterFactory {@link GBindParamConverterFactory}のインスタンス
	 * @author hashimoto
	 * @create 2016/2/20
	 * @since 3.17.0
	 */
	public GSQLExecuterBase(GSQLTypeHandler typeHandler, GBindParamConverterFactory converterFactory) {
		this(typeHandler, -1, converterFactory);
	}

	/**
	 * {@link GSQLExecuterBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @author KCCS K.Fujita
	 * @create 2013/02/07
	 * @since 3.12.0
	 */
	@Deprecated
	public GSQLExecuterBase(GSQLTypeHandler typeHandler, int queryTimeout) {
		this.typeHandler = typeHandler;
		this.queryTimeout = queryTimeout;
	}

	/**
	 * {@link GSQLExecuterBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @param converterfactory {@link GBindParamConverterFactory}のインスタンス
	 * @author hashimoto
	 * @create 2016/2/20
	 * @since 3.17.0
	 */
	public GSQLExecuterBase(GSQLTypeHandler typeHandler, int queryTimeout, GBindParamConverterFactory converterfactory) {
		this.typeHandler = typeHandler;
		this.queryTimeout = queryTimeout;
		this.converterFactory = converterfactory;
	}

	@Override
	public ResultSet executeQuery(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {

			ps = prepareStatement(connection, piece.getSql(), timeoutSeconds);
			bindParameter(ps, convertedParams);

			GStopWatch stopWatch = new GStopWatch();
			stopWatch.start();
			rs = ps.executeQuery();

			logSqlDebug(piece.getSql(), convertedParams);
			logDebug("Execute Query(" + stopWatch.stop() + ")");

			return rs;
		} catch (RuntimeException e) {
			close(ps, rs);
			throw e;
		} catch (SQLException e) {
			logSqlError(piece.getSql(), convertedParams);
			close(ps, rs);
			throw e;
		}
	}

	@Override
	public int executeCount(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException {
		PreparedStatement ps = null;
		ResultSet resultSet = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {
			ps = prepareStatement(connection, piece.getSql(), timeoutSeconds);
			bindParameter(ps, convertedParams);

			GStopWatch stopWatch = new GStopWatch();
			stopWatch.start();
			resultSet = ps.executeQuery();
			logSqlDebug(piece.getSql(), convertedParams);
			logDebug("Execute Count(" + stopWatch.stop() + ")");

			if (resultSet.next()) {
				return resultSet.getInt(1);
			} else {
				throw new IllegalStateException("The search result does not exist.");
			}
		} catch (SQLException e) {
			logSqlError(piece.getSql(), convertedParams);
			throw e;
		} finally {
			close(ps, resultSet);
		}
	}

	@Override
	public int executeUpdate(Connection connection, GSQLPiece piece,  int timeoutSeconds) throws SQLException {
		PreparedStatement ps = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {
			ps = prepareStatement(connection, piece.getSql(), timeoutSeconds);
			bindParameter(ps, convertedParams);

			GStopWatch stopWatch = new GStopWatch();
			stopWatch.start();
			int result = ps.executeUpdate();
			logDebug("Execute Update(" + stopWatch.stop() + ")");
			logSqlDebug(piece.getSql(), convertedParams);

			return result;
		} catch (SQLException sqle) {
			logSqlError(piece.getSql(), convertedParams);
			throw handleException(sqle);
		}
		finally {
			close(ps);
		}
	}

	@Override
	public int executeBatchUpdate(Connection connection, GSQLPiece piece, int batchSize, int timeoutSeconds)
		throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		PreparedStatement ps = null;
		List<GBindParam[]> bindListForLog = new ArrayList<GBindParam[]>();
		int totUpdCnt = 0;

		try {
			int size = piece.getParameterList().size();
			int[] totalResuls = new int[size];
			int pos = 0;

			ps = prepareStatement(connection, piece.getSql(), timeoutSeconds);
			for (int i = 0; i < size; i++) {
				GBindParam[] convertedParams =
						convertBindParams(piece.getParameterList().get(i));
				bindListForLog.add(convertedParams);
				bindParameter(ps, convertedParams);
				ps.addBatch();

				if (batchSize > 0 && ((size - 1) == i || ((i + 1) % batchSize == 0))) {
					stopWatch.start();
					int[] result = ps.executeBatch();
					logDebug("Execute Batch(" + stopWatch.stop() + "):");

					logBatchSqlDebug(piece.getSql(), bindListForLog);
					bindListForLog.clear();
					System.arraycopy(result, 0, totalResuls, pos, result.length);
					pos = i + 1;
				}
			}

			if (batchSize <= 0) {
				stopWatch.start();
				totalResuls = ps.executeBatch();
				logDebug("Execute Batch(" + stopWatch.stop() + "):");
				logBatchSqlDebug(piece.getSql(), bindListForLog);
			}

			for (int i : totalResuls) {
				totUpdCnt += i;
			}

			return totUpdCnt;

		} catch (BatchUpdateException bue) {
			logBatchSqlError(piece.getSql(), bindListForLog);
			throw bue;
		} catch (SQLException sqle) {
			logBatchSqlError(piece.getSql(), bindListForLog);
			throw handleException(sqle);
		}
		finally {
			close(ps);
		}
	}

	@Override
	public GQueryResult execute(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		PreparedStatement ps = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {
			ps = prepareStatement(connection, piece.getSql(), timeoutSeconds);
			bindParameter(ps, convertedParams);

			stopWatch.start();
			boolean result = ps.execute();

			logSqlDebug(piece.getSql(), convertedParams);
			logDebug("Execute SQL(" + stopWatch.stop() + ")");

			return new GQueryResultImpl(result, ps);
		} catch (SQLException sqle) {
			logSqlError(piece.getSql(), convertedParams);
			close(ps);
			throw handleException(sqle);
		} catch (RuntimeException e) {
			logSqlError(piece.getSql(), convertedParams);
			close(ps);
			throw e;
		}
	}


	@Override
	public int callUpdate(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		CallableStatement cs = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {
			cs = prepareCall(connection, piece.getSql(), timeoutSeconds);
			bindParameter(cs, convertedParams);

			stopWatch.start();
			int result = cs.executeUpdate();
			logSqlDebug(piece.getSql(), convertedParams);
			logDebug("Execute Procedure(" + stopWatch.stop() + ")");

			// OUT, INOUTパラメータの値を更新
			applyParamValues(convertedParams, cs);

			return result;
		} catch (RuntimeException e) {
			logSqlError(piece.getSql(), convertedParams);
			throw e;
		} catch (SQLException e) {
			logSqlError(piece.getSql(), convertedParams);
			throw e;
		} finally {
			close(cs);
		}
	}

	@Override
	public <T> T callData(Connection connection, GSQLPiece piece, GColumnType returnType, int timeoutSeconds) throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		CallableStatement cs = null;
		ResultSet resultSet = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {
			cs = prepareCall(connection, piece.getSql(), timeoutSeconds);
			bindParameter(cs, convertedParams);

			stopWatch.start();
			boolean hasResultSet = cs.execute();
			logSqlDebug(piece.getSql(), convertedParams);
			logDebug("Execute Procedure(" + stopWatch.stop() + ")");

			// OUT, INOUTパラメータの値を更新
			applyParamValues(convertedParams, cs);

			if (hasResultSet) { // MySQL
				resultSet = cs.getResultSet();
				resultSet.next();
				@SuppressWarnings("unchecked")
				T data = (T) typeHandler.getValue(resultSet, 1, returnType);
				return data;
			} else { // Oracle
				return typeHandler.getValue(cs, 1, convertedParams[0]);
			}
		} catch (RuntimeException e) {
			logSqlError(piece.getSql(), convertedParams);
			throw e;
		} catch (SQLException e) {
			logSqlError(piece.getSql(), convertedParams);
			throw e;
		} finally {
			close(cs, resultSet);
		}
	}

	@Override
	public ResultSet callQuery(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		CallableStatement cs = null;
		ResultSet rs = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {
			cs = prepareCall(connection, piece.getSql(), timeoutSeconds);
			bindParameter(cs, convertedParams);

			stopWatch.start();
			boolean hasResultSet = cs.execute();
			logSqlDebug(piece.getSql(), convertedParams);
			logDebug("Execute Procedure(" + stopWatch.stop() + ")");

			applyParamValues(convertedParams, cs);

			if (hasResultSet) { // MySQL、DB_2等の場合
				return cs.getResultSet();
			} else { // Oracle、PostgreSQL等の場合
				return (ResultSet) cs.getObject(1);
			}
		} catch (RuntimeException e) {
			close(cs, rs);
			throw e;
		} catch (SQLException e) {
			logSqlError(piece.getSql(), convertedParams);
			close(cs, rs);
			throw e;
		}
	}

	@Override
	public GQueryResult call(Connection connection, GSQLPiece piece, int timeoutSeconds) throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		CallableStatement cs = null;
		GBindParam[] convertedParams = convertBindParams(piece.getParameter());
		try {
			cs = prepareCall(connection, piece.getSql(), timeoutSeconds);

			bindParameter(cs, convertedParams);

			stopWatch.start();
			boolean hasResultSet = cs.execute();
			logSqlDebug(piece.getSql(), convertedParams);
			logDebug("Execute Procedure(" + stopWatch.stop() + ")");

			applyParamValues(convertedParams, cs);

			return new GQueryResultImpl(hasResultSet, cs);
		} catch (RuntimeException e) {
			close(cs);
			throw e;
		} catch (SQLException e) {
			logSqlError(piece.getSql(), convertedParams);
			close(cs);
			throw e;
		}
	}

	/**
	 * {@link GBindParam}の値を型変換します。
	 *
	 * {@link GBindParamConverterFactory}がnullの場合、<br>
	 * または、{@link GBindParamConverter}がnullの場合は、<br>
	 * コンバートせずに{@link GBindParam}をそのまま返却します。<br>
	 *
	 * @param params {@link GBindParam}のインスタンス
	 * @return 値を型変換をした{@link GBindParam}のインスタンス
	 * @author hashimoto
	 * @create 2016/05/18
	 * @since 3.18.0
	 */
	protected GBindParam[] convertBindParams(GBindParam[] params) {
		if (params == null || params.length <= 0) {
			return params;
		}
		if (converterFactory == null) {
			return params;
		}

		List<GBindParam> result = new ArrayList<>();

		for (GBindParam param : params) {
			Object value = param.getValue();
			GBindParamConverter converter = converterFactory.getConverter(value == null ? null : value.getClass());
			result.add(converter == null ? param : converter.convert(param));
		}
		return (GBindParam[]) result.toArray(new GBindParam[0]);
	}

	//////////////////////////
	/* 制約違反のハンドル */
	//////////////////////////
	@Override
	public SQLException handleException(SQLException e) {
		// 検査制約違反
		if (isCheckConstraintViolation(e)) {
			return new GCheckConstraintException("CHECK constraint violated. ", e.getSQLState(), e.getErrorCode(), e);
		}
		// 非NULL制約違反
		else if (isNotNullConstraintViolation(e)) {
			return new GNotNullConstraintException("NOT NULL constraint violated. ", e.getSQLState(), e.getErrorCode(), e);
		}
		// 一意制約違反
		else if (isUniqueConstraintViolation(e)) {
			return new GUniqueConstraintException("UNIQUE constraint violated. ", e.getSQLState(), e.getErrorCode(), e);
		}
		// 外部キー制約違反
		else if (isForeignKeyConstraintViolation(e)) {
			return new GForeignKeyConstraintException("FOREIGN KEY constraint violated. ", e.getSQLState(), e.getErrorCode(), e);
		}
		// 制約違反以外のSQL例外
		else {
			return e;
		}
	}

	/**
	 * SQL例外が検査制約違反を表すものかを識別します.
	 *
	 * @param e 識別するSQL例外
	 * @return 検査制約違反を表す例外であれば<code>true</code>/そうでなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	private boolean isCheckConstraintViolation(SQLException e) {
		return Arrays.asList(getCheckCodes()).contains(e.getErrorCode())
			&& Arrays.asList(getCheckStatuses()).contains(e.getSQLState());
	}

	/**
	 * SQL例外が非NULL制約違反を表すものかを識別します.
	 *
	 * @param e 識別するSQL例外
	 * @return 非NULL制約違反を表す例外であれば<code>true</code>/そうでなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	private boolean isNotNullConstraintViolation(SQLException e) {
		return Arrays.asList(getNotNullCodes()).contains(e.getErrorCode())
			&& Arrays.asList(getNotNullStatuses()).contains(e.getSQLState());
	}

	/**
	 * SQL例外が一意制約違反を表すものかを識別します.
	 *
	 * @param e 識別するSQL例外
	 * @return 一意制約違反を表す例外であれば<code>true</code>/そうでなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	private boolean isUniqueConstraintViolation(SQLException e) {
		return Arrays.asList(getUniqueCodes()).contains(e.getErrorCode())
			&& Arrays.asList(getUniqueStatuses()).contains(e.getSQLState());
	}

	/**
	 * SQL例外が外部キー制約違反を表すものかを識別します.
	 *
	 * @param e 識別するSQL例外
	 * @return 外部キー制約違反を表す例外であれば<code>true</code>/そうでなければ<code>false</code>
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	private boolean isForeignKeyConstraintViolation(SQLException e) {
		return Arrays.asList(getForeignKeyCodes()).contains(e.getErrorCode())
			&& Arrays.asList(getForeignKeyStatuses()).contains(e.getSQLState());
	}

	/**
	 * 検査制約違反のエラーコードを取得します.
	 *
	 * @return 検査制約違反のエラーコード
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract Integer[] getCheckCodes();

	/**
	 * 検査制約違反のSQLステータスを取得します.
	 *
	 * @return 検査制約違反のSQLステータス
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract String[] getCheckStatuses();

	/**
	 * 非NULL制約違反のエラーコードを取得します.
	 *
	 * @return 非NULL制約違反のエラーコード
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract Integer[] getNotNullCodes();

	/**
	 * 非NULL制約違反のSQLステータスを取得します.
	 *
	 * @return 非NULL制約違反のSQLステータス
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract String[] getNotNullStatuses();

	/**
	 * 一意制約違反のエラーコードを取得します.
	 *
	 * @return 一意制約違反のエラーコード
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract Integer[] getUniqueCodes();

	/**
	 * 一意制約違反のSQLステータスを取得します.
	 *
	 * @return 一意制約違反のSQLステータス
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract String[] getUniqueStatuses();

	/**
	 * 外部キー制約違反のエラーコード を取得します.
	 *
	 * @return 外部キー制約違反のエラーコード
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract Integer[] getForeignKeyCodes();

	/**
	 * 外部キー制約違反のSQLステータスを取得します.
	 *
	 * @return 外部キー制約違反のSQLステータス
	 * @author KCCS K.Fujita
	 * @create 2013/06/05
	 * @since 3.12.0
	 */
	protected abstract String[] getForeignKeyStatuses();


	//////////////////////////////////
	/*       Statementの生成        */
	//////////////////////////////////

	/**
	 * {@link PreparedStatement}を生成します.
	 *
	 * @param connection コネクション
	 * @param sql SQL文
	 * @param timeoutSeconds ステートメントの実行を待つ時間（秒）
	 * @return {@link PreparedStatement}
	 * @throws SQLException {@link PreparedStatement}の生成やクローズに失敗した場合
	 * @author KCCS kitamura
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	protected PreparedStatement prepareStatement(Connection connection, String sql, int timeoutSeconds) throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		PreparedStatement ps = null;

		// 渡されたタイムアウト時間が-1の場合、DIで定義されたタイムアウト時間を使用する
		if (timeoutSeconds == -1) {
			timeoutSeconds = this.queryTimeout;
		}

		try {
			stopWatch.start();

			ps = connection.prepareStatement(sql);
			if (timeoutSeconds > -1) {
				ps.setQueryTimeout(timeoutSeconds);
			}

			logDebug("Prepare(" + stopWatch.stop() + ")"); // PreparedStatement生成時間
			return ps;
		}
		catch (RuntimeException e) {
			close(ps);
			throw e;
		}
		catch (SQLException e) {
			close(ps);
			throw e;
		}
	}

	/**
	 * {@link CallableStatement}を生成します.
	 *
	 * @param connection コネクション
	 * @param sql SQL文
	 * @param timeoutSeconds ステートメントの実行を待つ時間（秒）
	 * @return {@link CallableStatement}
	 * @throws SQLException {@link CallableStatement}の生成に失敗した場合。
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	protected CallableStatement prepareCall(Connection connection, String sql, int timeoutSeconds) throws SQLException {
		GStopWatch stopWatch = new GStopWatch();
		CallableStatement cs = null;

		// 渡されたタイムアウト時間が-1の場合、DIで定義されたタイムアウト時間を使用する
		if (timeoutSeconds == -1) {
			timeoutSeconds = this.queryTimeout;
		}

		try {
			stopWatch.start();
			cs = connection.prepareCall(sql);
			logDebug("PrepareCall(" + stopWatch.stop() + ")"); // CallableStatement生成の所要時間

			if (timeoutSeconds > -1) {
				cs.setQueryTimeout(timeoutSeconds);
			}

			return cs;
		}
		catch (RuntimeException e) {
			close(cs);
			throw e;
		}
		catch (SQLException e) {
			close(cs);
			throw e;
		}
	}

	//////////////////////////////////
	/*       パラメータの操作        */
	//////////////////////////////////
	/**
	 * {@link PreparedStatement}にパラメータをバインドします.
	 *
	 * @param ps パラメータをバインドする{@link PreparedStatement}
	 * @param params バインドパラメータ
	 * @throws SQLException パラメータのバインドに失敗した場合
	 * @author KCCS kitamura
	 * @create 2012/10/08
	 * @since 3.12.0
	 */
	protected void bindParameter(PreparedStatement ps, GBindParam[] params) throws SQLException {
		if (params == null || params.length <= 0) {
			return;
		}
		int index = 1;
		for (GBindParam param : params) {
			typeHandler.bindValue(ps, index, param);
			index++;
		}
	}

	/**
	 * {@link CallableStatement}にパラメータをバインドします.
	 *
	 * @param cs パラメータをバインドする{@link CallableStatement}
	 * @param params バインドパラメータ
	 * @throws SQLException パラメータのバインドに失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	protected void bindParameter(CallableStatement cs, GBindParam[] params) throws SQLException {
		if (params == null || params.length <= 0) {
			return;
		}
		int index = 1;
		for (GBindParam param : params) {
			typeHandler.bindValue(cs, index, param);
			index++;
		}
	}

	/**
	 * OUTパラメータまたはINOUTパラメータが保持している値を、
	 * ストアドプロシージャまたはストアドファンクション実行後の値に更新します.
	 * INパラメータに対しては何も行いません。<br/>
	 *
	 * @param cs パラメータの値を取り出す{@link CallableStatement}
	 * @param params パラメータ
	 * @throws SQLException 値の取得に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	protected void applyParamValues(GBindParam[] params, CallableStatement cs) throws SQLException {
		if (params == null || params.length <= 0) {
			return;
		}
		int index = 1;
		for (GBindParam param : params) {
			if (ParamMode.OUT.equals(param.getParamMode()) || ParamMode.INOUT.equals(param.getParamMode())) {
				Object value = typeHandler.getValue(cs, index, param);
				param.setValue(value);
			}
			index++;
		}
	}

	//////////////////////////////////
	/*             ログ出力             */
	//////////////////////////////////

	/**
	 * 文字列をデバッグログとして出力します.
	 *
	 * @param log ログ出力する文字列
	 * @author KCCS K.Fujita
	 * @create 2012/12/18
	 * @since 3.12.0
	 */
	protected void logDebug(String log) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(log);
		}
	}

	/**
	 * SQL文中のプレースホルダをバインドパラメータの値に置き換え、デバッグログとして出力します.
	 *
	 * @param sql プレースホルダを含むSQL文字列
	 * @param params バインドパラメータ
	 * @author KCCS K.Fujita
	 * @create 2012/12/18
	 * @since 3.12.0
	 */
	protected void logSqlDebug(String sql, GBindParam[] params) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("SQL:" + createLogSql(sql, params));
		}
	}

	/**
	 * 一括実行するSQLをデバッグログとして出力します.
	 *
	 * @param sql SQL
	 * @param paramsList バインドパラメータのリスト
	 * @author KCCS K.Fujita
	 * @create 2012/12/18
	 * @since 3.12.0
	 */
	protected void logBatchSqlDebug(String sql, List<GBindParam[]> paramsList) {
		if (LOGGER.isDebugEnabled()) {
			for (GBindParam[] bindParamForLog : paramsList) {
				logSqlDebug(sql, bindParamForLog);
			}
		}
	}

	/**
	 * 文字列をエラーログとして出力します.
	 *
	 * @param log ログ出力する文字列
	 * @author KCCS K.Fujita
	 * @create 2012/12/18
	 * @since 3.12.0
	 */
	protected void logError(String log) {
		if (LOGGER.isErrorEnabled()) {
			LOGGER.error(log);
		}
	}

	/**
	 * SQL文中のプレースホルダをバインドパラメータの値に置き換え、エラーログとして出力します.
	 *
	 * @param sql SQL
	 * @param params バインドパラメータ
	 * @author KCCS K.Fujita
	 * @create 2012/12/18
	 * @since 3.12.0
	 */
	protected void logSqlError(String sql, GBindParam[] params) {
		if (LOGGER.isErrorEnabled()) {
			LOGGER.error("!SQL:" + createLogSql(sql, params));
		}
	}

	/**
	 * 一括実行したSQLをエラーログとして出力します.
	 *
	 * @param sql SQL
	 * @param paramsList バインドパラメータのリスト
	 * @author KCCS K.Fujita
	 * @create 2012/12/18
	 * @since 3.12.0
	 */
	protected void logBatchSqlError(String sql, List<GBindParam[]> paramsList) {
		if (LOGGER.isErrorEnabled()) {
			for (GBindParam[] bindParamForLog : paramsList) {
				logSqlError(sql, bindParamForLog);
			}
		}
	}

	/**
	 * SQL文のプレースホルダをバインドパラメータに置換し、ログとして出力するSQL文を生成します.
	 *
	 * @param sql SQL文
	 * @param params バインドパラメータ
	 * @return ログ出力するSQL文
	 * @author KCCS K.Fujita
	 * @create 2012/12/19
	 * @since 3.12.0
	 */
	protected String createLogSql(String sql, GBindParam[] params) {
		final String REG_BINDPARAM = "\\?";
		final Pattern PTN_BINDPARAM = Pattern.compile(REG_BINDPARAM);

		Map<String, String> replacedComments = new HashMap<String, String>();
		sql = replaceString(sql, replacedComments, PTN_COMMENT.matcher(sql), "@");

		Matcher matcher = PTN_BINDPARAM.matcher(sql);
		int index = 0;
		int position = 0;

		StringBuilder replaced = new StringBuilder();

		while (matcher.find()) {
			String before = sql.substring(position, matcher.start());
			replaced.append(before); // 項目が見つかるまでの文字列を追加

			replaced.append(createLogValue(params[index].getValue()));

			position = matcher.end();
			index++;
		}
		String after = sql.substring(position, sql.length());
		replaced.append(after);

		return restoreString(replaced.toString(), replacedComments);
	}

	/**
	 * パターンにマッチした文字列を置換します.
	 *
	 * @param sql SQL文
	 * @param replacedStrings 置換されたコメントを格納するマップ
	 * @param matcherString 置換されたコメントを格納するマップ
	 * @param replaceChar 置換時に使用する文字
	 * @return コメントが置換されたSQL文
	 * @author mikazura
	 * @create 2017/03/09
	 * @since 3.19.2
	 */
	protected String replaceString (String sql, Map<String, String> replacedStrings, Matcher matcherString, String replaceChar) {
		// ﾊﾟﾀｰﾝにﾏｯﾁした文字列をﾌﾟﾚｰｽﾎﾙﾀﾞ文字列に置換する。（replaceChar="@"ならば、"@@@数字@@"に置換）
		// 複数ﾏｯﾁする場合は、"@@@0@@"、"@@@1@@"、と数字をｲﾝｸﾘﾒﾝﾄして置換する
		// 置換前の文字列はｷｬｯｼｭしておき、後処理で元に戻す（"@@@0@@"は「戻す場所」を示すﾌﾟﾚｰｽﾎﾙﾀﾞの役割を担う）
		// 元のsql文字列に"@@@数字@@"が含まれる場合、元に戻す処理が失敗する（同じﾌﾟﾚｰｽﾎﾙﾀﾞが複数になるため）
		// そのため、sql文字列に"@@@数字@@"という文字列が含まれるか調べ、含まれる場合は数字を抽出しておく
		// ﾌﾟﾚｰｽﾎﾙﾀﾞ文字列は、"@@@0@@"、"@@@1@@"と数字をｲﾝｸﾘﾒﾝﾄして生成するが、あらかじめ抽出した数字はｽｷｯﾌﾟすることで重複を防ぐ
		StringBuilder regBuilder = new StringBuilder();
		regBuilder.append(replaceChar);
		regBuilder.append("+[0-9]+|[0-9]+");
		regBuilder.append(replaceChar);
		regBuilder.append("+|");
		regBuilder.append(replaceChar);
		regBuilder.append("+[0-9]+");
		regBuilder.append(replaceChar);
		regBuilder.append("+");

		String reg = regBuilder.toString();
		Matcher matcherScope = Pattern.compile(reg, Pattern.DOTALL).matcher(sql);
		List<String> skipNumList = new ArrayList<String>();
		while (matcherScope.find()) {
			String group = matcherScope.group();
			skipNumList.add(group.replaceAll("[^0-9]",""));
		}

		int position = 0;
		StringBuilder replaceBuf = new StringBuilder();
		int index = 0;
		while (matcherString.find()) {
			String before = sql.substring(position, matcherString.start(0));
			// 数字が重複する場合はｽｷｯﾌﾟして重複を防ぐ
			while (skipNumList.contains(String.valueOf(index))) {
				index++;
			}
			StringBuilder builder = new StringBuilder();
			builder.append(replaceChar);
			builder.append(replaceChar);
			builder.append(replaceChar);
			builder.append(index++);
			builder.append(replaceChar);
			builder.append(replaceChar);
			String replaceStr = builder.toString();

			replaceBuf.append(before).append(replaceStr);
			replacedStrings.put(replaceStr, matcherString.group(0));
			position = matcherString.end(0);
		}
		String after = sql.substring(position, sql.length());
		return replaceBuf.append(after).toString();
	}

	/**
	 * 文字列を置換される以前の状態へ戻します.
	 *
	 * @param String 置換対象の文字列
	 * @param escapeString 置換された文字列のマップ
	 * @return 文字列リテラルが置換される以前の状態へ戻された文字列
     * @author KCCS mikazura
     * @create 2017/03/09
     * @since 3.19.2
	 */
	protected String restoreString(String sql, Map<String, String> escapeString) {
		String replace = sql;
		for (String key : escapeString.keySet()) {
			replace = replace.replace(key, escapeString.get(key));
		}
		return replace;
	}

	/**
	 * ログ出力する値の文字列を生成します.
	 *
	 * @param value 値
	 * @return ログ出力する値の文字列
	 * @author KCCS K.Fujita
	 * @create 2012/12/19
	 * @since 3.12.0
	 */
	protected String createLogValue(Object value) {
		if (value == null) {
			return "null";
		} else if (value instanceof java.sql.Timestamp) {	//日付型
			return "'" + value.toString() + "'";
		} else if (value instanceof java.util.Date || value instanceof java.sql.Date) {	//日付型
			return "'" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(value) + "'";
		} else if (value instanceof Number) { //数値型
			return value.toString();
		} else {		//null と 日付型、数値型以外
			return "'" + value.toString() + "'";
		}
	}

	//////////////////////////////////
	/*        リソースの解放         */
	//////////////////////////////////

	/**
	 * ステートメントと結果セットを解放します.
	 *
	 * @param ps 解放する{@link PreparedStatement}
	 * @param rs 解放する結果セット
	 * @throws SQLException リソースの解放に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	protected void close(Statement ps, ResultSet rs) throws SQLException {
		try {
			close(ps);
		} finally {
			close(rs);
		}
	}

	/**
	 * ステートメントを解放します.
	 *
	 * @param stmt 解放する{@link PreparedStatement}
	 * @throws SQLException {@link PreparedStatement}の解放に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/21
	 * @since 3.12.0
	 */
	protected void close (Statement stmt) throws SQLException {
		if (stmt != null) {
			stmt.close();
		}
	}

	/**
	 * 結果セットを解放します.
	 *
	 * @param resultSet 解放する結果セット
	 * @throws SQLException 結果セットの解放に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/21
	 * @since 3.12.0
	 */
	protected void close (ResultSet resultSet) throws SQLException {
		if (resultSet != null) {
			resultSet.close();
		}
	}
}
