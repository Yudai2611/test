/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;


/**
 * {@link GSQLExecuterMySQLBase}をMySQL8.0用に実装するクラスです.
 *
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GSQLExecuterMySQL8_0 extends GSQLExecuterMySQLBase {
	
	/**
	 * {@link GSQLExecuterMySQL8_0}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param converterFactory コンバータファクトリ
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GSQLExecuterMySQL8_0(GSQLTypeHandler typeHandler, GBindParamConverterFactory converterFactory) {
		super(typeHandler, -1, converterFactory);
	}

	/**
	 * {@link GSQLExecuterMySQL8_0}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @param converterFactory コンバータファクトリ
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GSQLExecuterMySQL8_0(GSQLTypeHandler typeHandler, int queryTimeout, GBindParamConverterFactory converterFactory) {
		super(typeHandler, queryTimeout, converterFactory);
	}
}
