/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;


/**
 * {@link GSQLExecuterBase}をMySQL用に実装する基底クラスです.
 *
 * @author KCCS hashimoto
 * @create 2016/05/11
 * @since 3.18.0
 */
public abstract class GSQLExecuterMySQLBase extends GSQLExecuterBase {

	/*
	 * 各種制約違反のエラーコード
	 */
	/** 非NULL制約違反のエラーコード */
	private static final Integer[] ERRORCODE_NOTNULL = {1048};
	/** 一意制約違反のエラーコード */
	private static final Integer[] ERRORCODE_UNIQUE = {1022, 1062};
	/** 外部キー制約違反のエラーコード */
	private static final Integer[] ERRORCODE_FOREIGNKEY = {1451, 1452};
	/*
	 * 各種制約違反のSQLステータス
	 */
	/** 非NULL制約違反のSQLステータス */
	private static final String[] SQLSTATE_NOTNULL = {"23000"};
	/** 一意制約違反のSQLステータス */
	private static final String[] SQLSTATE_UNIQUE = {"23000"};
	/** 外部キー制約違反のSQLステータス */
	private static final String[] SQLSTATE_FOREIGNKEY = {"23000"};

	/**
	 * {@link GSQLExecuterMySQLBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param converterFactory コンバータファクトリ
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	public GSQLExecuterMySQLBase(GSQLTypeHandler typeHandler, GBindParamConverterFactory converterFactory) {
		super(typeHandler, -1, converterFactory);
	}

	/**
	 * {@link GSQLExecuterMySQLBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @param converterFactory コンバータファクトリ
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	public GSQLExecuterMySQLBase(GSQLTypeHandler typeHandler, int queryTimeout, GBindParamConverterFactory converterFactory) {
		super(typeHandler, queryTimeout, converterFactory);
	}

	@Override
	protected Integer[] getCheckCodes() {
		return new Integer[]{};		// MySQLには検査制約違反が無い
	}

	@Override
	protected String[] getCheckStatuses() {
		return new String[]{};		// MySQLには検査制約違反が無い
	}

	@Override
	protected Integer[] getNotNullCodes() {
		return ERRORCODE_NOTNULL;
	}

	@Override
	protected String[] getNotNullStatuses() {
		return SQLSTATE_NOTNULL;
	}

	@Override
	protected Integer[] getUniqueCodes() {
		return ERRORCODE_UNIQUE;
	}

	@Override
	protected String[] getUniqueStatuses() {
		return SQLSTATE_UNIQUE;
	}

	@Override
	protected Integer[] getForeignKeyCodes() {
		return ERRORCODE_FOREIGNKEY;
	}

	@Override
	protected String[] getForeignKeyStatuses() {
		return SQLSTATE_FOREIGNKEY;
	}
}
