/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * {@link GSQLExecuterOracleBase}をOracle19c用に実装するクラスです.
 *
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GSQLExecuterOracle19c extends GSQLExecuterOracleBase {

	/**
	  * {@link GSQLExecuterOracle19c}のインスタンスを生成します.
	  *
	  * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	  * @param converterFactory コンバータファクトリ
	  * @author KCCS okanishi
	  * @create 2021/3/31
	  * @since 21.3.0
	  */
	public GSQLExecuterOracle19c(GSQLTypeHandler typeHandler, GBindParamConverterFactory converterFactory) {
		super(typeHandler, -1, converterFactory);
	}

	/**
	 * {@link GSQLExecuterOracle19c}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @param converterFactory コンバータファクトリ
	  * @author KCCS okanishi
	  * @create 2021/3/31
	  * @since 21.3.0
	 */
	public GSQLExecuterOracle19c(GSQLTypeHandler typeHandler, int queryTimeout, GBindParamConverterFactory converterFactory) {
		super(typeHandler, queryTimeout, converterFactory);
	}
}
