/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.tools.GStopWatch;

/**
 * {@link GSQLExecuterBase}をOracle用に実装する基底クラスです.
 *
 * @author KCCS Hashimoto
 * @create 2016/08/30
 * @since 3.19.0
 */
public abstract class GSQLExecuterOracleBase extends GSQLExecuterBase {

	/* 各種制約違反のエラーコード*/
	/** 検査制約違反のエラーコード */
	private final Integer[] ERRORCODE_CHECK = {2290};
	/** 非NULL制約違反のエラーコード */
	private final Integer[] ERRORCODE_NOTNULL = {1400, 1407};
	/** 一意制約違反のエラーコード */
	private final Integer[] ERRORCODE_UNIQUE = {1};
	/** 外部キー制約違反のエラーコード */
	private final Integer[] ERRORCODE_FOREIGNKEY = {2291, 2292};

	/* 各種制約違反のSQLステータス */
	/** 検査制約違反のSQLステータス */
	private final String[] SQLSTATE_CHECK = {"23000"};
	/** 非NULL制約違反のSQLステータス */
	private final String[] SQLSTATE_NOTNULL = {"23000", "72000"};
	/** 一意制約違反のSQLステータス */
	private final String[] SQLSTATE_UNIQUE = {"23000"};
	/** 外部キー制約違反のSQLステータス */
	private final String[] SQLSTATE_FOREIGNKEY = {"23000"};

	/**
	  * {@link GSQLExecuterOracleBase}のインスタンスを生成します.
	  *
	  * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	  * @param converterFactory コンバータファクトリ
	  * @author KCCS Hashimoto
	  * @create 2016/08/30
	  * @since 3.19.0
	  */
	public GSQLExecuterOracleBase(GSQLTypeHandler typeHandler, GBindParamConverterFactory converterFactory) {
		super(typeHandler, -1, converterFactory);
	}

	/**
	 * {@link GSQLExecuterOracleBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @param converterFactory コンバータファクトリ
	 * @author KCCS Hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public GSQLExecuterOracleBase(GSQLTypeHandler typeHandler, int queryTimeout, GBindParamConverterFactory converterFactory) {
		super(typeHandler, queryTimeout, converterFactory);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int executeBatchUpdate(Connection connection, GSQLPiece piece, int batchSize, int timeoutSeconds)
		throws SQLException {
		GStopWatch stopWatch = new GStopWatch();

		PreparedStatement ps = null;
		List<GBindParam[]> bindListForLog = new ArrayList<GBindParam[]>();
		int totUpdCnt = 0;
		try {
			int size = piece.getParameterList().size();

			ps = prepareStatement(connection, piece.getSql(), timeoutSeconds);
			for (int i = 0; i < size; i++) {
				GBindParam[] convertedParams =
						convertBindParams(piece.getParameterList().get(i));
				bindListForLog.add(convertedParams);
				bindParameter(ps, convertedParams);
				ps.addBatch();

				if (batchSize > 0 && ((size - 1) == i || ((i + 1) % batchSize == 0))) {
					stopWatch.start();
					ps.executeBatch();
					logDebug("Execute Batch(" + stopWatch.stop() + "):"); // SQL実行時間

					// ログ出力
					logBatchSqlDebug(piece.getSql(), bindListForLog);
					bindListForLog.clear();

					totUpdCnt += ps.getUpdateCount();
				}
			}

			if (batchSize <= 0) { // 全件一括処理
				stopWatch.start();

				ps.executeBatch();
				logDebug("Execute Batch(" + stopWatch.stop() + "):"); // SQL実行時間
				logBatchSqlDebug(piece.getSql(), bindListForLog);

				totUpdCnt += ps.getUpdateCount();
			}

			return totUpdCnt;
		} catch (BatchUpdateException bue) {
			logBatchSqlError(piece.getSql(), bindListForLog);
			throw bue;
		} catch (SQLException sqle) {
			logBatchSqlError(piece.getSql(), bindListForLog);
			throw handleException(sqle);
		}
		finally {
			close(ps);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Integer[] getCheckCodes() {
		return ERRORCODE_CHECK;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String[] getCheckStatuses() {
		return SQLSTATE_CHECK;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Integer[] getNotNullCodes() {
		return ERRORCODE_NOTNULL;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String[] getNotNullStatuses() {
		return SQLSTATE_NOTNULL;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Integer[] getUniqueCodes() {
		return ERRORCODE_UNIQUE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String[] getUniqueStatuses() {
		return SQLSTATE_UNIQUE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Integer[] getForeignKeyCodes() {
		return ERRORCODE_FOREIGNKEY;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String[] getForeignKeyStatuses() {
		return SQLSTATE_FOREIGNKEY;
	}
}
