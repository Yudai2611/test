/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * {@link GSQLExecuterPostgreSQLBase}をPostgreSQL13.2に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GSQLExecuterPostgreSQL13_2 extends GSQLExecuterPostgreSQLBase {

	/**
	 * {@link GSQLExecuterPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param converterFactory コンバータファクトリ
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLExecuterPostgreSQL13_2(GSQLTypeHandler typeHandler, GBindParamConverterFactory converterFactory) {
		super(typeHandler, -1, converterFactory);
	}

	/**
	 * {@link GSQLExecuterPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @param converterFactory コンバータファクトリ
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLExecuterPostgreSQL13_2(GSQLTypeHandler typeHandler, int queryTimeout, GBindParamConverterFactory converterFactory) {
		super(typeHandler, queryTimeout, converterFactory);
	}
}
