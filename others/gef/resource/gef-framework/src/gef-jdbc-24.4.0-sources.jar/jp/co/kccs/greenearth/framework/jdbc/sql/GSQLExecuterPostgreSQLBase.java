/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * {@link GSQLExecuterBase}をPostgreSQL用に実装する基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public abstract class GSQLExecuterPostgreSQLBase extends GSQLExecuterBase {

	/*
	 * 各種制約違反のエラーコード
	 */
	/** 検査制約違反のエラーコード */
	private final Integer[] ERRORCODE_CHECK = {0};
	/** 非NULL制約違反のエラーコード */
	private static final Integer[] ERRORCODE_NOTNULL = {0};
	/** 一意制約違反のエラーコード */
	private static final Integer[] ERRORCODE_UNIQUE = {0};
	/** 外部キー制約違反のエラーコード */
	private static final Integer[] ERRORCODE_FOREIGNKEY = {0};
	/*
	 * 各種制約違反のSQLステータス
	 */
	/** 検査制約違反のSQLステータス */
	private final String[] SQLSTATE_CHECK = {"23514"};
	/** 非NULL制約違反のSQLステータス */
	private static final String[] SQLSTATE_NOTNULL = {"23502"};
	/** 一意制約違反のSQLステータス */
	private static final String[] SQLSTATE_UNIQUE = {"23505"};
	/** 外部キー制約違反のSQLステータス */
	private static final String[] SQLSTATE_FOREIGNKEY = {"23503"};

	/**
	 * {@link GSQLExecuterPostgreSQLBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param converterFactory コンバータファクトリ
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLExecuterPostgreSQLBase(GSQLTypeHandler typeHandler, GBindParamConverterFactory converterFactory) {
		super(typeHandler, -1, converterFactory);
	}

	/**
	 * {@link GSQLExecuterPostgreSQLBase}のインスタンスを生成します.
	 *
	 * @param typeHandler {@link GSQLTypeHandler}のインスタンス
	 * @param queryTimeout タイムアウト時間のデフォルト値
	 * @param converterFactory コンバータファクトリ
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLExecuterPostgreSQLBase(GSQLTypeHandler typeHandler, int queryTimeout, GBindParamConverterFactory converterFactory) {
		super(typeHandler, queryTimeout, converterFactory);
	}

	@Override
	protected Integer[] getCheckCodes() {
		return ERRORCODE_CHECK;
	}

	@Override
	protected String[] getCheckStatuses() {
		return SQLSTATE_CHECK;
	}

	@Override
	protected Integer[] getNotNullCodes() {
		return ERRORCODE_NOTNULL;
	}

	@Override
	protected String[] getNotNullStatuses() {
		return SQLSTATE_NOTNULL;
	}

	@Override
	protected Integer[] getUniqueCodes() {
		return ERRORCODE_UNIQUE;
	}

	@Override
	protected String[] getUniqueStatuses() {
		return SQLSTATE_UNIQUE;
	}

	@Override
	protected Integer[] getForeignKeyCodes() {
		return ERRORCODE_FOREIGNKEY;
	}

	@Override
	protected String[] getForeignKeyStatuses() {
		return SQLSTATE_FOREIGNKEY;
	}
}
