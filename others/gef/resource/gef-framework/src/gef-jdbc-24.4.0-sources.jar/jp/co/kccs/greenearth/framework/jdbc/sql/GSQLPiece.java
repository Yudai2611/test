/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.LinkedList;
import java.util.List;


/**
 * SQL断片を表すクラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 * 
 */
public class GSQLPiece {
	/** SQL */
	private StringBuilder sql = null;
	/** バインドパラメータ */
	private List<GBindParam[]> parameter = null;

    /**
     * {@link GSQLPiece}を初期化します.
     * 
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GSQLPiece() {
	}
	
    /**
     * {@link GSQLPiece}を初期化します.
     * 
     * @param sql SQL文
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GSQLPiece(String sql) {
		this.sql = new StringBuilder(sql);
	}
	
    /**
     * {@link GSQLPiece}を初期化します.
     * 
     * @param sql SQL文
     * @param parameter パラメータ配列
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GSQLPiece(String sql, GBindParam[] parameter) {
		this(sql);
		List<GBindParam[]> list = new LinkedList<GBindParam[]>();
		list.add(parameter);
		this.parameter = list;
	}
	
    /**
     * {@link GSQLPiece}を初期化します.
     * 
     * @param sql SQL文
     * @param parameter パラメータ配列のリスト
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GSQLPiece(String sql, List<GBindParam[]> parameter) {
		this(sql);
		this.parameter = parameter;
	}

    /**
     * SQL文を取得します.
     * 
     * @return SQL文
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public String getSql() {
		return this.sql.toString();
	}
    /**
     * SQL文を設定します.
     * 
     * @param sql SQL文
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setSql(String sql) {
		this.sql = new StringBuilder(sql);
	}
	
	/**
	 * 現在設定されているSQL文に新しいSQL文を追加します.
	 * 
	 * @param sql 追加するSQL文
	 * @author KCCS K.Fujita
	 * @create 2013/04/01
	 * @since 3.12.0
	 */
	public void appendSql(String sql) {
		if (this.sql == null) {
			setSql(sql);
		} else {
			this.sql.append(sql);
		}
	}

	/**
	 * 指定された SQL文をこのシーケンスに挿入します。
	 * 
	 * @param offset オフセット
	 * @param sql SQL文
	 * @author KCCS kitamura
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	public void insertSql(int offset, String sql) {
		this.sql.insert(offset, sql);
	}
	
	/**
	 * 現在設定されているSQL文の指定された部分を削除します.
	 * 
	 * @param start 開始インデックス（この値を含む）
	 * @param end 終了インデックス（この値を含まない）
	 * @author KCCS K.Fujita
	 * @create 2013/04/01
	 * @since 3.12.0
	 */
	public void deleteSql(int start, int end) {
		this.sql.delete(start, end);
	}
	
    /**
     * パラメータの配列のリストの最初の要素を取得します.
     * 
     * @return パラメータの配列
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public GBindParam[] getParameter() {
		return parameter != null ? parameter.get(0) : null;
	}
	
    /**
     * パラメータの配列をリストに追加します.
     * 
     * @param param パラメータの配列
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void addParameter(GBindParam[] param) {
		parameter = parameter == null ? new LinkedList<GBindParam[]>() : parameter;
		parameter.add(param);
	}

    /**
     * パラメータの配列のリストを取得します.
     * 
     * @return パラメータの配列のリスト
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public List<GBindParam[]> getParameterList() {
		return parameter;
	}

    /**
     * パラメータの配列のリストを更新します.<br/>
     * 渡されたパラメータの配列がnullもしくは要素数が0の場合、パラメータの配列のリストをnullに設定し、
     * 要素数が1以上の場合、唯一のパラメータの配列として設定します.<br/>
     * 
     * @param updateParameter 要整備
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setParameter(GBindParam[] updateParameter) {
		if (updateParameter == null || updateParameter.length == 0) {
			this.parameter = null;
		} else {
			List<GBindParam[]> list = new LinkedList<GBindParam[]>();
			list.add(updateParameter);
			this.parameter = list;
		}
	}

    /**
     * パラメータの配列のリストを設定します.
     * 
     * @param updateParameter パラメータの配列のリスト
     * @author KCCS kitamura
     * @create 2012/12/05
     * @since 3.12.0
     */
	public void setParameter(List<GBindParam[]> updateParameter) {
		this.parameter = updateParameter;
	}
}
 