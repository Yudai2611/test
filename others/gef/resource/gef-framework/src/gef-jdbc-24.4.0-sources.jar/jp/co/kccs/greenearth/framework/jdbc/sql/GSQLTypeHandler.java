/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;

import jp.co.kccs.greenearth.commons.exception.GIllegalTypeException;
import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam.ParamMode;

/**
 * カラムのタイプにより処理を振り分けるインタフェースです。
 * 
 * @author KCCS kitamura
 * @create 2012/10/29
 * @since 3.12.0
 */
public interface GSQLTypeHandler {

	/**
	 * カラム名を指定して結果セットから値を取得します。
	 * 
	 * @param resultSet 結果セット
	 * @param key カラム名
	 * @param type カラムのタイプ
	 * @return 結果セットから取得した値
	 * @throws SQLException 値の取得に失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException;
	
	/**
	 * インデックスを指定して結果セットから値を取得します。
	 * <p>
	 * インデックスの開始値は1です。
	 * 
	 * @param resultSet 結果セット
	 * @param index インデックス
	 * @param type カラムのタイプ
	 * @return 結果セットから取得した値
	 * @throws SQLException 値の取得に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2013/02/13
	 * @since 3.12.0
	 */
	Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException;

	/**
	 * {@link PreparedStatement}に値をバインドします。
	 * <p>
	 * インデックスの開始値は1です。
	 * 
	 * @param ps {@link PreparedStatement}
	 * @param index インデックス
	 * @param param バインドする値
	 * @throws SQLException パラメータのバインドに失敗した場合
	 * @author KCCS hashimoto
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	void bindValue(PreparedStatement ps, int index, GBindParam param) throws SQLException;

	/**
	 * {@link CallableStatement}に値バインドします。
	 * <p>
	 * インデックスの開始値は1です。
	 * 
	 * @param cs {@link CallableStatement}
	 * @param index インデックス
	 * @param param バインドする値
	 * @throws SQLException パラメータのバインドに失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException;

	/**
	 * ストアドファンクション、ストアドプロシージャの実行結果を取得します。
	 * <p>
	 * インデックスの開始値は1です。
	 * 
	 * @param <T> 戻り値の型
	 * @param cs ステートメント
	 * @param index インデックス
	 * @param param バインドする値
	 * @return 実行結果
	 * @throws SQLException 実行結果の取得に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	<T> T getValue(CallableStatement cs, int index, GBindParam param) throws SQLException;

	/**
	 * ハンドラのSQLタイプを取得します。
	 * @return ハンドラのSQLタイプ
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	int getSQLType();

	/**
	 * エンティティー定義で定義されたカラムのタイプがVarcharの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class VarcharHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.VARCHAR;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getString(key);
		}
		
		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getString(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof String) {
				statement.setString(index, (String) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof String) {
					cs.setString(index, (String) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public String getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getString(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがCharの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class CharHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.CHAR;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getString(key);
		}
		
		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getString(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof String) {
				statement.setString(index, (String) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof String) {
					cs.setString(index, (String) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public String getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getString(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがLongの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class LongVarcharHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.LONGVARCHAR;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getString(key);
		}
		
		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getString(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof String) {
				statement.setString(index, (String) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof String) {
					cs.setString(index, (String) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public String getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getString(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがBooleanの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class BooleanHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public int SQL_TYPE = Types.BIT;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getBoolean(key);
		}
		
		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getBoolean(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Boolean) {
				statement.setBoolean(index, (Boolean) value);
			} else if (value instanceof Number) {
				Number num = (Number) value;
				statement.setBoolean(index, num.byteValue() == 0 ? false : true);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Boolean) {
					cs.setBoolean(index, (Boolean) value);
				} else if (value instanceof Number) {
					Number num = (Number) value;
					cs.setBoolean(index, num.byteValue() == 0 ? false : true);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Boolean getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getBoolean(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがNumericの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class NumericHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.NUMERIC;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getBigDecimal(key);
		}
		
		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getBigDecimal(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof BigDecimal) {
				statement.setBigDecimal(index, (BigDecimal) value);
			} else if (value instanceof Integer || value instanceof Long || value instanceof Short
				|| value instanceof Byte) {
				long num = ((Number) value).longValue();
				statement.setBigDecimal(index, BigDecimal.valueOf(num));
			} else if (value instanceof Double || value instanceof Float) {
				double num = ((Number) value).doubleValue();
				statement.setBigDecimal(index, BigDecimal.valueOf(num));
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof BigDecimal) {
					cs.setBigDecimal(index, (BigDecimal) value);
				} else if (value instanceof Integer || value instanceof Long || value instanceof Short
					|| value instanceof Byte) {
					long num = ((Number) value).longValue();
					cs.setBigDecimal(index, BigDecimal.valueOf(num));
				} else if (value instanceof Double || value instanceof Float) {
					double num = ((Number) value).doubleValue();
					cs.setBigDecimal(index, BigDecimal.valueOf(num));
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public BigDecimal getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getBigDecimal(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがByteの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class ByteHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.TINYINT;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getByte(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getByte(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Number) {
				Number num = (Number) value;
				statement.setByte(index, num.byteValue());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Number) {
					Number num = (Number) value;
					cs.setByte(index, num.byteValue());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Byte getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getByte(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがShortの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class ShortHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.SMALLINT;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getShort(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getShort(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Number) {
				Number num = (Number) value;
				statement.setShort(index, num.shortValue());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Number) {
					Number num = (Number) value;
					cs.setShort(index, num.shortValue());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Short getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getShort(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがIntegerの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class IntegerHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.INTEGER;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getInt(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getInt(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Number) {
				Number num = (Number) value;
				statement.setInt(index, num.intValue());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Number) {
					Number num = (Number) value;
					cs.setInt(index, num.intValue());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Integer getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getInt(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがLongの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class LongHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.BIGINT;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getLong(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getLong(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Number) {
				Number num = (Number) value;
				statement.setLong(index, num.longValue());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Number) {
					Number num = (Number) value;
					cs.setLong(index, num.longValue());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Long getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getLong(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがFloatの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class FloatHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public int SQL_TYPE = Types.FLOAT;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getFloat(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getFloat(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Number) {
				Number num = (Number) value;
				statement.setFloat(index, num.floatValue());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Number) {
					Number num = (Number) value;
					cs.setFloat(index, num.floatValue());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Float getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getFloat(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがDoubleの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class DoubleHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.DOUBLE;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getDouble(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getDouble(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Number) {
				Number num = (Number) value;
				statement.setDouble(index, num.doubleValue());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Number) {
					Number num = (Number) value;
					cs.setDouble(index, num.doubleValue());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Double getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getDouble(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがDateの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class DateHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.DATE;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getTimestamp(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getTimestamp(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Timestamp) {
				statement.setTimestamp(index, (Timestamp) value);
			} else if (value instanceof Date) {
				statement.setTimestamp(index, new Timestamp(((Date) value).getTime()));
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Timestamp) {
					cs.setTimestamp(index, (Timestamp) value);
				} else if (value instanceof Date) {
					cs.setTimestamp(index, new Timestamp(((Date) value).getTime()));
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Date getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getDate(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがTimestampの場合の処理を表すクラスです。
	 * 
	 * @author KCCS kitamura
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class TimestampHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.TIMESTAMP;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getTimestamp(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getTimestamp(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof Timestamp) {
				statement.setTimestamp(index, (Timestamp) value);
			} else if (value instanceof Date) {
				statement.setTimestamp(index, new Timestamp(((Date) value).getTime()));
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof Timestamp) {
					cs.setTimestamp(index, (Timestamp) value);
				} else if (value instanceof Date) {
					cs.setTimestamp(index, new Timestamp(((Date) value).getTime()));
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Timestamp getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getTimestamp(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがBlobの場合の処理を表すクラスです。
	 * 
	 * @author KCCS hashimoto
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class BlobHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.BLOB;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getBlob(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getBlob(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof InputStream) {
				statement.setBinaryStream(index, (InputStream) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof InputStream) {
					cs.setBinaryStream(index, (InputStream) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Blob getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getBlob(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがClobの場合の処理を表すクラスです。
	 * 
	 * @author KCCS hashimoto
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class ClobHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.CLOB;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet.getClob(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet.getClob(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof InputStream) {
				InputStreamReader reader = new InputStreamReader((InputStream) value);
				statement.setCharacterStream(index, reader);
			} else if (value instanceof Reader) {
				statement.setCharacterStream(index, (Reader) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof InputStream) {
					InputStreamReader reader = new InputStreamReader((InputStream) value);
					cs.setCharacterStream(index, reader);
				} else if (value instanceof Reader) {
					cs.setCharacterStream(index, (Reader) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Clob getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getClob(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがBinaryの場合の処理を表すクラスです。
	 * 
	 * @author KCCS hashimoto
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class BinaryHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public int SQL_TYPE = Types.BLOB;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {

			Blob blob = resultSet.getBlob(key);
			byte[] bytes = blob.getBytes(1, (int) blob.length());

			return bytes;
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			Blob blob = resultSet.getBlob(index);
			byte[] bytes = blob.getBytes(1, (int) blob.length());

			return bytes;
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof byte[]) {
				statement.setBytes(index, (byte[]) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof byte[]) {
					cs.setBytes(index, (byte[]) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public byte[] getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getBytes(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがTextの場合の処理を表すクラスです。
	 * 
	 * @author KCCS hashimoto
	 * @create 2012/10/29
	 * @since 3.12.0
	 */
	public static class TextHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.CLOB;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			Clob clob = resultSet.getClob(key);
			int length = (int) clob.length();
			return clob.getSubString(1, length);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			Clob clob = resultSet.getClob(index);
			int length = (int) clob.length();
			return clob.getSubString(1, length);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof String) {
				statement.setString(index, (String) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof String) {
					cs.setString(index, (String) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public String getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getString(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがResultSetの場合の処理を表す基底クラスです。
	 * 
	 * @author KCCS K.Fujita
	 * @create 2013/02/07
	 * @since 3.12.0
	 */
	public static class ResultSetHandlerBase implements GSQLTypeHandler {

		@Override
		public int getSQLType() {
			return 0;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			return resultSet;
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			return resultSet;
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			return;
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return;
		}

		@SuppressWarnings("unchecked")
		@Override
		public ResultSet getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			if (cs.getResultSet() != null) {
				return cs.getResultSet();
			}
			return (ResultSet) cs.getObject(index);
		}
	}

}
