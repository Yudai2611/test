/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;

/**
 * {@link GSQLTypeHandler}を実装する基底クラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/01
 * @since 3.12.0
 */
public abstract class GSQLTypeHandlerBase implements GSQLTypeHandler {

	/** タイプ別のハンドラークラスを保持するマップ */
	public Map<GColumnType, GSQLTypeHandler> handlerMap = new HashMap<GColumnType, GSQLTypeHandler>();

	/**
	 * GSQLTypeHandlerBaseのインスタンスを生成します.
	 * 
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public GSQLTypeHandlerBase() {
		handlerMap.put(GColumnType.VARCHAR, new GSQLTypeHandler.VarcharHandler());
		handlerMap.put(GColumnType.CHAR, new GSQLTypeHandler.CharHandler());
		handlerMap.put(GColumnType.LONGVARCHAR, new GSQLTypeHandler.LongVarcharHandler());
		handlerMap.put(GColumnType.BOOLEAN, new GSQLTypeHandler.BooleanHandler());
		handlerMap.put(GColumnType.NUMERIC, new GSQLTypeHandler.NumericHandler());
		handlerMap.put(GColumnType.INTEGER, new GSQLTypeHandler.IntegerHandler());
		handlerMap.put(GColumnType.LONG, new GSQLTypeHandler.LongHandler());
		handlerMap.put(GColumnType.FLOAT, new GSQLTypeHandler.FloatHandler());
		handlerMap.put(GColumnType.DOUBLE, new GSQLTypeHandler.DoubleHandler());
		handlerMap.put(GColumnType.BYTE, new GSQLTypeHandler.ByteHandler());
		handlerMap.put(GColumnType.SHORT, new GSQLTypeHandler.ShortHandler());
		handlerMap.put(GColumnType.DATE, new GSQLTypeHandler.DateHandler());
		handlerMap.put(GColumnType.TIMESTAMP, new GSQLTypeHandler.TimestampHandler());
		handlerMap.put(GColumnType.BLOB, new GSQLTypeHandler.BlobHandler());
		handlerMap.put(GColumnType.CLOB, new GSQLTypeHandler.ClobHandler());
		handlerMap.put(GColumnType.BINARY, new GSQLTypeHandler.BinaryHandler());
		handlerMap.put(GColumnType.TEXT, new GSQLTypeHandler.TextHandler());
	}

	/**
	 * GSQLTypeHandlerBaseのインスタンスを生成します.
	 * 
	 * @param addMap {@link GSQLTypeHandler}のインスタンスを保持するマップ
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	public GSQLTypeHandlerBase(Map<String, GSQLTypeHandler> addMap) {
		for (Entry<String, GSQLTypeHandler> entry : addMap.entrySet()) {
			handlerMap.put(GColumnType.valueOf(entry.getKey()), entry.getValue());
		}
	}

	@Override
	public int getSQLType() {
		return 0;
	}

	@Override
	public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
		// 型未指定
		if (type == null) {
			return getNoTypeValue(resultSet, key);
		}
		if (!handlerMap.containsKey(type)) {
			throw new IllegalArgumentException("It cannot get a value with the specified type. :" + key);
		}

		return handlerMap.get(type).getValue(resultSet, key, type);
	}

	@Override
	public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
		// 型未指定
		if (type == null) {
			return getNoTypeValue(resultSet, index);
		}
		if (!handlerMap.containsKey(type)) {
			throw new IllegalArgumentException("It cannot get a value with the specified type. :" + index);
		}

		return handlerMap.get(type).getValue(resultSet, index, type);
	}

	@Override
	public void bindValue(PreparedStatement ps, int index, GBindParam param) throws SQLException {
		GColumnType type = param.getType();
		
		// 型未指定
		if (type == null) {
			bindNoTypeValue(ps, index, param);
			return;
		}
		if (!handlerMap.containsKey(type)) {
			throw new IllegalArgumentException("This type is not allowed. :" + param.getType());
		}
		
		handlerMap.get(type).bindValue(ps, index, param);
	}

	@Override
	public <T> T getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
		GColumnType columnType = param.getType();
		
		// 型未指定
		if (columnType == null) {
			return getNoTypeValue(cs, index);
		}
		if (!handlerMap.containsKey(columnType)) {
			throw new IllegalArgumentException("This type is not allowed. :" + columnType);
		}
		
		return handlerMap.get(columnType).getValue(cs, index, param);
	}
	
	@Override
	public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
		GColumnType columnType = param.getType();
		// 型未指定
		if (columnType == null) {
			bindNoTypeValue(cs, index, param);
			return;
		}
		if (!handlerMap.containsKey(columnType)) {
			throw new IllegalArgumentException("This type is not allowed. :" + columnType);
		}
		
		handlerMap.get(columnType).bindValue(cs, index, param);
	}

	/**
	 * タイプ指定のない項目の値を{@link PreparedStatement}にバインドします.
	 * 
	 * @param ps {@link PreparedStatement}のインスタンス
	 * @param index PreparedStatementのバインドに利用するインデックス
	 * @param param バインドする値
	 * @throws SQLException バインド実行時のエラー
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected void bindNoTypeValue(PreparedStatement ps, int index, GBindParam param) throws SQLException {
		Object value = param.getValue();
		if (value == null) {
			ps.setNull(index, Types.VARCHAR);
		} else if (value instanceof Timestamp) {
			handlerMap.get(GColumnType.TIMESTAMP).bindValue(ps, index, param);
		} else if (value instanceof Date) {
			handlerMap.get(GColumnType.DATE).bindValue(ps, index, param);
		} else {
			ps.setObject(index, param.getValue());
		}
	}

	/**
	 * タイプ指定のない項目の値を結果セットより取得します.
	 * 
	 * @param resultSet 結果セット
	 * @param key 結果セットの項目名
	 * @return 結果セットから取得した値
	 * @throws SQLException 値取得時のエラー
	 * @author KCCS hashimoto
	 * @create 2012/12/04
	 * @since 3.12.0
	 */
	protected Object getNoTypeValue(ResultSet resultSet, String key) throws SQLException {
		// 式指定等でGColumnが取得できない場合はそのまま設定
		return resultSet.getObject(key);
	}
	
	/**
	 * タイプ指定のない項目の値を結果セットより取得します.
	 * 
	 * @param resultSet 結果セット
	 * @param index インデックス
	 * @return 結果セットから取得した値
	 * @throws SQLException 値取得時のエラー
	 * @author KCCS K.Fujita
	 * @create 2013/02/13
	 * @since 3.12.0
	 */
	protected Object getNoTypeValue(ResultSet resultSet, int index) throws SQLException {
		// 式指定等でGColumnが取得できない場合はそのまま設定
		return resultSet.getObject(index);
	}
	
	/**
	 * タイプ指定のない項目の値を{@link CallableStatement}へバインドします.
	 * 
	 * @param cs {@link CallableStatement}
	 * @param index インデックス
	 * @param param バインドパラメータ
	 * @throws SQLException パラメータのバインドに失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	protected void bindNoTypeValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
		Object value = param.getValue();
		if (value == null) {
			cs.setNull(index, Types.VARCHAR);
		} else if (value instanceof Timestamp) {
			handlerMap.get(GColumnType.TIMESTAMP).bindValue(cs, index, param);
		} else if (value instanceof Date) {
			handlerMap.get(GColumnType.DATE).bindValue(cs, index, param);
		} else {
			cs.setObject(index, param.getValue());
		}
	}

	/**
	 * タイプ指定のない項目の、ストアドファンクション／ストアドプロシージャの実行結果を取得します.
	 * 
	 * @param <T> 戻り値の型
	 * @param cs {@link CallableStatement}
	 * @param index インデックス
	 * @return 実行結果の値
	 * @throws SQLException 実行結果の取得に失敗した場合
	 * @author KCCS K.Fujita
	 * @create 2012/12/25
	 * @since 3.12.0
	 */
	protected <T> T getNoTypeValue(CallableStatement cs, int index) throws SQLException {
		// 式指定等でGColumnが取得できない場合はそのまま設定
		@SuppressWarnings("unchecked")
		T value = (T) cs.getObject(index);
		return value;
	}
}
