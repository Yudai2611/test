/*
 * Copyright 2016-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;

/**
 * {@link GSQLTypeHandlerMySQLBase}をMySQL8.0用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GSQLTypeHandlerMySQL8_0 extends GSQLTypeHandlerMySQLBase {
	
	/**
	 * {@link GSQLTypeHandlerMySQL8_0}のインスタンスを生成します.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GSQLTypeHandlerMySQL8_0() {
		super();
		super.handlerMap.put(GColumnType.RESULTSET, new ResultSetHandlerMySQL8_0());
	}
	
	/**
	 * {@link GSQLTypeHandlerMySQL8_0}のインスタンスを生成します.
	 * 
	 * @param addMap {@link GSQLTypeHandler}のインスタンスを保持するマップ
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GSQLTypeHandlerMySQL8_0(Map<String, GSQLTypeHandler> addMap) {
		super(addMap);
	}
	
	/**
	 * エンティティー定義で定義されたカラムのタイプがResultSetの場合のMySQL8.0用の処理を表すクラスです.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public static class ResultSetHandlerMySQL8_0 extends ResultSetHandlerBase {
		// NOTE : MySQLはパラメータで結果セットを返すことができないため実装なし
	}
}
