/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GSQLTypeHandlerBase}をMySQL用に実装する基底クラスです.
 * 
 * @author KCCS hashimoto
 * @create 2016/05/11
 * @since 3.18.0
 */
public abstract class GSQLTypeHandlerMySQLBase extends GSQLTypeHandlerBase {
	
	/**
	 * {@link GSQLTypeHandlerMySQLBase}のインスタンスを生成します.
	 * 
	 * @author KCCS hashimoto
	 * @create 2016/05/11
	 * @since 3.18.0
	 */
	public GSQLTypeHandlerMySQLBase() {
		super();
	}
	
	/**
	 * {@link GSQLTypeHandlerMySQLBase}のインスタンスを生成します.
	 * 
	 * @param addMap {@link GSQLTypeHandler}のインスタンスを保持するマップ
	 * @author KCCS kitamura
	 * @create 2012/12/09
	 * @since 3.12.0
	 */
	public GSQLTypeHandlerMySQLBase(Map<String, GSQLTypeHandler> addMap) {
		super(addMap);
	}
}
