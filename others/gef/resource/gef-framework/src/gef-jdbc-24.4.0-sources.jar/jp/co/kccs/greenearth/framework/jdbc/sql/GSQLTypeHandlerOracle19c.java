/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.Map;

import jp.co.kccs.greenearth.framework.jdbc.GColumnType;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam.ParamMode;
import oracle.jdbc.OracleTypes;

/**
 * {@link GSQLExecuterOracleBase}をOracle19c用に実装するクラスです.
 * 
 * @author KCCS okanishi
 * @create 2021/3/31
 * @since 21.3.0
 */
public class GSQLTypeHandlerOracle19c extends GSQLTypeHandlerOracleBase {

	/**
	 * {@link GSQLTypeHandlerOracle19c}のインスタンスを生成します.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GSQLTypeHandlerOracle19c() {
		super();
		super.handlerMap.put(GColumnType.RESULTSET, new ResultSetHandlerOracle19c());
	}

	/**
	 * {@link GSQLTypeHandlerOracle19c}のインスタンスを生成します.
	 * 
	 * @param addMap {@link GSQLTypeHandler}のインスタンスを保持するマップ
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public GSQLTypeHandlerOracle19c(Map<String, GSQLTypeHandler> addMap) {
		super(addMap);
	}
	
	/**
	 * エンティティー定義で定義されたカラムのタイプがResultSetの場合のOracle19c用の処理を表すクラスです.
	 * 
	 * @author KCCS okanishi
	 * @create 2021/3/31
	 * @since 21.3.0
	 */
	public static class ResultSetHandlerOracle19c extends ResultSetHandlerBase {
		/** タイプを表す定数 */
		public static final int SQL_TYPE = OracleTypes.CURSOR;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}
		
		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			ParamMode mode = param.getParamMode();
			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
			return;
		}
	}
}
