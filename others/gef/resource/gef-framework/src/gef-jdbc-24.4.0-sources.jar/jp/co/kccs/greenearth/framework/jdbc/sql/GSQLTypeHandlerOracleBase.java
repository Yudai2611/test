/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

/**
 * {@link GSQLTypeHandlerBase}をOracle用に実装する基底クラスです.
 * 
 * @author KCCS Hashimoto
 * @create 2016/08/30
 * @since 3.19.0
 */
public abstract class GSQLTypeHandlerOracleBase extends GSQLTypeHandlerBase {

	/**
	 * {@link GSQLTypeHandlerOracleBase}のインスタンスを生成します.
	 * 
	 * @author KCCS Hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public GSQLTypeHandlerOracleBase() {
		super();
	}

	/**
	 * {@link GSQLTypeHandlerOracleBase}のインスタンスを生成します.
	 * 
	 * @param addMap {@link GSQLTypeHandler}のインスタンスを保持するマップ
	 * @author KCCS Hashimoto
	 * @create 2016/08/30
	 * @since 3.19.0
	 */
	public GSQLTypeHandlerOracleBase(Map<String, GSQLTypeHandler> addMap) {
		super(addMap);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Object getNoTypeValue(ResultSet resultSet, String key) throws SQLException {
		// 式指定等でGColumnが取得できない場合はそのまま設定
		Object value = resultSet.getObject(key);
		// NOTE : OracleのTimestamp型はjava.sql.Timestampではなくoracle.sql.TIMESTAMPを返すための対応
		if (value instanceof oracle.sql.TIMESTAMP) {
			value = resultSet.getTimestamp(key);
		} else if (value instanceof oracle.sql.TIMESTAMPTZ) {
			value = resultSet.getTimestamp(key);
		}
		return value;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Object getNoTypeValue(ResultSet resultSet, int index) throws SQLException {
		// 式指定等でGColumnが取得できない場合はそのまま設定
		Object value = resultSet.getObject(index);
		// NOTE : OracleのTimestamp型はjava.sql.Timestampではなくoracle.sql.TIMESTAMPを返すための対応
		if (value instanceof oracle.sql.TIMESTAMP) {
			value = resultSet.getTimestamp(index);
		} else if (value instanceof oracle.sql.TIMESTAMPTZ) {
			value = resultSet.getTimestamp(index);
		}
		return value;
	}
}
