/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import jp.co.kccs.greenearth.commons.exception.GIllegalTypeException;
import jp.co.kccs.greenearth.framework.jdbc.GColumnType;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialClob;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.*;
import java.util.Map;
import jp.co.kccs.greenearth.framework.jdbc.sql.GBindParam.ParamMode;

/**
 * {@link GSQLTypeHandlerPostgreSQLBase}をPostgreSQL13.2用に実装するクラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public class GSQLTypeHandlerPostgreSQL13_2 extends GSQLTypeHandlerPostgreSQLBase {

	/**
	 * {@link GSQLTypeHandlerPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLTypeHandlerPostgreSQL13_2() {
		super();
		super.handlerMap.put(GColumnType.RESULTSET, new ResultSetHandlerPostgreSQL13_2());
		super.handlerMap.put(GColumnType.BINARY, new BinaryHandler());
		super.handlerMap.put(GColumnType.BLOB, new BlobHandler());
		super.handlerMap.put(GColumnType.TEXT, new TextHandler());
		super.handlerMap.put(GColumnType.CLOB, new ClobHandler());
		super.handlerMap.put(GColumnType.FLOAT, new FloatHandler());
	}

	/**
	 * {@link GSQLTypeHandlerPostgreSQL13_2}のインスタンスを生成します.
	 *
	 * @param addMap {@link GSQLTypeHandler}のインスタンスを保持するマップ
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLTypeHandlerPostgreSQL13_2(Map<String, GSQLTypeHandler> addMap) {
		super(addMap);
	}
	
	/**
	 * エンティティー定義で定義されたカラムのタイプがResultSetの場合のPostgreSQL13.2用の処理を表すクラスです.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class ResultSetHandlerPostgreSQL13_2 extends ResultSetHandlerBase {
		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.REF_CURSOR;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			ParamMode mode = param.getParamMode();
			if (ParamMode.INOUT.equals(mode)) { // INOUTパラメータの型の設定
				cs.setNull(index, Types.OTHER);
			}
			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
			return;
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがFloatの場合の処理を表すクラスです。
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class FloatHandler extends GSQLTypeHandler.FloatHandler{

		/** タイプを表す定数 */
		public int SQL_TYPE = Types.REAL;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがClobの場合の処理を表すクラスです。
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class ClobHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.VARCHAR;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			String text = resultSet.getString(key);
			if(text != null){
				return new SerialClob(text.toCharArray());
			}
			return null;
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			String text = resultSet.getString(index);
			if(text != null){
				return new SerialClob(text.toCharArray());
			}
			return null;
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {

			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof InputStream) {
				InputStreamReader reader = new InputStreamReader((InputStream) value);
				statement.setCharacterStream(index, reader);
			} else if (value instanceof Reader) {
				statement.setCharacterStream(index, (Reader) value);
			} else if (value instanceof Clob) {
				statement.setCharacterStream(index, ((Clob)value).getCharacterStream());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof InputStream) {
					InputStreamReader reader = new InputStreamReader((InputStream) value);
					cs.setCharacterStream(index, reader);
				} else if (value instanceof Reader) {
					cs.setCharacterStream(index, (Reader) value);
				} else if (value instanceof Clob) {
					cs.setCharacterStream(index, ((Clob)value).getCharacterStream());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Clob getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			String text = cs.getString(index);
			if(text != null){
				return new SerialClob(text.toCharArray());
			}
			return null;
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがTextの場合の処理を表すクラスです。
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class TextHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.VARCHAR;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			String text = resultSet.getString(key);
			return text;
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			String text = resultSet.getString(index);
			return text;
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof String) {
				statement.setString(index, (String) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof String) {
					cs.setString(index, (String) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public String getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getString(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがBinaryの場合の処理を表すクラスです。
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class BinaryHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public int SQL_TYPE = Types.BINARY;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {

			return resultSet.getBytes(key);
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {

			return resultSet.getBytes(index);
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof byte[]) {
				statement.setBytes(index, (byte[]) value);
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof byte[]) {
					cs.setBytes(index, (byte[]) value);
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public byte[] getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			return cs.getBytes(index);
		}
	}

	/**
	 * エンティティー定義で定義されたカラムのタイプがBlobの場合の処理を表すクラスです。
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class BlobHandler implements GSQLTypeHandler {

		/** タイプを表す定数 */
		public static final int SQL_TYPE = Types.BINARY;

		@Override
		public int getSQLType() {
			return SQL_TYPE;
		}

		@Override
		public Object getValue(ResultSet resultSet, String key, GColumnType type) throws SQLException {
			if(resultSet.getBinaryStream(key) != null){
				try {
					return new SerialBlob(resultSet.getBinaryStream(key).readAllBytes());
				} catch (IOException e) {
					throw new SQLException(e);
				}
			}
			return null;
		}

		@Override
		public Object getValue(ResultSet resultSet, int index, GColumnType type) throws SQLException {
			if(resultSet.getBinaryStream(index) != null){
				try {
					return new SerialBlob(resultSet.getBinaryStream(index).readAllBytes());
				} catch (IOException e) {
					throw new SQLException(e);
				}
			}
			return null;
		}

		@Override
		public void bindValue(PreparedStatement statement, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			if (value == null) {
				statement.setNull(index, getSQLType());
			} else if (value instanceof InputStream) {
				statement.setBinaryStream(index, (InputStream) value);
			} else if (value instanceof Blob) {
				statement.setBinaryStream(index, ((Blob)value).getBinaryStream());
			} else {
				throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
			}
		}

		@Override
		public void bindValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			Object value = param.getValue();
			ParamMode mode = param.getParamMode();

			if (ParamMode.IN.equals(mode) || ParamMode.INOUT.equals(mode)) { // INパラメータの設定
				if (value == null) {
					cs.setNull(index, getSQLType());
				} else if (value instanceof InputStream) {
					cs.setBinaryStream(index, (InputStream) value);
				} else if (value instanceof Blob) {
					cs.setBinaryStream(index, ((Blob)value).getBinaryStream());
				} else {
					throw new GIllegalTypeException("Bound illegal type! : " + value.getClass());
				}
			}

			if (ParamMode.OUT.equals(mode) || ParamMode.INOUT.equals(mode)) { // OUTパラメータの型の設定
				cs.registerOutParameter(index, getSQLType());
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public Blob getValue(CallableStatement cs, int index, GBindParam param) throws SQLException {
			if(cs.getBytes(index) != null){
				return new SerialBlob(cs.getBytes(index));
			}
			return null;
		}
	}
}
