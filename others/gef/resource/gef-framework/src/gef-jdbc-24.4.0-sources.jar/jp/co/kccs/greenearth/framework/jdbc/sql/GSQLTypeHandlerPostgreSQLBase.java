/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import java.util.Map;

/**
 * {@link GSQLTypeHandlerBase}をPostgreSQL用に実装する基底クラスです.
 *
 * @author KCSS
 * @create 2021/09/30
 * @since 21.9.0
 */
public abstract class GSQLTypeHandlerPostgreSQLBase extends GSQLTypeHandlerBase {

	/**
	 * {@link GSQLTypeHandlerPostgreSQLBase}のインスタンスを生成します.
	 *
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLTypeHandlerPostgreSQLBase() {
		super();
	}

	/**
	 * {@link GSQLTypeHandlerPostgreSQLBase}のインスタンスを生成します.
	 *
	 * @param addMap {@link GSQLTypeHandler}のインスタンスを保持するマップ
	 * @author KCSS
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GSQLTypeHandlerPostgreSQLBase(Map<String, GSQLTypeHandler> addMap) {
		super(addMap);
	}
}
