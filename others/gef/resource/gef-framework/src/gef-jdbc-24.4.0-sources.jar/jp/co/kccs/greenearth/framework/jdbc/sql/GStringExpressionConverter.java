/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

import jp.co.kccs.greenearth.framework.jdbc.GReplaceExpression;
import jp.co.kccs.greenearth.framework.jdbc.GStringExpression;

/**
 * {@link GStringExpression}を文字列に変換する機能を提供する基底クラスです.
 * 
 * @author KCCS kitamura
 * @create 2012/12/05
 * @since 3.12.0
 * 
 */
public class GStringExpressionConverter extends GReplaceExpressionConverterBase {

    /**
     * {@link GStringExpressionConverter}を初期化します.
     * 
	 * @author KCCS kitamura
	 * @create 2012/12/05
	 * @since 3.12.0
     */
	public GStringExpressionConverter() {
	}

	@Override
	protected String createSource(GReplaceExpression exp) {
		GStringExpression nexp = (GStringExpression) exp;
		return nexp.getSource();
	}
}
