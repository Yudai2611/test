/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.jdbc.sql;

/**
 * 一意制約違反を表す例外クラスです.
 * 
 * @author KCCS K.Fujita
 * @create 2012/12/05
 * @since 3.12.0
 *
 */
public class GUniqueConstraintException extends GConstraintViolationException {

	/** シリアルバージョンUID	 */
	private static final long serialVersionUID = 961946673648950728L;
	
	/**
	 * 指定された情報で{@link GUniqueConstraintException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUniqueConstraintException(String reason) {
		super(reason);
	}
	
	/**
	 * 指定された情報で{@link GUniqueConstraintException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUniqueConstraintException(String reason, String sqlState) {
		super(reason, sqlState);
	}
	
	/**
	 * 指定された情報で{@link GUniqueConstraintException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @param vendorCode データベースベンダー固有の例外コード
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUniqueConstraintException(String reason, String sqlState, int vendorCode) {
		super(reason, sqlState, vendorCode);
	}
	
	/**
	 * 指定された情報で{@link GUniqueConstraintException}インスタンスを初期化します.
	 * 
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUniqueConstraintException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * 指定された情報で{@link GUniqueConstraintException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUniqueConstraintException(String reason, Throwable cause) {
		super(reason, cause);
	}
	
	/**
	 * 指定された情報で{@link GUniqueConstraintException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUniqueConstraintException(String reason, String sqlState, Throwable cause) {
		super(reason, sqlState, cause);
	}
	
	/**
	 * 指定された情報で{@link GConstraintViolationException}インスタンスを初期化します.
	 * 
	 * @param reason 例外の説明
	 * @param sqlState 例外を識別するXOPEN コードまたは SQL:2003 コード
	 * @param vendorCode データベースベンダー固有の例外コード
	 * @param cause この例外の基となる原因
	 * @author KCCS K.Fujita
	 * @create 2012/12/05
	 * @since 3.12.0
	 */
	public GUniqueConstraintException(String reason, String sqlState, int vendorCode, Throwable cause) {
		super(reason, sqlState, vendorCode, cause);
	}

}
