/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.exception;

/**
 * 対象のクラスやメソッドがサポートされていない（実装されていない）事を表す例外です。
 * 
 * @create 2007/12/10
 * @author kitamura
 * @since 3.9.0
 */
public class GNotSupportedException extends RuntimeException {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 6787443649350729152L;

	/**
	 * {@link GNotSupportedException}のインスタンスを初期化します.
	 * 
	 * @create 2007/12/10
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GNotSupportedException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GNotSupportedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/02/07
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GNotSupportedException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GNotSupportedException}のインスタンスを初期化します.
	 * 
	 * @create 2011/02/07
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GNotSupportedException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GNotSupportedException}のインスタンスを初期化します。
	 * 
	 * @create 2010/10/22
	 * @param message 例外メッセージ
	 * @param cause 発生原因となった例外
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GNotSupportedException(String message, Throwable cause) {
		super(message, cause);
	}
}
