/*
 * Copyright 2007-2008 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 特定のURLの適応除外を設定できるフィルターを提供します. <br>
 * サーブレット初期化パラメータにてフィルター適用除外URLを指定します.<br>
 * 認証チェック適用除外URLはweb.xml以下のように記述します。<br><br>
 * 
 * ・web.xml
 * <pre>
 * &lt;filter&gt;
 *    &lt;filter-name&gt;FooFilter&lt;/filter-name&gt;
 *    &lt;filter-class&gt;sample.FooFilter&lt;/filter-class&gt;
 *       &lt;init-param&gt;
 *          &lt;param-name&gt;exclude-url/hoge&lt;/param-name&gt;
 *          &lt;param-value&gt;/hoge.action&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *    &lt;init-param&gt;
 *       &lt;param-name&gt;exclude-url/fuga&lt;/param-name&gt;
 *       &lt;param-value&gt;/fuga.jsp&lt;/param-value&gt;
 *    &lt;/init-param&gt;
 * &lt;/filter&gt;
 * 
 * &lt;filter-mapping&gt;
 *    &lt;filter-name&gt;FooFilter&lt;/filter-name&gt;
 *    &lt;url-pattern&gt;*&lt;/url-pattern&gt;
 * &lt;/filter-mapping&gt; 
 * </pre>
 * ※sample.FooFilterは{@link GExcludableFilter}を継承しています。
 * 
 * @create 2007/02/14
 * @author kitamura
 * @since 3.0.0
 */
public abstract class GExcludableFilter implements Filter {

	/** 認証チェック適用除外URL{@link Map}. */
	private Map<String, String> excludeUrlMap = new HashMap<String, String>();

	/**
	 * フィルターのサービス状態終了時の処理です.
	 * 
	 * @create 2007/02/14
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void destroy() {
		excludeUrlMap.clear();
	}

	/**
	 * フィルタの適用を行います.<br>
	 * 指定された要求がフィルター適用除外URLに指定されている場合にのみ{@link #doFilter(HttpServletRequest, HttpServletResponse, FilterChain)}
	 * を呼び出しています
	 * 
	 * @see jakarta.servlet.Filter#doFilter(jakarta.servlet.ServletRequest, jakarta.servlet.ServletResponse, jakarta.servlet.FilterChain)
	 * @create 2007/03/31
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain FilterChain
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		if (!getExcludeUrlMap().containsKey(httpRequest.getServletPath())) {
			doFilter(httpRequest, httpResponse, chain);
		} else {
			// Pass control on to the next filter
			chain.doFilter(request, response);
		}
	}

	/**
	 * 指定された要求がフィルター適用除外URLに指定されている場合に実行する処理です.
	 * 
	 * @create 2007/03/31
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain FilterChain
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException;

	/**
	 * 認証チェック適用除外URL{@link Map}を取得します.
	 * 
	 * @create 2007/02/14
	 * @return 認証チェック適用除外URLマップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Map<String, String> getExcludeUrlMap() {
		return excludeUrlMap;
	}

	/**
	 * フィルターのサービス状態終了時の処理です.<br>
	 * フィルター初期化パラメータで指定された認証チェック適用除外URLを保持します。<br>
	 * 
	 * @create 2007/02/14
	 * @param filterConfig フィルタ設定情報
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		Enumeration< ? > names = filterConfig.getInitParameterNames();
		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			if (!name.startsWith("exclude-url/")) {
				continue;
			}
			String url = filterConfig.getInitParameter(name);
			excludeUrlMap.put(url, url);
		}
	}

	/**
	 * 認証チェック適用除外URL{@link Map}を設定します.
	 * 
	 * @create 2007/02/14
	 * @param excludeUrlMap 認証チェック認証適用除外URLマップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setExcludeUrlMap(Map<String, String> excludeUrlMap) {
		this.excludeUrlMap = excludeUrlMap;
	}
}
