/*
 * Copyright 2009-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.IOException;
import java.util.Locale;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.framework.action.GActionInvoker;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateException;

/**
 * リクエストパラメータを元に、任意のアクションを呼び出すサーブレットです。<br>
 * <br>
 * <b>【処理概要】</b><br>
 * 　GreenEARTH Frameworkは、クライアントから受けたリクエストパラメータを基に、
 * 指定されたビジネスロジックを実行し、その結果をレスポンスとしてクライアントに返すための流れを自動化します。<br>
 * これにより、利用者は、リクエストとして送信するパラメータのセットと、
 * ビジネスロジックの実装のみを行うだけで、Webアプリケーションを構築することができます。<br>
 * 
 * <br>
 * <b>【アクションの実行ルール】</b><br>
 * 　{@link GActionServlet}は特定のルールに則り、リクエストに応じた任意のビジネスロジックを実行します。<br>
 * アクションはJAVAのクラスで表現され、基本的に作成するアプリケーションの要件に合わせて利用者が作成する必要があります。<br>
 * <br>
 * ◆アクションメソッドの指定<br>
 * 　コントローラはリクエスト内に積まれたパラメータの内容を基に、以下のルールに従ってアクションを選定し実行します。<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * 	<tr bgcolor="#CCCCFF"><td>パラメータキー名</td><td>パラメータが示す意味</td></tr>
 *  <tr><td>actionbean</td><td>アクションクラスの完全修飾名</td></tr>
 *  <tr><td>actionmethod</td><td>アクションメソッド名</td></tr>
 * </table>
 * <br>
 * ◆アクションクラスの実装<br>
 * 　アクションでは、その中に実装された任意のメソッド（アクションメソッド）がコントローラによって呼び出されることになります。<br>
 * 開発者は要件に応じてこのメソッドを実装することになります。<br>
 * 原則として１リクエスト = １アクションメソッドという構成で作成します。<br>
 * アクションクラスは、特に決まったクラスやインターフェースを実装する必要はありませんが、
 * コントローラに実行させるアクションメソッドは以下のようなシグニチャである必要があります。
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr><td bgcolor="#CCCCFF">メソッド名</td><td colspan="2">pubulic {@link GResultData} XXXX({@link GParameter} parameter, {@link GResultData} data )</td></tr>
 * <tr><td bgcolor="#CCCCFF" rowspan="2">引数</td><td>parameter</td><td>パラメータオブジェクト</td></tr>
 * <tr><td>data</td><td>結果セット</td></tr>
 * <tr><td bgcolor="#CCCCFF">戻り値</td><td colspan="2">処理結果が積まれた結果セットオブジェクト</td></tr>
 * </table>
 * <br>
 * 
 * <b>【アクションインターセプター】</b><br>
 * 　インターセプターとは、AOPの一種で、特定のビジネス処理にかかわらず、共通の 機能を横断的に適用したいときに有効な仕組みです。<br>
 * Core Frameworkではアクションメソッド専用のインターセプターを用意しています。<br>
 * Core Frameworkでは、初めからDBコネクションの確立を自動化する{@link jp.co.kccs.greenearth.framework.db.GConnectionInterceptor}や
 * トランザクション処理を自動化する{@link jp.co.kccs.greenearth.framework.db.GTransactionIntercepto}などが用意されていますが、新規でインターセプターを作成することもできます。<br>
 * これらアクションインターセプターを利用し、複数のアクションで共通する前後処理を追加します。<br>
 * アクションインターセプターの指定方法は、{@link jp.co.kccs.greenearth.framework.action.GActionInterceptor}クラスの説明を参照してください。<br>
 * <br>
 * 
 * <b>【必要なリクエストパラメータ】</b><br>
 * 　Core Frameworkを駆動させるためには、少なくとも以下のパラメータをリクエストに詰めてサブミットする必要がります。<br>
 * また、これらのパラメータは、フレームワークが優先的に利用するための予約語として扱われるため、
 * アプリケーションデータとして利用することはできません。
 * <table border="1" cellpadding="3" cellspacing="0">
 * 	<tr bgcolor="#CCCCFF"><td>パラメータキー名</td><td>パラメータが示す意味</td></tr>
 *  <tr><td>actionid</td><td>アクションイベントを発生させたコンポーネントのID</td></tr>
 *  <tr><td>actionbean</td><td>アクションクラスの完全修飾名</td></tr>
 *  <tr><td>actionmethod</td><td>アクションメソッド名</td></tr>
 *  <tr><td>mode</td><td>アクションのモード（任意文字列）</td></tr>
 *  <tr><td>validate</td><td>入力値検証を行うレベル（error/warning/info/none）</td></tr>
 * </table> 
 * 
 * @create 2009/07/27
 * @author kitamura
 * @since 3.6.0
 */
public class GActionServlet extends HttpServlet {

	/** アクションクラスを指定するパラメータキー名. */
	public static final String ACTION_BEAN_KEY = "actionbean";

	/** アクションメソッドを指定するパラメータキー名. */
	public static final String ACTION_METHOD_KEY = "actionmethod";
	/** パラメータにアクションを実行したコンポーネントのID格納するときのキー名. */
	public static final String ACTION_ID = "actionid";
	/** アクションメソッドの実行モードを指定するパラメータキー名. */
	public static final String ACTION_MODE_KEY = "mode";
	/** アクションメソッドの警告に対する対応区分を指定するパラメータキー名. */
	public static final String VALIDATE_KEY = "validate";
	/** デフォルトロケール. */
	protected static final Locale DEFAULT_LOCALE = new Locale("");

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = -2619520209368147657L;

	/**
	 * {@link GActionServlet}インスタンスを初期化します。
	 * 
	 * @create 2009/07/27
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GActionServlet() {
	}
	
	/**
	 * アクションクラスのインスタンスを生成します.<br>
	 * 
	 * 引数に指定された{@link GParameter}に{@link GActionServlet#ACTION_BEAN_KEY}
	 * という名前で格納されている値が示すクラス名が示すクラスをアクションクラスとし、インスタンス化します。<br>
	 * 
	 * @create 2009/05/18
	 * @param parameter パラメータ
	 * @param request リクエスト
	 * @return アクションクラス
	 * @throws ClassNotFoundException アクションクラスが見つからなかった場合
	 * @throws IllegalAccessException コンストラクタにアクセスできなかった場合
	 * @throws InstantiationException インスタンスの生成に失敗した場合
	 * @author okajima
	 * @since 3.6.0
	 */
	protected Object createActionInstance(GParameter parameter, HttpServletRequest request) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		
		// クラスの生成
		String className = parameter.getValue(ACTION_BEAN_KEY);
		if (className == null) {
			throw new IllegalArgumentException("'" + ACTION_BEAN_KEY + "' is not found!");
		}

		return GActionInvoker.getInstance().createAction(className);
	}

	/**
	 * パラメータにて指定されているアクションを実行します。
	 * <br><br>
	 * 【アクションの選定】<br>
	 * パラメータに「actionbean」という名前で格納されている値が実行されるアクションクラスの完全修飾名となります。<br>
	 * パラメータの「actionmethod」という名前で格納されている値がコールされるアクションメソッド名となります。<br>
	 * <br>
	 * 【アクションメソッドのシグニチャ】<br>
	 * 以下のシグニチャに準拠している必要があります。<br>
	 * <li>public {@link GResultData} XXXX({@link GParameter}, {@link GResultData});
	 * <br>
	 * 【インターセプターの指定(AOP:Aspect Oriented Programming)】<br>
	 * アクションクラスにはインターセプターを指定することによりAOP的な機能拡張が可能です。<br>
	 * アクションメソッドに{@link jp.co.kccs.greenearth.framework.action.ActionInterceptors}アノテーションを指定し、
	 * その属性に拡張に利用するインターセプターを指定します。<br>
	 * <br>
	 * 【チェックエラーの処理】<br>
	 * アクションメソッドより、チェックエラー({@link GValidateException})がスローされた場合、
	 * {@link #doAction(HttpServletRequest, HttpServletResponse, GParameter)}メソッドではその内容をキャッチし、{@link GResultData}に詰めて返します。<br>
	 * このため、チェックエラーがこのメソッドより先にスローされることはありません。<br>
	 * 
	 * @create 2009/07/27
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter リクエストパラメータ
	 * @param resultData 結果オブジェクト
	 * @return 実行結果
	 * @throws Throwable アクションメソッド内部で例外が発生した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected GResultData doAction(HttpServletRequest request, HttpServletResponse response, GParameter parameter, GResultData resultData) throws Throwable {
		// メソッド名の取得
		String methodName = parameter.getValue(ACTION_METHOD_KEY);
		if (methodName == null) {
			throw new IllegalArgumentException("'" + ACTION_METHOD_KEY + "' is not found!");
		}
		
		// アクションクラスの生成
		Object target = createActionInstance(parameter, request);

		return invokeAction(target, methodName, parameter, resultData);
	}

	/**
	 * HTTPの"GET"リクエストを処理します.<br>
	 * {@link #doPerform(HttpServletRequest, HttpServletResponse)}メソッドに処理を委託しています。
	 * 
	 * @create 2009/07/27
	 * @see jakarta.servlet.http.HttpServlet#doGet(jakarta.servlet.http.HttpServletRequest, jakarta.servlet.http.HttpServletResponse)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @throws IOException 入出力エラーが発生した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPerform(request, response);
	}

	/**
	 * このリクエストに対する標準的なリクエスト処理を実行して、 対応するレスポンスを生成します。
	 * 
	 * @create 2009/07/27
	 * @param request リクエスト
	 * @param response レスポンス
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @throws IOException 入出力エラーが発生した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected void doPerform(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
			GResultData resultData = (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);
			resultData.setExitCode(GResultData.EXIT_CODE_SUCCESS);

			// アクションの実行
			resultData = doAction(request, response, parameter, resultData);
			request.setAttribute(GConstants.RESULT_DATA_KEY, resultData);
		} catch (Throwable e) {
			throw new ServletException(e);
		}
	}

	/**
	 * HTTPの"POST"リクエストを処理します.<br>
	 * {@link #doPerform(HttpServletRequest, HttpServletResponse)}メソッドに処理を委託しています。
	 * 
	 * @create 2009/07/27
	 * @see jakarta.servlet.http.HttpServlet#doPost(jakarta.servlet.http.HttpServletRequest, jakarta.servlet.http.HttpServletResponse)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @throws IOException 入出力エラーが発生した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPerform(request, response);
	}

	/**
	 * 指定されたアクションメソッドを実行します。
	 * 
	 * @create 2009/07/27
	 * @param action アクションオブジェクト
	 * @param methodName アクションメソッド
	 * @param parameter パラメータ
	 * @param resultData 結果オブジェクト
	 * @return 結果オブジェクト
	 * @throws Throwable アクションメソッド内部で例外が発生した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected GResultData invokeAction(Object action, String methodName, GParameter parameter, GResultData resultData) throws Throwable {
		try {
			return GActionInvoker.getInstance().invoke(action, methodName, parameter, resultData);
		} catch (GValidateException e) {
			// チェックエラー発生時
			resultData.setExitCode(GResultData.EXIT_CODE_VALIDATE_ERROR);
			resultData.setErrors(e.getValidateErrors());
			return resultData;
		}
	}
}
