/*
 * Copyright 2009-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;


/**
 * CoreFrameworkにおける静的定義情報をまとめたクラスです。
 * 
 * @create 2009/07/28
 * @author kitamura
 * @since 3.6.0
 */
public final class GConstants {

	/**
	 * インスタンス化させません
	 * 
	 * @create 2009/07/28
	 * @auther kitamura
	 * @since 3.6.0
	 */
	private GConstants() {
	}

	/** スコープオブジェクトに{@link GParameter}を格納する場合のキー名 */
	public static final String PARAMETER_KEY = "jp.co.kccs.greenearth.framework.PARAMETER";
	/** スコープオブジェクトに{@link jp.co.kccs.greenearth.framework.data.GResultData}を格納する場合のキー名 */
	public static final String RESULT_DATA_KEY = "jp.co.kccs.greenearth.framework.RESULT_DATA";
	/** スコープオブジェクトにシステムエラーを表す例外を格納する場合のキー名 */
	public static final String EXCEPTION_KEY = "jp.co.kccs.greenearth.framework.EXCEPTION";
	/** スコープオブジェクトに{@link jp.co.kccs.greenearth.framework.session.GSession}を格納する場合のキー名 */
	public static final String GSESSION_KEY = "jp.co.kccs.greenearth.framewrok.GSESSION";
	/** {@link jakarta.servlet.http.HttpSession}にワンタイムトークンを格納した{@link java.util.Map}を格納する場合のキー名 */
	public static final String ONE_TIME_TOKEN_SESSION_KEY = "jp.co.kccs.greenearth.framework.ONE_TIME_TOKEN";
	/** ワンタイムトークンをサブミットするためのパラメータキー名 */
	public static final String ONE_TIME_TOKEN_PARAM_KEY = "onetimetoken";	
	/** ワンタイムトークンエラーを格納するためのキー名 */
	public static final String ONE_TIME_TOKEN_EXCEPTION_KEY = ONE_TIME_TOKEN_SESSION_KEY + ".EXCEPTION";
	/** 画面を識別するIDを保持するパラメータキー名 */
	public static final String VIEWID_KEY = "viewid";
}
