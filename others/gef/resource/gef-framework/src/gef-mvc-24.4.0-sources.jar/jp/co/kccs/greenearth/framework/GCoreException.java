/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import jp.co.kccs.greenearth.commons.GFrameworkException;

/**
 * Core Frameworkの処理中に発生した例外を表します.
 * 
 * @create 2007/02/12
 * @author kitamura
 * @since 3.0.0
 */
public class GCoreException extends GFrameworkException {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = 7469649870576024209L;

	/**
	 * {@link GCoreException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GCoreException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GCoreException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GCoreException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GCoreException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GCoreException(Throwable cause) {
		super(cause);
	}

	/**
	 * 例外メッセージと、この例外の発生原因を指定し、{@link GCoreException}のインスタンスを初期化します.
	 * 
	 * @param message メッセージ
	 * @param cause 原因となった例外
	 * @author KCCS kitamura 
	 * @since 2013/07/01
	 */
	public GCoreException(String message, Throwable cause) {
		super(message, cause);
	}
}
