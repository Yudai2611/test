/*
 * Copyright 2009-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.IOException;
import java.util.Locale;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;
import jp.co.kccs.greenearth.commons.tools.GStopWatch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * CoreFrameworkにおいて、ユーザからのリクエストを受け付ける玄関となるフィルターです。<br>
 * フレームワークを利用した処理を実行するリクエストのフィルターチェーンのトップに、
 * 必ずこのフィルターが来るようにweb.xmlにて設定をする必要があります。<br>
 * <br>
 * <b>■web.xml設定例</b><br>
 * 　※JSPの場合は、エラーページへの遷移として呼び出される可能性があるため、&lt;dispatcher>に"ERROR"を指定しています
 * <pre>
 * &lt;filter>
 *    &lt;filter-name>FacadeFilter&lt;/filter-name>
 *    &lt;filter-class>jp.co.kccs.greenearth.framework.GFacadeFilter&lt;/filter-class>
 * &lt;/filter>
 * 
 * &lt;filter-mapping>
 *    &lt;filter-name>FacadeFilter&lt;/filter-name>
 *    &lt;url-pattern>*.view-action&lt;/url-pattern>
 *    &lt;dispatcher>REQUEST&lt;/dispatcher>
 * &lt;/filter-mapping>
 * &lt;filter-mapping>
 *    &lt;filter-name>FacadeFilter&lt;/filter-name>
 *    &lt;url-pattern>*.jsp&lt;/url-pattern>
 *    &lt;dispatcher>REQUEST&lt;/dispatcher>
 *    &lt;dispatcher>ERROR&lt;/dispatcher>
 * &lt;/filter-mapping>
 * &lt;filter-mapping>
 *    &lt;filter-name>FacadeFilter&lt;/filter-name>
 *    &lt;url-pattern>*.xrmi-action&lt;/url-pattern>
 *    &lt;dispatcher>REQUEST&lt;/dispatcher>
 * &lt;/filter-mapping>
 * </pre>
 * 
 * <b>■このフィルターで行われる処理</b><br>
 * 　①{@link GWebContext}の初期化<br>
 * 　②処理されなかったエラーのハンドリング（エラーログの出力）<br>
 * <br>
 * 
 * @create 2009/07/28
 * @author kitamura
 * @since 3.6.0
 */
public class GFacadeFilter extends GExcludableFilter {

	/** リクエストヘッダの許容言語識別子. */
	public static final String ACCEPT_LANGUAGE = "Accept-Language";
	
	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GFacadeFilter.class);

	/** デフォルトロケール. */
	protected static final Locale DEFAULT_LOCALE = new Locale("");

	/** サーブレットコンテキスト. */
	private ServletContext _servletContext = null;
	
	/**
	 * {@link GFacadeFilter}インスタンスを初期化します。
	 * 
	 * @create 2009/07/28
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GFacadeFilter() {
	}

	/**
	 * Commons-Loggingのログインスタンスを開放しています。<br>
	 * 
	 * @create 2009/07/28
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#destroy()
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void destroy() {
		_servletContext = null;
	}

	/**
	 * フレームワークを利用したシステムへのリクエストに対する初期化処理と後処理を行います。<br>
	 * 処理内容に関しては{@link GFacadeFilter}クラスコメントを参照
	 * 
	 * @create 2009/07/28
	 * @see GExcludableFilter#doFilter(HttpServletRequest, HttpServletResponse, FilterChain)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain フィルターチェイン
	 * @throws IOException 入出力処理に失敗場合
	 * @throws ServletException サーブレット処理に失敗場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {

		GStopWatch watch = new GStopWatch();
		watch.start();
		try {
			// パラメータの生成
			GParameter parameter = createParameter(request);
			request.setAttribute(GConstants.PARAMETER_KEY, parameter);
			
			// Webコンテキストの設定
			GWebContext context = GWebContext.getInstance();
			context.init(request, response);
			
			LOGGER.info("Request Start");
			
			LOGGER.debug("Parameter : " + parameter.toString());

			// Pass control on to the next filter
			chain.doFilter(request, response);

		} catch (Exception e) {
			LOGGER.error("Error Handling Faild!!!", e);

			Throwable nestedEx = e;
			while (true) {
				if (nestedEx instanceof ServletException) {
					ServletException se = (ServletException) nestedEx;
					Throwable cause = se.getRootCause();
					LOGGER.error("Error Cause!!!", cause);
					nestedEx = cause;
				} else {
					break;
				}
			}
			
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

		} finally {
			LOGGER.info("Request End (" + watch.stop() + ")");
		}
	}

	/**
	 * サーブレットコンテキストを取得します。
	 * 
	 * @create 2009/07/28
	 * @return サーブレットコンテキスト
	 * @author kitamura
	 * @since 3.6.0
	 */
	public ServletContext getServletContext() {
		return _servletContext;
	}

	/**
	 * サーブレットコンテキストの取得と、起動メッセージの出力を行っています。
	 * 
	 * @create 2009/07/28
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#init(jakarta.servlet.FilterConfig)
	 * @param filterConfig フィルター定義情報
	 * @throws ServletException サーブレット処理に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);
		_servletContext = filterConfig.getServletContext();
	}

	/**
	 * サーブレットコンテキストを設定します。
	 * 
	 * @create 2009/07/28
	 * @param servletContext サーブレットコンテキスト
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void setServletContext(ServletContext servletContext) {
		_servletContext = servletContext;
	}


	/**
	 * {@link HttpServletRequest}から{@link GParameter}を生成します。
	 * 
	 * @create 2009/07/28
	 * @param request リクエスト
	 * @return {@link GParameter}オブジェクト
	 * @throws GCoreException {@link GParameter}の生成に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected GParameter createParameter(HttpServletRequest request) throws GCoreException {
		GParameter parameter = (GParameter) GFrameworkUtils.getComponent(GParameter.class.getName());
		parameter.parseRequest(request);
		return parameter;
	}

}
