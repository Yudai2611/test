/*
 * Copyright 2009-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.listener.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

/**
 * CoreFramework起動時の初期化処理や、停止時の後処理を実行する{@link ServletContextListener}です。<br>
 *
 * このクラスでは、サーブレットコンテナの起動時と停止時に、
 * スキャンされたパッケージに{@link jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable}を呼び出しています。<br>
 * CoreFramework起動時や停止時に任意の処理を追加したい場合は、
 * {@link GBootstrapInitializable}インターフェースを実装したクラスを作成し、
 * <b>◆{@link GBootstrapInitializable}の実行順序<br></b>
 * 上記定義例のように{@link GBootstrapInitializable}を複数指定した場合の実行順序は以下のようになります。<br>
 * 　フレームワーク起動時：設定内容のインデックス順（記述したリスナーを上から順に実行)<br>
 * 　フレームワーク停止時：設定内容のインデックス逆順<br>
 * <br>
 * @create 2009/07/28
 * @author kitamura
 * @since 3.6.0
 */
public class GMVCFrameworkInitializer implements ServletContextListener {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GMVCFrameworkInitializer.class);
	private GBootstrapInitializer coreListener;
	private static final String GEF_NEXT_VERSION  = "24.4.0";

	/**
	 * {@link GMVCFrameworkInitializer}インスタンスを初期化します。
	 *
	 * @create 2009/07/28
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GMVCFrameworkInitializer() {
	}

	/**
	 * フレームワーク停止時の後処理を実行します。
	 *
	 * @create 2009/07/28
	 * @see ServletContextListener#contextDestroyed(ServletContextEvent)
	 * @param sce イベント
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void contextDestroyed(ServletContextEvent sce) {
		try {
			LOGGER.info("GreenEARTH MVC Framework " + getVersion() + " Stopped.");
			// Release LogFactory and Log instances
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			if (classLoader == null) {
				classLoader = GMVCFrameworkInitializer.class.getClassLoader();
			}
			coreListener.destroy();
			try {
				LogFactory.release(classLoader);
			} catch (Throwable e) {
				e.printStackTrace();
			}
		}
		finally {
			GFrameworkUtils.destroyDIContainer();
		}


	}

	/**
	 * フレームワーク起動時の初期化処理を実行します。
	 *
	 * @create 2009/07/28
	 * @see ServletContextListener#contextInitialized(ServletContextEvent)
	 * @param sce イベント
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void contextInitialized(ServletContextEvent sce) {
		GFrameworkUtils.initDIContainer(sce.getServletContext());

		coreListener = new GBootstrapCoreListener();
		coreListener.initialize();
		
		System.out.println("-----------------------------------------------");
		System.out.println("      GreenEARTH MVC Framework " + getVersion() + " Started.");
		System.out.println("-----------------------------------------------");
		LOGGER.info("GreenEARTH MVC Framework " + getVersion() + " Started.");
	}

	public String getVersion() {
		return GEF_NEXT_VERSION;
	}

}
