/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import jakarta.servlet.http.HttpServletRequest;

import jp.co.kccs.greenearth.framework.data.GErrorLevel;

/**
 * クライアントからのリクエストパラメータを表します.<br>
 * 名前とパラメータをマッピングして管理するマップ構造になっています。<br>
 * 同一のキーを複数の値を登録することができ、値に<code>null</code>値を指定することもできます。<br>
 * 格納できる値は、文字列({@link String})とアップロードファイル({@link GUploadFile})の二種類で、
 * それぞれは別々のマップとして管理されます。<br>
 * ※{@link GParameter}はマルチパートリクエストに対応しています。
 * 
 * @create 2006/11/28
 * @author kitamura
 * @since 3.0.0
 */
public interface GParameter {

	/**
	 * 指定した名前をキーにアップロードファイルを追加します.
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param file アップロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addFile(String name, GUploadFile file);

	/**
	 * 指定した名前で格納されているファイルリストの指定したインデックスにアップロードファイルを追加します.<br>
	 * 指定したインデックス以降に格納されていた値はインデックスが後方にづれます。
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @param file アップロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addFile(String name, int index, GUploadFile file);

	/**
	 * 指定した名前をキーにアップロードファイル配列を追加します.
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param files アップロードファイル配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addFiles(String name, GUploadFile[] files);

	/**
	 * 指定した名前で格納されているファイルリストの指定したインデックス以降にアップロードファイルの配列を追加します.<br>
	 * 指定したインデックス以降の値は追加されたアップロードファイル配列の要素数分インデックスが後方にづれます。
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @param files アップロードファイル配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addFiles(String name, int index, GUploadFile[] files);

	/**
	 * 指定した名前で格納されているパラメータリストの指定したインデックスに文字列を追加します.<br>
	 * 指定したインデックス以降に格納されていた値はインデックスが後方にづれます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @param index インデックス
	 * @param value 文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addValue(String name, int index, String value);

	/**
	 * 指定した名前をキーにパラメータを追加します.
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @param value 文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addValue(String name, String value);

	/**
	 * 指定した名前で格納されているパラメータリストの指定したインデックス以降に文字列の配列を追加します.<br>
	 * 指定したインデックス以降の値は追加された文字列配列の要素数分インデックスが後方にづれます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @param index インデックス
	 * @param values パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addValues(String name, int index, String[] values);

	/**
	 * 指定した名前をキーにパラメータ配列を追加します.
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @param values パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void addValues(String name, String[] values);

	/**
	 * 格納されている値を全てクリアします.
	 * 
	 * @create 2006/11/28
	 * @author kitamura
	 * @since 3.0.0
	 */
	void clear();

	/**
	 * ファイルマップをクリアします.
	 * 
	 * @create 2007/01/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	void clearFiles();

	/**
	 * パラメータ(文字列)マップをクリアします.
	 * 
	 * @create 2007/01/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	void clearValues();

	/**
	 * 指定のキー名のアップロードファイルを保持する場合に<code>true</code>を返します.
	 * 
	 * @create 2007/04/09
	 * @param name キー名
	 * @return 存在する=<code>true</code>/存在しない<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean containsFileKey(String name);

	/**
	 * 指定のキー名のパラメータを保持する場合に<code>true</code>を返します.
	 * 
	 * @create 2007/04/09
	 * @param name キー名
	 * @return 存在する=<code>true</code>/存在しない<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean containsValueKey(String name);

	/**
	 * ファイルマップに格納されている名前のセットビューを返します.<br>
	 * セットは{@link GParameter}と連動しているので、{@link GParameter}に対する変更はセットに反映され、またセットに
	 * 対する変更は{@link GParameter}に反映されます。
	 * 
	 * @create 2007/01/12
	 * @return ファイルマップの名前セット
	 * @author kitamura
	 * @since 3.0.0
	 */
	Set<String> filesKeySet();

	/**
	 * 指定された名前で格納されている値を{@link BigDecimal}で取得します.<br>
	 * ({@link BigDecimal#BigDecimal(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return {@link BigDecimal}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	BigDecimal getBigDecimal(String name);

	/**
	 * 指定された名前で格納されている値を{@link BigDecimal}で取得します.<br>
	 * ({@link BigDecimal#BigDecimal(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return {@link BigDecimal}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	BigDecimal getBigDecimal(String name, int index);

	/**
	 * 指定された名前で格納されている値を{@link BigInteger}で取得します.<br>
	 * ({@link BigInteger#BigInteger(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return {@link BigInteger}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	BigInteger getBigInteger(String name);

	/**
	 * 指定された名前で格納されている値を{@link BigInteger}で取得します.<br>
	 * ({@link BigInteger#BigInteger(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return {@link BigInteger}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	BigInteger getBigInteger(String name, int index);

	/**
	 * 指定された名前で格納されている値を<code>boolean</code>で取得します.<br>
	 * {@link Boolean#parseBoolean(String)}された値が返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return <code>boolean</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	boolean getBoolean(String name);

	/**
	 * 指定された名前で格納されている値を<code>boolean</code>で取得します.<br>
	 * {@link Boolean#parseBoolean(String)}された値が返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>boolean</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	boolean getBoolean(String name, int index);

	/**
	 * 指定された名前で格納されている値を<code>byte</code>で取得します.<br>
	 * {@link Byte#parseByte(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return <code>byte</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Byte getByte(String name);

	/**
	 * 指定された名前で格納されている値を<code>byte</code>で取得します.<br>
	 * {@link Byte#parseByte(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>byte</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Byte getByte(String name, int index);

	/**
	 * 指定された名前で格納されている値を{@link Date}で取得します.<br>
	 * この場合、対象の値はフォーマットがプロパティファイルに格納されている必要があります。<br>
	 * また、日付解析を厳密に行わないかどうかは、デフォルトプロパティを使用します。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return {@link Date}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Date getDate(String name);

	/**
	 * 指定された名前で格納されている値を{@link Date}で取得します.<br>
	 * この場合、対象の値はフォーマットがプロパティファイルに格納されている必要があります。<br>
	 * また、日付解析を厳密に行わないかどうかは、デフォルトプロパティを使用します。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return {@link Date}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Date getDate(String name, int index);

	/**
	 * 指定された名前で格納されている値を<code>double</code>で取得します.<br>
	 * {@link Double#parseDouble(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return <code>double</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Double getDouble(String name);

	/**
	 * 指定された名前で格納されている値を<code>double</code>で取得します.<br>
	 * {@link Double#parseDouble(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>double</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Double getDouble(String name, int index);

	/**
	 * 指定した名前で格納されているアップロードファイルを取得します.<br>
	 * 値が複数格納されている場合は、リストの先頭から検索し、最初に見つかったアップロードファイルを取得します。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @return アップロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUploadFile getFile(String name);

	/**
	 * 指定した名前で格納されているアップロードファイルリストの中から、指定したインデックスに該当するアップロードファイルを取得します.<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @param index インデックス
	 * @return アップロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUploadFile getFile(String name, int index);

	/**
	 * 指定した名前で格納されているアップロードファイルの数を取得します.
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @return パラメータの数
	 * @author kitamura
	 * @since 3.0.0
	 */
	int getFileCount(String name);

	/**
	 * 指定した名前で格納されているアップロードファイルリストを配列で取得します.<br>
	 * 要素が1つしか格納されていないものに対しては、サイズ1の配列が返されます。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @return アップロードファイル配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUploadFile[] getFiles(String name);

	/**
	 * アップロードファイルマップを{@link Map}で返します.<br>
	 * マップのkeyは{@link String}型。
	 * マップの値は{@link GUploadFile}の配列です。
	 * 
	 * @create 2007/01/12
	 * @return ファイルマップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	Map<String, GUploadFile[]> getFilesMap();

	/**
	 * 指定された名前で格納されている値を<code>float</code>で取得します.<br>
	 * {@link Float#parseFloat(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>float</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Float getFloat(String name);

	/**
	 * 指定された名前で格納されている値を<code>float</code>で取得します.<br>
	 * {@link Float#parseFloat(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>float</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Float getFloat(String name, int index);

	/**
	 * 指定された名前で格納されている値を<code>int</code>で取得します.<br>
	 * {@link Integer#parseInt(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>int</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Integer getInteger(String name);

	/**
	 * 指定された名前で格納されている値を<code>int</code>で取得します.<br>
	 * {@link Integer#parseInt(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>int</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Integer getInteger(String name, int index);

	/**
	 * 指定された名前で格納されている値を<code>long</code>で取得します.<br>
	 * {@link Long#parseLong(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>long</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Long getLong(String name);

	/**
	 * 指定された名前で格納されている値を<code>long</code>で取得します.<br>
	 * {@link Long#parseLong(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>long</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Long getLong(String name, int index);

	/**
	 * 指定された名前で格納されている値を<code>short</code>で取得します.<br>
	 * {@link Short#parseShort(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>short</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Short getShort(String name);

	/**
	 * 指定された名前で格納されている値を<code>short</code>で取得します.<br>
	 * {@link Short#parseShort(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>short</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	Short getShort(String name, int index);

	/**
	 * エラーへの対応区分を取得します .<br>
	 * エラーへの対応区分は、パラメータ内に{@link GActionServlet#VALIDATE_KEY}キーで登録されている値を元に判定します。<br>
	 * [1]値が"none"の場合、{@link GErrorLevel#NONE}を返します。<br>
	 * [2]値が"error"の場合、{@link GErrorLevel#ERROR}を返します。<br>
	 * [3]値が"warning"の場合、{@link GErrorLevel#WARNING}を返します。<br>
	 * [4]値が"info"の場合、{@link GErrorLevel#INFO}を返します。<br>
	 * 
	 * @create 2007/02/07
	 * @return GValidationType
	 * @author aono
	 * @since 3.0.0
	 */
	GErrorLevel getValidationLevel();

	/**
	 * 指定した名前で格納されているパラメータを取得します.<br>
	 * 値が複数格納されている場合は、リストの先頭から検索し、最初に見つかったパラメータを取得します。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @return パラメータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getValue(String name);

	/**
	 * 指定した名前で格納されているパラメータリストの中から、指定したインデックスに該当するパラメータを取得します.<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @param index インデックス
	 * @return パラメータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getValue(String name, int index);

	/**
	 * 指定した名前で格納されているパラメータの数を取得します.
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @return パラメータの数
	 * @author kitamura
	 * @since 3.0.0
	 */
	int getValueCount(String name);

	/**
	 * 指定した名前で格納されているパラメータリストを配列で取得します.<br>
	 * 要素が1つしか格納されていないものに対しては、サイズ1の配列が返されます。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2006/11/28
	 * @param name 名前
	 * @return パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	String[] getValues(String name);

	/**
	 * パラメータマップを{@link Map}で返します.
	 * 
	 * @create 2007/01/12
	 * @return ファイルマップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	Map<String, String[]> getValuesMap();

	/**
	 * 指定されたリクエストの情報を解析し、{@link GParameter}オブジェクト内に展開します.<br>
	 * 通常のリクエストの場合、リクエストに格納されているパラメータマップをコピーします.<br>
	 * マルチパートリクエストの場合は、アップロードされたファイルをファイルマップ、
	 * それ以外のフォームパラメータはパラメータマップに格納されます。
	 * 
	 * @create 2007/01/12
	 * @param request リクエスト
	 * @throws GCoreException リクエストの解析に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	void parseRequest(HttpServletRequest request) throws GCoreException;

	/**
	 * 指定された名前に関連づくアップロードファイルリストをアップロードファイルマップから削除します.
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeFile(String name);

	/**
	 * 指定された名前とインデックスに関連づくアップロードファイルをアップロードファイルマップから削除します.
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeFile(String name, int index);

	/**
	 * 指定された名前に関連づくパラメータをパラメータマップから削除します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeValue(String name);

	/**
	 * 指定した名前とインデックスに関連づくパラメータリストをパラメータマップから削除します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @param index インデックス
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeValue(String name, int index);

	/**
	 * 指定した名前でアップロードファイルを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param file アップロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setFile(String name, GUploadFile file);

	/**
	 * 指定した名前で格納されているアップロードファイルリストの、
	 * 指定したインデックスにアップロードファイルを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @param file アップロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setFile(String name, int index, GUploadFile file);

	/**
	 * 指定した名前でアップロードファイルの配列を格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @create 2007/01/12
	 * @param name 名前
	 * @param files アップロードファイル配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setFiles(String name, GUploadFile[] files);

	/**
	 * 指定した名前で格納されているパラメータリストの、指定したインデックスにパラメータを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @param index インデックス
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setValue(String name, int index, String value);

	/**
	 * 指定した名前でパラメータを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setValue(String name, String value);

	/**
	 * 指定した名前でパラメータの配列を格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @param values パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setValues(String name, String[] values);

	/**
	 * パラメータマップに格納されている名前のセットビューを返します.<br>
	 * セットは{@link GParameter}と連動しているので、{@link GParameter}に対する変更はセットに反映され、またセットに
	 * 対する変更は{@link GParameter}に反映されます。
	 * 
	 * @create 2007/01/12
	 * @return パラメータの名前セット
	 * @author kitamura
	 * @since 3.0.0
	 */
	Set<String> valuesKeySet();
}
