/*
 * Copyright 2007-2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.fileupload2.core.DiskFileItem;
import org.apache.commons.fileupload2.core.DiskFileItemFactory;
import org.apache.commons.fileupload2.core.FileUploadException;
import org.apache.commons.fileupload2.jakarta.JakartaServletDiskFileUpload;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.utils.GConvertUtils;

/**
 * {@link GParameter}のデフォルト実装です.<br>
 * クライアントからのリクエストパラメータを表します。<br>
 * 基本的には、{@link HttpServletRequest}に積まれているパラメータと同一の内容となります。<br>
 * マルチパートリクエストに対しては、commons-uploadを利用して解析しています。
 * <p>
 * マルチパートリクエストの解析におけるアップロードファイルに関する以下の設定は
 * 環境設定ファイル（ge-framework.properties）で行うことができます。<br>
 * <ul>
 * <li>アップロードファイルテンポラリ保存サイズ
 * <li>アップロードファイルテンポラリ保存ディレクトリ
 * </ul>
 * <table border="1" cellpadding="3" cellspacing="0" width="100%">
 * <tr bgcolor="#CCCCFF"><td>[設定内容]	</td><td>[設定キー名]	</td><td>[省略時]	</td></tr>
 * <tr><td>アップロードファイルテンポラリ保存サイズ</td><td>geframe.core.FileUpload.TempSize</td><td>0</td></tr>
 * <tr><td>アップロードファイルテンポラリ保存ディレクトリ</td><td>geframe.core.FileUpload.TempDirectory</td><td>指定なし<br>（APサーバのテンポラリディレクトリ）</td></tr>
 * </table>
 * <br>
 * 
 * このクラスの実装にあたっては{@link GUploadFile}のデフォルト実装クラスである{@link GUploadFileImpl}を使用しています。
 * <br>
 * 
 * @see jp.co.kccs.greenearth.framework.GParameter
 * @create 2006/11/28
 * @author kitamura
 * @since 3.0.0
 */
public class GParameterImpl implements GParameter {

	/** アップロードファイル最大サイズ デフォルト値. */
	protected static final String UPLOADFILE_MAX_SIZE_DEFAULT = "-1";
	/** アップロードファイルテンポラリディレクトリ　デフォルト値. */
	protected static final String UPLOADFILE_TEMP_DIR_DEFAULT = null;
	/** アップロードファイルテンポラリディレクトリ　KEY名. */
	protected static final String UPLOADFILE_TEMP_DIR_KEY = "geframe.core.FileUpload.TempDirectory";
	/** アップロードファイルテンポラリサイズ　デフォルト値. */
	protected static final String UPLOADFILE_TEMP_SIZE_DEFAULT = "0";

	/** アップロードファイルテンポラリサイズ　KEY名. */
	protected static final String UPLOADFILE_TEMP_SIZE_KEY = "geframe.core.FileUpload.TempSize";

	/** アップロードファイルマップ. */
	private Map<String, GUploadFile[]> _files = new HashMap<String, GUploadFile[]>();
	/** アップロードファイル最大サイズ. */
	private String _uploadfileMaxSize = UPLOADFILE_MAX_SIZE_DEFAULT;

	/** アップロードファイルテンポラリディレクトリ. */
	private String _uploadfileTempDir = null;
	/** アップロードファイルテンポラリサイズ. */
	private String _uploadfileTempSize = null;
	/** パラメータのマップ. */
	private Map<String, String[]> _values = new HashMap<String, String[]>();

	/**
	 * {@link GParameterImpl}インスタンスを初期化します.
	 * 
	 * @create 2006/11/28
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GParameterImpl() {
	}

	/**
	 * 指定した名前をキーにアップロードファイルを追加します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addFile(java.lang.String, jp.co.kccs.greenearth.framework.GUploadFile)
	 * @create 2007/01/15
	 * @param name 名前
	 * @param file アップロードファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void addFile(String name, GUploadFile file) {
		GUploadFile[] oldFiles = _files.get(name);
		if (oldFiles == null) {
			GUploadFile[] newFiles = new GUploadFile[1];
			newFiles[0] = file;
			_files.put(name, newFiles);
		} else {
			GUploadFile[] newFiles = new GUploadFile[oldFiles.length + 1];
			for (int i = 0; i < oldFiles.length; i++) {
				newFiles[i] = oldFiles[i];
			}
			newFiles[oldFiles.length] = file;
			_files.put(name, newFiles);
		}
	}

	/**
	 * 指定した名前で格納されているアップロードファイルリストの指定したインデックスにアップロードファイルを追加します.<br>
	 * 指定したインデックス以降に格納されていた値はインデックスが後方にずれます。<br>
	 * 指定された名前のリストが存在しない場合に、インデックスに0以外の値が指定された場合は{@link IndexOutOfBoundsException}がスローされます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addFile(java.lang.String, int, jp.co.kccs.greenearth.framework.GUploadFile)
	 * @create 2007/01/15
	 * @param name 名前
	 * @param index インデックス
	 * @param file アップロードファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void addFile(String name, int index, GUploadFile file) {
		GUploadFile[] files = _files.get(name);
		if (files == null) {
			if (index != 0) {
				throw new IndexOutOfBoundsException("Index is invalid.");
			}
			GUploadFile[] newFiles = new GUploadFile[1];
			newFiles[0] = file;
			_files.put(name, newFiles);
		} else {
			GUploadFile[] newFiles = new GUploadFile[files.length + 1];
			for (int i = 0; i < newFiles.length; i++) {
				if (i < index) {
					newFiles[i] = files[i];
				} else if (i == index) {
					newFiles[i] = file;
				} else if (i > index) {
					newFiles[i] = files[i - 1];
				}
			}
			_files.put(name, newFiles);
		}
	}

	/**
	 * 指定した名前をキーにアップロードファイル配列を追加します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addValues(java.lang.String, jp.co.kccs.greenearth.framework.GUploadFile[])
	 * @create 2007/01/15
	 * @param name 名前
	 * @param files アップロードファイル配列
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void addFiles(String name, GUploadFile[] files) {
		GUploadFile[] oldFiles = _files.get(name);
		if (oldFiles != null) {
			GUploadFile[] newFiles = new GUploadFile[oldFiles.length + files.length];
			for (int i = 0; i < oldFiles.length; i++) {
				newFiles[i] = oldFiles[i];
			}
			for (int i = 0; i < files.length; i++) {
				newFiles[oldFiles.length + i] = files[i];
			}
			_files.put(name, newFiles);
		} else {
			_files.put(name, files);
		}
	}

	/**
	 * 指定した名前で格納されているアップロードファイルリストの指定したインデックス以降にアップロードファイルの配列を追加します.<br>
	 * 指定したインデックス以降の値は追加されたアップロードファイル配列の要素数分インデックスが後方にずれます。<br>
	 * 指定された名前のリストが存在しない場合に、インデックスに0以外の値が指定された場合は{@link IndexOutOfBoundsException}がスローされます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addValues(java.lang.String, int, jp.co.kccs.greenearth.framework.GUploadFile[])
	 * @create 2007/01/15
	 * @param name 名前
	 * @param index インデックス
	 * @param files アップロードファイル配列
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void addFiles(String name, int index, GUploadFile[] files) {
		GUploadFile[] oldFiles = _files.get(name);
		if (oldFiles == null) {
			if (index != 0) {
				throw new IndexOutOfBoundsException("Index is invalid.");
			}
			_files.put(name, files);
		} else {

			GUploadFile[] newFiles = new GUploadFile[oldFiles.length + files.length];

			for (int i = 0; i < index; i++) {
				newFiles[i] = oldFiles[i];
			}

			int j = 0;
			for (int i = index; i < index + files.length; i++) {
				newFiles[i] = files[j];
				j++;
			}

			for (int i = index + files.length; i < newFiles.length; i++) {
				newFiles[i] = oldFiles[i - files.length];
			}
			_files.put(name, newFiles);
		}
	}

	/**
	 * 指定した名前で格納されているパラメータリストの指定したインデックスに文字列を追加します.<br>
	 * 指定したインデックス以降に格納されていた値はインデックスが後方にずれます。<br>
	 * 指定された名前のリストが存在しない場合に、インデックスに0以外の値が指定された場合は{@link IndexOutOfBoundsException}がスローされます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addValue(java.lang.String, int, java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @param value パラメータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addValue(String name, int index, String value) {
		String[] values = _values.get(name);
		if (values == null) {
			if (index != 0) {
				throw new IndexOutOfBoundsException("Index is invalid.");
			}
			String[] newValues = new String[1];
			newValues[0] = value;
			_values.put(name, newValues);
		} else {
			String[] newValues = new String[values.length + 1];
			for (int i = 0; i < newValues.length; i++) {
				if (i < index) {
					newValues[i] = values[i];
				} else if (i == index) {
					newValues[i] = value;
				} else if (i > index) {
					newValues[i] = values[i - 1];
				}
			}
			_values.put(name, newValues);
		}
	}

	/**
	 * 指定した名前をキーにパラメータを追加します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addValue(java.lang.String, java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @param value パラメータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addValue(String name, String value) {
		String[] oldValues = _values.get(name);
		if (oldValues == null) {
			String[] newValues = new String[1];
			newValues[0] = value;
			_values.put(name, newValues);
		} else {
			String[] newValues = new String[oldValues.length + 1];
			for (int i = 0; i < oldValues.length; i++) {
				newValues[i] = oldValues[i];
			}
			newValues[oldValues.length] = value;
			_values.put(name, newValues);
		}
	}

	/**
	 * 指定した名前で格納されているパラメータリストの指定したインデックス以降に文字列の配列を追加します.<br>
	 * 指定したインデックス以降の値は追加された文字列配列の要素数分インデックスが後方にずれます。<br>
	 * 指定された名前のリストが存在しない場合に、インデックスに0以外の値が指定された場合は{@link IndexOutOfBoundsException}がスローされます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addValues(java.lang.String, int, java.lang.String[])
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @param values パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addValues(String name, int index, String[] values) {
		String[] oldValues = _values.get(name);
		if (oldValues == null) {
			if (index != 0) {
				throw new IndexOutOfBoundsException("Index is invalid.");
			}
			_values.put(name, values);
		} else {
			String[] newValues = new String[oldValues.length + values.length];

			for (int i = 0; i < index; i++) {
				newValues[i] = oldValues[i];
			}

			int j = 0;
			for (int i = index; i < index + values.length; i++) {
				newValues[i] = values[j];
				j++;
			}

			for (int i = index + values.length; i < newValues.length; i++) {
				newValues[i] = oldValues[i - values.length];
			}

			_values.put(name, newValues);
		}
	}

	/**
	 * 指定した名前をキーにパラメータ配列を追加します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#addValues(java.lang.String, java.lang.String[])
	 * @create 2007/01/12
	 * @param name 名前
	 * @param values パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addValues(String name, String[] values) {
		String[] oldValues = _values.get(name);
		if (oldValues != null) {
			String[] newValues = new String[oldValues.length + values.length];
			for (int i = 0; i < oldValues.length; i++) {
				newValues[i] = oldValues[i];
			}
			for (int i = 0; i < values.length; i++) {
				newValues[oldValues.length + i] = values[i];
			}
			_values.put(name, newValues);
		} else {
			_values.put(name, values);
		}
	}

	/**
	 * 格納されている値を全てクリアします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#clear()
	 * @create 2007/01/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clear() {
		_values.clear();
		_files.clear();
	}

	/**
	 * ファイルマップをクリアします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#clearFiles()
	 * @create 2007/01/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clearFiles() {
		_files.clear();
	}

	/**
	 * パラメータ(文字列)マップをクリアします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#clearValues()
	 * @create 2007/01/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clearValues() {
		_values.clear();
	}

	/**
	 * 指定のキー名のアップロードファイルを保持する場合に<code>true</code>を返します.
	 * 
	 * @create 2007/04/09
	 * @param name キー名
	 * @return 存在する=<code>true</code>/存在しない<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean containsFileKey(String name) {
		return _files.containsKey(name);
	}

	/**
	 * 指定のキー名のパラメータを保持する場合に<code>true</code>を返します.
	 * 
	 * @create 2007/04/09
	 * @param name キー名
	 * @return 存在する=<code>true</code>/存在しない<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean containsValueKey(String name) {
		return _values.containsKey(name);
	}

	/**
	 * アップロードファイルマップに格納されている名前のセットビューを返します.<br>
	 * セットは{@link GParameter}と連動しているので、{@link GParameter}に対する変更はセットに反映され、またセットに
	 * 対する変更は{@link GParameter}に反映されます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#filesKeySet()
	 * @create 2007/01/15
	 * @return アップロードファイルの名前セット
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Set<String> filesKeySet() {
		return _files.keySet();
	}

	/**
	 * 指定された名前で格納されている値を{@link BigDecimal}で取得します.<br>
	 * ({@link BigDecimal#BigDecimal(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return {@link BigDecimal}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public BigDecimal getBigDecimal(String name) {
		return getBigDecimal(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を{@link BigDecimal}で取得します.<br>
	 * ({@link BigDecimal#BigDecimal(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return {@link BigDecimal}値
	 * @author aono
	 * @since 3.0.0
	 */
	public BigDecimal getBigDecimal(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toBigDecimal(value);
	}

	/**
	 * 指定された名前で格納されている値を{@link BigInteger}で取得します.<br>
	 * ({@link BigInteger#BigInteger(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return {@link BigInteger}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public BigInteger getBigInteger(String name) {
		return getBigInteger(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を{@link BigInteger}で取得します.<br>
	 * ({@link BigInteger#BigInteger(String))返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return {@link BigInteger}値
	 * @author aono
	 * @since 3.0.0
	 */
	public BigInteger getBigInteger(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toBigInteger(value);
	}

	/**
	 * 指定された名前で格納されている値を<code>boolean</code>で取得します.<br>
	 * {@link Boolean#parseBoolean(String)}された値が返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return <code>boolean</code>値
	 * @throws IllegalArgumentException 該当する値が<code>null</code>の場合
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public boolean getBoolean(String name) throws IllegalArgumentException {
		return getBoolean(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を<code>boolean</code>で取得します.<br>
	 * {@link Boolean#parseBoolean(String)}された値が返されます。
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>boolean</code>値
	 * @throws IllegalArgumentException 該当する値が<code>null</code>の場合
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public boolean getBoolean(String name, int index) throws IllegalArgumentException {
		String value = getValue(name, index);
		return GConvertUtils.toBoolean(value);
	}

	/**
	 * 指定された名前で格納されている値を<code>byte</code>で取得します.<br>
	 * {@link Byte#parseByte(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return <code>byte</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Byte getByte(String name) {
		return getByte(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を<code>byte</code>で取得します.<br>
	 * {@link Byte#parseByte(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>byte</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Byte getByte(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toByte(value);
	}

	/**
	 * 指定された名前で格納されている値を{@link Date}で取得します.<br>
	 * この場合、対象の値はフォーマットがプロパティファイルに格納されている必要があります。<br>
	 * また、日付解析を厳密に行わないかどうかは、デフォルトプロパティを使用します。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return {@link Date}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Date getDate(String name) {
		return getDate(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を{@link Date}で取得します.<br>
	 * この場合、対象の値はデフォルトフォーマットで格納されている必要があります。<br>
	 * また、日付解析を厳密に行わないかどうかは、デフォルトプロパティを使用します。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return {@link Date}値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Date getDate(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toDate(value);
	}

	/**
	 * 指定された名前で格納されている値を<code>double</code>で取得します.<br>
	 * {@link Double#parseDouble(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @return <code>double</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Double getDouble(String name) {
		return getDouble(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を<code>double</code>で取得します.<br>
	 * {@link Double#parseDouble(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/08
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>double</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Double getDouble(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toDouble(value);
	}

	/**
	 * 指定した名前で格納されているアップロードファイルを取得します.<br>
	 * 値が複数格納されている場合は、リストの先頭から検索し、最初に見つかったアップロードファイルを取得します。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getFile(java.lang.String)
	 * @create 2007/01/16
	 * @param name 名前
	 * @return アップロードファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GUploadFile getFile(String name) {
		GUploadFile[] files = _files.get(name);
		if (files != null) {
			return files[0];
		} else {
			return null;
		}
	}

	/**
	 * 指定した名前で格納されているアップロードファイルリストの中から、指定したインデックスに該当するアップロードファイルを取得します.<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getValue(java.lang.String, int)
	 * @create 2007/01/16
	 * @param name 名前
	 * @param index インデックス
	 * @return アップロードファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GUploadFile getFile(String name, int index) {
		GUploadFile[] files = _files.get(name);
		if (files != null) {
			return files[index];
		} else {
			return null;
		}
	}

	/**
	 * 指定した名前で格納されているアップロードファイルの数を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getFileCount(java.lang.String)
	 * @create 2007/01/15
	 * @param name 名前
	 * @return アップロードファイルの数
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public int getFileCount(String name) {
		GUploadFile[] files = _files.get(name);
		if (files != null) {
			return files.length;
		} else {
			return 0;
		}
	}

	/**
	 * 指定した名前で格納されているアップロードファイルリストを配列で取得します.<br>
	 * 要素が1つしか格納されていないものに対しては、サイズ1の配列が返されます。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getFies(java.lang.String)
	 * @create 2007/01/15
	 * @param name 名前
	 * @return アップロードファイル配列
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GUploadFile[] getFiles(String name) {
		return _files.get(name);
	}

	/**
	 * アップロードファイルマップを{@link Map}で返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getFilesMap()
	 * @create 2007/01/15
	 * @return アップロードファイルマップ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Map<String, GUploadFile[]> getFilesMap() {
		return _files;
	}

	/**
	 * 指定された名前で格納されている値を<code>float</code>で取得します.<br>
	 * {@link Float#parseFloat(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>float</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Float getFloat(String name) {
		return getFloat(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を<code>float</code>で取得します.<br>
	 * {@link Float#parseFloat(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>float</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Float getFloat(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toFloat(value);
	}

	/**
	 * 指定された名前で格納されている値を<code>int</code>で取得します.<br>
	 * {@link Integer#parseInt(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>int</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Integer getInteger(String name) {
		return getInteger(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を<code>int</code>で取得します.<br>
	 * {@link Integer#parseInt(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>int</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Integer getInteger(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toInteger(value);
	}

	/**
	 * 指定された名前で格納されている値を<code>long</code>で取得します.<br>
	 * {@link Long#parseLong(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>long</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Long getLong(String name) {
		return getLong(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を<code>long</code>で取得します.<br>
	 * {@link Long#parseLong(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>long</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Long getLong(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toLong(value);
	}

	/**
	 * 指定された名前で格納されている値を<code>short</code>で取得します.<br>
	 * {@link Short#parseShort(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @return <code>short</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Short getShort(String name) {
		return getShort(name, 0);
	}

	/**
	 * 指定された名前で格納されている値を<code>short</code>で取得します.<br>
	 * {@link Short#parseShort(String)}された値が返されます。<br>
	 * 
	 * @create 2007/03/09
	 * @param name 名前
	 * @param index インデックス
	 * @return <code>short</code>値
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public Short getShort(String name, int index) {
		String value = getValue(name, index);
		return GConvertUtils.toShort(value);
	}

	/**
	 * エラーへの対応区分を取得します .<br>
	 * エラーへの対応区分は、パラメータ内に{@link GActionServlet#VALIDATE_KEY}キーで登録されている値を元に判定します。<br>
	 * [1]値が"none"の場合、{@link GValidationType#NONE}を返します。<br>
	 * [2]値が"error"の場合、{@link GValidationType#ERROR}を返します。<br>
	 * [3]上記以外の場合、{@link GValidationType#ALL}を返します。<br>
	 * 
	 * @create 2007/02/07
	 * @return GValidationType
	 * @author aono
	 * @since 3.0.0
	 */
	public GErrorLevel getValidationLevel() {
		String key = getValue(GActionServlet.VALIDATE_KEY);

		return GErrorLevel.convert(key);
	}

	/**
	 * 指定した名前で格納されているパラメータを取得します.<br>
	 * 値が複数格納されている場合は、リストの先頭から検索し、最初に見つかったパラメータを取得します。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getValue(java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @return パラメータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getValue(String name) {
		String[] values = _values.get(name);
		if (values != null) {
			return values[0];
		} else {
			return null;
		}
	}

	/**
	 * 指定した名前で格納されているパラメータリストの中から、指定したインデックスに該当するパラメータを取得します.<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getValue(java.lang.String, int)
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @return パラメータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getValue(String name, int index) {
		String[] values = _values.get(name);
		if (values != null) {
			return values[index];
		} else {
			return null;
		}
	}

	/**
	 * 指定した名前で格納されているパラメータの数を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getValueCount(java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @return パラメータの数
	 * @author kitamura
	 * @since 3.0.0
	 */
	public int getValueCount(String name) {
		String[] values = _values.get(name);
		if (values != null) {
			return values.length;
		} else {
			return 0;
		}
	}

	/**
	 * 指定した名前で格納されているパラメータリストを配列で取得します.<br>
	 * 要素が1つしか格納されていないものに対しては、サイズ1の配列が返されます。<br>
	 * 該当する値が存在しない場合は<code>null</code>を返します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getValues(java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @return パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String[] getValues(String name) {
		return _values.get(name);
	}

	/**
	 * パラメータマップを{@link Map}で返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#getValuesMap()
	 * @create 2007/01/12
	 * @return パラメータマップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Map<String, String[]> getValuesMap() {
		return _values;
	}

	/**
	 * 指定されたリクエストの情報を解析し、{@link GParameter}オブジェクト内に展開します.<br>
	 * 通常のリクエストの場合、リクエストに格納されているパラメータマップをコピーします.<br>
	 * マルチパートリクエストの場合は、アップロードされたファイルをファイルマップ、
	 * それ以外のフォームパラメータはパラメータマップに格納されます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#parseRequest(jakarta.servlet.http.HttpServletRequest)
	 * @create 2007/01/12
	 * @param request リクエスト
	 * @throws GCoreException リクエストの解析に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void parseRequest(HttpServletRequest request) throws GCoreException {
		if (request.getContentType() != null && request.getContentType().startsWith("multipart/form-data")) {
			parseMultipartRequest(request);
		} else {
			parseNomalRequest(request);
		}
	}

	/**
	 * 指定された名前に関連づくアップロードファイルをアップロードファイルマップから削除します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#removeFile(java.lang.String)
	 * @create 2007/01/15
	 * @param name 名前
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void removeFile(String name) {
		_files.remove(name);
	}

	/**
	 * 指定した名前とインデックスに関連づくアップロードファイルリストをアップロードファイルマップから削除します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#removeFile(java.lang.String, int)
	 * @create 2007/01/15
	 * @param name 名前
	 * @param index インデックス
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void removeFile(String name, int index) {
		GUploadFile[] files = _files.get(name);
		if (files != null) {
			GUploadFile[] newFiles = new GUploadFile[files.length - 1];
			int j = 0;
			for (int i = 0; i < files.length; i++) {
				if (i != index) {
					newFiles[j] = files[i];
					j++;
				}
			}

			_files.put(name, newFiles);
		}
	}

	/**
	 * 指定された名前に関連づくパラメータをパラメータマップから削除します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#removeValue(java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void removeValue(String name) {
		_values.remove(name);
	}

	/**
	 * 指定した名前とインデックスに関連づくパラメータリストをパラメータマップから削除します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#removeValue(java.lang.String, int)
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void removeValue(String name, int index) {
		String[] values = _values.get(name);
		if (values != null) {
			String[] newValues = new String[values.length - 1];
			int j = 0;
			for (int i = 0; i < values.length; i++) {
				if (i != index) {
					newValues[j] = values[i];
					j++;
				}
			}

			_values.put(name, newValues);
		}
	}

	/**
	 * 指定した名前でアップロードファイルを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#setFile(java.lang.String, jp.co.kccs.greenearth.framework.GUploadFile)
	 * @create 2007/01/15
	 * @param name 名前
	 * @param file アップロードファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setFile(String name, GUploadFile file) {
		GUploadFile[] files = new GUploadFile[1];
		files[0] = file;
		_files.put(name, files);
	}

	/**
	 * 指定した名前で格納されているアップロードファイルリストの、指定したインデックスにアップロードファイルを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。<br>
	 * 指定された名前のリストが存在しない場合に、インデックスに0以外の値が指定された場合は{@link IndexOutOfBoundsException}がスローされます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#setFile(java.lang.String, int, jp.co.kccs.greenearth.framework.GUploadFile)
	 * @create 2007/01/15
	 * @param name 名前
	 * @param index インデックス
	 * @param file アップロードファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setFile(String name, int index, GUploadFile file) {
		GUploadFile[] files = _files.get(name);
		if (files == null) {
			if (index != 0) {
				throw new IndexOutOfBoundsException("Index is invalid.");
			}
			GUploadFile[] newFiles = new GUploadFile[1];
			newFiles[0] = file;
			_files.put(name, newFiles);
		} else {
			files[index] = file;
			_files.put(name, files);
		}
	}

	/**
	 * 指定した名前でアップロードファイルの配列を格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#setFiles(java.lang.String, jp.co.kccs.greenearth.framework.GUploadFile[])
	 * @create 2007/01/15
	 * @param name 名前
	 * @param files アップロードファイル配列
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setFiles(String name, GUploadFile[] files) {
		_files.put(name, files);
	}

	/**
	 * 指定した名前で格納されているパラメータリストの、指定したインデックスにパラメータを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。<br>
	 * 指定された名前のリストが存在しない場合に、インデックスに0以外の値が指定された場合は{@link IndexOutOfBoundsException}がスローされます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#setValue(java.lang.String, int, java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @param index インデックス
	 * @param value パラメータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setValue(String name, int index, String value) {
		String[] values = _values.get(name);
		if (values == null) {
			if (index != 0) {
				throw new IndexOutOfBoundsException("Index is invalid.");
			}
			String[] newValues = new String[1];
			newValues[0] = value;
			_values.put(name, newValues);
		} else {
			values[index] = value;
			_values.put(name, values);
		}
	}

	/**
	 * 指定した名前でパラメータを格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#setValue(java.lang.String, java.lang.String)
	 * @create 2007/01/12
	 * @param name 名前
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setValue(String name, String value) {
		String[] values = new String[1];
		values[0] = value;
		_values.put(name, values);
	}

	/**
	 * 指定した名前でパラメータの配列を格納します.<br>
	 * 既に同じ名前の値が格納されている場合は上書きます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#setValues(java.lang.String, java.lang.String[])
	 * @create 2007/01/12
	 * @param name 名前
	 * @param values パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setValues(String name, String[] values) {
		_values.put(name, values);
	}

	/**
	 * 格納している要素を"name=value"形式で文字列化しています.<br>
	 * アップロードファイル情報は、ファイル名のみ出力します。
	 * 
	 * @see java.lang.Object#toString()
	 * @create 2007/01/16
	 * @return 格納要素を表示する文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public String toString() {
		StringBuilder log = new StringBuilder();
		for (String name : valuesKeySet()) {
			String[] values = getValues(name);
			if (values.length == 1) {
				log.append(name + "=" + values[0] + ";");
			} else {
				for (int i = 0; i < values.length; i++) {
					log.append(name + "[" + i + "]" + "=" + values[i] + ";");
				}
			}
		}
		for (String name : filesKeySet()) {
			GUploadFile[] files = getFiles(name);
			if (files.length == 1) {
				log.append(name + "=" + files[0].getName() + ";");
			} else {
				for (int i = 0; i < files.length; i++) {
					log.append(name + "[" + i + "]" + "=" + files[i].getName() + ";");
				}
			}
		}
		return log.toString();
	}

	/**
	 * パラメータマップに格納されている名前のセットビューを返します.<br>
	 * セットは{@link GParameter}と連動しているので、{@link GParameter}に対する変更はセットに反映され、またセットに
	 * 対する変更は{@link GParameter}に反映されます。
	 * 
	 * @see jp.co.kccs.greenearth.framework.GParameter#valuesKeySet()
	 * @create 2007/01/12
	 * @return パラメータの名前セット
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Set<String> valuesKeySet() {
		return _values.keySet();
	}

	/**
	 * アップロード可能ファイル最大サイズを取得します.
	 * 
	 * @create 2007/01/19
	 * @return String アップロード可能ファイル最大サイズ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected String getUploadfileMaxSize() {
		return _uploadfileMaxSize;
	}

	/**
	 * アップロードファイルテンポラリディレクトリを取得します.
	 * 
	 * @create 2007/01/19
	 * @return String アップロードファイルテンポラリディレクトリ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected String getUploadfileTempDir() {
		if (_uploadfileTempDir == null) {
			return GFrameworkUtils.getProperty(UPLOADFILE_TEMP_DIR_KEY, UPLOADFILE_TEMP_DIR_DEFAULT);
		} else {
			return _uploadfileTempDir;
		}
	}

	/**
	 * アップロードファイルテンポラリサイズを取得します.
	 * 
	 * @create 2007/01/19
	 * @return String アップロードファイルテンポラリサイズ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected String getUploadfileTempSize() {
		if (_uploadfileTempSize == null) {
			return GFrameworkUtils.getProperty(UPLOADFILE_TEMP_SIZE_KEY, UPLOADFILE_TEMP_SIZE_DEFAULT);
		} else {
			return _uploadfileTempSize;
		}
	}

	/**
	 * 指定されたマルチパートリクエストの情報を解析し、アップロードされたファイルをファイルマップに格納します.
	 * 
	 * @create 2007/01/15
	 * @param request リクエスト
	 * @throws GCoreException リクエストの解析に失敗した場合
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected void parseMultipartRequest(HttpServletRequest request) throws GCoreException {

		int tempSize = Integer.parseInt(getUploadfileTempSize());
		String tempDir = getUploadfileTempDir();

		DiskFileItemFactory factory = (tempDir != null) ? (DiskFileItemFactory.builder().setBufferSize(tempSize).setFile(tempDir).get())
				: (DiskFileItemFactory.builder().setBufferSize(tempSize).get());

		JakartaServletDiskFileUpload upload = new JakartaServletDiskFileUpload(factory);
		int maxsize = Integer.parseInt(getUploadfileMaxSize());
		upload.setSizeMax(maxsize);
		Optional<Charset> charset = getCharsetFrom(request);
		
		if (charset.isPresent()) {
			upload.setHeaderCharset(charset.get());
		}
		
		try {
			upload.parseRequest(request)
				.stream()
				.forEach(f -> {
					if (f.isFormField()) {
						addValue(getFieldName(f), getValueFrom(f, charset));
					} else {
						addFile(f.getFieldName(), new GUploadFileImpl(f));
					}
				});
		} catch (FileUploadException e) {
			throw new GCoreException(e);
		}
	}


	/**
	 * 指定されたリクエストを情報を解析し、フォームパラメータをパラメータマップに格納します.
	 * 
	 * @create 2007/01/15
	 * @param request リクエスト
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected void parseNomalRequest(HttpServletRequest request) {
		Enumeration< ? > keys = request.getParameterNames();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String[] data = request.getParameterValues(key);
			int dataSize = data.length;
			if (dataSize == 1) {
				setValue(key, data[0]);
			} else {
				setValues(key, data);
			}
		}
	}

	/**
	 * アップロード可能ファイル最大サイズを設定します.
	 * 
	 * @create 2007/01/19
	 * @param maxSize アップロード可能ファイル最大サイズ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected void setUploadfileMaxSize(String maxSize) {
		_uploadfileMaxSize = maxSize;
	}

	/**
	 * アップロードファイルテンポラリディレクトリを設定します.
	 * 
	 * @create 2007/01/19
	 * @param tempDir アップロードファイルテンポラリディレクトリ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected void setUploadfileTempDir(String tempDir) {
		_uploadfileTempDir = tempDir;
	}

	/**
	 * アップロードファイルテンポラリサイズを設定します.
	 * 
	 * @create 2007/01/19
	 * @param tempSize アップロードファイルテンポラリサイズ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected void setUploadfileTempSize(String tempSize) {
		_uploadfileTempSize = tempSize;
	}

	private Optional<Charset> getCharsetFrom(HttpServletRequest request) {
		String encoding = request.getCharacterEncoding();
		return Objects.nonNull(encoding) ? Optional.ofNullable(Charset.forName(request.getCharacterEncoding())) : Optional.empty();
	}
	
	private String getValueFrom(DiskFileItem fileItem, Optional<Charset> charset) {
		try {
			return charset.isPresent() ? fileItem.getString(charset.get()) : fileItem.getString();
		} catch (IOException e) {
			throw new GCoreException(e);
		} 
	}
	
	private String getFieldName(DiskFileItem fileItem) {
		return fileItem.getFieldName();
	}
}
