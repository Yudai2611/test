/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;
import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.utils.GFileDownloadUtils;

/**
 * {@link GResultData}を元に、マッピングされたURLのリクエストに対するレスポンスを生成フィルターです。<br>
 * 生成したレスポンスデータは{@link HttpServletResponse}に書き込まれクライアントに返されます。<br>
 * このフィルターでは、リクエストからの処理要求があったタイミングで、{@link HttpServletRequest}に{@value GConstants#RESULT_DATA_KEY}キーにて
 * {@link GResultData}を格納します。<br>
 * 後続のフィルターやサーブレット、アクションでの処理では、この{@link GResultData}に対し処理結果を格納していく事で、
 * 最終的にこのフィルターに処理が戻ってきた段階で、その内容がレスポンストして出力される事になります。<br>
 * 
 * @create 2009/08/24
 * @author yamashita
 * @since 3.6.0
 */
public abstract class GResponseFilter extends GExcludableFilter {
	
	/** ダウンロードファイルバッファ　デフォルト値. */
	protected static final String DOWNLOADFILE_BUFFER_DEFAULT = "4096";
	
	/** ダウンロードファイルバッファ　KEY名. */
	protected static final String DOWNLOADFILE_BUFFER_KEY = "geframe.core.FileDownload.BufferSize";
	/** ロガー */
	private static final Log LOGGER = LogFactory.getLog(GResponseFilter.class);

	/**
	 * リクエスト処理の復路にてレスポンスの書き込みを実施します。
	 * 
	 * @create 2009/08/24
	 * @see GExcludableFilter#doFilter(HttpServletRequest, HttpServletResponse, FilterChain)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain フィルターチェーン
	 * @throws IOException レスポンスの書き込みに失敗した場合
	 * @throws ServletException フィルター処理に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		try {
			prepareResultData(request, response);
			
			// Pass control on to the next filter
			chain.doFilter(request, response);
			
			// レスポンスの書き込み
			writeResponse(request, response);
		}
		catch (Exception e) {
			handleException(request, response, e);
		}
	}

	/**
	 * レスポンスの書き込みに失敗した場合のエラーハンドリングを行います。<br>
	 * 内部でエラーハンドリング処理を{@link #writeErrorResponse(HttpServletRequest, HttpServletResponse, GParameter, Throwable)}に委譲しています。
	 * 
	 * @create 2009/08/22
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param exception 例外オブジェクト
	 * @throws ServletException エラーレスポンスの生成に失敗した場合
	 * @throws IOException エラーレスポンスの生成に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected void handleException(HttpServletRequest request, HttpServletResponse response, Throwable exception) throws ServletException, IOException {
		LOGGER.error("Handle Error!!!", exception);

		Throwable realEx = exception;
		if (exception instanceof ServletException) {
			while (true) {
				if (realEx instanceof ServletException) {
					ServletException se = (ServletException) realEx;
					Throwable cause = se.getRootCause();
					if (cause == null) {
						break;
					}
					LOGGER.error("Error Cause!!!", cause);
					realEx = cause;
				} else {
					break;
				}
			}
		}

		try {
			LOGGER.info("Write Error Response Start");
			GStopWatch watch = new GStopWatch();
			watch.start();

			GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
			writeErrorResponse(request, response, parameter, realEx);

			LOGGER.info("Write Error Response End (" + watch.stop() + ")");
		} catch (ServletException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}
	
	/**
	 * リクエスト処理の往路時に行う準備処理です。<br>
	 * {@link HttpServletRequest}に{@link GResultData}を格納しています。
	 * 
	 * @create 2009/08/22
	 * @param request リクエスト
	 * @param response レスポンス
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected void prepareResultData(HttpServletRequest request, HttpServletResponse response) {
		/// 結果セットの設定
		GResultData resultData = GResultData.Factory.create(GResultData.EXIT_CODE_DIRECT_RESPONSE);
		request.setAttribute(GConstants.RESULT_DATA_KEY, resultData);
	}
	
	/**
	 * {@link GResultData}に格納された{@link GDownloadFile}情報をダウンロードデータしてレスポンスに出力します。<br>
	 * レスポンスの書き込み処理はバッファリングされており、バッファーサイズはプロパティファイルの
	 * <code>geframe.core.FileDownload.BufferSize</code>項目にバイト単位で指定できます。
	 * 指定され無かった場合は、4096になります。
	 * 
	 * @create 2009/08/10
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果オブジェクト
	 * @throws IOException I/O処理に失敗した場合
	 * @throws ServletException レスポンスの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected void writeDownloadResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter, GResultData resultData) throws IOException, ServletException {		
		LOGGER.info("Write File Download Response Start");
		GStopWatch watch = new GStopWatch();
		watch.start();
		
		// ファイルダウンロード
		GDownloadFile file = resultData.getDownloadFile();
		if (file.getBufferSize() == -1) {
			String bufferSizeStr = GFrameworkUtils.getProperty(DOWNLOADFILE_BUFFER_KEY, DOWNLOADFILE_BUFFER_DEFAULT);
			int bufferSize = Integer.parseInt(bufferSizeStr);
			file.setBufferSize(bufferSize);
		}
		GFileDownloadUtils.writeResponse(request, response, file);
		
		LOGGER.debug("Write File Download Response End (" + watch.stop() + ") : filename=" + file.getName());
	}

	/**
	 * 指定された{@link HttpServletResponse}に対し、エラー情報{@link Throwable}の情報を書き込みます。<br>
	 * サーバーサイドの処理で例外が発生した場合に、呼び出される事を想定しています。
	 * 
	 * @create 2009/08/24
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param e 例外オブジェクト
	 * @throws IOException レスポンス書き込み時にI/Oエラーが発生した場合
	 * @throws ServletException レスポンス書き込み時にI/Oエラーが発生した場合
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected abstract void writeErrorResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter, Throwable e) throws IOException, ServletException;

	/**
	 * {@link GResultData}の終了コードが{@link GResultData#EXIT_CODE_DIRECT_RESPONSE}、{@link GResultData#EXIT_CODE_FILE_DOWNLOAD}、
	 * {@link GResultData#EXIT_CODE_SYSTEM_ERROR}、{@link GResultData#EXIT_CODE_VALIDATE_ERROR}以外の場合のレスポンスデータを生成します。<br>
	 * 
	 * @create 2009/08/24
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @throws IOException I/O処理に失敗した場合
	 * @throws ServletException レスポンスの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected abstract void writeNomalResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter, GResultData resultData) throws IOException, ServletException;

	/**
	 * レスポンスの書き出し処理を行います。<br>
	 * {@link GResultData}の終了コード別に処理を分岐しています。<br>
	 * <br>
	 * <table border="1" cellpadding="3" cellspacing="0">
	 * <tr bgcolor="#CCCCFF"><td>{@link GResultData#EXIT_CODE_DIRECT_RESPONSE}</td><td>なにも処理は行いません</td></tr>
	 * <tr><td>{@link GResultData#EXIT_CODE_SYSTEM_ERROR}</td><td>{@link #writeErrorResponse(HttpServletRequest, HttpServletResponse, GParameter, Throwable)}を呼び出します</td><tr>
	 * <tr><td>{@link GResultData#EXIT_CODE_FILE_DOWNLOAD}</td><td>{@link #writeDownloadResponse(HttpServletRequest, HttpServletResponse, GParameter, GResultData)を呼び出します}</td></tr>
	 * <tr><td>上記以外</td><td>{@link #writeNomalResponse(HttpServletRequest, HttpServletResponse, GParameter, GResultData)}を呼び出します</td></tr>
	 * </table>
	 * 
	 * @create 2009/08/24
	 * @param request リクエスト
	 * @param response レスポンス
	 * @throws IOException レスポンスの出力に失敗した場合
	 * @throws ServletException レスポンスの出力に失敗した場合
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected void writeResponse(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
		GResultData resultData = (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);

		LOGGER.info("Write Response Start : exitcode=" + resultData.getExitCode());
		GStopWatch watch = new GStopWatch();
		watch.start();

		// ※終了コードがDIRECT_RESPONSEの場合、何も処理を行いません。
		if (!GResultData.EXIT_CODE_DIRECT_RESPONSE.equals(resultData.getExitCode())) {
			
			if (GResultData.EXIT_CODE_SYSTEM_ERROR.equals(resultData.getExitCode())) {
				// エラー
				Throwable e = resultData.getException();
				writeErrorResponse(request, response, parameter, e);
			} else if (GResultData.EXIT_CODE_FILE_DOWNLOAD.equals(resultData.getExitCode())) {
				// ダウンロード処理
				writeDownloadResponse(request, response, parameter, resultData);
			} else {
				// 各種サーブレットが提供するデフォルトのレスポンス形態
				writeNomalResponse(request, response, parameter, resultData);
			}
		}
		
		LOGGER.info("Write Response End (" + watch.stop() + ")");
	}

}
