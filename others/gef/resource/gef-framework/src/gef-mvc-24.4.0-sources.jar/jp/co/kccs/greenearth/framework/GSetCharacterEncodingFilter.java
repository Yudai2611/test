/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

/**
 * リクエストパラメータに対する文字エンコーディングを設定するフィルタです.<br>
 * Tomcatのサンプルプログラムに含まれている{@link SetCharacterEncodingFilter}をそのまま移植しています。<br>
 * <ul>
 * <li><strong>encoding</strong> - エンコードに利用する文字セット</li>
 * <li><strong>ignore</strong> - <code>"true"</code>を設定した場合は、フィルターでセットされる文字セットを適用します。
 *     <code>"false"</code>を指定された場合は、クライアントで指定されている文字セットが適用されます。
 *     デフォルト値は<code>"true"</code>になります。</li>
 * </ul>
 * 
 * @create 2006/04/21
 * @author kitamura
 * @since 3.0.0
 */
public class GSetCharacterEncodingFilter implements Filter {

	/** エンコードに利用する文字セット. */
	protected String _encoding = null;
	/** FilterConfigオブジェクト. */
	protected FilterConfig _filterConfig = null;
	/** エンコーディング指定を無視するかを表す値. */
	protected boolean _ignore = true;
	
	/**
	 * {@link GSetCharacterEncodingFilter}インスタンスを初期化します。
	 * 
	 * @create 2009/07/23
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GSetCharacterEncodingFilter() {
	}

	/**
	 * サービス状態を終えた事を{@link Filter}に伝えるために Web コンテナが呼び出します.<br>
	 * エンコード文字セットと{@link FilterConfig}オブジェクトの破棄を行っています。
	 * 
	 * @see jakarta.servlet.Filter#destroy()
	 * @create 2006/04/21
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void destroy() {
		_encoding = null;
		_filterConfig = null;
	}

	/**
	 * フィルター実行メソッドです.<br>
	 * ここでは、初期化パラメータによって指定されたエンコーディングをリクエストにセットしています。
	 * 
	 * @see jakarta.servlet.Filter#doFilter(jakarta.servlet.ServletRequest, jakarta.servlet.ServletResponse, jakarta.servlet.FilterChain)
	 * @create 2006/04/21
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain フィルターチェーン
	 * @throws IOException I/Oエラーが発生した場合
	 * @throws ServletException サーブレット例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// Conditionally select and set the character encoding to be used
		if (_ignore || (request.getCharacterEncoding() == null)) {
			String encoding = selectEncoding(request);
			if (encoding != null) {
				request.setCharacterEncoding(encoding);
			}
		}

		// Pass control on to the next filter
		chain.doFilter(request, response);

	}

	/**
	 * Web コンテナは、{@link Filter}をサービス状態にするために{@link #init(FilterConfig)}メソッドを呼び出します.<br>
	 * ここでは{@link FilterConfig}オブジェクトの取得を行っています。
	 * 
	 * @see jakarta.servlet.Filter#init(jakarta.servlet.FilterConfig)
	 * @create 2006/04/21
	 * @param filterConfig FilterConfigオブジェクト
	 * @throws ServletException サーブレット例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		this._filterConfig = filterConfig;
		this._encoding = filterConfig.getInitParameter("encoding");
		String value = filterConfig.getInitParameter("ignore");
		if (value == null) {
			_ignore = true;
		}
		else if (value.equalsIgnoreCase("true")) {
			_ignore = true;
		}
		else if (value.equalsIgnoreCase("yes")) {
			_ignore = true;
		}
		else {
			_ignore = false;
		}
	}

	/**
	 * 指定されたリクエストより、エンコードに利用する文字コードを選択します.<br>
	 * ここでは、初期値パラメータの<code>encoding</code>項目に指定された値を選択します。
	 * 
	 * @create 2006/04/21
	 * @param request リクエスト
	 * @return 文字セット
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected String selectEncoding(ServletRequest request) {
		return _encoding;
	}

}
