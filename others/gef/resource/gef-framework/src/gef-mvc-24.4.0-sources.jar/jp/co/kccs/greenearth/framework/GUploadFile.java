/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import jakarta.servlet.http.HttpServletRequest;


/**
 * クライアントよりマルチパートリクエストによってアップロードされたファイルを表します.<br>
 * アップロードされたファイル情報は、{@link GActionServlet}により捕捉され、{@link GParameter}の
 * {@link GParameter#parseRequest(HttpServletRequest)}にリクエストを基に生成され、
 * その{@link GParameter}に格納されます。<br>
 * 
 * アップロードされたファイル情報を管理する方法（メモリ上、ディスク保存、DB保存、etc...)
 * は実装によって異なります。<br>
 * 詳しくは書く実装内容を確かめてください。 
 * 
 * @see jp.co.kccs.greenearth.framework.GParameter
 * @create 2007/01/13
 * @author kitamura
 * @since 3.0.0
 */
public interface GUploadFile {

	/**
	 * アップロードファイル情報を管理しているメモリ領域、一時ディスク領域等のストレージを解放します.<br>
	 * このメソッド実行後は、同じ{@link GUploadFile}インスタンスに対しての以下のメソッドの動作の保障をしません。<br>
	 * 　{@link #getInputStream()}<br>
	 * 　{@link #getBytes()}<br>
	 * 　{@link #write(File)}<br>
	 * また、このメソッドの二度目以降の呼び出しでは何も実行されません。
	 * 
	 * @create 2007/01/13
	 * @author kitamura
	 * @since 3.0.0
	 */
	void delete();

	/**
	 * ファイルアイテムの内容をバイト配列で返します.
	 * 
	 * @create 2007/01/13
	 * @return ファイルアイテムの内容を示すバイト配列
	 * @author kitamura
	 * @since 3.0.0
	 */
	byte[] getBytes();

	/**
	 * ブラウザによって付加されたコンテントタイプを返します.
	 * 
	 * @create 2007/01/13
	 * @return コンテントタイプ
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getContentType();

	/**
	 * ファイルの内容を取得するための{@link InputStream}を返します.
	 * 
	 * @create 2007/01/13
	 * @return ファイルの内容を取得するための{@link InputStream}
	 * @throws IOException ストリームの取得に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	InputStream getInputStream() throws IOException;

	/**
	 * クライアントのファイルシステム上でのオリジナルのファイル名を返します.<br>
	 * ディレクトリ名は取得できません。
	 * 
	 * @create 2007/01/13
	 * @return ファイル名
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getName();

	/**
	 * ファイルアイテムのサイズを返します.
	 * 
	 * @create 2007/01/13
	 * @return ファイルアイテムのバイト単位のサイズ 
	 * @author kitamura
	 * @since 3.0.0
	 */
	long getSize();

	/**
	 * アップロードファイルをディスクに書き出します.<br>
	 * このメソッド実行後は、同じ{@link GUploadFile}インスタンスに対しての以下のメソッドの動作の保障をしません。<br>
	 * 　{@link #getInputStream()}<br>
	 * 　{@link #getBytes()}<br>
	 * 　{@link #write(File)}
	 * 
	 * @create 2007/01/13
	 * @param file アップロードアイテムの出力先となる{@link File} 
	 * @throws IOException ファイルの保存に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	void write(File file) throws IOException;
}
