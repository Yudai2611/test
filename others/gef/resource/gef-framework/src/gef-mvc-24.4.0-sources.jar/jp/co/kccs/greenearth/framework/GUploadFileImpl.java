/*
 * Copyright 2007-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.fileupload2.core.FileItem;

/**
 * {@link GUploadFile}のデフォルト実装です.<br>
 * クライアントよりマルチパートリクエストによってアップロードされたファイルを表します.<br>
 * <br>
 * このクラスは{@link GParameter}のデフォルト実装クラスである{@link GParameterImpl}で使用されています。
 * <br>
 * 
 * @see jp.co.kccs.greenearth.framework.GUploadFile
 * @create 2007/01/15
 * @author fujikawa
 * @since 3.0.0
 */
public class GUploadFileImpl implements GUploadFile {

	/** アップロードファイルファイル名. */
	private String _fileName = null;
	/** アップロードファイル. */
	private FileItem _fileItem = null;

	/**
	 * {@link GUploadFileImpl}インスタンスを初期化します.
	 * 
	 * @create 2007/01/15
	 * @param fileItem アップロードファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GUploadFileImpl(FileItem fileItem) {
		_fileItem = fileItem;

		// Httpプロトコルの規定ではファイルをアップロードした際にファイル名が
		// 同時に送信されますが、IEでは不具合の為、ファイル名ではなくフルパスが
		// 送信されます。
		// 以下の処理では、上記の問題に対応するため、パス情報を除去する処理を
		// 行なっています。
		String fileName = fileItem.getName();
		if (fileName != null && !fileName.equals("")) {
			// サーバがLinuxの場合、ウィンドウズのファイルセパレータ"\\"が認識でき
			// ないので、ファイル名に"\\"が含まれる場合、最後に出現する"\\"以降を
			// ファイル名として使用します。
			int index = fileName.lastIndexOf("\\");
			if (index != -1) {
				fileName = fileName.substring(index + 1);
			}

			_fileName = (new File(fileName)).getName();
		}
		else {
			_fileItem = fileItem;
		}
	}

	/**
	 * アップロードファイル情報を管理しているメモリ領域、一時ディスク領域等のストレージを解放します.<br>
	 * このメソッド実行後は、同じ{@link GUploadFile}インスタンスに対しての以下のメソッドの動作の保障をしません。<br>
	 * 　{@link #getInputStream()}<br>
	 * 　{@link #getBytes()}<br>
	 * 　{@link #write(File)}<br>
	 * また、このメソッドの二度目以降の呼び出しでは何も実行されません。
	 * 
	 * @create 2007/01/15
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void delete() {
		try {
			_fileItem.delete();
		} catch (IOException e) {
			throw new GCoreException(e);
		}
	}

	/**
	 * ファイルアイテムの内容をバイト配列で返します.
	 * 
	 * @create 2007/01/15
	 * @return ファイルアイテムの内容を示すバイト配列
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public byte[] getBytes() {
		return _fileItem.get();
	}

	/**
	 * ブラウザによって付加されたコンテントタイプを返します.
	 * 
	 * @create 2007/01/15
	 * @return コンテントタイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public String getContentType() {
		return _fileItem.getContentType();
	}

	/**
	 * ファイルの内容を取得するための{@link InputStream}を返します.
	 * 
	 * @create 2007/01/15
	 * @return ファイルの内容を取得するための{@link InputStream}
	 * @throws IOException ファイルの保存に失敗した場合
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public InputStream getInputStream() throws IOException {
		return _fileItem.getInputStream();
	}

	/**
	 * クライアントのファイルシステム上でのオリジナルのファイル名を返します.<br>
	 * ディレクトリ名は取得できません。
	 * 
	 * @create 2007/01/15
	 * @return ファイル名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public String getName() {
		return _fileName;
	}

	/**
	 * ファイルアイテムのサイズを返します.
	 * 
	 * @create 2007/01/15
	 * @return ファイルアイテムのバイト単位のサイズ 
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public long getSize() {
		return _fileItem.getSize();
	}

	/**
	 * アップロードファイルをディスクに書き出します.<br>
	 * このメソッド実行後は、同じ{@link GUploadFile}インスタンスに対しての以下のメソッドの動作の保障をしません。<br>
	 * 　{@link #getInputStream()}<br>
	 * 　{@link #getBytes()}<br>
	 * 　{@link #write(File)}
	 * 
	 * @create 2007/01/15
	 * @param file アップロードアイテムの出力先となる{@link File} 
	 * @throws IOException ファイルの保存に失敗した場合
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void write(File file) throws IOException {

		try {
			if (file.getParentFile() != null && !file.getParentFile().exists()) {
				file.getParentFile().mkdir();
			}
			_fileItem.write(file.toPath());
		}
		catch (IOException e) {
			throw e;
		}
		catch (Exception e) {
			IOException ie = new IOException();
			ie.initCause(e);
			throw ie;
		}
	}
}
