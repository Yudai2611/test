/*
 * Copyright 2009-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;
import jp.co.kccs.greenearth.framework.action.GOneTimeTokenException;
import jp.co.kccs.greenearth.framework.data.GResultData;

/**
 * ワンタイムトークン照合処理を行うフィルターです.<br>
 * セッションに保持したトークンと画面に埋め込んだトークンを照合し、一致しなかった場合はアクションの呼び出しを禁止します。<br>
 * <br>
 * [トークンの取得]<br>
 * 画面生成時、{@link HttpSession}に"[ViewのID]=トークン文字列"として保持しています。
 * トークン照合処理時、{@link GParameter}の"viewid"の値をキーとして{@link HttpSession}からトークン文字列を取得します。<br>
 * <br>
 * [トークン照合処理の切り替え]<br>
 * トークン照合処理を行う場合は、このフィルタをデプロイメントディスクリプタ(<code>web.xml</code>)に指定してください。<br>
 * フィルタの初期化パラメータ"suffix"に指定された値とアクションメソッドの最後尾文字列が一致した場合にトークン照合処理を行います。<br>
 * アクション単位でトークンの照合処理の切り替えたい場合、フィルタの初期化パラメータ"suffix"を適切な値に変更してください。<br>
 * 
 * @create 2009/07/10
 * @author okajima
 * @since 3.6.0
 */
public class GVerifyOneTimeTokenFilter extends GExcludableFilter {

	/** 初期化パラメータ"suffix"の値. */
	protected String _actionSuffix = null;

	/**
	 * {@link GVerifyOneTimeTokenFilter}インスタンスを初期化します。
	 * 
	 * @create 2009/07/10
	 * @auther okajima
	 * @since 3.6.0
	 */
	public GVerifyOneTimeTokenFilter() {
	}

	/**
	 * パラメータのトークン文字列と、
	 * セッションに保持されたワンタイムトークンの照合処理を行います。
	 * 
	 * @create 2009/11/13
	 * @see GExcludableFilter#doFilter(HttpServletRequest, HttpServletResponse, FilterChain)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain FilterChain
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException 照合処理に失敗した場合
	 * @author okajima
	 * @since 3.6.0
	 */
	@Override
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException{
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
		try {
			resetTokenError(request);
			if (shouldCheckOneTimeToken(request, response)) {
				checkOneTimeToken(request, parameter);
			}
		} catch (ServletException e) {
			handleTokenError(request, e);
			throw e;
		}
		try {
			chain.doFilter(request, response);
		} finally {
			removeOneTimeToken(request, parameter);
		}
	}
	
	/**
	 * セッションに保持されているワンタイムトークンエラーを削除します。
	 * 
	 * @create 2020/6/23
	 * @param request リクエスト
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected void resetTokenError(HttpServletRequest request) {
		HttpSession httpSession = request.getSession();
		httpSession.removeAttribute(GConstants.ONE_TIME_TOKEN_EXCEPTION_KEY);
	}
	
	/**
	 * ワンタイムトークンエラーをセッションに保持します。
	 * 
	 * @create 2020/6/23
	 * @param request リクエスト
	 * @param exception 例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected void handleTokenError(HttpServletRequest request, Throwable exception) {
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute(GConstants.ONE_TIME_TOKEN_EXCEPTION_KEY, exception);
	}

	/**
	 * 
	 * GFacadeFilterで生成したGParameterから、methodNameを取得します.<br>
	 * ※multipartのリクエストはStreamになっており、一度読み込むと中身が空になるため、requestの種類に関わらず最初に読み込んだ情報を利用します
	 * 
	 * @create 2016/05/18
	 * @param parameter {@link GParameter}オブジェクト
	 * @return 引数の parameter から取得した methodName
	 * @author kobayashi
	 * @since 3.18.0
	 */
	protected String getMethodName (GParameter parameter) {
		return parameter.getValue(GActionServlet.ACTION_METHOD_KEY);
	}
	
	/**
	 * ワンタイムトークン照合処理が必要か否かを判定します.<br>
	 * メソッド名のサフィックスが、デプロイメントディスクリプタに設定された初期化パラメータ"suffix"の値と一致した場合、trueを返します。<br>
	 * それ以外の場合はfalseを返します。
	 * 
	 * @create 2017/05/19
	 * @param request リクエスト
	 * @param response レスポンス
	 * @return ワンタイムトークン照合処理の要否  true:要／false:否
	 * @author kikuchi
	 * @since 3.20.0
	 */
	protected boolean shouldCheckOneTimeToken(HttpServletRequest request, HttpServletResponse response) {
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
		if (parameter != null) {
			String methodName = getMethodName(parameter);
			if (methodName != null) {
				int lastIndex = methodName.lastIndexOf(_actionSuffix);
				return lastIndex != -1 && (lastIndex + _actionSuffix.length()) == methodName.length();
			}
		}
		return false;
	}
	
	/**
	 * 
	 * SessionからTokenMapを取得し、OneTimeTokenの検証を行います.<br>
	 * 検証に成功した場合はtrueを返し、失敗した場合はServletExceptionをスローします。
	 * 
	 * @create 2016/05/18
	 * @param request {@link HttpServletRequest}オブジェクト
	 * @param parameter {@link GParameter}オブジェクト
	 * @return 検証結果  true:検証OK／falseは返却されません（検証NGの場合は例外をスロー）
	 * @throws ServletException 検証結果がNGの場合にスローします。
	 * @author kobayashi
	 * @since 3.18.0
	 */
	protected boolean checkOneTimeToken(HttpServletRequest request, GParameter parameter) throws ServletException {
		Map<String, String> tokenMap = getManagedTokens(request);

		String viewId = parameter.getValue(GConstants.VIEWID_KEY);
		if (viewId == null) {
			throw new ServletException(new GOneTimeTokenException("One Time Token verification is failed. \"viewid\" is not found in Request Parameter."));
		}
		
		String oneTimeTokenSession = tokenMap.get(viewId);

		if (oneTimeTokenSession == null) {
			throw new ServletException(new GOneTimeTokenException("One Time Token verification is failed. One Time Token is not found in GSession."));
		}

		String oneTimeTokenParam = parameter.getValue(GConstants.ONE_TIME_TOKEN_PARAM_KEY);

		if (oneTimeTokenParam == null) {
			throw new ServletException(new GOneTimeTokenException("One Time Token verification is failed. \"onetimetoken\" is not found in Request Parameter."));
		}

		if (oneTimeTokenParam.equals(oneTimeTokenSession)) {
			return true;
		} else {
			throw new ServletException(new GOneTimeTokenException("One Time Token verification is failed. One Time Token is mismatched."));
		}
	}

	/**
	 * セッション情報で管理されているワンタイムトークンのMapを取得します。
	 * 
	 * @create 2020/6/23
	 * @param request
	 * @return ワンタイムトークン
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@SuppressWarnings("unchecked")
	protected Map<String, String> getManagedTokens(HttpServletRequest request) {
		HttpSession httpSession = request.getSession();
		Map<String, String> tokens = (Map<String, String>) httpSession.getAttribute(GConstants.ONE_TIME_TOKEN_SESSION_KEY);
		if (tokens == null) {
			tokens = new HashMap<String, String>();
		}
		httpSession.setAttribute(GConstants.ONE_TIME_TOKEN_SESSION_KEY, tokens);
		return tokens;
	}
	
	/**
	 * 検証済みのOneTimeTokenをTokenMapから削除します.<br>
	 * 結果セットの終了ファイルダウンロード、ダイレクトレスポンス、アプリ独自の終了コードの場合は、OneTimeTokenを削除しません。
	 * 
	 * @create 2017/04/24
	 * @param request {@link HttpServletRequest}オブジェクト
	 * @param parameter {@link GParameter}オブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	@SuppressWarnings("unchecked")
	protected void removeOneTimeToken(HttpServletRequest request, GParameter parameter) {
		Map<String, String> tokenMap = (Map<String, String>) request.getSession().getAttribute(GConstants.ONE_TIME_TOKEN_SESSION_KEY);
		String viewId = parameter.getValue(GConstants.VIEWID_KEY);
		GResultData resultData = (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);

		if (tokenMap == null || viewId == null) {
			return;
		}
		if (resultData == null) {
			tokenMap.remove(viewId);
		} else {
			String exitCode = resultData.getExitCode();
			if (GResultData.EXIT_CODE_SUCCESS.equals(exitCode) || 
					GResultData.EXIT_CODE_VALIDATE_ERROR.equals(exitCode) || 
					GResultData.EXIT_CODE_SYSTEM_ERROR.equals(exitCode)) {
				tokenMap.remove(viewId);
			}
		}
	}

	/**
	 * フィルタの初期化処理を行います.<br>
	 * デプロイメントディスクリプタに設定された初期化パラメータ"suffix"をフィールドに保持します。<br>
	 * 
	 * @create 2009/07/10
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#init(jakarta.servlet.FilterConfig)
	 * @param filterConfig {@link FilterConfig}オブジェクト
	 * @throws ServletException サーブレット例外が発生した場合
	 * @author okajima
	 * @since 3.6.0
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

		super.init(filterConfig);

		this._actionSuffix = filterConfig.getInitParameter("suffix");
	}

	/**
	 * 保持しているsuffixを初期状態に戻します.<br>
	 * サービス状態を終えた事を{@link Filter}に伝えるために Web コンテナが呼び出します.
	 * 
	 * @create 2009/07/10
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#destroy()
	 * @author okajima
	 * @since 3.6.0
	 */
	@Override
	public void destroy() {

		super.destroy();
		this._actionSuffix = null;
	}
}
