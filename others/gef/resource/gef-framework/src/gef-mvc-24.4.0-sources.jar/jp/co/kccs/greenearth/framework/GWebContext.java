/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import java.util.Locale;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * Coreフレームワークにおいて、リクエスト毎の状態を管理するコンテキストです。<br>
 * {@link GWebContext}インスタンスは、フレームワークのライフサイクルにおいてリクエスト時にインスタンス化されます。
 * インスタンスの取得方法は以下になります。
 * <pre>
 * 	GWebContext context = GWebContext();
 * </pre>
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GWebContext extends GFrameworkContext {
	
	/** リクエストヘッダの許容言語識別子. */
	public static final String ACCEPT_LANGUAGE = "Accept-Language";

	/**
	 * {@link GWebContext}のインスタンスを取得します.<br>
	 * 
	 * @return インスタンス
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public static GWebContext getInstance() {
		return (GWebContext) GFrameworkContext.getInstance();
	}

	/** リクエスト. */
	private HttpServletRequest request = null;
	/** レスポンス. */
	private HttpServletResponse response = null;
	/** サーブレットコンテキスト. */
	private ServletContext servletContext = null;
	/** セッション */
	private GSession session = null;
	
	/**
	 * {@link GWebContext}インスタンスを初期化します。
	 * 
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	protected GWebContext() {
		super();
	}

	/**
	 * コンテキストを初期化します。<br>
	 * ライフサイクル開始時に呼び出されます。
	 * 
	 * @param request リクエスト
	 * @param response レスポンス
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public void init(final HttpServletRequest request, final HttpServletResponse response) {
		this.request = request;
		this.response = response;
		HttpSession httpSession = request.getSession();
		// NOTE: Servlet 3.0からはrequestからServletContextを取得することが可能だが、下位互換のため、HttpSessionから取得する
		this.servletContext = httpSession.getServletContext();
		
		// ロケールのセット
		Locale locale = GFrameworkUtils.getDefaultLocale();
		String lang = request.getHeader(ACCEPT_LANGUAGE);
		if (lang != null) {
			locale = request.getLocale();
		}
		setLocale(locale);

		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session = manager.getSession(httpSession);
		setSession(session);

	}

	/**
	 * コンテキスト情報を破棄します。
	 * 
	 * @see jp.co.kccs.greenearth.commons.GFrameworkContext#destroy()
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public void destroy() {
		super.destroy();
		request = (HttpServletRequest) null;
		response = (HttpServletResponse) null;
		servletContext = (ServletContext) null;
		session = (GSession) null;
	}

	/**
	 * Httpリクエストを取得します。
	 * 
	 * @return リクエスト
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public HttpServletRequest getRequest() {
		return request;
	}

	/**
	 * Httpレスポンスを取得します。
	 * 
	 * @return レスポンス
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public HttpServletResponse getResponse() {
		return response;
	}

	/**
	 * サーブレットコンテキストを取得します。
	 * 
	 * @return サーブレットコンテキスト
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public ServletContext getServletContext() {
		return servletContext;
	}

	/**
	 * Httpリクエストを設定します。
	 * 
	 * @param request リクエスト
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public void setRequest(final HttpServletRequest request) {
		this.request = request;
	}

	/**
	 * Httpレスポンスを設定します。
	 * 
	 * @param response レスポンス
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public void setResponse(final HttpServletResponse response) {
		this.response = response;
	}

	/**
	 * サーブレットコンテキストを設定します。
	 * 
	 * @param servletContext サーブレットコンテキスト
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public void setServletContext(final ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	/**
	 * セッションを取得します.
	 * 
	 * @create 2007/02/14
	 * @return セッション
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GSession getSession() {
		return session;
	}

	/**
	 * セッションを設定します.
	 * 
	 * @create 2007/02/06
	 * @param session セッション
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setSession(final GSession session) {
		this.session = session;
	}

}
