/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * アクションメソッドに対してインターセプターを利用した拡張を行うかを示すアノテーションです.<br>
 * アクションメソッドは{@link ActionInterceptor}アノテーションが指定されていた場合、
 * アノテーションにて指定された{@link GActionInterceptor}を利用して機能拡張が行われます。<br>
 * <br>
 * {@link ActionInterceptor}にはインターセプターと、そのインターセプターに引き渡すパラメータを
 * 指定することができます。<br>
 * インターセプターはvalue属性にて、パラメータはparams属性にて指定します。<br>
 * パラメータは文字列配列にて指定可能であり、複数指定することが可能です。<br>
 * <br>
 * アクションメソッドへのインターセプターの指定方法は以下のようになります。
 * <pre>
 * 　&#064;ActionInterceptor(SampleInterceptor1.class)
 * 　public GResultData doAction(GParameter parameter) {}
 * </pre>
 * 
 * @create 2007/01/02
 * @author kitamura
 * @since 3.0.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@MethodInterceptor(scanBy = GActionInterceptorScanner.class)
public @interface ActionInterceptor {

	/** インターセプター. */
	Class< ? extends GActionInterceptor> value();

	/** パラメータ. */
	String[] params() default {};
}