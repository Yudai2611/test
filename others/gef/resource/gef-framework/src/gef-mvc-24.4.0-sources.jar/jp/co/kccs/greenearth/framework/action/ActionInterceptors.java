/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * アクションメソッドに対して、インターセプターを複数個指定したい場合に利用する
 * アクションインターセプターしていようアノテーションです.<br>
 * 
 * {@link ActionInterceptor}アノテーションは、1つのアクションメソッドに対して、
 * 1つしかが指定することができません。しかし、1つのメソッドに複数のアクションインターセプターを
 * 適用したい場合があります。<br>
 * そこで、1つのメソッドに対して、複数個のインターセプターを定義する方法として、<br>
 * {@link ActionInterceptors}のvalue属性に{@link ActionInterceptor}アノテーションを配列で
 * 指定することで、それを実現しています。<br>
 * 配列でしていされたインターセプターはその順序にそってアクションメソッド実行時にコールバックされます.
 * <br>
 * アクションメソッドへのインターセプターの指定方法は以下のようになります。
 * <pre>
 * 　&#064;ActionInterceptors({
 * 　　　&#064;ActionInterceptor(SampleInterceptor1.class),
 * 　　　&#064;ActionInterceptor(value=TestInterceptor2.class,params={"paramA","paramB"}) 
 * 　})
 * 　public GResultData doAction(GParameter parameter) {}
 * </pre>
 * 
 * @create 2007/01/01
 * @author kitamura
 * @since 3.0.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@MethodInterceptor(scanBy = GActionInterceptorsScanner.class)
public @interface ActionInterceptors {

	/** インターセプターを指定するアノテーションの配列. */
	ActionInterceptor[] value() default {};
}