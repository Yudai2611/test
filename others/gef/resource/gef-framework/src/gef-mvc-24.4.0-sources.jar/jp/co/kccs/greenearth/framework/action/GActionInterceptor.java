/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

/**
 * アクションメソッドを拡張するインターセプターを定義します. <br><br>
 * 
 * 【アクションへのインターセプターの指定】<br>
 * {@link GActionInterceptor}はアクションメソッドに対し{@link ActionInterceptor}
 * アノテーションを利用して指定します。<br>
 * {@link ActionInterceptor}には、{@link ActionInterceptor#params()}プロパティにてインターセプターに渡すパラメータを
 * 指定することができます。パラメータはString配列で指定します。<br>
 * アクションメソッドへのインターセプターの指定方法は以下のようになります。
 * <pre>
 * 　&#064;ActionInterceptor(value=SampleInterceptor.class,params={"paramA","paramB"}) 
 * 　public GResultData doAction(GParameter parameter) {}
 * </pre>
 * 
 * 【アクションインターセプターの実装】<br>
 * インターセプターを実装する場合は、{@link GActionInterceptor#invoke(MethodInvocation)}メソッドを実装する必要があります。<br>
 * 実際にアクションメソッドの前後にログを出力するようなインターセプターの実装例は以下のようになります。<br>
 * <pre>
 * public Object invoke( MethodInvocation invocation ) throws Throwable
 * {
 * 　　String methodName = invocation.getMethod().getName();
 * 　　System.out.println( methodName + "アクションの開始" );
 * 　　Object result = invocation.proceed();
 * 　　System.out.println( methodName + "アクションの終了" );
 * 　　return result;
 * }
 * </pre>
 * 
 * @see org.aopalliance.intercept.MethodInterceptor
 * @create 2007/01/02
 * @author kitamura
 * @since 3.0.0
 */
public interface GActionInterceptor extends GMethodInterceptor<String> {

	/**
	 * {@link ActionInterceptor}アノテーションにて指定されたパラメータ配列を取得します.
	 * 
	 * @create 2007/01/02
	 * @return 文字列パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
    @Override
	String[] getParameters();

	/**
	 * パラメータ配列を設定します.
	 * 
	 * @create 2007/01/02
	 * @param parameters 文字列パラメータ配列
	 * @author kitamura
	 * @since 3.0.0
	 */
    @Override
	void setParameters(String[] parameters);
}
