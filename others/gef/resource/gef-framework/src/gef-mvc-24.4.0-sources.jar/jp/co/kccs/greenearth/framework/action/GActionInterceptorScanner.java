/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Annotation;
import java.util.LinkedList;
import java.util.List;

/**
 * {@link ActionInterceptor}アノテーションのインターセプタークラスをスキャンします.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GActionInterceptorScanner implements GMethodInterceptorScanner<String> {

	/**
	 * {@inheritDoc}
	 * 
	 * @see jp.co.kccs.greenearth.framework.action.GMethodInterceptorScanner#scan(java.lang.annotation.Annotation)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public List<? extends GMethodInterceptor<String>> scan(Annotation annotation) throws InstantiationException, IllegalAccessException {
		List<GMethodInterceptor<String>> interceptors = new LinkedList<>();
		ActionInterceptor actionInterceptor = ActionInterceptor.class.cast(annotation);
		GMethodInterceptor<String> interceptor = actionInterceptor.value().newInstance();
		String[] params = actionInterceptor.params();
		interceptor.setParameters(params);
		interceptors.add(interceptor);
		return interceptors;
	}
}