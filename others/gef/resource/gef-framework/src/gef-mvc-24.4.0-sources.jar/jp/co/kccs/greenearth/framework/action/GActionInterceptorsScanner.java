/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Annotation;
import java.util.LinkedList;
import java.util.List;

/**
 * {@link ActionInterceptors}アノテーションのインターセプタークラスをスキャンします.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GActionInterceptorsScanner implements GMethodInterceptorScanner<String> {

	/**
	 * {@inheritDoc}
	 * 
	 * @see jp.co.kccs.greenearth.framework.action.GMethodInterceptorScanner#scan(java.lang.annotation.Annotation)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public List<? extends GMethodInterceptor<String>> scan(Annotation annotation) throws InstantiationException, IllegalAccessException {
		List<GMethodInterceptor<String>> interceptors = new LinkedList<>();
		ActionInterceptors actionInterceptors = ActionInterceptors.class.cast(annotation);
		for (ActionInterceptor actionInterceptor : actionInterceptors.value()) {
			GMethodInterceptorScanner<String> scanner = GMethodInterceptorScannerProvider.get(actionInterceptor);
			List<? extends GMethodInterceptor<String>> result = scanner.scan(actionInterceptor);
			interceptors.addAll(result);
		}

		return interceptors;
	}
}