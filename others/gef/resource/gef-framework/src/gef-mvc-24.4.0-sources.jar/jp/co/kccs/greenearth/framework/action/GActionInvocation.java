/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import java.util.LinkedList;

import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * インターセプトされるアクションメソッドの詳細情報を表します. <br>
 * アクションメソッド専用の{@link MethodInvocation}です。<br>
 * {@link #proceed()}メソッドにより、セットされたインターセプターを順次実行します。
 * 
 * @see org.aopalliance.intercept.MethodInvocation
 * @create 2005/04/08
 * @author kitamura
 * @since 3.0.0
 */
public class GActionInvocation implements MethodInvocation {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GActionInvocation.class);

	/** ウィーブ対象メソッドに渡される引数. */
	private Object[] _arguments = null;
	/** ウィーブ対象メソッド. */
	private Method _method = null;
	/** インターセプターのリストを格納するキュー. */
	private LinkedList<GMethodInterceptor<String>> _queue = new LinkedList<>();
	/** ウィーブ対象オブジェクト. */
	private Object _target = null;

	/**
	 * ウィーブ対象となるオブジェクト、メソッド、メソッドに渡される引数、
	 * ウィーブするインターセプターの配列を指定して{@link GActionInvocation}クラスの新しいインスタンスを初期化します.
	 * 
	 * @create 2005/04/11
	 * @param target ウィーブ対象オブジェクト
	 * @param method ウィーブ対象メソッド
	 * @param arguments ウィーブ対象メソッドに渡される引数
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GActionInvocation(Object target, Method method, Object[] arguments) {
		_target = target;
		_method = method;
		_arguments = arguments;
	}

	/**
	 * ウィーブするインターセプターを追加します.
	 * 
	 * @create 2007/01/01
	 * @param interceptor インターセプター
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addInterceptor(GActionInterceptor interceptor) {
		_queue.addLast(interceptor);
	}

	/**
	 * ウィーブ対象メソッドに渡される引数を取得します.
	 * 
	 * @see org.aopalliance.intercept.Invocation#getArguments()
	 * @create 2005/04/11
	 * @return ウィーブ対象メソッドに渡される引数
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object[] getArguments() {
		return _arguments;
	}

	/**
	 * インターセプターキューを取得します.
	 * 
	 * @create 2007/01/02
	 * @return インターセプターキュー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public LinkedList<GMethodInterceptor<String>> getInterceptors() {
		return _queue;
	}

	/**
	 * ウィーブ対象メソッドを取得します.
	 * 
	 * @see org.aopalliance.intercept.MethodInvocation#getMethod()
	 * @create 2005/04/11
	 * @return ウィーブ対象メソッド
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Method getMethod() {
		return _method;
	}

	/**
	 * フック対象の{@link AccessibleObject}を取得します.
	 * 
	 * @see org.aopalliance.intercept.Joinpoint#getStaticPart()
	 * @create 2005/04/11
	 * @return フック対象の{@link AccessibleObject}
	 * @author kitamura
	 * @since 3.0.0
	 */
	public AccessibleObject getStaticPart() {
		return _method;
	}

	/**
	 * ウィーブ対象オブジェクトを取得します.
	 * 
	 * @see org.aopalliance.intercept.Joinpoint#getThis()
	 * @create 2005/04/11
	 * @return ウィーブ対象オブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object getThis() {
		return _target;
	}

	/**
	 * チェーンされている次のインターセプターの処理に進みます. <br>
	 * セットされている{@link GActionInterceptor}をリスト順に呼び出しています。
	 * 
	 * @see org.aopalliance.intercept.Joinpoint#proceed()
	 * @create 2005/04/11
	 * @return ウィーブ対象メソッドの処理結果
	 * @throws Throwable ウィーブ対象メソッドが例外を発生させた場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object proceed() throws Throwable {
		Object result = null;
		if (!isInterceptorEmpty()) {
			GActionInterceptor interceptor = getNextInterceptor();
			LOGGER.debug("Intercept Action : interceptor=" + interceptor.getClass().getName());
			result = interceptor.invoke(this);
		}
		else {
			result = getMethod().invoke(getThis(), getArguments());
		}
		return result;
	}

	/**
	 * インターセプターキューを設定します.
	 * 
	 * @create 2007/01/02
	 * @param interceptors インターセプターキュー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setInterceptors(LinkedList<GMethodInterceptor<String>> interceptors) {
		_queue = interceptors;
	}

	/**
	 * 次にウィーブ対象となっているメソッドインターセプターを取得します.
	 * 
	 * @create 2005/04/11
	 * @return 現在ウィーブ対象となっているメソッドインターセプター
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GActionInterceptor getNextInterceptor() {
		return (GActionInterceptor) _queue.removeFirst();
	}

	/**
	 * ウィーブするインターセプターのリストが空であるかを示す値を取得します.
	 * 
	 * @create 2005/04/11
	 * @return ウィーブするインターセプターのリストが空であるかを示す値 : 空ならtrue
	 * @author kitamura
	 * @since 3.0.0
	 */
	private boolean isInterceptorEmpty() {
		return _queue.isEmpty();
	}
}
