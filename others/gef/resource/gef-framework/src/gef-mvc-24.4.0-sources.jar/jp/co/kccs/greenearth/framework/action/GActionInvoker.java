/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;

/**
 * アクションを生成し、アクションメソッドを呼び出します.<br>
 * 
 * ◆アクションクラスの実装<br>
 * 　アクションでは、その中に実装された任意のメソッド（アクションメソッド）が呼び出されることになります。<br>
 * アクションクラスは、特に決まったクラスやインターフェースを実装する必要はありませんが、
 * 実行させるアクションメソッドは以下のようなシグニチャである必要があります。
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr><td bgcolor="#CCCCFF">メソッド名</td><td colspan="2">pubulic {@link GResultData} XXXX({@link GParameter} parameter,{@link GResultData} data)</td></tr>
 * <tr><td bgcolor="#CCCCFF" rowspan="2">引数</td><td>parameter</td><td>パラメータオブジェクト</td></tr>
 * <tr><td>data</td><td>事前アクションの実行結果</td></tr>
 * <tr><td bgcolor="#CCCCFF">戻り値</td><td colspan="2">処理結果が積まれた結果セットオブジェクト</td></tr>
 * </table>
 * <br>
 * 
 * <b>【アクションインターセプター】</b><br>
 * 　インターセプターとは、AOPの一種で、特定のビジネス処理にかかわらず、共通の 機能を横断的に適用したいときに有効な仕組みです。<br>
 * Core Frameworkではアクションメソッド専用のインターセプターを用意しています。<br>
 * Core Frameworkでは、デフォルトでDBコネクションの確立を自動化する{@link GConnectionInterceptor}や
 * トランザクション処理を自動化する{@link GTransactionInterceptor}などが用意されています。
 * これらアクションインターセプターを利用し、複数のアクションで共通する前後処理を追加します。<br>
 * アクションインターセプターの指定方法は、{@link GActionInterceptor}クラスの説明を参照してください。<br>
 * <br>
 * 
 * @create 2007/04/07
 * @author kitamura
 * @since 3.0.0
 */
public abstract class GActionInvoker {

	/**
	 * {@link GActionInvoker}インスタンスを生成します.
	 * 
	 * @create 2007/04/09
	 * @return {@link GActionInvoker}インスタンス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GActionInvoker getInstance() {
		return (GActionInvoker) GFrameworkUtils.getComponent(GActionInvoker.class.getName());
	}

	/**
	 * アクションインスタンスを生成します.
	 * 
	 * @param actionName アクションクラス名
	 * @return アクションインスタンス
	 */
	public abstract Object createAction(String actionName);

	/**
	 * インスタンス指定でアクションを実行します.<br><br>
	 * 
	 * <b>【アクションメソッドのシグニチャ】</b><br>
	 * 以下のシグニチャに準拠している必要があります。<br>
	 * <li>public {@link GResultData} XXXX({@link GParameter},{@link GResultData});<br>
	 * 
	 * <b>【インターセプターの指定(AOP:Aspect Oriented Programming)】</b><br>
	 * アクションクラスにはインターセプターを指定することによりAOP的な機能拡張が可能です。<br>
	 * アクションメソッドに{@link ActionInterceptors}アノテーションを指定し、
	 * その属性に拡張に利用するインターセプターを指定します。<br><br>
	 * 
	 * <b>【検証エラーの処理】</b><br>
	 * アクションメソッドより、検証エラー({@link GValidateException})がスローされた場合は
	 * その内容をキャッチし、{@link GResultData}に詰め直してリターンします。<br>
	 * このため、{@link GValidateException}がスローされることはありません。<br>
	 * 
	 * @create 2007/04/09
	 * @param action アクションインスタンス
	 * @param methodName アクションメソッド名
	 * @param parameter パラメータ
	 * @param data 事前アクション実行結果
	 * @return アクションの実行結果
	 * @throws Throwable アクション内部で例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract GResultData invoke(Object action, String methodName, GParameter parameter, GResultData data) throws Throwable;

	/**
	 * クラス名指定でアクションを実行します.
	 * 
	 * <b>【アクションメソッドのシグニチャ】</b><br>
	 * 以下のシグニチャに準拠している必要があります。<br>
	 * <li>public {@link GResultData} XXXX({@link GParameter},{@link GResultData});<br>
	 * 
	 * <b>【インターセプターの指定(AOP:Aspect Oriented Programming)】</b><br>
	 * アクションクラスにはインターセプターを指定することによりAOP的な機能拡張が可能です。<br>
	 * アクションメソッドに{@link ActionInterceptors}アノテーションを指定し、
	 * その属性に拡張に利用するインターセプターを指定します。<br><br>
	 * 
	 * <b>【検証エラーの処理】</b><br>
	 * アクションメソッドより、検証エラー({@link GValidateException})がスローされた場合は
	 * その内容をキャッチし、{@link GResultData}に詰め直してリターンします。<br>
	 * このため、{@link GValidateException}がスローされることはありません。<br>
	 * 
	 * @create 2007/04/09
	 * @param className アクションクラス名
	 * @param methodName アクションメソッド名
	 * @param parameter パラメータ
	 * @param data 事前アクション実行結果
	 * @return アクションの実行結果
	 * @throws Throwable アクション内部で例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public abstract GResultData invoke(String className, String methodName, GParameter parameter, GResultData data) throws Throwable;
}
