/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * {@link GActionInvoker}を実装するための基底クラスです。
 * 
 * @author KCCS kitamura
 * @since 3.12.0
 */
public abstract class GActionInvokerBase extends GActionInvoker {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GActionInvoker.class);

	/**
	 * {@link GActionInvokerBase}インスタンスを初期化します.
	 * 
	 * @create 2013/03/31
	 * @author KCCS kitamura
	 * @since 3.12.0
	 */
	public GActionInvokerBase() {
	}
	
	@Override
	public abstract Object createAction(String actionName);

	/**
	 * インスタンス指定でアクションを実行します.
	 * 
	 * @create 2007/04/09
	 * @param action アクションオブジェクト
	 * @param methodName アクションメソッド名
	 * @param parameter パラメータ
	 * @param data 事前アクション実行結果
	 * @return アクションの実行結果
	 * @throws Throwable アクション内部で例外が発生した場合
	 * @author KCCS kitamura
	 * @since 3.12.0
	 */
	@Override
	public GResultData invoke(Object action, String methodName, GParameter parameter, GResultData data) throws Throwable {
		// メソッドの生成
		Class< ? > clazz = action.getClass();
		Class< ? >[] parameterTypes = new Class[2];
		parameterTypes[0] = GParameter.class;
		parameterTypes[1] = GResultData.class;
		Method method = clazz.getMethod(methodName, parameterTypes);

		// 開始ログ
		String className = action.getClass().getName();
		LOGGER.info("Action Start : action=" + className + "#" + method.getName());
		GStopWatch watch = new GStopWatch();
		watch.start();

		// 実行
		GResultData resultData = null;
		try {
			Object[] parameters = new Object[2];
			parameters[0] = parameter;
			parameters[1] = data;
			resultData = (GResultData) method.invoke(action, parameters);
		} catch (InvocationTargetException e) {
			throw e.getTargetException();
		}

		// 終了ログ
		LOGGER.info("Action End (" + watch.stop() + ") : exitcode=" + resultData.getExitCode());

		return resultData;
	}

	/**
	 * クラス名指定でアクションを実行します.
	 * 
	 * @create 2007/04/09
	 * @param className アクションクラス名
	 * @param methodName アクションメソッド名
	 * @param parameter パラメータ
	 * @param data 事前アクション実行結果
	 * @return アクションの実行結果
	 * @throws Throwable アクション内部で例外が発生した場合
	 * @author KCCS kitamura
	 * @since 3.12.0
	 */
	@Override
	public GResultData invoke(String className, String methodName, GParameter parameter, GResultData data) throws Throwable {
		// クラスの生成
		Object instance = createAction(className);
		return invoke(instance, methodName, parameter, data);
	}
}
