/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.reflect.Method;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GCoreException;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;

/**
 * {@link GActionInvoker}のデフォルト実装です.
 * CGLIBを利用してアクションインターセプターを実現しています.
 * 
 * @see jp.co.kccs.greenearth.framework.action.GActionInvoker
 * @create 2007/03/31
 * @author kitamura
 * @since 3.0.0
 */
public class GActionInvokerImpl extends GActionInvokerBase {

	/**
	 * {@link GActionInvokerImpl}インスタンスを初期化します.
	 * 
	 * @create 2007/03/31
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GActionInvokerImpl() {
	}

	/**
	 * 指定されたクラス名からリフレクションにてアクションクラスを生成します。
	 * 
	 * @param actionName アクションクラス名
	 * @author KCCS kitamura
	 * @since 3.12.0
	 */
	@Override
	public Object createAction(String actionName) {
		try {
			Class< ? > clazz = Class.forName(actionName);
			return clazz.newInstance();
		} catch (InstantiationException e) {
			throw new GCoreException("create action instance is failed.", e);
		} catch (ClassNotFoundException e) {
			throw new GCoreException("create action instance is failed.", e);
		} catch (IllegalAccessException e) {
			throw new GCoreException("create action instance is failed.", e);
		}
	}

	/**
	 * インスタンス指定でアクションを実行します.
	 * 
	 * @create 2007/04/09
	 * @param action アクションオブジェクト
	 * @param methodName アクションメソッド名
	 * @param parameter パラメータ
	 * @param data 事前アクション実行結果
	 * @return アクションの実行結果
	 * @throws Throwable アクション内部で例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public GResultData invoke(Object action, String methodName, GParameter parameter, GResultData data) throws Throwable {
		// アクションインターセプターのセット
		Object instance = wrappedByActionProxy(action, methodName);
		return super.invoke(instance, methodName, parameter, data);
	}

	/**
	 * 指定されたアクションオブジェクトに対してAOP用プロキシをセットします.<br>
	 * CGLIBを利用した、既に生成されたオブジェクトに対するAOPの設定を行っています。
	 * 
	 * @create 2007/01/01
	 * @param action アクションオブジェクト
	 * @param methodName アクションメソッド名
	 * @return プロキシがセットされたアクションオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected Object wrappedByActionProxy(Object action, String methodName) {
		Method method = null;
		try {
			method = action.getClass().getMethod(methodName, GParameter.class, GResultData.class);
		} catch (NoSuchMethodException e) {
			throw new GFrameworkException(e);
		}
		return wrappedByActionProxy(action, method);
	}

	protected Object wrappedByActionProxy(Object action, Method method) {
		return new GActionProxy(action, method).createProxy();
	}
}
