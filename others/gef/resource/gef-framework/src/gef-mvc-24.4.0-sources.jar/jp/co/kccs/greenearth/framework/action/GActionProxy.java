package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.stream.Stream;

import org.springframework.aop.framework.ProxyFactory;

import jp.co.kccs.greenearth.commons.GFrameworkException;

public class GActionProxy {
	/** ウィーブするターゲットオブジェクト. */
	private ProxyFactory proxyFactory = null;

	/**
	 * ターゲットを指定して{@link GActionProxy}クラスの新しいインスタンスを初期化します.
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public GActionProxy(Object targetObject, Method method) {
		proxyFactory = new ProxyFactory(targetObject);
		proxyFactory.setProxyTargetClass(true);
		try {
			LinkedList<GMethodInterceptor<String>> interceptors = getInterceptorList(method);
			for (GMethodInterceptor<String> interceptor : interceptors) {
				if (!interceptors.isEmpty()) {
					proxyFactory.addAdvice(interceptor);
				}
			}
		} catch (InstantiationException | IllegalAccessException e) {
			throw new GFrameworkException(e);
		}
	}


	/**
	 * 指定されたメソッドに関連付けられたメソッドインターセプターのリストを取得します.
	 *
	 * @create 2023/10/25
	 * @param method メソッド
	 * @return メソッドインターセプター
	 * @throws InstantiationException インターセプタークラスの生成に失敗した場合
	 * @throws IllegalAccessException インターセプタークラスへのアクセス権限がない場合
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	protected LinkedList<GMethodInterceptor<String>> getInterceptorList(Method method) throws InstantiationException, IllegalAccessException {
		LinkedList<GMethodInterceptor<String>> interceptors = new LinkedList<>();
		Annotation[] annotations = method.getAnnotations();

		for (Annotation annotation : annotations) {
			MethodInterceptor actionProxy = annotation.annotationType().getDeclaredAnnotation(MethodInterceptor.class);
			if(actionProxy == null) {
				continue;
			}

			if(!actionProxy.interceptBy().isInterface()) {
				GMethodInterceptor<String> interceptor = actionProxy.interceptBy().newInstance();
				interceptor.setParameters(extractParams(annotation));
				interceptors.add(interceptor);
			}

			if(!actionProxy.scanBy().isInterface()) {
				GMethodInterceptorScanner<String> scanner = GMethodInterceptorScannerProvider.get(annotation);
				interceptors.addAll(scanner.scan(annotation));
			}
		}

		return interceptors;
	}

	private String[] extractParams(Annotation annotation) {
		if(Stream.of(annotation.annotationType().getDeclaredMethods()).anyMatch(method -> "params".equals(method.getName()))) {
			try {
				return (String[]) annotation.annotationType().getDeclaredMethod("params").invoke(annotation);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e) {
				throw new RuntimeException();
			}
		}
		return null;
	}

	public Object createProxy() {
		return proxyFactory.getProxy();
	}
}