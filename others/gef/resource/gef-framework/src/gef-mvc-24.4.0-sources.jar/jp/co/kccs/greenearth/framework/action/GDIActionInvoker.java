/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * DIコンテナ経由で生成したアクションを利用して処理を実行する{@link GActionInvoker}実装クラスです。
 * 
 * @author KCCS kitamura
 * @since 2013/07/01
 */
public class GDIActionInvoker extends GActionInvokerBase {

	/**
	 * {@link GDIActionInvoker}インスタンスを初期化します。
	 * 
	 * @author KCCS kitamura
	 * @since 2013/07/01
	 */
	public GDIActionInvoker() {
	}

	/**
	 * 指定されたコンポーネントIDより、DIコンテナからアクションインスタンスを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.action.GActionInvokerBase#createAction(java.lang.String)
	 * @param componentName コンポーネントID
	 * @return アクションインスタンス
	 * @author KCCS kitamura
	 * @since 2013/07/01
	 */
	@Override
	public Object createAction(String componentID) {
		return GFrameworkUtils.getComponent(componentID);
	}
}
