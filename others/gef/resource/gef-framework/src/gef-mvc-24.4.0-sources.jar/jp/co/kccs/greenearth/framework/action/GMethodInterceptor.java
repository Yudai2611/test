/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import org.aopalliance.intercept.MethodInterceptor;

public interface GMethodInterceptor<T> extends MethodInterceptor {

	T[] getParameters();

	void setParameters(T[] parameters);
}
