/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Annotation;
import java.util.List;

/**
 * {@link GMethodInterceptor}をスキャンします.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public interface GMethodInterceptorScanner<T> {

	/**
	 * 指定したアノテーションで{@link GMethodInterceptor}をスキャンします.<br/>
	 * 
	 * @create 2023/10/25
	 * @param annotation アノテーション
	 * @return スキャン結果
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public List<? extends GMethodInterceptor<T>> scan(Annotation annotation) throws InstantiationException, IllegalAccessException;
}
