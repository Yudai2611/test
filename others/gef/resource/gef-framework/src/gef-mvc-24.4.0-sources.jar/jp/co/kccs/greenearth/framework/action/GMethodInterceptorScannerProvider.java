/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Annotation;

/**
 * 
 * 
 * @create 2023/10/25
 * @author KCCS okanshi
 * @since 23.10.0
 */
public interface GMethodInterceptorScannerProvider {

	@SuppressWarnings({ "unchecked", "deprecation" })
	public static <T> GMethodInterceptorScanner<T> get(Annotation annotation) throws InstantiationException, IllegalAccessException {
		MethodInterceptor actionProxy = annotation.annotationType().getDeclaredAnnotation(MethodInterceptor.class);
		return actionProxy.scanBy().newInstance();
	}
}