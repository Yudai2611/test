/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

/**
 * ワンタイムトークン照合処理にて発生した例外を表します。
 * 
 * @create 2009/11/20
 * @author okajima
 * @since 3.6.0
 */
public class GOneTimeTokenException extends Exception {

	/** シリアルバージョンUID. */
	private static final long serialVersionUID = -5458045704464922682L;
	
	/**
	 * {@link GOneTimeTokenException}インスタンスを初期化します.
	 * 
	 * @create 2009/11/20
	 * @auther okajima
	 * @since 3.6.0
	 */
	public GOneTimeTokenException() {
		super();
	}
	
	/**
	 * {@link GOneTimeTokenException}インスタンスを初期化します.
	 * 
	 * @create 2009/11/20
	 * @param message メッセージ
	 * @auther okajima
	 * @since 3.6.0
	 */
	public GOneTimeTokenException(String message) {
		super(message);
	}
}