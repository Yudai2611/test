/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.action;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.ANNOTATION_TYPE)
public @interface MethodInterceptor {

	/** インターセプター. */
	@SuppressWarnings("rawtypes")
    Class<? extends GMethodInterceptor> interceptBy() default GMethodInterceptor.class;
	
	/** プロキシスキャナー. */
	@SuppressWarnings("rawtypes")
    Class<? extends GMethodInterceptorScanner> scanBy() default GMethodInterceptorScanner.class;
}
