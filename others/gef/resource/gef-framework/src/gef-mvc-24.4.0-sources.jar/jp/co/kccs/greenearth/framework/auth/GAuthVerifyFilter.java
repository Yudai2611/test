/*
 * Copyright 2009-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * クライアントからのリクエストが認証済みであるかを検証するフィルターです。<br>
 * 内部で
 * {@link GAuthentication#loginCheck(HttpServletRequest, HttpServletResponse, GSession)}
 * を呼び出しています。<br>
 * <br>
 * 【web.xmlの設定例】<br>
 * 
 * <pre>
 * &lt;filter&gt;
 * 　　　　&lt;filter-name&gt;AuthVerifyFilter&lt;/filter-name&gt;
 * 　　　　&lt;filter-class&gt;jp.co.kccs.greenearth.framework.view.auth.GAuthValidateFilter&lt;/filter-class&gt;
 * 　　　　&lt;init-param&gt;
 * 　　　　　　　　&lt;param-name&gt;exclude-url/login.action&lt;/param-name&gt;
 * 　　　　　　　　&lt;param-value&gt;/login.view-action&lt;/param-value&gt;
 * 　　　　&lt;/init-param&gt;
 * 　　　　&lt;init-param&gt;
 * 　　　　　　　　&lt;param-name&gt;exclude-url/login.xrmi-action&lt;/param-name&gt;
 * 　　　　　　　　&lt;param-value&gt;/Login.xrmi-action&lt;/param-value&gt;
 * 　　　　&lt;/init-param&gt;
 * &lt;/filter&gt;
 * &lt;filter-mapping&gt;
 * 　　　　&lt;filter-name&gt;AuthVerifyFilter&lt;/filter-name&gt;
 * 　　　　&lt;url-pattern&gt;*.view-action&lt;/url-pattern&gt;
 * 　　　　&lt;dispatcher&gt;REQUEST&lt;/dispatcher&gt;
 * &lt;/filter-mapping&gt;
 * &lt;filter-mapping&gt;
 * 　　　　&lt;filter-name&gt;AuthVerifyFilter&lt;/filter-name&gt;
 * 　　　　&lt;url-pattern&gt;*.jsp&lt;/url-pattern&gt;
 * 　　　　&lt;dispatcher&gt;REQUEST&lt;/dispatcher&gt;
 * &lt;/filter-mapping&gt;
 * &lt;filter-mapping&gt;
 * 　　　　&lt;filter-name&gt;AuthVerifyFilter&lt;/filter-name&gt;
 * 　　　　&lt;url-pattern&gt;*.xrmi-action&lt;/url-pattern&gt;
 * 　　　　&lt;dispatcher&gt;REQUEST&lt;/dispatcher&gt;
 * &lt;/filter-mapping&gt;
 * 
 * </pre>
 * 
 * 
 * @create 2009/07/23
 * @author kitamura
 * @since 3.6.0
 */
public class GAuthVerifyFilter extends GExcludableFilter {

	/**
	 * {@link GAuthVerifyFilter}インスタンスを初期化します。
	 * 
	 * @create 2009/07/23
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GAuthVerifyFilter() {
	}

	/**
	 * {@link GAuthentication}インスタンスを取得します。
	 * 
	 * @create 2009/07/23
	 * @return {@link GAuthentication}インスタンス
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected GAuthentication getAuthentication() {
		return (GAuthentication) GFrameworkUtils.getComponent(GAuthentication.class.getName());
	}

	/**
	 * 認証済みかどうかの検証処理を行います。<br>
	 * 
	 * @create 2009/07/23
	 * @see GExcludableFilter#doFilter(jakarta.servlet.http.HttpServletRequest,
	 *      jakarta.servlet.http.HttpServletResponse, jakarta.servlet.FilterChain)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain フィルターチェーン
	 * @throws IOException 未認証時のエラーページ遷移に失敗した場合
	 * @throws ServletException 未認証時のエラーページ遷移に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
		throws IOException, ServletException {
		try {
			GSession session = GSessionManagerFactory.getSessionManager().getSession(request.getSession());
			GAuthentication auth = getAuthentication();
			auth.loginCheck(request, response, session);
		} catch (GAuthenticationException e) {
			throw new ServletException(e);
		}

		// Pass control on to the next filter
		chain.doFilter(request, response);
	}
}
