/*
 * Copyright 2007-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.framework.session.GSession;

/**
 * 認証ロジック、または外部認証を利用する場合アダプター機能を提供します.
 * 
 * @create 2007/03/14
 * @author kitamura
 * @since 3.0.0
 */
public interface GAuthentication {

	/**
	 * ログインロジックを実行します.
	 * 
	 * @create 2007/03/18
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param session セッション
	 * @return ログインユーザセッション
	 * @throws GAuthenticationException ログインできない場合、またはログインに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	GSession login(HttpServletRequest request, HttpServletResponse response, GSession session)
		throws GAuthenticationException;

	/**
	 * ログインチェックロジックを実行します.
	 * 
	 * @create 2007/03/18
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param session セッション
	 * @return ログインユーザセッション
	 * @throws GAuthenticationException ログインしていない場合、またはログインチェックに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	GSession loginCheck(HttpServletRequest request, HttpServletResponse response, GSession session)
		throws GAuthenticationException;

	/**
	 * ログアウトロジックを実行します.
	 * 
	 * @create 2007/03/18
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param session セッション
	 * @throws GAuthenticationException ログアウトに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	void logout(HttpServletRequest request, HttpServletResponse response, GSession session)
		throws GAuthenticationException;
}
