/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.auth;

import java.util.Locale;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * GreenEARTH Frameworkのデフォルト認証ロジックを提供します.<br>
 * 指定したユーザIDに該当するユーザをマスタより引き当て、入力されたパスワードがマスタの内容と一致すれば認証します。<br>
 * <br>
 * <b>【入力パラメータ】</b>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF">
 * <td>パラメータキー名</td>
 * <td>パラメータが示す意味</td>
 * </tr>
 * <tr>
 * <td>companycd</td>
 * <td>会社コード</td>
 * </tr>
 * <tr>
 * <td>userid</td>
 * <td>ユーザID</td>
 * </tr>
 * <tr>
 * <td>userid</td>
 * <td>パスワード</td>
 * </tr>
 * <tr>
 * <td>locale</td>
 * <td>ロケール（例:ja_JP）</td>
 * </tr>
 * </table>
 * ※ロケールが指定されたなかった場合、リクエストヘッダの「Accept-Language」からロケールを特定します。
 * 
 * @create 2007/03/14
 * @author kitamura
 * @since 3.0.0
 */
public class GAuthenticationImpl implements GAuthentication {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GAuthentication.class);

	/**
	 * {@link GAuthenticationImpl}インスタンスを初期化します。
	 * 
	 * @create 2009/07/23
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GAuthenticationImpl() {
	}

	/**
	 * ログインロジックを実行します.<br>
	 * <br>
	 * 
	 * <b>【ログインロジック】</b><br>
	 * １．指定された会社コード、ユーザIDを元にユーザマスタよりユーザ情報を検索<br>
	 * ２．ユーザ情報のパスワードと、入力されたパスワードをマッチング<br>
	 * ３．該当するユーザ情報が存在し、正しいパスワードが入力されている場合、認証OK<br>
	 * ３．入力値に該当するユーザ情報がない、またはパスワードが間違っている場合はエラー<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GAuthentication#login(jakarta.servlet.http.HttpServletRequest,
	 *      jakarta.servlet.http.HttpServletResponse,
	 *      jp.co.kccs.greenearth.framework.session.GSession)
	 * @create 2007/03/14
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param session セッション
	 * @return ログインユーザセッション
	 * @throws GAuthenticationException 該当するユーザ情報が存在しない場合、またはパスワードが間違っている場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GSession login(HttpServletRequest request, HttpServletResponse response, GSession session)
		throws GAuthenticationException {
		// 入力パラメータ
		String companyCD = request.getParameter("companycd");
		if (companyCD == null) {
			throw new IllegalArgumentException("'companycd' parameter is not Found!");
		}
		String userID = request.getParameter("userid");
		if (userID == null) {
			throw new IllegalArgumentException("'userid' parameter is not Found!");
		}
		String password = request.getParameter("password");
		if (password == null) {
			throw new IllegalArgumentException("'password' parameter is not Found!");
		}

		HttpSession httpSession = request.getSession();

		GUserDao dao = getUserDao();
		GUser user = null;
		try {
			user = dao.findUser(companyCD, userID);
		} catch (GResourceProcessingException e) {
			GErrorMessage messages =
				GErrorMessages.getErrorMessage("GEF-000000", GFrameworkContext.getInstance().getLocale());
			throw new GAuthenticationException(messages, e);
		}

		// 認証
		if (user != null && password.equals(user.getPassword())) {
			if (user.isInvalid()) {
				// 認証NG(停止)
				LOGGER.info("Authentication Error!!!");
				GErrorMessage messages =
					GErrorMessages.getErrorMessage("GEF-001002", GFrameworkContext.getInstance().getLocale());
				throw new GAuthenticationException(messages);
			}

			// 認証OK
			// セッションの再構築
			httpSession.invalidate();
			httpSession = request.getSession(true);
			GSession newSession = GSessionManagerFactory.getSessionManager().getSession(httpSession);

			// パスワードを削除
			user.setPassword(null);
			newSession.setLoginUser(user);

			// ロケールの設定
			String lang = request.getParameter("locale");
			if (lang != null) {
				Locale locale = GLocaleUtils.getLocale(lang);
				user.setLocale(locale);
				GFrameworkContext.getInstance().setLocale(user.getLocale());
			}

			LOGGER.info("Authentication Success : id=" + userID);
			return newSession;
		} else {
			// 認証NG
			LOGGER.info("Authentication Error!!!");
			GErrorMessage messages =
				GErrorMessages.getErrorMessage("GEF-001000", GFrameworkContext.getInstance().getLocale());
			throw new GAuthenticationException(messages);
		}
	}

	/**
	 * ログインチェック処理を実行します.<br>
	 * <br>
	 * 
	 * <b>【ログインチェックロジック】</b><br>
	 * セッションにログインユーザ情報が詰まっていればOK。<br>
	 * 詰まっていなければ不正アクセスとしNG<br>
	 * 認証済みであれば、ユーザーに紐付けられたロケールを{@link GFrameworkContext}にセットします。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GAuthentication#loginCheck(jakarta.servlet.http.HttpServletRequest,
	 *      jakarta.servlet.http.HttpServletResponse,
	 *      jp.co.kccs.greenearth.framework.session.GSession)
	 * @create 2007/03/14
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param session セッション
	 * @return ログインユーザセッション
	 * @throws GAuthenticationException 不正アクセスの場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GSession loginCheck(HttpServletRequest request, HttpServletResponse response, GSession session)
		throws GAuthenticationException {
		if (session.isInvalid() || session.getLoginUser() == null) {
			// 不正なアクセス or タイムアウト
			LOGGER.info("Authentication Check Error!!!");
			GErrorMessage messages =
				GErrorMessages.getErrorMessage("GEF-001001", GFrameworkContext.getInstance().getLocale());
			throw new GAuthenticationException(messages);
		}
		GUser user = session.getLoginUser();
		if (user.getLocale() != null) {
			GFrameworkContext.getInstance().setLocale(user.getLocale());
		}
		return session;
	}

	/**
	 * ログアウト処理を実行します.<br>
	 * <br>
	 * 
	 * <b>【ログアウトロジック】</b><br> {@link HttpSession}、{@link GSession}
	 * 共に無効化し、セッションプールより解放します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.auth.GAuthentication#logout(jakarta.servlet.http.HttpServletRequest,
	 *      jakarta.servlet.http.HttpServletResponse,
	 *      jp.co.kccs.greenearth.framework.session.GSession)
	 * @create 2007/03/14
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param session セッション
	 * @throws GAuthenticationException ログアウト処理に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void logout(HttpServletRequest request, HttpServletResponse response, GSession session)
		throws GAuthenticationException {
		HttpSession httpSession = request.getSession();
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		// セッションの無効化
//		manager.closeSession(session);
		manager.closeSession(session, httpSession);
		httpSession.invalidate();
	}

	/**
	 * ユーザ情報を参照する為のDaoクラスを取得します.
	 * 
	 * @create 2007/04/27
	 * @return {@link GUserDao}
	 * @author aono
	 * @since 3.0.0
	 */
	protected GUserDao getUserDao() {
		return GFrameworkUtils.getComponent(GUserDao.class.getName());
	}
}
