/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * アクションメソッドに対して実行権限を与えるかを示すアノテーションです.<br>
 * アクションメソッドに{@link AuthorityRole}アノテーションが指定されていた場合、
 * アノテーションで指定されたロールがそのアクションメソッドに適用されます。<br>
 * 使用される場合、{@link GActionAuthorizationFilter}の設定が必要ので、ご注意ください。<br>
 * 
 * アクションメソッドにロールを指定する方法は以下のようになります。
 * <pre>
 * 　&#064;AuthorityRole("roleID")
 * 　public GResultData doAction(GParameter parameter) {}
 * </pre>
 * 
 * また、{@link GURIAuthorizationFilter}を利用しURIを制御することによって、
 * 同じ効果が得られます。詳細は{@link GURIAuthorizationFilter}をご参照ください。<br><br>
 * 
 * @create 2007/01/02
 * @author KCCS kyo
 * @since 3.9.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface AuthorityRole {

	/**
	 * ロールIDを取得します
	 * 
	 * @return　ロールID
	 * @create 2011/07/30
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	String value();
}
