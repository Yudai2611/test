/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * 特定のアクションのアクセス権限を確認するフィルタです. <br>
 * 各アクションにアノテーションの形でロールを付与することが出来ます.<br><br>
 * 
 * @create 2011/07/18
 * @author KCCS kyo
 * @since v3.9.0
 */
public class GActionAuthorizationFilter extends GExcludableFilter {
	
	/** ロールが設定されていない場合、権限ある/ないと判断するフラグ */
	// true: ロール設定がない場合、権限あり
	// false: ロール設定が無い場合、権限なし
	protected boolean _accessAuthorityWithoutSet = false;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);
		
		//アクションにアクセス権限の設定が無い場合、accessAuthorityWithoutSetの値をデフォルトのアクセス権限にする
	    String value = filterConfig.getInitParameter("accessAuthorityWithoutSet");
	    
		if (value == null) {
			return;
		}
	  
		_accessAuthorityWithoutSet = (value.equalsIgnoreCase("true")) ? true : false;
		
	}
	
	@Override
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
		throws IOException, ServletException {

		if (!checkAuthority(request, response)) {
			throw createAuthorizationException();
		}

		chain.doFilter(request, response);
	}

	/**
	 * アクションメソッドに紐付くロールの有効性をチェック.
	 * 
	 * @param request
	 * @param response
	 * @return true:権限あり / false:権限なし
	 * @throws ServletException
	 * @create 2011/07/18
	 * @author KCCS kyo
	 * @since
	 */
	protected boolean checkAuthority(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		
		GSessionManager sessionManager = GSessionManagerFactory.getSessionManager();
		GSession gsession = sessionManager.getSession(request.getSession());
		GUser user = gsession.getLoginUser();
		if (user == null) {
			return false;
		}
		
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
		String roleID = getRoleID(parameter);

		return checkAuthority(roleID, user);
	} 

	/**
	 * アクションメソッドと紐付けたロール名を取得.
	 * 
	 * @param className
	 * @return String
	 * @create 2010/10/24
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	protected String getRoleID(GParameter parameter) throws ServletException {
		String roleID = null;
		try {
			String className = getActionClassName(parameter);
			
			String classMethod = parameter.getValue(GActionServlet.ACTION_METHOD_KEY);
			if (classMethod == null) {
				throw new IllegalArgumentException("'" + GActionServlet.ACTION_METHOD_KEY + "' is not found!");
			}
			
			Class< ? > clazz = Class.forName(className);
			Object target = clazz.newInstance();
			Method method = target.getClass().getMethod(classMethod, GParameter.class, GResultData.class);
			Annotation[] annotations = method.getAnnotations();
			for (Annotation annotation : annotations) {
				if (annotation instanceof AuthorityRole) {
					roleID = ((AuthorityRole) annotation).value();
				}
			}
		} catch (SecurityException e) {
			throw new ServletException(e);
		} catch (NoSuchMethodException e) {
			throw new ServletException(e);
		} catch (InstantiationException e) {
			throw new ServletException(e);
		} catch (IllegalAccessException e) {
			throw new ServletException(e);
		} catch (ClassNotFoundException e) {
			throw new ServletException(e);
		}

		return roleID;
	}
	
	protected String getActionClassName(GParameter parameter) {
		String className = parameter.getValue(GActionServlet.ACTION_BEAN_KEY);
		if (className == null) {
			throw new IllegalArgumentException("'" + GActionServlet.ACTION_BEAN_KEY + "' is not found!");
		}
		return className;
	}

	protected boolean checkAuthority(String roleID, GUser user) throws ServletException {
		if (user == null) {
			return false;
		}
		if (roleID == null) {
			return _accessAuthorityWithoutSet;
		}
		
		GRoleFinder finder = GRoleFinder.Factory.getInstance();
		GCompany company = user.getCompany();
		GRole role = finder.getRole(company.getCode(), roleID);
		if (role == null) {
			return false;
		}
		return role.hasAuthority(user);
	}
	
	protected GAuthorizationException createAuthorizationException(){
		GErrorMessage message = GErrorMessages.getErrorMessage("GEF-001004", GFrameworkContext.getInstance().getLocale());
		return new GAuthorizationException(message);
		
	}
}
