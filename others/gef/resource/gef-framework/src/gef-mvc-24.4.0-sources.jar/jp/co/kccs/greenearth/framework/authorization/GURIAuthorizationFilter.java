/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.authorization;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.MissingResourceException;
import java.util.Properties;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * 特定のURIのアクセス権限を確認するフィルタです. <br>
 * 設定ファイルにURIにロールを付与することが出来ます.<br>
 * <br>
 * 
 * @create 2011/07/18
 * @author KCCS kyo
 * @since v3.9.0
 */
public class GURIAuthorizationFilter extends GExcludableFilter {

	/** プロパティファイル名. **/
	protected static final String PROPERTIES_FILE_NAME = "ge-authority-uri-map";

	protected Properties _properties = null;

	protected boolean _accessAuthorityWithoutSet = false;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);

		loadProperties();

		// URIにアクセス権限の設定が無い場合、accessAuthorityWithoutSetの値をデフォルトのアクセス権限にする
		String value = filterConfig.getInitParameter("accessAuthorityWithoutSet");

		if (value == null) {
			return;
		}

		_accessAuthorityWithoutSet = (value.equalsIgnoreCase("true")) ? true
				: false;

	}

	@Override
	public void destroy() {
		_properties = null;
		super.destroy();
	}

	protected String getConfigPath() {
		return PROPERTIES_FILE_NAME.replace('.', '/') + ".properties";
	}

	protected void loadProperties() {
		String path = getConfigPath();
		URL url = GFileUtils.getResource(path);
		if (url == null) {
			throw new MissingResourceException("property file is not found. : "	+ path, path, "");
		}

		_properties = new Properties();
		try {
			InputStream stream = url.openStream();
			_properties.load(stream);
		} catch (IOException e) {
			throw new MissingResourceException(e.getMessage(), path, "");
		}
	}

	@Override
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {

		if (!checkAuthority(request, response)) {
			throw createAuthorizationException();
		}

		chain.doFilter(request, response);
	}

	protected boolean checkAuthority(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		String uri = request.getRequestURI();
		if (!_properties.containsKey(uri)) {
			return _accessAuthorityWithoutSet;
		}

		String roleID = _properties.getProperty(uri);
		if (GStringUtils.isEmpty(roleID)) {
			return false;
		}

		GSessionManager sessionManager = GSessionManagerFactory.getSessionManager();
		GSession gsession = sessionManager.getSession(request.getSession());
		GUser user = gsession.getLoginUser();
		if (user == null) {
			return false;
		}
		GCompany company = user.getCompany();
		GRoleFinder finder = GRoleFinder.Factory.getInstance();
		GRole role = finder.getRole(company.getCode(), roleID);
		if (role == null) {
			return false;
		}
		return role.hasAuthority(user);
	}

	protected GAuthorizationException createAuthorizationException() {
		GErrorMessage message = GErrorMessages.getErrorMessage("GEF-001004", GFrameworkContext.getInstance().getLocale());
		return new GAuthorizationException(message);
	}
}
