/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * {@link ArrayList}を基底とした{@link GPageableList}の実装クラスです。
 *
 * @param <T> リストに格納される要素の型
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GArrayPageableList<T> implements GPageableList<T> {
	
	/** シリアルバージョンID */
	private static final long serialVersionUID = -2936517960935997322L;

	/** 行データマップ. */
	private List<T> _rows = new ArrayList<T>();

	/** 開始インデックス. */
	private int _startIndex = -1;

	/** 全ページングリストの合計サイズ. */
	private int _totalSize = 0;

	/** 1ページに表示する最大データ件数. */
	private int _maxListSize = -1;

	/**
	 * {@link GArrayPageableList}インスタンスを初期化します。<br>
	 *
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public GArrayPageableList() {
	}

	/**
	 * トータルサイズを指定して、{@link GArrayPageableList}インスタンスを初期化します 。<br>
	 *
	 * @param totalSize トータルサイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public GArrayPageableList(int totalSize) {
		_totalSize = totalSize;
	}

	/**
	 * スタート位置、トータルサイズを指定して、{@link GArrayPageableList}インスタンスを初期化します 。<br>
	 *
	 * @param startIndex 開始インディクス
	 * @param totalSize トータルサイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public GArrayPageableList(int startIndex, int totalSize) {
		this(totalSize);

		_startIndex = startIndex;
	}

	/**
	 * スタート位置、トータルサイズ、最大リストサイズを指定して、{@link GArrayPageableList}インスタンスを初期化します 。<br>
	 *
	 * @param startIndex 開始インディクス
	 * @param totalSize トータルサイズ
	 * @param maxListSize リスト最大サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public GArrayPageableList(int startIndex, int totalSize, int maxListSize) {
		this(startIndex, totalSize);

		_maxListSize = maxListSize;
	}

	/**
	 * 要素を挿入します.<br>
	 *
	 * @param data データ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public void add(T data) {
		_rows.add(data);
	}

	/**
	 * 指定したインディクスに要素を挿入します.<br>
	 *
	 * @param index インディクス
	 * @param element 要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public void add(int index, T element) {
		_rows.add(index, element);
	}

	/**
	 * コレクションの全要素を挿入します.<br>
	 *
	 * @param c リストに追加されるコレクション
	 * @return この呼び出しの結果、このリストが変更された場合は true
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean addAll(Collection<T> c) {
		return _rows.addAll(c);
	}

	/**
	 * 指定したインディクスにコレクションの全要素を挿入します.<br>
	 *
	 * @param index インディクス
	 * @param c コレクション
	 * @return boolean
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean addAll(int index, Collection<T> c) {
		return _rows.addAll(index, c);
	}

	/**
	 * 全要素を削除します.<br>
	 *
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public void clear() {
		_rows.clear();
	}

	/**
	 * 指定された要素が含まれているかどうかを判断します.<br>
	 *
	 * @param data データ
	 * @return boolean<br>
	 * 			true:　含まれている / false: 含まれていない
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean contains(T data) {
		return _rows.contains(data);
	}

	/**
	 * 指定されたコレクションが含まれているかどうかを判断します.<br>
	 *
	 * @param c コレクション
	 * @return boolean<br>
	 * 			true:　含まれている / false: 含まれていない
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean containsAll(Collection<T> c) {
		return _rows.containsAll(c);
	}

	/**
	 * 指定されたインディクスにある要素を取得します.<br>
	 *
	 * @param index インデックス
	 * @return 該当する要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public T get(int index) {
		return _rows.get(index);
	}

	/**
	 * リストを取得します.
	 *
	 * @return リスト
	 */
	public List<T> getRows() {
		return _rows;
	}

	/**
	 * リストの最大のサイズを取得します.<br>
	 *
	 * @return int サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public int getMaxListSize() {
		return _maxListSize;
	}

	/**
	 * リストの開始インディクスを取得します.<br>
	 *
	 * @return int 開始インディクス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public int getStartIndex() {
		return _startIndex;
	}

	/**
	 * リストのトータルサイズを取得します.<br>
	 *
	 * @return int サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public int getTotalSize() {
		return _totalSize;
	}

	/**
	 * 指定した要素のインディクスを取得します.<br>
	 *
	 * @param data 要素
	 * @return インデックス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public int indexOf(T data) {
		return _rows.indexOf(data);
	}

	/**
	 * 要素の有無を判断します.<br>
	 *
	 * @return boolean <br>
	 * 			true: 存在する / false: 存在しない
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean isEmpty() {
		return _rows.isEmpty();
	}

	/**
	 * 指定した要素が最後に検出されたインディクスを取得します.<br>
	 *
	 * @param data 要素
	 * @return インディクス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public int lastIndexOf(T data) {
		return _rows.lastIndexOf(data);
	}

	/**
	 * 要素を適切な順序で繰り返し処理する反復子を返します.<br>
	 *
	 * @return Iterator イテレータ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public Iterator<T> iterator() {
		return _rows.iterator();
	}

	/**
	 * 要素を適切な順序で繰り返し処理する反復子を返します.<br>
	 *
	 * @return ListIterator リストイテレータ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public ListIterator<T> listIterator() {
		return _rows.listIterator();
	}

	/**
	 * 指定されたインディクスから開始する反復子を返します.<br>
	 *
	 * @param index インデックス
	 * @return ListIterator リストイテレータ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public ListIterator<T> listIterator(int index) {
		return _rows.listIterator(index);
	}

	/**
	 * 指定した最初に検出された要素を削除します.<br>
	 *
	 * @param data 要素
	 * @return boolean
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean remove(T data) {
		return _rows.remove(data);
	}

	/**
	 * 指定したインディクスにある要素を削除します.<br>
	 *
	 * @param index 要素がリストに追加されるコレクション
	 * @return 指定された位置に以前あった要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public T remove(int index) {
		return _rows.remove(index);
	}

	/**
	 * 指定したコレクションを削除します.<br>
	 *
	 * @param c どの要素がリストから削除されるかを定義するコレクション
	 * @return この呼び出しの結果、このリストが変更された場合は true
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean removeAll(Collection<T> c) {
		return _rows.removeAll(c);
	}

	/**
	 * 指定したコレクションに格納されている要素だけが含まれるようにします.<br>
	 *
	 * @param c セットが保持する要素を定義するコレクション
	 * @return この呼び出しの結果、このリストが変更された場合は <true></true>
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public boolean retainAll(Collection<T> c) {
		return _rows.retainAll(c);
	}

	/**
	 * 指定した位置にある要素を、指定した要素に置き換えます .<br>
	 *
	 * @param index 置換される要素のインデックス
	 * @param element 指定された位置に格納される要素
	 * @return 指定された位置に以前あった要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public T set(int index, T element) {
		return _rows.set(index, element);
	}

	/**
	 * リストの最大サイズを設定します .<br>
	 *
	 * @param maxListSize リスト最大サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setMaxListSize(int maxListSize) {
		_maxListSize = maxListSize;
	}

	/**
	 * 開始インディクスを設定します .<br>
	 *
	 * @param startIndex 開始インディクス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setStartIndex(int startIndex) {
		_startIndex = startIndex;
	}

	/**
	 * トータルサイズを設定します .<br>
	 *
	 * @param totalSize トータルサイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public void setTotalSize(int totalSize) {
		_totalSize = totalSize;
	}

	/**
	 * サイズを取得します .<br>
	 *
	 * @return int サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	public int size() {
		return _rows.size();
	}

}
