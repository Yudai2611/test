/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

/**
 * ダウンロード時の表示タイプを表現します.<br>
 * [1]INLINE　　　:送信内容をブラウザによってただちに表示する。<br>
 * [2]ATTACHMENT　:ブラウザによってファイルに保存する。<br>
 * 
 * @create 2007/02/20
 * @author fujikawa
 * @since 3.0.0
 */
public enum GDownloadDisplayType {
	/** 送信内容をブラウザによってただちに表示する. */
	INLINE("inline"),
	/** ブラウザによってファイルに保存する. */
	ATTACHMENT("attachment");

	/** 表示名. */
	private String _name;

	/**
	 * コンストラクタ.<br>
	 * 
	 * @create 2007/02/20
	 * @param name 表示名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	GDownloadDisplayType(String name) {
		_name = name;
	}

	/**
	 * 文字列表現を返します.<br>
	 * 
	 * @create 2007/02/20
	 * @return 表示名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public String toString() {
		return _name;
	}
}
