/*
 * Copyright 2007-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * ダウンロードファイルを表現します.<br>
 * 
 * @create 2007/02/19
 * @author fujikawa
 * @since 3.0.0
 */
public class GDownloadFile {

	/** テンポラリファイル名. */
	public static final String TEMP_FILE_NAME = "GDownloadFile";

	/** ダウンロードファイル. */
	protected File _file = null;

	/** ダウンロードファイル入力ストリーム. */
	protected InputStream _inputStream = null;

	/** ダウンロードファイル出力ストリーム. */
	protected OutputStream _outputStream = null;

	/** テンポラリファイル. */
	protected File _tempFile = null;


	/** レスポンス書き込み時のバッファリングサイズ */
	private int _bufferSize = -1;
	
	/** コンテンツのサイズ */
	private long _contentLength = -1; 

	/** コンテンツのタイプ. */
	private String _contentType = null;

	/** 削除フラグ. */
	private boolean _deleteFlag = false;

	/** ダウンロード時の表示タイプ（ディスポジションタイプ）. */
	private GDownloadDisplayType _displayType = GDownloadDisplayType.ATTACHMENT;

	/** ダウンロードファイル名. */
	private String _name = null;

	/**
	 * コンストラクタ.
	 * 
	 * @create 2007/04/17
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GDownloadFile() {
	}

	/**
	 * {@link File}を指定してダウンロードファイルを生成します.
	 * 
	 * @create 2007/04/17
	 * @param file ファイル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GDownloadFile(File file) {
		_file = file;
		if (_file.exists()) {
			setContentLength(_file.length());
		}
	}

	/**
	 * {@link File}、ダウンロード後にファイルを削除するかどうかを指定して ダウンロードファイルを生成します.
	 * 
	 * @create 2007/04/17
	 * @param file ファイル
	 * @param deleteFlag ダウンロード後にファイルを削除するかどうか
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GDownloadFile(File file, boolean deleteFlag) {
		this(file);
		_deleteFlag = deleteFlag;
	}

	/**
	 * {@link InputStream}を指定してダウンロードファイルを生成します.
	 * 
	 * @create 2007/04/17
	 * @param inputstream 入力ストリーム
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GDownloadFile(InputStream inputstream) {
		_inputStream = inputstream;
	}

	/**
	 * テンポラリファイルへの出力ストリームをcloseします.
	 * 
	 * @create 2007/04/16
	 * @author fujikawa
	 * @throws IOException ファイルI/O例外
	 * @since 3.0.0
	 */
	public void close() throws IOException {
		_outputStream.close();
	}

	/**
	 * ファイル・テンポラリファイルを削除し、入力ストリームはcloseします.
	 * 
	 * @create 2007/04/16
	 * @author fujikawa
	 * @throws IOException ファイルI/O例外
	 * @since 3.0.0
	 */
	public void delete() throws IOException {
		if (_outputStream != null) {
			_outputStream.close();
		}
		if (_file != null) {
			if (isDeleteFlag() && _file.exists()) {
				_file.delete();
			}
		}
		if (_tempFile != null) {
			if (_tempFile.exists()) {
				_tempFile.delete();
			}
		}
		if (_inputStream != null) {
			_inputStream.close();
		}
	}

	/**
	 * テンポラリファイルへの出力ストリームをflushします.
	 * 
	 * @create 2007/04/16
	 * @author fujikawa
	 * @throws IOException ファイルI/O例外
	 * @since 3.0.0
	 */
	public void flush() throws IOException {
		_outputStream.flush();
	}

	/**
	 * レスポンス書き込み時のバッファリングサイズを取得します.
	 * 
	 * @create 2009/05/06
	 * @return bufferSize バッファリングサイズ
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public int getBufferSize() {
		return _bufferSize;
	}
	
	/**
	 * コンテンツのサイズを取得します。
	 * 
	 * @create 2010/10/27
	 * @return コンテンツのサイズ
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public long getContentLength() {
		return _contentLength;
	}

	/**
	 * コンテントタイプを取得します.
	 * 
	 * @create 2007/02/19
	 * @return コンテントタイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public String getContentType() {
		return _contentType;
	}

	/**
	 * ダウンロード時の表示タイプを取得します.
	 * 
	 * @create 2007/02/19
	 * @return ダウンロード時の表示タイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GDownloadDisplayType getDisplayType() {
		return _displayType;
	}

	/**
	 * {@link InputStream}を取得します.
	 * 
	 * @create 2007/04/16
	 * @return 入力ストリーム
	 * @author fujikawa
	 * @throws FileNotFoundException ファイル読込時の例外
	 * @since 3.0.0
	 */
	public InputStream getInputStream() throws FileNotFoundException {
		if (_file != null) {
			return new FileInputStream(_file);
		}
		if (_tempFile != null) {
			return new FileInputStream(_tempFile);
		}
		return _inputStream;
	}

	/**
	 * ダウンロードファイル名を取得します.
	 * 
	 * @create 2007/02/19
	 * @return ダウンロードファイル名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public String getName() {
		String name = null;
		if (_file != null) {
			name = _file.getName();
		}
		if (_name != null) {
			name = _name;
		}
		return name;
	}

	/**
	 * ダウンロード後にファイルを削除するかどうかを取得します.
	 * 
	 * @create 2007/04/16
	 * @return true：ファイルを削除する／false：ファイルを削除しない
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public boolean isDeleteFlag() {
		return _deleteFlag;
	}

	/**
	 * テンポラリファイルへの出力ストリームをオープンします.
	 * 
	 * @create 2007/04/16
	 * @author fujikawa
	 * @throws IllegalStateException ファイル・入力ストリームが指定されていてopenが呼び出された場合
	 * @throws IOException ファイルオープン例外
	 * @since 3.0.0
	 */
	public void open() throws IllegalStateException, IOException {
		if (_file != null || _inputStream != null) {
			throw new IllegalStateException("Invalid action.");
		}

		if (_outputStream == null) {
			_tempFile = File.createTempFile(TEMP_FILE_NAME, null);
			_outputStream = new FileOutputStream(_tempFile);
		}
	}

	/**
	 * レスポンス書き込み時のバッファリングサイズを設定します.
	 *
	 * @create 2009/05/06
	 * @param bufferSize バッファリングサイズ
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public void setBufferSize(int bufferSize) {
		_bufferSize = bufferSize;
	}
	
	/**
	 * コンテンツのサイズを設定します。
	 * 
	 * @create 2010/10/27
	 * @param contentLength コンテンツのサイズ
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public void setContentLength(long contentLength) {
		_contentLength = contentLength;
	}

	/**
	 * コンテンツのタイプを設定します.
	 * 
	 * @create 2007/02/19
	 * @param contentType タイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setContentType(String contentType) {
		_contentType = contentType;
	}

	/**
	 * ダウンロード後にファイルを削除するかどうかを設定します.
	 * 
	 * @create 2007/04/16
	 * @param flag ダウンロード後にファイルを削除するかどうか
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setDeleteFlag(boolean flag) {
		_deleteFlag = flag;
	}

	/**
	 * ダウンロード時の表示タイプを設定します.
	 * 
	 * @create 2007/02/19
	 * @param type ダウンロード時の表示タイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setDisplayType(GDownloadDisplayType type) {
		_displayType = type;
	}

	/**
	 * ファイル名を設定します.
	 * 
	 * @create 2007/04/16
	 * @param name ダウンロードファイル名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * 指定されたバイト配列の b.length バイトをこのダウンロードファイルに書き込みます.
	 * 
	 * @create 2007/04/16
	 * @param b バイト配列
	 * @author fujikawa
	 * @throws IOException ファイル書き込み例外
	 * @throws IllegalStateException ファイル・入力ストリームが指定されていてopenが呼び出された場合
	 * @since 3.0.0
	 */
	public void write(byte[] b) throws IOException, IllegalStateException {
		if (_file != null || _inputStream != null) {
			throw new IllegalStateException("Invalid action.");
		}
		if (_outputStream == null) {
			throw new IllegalStateException("OutputStream is not open.");
		}
		_outputStream.write(b);
	}

	/**
	 * ガーベージコレクション時の処理です.
	 * 
	 * @create 2007/04/16
	 * @throws Throwable 例外
	 * @author fujikawa
	 * @since 3.0.0
	 */
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		delete();
	}
}
