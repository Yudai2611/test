/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.util.HashMap;
import java.util.Map;

/**
 * エラーレベルを定義します.
 * 
 * @create 2007/03/27
 * @author fujikawa
 * @since 3.0.0
 */
public enum GErrorLevel {
	/** なし. */
	NONE("none"),
	/** インフォメーションレベル. */
	INFO("info"),
	/** 警告レベル. */
	WARNING("warning"),
	/** エラーレベル. */
	ERROR("error");

	/** エラーレベルマップ. */
	private static Map<String, GErrorLevel> map = new HashMap<String, GErrorLevel>();
	/** 表示名. */
	private String name = null;

	static {
		map.put(NONE.name, GErrorLevel.NONE);
		map.put(INFO.name, GErrorLevel.INFO);
		map.put(WARNING.name, GErrorLevel.WARNING);
		map.put(ERROR.name, GErrorLevel.ERROR);
	}

	/**
	 * コンストラクタ.<br>
	 * 
	 * @create 2007/03/27
	 * @param name 表示名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	GErrorLevel(String name) {
		this.name = name;
	}

	/**
	 * String型のエラーレベルをGErrorLevel型に変換します.<br>
	 * 
	 * @create 2007/03/27
	 * @param errorLevel	エラーレベルの文字列
	 * @return エラーレベル
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static GErrorLevel convert(String errorLevel) {
		GErrorLevel key = map.get(errorLevel);
		if (key == null) {
			key = GErrorLevel.INFO;
		}
		return key;
	}

	/**
	 * 文字列表現を返します.<br>
	 * 
	 * @create 2007/03/27
	 * @return 表示名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public String toString() {
		return name;
	}
}
