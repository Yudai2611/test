/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;


/**
 * アクションの実行結果である{@link GResultData}に格納できるリスト要素を表します.<br>
 * n行n列のリスト構造となっており、行を表す{@link GRowData}と、行内の各セルを構成する各データ要素で構成されます。
 * 
 * @see jp.co.kccs.greenearth.framework.data.GResultData
 * @see jp.co.kccs.greenearth.framework.data.GRowData
 * @create 2007/01/21
 * @author kitamura
 * @since 3.0.0
 */
public class GListData extends GArrayPageableList<GRowData> {
	
	/** シリアルバージョンID */
	private static final long serialVersionUID = 374405826779858635L;

	/**
	 * {@link GListData}インスタンスを初期化します.
	 * 
	 * @create 2007/02/08
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GListData() {
	}

	/**
	 * 全ページングリストの合計サイズを指定してリストを生成します.
	 * 
	 * @create 2007/02/08
	 * @param totalSize 全てのリストの合計サイズ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GListData(int totalSize) {
		super(totalSize);
	}

	/**
	 * 開始インデックスおよび全ページングリストの合計サイズを指定してリストを生成します.
	 * 
	 * @create 2007/02/08
	 * @param totalSize 全てのリストの合計サイズ
	 * @param startIndex リストの開始インデックス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GListData(int startIndex, int totalSize) {
		super(startIndex, totalSize);
	}

	/**
	 * 開始インデックス、全ページングリストの合計サイズ、および1ページに表示する最大データ件数を指定してリストを生成します.
	 * 
	 * @create 2008/04/22
	 * @param startIndex 全てのリストの合計サイズ
	 * @param totalSize リストの開始インデックス
	 * @param maxListSize 1ページに表示する最大データ件数
	 * @auther kitamura
	 * @since 3.5.0
	 */
	public GListData(int startIndex, int totalSize, int maxListSize) {
		super(startIndex, totalSize, maxListSize);
	}
}
