/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;

/**
 * ページングするリストのメタデータを表すインターフェースです.<br>
 * 
 * @param <T> リストに格納される要素の型
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public interface GPageableList<T> extends Iterable<T>,Serializable {

	/**
	 * 要素を挿入します.<br>
	 * 
	 * @param data データ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	void add(T data);

	/**
	 * 指定したインディクスに要素を挿入します.<br>
	 * 
	 * @param index インディクス
	 * @param element 要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	void add(int index, T element);

	/**
	 * コレクションの全要素を挿入します.<br>
	 * 
	 * @param c リストに追加されるコレクション
	 * @return この呼び出しの結果、このリストが変更された場合は true
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean addAll(Collection<T> c);

	/**
	 * 指定したインディクスにコレクションの全要素を挿入します.<br>
	 * 
	 * @param index インディクス
	 * @param c コレクション
	 * @return boolean 
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean addAll(int index, Collection<T> c);

	/**
	 * 全要素を削除します.<br>
	 * 
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	void clear();

	/**
	 * 指定された要素が含まれているかどうかを判断します.<br>
	 * 
	 * @param data データ
	 * @return boolean<br>
	 * 			true:　含まれている / false: 含まれていない
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean contains(T data);

	/**
	 * 指定されたコレクションが含まれているかどうかを判断します.<br>
	 *
	 * @param c コレクション
	 * @return boolean<br>
	 * 			true:　含まれている / false: 含まれていない
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean containsAll(Collection<T> c);

	/**
	 * 指定されたインディクスにある要素を取得します.<br>
	 * 
	 * @param index インデックス
	 * @return 該当する要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	T get(int index);

	/**
	 * リストの最大のサイズを取得します.<br>
	 * 
	 * @return int サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	int getMaxListSize();

	/**
	 * リストを取得します.
	 *
	 * @return リスト
	 */
	List<T> getRows();

	/**
	 * リストの開始インディクスを取得します.<br>
	 * 
	 * @return int 開始インディクス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	int getStartIndex();

	/**
	 * リストのトータルサイズを取得します.<br>
	 * 
	 * @return int サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	int getTotalSize();

	/**
	 * 指定した要素のインディクスを取得します.<br>
	 * 
	 * @param data 要素
	 * @return インデックス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	int indexOf(T data);

	/**
	 * 要素の有無を判断します.<br>
	 * 
	 * @return true: 存在する / false: 存在しない
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean isEmpty();

	/**
	 * 指定した要素が最後に検出されたインディクスを取得します.<br>
	 * 
	 * @param data 要素
	 * @return インディクス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	int lastIndexOf(T data);

	/**
	 * 要素を適切な順序で繰り返し処理する反復子を返します.<br>
	 * 
	 * @return ListIterator リストイテレータ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	ListIterator<T> listIterator();

	/**
	 * 指定されたインディクスから開始する反復子を返します.<br>
	 * 
	 * @param index インデックス
	 * @return ListIterator リストイテレータ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	ListIterator<T> listIterator(int index);

	/**
	 * 指定した最初に検出された要素を削除します.<br>
	 * 
	 * @param data 要素
	 * @return boolean
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean remove(T data);

	/**
	 * 指定したインディクスにある要素を削除します.<br>
	 * 
	 * @param index 要素がリストに追加されるコレクション
	 * @return 指定された位置に以前あった要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	T remove(int index);

	/**
	 * 指定したコレクションを削除します.<br>
	 * 
	 * @param c どの要素がリストから削除されるかを定義するコレクション
	 * @return この呼び出しの結果、このリストが変更された場合は true
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean removeAll(Collection<T> c);

	/**
	 * 指定したコレクションに格納されている要素だけが含まれるようにします.<br>
	 * 
	 * @param c セットが保持する要素を定義するコレクション
	 * @return この呼び出しの結果、このリストが変更された場合は <true></true>
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	boolean retainAll(Collection<T> c);

	/**
	 * 指定した位置にある要素を、指定した要素に置き換えます .<br>
	 * 
	 * @param index 置換される要素のインデックス
	 * @param element 指定された位置に格納される要素
	 * @return 指定された位置に以前あった要素
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	T set(int index, T element);

	/**
	 * リストの最大サイズを設定します .<br>
	 * 
	 * @param maxListSize リスト最大サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	void setMaxListSize(int maxListSize);

	/**
	 * 開始インディクスを設定します .<br>
	 * 
	 * @param startIndex 開始インディクス
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	void setStartIndex(int startIndex);

	/**
	 * トータルサイズを設定します .<br>
	 * 
	 * @param totalSize トータルサイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	void setTotalSize(int totalSize);

	/**
	 * サイズを取得します .<br>
	 * 
	 * @return int サイズ
	 * @create 2011/04/18
	 * @author kyo
	 * @since 3.9.0
	 */
	int size();
}