/*
 * Copyright 2014-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;

/**
 * 画面に表示されているリストのページング処理を提供します。<br/>
 * 主にページ単位の開始位置や件数の計算を行います。
 *
 * @param <T> リストの要素となるオブジェクトの型
 * @create 2014/02/20
 * @author KCCS N.Nishimura
 * @since 3.13.0
 */
public abstract class GPagingNavigator<T> {

	/** デフォルトのリストサイズ. */
	public static final int DEFAULT_LIST_SIZE = -1;

	/** 画面項目：リストサイズ */
	public static final String LISTSIZE = ".listsize";

	/** 最初ページ(mode) */
	public static final String MODE_FIRST = "first";

	/** 最後ページ(mode) */
	public static final String MODE_LAST = "last";

	/** 次ページ(mode) */
	public static final String MODE_NEXT = "next";

	/** 前ページ(mode) */
	public static final String MODE_PREVIOUS = "previous";

	/** 次ページ(destpage) */
	@Deprecated
	protected static final String DESTPAGE_NEXT = "NEXT";

	/** 前ページ(destpage) */
	@Deprecated
	protected static final String DESTPAGE_PREV = "PREV";

	/** 画面項目：開始インデックス */
	public static final String STARTINDEX = ".startindex";

	/** 画面項目: 遷移先ページ */
	public static final String DESTPAGE = "destpage";

	/**
	 * 指定したパラメータとリストIDからリストに表示するデータの総件数を取得します。
	 *
	 * @param parameter パラメータ
	 * @param listID リストID
	 * @return 総件数
	 * @throws GResourceProcessingException 外部リソースアクセスに失敗した場合
	 * @create 2014/02/20
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public abstract int count(GParameter parameter, String listID) throws GResourceProcessingException;

	/**
	 * 指定したパラメータとリストID、開始位置、リストサイズ、総件数より、１ページ分のリストデータを取得し返します。
	 *
	 * @param parameter パラメータ
	 * @param listID リストID
	 * @param startIndex 開始位置
	 * @param listSize リストサイズ
	 * @param totalCount 総件数
	 * @return １ページ分のリストデータ
	 * @throws GResourceProcessingException 外部リソースアクセスに失敗した場合
	 * @create 2014/02/20
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public abstract List<T> findList(GParameter parameter, String listID, int startIndex, int listSize, int totalCount) throws GResourceProcessingException;

	/**
	 * 指定したパラメータとリストIDより、ページング用のリストデータを取得し返します。<br/>
	 * ページングのスクロール方向はパラメータ内に積まれたmodeキー値によって決定します。<br/>
	 * modeキー値に指定できるパターンは以下になります。<br/>
	 * <code>mode</code>パラメータを識別子に利用することで、「次へ」、「前へ」「最初へ」、「最後へ」のページング処理を自動化します。
	 * <table border="1" cellpadding="3" cellspacing="0">
	 * <tr bgcolor="#CCCCFF"><td>mode</td><td>動作</td></tr>
	 * <tr><td>first</td><td>最初へ</td></tr>
	 * <tr><td>previous</td><td>前へ</td></tr>
	 * <tr><td>next</td><td>次へ</td></tr>
	 * <tr><td>last</td><td>最後へ</td></tr>
	 * </table>
	 *
	 * @param parameter パラメータ
	 * @param listID リストID
	 * @return ページング用のリストデータ
	 * @throws GResourceProcessingException 外部リソースアクセスに失敗した場合
	 * @create 2014/02/20
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public GPageableList<T> findList(GParameter parameter, String listID) throws GResourceProcessingException {

		GSearchMode searchMode = GSearchMode.create(parameter.getValue(GActionServlet.ACTION_MODE_KEY));
		return findListCommon(parameter, listID, searchMode);
	}

	/**
	 * 指定したパラメータとリストIDより、ページネーション用のリストデータを取得し返します。<br/>
	 * ページングのスクロール方向はパラメータ内に積まれたdestpageキー値によって決定します。<br/>
	 * destpageキー値に指定できるパターンは以下になります。<br/>
	 * <code>destpage</code>パラメータを識別子に利用することで、「次へ」、「前へ」、「ページ指定」のページング処理を自動化します。
	 * <table border="1" cellpadding="3" cellspacing="0">
	 * <tr bgcolor="#CCCCFF"><td>mode</td><td>動作</td></tr>
	 * <tr><td>PREV</td><td>前へ</td></tr>
	 * <tr><td>NEXT</td><td>次へ</td></tr>
	 * <tr><td>整数値</td><td>指定されたページへの移動</td></tr>
	 * </table>
	 *
	 * @param parameter パラメータ
	 * @param listID リストID
	 * @return ページネーション用のリストデータ
	 * @throws GResourceProcessingException 外部リソースアクセスに失敗した場合
	 * @create 2014/02/05
	 * @author KCCS N.Nishimura
	 * @since 3.13.0
	 */
	public GPageableList<T> findPaginationList(GParameter parameter, String listID) throws GResourceProcessingException {

		GSearchMode searchMode = GSearchMode.create(parameter.getValue(DESTPAGE));
		return findListCommon(parameter, listID, searchMode);
	}

	private GPageableList<T> findListCommon(GParameter parameter, String listID, GSearchMode searchMode) throws GResourceProcessingException {

		// 開始インデックス
		int startIndex = 0;
		String strStartIndex = parameter.getValue(listID + STARTINDEX);
		if (!GStringUtils.isEmpty(strStartIndex)) {
			startIndex = Integer.parseInt(strStartIndex);
		}

		// リストサイズ
		int listSize = DEFAULT_LIST_SIZE;
		String strListSize = parameter.getValue(listID + LISTSIZE);
		if (!GStringUtils.isEmpty(strListSize)) {
			listSize = Integer.parseInt(strListSize);
		}

		int count = count(parameter, listID);
		// 新しい開始インデックスの計算
		startIndex = calculateStartIndex(startIndex, listSize, count, searchMode);

		List<T> list = null;
		if (count == 0) {
			list = new ArrayList<T>();
		} else {
			list = findList(parameter, listID, startIndex, listSize, count);
		}

		GPageableList<T> listData = new GArrayPageableList<T>();
		listData.addAll(list);
		listData.setStartIndex(startIndex);
		listData.setTotalSize(count);
		listData.setMaxListSize(listSize);
		return listData;
	}

	/**
	 * 指定されたパラメータの情報から検索条件を抽出し、検索を行うページング共通処理です.<br>
	 * 検索した結果は、{@link GListData}形式で取得されます。<br>
	 *
	 * <code>searchMode</code>パラメータを識別子に利用することで、「次へ」、「前へ」「最初へ」、「最後へ」、「指定ページへ」のページング処理を自動化します。
	 * <table border="1" cellpadding="3" cellspacing="0">
	 * <tr bgcolor="#CCCCFF"><td>mode</td><td>動作</td></tr>
	 * <tr><td>SEARCH_MODE_FIRST</td><td>最初へ</td></tr>
	 * <tr><td>SEARCH_MODE_PREVIOUS</td><td>前へ</td></tr>
	 * <tr><td>SEARCH_MODE_NEXT</td><td>次へ</td></tr>
	 * <tr><td>SEARCH_MODE_LAST</td><td>最後へ</td></tr>
	 * <tr><td>SEARCH_MODE_PAGENO</td><td>指定ページへ</td></tr>
	 * </table>
	 *
	 * @param currentIndex 現在の開始位置
	 * @param listSize リストサイズ
	 * @param totalCount 検索結果の総数
	 * @param searchMode 検索モード
	 * @return 検索結果のリスト
	 * @throws SQLException 検索処理中に例外が発生した場合
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public static int calculateStartIndex(int currentIndex, int listSize, int totalCount, GSearchMode searchMode) {
		// 開始インデックス
		if (listSize != GPagingNavigator.DEFAULT_LIST_SIZE) {
			switch (searchMode.getInternalSearchMode()) {
				case SEARCH_MODE_FIRST:
					currentIndex = 0;
					break;
				case SEARCH_MODE_LAST:
					currentIndex = listSize * ((totalCount - 1) / listSize);
					break;
				case SEARCH_MODE_PREVIOUS:
					currentIndex = currentIndex - listSize;
					break;
				case SEARCH_MODE_NEXT:
					currentIndex = currentIndex + listSize;
					break;
				case SEARCH_MODE_PAGENO:
					int pagNo = Integer.parseInt(searchMode.getValue());
					currentIndex = (pagNo - 1) * listSize;
					break;
				default:
					// 通常検索
					currentIndex = 0;
			}
			// 算出されたstartIndexが許可値以外なら、補正処理を行う
			if (currentIndex < 0) {
				currentIndex = 0; // トップへ
			} else if (currentIndex + 1 > totalCount) {
				currentIndex = listSize * ((totalCount - 1) / listSize); // ラストへ
			}
			return currentIndex;
		}
		// 通常検索
		return 0;
	}

}
