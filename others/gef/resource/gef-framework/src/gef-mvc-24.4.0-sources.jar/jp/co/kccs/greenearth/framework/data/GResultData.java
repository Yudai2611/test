/*
 * Copyright 2007-2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.utils.GConvertUtils;

/**
 * アクション（ビジネスロジック）の処理結果を格納する結果セットを表すクラスです.<br>
 * アクションは処理結果として必ず結果セットを返す必要があります。<br>
 * <br>
 * {@link GResultData}には処理結果として主に以下のような情報を積み込む事ができます。
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>積み込めるクラス</td><td>データが持つ意味</td></tr>
 * <tr><td><code>byte</code></td><td>整数型(<code>byte</code>)のデータ</td></tr>
 * <tr><td><code>short</code></td><td>整数型(<code>short</code>)のデータ</td></tr>
 * <tr><td><code>int</code></td><td>整数型(<code>int</code>)のデータ</td></tr>
 * <tr><td><code>long</code></td><td>整数型(<code>long</code>)のデータ</td></tr>
 * <tr><td><code>float</code></td><td>浮動小数点数(<code>float</code>)のデータ</td></tr>
 * <tr><td><code>double</code></td><td>浮動小数点数(<code>double</code>)のデータ</td></tr>
 * <tr><td><code>boolean</code></td><td>真偽値データ</td></tr>
 * <tr><td>{@link String}</td><td>文字列データ</td></tr>
 * <tr><td>{@link BigInteger}</td><td>任意精度の整数データ</td></tr>
 * <tr><td>{@link BigDecimal}</td><td>任意精度の符号付き 10 進数のデータ</td></tr>
 * <tr><td>{@link Date}</td><td>日付型データ</td></tr>
 * <tr><td>{@link GListData}</td><td>上記データを要素に持つn行n列のリストデータ</td></tr>
 * <tr><td>{@link GDownloadFile}</td><td>ダウンロードファイル</td></tr>
 * <tr><td>{@link GValidateError}</td><td>入力チェックエラー</td></tr>
 * </table>
 * <br>
 * また、結果セットには処理結果を総体的に表す終了コード(ExitCode)を設定する必要があります。<br>
 * 終了コードを明示的に指定しなかった場合は、デフォルト値として{@value #EXIT_CODE_SUCCESS}が適用されます。<br>
 * 終了コードには任意の文字列を指定しますが、次のコードはフレームワークで予約されています。<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>終了コード</td><td>意味</td></tr>
 * <tr><td>{@value #EXIT_CODE_SUCCESS}</td><td>処理の正常終了</td></tr>
 * <tr><td>{@value #EXIT_CODE_VALIDATE_ERROR}</td><td>入力値（パラメータ）の検証エラー</td></tr>
 * <tr><td>{@value #EXIT_CODE_FILE_DOWNLOAD}</td><td>ファイルのダウンロード<br></td></tr>
 * <tr><td>{@value #EXIT_CODE_DIRECT_RESPONSE}</td><td>GreenEARTH Frameworkのレスポンス生成機能を利用せず、
 *    独自で生成したレスポンスをクライアントに返す場合の終了コード。</td></tr>
 * <tr><td>{@value #EXIT_CODE_SYSTEM_ERROR}</td><td>システムエラー</td></tr>
 * </table>
 * 
 * @create 2006/12/16
 * @author kitamura
 * @since 3.0.0
 */
public class GResultData {

	/** メソッドを実行せず、Action内で生成したレスポンスをそのままクライアントに返します. */
	public static final String EXIT_CODE_DIRECT_RESPONSE = "direct-response";
	/** 処理の正常終了を表す終了コード. */
	public static final String EXIT_CODE_SUCCESS = "success";
	/** 値の検証エラーが発生した場合の終了コード. */
	public static final String EXIT_CODE_VALIDATE_ERROR = "validate-error";
	/** ファイルダウンロードを表す終了コード. */
	public static final String EXIT_CODE_FILE_DOWNLOAD = "file-download";
	/** システムエラーを表す終了コード. */
	public static final String EXIT_CODE_SYSTEM_ERROR = "system-error";
	
	/** 処理結果マップ. */
	private Map<String, Object> _datas = new HashMap<String, Object>();
	/** 終了コード. */
	private String _exitCode = EXIT_CODE_SUCCESS;
	/** 検証エラーリスト. */
	private List<GValidateError> _validateErrors = new ArrayList<GValidateError>();
	/** ダウンロードファイル. */
	private GDownloadFile _downloadFile = null;
	/** 例外 */
	private Throwable _throwable = null;
	
	/**
	 * {@link GResultData}インスタンスを初期化します.
	 * 
	 * @create 2006/12/16
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GResultData() {
	}

	/**
	 * 終了コードを指定して{@link GResultData}インスタンスを初期化します.
	 * 
	 * @create 2006/12/16
	 * @param exitCode 終了コード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GResultData(String exitCode) {
		_exitCode = exitCode;
	}

	/**
	 * チェックエラーを追加します.
	 * 
	 * @create 2006/12/16
	 * @param error チェックエラー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addError(GValidateError error) {
		_validateErrors.add(error);
	}

	/**
	 * リスト内の指定された位置に、チェックエラーを挿入します .
	 * 
	 * @create 2006/12/16
	 * @param index インデックス
	 * @param error チェックエラー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addError(int index, GValidateError error) {
		_validateErrors.add(index, error);
	}

	/**
	 * 指定されたチェックエラーリスト内の全ての要素を挿入します.
	 * 
	 * @create 2006/12/16
	 * @param errors チェックエラーリスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void addErrors(List<GValidateError> errors) {
		_validateErrors.addAll(errors);
	}

	/**
	 * 格納されている値全てをクリアします.<br>
	 * 終了コードも{@link #EXIT_CODE_SUCCESS}で初期化されます。
	 * 
	 * @create 2006/12/16
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clear() {
		_datas.clear();
		_exitCode = EXIT_CODE_SUCCESS;
		_validateErrors.clear();
		_downloadFile = null;
	}

	/**
	 * 格納されているデータをクリアします.
	 * 
	 * @create 2007/01/21
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clearDatas() {
		_datas.clear();
	}

	/**
	 * エラーリストをクリアします.
	 * 
	 * @create 2006/12/16
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clearErrors() {
		_validateErrors.clear();
	}

	/**
	 * 処理結果に指定の名前のマッピングを保持する場合に<code>true</code>を返します.
	 * 
	 * @create 2006/12/26
	 * @param name 名前
	 * @return true/false
	 * @author shimano
	 * @since 3.0.0
	 */
	public boolean containsDataName(String name) {
		return _datas.containsKey(name);
	}

	/**
	 * チェックエラーリスト内に指定のエラーが存在する場合に<code>true</code>を返します.
	 * 
	 * @create 2006/12/27
	 * @param error チェックエラー
	 * @return true/false
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean containsError(GValidateError error) {
		return _validateErrors.contains(error);
	}

	/**
	 * 格納されている結果オブジェクトマップの名前のセットビューを返します.
	 * 
	 * @create 2006/12/16
	 * @return キーセット
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Set<String> dataNameSet() {
		return _datas.keySet();
	}

	/**
	 * 結果オブジェクトマップのサイズを取得します.
	 * 
	 * @create 2006/12/16
	 * @return サイズ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public int datasSize() {
		return _datas.size();
	}

	/**
	 * エラーリスト内の要素を適切な順序で繰り返し処理する反復子を返します.
	 * 
	 * @create 2007/01/21
	 * @return エラーリストイテレータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Iterator<GValidateError> errorIterator() {
		return _validateErrors.iterator();
	}

	/**
	 * エラーリストのサイズを取得します.
	 * 
	 * @create 2006/12/16
	 * @return サイズ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public int errorsSize() {
		return _validateErrors.size();
	}
	
	/**
	 * 指定された名前で格納されている{@link BigDecimal}値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link BigDecimal}として作り直されて({@link BigDecimal#BigDecimal(String))返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return {@link BigDecimal}値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public BigDecimal getBigDecimal(String name) {
		Object value = _datas.get(name);
		return GConvertUtils.toBigDecimal(value);
	}

	/**
	 * 指定された名前で格納されている{@link BigInteger}値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link BigInteger}として作り直されて({@link BigInteger#BigInteger(String))返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return {@link BigInteger}値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public BigInteger getBigInteger(String name) {
		Object value = _datas.get(name);
		return GConvertUtils.toBigInteger(value);
	}

	/**
	 * 指定された名前で格納されている<code>boolean</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Boolean#parseBoolean(String)}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>boolean</code>値
	 * @throws ClassCastException 該当する値が<code>boolean</code>値として認識できなかった場合
	 * @throws IllegalArgumentException 該当する値が<code>null</code>の場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean getBoolean(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _datas.get(name);
		return GConvertUtils.toBoolean(value);
	}

	/**
	 * 指定された名前で格納されている<code>byte</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Byte#parseByte(String)}された値が返されます。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#byteValue()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>byte</code>値
	 * @throws ClassCastException 該当する値が<code>byte</code>値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Byte getByte(String name) throws ClassCastException {
		Object value = _datas.get(name);
		return GConvertUtils.toByte(value);
	}

	/**
	 * 指定した名前で格納されている結果オブジェクトを取得します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return 結果オブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object getData(String name) {
		return _datas.get(name);
	}

	/**
	 * 指定された名前で格納されている{@link Date}値を取得します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return {@link Date}値
	 * @author aono
	 * @since 3.0.0
	 */
	public Date getDate(String name) {
		Object value = _datas.get(name);
		return GConvertUtils.toDate(value);
	}

	/**
	 * 指定された名前で格納されている<code>double</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Double#parseDouble(String)}された値が返されます。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#doubleValue()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>double</code>値
	 * @throws ClassCastException 該当する値が<code>double</code>値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Double getDouble(String name) throws ClassCastException {
		Object value = _datas.get(name);
		return GConvertUtils.toDouble(value);
	}

	/**
	 * ダウンロードファイルを取得します.
	 * 
	 * @create 2007/01/29
	 * @return ダウンロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GDownloadFile getDownloadFile() {
		return _downloadFile;
	}

	/**
	 * 指定した位置に格納されているチェックエラーを取得します.
	 * 
	 * @create 2006/12/18
	 * @param index インデックス
	 * @return チェックエラー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError getError(int index) {
		return _validateErrors.get(index);
	}

	/**
	 * チェックエラーのリストを取得します.
	 * 
	 * @create 2006/12/16
	 * @return チェックエラーリスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public List<GValidateError> getErrors() {
		return _validateErrors;
	}

	/**
	 * {@link Throwable}を取得します.<br>
	 * 
	 * @create 2023/10/25
	 * @return {@link Throwable}値
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public Throwable getException() {
		return _throwable;
	}

	/**
	 * 終了コードを取得します.
	 * 
	 * @create 2006/12/16
	 * @return 終了コード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getExitCode() {
		return _exitCode;
	}

	/**
	 * 指定された名前で格納されている<code>float</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Float#parseFloat(String)}された値が返されます。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#floatValue()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>float</code>値
	 * @throws ClassCastException 該当する値が<code>float</code>値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Float getFloat(String name) throws ClassCastException {
		Object value = _datas.get(name);
		return GConvertUtils.toFloat(value);
	}

	/**
	 * 指定された名前で格納されている<code>int</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Integer#parseInt(String)}された値が返されます。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#intValue()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>int</code>値
	 * @throws ClassCastException 該当する値が<code>int</code>値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Integer getInteger(String name) throws ClassCastException {
		Object value = _datas.get(name);
		return GConvertUtils.toInteger(value);
	}

	/**
	 * 指定された名前で格納されている{@link GListData}値を取得します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return {@link GListData}値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GListData getListData(String name) {
		Object value = _datas.get(name);
		if (value != null) {
			if (value instanceof GListData) {
				return (GListData) _datas.get(name);
			}
			else {
				throw new ClassCastException("The value that corresponds to the specified name is not \"GListData\". : " + name);
			}
		}
		else {
			return null;
		}
	}

	/**
	 * 指定された名前で格納されている<code>long</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Long#parseLong(String)}された値が返されます。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#longValue()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>long</code>値
	 * @throws ClassCastException 該当する値が{@link long}値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Long getLong(String name) throws ClassCastException {
		Object value = _datas.get(name);
		return GConvertUtils.toLong(value);
	}

	/**
	 * 指定された名前で格納されている<code>short</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Short#parseShort(String)}された値が返されます。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#shortValue()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>short</code>値
	 * @throws ClassCastException 該当する値が<code>short</code>値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Short getShort(String name) throws ClassCastException {
		Object value = _datas.get(name);
		return GConvertUtils.toShort(value);
	}

	/**
	 * 指定した名前で格納されている文字列を取得します.<br>
	 * 格納されている値の型が{@link String}型以外の場合は、{@link Object#toString()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return 文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getString(String name) {
		Object value = _datas.get(name);
		if (value != null) {
			return value.toString();
		}
		else {
			return null;
		}
	}

	/**
	 * 指定した名前で格納されている結果オブジェクトを削除します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void removeData(String name) {
		_datas.remove(name);
	}

	/**
	 * 格納されているチェックエラーリスト内で指定された要素が最初に検出されたとき、その要素を削除します.<br>
	 * リストにその要素がない場合は、変更されません。
	 * 
	 * @create 2006/12/18
	 * @param error チェックエラー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void removeError(GValidateError error) {
		_validateErrors.remove(error);
	}

	/**
	 * 格納されているチェックエラーリスト内の指定された位置にある要素を削除します.<br>
	 * 後続の要素は左に移動します (インデックス値から 1 を減算)。
	 * 
	 * @create 2006/12/18
	 * @param index インデックス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void removeError(int index) {
		_validateErrors.remove(index);
	}

	/**
	 * 格納されているチェックエラーリスト内において、指定されたコレクション内にある各要素が
	 * 最初に検出されたとき、その要素を削除します.
	 * 
	 * @create 2006/12/18
	 * @param errors チェックエラーリスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void removeErrors(List<GValidateError> errors) {
		_validateErrors.removeAll(errors);
	}

	/**
	 * 指定した名前で結果オブジェクトを格納します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @param value 結果オブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setData(String name, Object value) {
		_datas.put(name, value);
	}

	/**
	 * ダウンロードファイルを設定します.
	 * 
	 * @create 2007/01/29
	 * @param downloadFile ダウンロードファイル
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setDownloadFile(GDownloadFile downloadFile) {
		_downloadFile = downloadFile;
	}

	/**
	 * 格納されているチェックエラーリスト内の指定された位置にある要素を、指定された要素に置き換えます。.
	 * 
	 * @create 2006/12/18
	 * @param index インデックス
	 * @param error チェックエラー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setError(int index, GValidateError error) {
		_validateErrors.set(index, error);
	}

	/**
	 * チェックエラーリストを設定します.
	 * 
	 * @create 2006/12/18
	 * @param errors チェックエラーリスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setErrors(List<GValidateError> errors) {
		_validateErrors = errors;
	}

	/**
	 * 終了コードを設定します.
	 * 
	 * @create 2006/12/16
	 * @param code 終了コード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setExitCode(String code) {
		_exitCode = code;
	}
	
	/**
	 * {@link Throwable}を設定します.<br>
	 * 
	 * @create 2023/10/25
	 * @return {@link Throwable}値
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setException(Throwable throwable) {
		_throwable = throwable;
	}

	/**
	 * {@link GResultData}の実装クラスを生成するファクトリです。
	 * 
	 * @create 2009/07/23
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static class Factory {
		
		/**
		 * {@link GResultData}インターフェースの実装クラスを生成します。
		 * 
		 * @create 2009/07/23
		 * @return {@link GResultData}インターフェースの実装クラス
		 * @author kitamura
		 * @since 3.6.0
		 */
		public static GResultData create() {
			return GFrameworkUtils.getComponent(GResultData.class.getName());
		}
		
		/**
		 * 終了コードを指定して、{@link GResultData}インターフェースの実装クラスを生成します。
		 * 
		 * @create 2009/07/23
		 * @param exitCode 終了コード
		 * @return {@link GResultData}インターフェースの実装クラス
		 * @author kitamura
		 * @since 3.6.0
		 */
		public static GResultData create(String exitCode) {
			GResultData resultData = create();
			resultData.setExitCode(exitCode);
			return resultData;
		}
		
		/**
		 * インスタンス化させません。
		 * 
		 * @create 2009/07/23
		 * @auther kitamura
		 * @since 3.6.0
		 */
		private Factory() {
		}
	}
}