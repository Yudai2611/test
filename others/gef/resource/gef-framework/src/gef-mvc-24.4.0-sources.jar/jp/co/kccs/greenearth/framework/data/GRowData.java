/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import jp.co.kccs.greenearth.framework.utils.GConvertUtils;

/**
 * {@link GListData}に格納できる行を表します.<br>
 * この行を構成する各セルを表すデータ要素には主に以下のような情報を設定することができます。<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>積み込めるクラス</td><td>データが持つ意味</td></tr>
 * <tr><td>{@link Byte}</td><td>8bit整数型のデータ</td></tr>
 * <tr><td>{@link Short}</td><td>16bit整数型のデータ</td></tr>
 * <tr><td>{@link Integer}</td><td>32bit整数型のデータ</td></tr>
 * <tr><td>{@link Long}</td><td>64bit整数型のデータ</td></tr>
 * <tr><td>{@link Float}</td><td>32bit浮動小数点数型のデータ</td></tr>
 * <tr><td>{@link Double}</td><td>64bit浮動小数点数型のデータ</td></tr>
 * <tr><td><code>boolean</code></td><td>真偽値型のデータ</td></tr>
 * <tr><td>{@link String}</td><td>文字列型のデータ</td></tr>
 * <tr><td>{@link BigInteger}</td><td>任意精度の整数型のデータ</td></tr>
 * <tr><td>{@link BigDecimal}</td><td>任意精度の符号付き 10 進数のデータ</td></tr>
 * <tr><td>{@link Date}</td><td>日付型のデータ</td></tr>
 * </table>
 * 
 * @see jp.co.kccs.greenearth.framework.data.GListData
 * @create 2007/01/21
 * @author kitamura
 * @since 3.0.0
 */
public class GRowData implements Serializable{

	/** シリアルバージョンID */
	private static final long serialVersionUID = -9041839270102405163L;
	
	/** セルデータマップ. */
	private Map<String, Object> _cells = new HashMap<String, Object>();

	/**
	 * {@link GRowData}インスタンスを初期化します.
	 * 
	 * @create 2007/01/21
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GRowData() {
	}

	/**
	 * 格納されているセルデータを全てをクリアします.
	 * 
	 * @create 2006/12/16
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void clear() {
		_cells.clear();
	}

	/**
	 * 指定した名前の項目を保持する場合に<code>true</code>を返します.
	 * 
	 * @create 2006/12/26
	 * @param name 名前
	 * @return true/false
	 * @author shimano
	 * @since 3.0.0
	 */
	public boolean containsName(String name) {
		return _cells.containsKey(name);
	}

	/**
	 * 指定した名前で格納されているセルデータを取得します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return セルデータ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object getData(String name) {
		return _cells.get(name);
	}

	/**
	 * 指定された名前で格納されている{@link BigDecimal}値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link BigDecimal}として作り直されて返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return {@link BigDecimal}値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public BigDecimal getBigDecimal(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toBigDecimal(value);
	}

	/**
	 * 指定された名前で格納されている{@link BigInteger}値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link BigInteger}として作り直されて返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return {@link BigInteger}値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public BigInteger getBigInteger(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toBigInteger(value);
	}

	/**
	 * 指定された名前で格納されている<code>boolean</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、{@link Boolean#parseBoolean(String)}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>boolean</code>値
	 * @throws ClassCastException 該当する値が<code>boolean</code>値として認識できなかった場合
	 * @throws IllegalArgumentException 該当する値が<code>null</code>の場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean getBoolean(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toBoolean(value);
	}

	/**
	 * 指定された名前で格納されている<code>Byte</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、数値（{@link Byte}）に変換した値を返します。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#byteValue()}した値を格納したラッパー型インスタンスを返します。<br>
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>Byte</code>値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Byte getByte(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toByte(value);
	}

	/**
	 * セルデータマップを取得します.
	 * 
	 * @create 2007/01/21
	 * @return セルデータマップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Map<String, Object> getCells() {
		return _cells;
	}

	/**
	 * 指定された名前で格納されている{@link Date}値を取得します.<br>
	 * 
	 * 格納されている値の型が{@link Date}型の場合は、引数と同一のインスタンスを返します。<br>
	 * 格納されている値の型が{@link Calendar}型の場合は、{@link Date}インスタンスを返します。<br>
	 * 格納されている値の型が{@link String}型の場合は、<code>ge-framework.property</code>ファイルで定義された
	 * フォーマット文字列を元に、{@link Date}インスタンスを生成して返します。<br>
	 * 格納されている値が<code>null</code>又は空文字の場合は、<code>null</code>を返します。<br>
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>Date</code>値
	 * @throws ClassCastException {@link Date}型に変換できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Date getDate(String name) throws ClassCastException {
		Object value = _cells.get(name);
		return GConvertUtils.toDate(value);
	}

	/**
	 * 指定された名前で格納されている<code>Double</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、数値（{@link Double}）に変換した値を返します。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#doubleValue()}した値を格納したラッパー型インスタンスを返します。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>Double</code>値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Double getDouble(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toDouble(value);
	}

	/**
	 * 指定された名前で格納されている<code>Float</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、数値（{@link Float}）に変換した値を返します。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#floatValue()}した値を格納したラッパー型インスタンスを返します。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>Float</code>値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Float getFloat(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toFloat(value);
	}

	/**
	 * 指定された名前で格納されている<code>Integer</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、数値（{@link Integer}）に変換した値を返します。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#intValue()}した値を格納したラッパー型インスタンスを返します。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>Integer</code>値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Integer getInteger(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toInteger(value);
	}

	/**
	 * 指定された名前で格納されている<code>Long</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、数値（{@link Long}）に変換した値を返します。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#longValue()}した値を格納したラッパー型インスタンスを返します。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>Long</code>値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Long getLong(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toLong(value);
	}

	/**
	 * 指定された名前で格納されている<code>Short</code>値を取得します.<br>
	 * 格納されている値の型が{@link String}型の場合は、数値{@link Short}に変換した値を返します。<br>
	 * 格納されている値の型が{@link Number}型の場合は、{@link Number#shortValue()}された値を格納したラッパー型インスタンスを返します。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return <code>Short</code>値
	 * @throws ClassCastException {@link String}型,{@link Number}型以外の型の値が格納されていた場合
	 * @throws IllegalArgumentException  該当する値が数値として認識できなかった場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Short getShort(String name) throws ClassCastException, IllegalArgumentException {
		Object value = _cells.get(name);
		return GConvertUtils.toShort(value);
	}

	/**
	 * 指定した名前で格納されている文字列を取得します.<br>
	 * 格納されている値の型が{@link String}型以外の場合は、{@link Object#toString()}された値が返されます。
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @return 文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getString(String name) {
		Object value = _cells.get(name);
		if (value != null) {
			return value.toString();
		}
		else {
			return null;
		}
	}

	/**
	 * セルデータマップに格納されている名前のセットビューを返します.
	 * 
	 * @create 2007/01/21
	 * @return 名前のセットビュー
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Set<String> nameSet() {
		return _cells.keySet();
	}

	/**
	 * 指定した名前で格納されているセルを削除します.
	 * 
	 * @create 2006/12/16
	 * @param name 名前
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void remove(String name) {
		_cells.remove(name);
	}

	/**
	 * 指定した名前でセルデータを設定します.
	 * 
	 * @create 2007/01/21
	 * @param name セル名
	 * @param value 値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setData(String name, Object value) {
		_cells.put(name, value);
	}

	/**
	 * 列のサイズを取得します.
	 * 
	 * @create 2006/12/16
	 * @return サイズ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public int size() {
		return _cells.size();
	}
}
