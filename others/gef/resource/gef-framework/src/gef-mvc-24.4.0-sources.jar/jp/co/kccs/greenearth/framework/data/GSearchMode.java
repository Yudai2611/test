/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

/**
 * 検索モードを示すクラス。GSearchModeへの転換機能を提供する</br>
 *
 * @create 2021/09/30
 * @author KCSS
 * @since 21.9.0
 */
public class GSearchMode {
	private String _value;
	private InternalSearchMode _internalSearchMode;

	/**
	 * コンストラクタ</br>
	 * valueからInternalSearchModeに転換する一方、value値も保持する</br>
	 */
	private GSearchMode(String value) {
		this._internalSearchMode = InternalSearchMode.convert(value);
		this._value = value;
	}

	/**
	 * 規定値でGSearchModeのインスタンス作成</br>
	 *   規定値：</br>
	 *     "first"</br>
	 *     "previous:</br>
	 *     "next"</br>
	 *     "last"</br>
	 *     ページ番号（数字の文字列）</br>
	 * </br>
	 * @param value
	 * @return GSearchMode
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public static GSearchMode create(String value) {
		return new GSearchMode(value);
	}

	/**
	 * 初期化時の使った値を保持する
	 * @return
	 */
	public String getValue() {
		return _value;
	}

	protected InternalSearchMode getInternalSearchMode() {
		return _internalSearchMode;
	}

	/**
	 * GSearchMode内部用検索モードの列挙型</br>
	 */
	protected enum InternalSearchMode {
		SEARCH_MODE_FIRST(GPagingNavigator.MODE_FIRST),
		SEARCH_MODE_LAST(GPagingNavigator.MODE_LAST),
		SEARCH_MODE_NEXT(GPagingNavigator.MODE_NEXT),
		SEARCH_MODE_PREVIOUS(GPagingNavigator.MODE_PREVIOUS),
		SEARCH_MODE_PAGENO("_@pageno@_"),
		SEARCH_MODE_DEFAULT("");
		private String _value = null;
		InternalSearchMode(final String value) {
			this._value = value;
		}

		/**
		 * 規定値からInternalSearchModeに転換</br>
		 *   転換ルール：
		 *     "first" ==> SEARCH_MODE_FIRST</br>
		 *     "previous: ==> SEARCH_MODE_PREVIOUS</br>
		 *     "next" ==> SEARCH_MODE_NEXT</br>
		 *     "last" ==> SEARCH_MODE_LAST</br>
		 *     ページ番号（数字の文字列） ==> SEARCH_MODE_PAGENO</br>
		 *     以外 ==> SEARCH_MODE_DEFAULT</br>
		 * @param value
		 * @return InternalSearchMode
		 * @create 2021/09/30
		 * @author KCSS
		 * @since 21.9.0
		 */
		public static InternalSearchMode convert(final String value) {
			if (isInteger(value)) {
				return SEARCH_MODE_PAGENO;
			}

			// 既存アプリ側は、"NEXT"、"PREV"を使っている可能性を考えて、暫定対応追加
			// 今後GPagingNavigator.DESTPAGE_PREVとGPagingNavigator.DESTPAGE_NEXTの削除と共に以下処理も削除する
			if (GPagingNavigator.DESTPAGE_PREV.equals(value)) {
				return SEARCH_MODE_PREVIOUS;
			} else if (GPagingNavigator.DESTPAGE_NEXT.equals(value)) {
				return SEARCH_MODE_NEXT;
			}

			for (InternalSearchMode type : InternalSearchMode.values()) {
				if (type._value.equals(value)) {
					return type;
				}
			}
			return SEARCH_MODE_DEFAULT;
		}

		private static boolean isInteger(String str) {
			try {
				Integer.parseInt(str);
			} catch (NumberFormatException e) {
				return false;
			}
			return true;
		}
	}
}
