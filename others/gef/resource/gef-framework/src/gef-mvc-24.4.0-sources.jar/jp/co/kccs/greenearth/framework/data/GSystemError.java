/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.time.OffsetDateTime;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * システム例外を表すクラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GSystemError {

	/** スタックトレース表示プロパティキー名*/
	private static final String SYSTEMERROR_ENABLESTACKTRACE_KEY = "geframe.mvc.response.error.StackTrace.Enable.Default";
	/** スタックトレース表示デフォルト */
	private static final Boolean DEFAULT_ENABLE = Boolean.FALSE;
	/** タイムスタンプ */
	private OffsetDateTime _timeStamp;
	/** Httpステータスコード */
	private Optional<Integer> _statusCode = Optional.empty();
	/** Httpステータスメッセージ */
	private Optional<String> _message = Optional.empty();
	/** Throwableメッセージ */
	private String _description;
	/** スタックトレース */
	private StackTraceElement[] _stackTrace;
	/** スタックトレース出力 */
	private Optional<Boolean> enableStackTrace = Optional.empty();

	protected GSystemError() {}

	protected GSystemError(Throwable cause) {
		this._description = GStringUtils.isNullOrEmpty(cause.getMessage()) ? null : cause.getMessage();
		this._stackTrace = cause.getStackTrace().length == 0 ? null : cause.getStackTrace();
	}
	
	/**
	 * {@link GSystemError}のインスタンスを生成します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GSystemError}のインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static GSystemError create() {
		return new GSystemError();
	}

	/**
	 * {@link GSystemError}のインスタンスを生成します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param cause 例外
	 * @return
	 * @return {@link GSystemError}のインスタンス
	 * @since 23.10.0
	 */
	public static GSystemError create(Throwable cause) {
		return new GSystemError(cause);
	}

	/**
	 * タイムスタンプを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return タイムスタンプ
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public OffsetDateTime getTimeStamp() {
		return this._timeStamp;
	}

	/**
	 * ステータスコードを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return ステータスコード
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public Optional<Integer> getStatusCode() {
		return this._statusCode;
	}

	/**
	 * メッセージを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return メッセージ
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public Optional<String> getMessage() {
		return this._message;
	}

	/**
	 * 詳細を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return 詳細
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public String getDescription() {
		return this._description;
	}

	/**
	 * スタックトレースを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return スタックトレース
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public StackTraceElement[] getStackTrace() {
		return this._stackTrace;
	}
	
	/**
	 * スタックトレースの利用可否を判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return true: 利用可能 / false: 利用不可
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public Boolean isEnableStackTrace() {
		return this.enableStackTrace.orElseGet(() -> {
			String value = GFrameworkUtils.getProperty(SYSTEMERROR_ENABLESTACKTRACE_KEY, DEFAULT_ENABLE.toString());
			return Boolean.valueOf(GStringUtils.isNullOrEmpty(value) ? DEFAULT_ENABLE.toString() : value);
		});
	}
	
	/**
	 * タイムスタンプを設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param timestamp タイムスタンプ
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setTimeStamp(OffsetDateTime timestamp) {
		this._timeStamp = timestamp;
	}

	/**
	 * ステータスコードを設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param statusCode ステータスコード
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setStatusCode(int statusCode) {
		this._statusCode = Optional.of(statusCode);
	}

	/**
	 * メッセージを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param message メッセージ
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setMessage(String message) {
		this._message = Optional.ofNullable(message);
	}

	/**
	 * 詳細を設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param description 詳細
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setDescription(String description) {
		this._description = description;
	}

	/**
	 * スタックトレースを設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param stackTrace
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setStackTrace(StackTraceElement[] stackTrace) {
		this._stackTrace = stackTrace;
	}
	
	/**
	 * スタックトレースの有効可否を設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param 利用可否(true: 利用可能 / false: 利用不可)
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public void setEnableStackTrace(boolean enable) {
		this.enableStackTrace = Optional.of(Boolean.valueOf(enable));
	}
}
