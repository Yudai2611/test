/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;

/**
 * 入力検証エラー情報を表します.
 * 
 * @create 2007/02/28
 * @author kitamura
 * @since 3.0.0
 */
public class GValidateError implements Serializable{

	/** シリアルバージョンID */
	private static final long serialVersionUID = -4656755666599860024L;
	/** エラーコード. */
	private String _code = null;
	/** エラー詳細. */
	private String _description = null;
	/** エラー項目id. */
	private List<String> _fieldIds = new ArrayList<String>();
	/** エラー項目名. */
	private String _label = null;
	/** エラー項目の空間名. */
	private String _labelspace = null;
	/** メッセージ. */
	private String _message = null;
	/** エラータイプ. */
	private GErrorType _type = null;

	/**
	 * {@link GValidateError}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError() {
	}

	/**
	 * {@link GErrorMessage}を指定して{@link GValidateError}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param errormessage エラーメッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError(GErrorMessage errormessage) {
		_code = errormessage.getCode();
		_message = errormessage.getMessage();
		_type = errormessage.getType();
	}

	/**
	 * エラーコードを指定して{@link GValidateError}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param errorCode エラーコード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError(String errorCode) {
		_code = errorCode;
	}

	/**
	 * エラーコード、メッセージを指定して{@link GValidateError}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError(String errorCode, String message) {
		_code = errorCode;
		_message = message;
	}

	/**
	 * エラーコード、メッセージ、エラータイプを指定して{@link GValidateError}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError(String errorCode, String message, GErrorType type) {
		_code = errorCode;
		_message = message;
		_type = type;
	}

	/**
	 * エラーコード、メッセージ、エラータイプを指定して{@link GValidateError}インスタンスを初期化します.
	 * 
	 * @create 2007/02/28
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @param description エラー詳細
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError(String errorCode, String message, GErrorType type, String description) {
		_code = errorCode;
		_message = message;
		_type = type;
		_description = description;
	}

	/**
	 * エラー項目idを追加します.
	 * 
	 * @create 2007/04/06
	 * @param id エラー項目id
	 * @author namazue
	 * @since 3.0.0
	 */
	public void addFieldId(String id) {
		_fieldIds.add(id);
	}

	/**
	 * エラーコードを取得する.
	 * 
	 * @create 2007/02/28
	 * @return エラーコード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getCode() {
		return _code;
	}

	//	 ---- パブリックプロパティ ---------------------------------------------

	/**
	 * エラー名を取得する.
	 * 
	 * @create 2007/02/28
	 * @return エラー名
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getDescription() {
		return _description;
	}

	/**
	 * 指定した位置にあるエラー項目idを取得します.
	 * 
	 * @create 2007/04/06
	 * @param index インデックス
	 * @return エラー項目id
	 * @author namazue
	 * @since 3.0.0
	 */
	public String getFieldId(int index) {
		return _fieldIds.get(index);
	}

	/**
	 * エラー項目のidの一覧を取得します.
	 * 
	 * @create 2007/04/05
	 * @return エラー項目のid一覧
	 * @author namazue
	 * @since 3.0.0
	 */
	public List<String> getFieldIdList() {
		return _fieldIds;
	}

	/**
	 * エラー項目名を取得します.
	 * 
	 * @create 2007/04/05
	 * @return エラー項目名
	 * @author namazue
	 * @since 3.0.0
	 */
	public String getLabel() {
		return _label;
	}

	/**
	 * エラー項目の表示名の名前空間を取得します.
	 * 
	 * @create 2007/04/18
	 * @return 表示名の名前空間
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getLabelspace() {
		return _labelspace;
	}

	/**
	 * メッセージを取得する.
	 * 
	 * @create 2007/02/28
	 * @return メッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getMessage() {
		return _message;
	}

	/**
	 * エラータイプを取得する.
	 * 
	 * @create 2007/03/27
	 * @return エラータイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public GErrorType getType() {
		return _type;
	}

	/**
	 * エラーコードを設定する.
	 * 
	 * @create 2007/02/28
	 * @param code エラーコード
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setCode(String code) {
		_code = code;
	}

	/**
	 * エラー名を設定する.
	 * 
	 * @create 2007/02/28
	 * @param description エラーのdescription値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setDescription(String description) {
		_description = description;
	}

	/**
	 * エラー項目のidを設定します.
	 * 
	 * @create 2007/04/05
	 * @param ids エラー項目のid
	 * @author namazue
	 * @since 3.0.0
	 */
	public void setFieldIdList(List<String> ids) {
		this._fieldIds = ids;
	}

	/**
	 * エラー項目名を設定します.
	 * 
	 * @create 2007/04/05
	 * @param label エラー項目名
	 * @author namazue
	 * @since 3.0.0
	 */
	public void setLabel(String label) {
		this._label = label;
	}

	/**
	 * エラー項目の表示名の名前空間を設定します.
	 * 
	 * @create 2007/04/18
	 * @param labelspace 表示名の名前空間
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setLabelspace(String labelspace) {
		_labelspace = labelspace;
	}

	/**
	 * メッセージを設定する.
	 * 
	 * @create 2007/02/28
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setMessage(String message) {
		_message = message;
	}

	/**
	 * エラータイプを設定する.
	 * 
	 * @create 2007/03/27
	 * @param type エラータイプ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public void setType(GErrorType type) {
		_type = type;
	}
}
