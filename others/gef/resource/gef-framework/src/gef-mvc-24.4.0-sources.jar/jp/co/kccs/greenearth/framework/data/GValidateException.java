/*
 * Copyright 2007-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.data;

import java.util.ArrayList;
import java.util.List;

/**
 * ユーザ入力値検証時の例外を表すクラスです.
 * 
 * @create 2007/02/16
 * @author aono
 * @since 3.0.0
 */
public class GValidateException extends Exception {

	/** シリアルバージョンID. */
	private static final long serialVersionUID = 593932982547008637L;

	/** 検証時に発生したエラーの情報. */
	private List<GValidateError> validateErrors = new ArrayList<GValidateError>();

	/**
	 * 新規例外を構築します.
	 * 
	 * @create 2006/11/28
	 * @author aono
	 * @since 3.0.0
	 */
	public GValidateException() {
	}

	/**
	 * エラー情報を設定したインスタンスを生成します.
	 * 
	 * @create 2007/02/16
	 * @param error エラー情報
	 * @author aono
	 * @since 3.0.0
	 */
	public GValidateException(GValidateError error) {
		addValidateError(error);
	}

	/**
	 * エラーメッセージを設定してインスタンスを生成します.
	 * 
	 * @create 2007/02/16
	 * @param message エラーメッセージ
	 * @author aono
	 * @since 3.0.0
	 */
	public GValidateException(String message) {
		super(message);
	}
	
	/**
	 * エラー情報リストを指定してインスタンスを生成します.
	 * 
	 * @create 2011/03/31
	 * @param errors エラー情報リスト
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GValidateException(List<GValidateError> errors) {
		addValidateErrors(errors);
	}

	/**
	 * エラー情報を追加します.
	 * 
	 * @create 2007/02/16
	 * @param error エラー情報
	 * @author aono
	 * @since 3.0.0
	 */
	public void addValidateError(GValidateError error) {
		validateErrors.add(error);
	}

	/**
	 * エラー情報を指定された位置に追加します.
	 * 
	 * @create 2007/02/16
	 * @param index 挿入位置
	 * @param error エラー情報
	 * @author aono
	 * @since 3.0.0
	 */
	public void addValidateError(int index, GValidateError error) {
		validateErrors.add(index, error);
	}

	/**
	 * エラー情報を一括追加します.
	 * 
	 * @create 2007/02/16
	 * @param errors エラー情報
	 * @author aono
	 * @since 3.0.0
	 */
	public void addValidateErrors(List<GValidateError> errors) {
		validateErrors.addAll(errors);
	}

	/**
	 * エラー情報をクリアします.
	 * 
	 * @create 2007/02/16
	 * @author aono
	 * @since 3.0.0
	 */
	public void clear() {
		validateErrors.clear();
	}

	/**
	 * 指定したインデックスにあるエラー情報を取得します.
	 * 
	 * @create 2007/05/03
	 * @param index インデックス
	 * @return エラー情報
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GValidateError getValidateError(int index) {
		return validateErrors.get(index);
	}

	/**
	 * エラー情報の一覧を取得します.
	 * 
	 * @create 2007/02/16
	 * @return エラー情報一覧
	 * @author aono
	 * @since 3.0.0
	 */
	public List<GValidateError> getValidateErrors() {
		return validateErrors;
	}

	/**
	 * 指定されたエラー情報を削除します.
	 * 
	 * @create 2007/02/16
	 * @param error 削除対象
	 * @author aono
	 * @since 3.0.0
	 */
	public void removeValidateError(GValidateError error) {
		validateErrors.remove(error);
	}

	/**
	 * 指定されたエラー情報を一括削除します.
	 * 
	 * @create 2007/02/16
	 * @param errors エラー情報
	 * @author aono
	 * @since 3.0.0
	 */
	public void removeValidateErrors(List<GValidateError> errors) {
		validateErrors.removeAll(errors);
	}
}
