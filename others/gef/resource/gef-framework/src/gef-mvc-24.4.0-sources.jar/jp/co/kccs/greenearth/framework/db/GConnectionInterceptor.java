/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.db;

import java.sql.Connection;

import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.framework.action.GActionInterceptor;

import org.aopalliance.intercept.MethodInvocation;

/**
 * コネクションの接続と解放を自動化するアクションインターセプターです. <br>
 * アクションメソッド開始前に接続の確立を行います。<br>
 * 正常、異常問わず、アクションメソッドが終了した場合に接続を解放します。<br>
 * <br>
 * {@link GConnectionInterceptor}には接続対象となるデータソースを
 * {@link Validatefull}アノテーションのparams属性にて指定できます。<br>
 * インターセプターの指定方法は以下のようになります。<br>
 * 
 * <li>メインデータソースの場合</li>
 * <pre>
 * 　&#064;ActionInterceptors({<b>@ActionInterceptor(GConnectionInterceptor.class)</b>})
 * 　public GResultData doUpdate(GParameter parameter) {}
 * </pre>
 * <li>データソースを指定する場合</li>
 * <pre>
 * 　&#064;ActionInterceptors({
 * 　　　<b>@ActionInterceptor(value=GConnectionInterceptor.class,params={"データソース名"})</b>
 * 　})
 * 　public GResultData doUpdate(GParameter parameter) {}
 * </pre>
 * 
 * @see jp.co.kccs.greenearth.framework.action.GActionInterceptor
 * @see org.aopalliance.intercept.MethodInterceptor
 * @create 2007/01/01
 * @author kitamura
 * @since 3.0.0
 */
public class GConnectionInterceptor implements GActionInterceptor {

	/** パラメータ. */
	private String[] _parameters = null;
	
	/**
	 * {@link GConnectionInterceptor}インスタンスを初期化します。
	 * 
	 * @create 2009/07/23
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GConnectionInterceptor() {
	}

	/**
	 * アクションメソッドをインターセプトし、コネクションの接続と解放を行います.
	 * 
	 * @see MethodInterceptor#invoke(org.aopalliance.intercept.MethodInvocation)
	 * @create 2007/01/01
	 * @param invocation インターセプトしたメソッド情報
	 * @return インターセプトメソッドの処理結果
	 * @throws Throwable インターセプトメソッド内部で例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object invoke(MethodInvocation invocation) throws Throwable {
		String[] parameters = getParameters();
		String dataSourceName = null;
		if (parameters.length >= 1) {
			dataSourceName = parameters[0];
		}

		GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
		Connection connection = null;
		try {
			if (dataSourceName == null) {
				connection = ds.open();
			}
			else {
				connection = ds.open(dataSourceName);
			}

			Object result = invocation.proceed();
			return result;
		}
		finally {
			ds.close(connection);
		}
	}

	/**
	 * {@link ActionIntersepter}アノテーションにて指定されたパラメータ配列を取得します.
	 * 
	 * @create 2007/01/02
	 * @return 文字列パラメータ配列
	 * @see GActionInterceptor#getParameters()
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String[] getParameters() {
		return _parameters;
	}

	/**
	 * パラメータ配列を設定します.
	 * 
	 * @create 2007/01/02
	 * @param parameters 文字列パラメータ配列
	 * @see GActionInterceptor#setParameters(String[])
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setParameters(String[] parameters) {
		_parameters = parameters;
	}
}
