/*
 * Copyright 2007-2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.db;

import java.sql.Connection;

import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.framework.action.GActionInterceptor;
import jp.co.kccs.greenearth.framework.data.GResultData;

import org.aopalliance.intercept.MethodInvocation;

/**
 * トランザクション処理を自動化するアクションインターセプターです. <br>
 * アクションメソッド開始前に接続の確立、トランザクションの開始を行います。<br>
 * アクションメソッドが正常終了した場合、トランザクションをコミットし、接続を解放します。<br>
 * アクションメソッドが異常終了（例外発生）した場合、トランザクションをロールバックし、
 * 接続を解放します。<br>
 * <br>
 * {@link GTransactionInterceptor}にはトランザクション対象とするデータソースを
 * {@link Validatefull}アノテーションのparams属性にて指定できます。<br>
 * インターセプターの指定方法は以下のようになります。<br>
 * 
 * <li>メインデータソースの場合</li>
 * <pre>
 * 　&#064;ActionInterceptors({<b>@ActionInterceptor(GTransactionInterceptor.class)</b>})
 * 　public GResultData doUpdate(GParameter parameter) {}
 * </pre>
 * <li>データソースを指定する場合</li>
 * <pre>
 * 　&#064;ActionInterceptors({
 * 　　　<b>@ActionInterceptor(value=GTransactionInterceptor.class,params={"データソース名"})</b>
 * 　})
 * 　public GResultData doUpdate(GParameter parameter) {}
 * </pre>
 * 
 * @see jp.co.kccs.greenearth.framework.action.GActionInterceptor
 * @see org.aopalliance.intercept.MethodInterceptor
 * @create 2007/01/01
 * @author kitamura
 * @since 3.0.0
 */
public class GTransactionInterceptor implements GActionInterceptor {

	/** パラメータ. */
	private String[] _parameters = null;
	
	/**
	 * {@link GTransactionInterceptor}インスタンスを初期化します。
	 * 
	 * @create 2009/07/23
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GTransactionInterceptor() {
	}

	/**
	 * アクションメソッドをインターセプトし、トランザクション処理を実行しています.
	 * 
	 * @see MethodInterceptor#invoke(org.aopalliance.intercept.MethodInvocation)
	 * @create 2007/01/01
	 * @param invocation インターセプトしたメソッド情報
	 * @return インターセプトメソッドの処理結果
	 * @throws Throwable インターセプトメソッド内部で例外が発生した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object invoke(MethodInvocation invocation) throws Throwable {
		String[] parameters = getParameters();
		String dataSourceName = null;
		if (parameters.length >= 1) {
			dataSourceName = parameters[0];
		}

		GConnectionManager manager = GConnectionManager.getInstance();
		Connection connection = null;
		try {
			if (dataSourceName == null) {
				connection = manager.catchConnection();
			}
			else {
				connection = manager.catchConnection(dataSourceName);
			}
			manager.beginTransaction(connection);

			GResultData result = (GResultData) invocation.proceed();
			if (GResultData.EXIT_CODE_VALIDATE_ERROR.equals(result.getExitCode())) {
				// TODO [2007/03/04][kitamura] validate-errorの場合のテストが未実施
				// そもそもvalidate-errorの場合ロールバックしていい？エラーでもコミットしたい場合はない？
				manager.rollbackTransaction(connection);
			}
			else {
				manager.commitTransaction(connection);
			}

			return result;
		}
		catch (Throwable e) {
			manager.rollbackTransaction(connection);
			throw e;
		}
		finally {
			manager.releaseConnection(connection);
		}
	}

	/**
	 * {@link ActionIntersepter}アノテーションにて指定されたパラメータ配列を取得します.
	 * 
	 * @create 2007/01/02
	 * @return 文字列パラメータ配列
	 * @see GActionInterceptor#getParameters()
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String[] getParameters() {
		return _parameters;
	}

	/**
	 * パラメータ配列を設定します.
	 * 
	 * @create 2007/01/02
	 * @param parameters 文字列パラメータ配列
	 * @see GActionInterceptor#setParameters(String[])
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setParameters(String[] parameters) {
		_parameters = parameters;
	}
}
