/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.util.Date;

/**
 * EnterpriseManagerV3用に{@link GMenu}を拡張したインタフェースです。
 * 
 * @create 2011/05/11
 * @author KCCS kitamura
 * @since 3.9.0
 */
public interface GEditableMenu extends GMenu {
	
	/**
	 * 親メニューのオブジェクトIDを設定します。
	 * 
	 * @param parentID 親メニューオブジェクトID
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setParentObjectID(String parentID);
	
	/**
	 * 親メニューオブジェクトIDを取得します。
	 * 
	 * @return 親メニューオブジェクトID
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	String getParentObjectID();

	/**
	 * 表示名リソースIDを設定します。
	 * 
	 * @param displayNameResourceID 表示名リソースID
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setDisplayNameResourceID(String displayNameResourceID);
	
	/**
	 * 表示名リソースIDを取得します。
	 * 
	 * @return 表示名リソースID
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since
	 */
	String getDisplayNameResourceID();
	
	/**
	 * ロールオブジェクトIDを設定します。
	 * 
	 * @param roleID ロールID
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setRoleObjectID(String roleID);
	
	/**
	 * ロールオブジェクトIDを取得します。
	 * 
	 * @return ロールオブジェクトID
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	String getRoleObjectID();

	/**
	 * 備考を設定します。
	 * 
	 * @param description 備考
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setDescription(String description);
	
	/**
	 * 備考を取得します
	 * 
	 * @return 備考
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	String getDescription();

	/**
	 * ソート順を設定します。
	 * 
	 * @param sortIndex ソート順
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setSortIndex(int sortIndex);
	
	/**
	 * ソート順を取得します。
	 * 
	 * @return ソート順
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	int getSortIndex();

	/**
	 * 更新日を設定します。
	 * 
	 * @param updatedDate 更新日
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setUpdatedDate(Date updatedDate);
	
	/**
	 * 更新日を取得します。
	 * 
	 * @return 更新日
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	Date getUpdatedDate();

	/**
	 * 更新者を設定します。
	 * 
	 * @param updatedPerson 更新者
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setUpdatedPerson(String updatedPerson);
	
	/**
	 * 更新日を取得します。
	 * 
	 * @return 更新日
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	String getUpdatedPerson();

	/**
	 * 排他キーを設定します。
	 * 
	 * @param exclusiveKey 排他キー
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	void setExclusiveKey(String exclusiveKey);
	
	/**
	 * 排他キーを取得します。
	 * 
	 * @return 排他キー
	 * @create 2011/05/11
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	String getExclusiveKey();
}
