/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * {@link GMenuDao}を拡張し、EnterpriseManagerV3用に機能を追加したインタフェースです。
 * 
 * @create 2011/07/29
 * @author KCCS nishimura
 * @since 3.9.0
 */
public interface GEditableMenuDao extends GMenuDao {

	/**
	 * メニューを生成します.
	 * 
	 * @return メニュー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableMenu createMenu();

	/**
	 * アイテムのアプリケーションタイプマップを取得します.
	 * 
	 * @param locale 地域コード
	 * @return アプリケーションタイプマップ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getItemAppTypeMap(Locale locale);

	/**
	 * カテゴリのアプリケーションタイプマップを取得します.
	 * 
	 * @param locale 地域コード
	 * @return アプリケーションタイプマップ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getCategoryAppTypeMap(Locale locale);

	/**
	 * アイテムのメニュータイプマップを取得します.
	 * 
	 * @param locale 地域コード
	 * @return メニュータイプマップ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getItemMenuTypeMap(Locale locale);

	/**
	 * カテゴリのメニュータイプマップを取得します.
	 * 
	 * @param locale 地域コード
	 * @return メニュータイプマップ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<String, String> getCategoryMenuTypeMap(Locale locale);

	/**
	 * 引数に指定した条件のメニューを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenuDao#findMenu(java.lang.String)
	 * @param objectID オブジェクトID
	 * @return メニュー
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GEditableMenu findMenu(String objectID) throws GResourceProcessingException;

	/**
	 * メニューを登録します.
	 * 
	 * @param menu メニュー
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @throws GOptimisticLockException 楽観的排他エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void insertMenu(GEditableMenu menu) throws GResourceProcessingException, GOptimisticLockException;

	/**
	 * メニューを更新します.
	 * 
	 * @param menu メニュー
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @throws GOptimisticLockException 楽観的排他エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void updateMenu(GEditableMenu menu) throws GResourceProcessingException, GOptimisticLockException;

	/**
	 * リスト内のメニューを更新します.
	 * 
	 * @param menuList メニューリスト
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @throws GOptimisticLockException 楽観的排他エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void updateMenuList(List<GEditableMenu> menuList) throws GResourceProcessingException, GOptimisticLockException;

	/**
	 * リスト内のメニューを削除します.
	 * 
	 * @param menuList メニューリスト
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @throws GOptimisticLockException 楽観的排他エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void deleteMenuList(List<GEditableMenu> menuList) throws GResourceProcessingException, GOptimisticLockException;

	/**
	 * 引数で指定した会社コードのメニューを全件削除します.
	 * 
	 * @param companyCode 会社コード
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void deleteMenuAll(String companyCode) throws GResourceProcessingException;

	/**
	 * {@link GEditableMenuDao}クラスを生成するファクトリクラスです.
	 * 
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public static class Factory {

		/** Factory. */
		// TODO [2020/08/17][yamashita]アクセスレベル見直し
		public static Factory instance = new Factory();
		
		/**
		 * デフォルトコンストラクタ.
		 * 
		 * @create 2011/09/08
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		// TODO [2020/08/17][yamashita]アクセスレベル見直し
		public Factory() {
		}

		/**
		 * {@link GEditableMenuDao}を返します。
		 * 
		 * @return GEditableMenuDao
		 */
		public GEditableMenuDao getMenuDao() {
			return GFrameworkUtils.getComponent(GMenuDao.class.getName());
		}
		
		/**
		 * {@link GEditableMenuDao}を生成します.
		 * 
		 * @return メニューDao
		 * @create 2011/09/08
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public static GEditableMenuDao getInstance() {
			return instance.getMenuDao();
		}
	}
	
}
