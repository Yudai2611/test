/*
 * Copyright 2013-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.authorization.GRoleDao;

/**
 * {@link GEditableMenuDao}インターフェースの実装クラスです.<br>
 * 
 * @author KCCS Shigeki Shoji
 * @create 2013/07/24
 * @since 3.12.0
 */
public class GEditableMenuDaoImpl extends GEditableMenuNoTxDaoImpl {

	/**
	 * {@link GEditableMenuNoTxDaoImpl}クラスの新しいインスタンスを初期化します.<br>
	 * 
	 * @param roleDao ロールDao
	 * @param categoryAppTypeMap アプリケーションタイプ情報(カテゴリ)
	 * @param itemAppTypeMap アプリケーションタイプ(アイテム)
	 * @param categoryMenuTypeMap メニュータイプ(カテゴリ)
	 * @param itemMenuTypeMap メニュータイプ(アイテム)
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	public GEditableMenuDaoImpl(GRoleDao roleDao, Map<String, String> categoryAppTypeMap,
								Map<String, String> itemAppTypeMap, Map<String, String> categoryMenuTypeMap,
								Map<String, String> itemMenuTypeMap) {
		super(roleDao, categoryAppTypeMap,
				itemAppTypeMap, categoryMenuTypeMap, itemMenuTypeMap);
	}
	
	@Override
	public void insertMenu(GEditableMenu menu) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			insertMenu(menu, connection);

			commitTransaction(connection);
		} catch (GOptimisticLockException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public void updateMenu(GEditableMenu menu) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			updateMenu(menu, connection);

			commitTransaction(connection);
		} catch (GOptimisticLockException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public void updateMenuList(List<GEditableMenu> menuList) throws GResourceProcessingException,
		GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			for (GEditableMenu menu : menuList) {
				updateMenu(menu, connection);
			}

			commitTransaction(connection);
		} catch (GOptimisticLockException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public void deleteMenuList(List<GEditableMenu> menuList) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			beginTransaction(connection);

			for (GEditableMenu role : menuList) {
				deleteMenu(role, connection);
			}

			commitTransaction(connection);
		} catch (GOptimisticLockException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public void deleteMenuAll(String companyCode) throws GResourceProcessingException {
		Connection connection = catchConnection();

		try {
			beginTransaction(connection);

			// GEMenuテーブルの削除
			Map<String, Object> searchParams = new HashMap<String, Object>();
			searchParams.put("companyCode", companyCode);
			delete("GEMenu").where(expMap($("#CompanyCode = :companyCode"), searchParams)).execute(connection);

			// GEMenuLocalizationResourceテーブルの削除
			searchParams = new HashMap<String, Object>();
			searchParams.put("companyCode", companyCode);
			delete(GEMenuLocalizationResource).where(expMap($("#CompanyCode = :companyCode"), searchParams)).execute(connection);

			commitTransaction(connection);
		} catch (SQLException e) {
			rollbackTransaction(connection);
			throw new GResourceProcessingException(e);
		} catch (GResourceProcessingException e) {
			rollbackTransaction(connection);
			throw e;
		} catch (RuntimeException e) {
			rollbackTransaction(connection);
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * 指定されたコネクションのトランザクションを開始します。<br>
	 * 
	 * @param connection コネクション
	 * @throws GResourceProcessingException トランザクション処理中の例外
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	protected void beginTransaction(Connection connection) throws GResourceProcessingException {
		try {
			GConnectionManager connManager = GConnectionManager.getInstance();
			connManager.beginTransaction(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 指定されたコネクションのトランザクションをロールバックします。<br>
	 * 
	 * @param connection コネクション
	 * @throws GResourceProcessingException トランザクション処理中の例外
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	protected void rollbackTransaction(Connection connection) throws GResourceProcessingException {
		try {
			GConnectionManager connManager = GConnectionManager.getInstance();
			connManager.rollbackTransaction(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 指定されたコネクションのトランザクションをコミットします。<br>
	 * 
	 * @param connection コネクション
	 * @throws GResourceProcessingException トランザクション処理中の例外
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	protected void commitTransaction(Connection connection) throws GResourceProcessingException {
		try {
			GConnectionManager connManager = GConnectionManager.getInstance();
			connManager.commitTransaction(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

}
