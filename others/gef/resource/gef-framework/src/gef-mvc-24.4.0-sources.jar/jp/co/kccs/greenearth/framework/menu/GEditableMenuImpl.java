/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.util.Date;

/**
 * {@link GEditableMenu}インターフェースの実装クラスです.
 * 
 * @create 2011/09/08
 * @author KCCS nishimura
 * @since 3.9.0
 */
public class GEditableMenuImpl extends GMenuImpl implements GEditableMenu {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = -4944603735472755776L;
	/** 親メニューID. */
	private String _parentMenuID = null;
	/** ロールID */
	private String _roleID = null;
	/** 備考 */
	private String _description = null;
	/** 順番 */
	private int _sortIndex = -1;
	/** 最終更新日 */
	private Date _updatedDate = null;
	/** 最終更新者 */
	private String _updatedPerson = null;
	/** 排他キー */
	private String _exclusiveKey = null;
	/** 表示名ID */
	private String _displayNameResourceID = null;

	/**
	 * デフォルトコンストラクタ<br>
	 * 
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GEditableMenuImpl() {
	}

	/**
	 * 親メニューのオブジェクトIDを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getParentObjectID()
	 * @return 親メニューオブジェクトID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getParentObjectID() {
		return _parentMenuID;
	}

	/**
	 * 親メニューのオブジェクトIDを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setParentObjectID(java.lang.String)
	 * @param parentMenuID 親メニューオブジェクトID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setParentObjectID(String parentMenuID) {
		_parentMenuID = parentMenuID;
	}

	/**
	 * ロールオブジェクトIDを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getRoleObjectID()
	 * @return ロールオブジェクトID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getRoleObjectID() {
		return _roleID;
	}
	/**
	 * ロールオブジェクトIDを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setRoleObjectID(java.lang.String)
	 * @param roleID ロールオブジェクトID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setRoleObjectID(String roleID) {
		_roleID = roleID;
	}

	/**
	 * 備考を取得します.<<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getDescription()
	 * @return 備考
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getDescription() {
		return _description;
	}

	/**
	 * 備考を設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setDescription(java.lang.String)
	 * @param description 備考
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setDescription(String description) {
		_description = description;
	}

	/**
	 * ソート順を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getSortIndex()
	 * @return ソート順
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public int getSortIndex() {
		return _sortIndex;
	}

	/**
	 * ソート順を設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setSortIndex(int)
	 * @param sortIndex ソート順
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setSortIndex(int sortIndex) {
		_sortIndex = sortIndex;
	}

	/**
	 * 更新日を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getUpdatedDate()
	 * @return 更新日
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public Date getUpdatedDate() {
		return _updatedDate;
	}

	/**
	 * 更新日を設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setUpdatedDate(java.util.Date)
	 * @param updatedDate 更新日
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setUpdatedDate(Date updatedDate) {
		_updatedDate = updatedDate;
	}

	/**
	 * 更新者を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getUpdatedPerson()
	 * @return 更新者
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getUpdatedPerson() {
		return _updatedPerson;
	}

	/**
	 * 更新者を設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setUpdatedPerson(java.lang.String)
	 * @param updatedPerson 更新者
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setUpdatedPerson(String updatedPerson) {
		_updatedPerson = updatedPerson;
	}

	/**
	 * 排他キーを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getExclusiveKey()
	 * @return 排他キー
	 * @create 2011/09/08
	 * @author KCCS XXXXX
	 * @since 3.9.0
	 */
	public String getExclusiveKey() {
		return _exclusiveKey;
	}

	/**
	 * 排他キーを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setExclusiveKey(java.lang.String)
	 * @param exclusiveKey 排他キー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setExclusiveKey(String exclusiveKey) {
		_exclusiveKey = exclusiveKey;
	}

	/**
	 * 表示名リソースIDを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#getDisplayNameResourceID()
	 * @return 表示名リソースID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getDisplayNameResourceID() {
		return _displayNameResourceID;
	}

	/**
	 * 表示名リソースIDを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenu#setDisplayNameResourceID(java.lang.String)
	 * @param displayNameResourceID 表示名リソースID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setDisplayNameResourceID(String displayNameResourceID) {
		_displayNameResourceID = displayNameResourceID;
	}
}
