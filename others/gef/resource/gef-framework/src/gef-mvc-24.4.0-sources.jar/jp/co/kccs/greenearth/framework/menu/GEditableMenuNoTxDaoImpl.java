/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.exception.GAlreadyInsertedException;
import jp.co.kccs.greenearth.commons.exception.GAlreadyUpdatedException;
import jp.co.kccs.greenearth.commons.exception.GOptimisticLockException;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.authorization.GRoleDao;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.GRecordImpl;
import jp.co.kccs.greenearth.framework.jdbc.sql.GUniqueConstraintException;

/**
 * {@link GEditableMenuDao}インターフェースの実装クラスです.<br>
 *
 * @author KCCS Shigeki Shoji
 * @create 2013/07/24
 * @since 3.12.0
 */
public class GEditableMenuNoTxDaoImpl extends GMenuDaoImpl implements GEditableMenuDao {

	/** GEMenuLocalizationResourceテーブルのテーブル名 */
	protected static final String GEMenuLocalizationResource = "GEMenuLocalizationResource";

	/** GEMenu項目：表示名ID */
	protected static final String DISPLAY_NAME_RESOURCE_ID = "DisplayNameResourceID";
	/** GEMenu項目：備考 */
	protected static final String DESCRIPTION = "Description";
	/** GEMenu項目：ソート順 */
	protected static final String SORT_INDEX = "SortIndex";
	/** GEMenu項目：更新日 */
	protected static final String UPDATED_DATE = "UpdatedDT";
	/** GEMenu項目：更新者 */
	protected static final String UPDATED_PERSON = "UpdatedPerson";
	/** GEMenu項目：排他フラグ */
	protected static final String EXCLUSIVE_KEY = "ExclusiveFG";

	/** GEMenuLocalizationResource項目：リソースID */
	private static final String RESOURCE_ID = "ResourceID";
	/** GEMenuLocalizationResource項目：地域コード */
	protected static final String RESOURCE_LOCALE = "Locale";
	/** GEMenuLocalizationResource項目：キー */
	protected static final String RESOURCE_VALUE = "Value";

	/** アプリケーションタイプ情報 (アイテム) */
	private Map<String, String> _itemAppTypeMap = null;
	/** アプリケーションタイプ情報(カテゴリ) */
	private Map<String, String> _categoryAppTypeMap = null;
	/** メニュータイプ情報(カテゴリ) */
	private Map<String, String> _categoryMenuTypeMap = null;
	/** メニュータイプ情報(アイテム) */
	private Map<String, String> _itemMenuTypeMap = null;

	/**
	 * {@link GEditableMenuNoTxDaoImpl}クラスの新しいインスタンスを初期化します.<br>
	 *
	 * @param roleDao ロールDao
	 * @param categoryAppTypeMap アプリケーションタイプ情報(カテゴリ)
	 * @param itemAppTypeMap アプリケーションタイプ(アイテム)
	 * @param categoryMenuTypeMap メニュータイプ(カテゴリ)
	 * @param itemMenuTypeMap メニュータイプ(アイテム)
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	public GEditableMenuNoTxDaoImpl(GRoleDao roleDao, Map<String, String> categoryAppTypeMap,
								Map<String, String> itemAppTypeMap, Map<String, String> categoryMenuTypeMap,
								Map<String, String> itemMenuTypeMap) {
		super(roleDao);
		_categoryAppTypeMap = categoryAppTypeMap;
		_itemAppTypeMap = itemAppTypeMap;
		_categoryMenuTypeMap = categoryMenuTypeMap;
		_itemMenuTypeMap = itemMenuTypeMap;
	}

	/**
	 * オブジェクトIDからメニューを検索します.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.menu.GEditableMenuDao#findMenu(java.lang.String)
	 * @param objectID オブジェクトID
	 * @return メニュー
	 * @throws GResourceProcessingException リソースアクセス時エラー
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public GEditableMenu findMenu(String objectID) throws GResourceProcessingException {
		return (GEditableMenu) super.findMenu(objectID);
	}

	/**
	 * メニューのゴーストを生成します.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.menu.GEditableMenuDao#createMenu()
	 * @return メニューゴースト
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public GGhostEditableMenuImpl createMenu() {
		return new GGhostEditableMenuImpl(new GEditableMenuImpl());
	}

	@Override
	protected GMenu createMenu(List<GRecord> recordList) {
		GGhostEditableMenuImpl menu = null;

		if (recordList.size() > 0) {

			menu = (GGhostEditableMenuImpl) super.createMenu(recordList);

			GRecord record = recordList.get(0);

			menu.setDescription(record.getString(DESCRIPTION));
			menu.setSortIndex(record.getInteger(SORT_INDEX));
			menu.setUpdatedDate(record.getDate(UPDATED_DATE));
			menu.setUpdatedPerson(record.getString(UPDATED_PERSON));
			menu.setExclusiveKey(record.getString(EXCLUSIVE_KEY));
			menu.setDisplayNameResourceID(record.getString(DISPLAY_NAME_RESOURCE_ID));
		}
		return menu;
	}

	@Override
	public void insertMenu(GEditableMenu menu) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			insertMenu(menu, connection);
		} catch (GOptimisticLockException e) {
			throw e;
		} catch (GResourceProcessingException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * １件のメニュー情報を新規登録します。<br>
	 *
	 * @param menu 新規登録メニュー情報
	 * @param connection コネクション
	 * @throws GOptimisticLockException 登録時にユニークエラーが発生した場合
	 * @throws GResourceProcessingException DBアクセスに失敗した場合
	 * @create 2013/07/24
	 * @author KCCS Shigeki Shoji
	 * @since 3.12.0
	 */
	protected void insertMenu(GEditableMenu menu, Connection connection) throws GOptimisticLockException, GResourceProcessingException {
		try {
			if (menu.getSortIndex() < 0) {
				// ソートインデックス採番
				menu.setSortIndex(numberingSortIndex(menu, connection));
			}
			GRecord record = createMenuRecord(menu);
			insert("GEMenu").values(record).execute(connection);
		} catch (GUniqueConstraintException e) {
			// ユニークキーエラーの場合
			throw new GAlreadyInsertedException(e);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
		insertResources(menu, connection);
	}

	/**
	 * 採番するソートインデックスを取得します。<br>
	 *
	 * @param menu 採番対象のメニュー
	 * @param connection コネクション
	 * @return ソートインデックス
	 * @throws SQLException SQL実行時の例外
	 * @create 2013/07/24
	 * @author KCCS Shigeki Shoji
	 * @since 3.12.0
	 */
	private int numberingSortIndex(GEditableMenu menu, Connection connection) throws SQLException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyCode", menu.getCompanyCode());
		params.put("parentMenuObjectID", GStringUtils.blankToNull(menu.getParentObjectID()));
		List<GRecord> records = select("GEMenu")
				.fields(col(exp("$MAX(#SortIndex)"), "SortIndex"))
				.where(expMap($("#CompanyCode = :[companyCode]").AND("#ParentMenuObjectID = :[parentMenuObjectID]"), params))
				.findList(connection);
		if (records.size() == 0) {
			return 0;
		}

		Integer sortIndex = records.get(0).getInteger(SORT_INDEX);
		if (sortIndex == null) {
			return 0;
		} else {
			return sortIndex.intValue() + 1;
		}
	}

	@Override
	public void updateMenu(GEditableMenu menu) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			updateMenu(menu, connection);
		} catch (GOptimisticLockException e) {
			throw e;
		} catch (GResourceProcessingException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * GEMenuテーブル、GEMenuLocalizationResourceテーブルを更新します。<br>
	 *
	 * @param menu メニュー
	 * @param connection 更新処理で使用するコネクション
	 * @throws GOptimisticLockException 楽観的排他制御のためGERoleテーブルの更新が行えなかった場合
	 * @throws GResourceProcessingException 更新処理で例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	protected void updateMenu(GEditableMenu menu, Connection connection) throws GOptimisticLockException, GResourceProcessingException {
		try {
			if (menu.getSortIndex() < 0) {
				// ソートインデックス採番
				menu.setSortIndex(numberingSortIndex(menu, connection));
			}
			GRecord record = createMenuRecord(menu);
			update("GEMenu").set(record).wherePK().execute(connection);
		} catch (jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException e) {
			throw new GAlreadyUpdatedException(e);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}

		// リソース
		deleteResources(menu, connection);
		insertResources(menu, connection);
	}

	@Override
	public void updateMenuList(List<GEditableMenu> menuList) throws GResourceProcessingException,
		GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			for (GEditableMenu menu : menuList) {
				updateMenu(menu, connection);
			}
		} catch (GOptimisticLockException e) {
			throw e;
		} catch (GResourceProcessingException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	@Override
	public void deleteMenuList(List<GEditableMenu> menuList) throws GResourceProcessingException, GOptimisticLockException {
		Connection connection = catchConnection();
		try {
			for (GEditableMenu role : menuList) {
				deleteMenu(role, connection);
			}
		} catch (GOptimisticLockException e) {
			throw e;
		} catch (GResourceProcessingException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * GEMenuテーブル、GEMenuLocalizationResourceテーブルからレコードを削除します。<br>
	 *
	 * @param menu メニュー
	 * @param connection コネクション
	 * @throws GResourceProcessingException 削除処理で例外が発生した場合
	 * @throws GOptimisticLockException 楽観的排他制御により削除が行えなかった場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	protected void deleteMenu(GEditableMenu menu, Connection connection) throws GResourceProcessingException, GOptimisticLockException {
		// GEMenuテーブル
		GRecord record = createMenuRecord(menu);
		try {
			delete("GEMenu").wherePK(record).execute(connection);
		} catch (jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException e) {
			throw new GAlreadyUpdatedException(e);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
		// GELocalizationResourceテーブル
		deleteResources(menu, connection);
	}

	@Override
	public void deleteMenuAll(String companyCode) throws GResourceProcessingException {
		Connection connection = catchConnection();

		try {
			// GEMenuテーブルの削除
			Map<String, Object> searchParams = new HashMap<String, Object>();
			searchParams.put("companyCode", companyCode);
			delete("GEMenu").where(expMap($("#CompanyCode = :companyCode"), searchParams)).execute(connection);

			// GEMenuLocalizationResourceテーブルの削除
			searchParams = new HashMap<String, Object>();
			searchParams.put("companyCode", companyCode);
			delete(GEMenuLocalizationResource).where(expMap($("#CompanyCode = :companyCode"), searchParams)).execute(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} catch (RuntimeException e) {
			throw e;
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * {@link GMenu}からメニュー情報を持つ{@link GRecord}を生成します.<br>
	 *
	 * @param menu メニュー
	 * @return 生成されたレコード
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	private GRecord createMenuRecord(GEditableMenu menu) {
		GRecord record = new GRecordImpl();
		// GMenuをGDBRecordにセットする
		record.setObject(OBJECT_ID, GStringUtils.blankToNull(menu.getObjectID()));
		record.setObject(COMPANY_CODE, menu.getCompanyCode());
		record.setObject(EXCLUSIVE_KEY, GStringUtils.blankToNull(menu.getExclusiveKey()));
		record.setObject(DISPLAY_NAME_RESOURCE_ID, GStringUtils.blankToNull(menu.getDisplayNameResourceID()));
		record.setObject(MENU_ID, menu.getMenuID());
		record.setObject(PARENT_MENU_OBJECT_ID, GStringUtils.blankToNull(menu.getParentObjectID()));
		record.setObject(APPLICATION_TYPE, menu.getApplicationType());
		record.setObject(MENU_TYPE, GStringUtils.blankToNull(menu.getMenuType()));
		record.setObject(START_MODULE, GStringUtils.blankToNull(menu.getStartModule()));
		record.setObject(PARAMETER, GStringUtils.blankToNull(menu.getParameter()));
		record.setObject(IS_ITEM, GBooleanUtils.toInteger(menu.isItem()));
		record.setObject(STATUS, menu.getStatus() != null ? menu.getStatus().toInt() : null);
		record.setObject(DESCRIPTION, GStringUtils.blankToNull(menu.getDescription()));
		record.setObject(SORT_INDEX, new Integer(menu.getSortIndex()));
		record.setObject(UPDATED_DATE, menu.getUpdatedDate());
		record.setObject(UPDATED_PERSON, menu.getUpdatedPerson());
		record.setObject(ROLE_OBJECT_ID, GStringUtils.blankToNull(menu.getRoleObjectID()));
		return record;
	}

	/**
	 * GEMenuLocalizationResourceテーブルにレコードを１件登録します。
	 *
	 * @param menu 登録するメニュー
	 * @param connection 登録処理に使用するコネクション
	 * @throws GResourceProcessingException レコード登録時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	private void insertResources(GEditableMenu menu, Connection connection) throws GResourceProcessingException {
		List<GRecord> resourceRecordList = createResourceRecord(menu);
		try {
			for (GRecord resourceRecord : resourceRecordList) {
				insert(GEMenuLocalizationResource).values(resourceRecord).execute(connection);
			}
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * GEMenuLocalizationResourceテーブルのレコードを１件削除します。
	 *
	 * @param menu 削除するメニュー
	 * @param connection 削除処理に使用するコネクション
	 * @throws GResourceProcessingException レコード削除時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	private void deleteResources(GEditableMenu menu, Connection connection) throws GResourceProcessingException {
		String displayNameResourceID = menu.getDisplayNameResourceID();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("resourceID", displayNameResourceID);
		params.put("companyCode", menu.getCompanyCode());
		try {
			delete(GEMenuLocalizationResource)
				.where(expMap($("#ResourceID = :resourceID").AND("#CompanyCode = :companyCode"), params))
				.execute(connection);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * GEMenuLocalizationResourceのレコードリストを返します。
	 *
	 * @param menu メニュー
	 * @return GEMenuLocalizationResourceのレコードリスト
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	private List<GRecord> createResourceRecord(GEditableMenu menu) {
		List<GRecord> recordList = new ArrayList<GRecord>();
		Map<Locale, String> map = menu.getDisplayNameMap();
		for (Map.Entry<Locale, String> entry : map.entrySet()) {
			GRecord resourceRecord = new GRecordImpl();
			resourceRecord.setObject(COMPANY_CODE, menu.getCompanyCode());
			resourceRecord.setObject(RESOURCE_ID, GStringUtils.blankToNull(menu.getDisplayNameResourceID()));
			resourceRecord.setObject(RESOURCE_LOCALE, entry.getKey().toString());
			resourceRecord.setObject(RESOURCE_VALUE, GStringUtils.blankToNull(entry.getValue()));
			recordList.add(resourceRecord);
		}
		return recordList;
	}

	/**
	 * {@link GEditableMenu}のゴーストクラスです。<br>
	 *
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public class GGhostEditableMenuImpl extends GGhostMenuImpl implements GEditableMenu {

		/**
		 * {@link GEditableMenu}を指定して{@link GGhostEditableMenuImpl}を初期化します。<br>
		 *
		 * @param menu メニュー
		 * @author KCCS Shigeki Shoji
		 * @create 2013/07/23
		 * @since 3.12.0
		 */
		public GGhostEditableMenuImpl(GEditableMenu menu) {
			super(menu);
		}

		/**
		 * メニューを取得します。<br>
		 *
		 * @return メニュー
		 * @author KCCS Shigeki Shoji
		 * @create 2013/07/23
		 * @since 3.12.0
		 */
		public GEditableMenu getMenu() {
			return (GEditableMenu) _menu;
		}

		@Override
		public String getDescription() {
			return getMenu().getDescription();
		}

		@Override
		public void setDescription(String description) {
			getMenu().setDescription(description);
		}

		@Override
		public int getSortIndex() {
			return getMenu().getSortIndex();
		}

		@Override
		public void setSortIndex(int sortIndex) {
			getMenu().setSortIndex(sortIndex);
		}

		@Override
		public Date getUpdatedDate() {
			return getMenu().getUpdatedDate();
		}

		@Override
		public void setUpdatedDate(Date updatedDate) {
			getMenu().setUpdatedDate(updatedDate);
		}

		@Override
		public String getUpdatedPerson() {
			return getMenu().getUpdatedPerson();
		}

		@Override
		public void setUpdatedPerson(String updatedPerson) {
			getMenu().setUpdatedPerson(updatedPerson);
		}

		@Override
		public String getExclusiveKey() {
			return getMenu().getExclusiveKey();
		}

		@Override
		public void setExclusiveKey(String exclusiveKey) {
			getMenu().setExclusiveKey(exclusiveKey);
		}

		@Override
		public String getDisplayNameResourceID() {
			return getMenu().getDisplayNameResourceID();
		}

		@Override
		public void setDisplayNameResourceID(String displayNameResourceID) {
			getMenu().setDisplayNameResourceID(displayNameResourceID);
		}
	}

	/**
	 * ロケールに合わせて、アプリケーションタイプ(アイテム)の一覧を保持するMapを取得します。<br/>
	 *
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenuDao#getItemAppTypeMap()
	 * @param locale ロケール
	 * @return アプリケーションタイプ一覧(アイテム)
	 * @create 2013/07/24
	 * @author KCCS Shigeki Shoji
	 * @since 3.12.0
	 */
	@Override
	public Map<String, String> getItemAppTypeMap(Locale locale) {
		Map<String, String> applicationTypeLocalizationMap = new HashMap<String, String>();
		for (Map.Entry<String, String> e : _itemAppTypeMap.entrySet()) {
			String resourceID = e.getValue();
			if (GStringUtils.isEmpty(resourceID)) {
				continue;
			}
			String value = GMessageResources.getMessage(resourceID, locale);
			applicationTypeLocalizationMap.put(e.getKey(), value);
		}
		return applicationTypeLocalizationMap;
	}

	/**
	 * ロケールに合わせて、アプリケーションタイプ(カテゴリ)の一覧を保持するMapを取得します。<br/>
	 *
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenuDao#getCategoryAppTypeMap()
	 * @param locale ロケール
	 * @return アプリケーションタイプ一覧(カテゴリ)
	 * @create 2013/07/24
	 * @author KCCS Shigeki Shoji
	 * @since 3.12.0
	 */
	@Override
	public Map<String, String> getCategoryAppTypeMap(Locale locale) {
		Map<String, String> categoryTypeLocalizationMap = new HashMap<String, String>();
		for (Map.Entry<String, String> e : _categoryAppTypeMap.entrySet()) {
			String resourceID = e.getValue();
			if (GStringUtils.isEmpty(resourceID)) {
				continue;
			}
			String value = GMessageResources.getMessage(resourceID, locale);
			categoryTypeLocalizationMap.put(e.getKey(), value);
		}
		return categoryTypeLocalizationMap;
	}

	/**
	 * ロケールに合わせて、メニュータイプ(アイテム)の一覧を保持するMapを取得します。<br/>
	 *
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenuDao#getItemMenuTypeMap()
	 * @param locale ロケール
	 * @return メニュータイプ(アイテム)の一覧を保持するMap
	 * @create 2013/07/24
	 * @author KCCS Shigeki Shoji
	 * @since 3.12.0
	 */
	@Override
	public Map<String, String> getItemMenuTypeMap(Locale locale) {
		Map<String, String> menuTypeLocalizationMap = new HashMap<String, String>();
		for (Map.Entry<String, String> e : _itemMenuTypeMap.entrySet()) {
			String resourceID = e.getValue();
			if (GStringUtils.isEmpty(resourceID)) {
				continue;
			}
			String value = GMessageResources.getMessage(resourceID, locale);
			menuTypeLocalizationMap.put(e.getKey(), value);
		}
		return menuTypeLocalizationMap;
	}

	/**
	 * ロケールに合わせて、メニュータイプ(カテゴリ)の一覧を保持するMapを取得します。<br/>
	 *
	 * @see jp.co.kccs.greenearth.framework.em.menumanager.GEditableMenuDao#getItemMenuTypeMap()
	 * @param locale ロケール
	 * @return メニュータイプ(カテゴリ)の一覧を保持するMap
	 * @create 2013/07/24
	 * @author KCCS Shigeki Shoji
	 * @since 3.12.0
	 */
	@Override
	public Map<String, String> getCategoryMenuTypeMap(Locale locale) {
		Map<String, String> menuTypeLocalizationMap = new HashMap<String, String>();
		for (Map.Entry<String, String> e : _categoryMenuTypeMap.entrySet()) {
			String resourceID = e.getValue();
			if (GStringUtils.isEmpty(resourceID)) {
				continue;
			}
			String value = GMessageResources.getMessage(resourceID, locale);
			menuTypeLocalizationMap.put(e.getKey(), value);
		}
		return menuTypeLocalizationMap;
	}

}
