/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.io.Serializable;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GRole;

/**
 * メニューを表すインターフェースです.
 * 
 * @create 2011/05/26
 * @author KCCS nishimura
 * @since 3.9.0
 */
public interface GMenu extends Serializable{
	
	/**
	 * オブジェクトIDを設定します.
	 * 
	 * @param objectID オブジェクトID
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setObjectID(String objectID);
	
	/**
	 * オブジェクトIDを取得します.
	 * 
	 * @return オブジェクトID
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getObjectID();

	/**
	 * 会社コードを設定します.
	 * 
	 * @param companyCode 会社コード
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setCompanyCode(String companyCode);
	
	/**
	 * 会社コードを取得します.
	 * 
	 * @return 会社コード
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getCompanyCode();
	
	/**
	 * メニューIDを設定します.
	 * 
	 * @param menuID メニューID
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setMenuID(String menuID);
	
	/**
	 * メニューIDを取得します.
	 * 
	 * @return メニューID
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getMenuID();
	
	/**
	 * アプリケーションタイプを設定します.
	 * 
	 * @param applicationType アプリケーションタイプ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setApplicationType(String applicationType);
	
	/**
	 * アプリケーションタイプを取得します.
	 * 
	 * @return アプリケーションタイプ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getApplicationType();
	
	/**
	 * メニュータイプを設定します.
	 * 
	 * @param menuType メニュータイプ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setMenuType(String menuType);
	
	/**
	 * メニュータイプを取得します.
	 * 
	 * @return メニュータイプ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getMenuType();
	
	/**
	 * 起動モジュールを設定します.
	 * 
	 * @param startModule 起動モジュール
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setStartModule(String startModule);
	
	/**
	 * 起動モジュールを取得します.
	 * 
	 * @return 起動モジュール
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getStartModule();
	
	/**
	 * パラメータを設定します.
	 * 
	 * @param parameter パラメータ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setParameter(String parameter);
	
	/**
	 * パラメータを取得します.
	 * 
	 * @return パラメータ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getParameter();
	
	/**
	 * アイテムフラグを設定します.
	 * 
	 * @param isItem アイテムフラグ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setIsItem(boolean isItem);
	
	/**
	 * アイテムフラグを取得します.
	 * 
	 * @return アイテムフラグ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	boolean isItem();
	
	/**
	 * 状態を取得します.
	 * 
	 * @return 状態
	 * @create 2011/06/04
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	GStatus getStatus();
	
	/**
	 * 状態を設定します.
	 * 
	 * @param status 状態
	 * @create 2011/06/04
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	void setStatus(GStatus status);
	
	/**
	 * ロールを設定します.
	 * 
	 * @param role ロール
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setRole(GRole role);
	
	/**
	 * ロールを取得します.
	 * 
	 * @return ロール
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GRole getRole();
	
	/**
	 * ロケールと表示名を設定します.
	 * 
	 * @param displayName ロケールと表示名のマップ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setDisplayNameMap(Map<Locale, String> displayName);
	
	/**
	 * ロケールと表示名のマップを取得します.
	 * 
	 * @return ロケールと表示名のマップ
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	Map<Locale, String> getDisplayNameMap();
	
	/**
	 * 表示名を取得します.
	 * 
	 * @return 表示名
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getDisplayName();
	
	/**
	 * 引数のロケールに応じたメニュー名を取得します.
	 * 
	 * @param locale ロケール
	 * @return メニュー名
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	String getDisplayName(Locale locale);
	
	/**
	 * 親メニューを取得します.
	 * 
	 * @return 親メニュー
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GMenu getParent();
	
	/**
	 * 親メニューを設定します.
	 * 
	 * @param menu 親メニュー
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setParent(GMenu menu);
	
	/**
	 * 子メニューを取得します.
	 * 
	 * @return 子メニューのリスト
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	List<GMenu> getChildren();
	
	/**
	 * 子メニューを設定します.
	 * 
	 * @param children 子メニューのリスト
	 * @create 2011/05/26
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	void setChildren(List<GMenu> children);
	
	/**
	 * ユーザーに権限があるかどうかを判定します.<br>
	 * 
	 * @param user ユーザー
	 * @return 権限の有無(true:権限アリ、false権限ナシ)
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	boolean hasAuthority(GUser user);
}
