/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;

/**
 * 永続化層にアクセスしてメニュー情報を操作するインターフェースです.<br>
 * 
 * @create 2011/07/29
 * @author KCCS nishimura
 * @since 3.9.0
 */
public interface GMenuDao {
	
	/**
	 * 会社コードを基に、ルート階層のメニュー情報を取得します.<br>
	 * 
	 * @create 2010/09/08
	 * @param companyCode 会社コード
	 * @return ルートメニュー情報リスト
	 * @throws GResourceProcessingException リソースの処理中に失敗した場合
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	List<GMenu> findRootMenuList(String companyCode) throws GResourceProcessingException;
	
	/**
	 * 会社コード、メニューIDを基に、メニュー情報を取得します.<br>
	 * 
	 * @param companyCode 会社コード
	 * @param menuID メニューID
	 * @return メニュー情報
	 * @throws GResourceProcessingException リソースの処理中に失敗した場合
	 * @create 2011/07/29
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	GMenu findMenu(String companyCode, String menuID) throws GResourceProcessingException;
	
	/**
	 *　オブジェクトIDを基に、メニュー情報を取得します.<br>
	 * 
	 * @param objectID オブジェクトID
	 * @return メニュー情報
	 * @throws GResourceProcessingException リソースの処理中に失敗した場合
	 * @create 2011/07/29
	 * @author KCCS nisimura
	 * @since 3.9.0
	 */
	GMenu findMenu(String objectID) throws GResourceProcessingException;
	
	/**
	 * GMenuDaoインスタンスのファクトリークラスです.<br>
	 * 
	 * @create 2011/07/29
	 * @author KCCS nisimura
	 * @since 3.9.0
	 * @deprecated
	 */
	public static class Factory {
		
		/**
		 * デフォルトコンストラクタ.<br>
		 * 
		 * @create 2011/07/29
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public Factory() {
		}
		/**
		 * DIに定義された{@link GMenuDao}のインスタンスを取得します.<br>
		 * 
		 * @return {@link GMenuDao}インスタンス
		 * @create 2011/07/29
		 * @author KCCS nishimura
		 * @since 3.9.0
		 */
		public static GMenuDao getInstance() {
			return (GMenuDao) GFrameworkUtils.getComponent(GMenuDao.class.getName());
		}
	}
}
