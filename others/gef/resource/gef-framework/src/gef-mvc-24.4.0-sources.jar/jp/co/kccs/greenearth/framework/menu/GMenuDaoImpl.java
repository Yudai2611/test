/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManager;
import jp.co.kccs.greenearth.commons.jdbc.GJdbcConnectionManagerFactory;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GRole;
import jp.co.kccs.greenearth.framework.authorization.GRoleDao;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;

/**
 * GreenEARTH Frameworkのメニュー情報を取得するデータアクセスクラスです.<br>
 * データベース上に存在するGreenEARTH Frameworkのメニュー情報から、指定されたメニュー情報を取得する機能を提供します。<br>
 *
 * <br>
 * <b>【データソース】</b><br>
 * GreenEARTH Frameworkのメニュー情報は、データベースに格納されています。<br>
 * メニュー情報は、データベースのGEMenuテーブルに格納されています。<br>
 * メニュー情報の登録は、GreenEARTH Framework付属のEnterprise Managerで行ってください。<br>
 *
 * <b>【DAOクラスの指定】</b><br> {@link GMenuDaoImpl}は、
 * {@link jp.co.kccs.greenearth.framework.menu.GMenuFinder}
 * の実装クラスにインジェクションして使用します。<br>
 *
 * @author KCCS Shigeki Shoji
 * @create 2013/07/23
 * @since 3.12.0
 */
public class GMenuDaoImpl implements GMenuDao {

	/** GEMenuテーブルのテーブル名 */
	protected static final String GEMENU = "GEMenu";

	/** GEMenu項目：オブジェクトID */
	protected static final String OBJECT_ID = "ObjectID";
	/** GEMenu項目：会社コード */
	protected static final String COMPANY_CODE = "CompanyCode";
	/** GEMenu項目：メニューID */
	protected static final String MENU_ID = "MenuID";
	/** GEMenu項目：親メニューオブジェクトID */
	protected static final String PARENT_MENU_OBJECT_ID = "ParentMenuObjectID";
	/** GEMenu項目：アプリケーションタイプ */
	protected static final String APPLICATION_TYPE = "ApplicationType";
	/** GEMenu項目：メニュータイプ */
	protected static final String MENU_TYPE = "MenuType";
	/** GEMenu項目：スタートモジュール */
	protected static final String START_MODULE = "StartModule";
	/** GEMenu項目：パラメータ */
	protected static final String PARAMETER = "Parameter";
	/** GEMenu項目：アイテムであるか */
	protected static final String IS_ITEM = "IsItem";
	/** GEMenu項目：ステータス */
	protected static final String STATUS = "Status";
	/** GEMenu項目：ロールオブジェクトID */
	protected static final String ROLE_OBJECT_ID = "RoleObjectID";
	/** GELocalizationResourcea項目:地域コード */
	protected static final String DISPLAY_LOCALE = "Locale";
	/** GELocalizationResourcea項目:値 */
	protected static final String DISPLAY_NAME = "Value";

	/** ロール情報を取得するデータアクセスクラス */
	private GRoleDao _roleDao = null;

	/** メニュー情報をプーリングするMap(オブジェクトID、メニュー情報) */
	private Map<String, GMenu> _pool = new ConcurrentHashMap<String, GMenu>();

	/**
	 * {@link GRoleDao}を指定して{@link GMenuDaoImpl}を初期化します。
	 *
	 * @param roleDao ロールデータアクセスオブジェクト
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public GMenuDaoImpl(GRoleDao roleDao) {
		_roleDao = roleDao;
	}

	/**
	 * {@link GMenu}のゴーストを作成します。<br>
	 *
	 * @return GMenu メニューのゴースト
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public GMenu createMenu() {
		return new GGhostMenuImpl(new GMenuImpl());
	}

	/**
	 * 検索条件（会社コード）を指定してメニューを検索します。<br>
	 *
	 * @param companyCode 会社コード
	 * @return 検索結果（{@link GMenu}のリスト）
	 * @throws GResourceProcessingException SQL実行時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public List<GMenu> findRootMenuList(String companyCode) throws GResourceProcessingException {
		return findChildMenuList(companyCode, null);
	}

	/**
	 * 検索条件（オブジェクトID）を指定してメニューを検索します。<br>
	 *
	 * @param objectID オブジェクトID
	 * @return 検索結果（{@link GMenu}）
	 * @throws GResourceProcessingException SQL実行時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public GMenu findMenu(String objectID) throws GResourceProcessingException {
		if (_pool.containsKey(objectID)) {
			return _pool.get(objectID);
		}

		// デフォルトのデータソースに接続する
		Connection connection = catchConnection();
		try {
			List<GRecord> recordList = select(GEMENU, "menu")
					.leftOuterJoinFK("ResourceKey", "resource")
					.where(exp("#menu.ObjectID = ?", objectID))
					.findList(connection);

			GMenu menu = createMenu(recordList);
			if (menu != null) {
				_pool.put(menu.getObjectID(), menu);
			}
			return menu;

		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * 一件のメニューを取得します.
	 *
	 * @param companyCode 会社コード
	 * @param menuID メニューID
	 * @return 検索結果（{@link GMEnu}）
	 * @throws GResourceProcessingException SQL実行時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public GMenu findMenu(String companyCode, String menuID) throws GResourceProcessingException {
		Connection connection = catchConnection();
		try {
			List<GRecord> recordList = select(GEMENU, "menu")
					.leftOuterJoinFK("ResourceKey", "resource")
					.where(exp("#menu.CompanyCode = ? AND #menu.MenuID = ?", companyCode, menuID))
					.findList(connection);

			GMenu menu = createMenu(recordList);
			if (menu != null) {
				_pool.put(menu.getObjectID(), menu);
			}
			return menu;

		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * 検索条件（会社コード、親メニュー）を指定して子メニューのリストを取得します.<br>
	 *
	 * @param companyCode 会社コード
	 * @param parentObjectID 親メニューのオブジェクトID
	 * @return 検索結果（子メニューのリスト）
	 * @throws GResourceProcessingException SQL実行時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	public List<GMenu> findChildMenuList(String companyCode, String parentObjectID) throws GResourceProcessingException {
		Connection connection = catchConnection();
		try {
			Map<String, Object> parameter = new HashMap<String, Object>();
			parameter.put("companyCode", companyCode);
			parameter.put("parentObjectID", parentObjectID);

			List<GRecord> recordList = select(GEMENU, "GEMenu")
						.leftOuterJoinFK("RoleKey", "GERole")
						.leftOuterJoinFK("ResourceKey", "resource")
						.where(expMap($("#GEMenu.CompanyCode = :companyCode").AND("#GEMenu.ParentMenuObjectID = :parentObjectID"), parameter))
						.orderBy(asc("GEMenu.SortIndex"), asc("GEMenu.MenuID"))
						.findList(connection);

			List<GMenu> menuList = createMenuList(recordList);

			return menuList;

		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		} finally {
			releaseConnection(connection);
		}
	}

	/**
	 * {@link GRecord}のリストより{@link GMenu}を作成します.<br>
	 *
	 * @param recordList メニューの生成元となるレコードのリスト
	 * @return 生成されたメニュー
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	protected GMenu createMenu(List<GRecord> recordList) {

		GGhostMenuImpl menu = null;
		Map<Locale, String> displayNameMap = new HashMap<Locale, String>();

		if (recordList.size() > 0) {
			menu = (GGhostMenuImpl) createMenu();
			GRecord recordTemp = recordList.get(0);
			menu.setObjectID(recordTemp.getString(OBJECT_ID));
			menu.setParentObjectID(recordTemp.getString(PARENT_MENU_OBJECT_ID));
			menu.setCompanyCode(recordTemp.getString(COMPANY_CODE));
			menu.setMenuID(recordTemp.getString(MENU_ID));
			menu.setApplicationType(recordTemp.getString(APPLICATION_TYPE));
			menu.setMenuType(recordTemp.getString(MENU_TYPE));
			menu.setStartModule(recordTemp.getString(START_MODULE));
			menu.setParameter(recordTemp.getString(PARAMETER));
			Integer isItem = recordTemp.getInteger(IS_ITEM);
			if (isItem != null) {
				menu.setIsItem(GBooleanUtils.isTrueBit(isItem));
			}
			Integer status = recordTemp.getInteger(STATUS);
			if (status != null) {
				menu.setStatus(GBooleanUtils.isTrueBit(status) ? GStatus.Active : GStatus.Stop);
			}
			// Role
			menu.setRoleObjectID(recordTemp.getString(ROLE_OBJECT_ID));

			for (GRecord record : recordList) {
				Locale locale = GLocaleUtils.getLocale(record.getString(DISPLAY_LOCALE));
				String value = record.getString(DISPLAY_NAME);
				displayNameMap.put(locale, value);
			}
			menu.setDisplayNameMap(displayNameMap);
		}
		return menu;
	}

	/**
	 * {@link GRecord}のリストを{@link GMenu}のリストに変換します.<br>
	 *
	 * @param recordList レコードのリスト
	 * @return 生成されたメニューのリスト
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	protected List<GMenu> createMenuList(List<GRecord> recordList) {
		List<GMenu> menus = new ArrayList<GMenu>();

		GMenu menu = null;
		String objectIDTemp = null;
		List<GRecord> recordListTemp = new ArrayList<GRecord>();


		int i = 0;
		int listSize = recordList.size();
		for (GRecord record : recordList) {
			if (i == 0) {
				objectIDTemp = record.getString(MENU_ID);
			}
			String objectID = record.getString(MENU_ID);

			if (!objectID.equals(objectIDTemp)) {
				menu = createMenu(recordListTemp);
				recordListTemp.clear();
				menus.add(menu);
			}
			if (i == listSize - 1) {
				recordListTemp.add(record);
				menu = createMenu(recordListTemp);
				recordListTemp.clear();
				menus.add(menu);
				break;
			}

			recordListTemp.add(record);
			objectIDTemp = objectID;
			i++;
		}

		return menus;
	}

	/**
	 * "GEMenu"エンティティの定義からデータソース名を取得します。<br>
	 *
	 * @return エンティティに定義されたデータソース名
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	protected String getDataSourceName() {
		return entity(GEMENU).getDatabase().getDataSource();
	}

	/**
	 * コネクションを取得します。<br>
	 *
	 * @return 取得されたコネクション
	 * @throws GResourceProcessingException コネクションの取得時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	protected Connection catchConnection() throws GResourceProcessingException {
		try {
			GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
			return ds.open(getDataSourceName());
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * 指定されたコネクションを解放します。<br>
	 *
	 * @param conn 開放するコネクション
	 * @throws GResourceProcessingException コネクションの解放時に例外が発生した場合
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	protected void releaseConnection(Connection conn) throws GResourceProcessingException {
		try {
			GJdbcConnectionManager ds = GJdbcConnectionManagerFactory.getInstance();
			ds.close(conn);
		} catch (SQLException e) {
			throw new GResourceProcessingException(e);
		}
	}

	/**
	 * {@link GMenu}のゴーストクラスです。<br>
	 *
	 * @author KCCS Shigeki Shoji
	 * @create 2013/07/23
	 * @since 3.12.0
	 */
	protected class GGhostMenuImpl implements GMenu {

		/** 親メニューのオブジェクトID */
		private String _parentObjectID = null;
		/** 親メニューが読み込まれているか否か */
		private boolean _isParentLoaded = false;
		/** 子メニューが読み込まれているか否か */
		private boolean _isChildrenLoaded = false;
		/** ロールのオブジェクトID */
		private String _roleObjectID = null;
		/** ロールが読み込まれているか否か */
		private boolean _isRoleLoaded = false;

		/** メニュー */
		protected GMenu _menu = null;

		/**
		 * {@link GMenu}を指定して{@link GGhostMenuImpl}を初期化します。<br>
		 *
		 * @param menu メニュー
		 * @author KCCS Shigeki Shoji
		 * @create 2013/07/23
		 * @since 3.12.0
		 */
		public GGhostMenuImpl(GMenu menu) {
			_menu = menu;
		}

		/**
		 * 親メニューのオブジェクトIDを取得します。<br>
		 *
		 * @return 親メニューのオブジェクトID
		 * @author KCCS Shigeki Shoji
		 * @create 2013/07/23
		 * @since 3.12.0
		 */
		public String getParentObjectID() {
			return _parentObjectID;
		}

		/**
		 * 親メニューのオブジェクトIDを設定します。<br>
		 *
		 * @param parentObjectID 親メニューのオブジェクトID
		 * @author KCCS Shigeki Shoji
		 * @create 2013/07/23
		 * @since 3.12.0
		 */
		public void setParentObjectID(String parentObjectID) {
			_parentObjectID = parentObjectID;
		}

		/**
		 * ロールのオブジェクトIDを取得します。<br>
		 *
		 * @return ロールのオブジェクトID
		 * @author KCCS Shigeki Shoji
		 * @create 2013/07/23
		 * @since 3.12.0
		 */
		public String getRoleObjectID() {
			return _roleObjectID;
		}

		/**
		 * ロールのオブジェクトIDを設定します。<br>
		 *
		 * @param roleObjectID ロールのオブジェクトID
		 * @author KCCS Shigeki Shoji
		 * @create 2013/07/23
		 * @since 3.12.0
		 */
		public void setRoleObjectID(String roleObjectID) {
			_roleObjectID = roleObjectID;
		}

		@Override
		public GMenu getParent() {
			if (!_isParentLoaded && _parentObjectID != null) {
				try {
					setParent(findMenu(_parentObjectID));
				} catch (GResourceProcessingException e) {
					throw new GResourceAccessException(e);
				}
			}
			return _menu.getParent();
		}

		@Override
		public void setParent(GMenu parent) {
			_menu.setParent(parent);
			_isParentLoaded = true;
		}

		@Override
		public List<GMenu> getChildren() {
			if (!_isChildrenLoaded && getCompanyCode() != null && getObjectID() != null) {
				try {
					setChildren(findChildMenuList(getCompanyCode(), getObjectID()));
				} catch (GResourceProcessingException e) {
					throw new GResourceAccessException(e);
				}
			}
			return _menu.getChildren();
		}

		@Override
		public void setChildren(List<GMenu> children) {
			_menu.setChildren(children);
			_isChildrenLoaded = true;
		}

		@Override
		public String getObjectID() {
			return _menu.getObjectID();
		}

		@Override
		public String getApplicationType() {
			return _menu.getApplicationType();
		}

		@Override
		public String getCompanyCode() {
			return _menu.getCompanyCode();
		}

		@Override
		public String getDisplayName() {
			return _menu.getDisplayName();
		}

		@Override
		public String getDisplayName(Locale locale) {
			return _menu.getDisplayName(locale);
		}

		@Override
		public Map<Locale, String> getDisplayNameMap() {
			return _menu.getDisplayNameMap();
		}

		@Override
		public String getMenuID() {
			return _menu.getMenuID();
		}

		@Override
		public String getMenuType() {
			return _menu.getMenuType();
		}

		@Override
		public String getParameter() {
			return _menu.getParameter();
		}

		@Override
		public GRole getRole() {
			if (!_isRoleLoaded && _roleObjectID != null) {
				try {
					setRole(_roleDao.findRole(_roleObjectID));
				} catch (GResourceProcessingException e) {
					throw new GResourceAccessException(e);
				}
			}
			return _menu.getRole();
		}

		@Override
		public String getStartModule() {
			return _menu.getStartModule();
		}

//		public String getStatus() {
//			return _menu.getStatus();
//		}

		@Override
		public boolean hasAuthority(GUser user) {
			getRole();
			getParent();
			return _menu.hasAuthority(user);
		}

		@Override
		public boolean isItem() {
			return _menu.isItem();
		}

		@Override
		public void setObjectID(String objectID) {
			_menu.setObjectID(objectID);
		}

		@Override
		public void setApplicationType(String applicationType) {
			_menu.setApplicationType(applicationType);
		}

		@Override
		public void setCompanyCode(String companyCode) {
			_menu.setCompanyCode(companyCode);
		}

		@Override
		public void setDisplayNameMap(Map<Locale, String> displayName) {
			_menu.setDisplayNameMap(displayName);
		}

		@Override
		public void setIsItem(boolean isItem) {
			_menu.setIsItem(isItem);
		}

		@Override
		public void setMenuID(String menuID) {
			_menu.setMenuID(menuID);
		}

		@Override
		public void setMenuType(String menuType) {
			_menu.setMenuType(menuType);
		}

		@Override
		public void setParameter(String parameter) {
			_menu.setParameter(parameter);
		}

		@Override
		public void setRole(GRole role) {
			_menu.setRole(role);
			_isRoleLoaded = true;
		}

		@Override
		public void setStartModule(String startModule) {
			_menu.setStartModule(startModule);
		}

		@Override
		public GStatus getStatus() {
			return _menu.getStatus();
		}

		@Override
		public void setStatus(GStatus status) {
			_menu.setStatus(status);
		}
	}

}