/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

public interface GMenuFinder {

	List<GMenu> getRootMenuList(String compnayCode);
	GMenu getMenu(String companyCode, String menuID);
	GMenu getMenu(String objectID);
	
	/**
	 * {@link GMenuFinder}を生成するファクトリークラスです.
	 * 
	 * @create 2010/09/09
	 * @author kyo
	 * @since 3.9.0
	 */
	public static class Factory {

		/**
		 * メニューマネージャーを取得します.
		 *
		 * @create 2010/09/09
		 * @author kyo
		 * @return メニューネージャー
		 * @since 3.9.0
		 */
		public static GMenuFinder getInstance() {
			return (GMenuFinder) GFrameworkUtils.getComponent(GMenuFinder.class.getName());
		}
		
	}
}
