/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.util.List;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.GResourceAccessException;

public class GMenuFinderImpl implements GMenuFinder {
	
	private GMenuDao menuDao;
	
	@Deprecated
	public GMenuFinderImpl() {
	}
	
	public GMenuFinderImpl(GMenuDao menuDao) {
		this.menuDao = menuDao;
	}
	
	public GMenuDao getMenuDao() {
		if(menuDao == null){
			menuDao = GMenuDao.Factory.getInstance();
		}
		return menuDao;
	}
	
	public List<GMenu> getRootMenuList(String companyCode) {
		try {
			return getMenuDao().findRootMenuList(companyCode);
		}
		catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}
	
	/**
	 * 一件検索
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenuFinder#getMenu(java.lang.String, java.lang.String)
	 * @param companyCode
	 * @param menuID
	 * @return
	 * @throws GResourceProcessingException
	 * @author KCCS kyo
	 * @since 2010/10/20
	 */
	public GMenu getMenu(String companyCode, String menuID) {
		try {
			return getMenuDao().findMenu(companyCode, menuID);
		}
		catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}
	
	public GMenu getMenu(String objectID) {
		try {
			return getMenuDao().findMenu(objectID);
		}
		catch (GResourceProcessingException e) {
			throw new GResourceAccessException(e);
		}
	}
}
