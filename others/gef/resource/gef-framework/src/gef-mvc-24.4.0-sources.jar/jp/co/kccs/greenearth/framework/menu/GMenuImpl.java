/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.menu;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GRole;

/**
 * Menuを表すクラス.
 * 
 * @author nishimura
 * @since 3.9.0
 */
public class GMenuImpl implements GMenu {


	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GMenuImpl() {
	}
	/** シリアルバージョンUID */
	private static final long serialVersionUID = 1472349608060974088L;
	/** メニュー権限プロパティ */
	private static final String MENU_AUTHORITY = "geframe.auth.menu.DefaultAuthority";

	/** オブジェクトID */
	private String _objectID = null;
	/** 会社コード(ユニークキー1). */
	private String _companyCode = null;
	/** メニューID (ユニークキー2) */
	private String _menuID = null;
	/** アプリケーションタイプ. */
	private String _applicationType = null;
	/** メニュータイプ. */
	private String _menuType = null;
	/** 起動モジュール */
	private String _startModule = null;
	/** 起動パラメーター. */
	private String _parameter = null;
	/** アイテムフラグ */
	private boolean _isItem = false;
	/** 状態 [0(active)or1(stop)] */
	// private GStatus _status = null;
	private GStatus _status = GStatus.Active;
	// private String _status = null;
	/** ロール */
	private GRole _role = null;
	/** 表示名 */
	private Map<Locale, String> _displayName = null;
	/** 子メニューリスト */
	private List<GMenu> _children = null;
	/** 親メニュー */
	private GMenu _parent = null;

	/**
	 * オブジェクトIDを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setObjectID(java.lang.String)
	 * @param objectID オブジェクトID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setObjectID(String objectID) {
		_objectID = objectID;
	}

	/**
	 * オブジェクトIDを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getObjectID()
	 * @return オブジェクトID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getObjectID() {
		return _objectID;
	}

	/**
	 * 会社コードを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setCompanyCode(java.lang.String)
	 * @param companyCode 会社コード
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setCompanyCode(String companyCode) {
		_companyCode = companyCode;
	}

	/**
	 * 会社コードを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getCompanyCode()
	 * @return 会社コード
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getCompanyCode() {
		return _companyCode;
	}

	/**
	 * メニューIDを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setMenuID(java.lang.String)
	 * @param menuID メニューID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setMenuID(String menuID) {
		_menuID = menuID;
	}

	/**
	 * メニューIDを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getMenuID()
	 * @return メニューID
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getMenuID() {
		return _menuID;
	}

	/**
	 * アプリケーションタイプを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setApplicationType(java.lang.String)
	 * @param applicationType アプリケーションタイプ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setApplicationType(String applicationType) {
		_applicationType = applicationType;
	}

	/**
	 * アプリケーションタイプを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getApplicationType()
	 * @return アプリケーションタイプ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getApplicationType() {
		return _applicationType;
	}

	/**
	 * メニュータイプを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setMenuType(java.lang.String)
	 * @param menuType メニュータイプ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setMenuType(String menuType) {
		_menuType = menuType;
	}

	/**
	 * メニュータイプを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getMenuType()
	 * @return メニュータイプ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getMenuType() {
		return _menuType;
	}

	/**
	 * 起動モジュールを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setStartModule(java.lang.String)
	 * @param startModule 起動モジュール
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setStartModule(String startModule) {
		_startModule = startModule;
	}

	/**
	 * 起動モジュールを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getStartModule()
	 * @return 起動モジュール
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getStartModule() {
		return _startModule;
	}

	/**
	 * パラメータを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setParameter(java.lang.String)
	 * @param parameter パラメータ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setParameter(String parameter) {
		_parameter = parameter;
	}

	/**
	 * パラメータを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getParameter()
	 * @return パラメータ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getParameter() {
		return _parameter;
	}

	/**
	 * アイテムフラグを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setIsItem(boolean)
	 * @param isItem アイテムフラグ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setIsItem(boolean isItem) {
		_isItem = isItem;
	}

	/**
	 * アイテムフラグを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#isItem()
	 * @return アイテムフラグ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public boolean isItem() {
		return _isItem;
	}

	/**
	 * ロールを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setRole(jp.co.kccs.greenearth.framework.authorization.GRole)
	 * @param role ロール
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setRole(GRole role) {
		_role = role;
	}

	/**
	 * ロールを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getRole()
	 * @return ロール
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GRole getRole() {
		return _role;
	}

	/**
	 * ロケールと表示名のマップを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setDisplayNameMap(java.util.Map)
	 * @param displayName ロケールと表示名のマップ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setDisplayNameMap(Map<Locale, String> displayName) {
		_displayName = displayName;
	}

	/**
	 * ロケールと表示名のマップを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getDisplayNameMap()
	 * @return ロケールと表示名のマップ
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public Map<Locale, String> getDisplayNameMap() {
		return _displayName;
	}

	/**
	 * 表示名を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getDisplayName()
	 * @return 表示名
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getDisplayName() {
		return getDisplayName(Locale.getDefault());
	}

	/**
	 * 引数のロケールに応じたメニュー名を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getDisplayName(java.util.Locale)
	 * @param locale ロケール
	 * @return メニュー名
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public String getDisplayName(Locale locale) {
		return _displayName.get(locale);
	}

	/**
	 * 親メニューを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getParent()
	 * @return 親メニュー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public GMenu getParent() {
		return _parent;
	}

	/**
	 * 親メニューを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setParent(jp.co.kccs.greenearth.framework.menu.GMenu)
	 * @param parent 親メニュー
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setParent(GMenu parent) {
		_parent = parent;
	}

	/**
	 * 子メニューを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getChildren()
	 * @return 子メニューのリスト
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public List<GMenu> getChildren() {
		return _children;
	}

	/**
	 * 子メニューを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setChildren(java.util.List)
	 * @param children 子メニューのリスト
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setChildren(List<GMenu> children) {
		_children = children;
	}

	/**
	 * ユーザーに権限があるかどうかを判定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#hasAuthority(jp.co.kccs.greenearth.framework.auth.GUser)
	 * @param user ユーザー
	 * @return 権限の有無(true:権限アリ、false:権限ナシ)
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public boolean hasAuthority(GUser user) {
		GRole role = getRole();
		if (role == null) { // ロールが無い場合、親のロールを適用する。先祖までロールの設定がないなら、設定ない時の権限が適用される。
			GMenu parent = getParent();
			if (parent == null) {
				// ロールがない場合、デフォルト値はプロパティの設定値になる。
				// 設定が"true"ではない場合、アクセスを制限する
				return GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(MENU_AUTHORITY), false);
			} else {
				return parent.hasAuthority(user);
			}
		}

		if (role.hasAuthority(user)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 状態を設定します
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#setStatus(jp.co.kccs.greenearth.framework.auth.GStatus)
	 * @param status 状態
	 * @create 2011/09/08
	 * @author KCCS nishimura
	 * @since 3.9.0
	 */
	public void setStatus(GStatus status) {
		_status = status;
	}

	/**
	 * 状態を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.menu.GMenu#getStatus()
	 * @return 状態
	 * @create 2011/06/04
	 * @author KCCS fujimura
	 * @since 3.9.0
	 */
	public GStatus getStatus() {
		return _status;
	}
}