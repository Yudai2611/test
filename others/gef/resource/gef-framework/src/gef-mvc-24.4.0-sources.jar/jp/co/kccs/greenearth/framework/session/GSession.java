/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.session;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.framework.auth.GUser;

/**
 * フレームワークを利用したアプリケーションにおけるユーザを表現します.<br>
 * {@link GSession}は{@link GSessionManager}によって管理されます。
 * 
 * @see jp.co.kccs.greenearth.framework.session.GSessionManager
 * @see jp.co.kccs.greenearth.framework.auth.GUser
 * @create 2007/01/06
 * @author kitamura
 * @since 3.0.0
 */
public interface GSession extends Serializable {

	/**
	 * セッションが生成された時刻を取得します.<br>
	 * 生成時刻は{@link GSessionManager}によって設定されます。
	 * 
	 * @create 2007/01/06
	 * @return 生成された時間
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	Date getCreationTime() throws IllegalStateException;

	/**
	 * セッションを一意に識別するIDを取得します.<br>
	 * IDには、通常は{@link HttpSession#getId()}で取得されるIDが設定されています。
	 * 
	 * @create 2007/01/06
	 * @return ID
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getId() throws IllegalStateException;

	/**
	 * ログイン時に指定された地域情報を取得します.<br>
	 * 特定の地理的、国家的、または文化的地域を識別するために利用します。
	 * 
	 * @create 2007/01/06
	 * @return ロケール
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Deprecated
	Locale getLocale() throws IllegalStateException;

	/**
	 * ログイン時に関連付けられてユーザ情報を取得します.
	 * 
	 * @create 2007/01/06
	 * @return ユーザ
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUser getLoginUser() throws IllegalStateException;

	/**
	 * 指定された名前でこのセッションにバインドされたオブジェクトを返します.<br>
	 * その名前でバインドされたオブジェクトがない場合は、<code>null</code>を返します。
	 * 
	 * @create 2007/01/06
	 * @param name オブジェクトの名前を指定する文字列
	 * @return 指定された名前のオブジェクト
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	Object getValue(String name) throws IllegalStateException;

	/**
	 * このセッションにバインドされたすべてのオブジェクトの名前が格納された、{@link String}オブジェクトの{@link Iterator}を返します.
	 * 
	 * @create 2007/01/06
	 * @return このセッションにバインドされたすべてのオブジェクトの名前が格納された、{@link String}オブジェクトの{@link Iterator}
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	Iterator<String> getValueNames() throws IllegalStateException;

	/**
	 * このセッションを無効化し、バインドされていたすべてのオブジェクトをアンバインドします.
	 * 
	 * @create 2007/01/06
	 * @author kitamura
	 * @since 3.0.0
	 */
	void invalidate();

	/**
	 * このセッションが無効である場合は<code>true</code>を返します.
	 * 
	 * @create 2007/01/06
	 * @return 無効な場合<code>true</code>、有効な場合<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	boolean isInvalid();

	/**
	 * 指定された名前でバインドされたオブジェクトをこのセッションから削除します.<br>
	 * セッションに指定された名前でバインドされたオブジェクトがない場合、このメソッドは何も実行しません。 
	 * 
	 * @create 2007/01/06
	 * @param name このセッションから削除されるオブジェクトの名前
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	void removeValue(String name) throws IllegalStateException;

	/**
	 * セッションが生成された時刻を設定します.<br>
	 * 通常は{@link GSessionManager}によって設定されます。
	 * 
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @create 2007/01/06
	 * @param createdTime 生成時刻
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Deprecated
	void setCreationTime(Date createdTime) throws IllegalStateException;

	/**
	 * セッションを一意に識別するIDを設定します.<br>
	 * IDには、通常は{@link HttpSession#getId()}で取得されるIDが設定されます。<br>
	 * 通常は{@link GSessionManager}によって設定されます。
	 * 
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @create 2007/01/06
	 * @param id セッションID
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Deprecated
	void setId(String id) throws IllegalStateException;

	/**
	 * 地域を特定するための{@link Locale}情報を設定します.<br>
	 * 特定の地理的、国家的、または文化的地域を識別するために利用します。<br>
	 * 通常はフレームワークによって設定されます。
	 * 
	 * @create 2007/01/06
	 * @param locale ロケール
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Deprecated
	void setLocale(Locale locale) throws IllegalStateException;

	/**
	 * ユーザ情報を取得します.<br>
	 * 通常はフレームワークによって設定されます。
	 * 
	 * @create 2007/01/06
	 * @param user ユーザ情報
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setLoginUser(GUser user) throws IllegalStateException;

	/**
	 * 指定された名前を使用して、オブジェクトをこのセッションにバインドします.<br>
	 * 同じ名前のオブジェクトがすでにセッションにバインドされている場合は、オブジェクトが置き換えられます。 
	 * 
	 * @create 2007/01/06
	 * @param name オブジェクトがバインドされる名前。<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setValue(String name, Object value) throws IllegalStateException;
}
