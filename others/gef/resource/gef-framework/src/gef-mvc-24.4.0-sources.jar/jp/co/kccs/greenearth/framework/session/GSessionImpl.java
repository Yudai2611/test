/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.session;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.collection.GEmptyIterator;
import jp.co.kccs.greenearth.framework.auth.GUser;

/**
 * {@link GSession}インターフェースのデフォルト実装です.
 * 
 * @see jp.co.kccs.greenearth.framework.session.GSession
 * @create 2005/02/24
 * @author kitamura
 * @since 3.0.0
 */
public class GSessionImpl implements GSession {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = -4423977339210916382L;
	/** 値がバインドされていない場合に返す{@link Iterator}. */
	private static final Iterator<String> EMPTY_ITERATOR = new GEmptyIterator<String>();
	/** セッション生成日時. */
	private Date creationTime = new Date();
	/** セッションID. */
	private String id = null;
	/** 無効フラグ. */
	private boolean invalid = false;
	/** ユーザ情報. */
	private GUser loginUser = null;

	/** 追加情報. */
	private Map<String, Object> values = null;

	/**
	 * {@link GSessionImpl}クラスの新しいインスタンスを初期化します.
	 * newするのではなく{@link GSessionManager}から生成してください。
	 * 
	 * @create 2005/02/25
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GSessionImpl() {
	}

	/**
	 * セッションが生成された時刻を取得します.
	 * 
	 * @see GSession#getCreationTime()
	 * @create 2005/02/25
	 * @return 生成された日付
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Date getCreationTime() throws IllegalStateException {
		checkInvalid();

		return creationTime;
	}

	/**
	 * セッションのIDを取得します.
	 * 
	 * @see GSession#getId()
	 * @create 2005/02/25
	 * @return セッションID
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getId() throws IllegalStateException {
		checkInvalid();

		return id;
	}

	/**
	 * ログイン時に指定された地域情報を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GSession#getLocale()
	 * @create 2007/01/06
	 * @return ロケール
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Locale getLocale() throws IllegalStateException {
		checkInvalid();

		return GFrameworkContext.getInstance().getLocale();
	}

	/**
	 * ログイン時に関連付けられてユーザ情報を取得します.
	 * 
	 * @see GSession#getLoginUser()
	 * @create 2005/02/25
	 * @return ユーザ情報
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GUser getLoginUser() throws IllegalStateException {
		checkInvalid();

		return loginUser;
	}

	/**
	 * 指定された名前でこのセッションに結びつけられているオブジェクトを返します.<br>
	 * 指定された名前に結びつけられているオブジェクトが存在しない場合は
	 * <code>null</code>を返します。
	 * 
	 * @see GSession#getValue(String)
	 * @create 2006/11/26
	 * @param name オブジェクトの名前を表す文字列
	 * @return 指定された名前を持つオブジェクト
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Object getValue(String name) throws IllegalStateException {
		checkInvalid();

		Object value = null;
		if (values != null) {
			value = values.get(name);
		}
		return value;
	}

	/**
	 * このセッションに結びつけられている全てのオブジェクトの名前を表す
	 * <code>String</code>オブジェクトの{@link Iterator}オブジェクトを返します.
	 * 
	 * @see GSession#getValueNames()
	 * @create 2006/11/26
	 * @return このセッションに結びつけられている全てのオブジェクトの名前を表す{@link String}オブジェクトの{@link Iterator}
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Iterator<String> getValueNames() throws IllegalStateException {
		checkInvalid();

		if (values != null) {
			return values.keySet().iterator();
		}
		else {
			return EMPTY_ITERATOR;
		}
	}

	/**
	 * このセッションを無効化し、バインドされていたすべてのオブジェクトをアンバインドします.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GSession#invalidate()
	 * @create 2007/01/06
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void invalidate() {
		invalid = true;
		values = null;
		id = null;
		creationTime = null;
		loginUser = null;
	}

	/**
	 * このセッションが無効である場合は<code>true</code>を返します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GSession#isInvalid()
	 * @create 2007/01/06
	 * @return 無効な場合<code>true</code>、有効な場合<code>false</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public boolean isInvalid() {
		return invalid;
	}

	/**
	 * 指定された名前でセッションに結びつけられているオブジェクトをセッションから 削除します.
	 * 指定された名前で結びつけられているオブジェクトがセッションに存在しない場 合は何もしません。
	 * 
	 * @see GSession#removeValue(String)
	 * @create 2006/11/26
	 * @param name このセッションから削除されるオブジェクトの名前
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void removeValue(String name) throws IllegalStateException {
		checkInvalid();

		if (values != null) {
			values.remove(name);

			if (values.size() == 0) {
				values = null;
			}
		}
	}

	/**
	 * セッションが生成された時刻を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GSession#setCreationTime(java.util.Date)
	 * @create 2007/01/06
	 * @param createdTime 生成時刻
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setCreationTime(Date createdTime) throws IllegalStateException {
		checkInvalid();

		creationTime = createdTime;
	}

	/**
	 * セッションのIDを設定します.
	 * 
	 * @see GSession#setId(String)
	 * @create 2005/03/25
	 * @param id セッションID
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setId(String id) throws IllegalStateException {
		checkInvalid();

		this.id = id;
	}

	/**
	 * 地域を特定するための{@link Locale}情報を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GSession#setLocale(java.util.Locale)
	 * @create 2007/01/06
	 * @param locale ロケール
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Deprecated
	public void setLocale(Locale locale) throws IllegalStateException {
		checkInvalid();
		
		GFrameworkContext.getInstance().setLocale(locale);
	}

	/**
	 * ユーザ情報を設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.session.GSession#setLoginUser(jp.co.kccs.greenearth.framework.auth.GUser)
	 * @create 2005/02/25
	 * @param user ユーザ情報
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setLoginUser(GUser user) throws IllegalStateException {
		checkInvalid();

		loginUser = user;
	}

	/**
	 * 指定された名前でこのセッションにオブジェクトを結びつけます.
	 * 同じ名前を持つオブジェクトが既にこのセッションに結びつけられている場合、
	 * そのオブジェクトを置き換えます。
	 * 
	 * オブジェクトとして<code>null</code>が指定された場合は
	 * {@link #removeValue(String)}が呼び出されたのと同じ動作をします。
	 * 
	 * @see GSession#setValue(String, Object)
	 * @create 2006/11/26
	 * @param name オブジェクトがバインドされる名前。<code>null</code>であってはならない
	 * @param value バインドされるオブジェクト
	 * @throws IllegalStateException すでに無効化されたセッションでこのメソッドが呼び出された場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setValue(String name, Object value) throws IllegalStateException {
		checkInvalid();

		// nullの場合は削除
		if (value == null) {
			removeValue(name);
		}

		if (values == null) {
			values = new HashMap<String, Object>();
		}
		values.put(name, value);
	}

	/**
	 * このセッション無効状態であるかをチェックします.<br>
	 * 無効な場合は{@link IllegalStateException}をスローします。
	 * 有効な場合は何もしません。
	 * 
	 * @create 2007/01/06
	 * @throws IllegalStateException このセッションが無効な場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	private void checkInvalid() throws IllegalStateException {
		if (invalid) {
			throw new IllegalStateException("This session is invalid.");
		}
	}
}
