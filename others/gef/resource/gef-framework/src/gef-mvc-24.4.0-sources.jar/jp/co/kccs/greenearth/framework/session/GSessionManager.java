/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.session;

import jakarta.servlet.http.HttpSession;

/**
 * フレームワーク中のセッションを管理するAPI を定義します.<br>
 * <br>
 * 【セッション管理】<br>
 * GreenEARTH Frameworkでは、Webコンテナが提供する{@link HttpSession}とは別に
 * 独自のセッションを生成し管理を行っています。<br>
 * フレームワークを利用したアプリケーション中のセッションは、
 * {@link GSession}オブジェクトとして、ログイン時に生成され、ログアウト時に解放されます。
 * {@link GSession}は{@link HttpSession}とセッションIDによって関連付けられ、管理されます。
 * そのため、明示的にログアウト処理が行われていない場合でも、{@link HttpSession}が解放されると(タイムアウト時など)、
 * 同時に{@link GSession}も解放されます。
 * 
 * @create 2005/03/23
 * @author kitamura
 * @since 3.0.0
 */
public interface GSessionManager {

//	/**
//	 * 指定したセッションをセッションプールから解放します.
//	 * 
//	 * @create 2005/03/23
//	 * @param session セッション
//	 * @author kitamura
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	void closeSession(GSession session);
	
	/**
	 * 指定したセッションをセッションプールから解放します.
	 * 
	 * @param session セッション
	 * @param httpSession HTTPセッション
	 */
	void closeSession(GSession session, HttpSession httpSession);

	/**
	 * 指定したHTTPセッションに関連づく{@link GSession}をセッションプールから取得します.<br>
	 * セッションプールに存在しない場合は、新規作成します。
	 * 
	 * @create 2005/04/01
	 * @param httpSession HTTPセッション
	 * @return {@link GSession}オブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	GSession getSession(HttpSession httpSession);

//	/**
//	 * セッションをプーリングしている{@link Map}を取得します.
//	 * 
//	 * @create 2005/03/23
//	 * @return セッションをプーリングしている{@link Map}
//	 * @author kitamura
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	Map<String, GSession> getSessionPool();
}
