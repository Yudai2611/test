/*
 * Copyright 2010-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.session;

import java.util.Date;

import jakarta.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * セッション情報の永続化を{@link HttpSession}を使った実装した{@link GSessionManager}実装です。<br>
 * アプリケーションサーバーなどのクラスタ機能を使う際に、セッションのレプリケーションを行いたい場合は、
 * この実装クラスを利用してください。
 * 
 * @create 2010/03/23
 * @author kitamura
 * @since 3.8.0
 */
public class GSessionManagerByHttpSession implements GSessionManager {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GSessionManager.class);
	
	/** セッション格納キー */
	protected static final String SESSION_ATTR_KEY = GSession.class.getName();

	/**
	 * {@link GSessionManagerByHttpSession}クラスの新しいインスタンスを初期化します.
	 * 
	 * @create 2005/03/23
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GSessionManagerByHttpSession() {

	}
//	/**
//	 * 指定したセッションを{@link HttpSession}内から削除します。<br />
//	 * ※将来的に予告なく削除される可能性があります。<br />
//	 * ※GContextの実装クラスにGLocalContextを使用する場合に必要となる下位互換メソッドであるため、<br />
//	 * その他のGContextの実装クラスを使用する場合は、<br />
//	 * 　{@link GSessionManagerByHttpSession#closeSession(GSession, HttpSession)}を使用してください。
//	 * @create 2010/03/23
//	 * @see jp.co.kccs.greenearth.framework.session.GSessionManager#closeSession(jp.co.kccs.greenearth.framework.session.GSession)
//	 * @param session セッション
//	 * @author kitamura
//	 * @since 3.8.0
//	 */
//	@Deprecated
//	public void closeSession(GSession session) {
//		GWebContext context = GWebContext.getInstance();
//		HttpSession httpSession = context.getRequest().getSession();
//		GSession gsession = (GSession) httpSession.getAttribute(SESSION_ATTR_KEY);
//		if (gsession != null) {
//			String id = gsession.getId();
//			httpSession.removeAttribute(SESSION_ATTR_KEY);
//			gsession.invalidate();
//			LOGGER.info("Close Session : id=" + id);
//		}
//	}

	/**
	 * 指定したセッションを{@link HttpSession}内から削除します。<br />
	 * 
	 * @param session セッション
	 * @param httpSession HTTPセッション
	 */
	public void closeSession(GSession session, HttpSession httpSession) {
		GSession gsession = (GSession) httpSession.getAttribute(SESSION_ATTR_KEY);
		if (gsession != null) {
			String id = gsession.getId();
			httpSession.removeAttribute(SESSION_ATTR_KEY);
			gsession.invalidate();
			LOGGER.info("Close Session : id=" + id);
		}
	}

	/**
	 * 指定したHTTPセッションから、関連づく{@link GSession}を取得します.<br>
	 * 関連づくセッションが存在しない場合は、新規作成します。<br>
	 * 
	 * @create 2010/03/23
	 * @see jp.co.kccs.greenearth.framework.session.GSessionManager#getSession(jakarta.servlet.http.HttpSession)
	 * @param httpSession HTTPセッション
	 * @return セッション
	 * @author kitamura
	 * @since 3.8.0
	 */
	public GSession getSession(HttpSession httpSession) {
		GSession session = (GSession) httpSession.getAttribute(SESSION_ATTR_KEY);
		if (session == null) {
			session = createSession(httpSession);
		}
		return session;
	}

//	/**
//	 * このメソッドは実装されていません。<br>
//	 * 
//	 * @create 2010/03/23
//	 * @see jp.co.kccs.greenearth.framework.session.GSessionManager#getSessionPool()
//	 * @return 例外が発生します
//	 * @author kitamura
//	 * @since 3.8.0
//	 */
//	public Map<String, GSession> getSessionPool() {
//		throw new UnsupportedOperationException("This operation is not implemented. : getSessionPool");
//	}

	/**
	 * 新規セッションを生成し、{@link HttpSession}に格納します。
	 * 
	 * @create 2010/03/23
	 * @param httpSession HTTPセッション
	 * @return セッション
	 * @author kitamura
	 * @since 3.8.0
	 */
	@SuppressWarnings("deprecation")
	protected GSession createSession(HttpSession httpSession) {
		GSession session = GFrameworkUtils.getComponent(GSession.class.getName());
		String id = httpSession.getId();
		session.setId(id);
		session.setCreationTime(new Date());
		httpSession.setAttribute(SESSION_ATTR_KEY, session);
		LOGGER.info("Create Session : id=" + id);
		return session;
	}

}
