/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.session;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * セッションマネージャーを生成するファクトリです.<br>
 * 生成される{@link GSessionManager}実装は、DI定義ファイルにてい定義します。<br>
 * また、{@link GSessionManager}シングルトンとして管理されており、
 * {@link #getSessionManager()}メソッドにて取得されるインスタンスは常に同じものが返されます。
 * 
 * @create 2007/03/12
 * @author kitamura
 * @since 3.0.0
 */
public final class GSessionManagerFactory {

	/**
	 * {@link GSessionManagerFactory}インスタンスを初期化します.
	 * 
	 * @create 2007/03/22
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GSessionManagerFactory() {
	}

	/**
	 * セッションマネージャを生成し取得します.<br>
	 * セッションマネージャはシングルインスタンスとして管理されているため、
	 * 初回アクセス時のみDI定義ファイルで定義したインスタンスを生成し返しますが、
	 * それ以降のアクセスでは、初回生成したインスタンスと同じものを常に返します。
	 * @create 2007/03/22
	 * @return {@link GSessionManager}のシングルトンインスタンス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GSessionManager getSessionManager() {
		return GFrameworkUtils.getComponent(GSessionManager.class.getName());
	}
}
