/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.session;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GSessionManager}のデフォルト実装です.
 * 
 * @create 2005/03/23
 * @author kitamura
 * @since 3.0.0
 */
public class GSessionManagerImpl implements GSessionManager, HttpSessionListener {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GSessionManager.class);

	/** セッションプール. */
	private Map<String, GSession> sessionPool = new HashMap<String, GSession>();

	/**
	 * {@link GSessionManagerImpl}クラスの新しいインスタンスを初期化します.
	 * 
	 * @create 2005/03/23
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GSessionManagerImpl() {
	}

	/**
	 * 指定したセッションをセッションプールから解放します.
	 * 
	 * @create 2005/03/23
	 * @param session セッション
	 * @author kitamura
	 * @since 3.0.0
	 */
	void closeSession(GSession session) {
		if (session.isInvalid()) {
			return;
		}
		String id = session.getId();
		if (sessionPool.containsKey(id)) {
			sessionPool.remove(id);
			session.invalidate();
			LOGGER.info("Close Session : id=" + id);
		}
	}

	/**
	 * 指定したセッションを{@link HttpSession}内から削除します。<br />
	 * 
	 * @param session セッション
	 * @param httpSession HTTPセッション
	 */
	public void closeSession(GSession session, HttpSession httpSession) {
		closeSession(session);
	}
	
	/**
	 * 指定したHTTPセッションに関連づく{@link GSession}をセッションプールから取得します.<br>
	 * セッションプールに存在しない場合は、新規作成します。
	 * 
	 * @create 2005/04/01
	 * @param httpSession HTTPセッション
	 * @return {@link GSession}オブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public synchronized GSession getSession(HttpSession httpSession) {
		GSession session = null;
		String sessionID = httpSession.getId();
		if (sessionPool.containsKey(sessionID)) {
			session = sessionPool.get(sessionID);
		}
		else {
			session = createSession(sessionID);
		}
		return session;
	}

	/**
	 * {@link HttpSession}が作成されたことを通知します.<br>
	 * 何も実装されていません。
	 * 
	 * @see HttpSessionListener#sessionCreated(jakarta.servlet.http.HttpSessionEvent)
	 * @create 2005/03/25
	 * @param se 通知するイベント
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void sessionCreated(HttpSessionEvent se) {
	}

	/**
	 * {@link HttpSession}が無効になったことを通知します.<br>
	 * {@link HttpSession}に紐づく{@link GSession}をプーリングから削除します。
	 * 
	 * @see HttpSessionListener#sessionDestroyed(jakarta.servlet.http.HttpSessionEvent)
	 * @create 2005/03/25
	 * @param se 通知するイベント
	 * @author kitamura
	 * @since 3.0.0
	 */
	@SuppressWarnings("deprecation")
	public void sessionDestroyed(HttpSessionEvent se) {
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		HttpSession httpSession = se.getSession();
		GSession session = manager.getSession(httpSession);
		if (session != null) {
//			manager.closeSession(session);
			manager.closeSession(session, httpSession);
		}
	}

	/**
	 * IDを指定してセッションを生成します.<br>
	 * 引数には{@link HttpSession#getId()}よって取得されたIDを指定してください。
	 * 
	 * @create 2005/03/23
	 * @param id セッションに採番するID
	 * @return 生成されたセッションオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	@SuppressWarnings("deprecation")
	protected GSession createSession(String id) {
		GSession session = GFrameworkUtils.getComponent(GSession.class.getName());
		session.setId(id);
		session.setCreationTime(new Date());
		sessionPool.put(id, session);
		LOGGER.info("Create Session : id=" + id);
		return session;
	}

	/**
	 * セッションをプーリングしている{@link Map}を取得します.
	 * 
	 * @create 2005/03/23
	 * @return セッションをプーリングしている{@link Map}
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Map<String, GSession> getSessionPool() {
		return sessionPool;
	}
}
