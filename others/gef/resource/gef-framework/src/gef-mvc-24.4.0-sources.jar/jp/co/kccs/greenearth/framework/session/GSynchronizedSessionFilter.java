/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.session;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;

/**
 * リクエストの処理順序を{@link HttpSession}単位で同期化（シリアル化）するための{@link jakarta.servlet.Filter}です。<br>
 * {@link HttpSession}オブジェクトをsynchronizedしています。
 * 
 * @create 2009/07/24
 * @author kitamura
 * @since 3.6.0
 */
public class GSynchronizedSessionFilter extends GExcludableFilter {
	
	/**
	 * {@link GSynchronizedSessionFilter}インスタンスを初期化します。
	 * 
	 * @create 2009/07/24
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GSynchronizedSessionFilter() {
	}

	/**
	 * {@link HttpSession}を同期化する処理を行います。
	 * 
	 * @create 2009/07/24
	 * @see GExcludableFilter#doFilter(HttpServletRequest, HttpServletResponse, FilterChain)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain フィルターチェーン
	 * @throws IOException チェーン先の処理で例外が発生した場合
	 * @throws ServletException チェーン先の処理で例外が発生した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpSession session = request.getSession();
		synchronized (session) {
			chain.doFilter(request, response);
		}
	}

}
