/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;

/**
 * アクションで利用する操作を簡素化する機能を提供します.<br>
 *
 * @create 2007/03/07
 * @author fujikawa
 * @since 3.0.0
 */
public class GActionUtils {

	/** アクションIDを指定するパラメータキー名. */
	private static final String ACTION_ID_KEY = "actionid";

	/**
	 * Don't let anyone instantiate this class.
	 *
	 * @create 2007/03/07
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected GActionUtils() {
	}

	/**
	 * パラメータ{@link GParameter}に格納されている値を結果セット{@link GResultData}にコピーします.<br>
	 *
	 * @create 2007/07/12
	 * @param resultData 結果セット
	 * @param parameter パラメータ
	 * @author wang chenjun
	 * @since 3.2.0
	 */
	public static void copyValue(GResultData resultData, GParameter parameter) {
		copyValue(resultData, parameter, GCopyType.ALL_COPY);
	}

	/**
	 * パラメータ{@link GParameter}に格納されている値を、結果セット{@link GResultData}にコピーします.<br>
	 *
	 * copyTypeに{@link GCopyType#ALL_COPY}を指定した場合、全ての項目をコピーします。<br>
	 * copyTypeに{@link GCopyType#BLANK_TO_NULL}を指定した場合、空文字値を<code>null</code>に変換してコピーします。<br>
	 * copyTypeに{@link GCopyType#EXCEPT_BLANK}を指定した場合、空文字項目はコピーされません。br>
	 *
	 * @create 2007/07/12
	 * @param resultData 結果セット
	 * @param parameter パラメータ
	 * @param copyType コピータイプ
	 * @author wang chenjun
	 * @since 3.2.0
	 */
	public static void copyValue(GResultData resultData, GParameter parameter, GCopyType copyType) {
		if (resultData == null) {
			throw new NullPointerException("ResultData is null");
		} else if (parameter == null) {
			throw new NullPointerException("Parameter is null");
		} else {
			for (String key : parameter.valuesKeySet()) {
				String value = parameter.getValue(key);
				// 空文字無視
				if (copyType != GCopyType.EXCEPT_BLANK || !"".equals(value)) {
					if (copyType == GCopyType.BLANK_TO_NULL) {
						resultData.setData(key, GStringUtils.blankToNull(value));
					} else {
						resultData.setData(key, value);
					}
				}
			}
		}
	}

	/**
	 * 行データ{@link GRowData}に格納されている値を
	 * 結果セット{@link GResultData}にコピーします.<br>
	 *
	 * @create 2007/07/12
	 * @param resultData 結果セット
	 * @param rowData 行データ
	 * @author wang chenjun
	 * @since 3.2.0
	 */
	public static void copyValue(GResultData resultData, GRowData rowData) {
		copyValue(resultData, rowData, GCopyType.ALL_COPY);
	}

	/**
	 * 行データ{@link GRowData}に格納されている値を
	 * 結果セット{@link GResultData}にコピーします.<br>
	 * copyTypeに{@link GCopyType#ALL_COPY}を指定した場合、全ての項目をコピーします。<br>
	 * copyTypeに{@link GCopyType#BLANK_TO_NULL}を指定した場合、空文字値を<code>null</code>に変換してコピーします。<br>
	 * copyTypeに{@link GCopyType#EXCEPT_BLANK}を指定した場合、空文字項目はコピーされません。br>
	 *
	 * @create 2007/07/12
	 * @param resultData 結果セット
	 * @param rowData 行データ
	 * @param copyType コピータイプ
	 * @author wang chenjun
	 * @since 3.2.0
	 */
	public static void copyValue(GResultData resultData, GRowData rowData, GCopyType copyType) {
		if (resultData == null) {
			throw new NullPointerException("ResultData is null");
		} else if (rowData == null) {
			throw new NullPointerException("RowData is null");
		} else {
			for (String key : rowData.nameSet()) {
				Object value = rowData.getData(key);
				// 空文字無視
				if (copyType != GCopyType.EXCEPT_BLANK || !"".equals(value)) {
					if (copyType == GCopyType.BLANK_TO_NULL) {
						if (value != null && value instanceof String) {
							resultData.setData(key, GStringUtils.blankToNull(value.toString()));
						} else {
							resultData.setData(key, value);
						}
					} else {
						resultData.setData(key, value);
					}
				}
			}
		}
	}

	/**
	 * コピー元の結果セット{@link GResultData}のデータを
	 * コピー先の結果セット{@link GResultData}にコピーします.<br>
	 * 結果セット{@link GResultData}に含まれるエラーリストとダウンロードファイルはコピーしません.<br>
	 * @create 2007/08/23
	 * @param dest コピー先結果セット
	 * @param src コピー元結果セット
	 * @author murashige
	 * @since 3.3.0
	 */
	public static void copyData(GResultData dest, GResultData src) {
		if (dest == null) {
			throw new NullPointerException("ResultData is null");
		} else if (src == null) {
			throw new NullPointerException("OriginalResultData is null");
		} else {
			for (String key : src.dataNameSet()) {
				Object value = src.getData(key);
				dest.setData(key, value);
			}
		}
	}
}
