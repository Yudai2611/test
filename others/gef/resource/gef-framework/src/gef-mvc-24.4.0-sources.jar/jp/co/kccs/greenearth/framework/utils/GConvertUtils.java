/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.formatter.GBigDecimalFormatter;
import jp.co.kccs.greenearth.commons.formatter.GBigIntegerFormatter;
import jp.co.kccs.greenearth.commons.formatter.GBooleanFormatter;
import jp.co.kccs.greenearth.commons.formatter.GByteFormatter;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.formatter.GDoubleFormatter;
import jp.co.kccs.greenearth.commons.formatter.GFloatFormatter;
import jp.co.kccs.greenearth.commons.formatter.GIntegerFormatter;
import jp.co.kccs.greenearth.commons.formatter.GLongFormatter;
import jp.co.kccs.greenearth.commons.formatter.GMultiPatternDateFormatter;
import jp.co.kccs.greenearth.commons.formatter.GPropDateMultiPatternProvider;
import jp.co.kccs.greenearth.commons.formatter.GShortFormatter;


/**
 * 型変換に関するユーティリティクラスです.<br>
 *
 * [1]数値型への型変換メソッドを提供します。<br>
 * ・数値型クラス同士の型変換機能を提供します。<br>
 * ・文字列から数値型へ、ロケールを考慮したパース機能を提供します。<br>
 * [2]数値型及び、日付型への型変換メソッドを提供します。<br>
 * ・{@link java.util.Calendar}から{@link java.sql.Date}への型変換をサポートします。<br>
 * ・文字列から日付型へ、ロケールを意識したパース機能を提供します。<br>
 *
 *
 * @create 2007/04/19
 * @author aono
 * @since 3.0.0
 */
public final class GConvertUtils {

	private static GBigDecimalFormatter bigDecimalFormatter = null;
	private static GBigIntegerFormatter bigIntegerFormatter = null;
	private static GBooleanFormatter booleanFormatter = null;
	private static GByteFormatter byteFormatter = null;
	private static GDateFormatter dateFormatter = null;
	private static GDoubleFormatter doubleFormatter = null;
	private static GFloatFormatter floatFormatter = null;
	private static GIntegerFormatter integerFormatter = null;
	private static GLongFormatter longFormatter = null;
	private static GShortFormatter shortFormatter = null;
	
	/**
	 * Don't let anyone instantiate this class.
	 *
	 * @create 2007/03/27
	 * @author aono
	 * @since 3.0.0
	 */
	private GConvertUtils() {
	}

	/**
	 * コンテキストからロケールを取得します。<br>
	 * ロケールが<code>null</code>の場合はシステムロケールを返します。<br>
	 *
	 * @return {@link Locale}
	 * @create 2011/07/31
	 * @author KCCS murashige
	 * @since 3.9.0
	 */
	private static Locale getLocale() {
		Locale locale = GFrameworkContext.getInstance().getLocale();
		if (locale == null) {
			locale = Locale.getDefault();
		}
		return locale;
	}


	/**
	 * 指定された値を{@link BigDecimal}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GBigDecimalFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link BigDecimal}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static BigDecimal toBigDecimal(Object value) {
		if (value == null) {
			return null;
		}
		if (value instanceof String) {
			Locale locale = getLocale();
			return toBigDecimal((String) value, locale);
		}
		else if (value instanceof Number) {
			if (value instanceof BigDecimal) {
				return (BigDecimal) value;
			}
			else if (value instanceof BigInteger) {
				return new BigDecimal((BigInteger) value);
			}
			else if (value instanceof Double || value instanceof Float) {
				return new BigDecimal(((Number) value).doubleValue());
			}
			else {
				return new BigDecimal(((Number) value).longValue());
			}
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"BigDecimal\".");
		}
	}

	/**
	 * 指定された値を{@link BigDecimal}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GBigDecimalFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link BigDecimal}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static BigDecimal toBigDecimal(String value, Locale locale) {
		GBigDecimalFormatter formatter = getBigDecimalFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * 指定された値を{@link BigInteger}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GBigIntegerFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link BigInteger}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static BigInteger toBigInteger(Object value) {
		if (value == null) {
			return null;
		}
		if (value instanceof String) {
			Locale locale = getLocale();
			return toBigInteger((String) value, locale);
		}
		else if (value instanceof Number) {
			if (value instanceof BigInteger) {
				return (BigInteger) value;
			}
			else if (value instanceof BigDecimal) {
				return ((BigDecimal) value).toBigInteger();
			}
			else if (value instanceof Double || value instanceof Float) {
				return new BigDecimal(((Number) value).doubleValue()).toBigInteger();
			}
			else {
				return new BigDecimal(((Number) value).longValue()).toBigInteger();
			}
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"BigInteger\".");
		}
	}

	/**
	 * 指定された値を{@link BigInteger}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GBigIntegerFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link BigInteger}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static BigInteger toBigInteger(String value, Locale locale) {
		GBigIntegerFormatter formatter = getBigIntegerFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * 指定された値を<code>boolean</code>に変換して取得します.<br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GBooleanFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return <code>boolean</code>値
	 * @author aono
	 * @since 3.0.0
	 */
	public static boolean toBoolean(Object value) {
		if (value != null) {
			if (value instanceof String) {
				GBooleanFormatter formatter = getBooleanFormatter();
				try {
					return formatter.parse((String) value, getLocale());
				} catch (ParseException e) {
					throw new IllegalArgumentException("The type that corresponds to the specified value is not \"boolean\".");
				}
			}
			else if (value instanceof Boolean) {
				return (Boolean) value;
			}
			else {
				throw new ClassCastException("The type that corresponds to the specified value is not \"boolean\".");
			}
		}
		else {
			throw new IllegalArgumentException("The type that corresponds to the specified value is not \"boolean\".");
		}
	}

	/**
	 * 指定された値を{@link Byte}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GByteFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link Byte}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Byte toByte(Object value) {
		if (value == null) {
			return null;
		}
		if (value instanceof String) {
			Locale locale = getLocale();
			return toByte((String) value, locale);
		}
		else if (value instanceof Number) {
			return ((Number) value).byteValue();
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"Byte\".");
		}
	}

	/**
	 * 指定された値を{@link Byte}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GByteFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link Byte}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Byte toByte(String value, Locale locale) {
		GByteFormatter formatter = getByteFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * 指定されたオブジェクトを{@link Date}型オブジェクトに変換します.<br>
	 *
	 * [1]許容する型<br>
	 * {@link String}/{@link Date}/{@link Calendar}<br>
	 * <br>
	 * 変換規則<br>
	 * [1]{@link Date}型とその派生クラスが引数に渡された場合、引数と同一のインスタンスを返します。<br>
	 * [2]{@link Calendar}型とその派生クラスが引数に渡された場合、{@link Date}インスタンスを返します。<br>
	 * [3]{@link String}型が引数に渡された場合、<code>ge-framework.property</code>ファイルで定義された
	 * フォーマット文字列を元に、{@link Date}インスタンスを生成して返します。<br>
	 * [4]引数に渡された{@link String}型インスタンスで{@link Date}インスタンスが生成できなかった場合は、
	 * {@link ClassCastException}をスロウします。<br>
	 * [5]<code>null</code>又は空文字が渡された場合、<code>null</code>を返します。<br>
	 * [6]上記以外のインスタンスが渡された場合、{@link ClassCastException}をスロウします。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GDateFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2007/04/13
	 * @param value 変換元インスタンス
	 * @return {@link Date}型オブジェクト
	 * @author aono
	 * @since 3.0.0
	 */
	public static Date toDate(Object value) {
		if (value != null) {
			if (value instanceof Date) {
				return (Date) value;
			}
			else if (value instanceof Calendar) {
				return new Date(((Calendar) value).getTimeInMillis());
			}
			else if (value instanceof String) {
				Locale locale = getLocale();
				return toDate((String) value, locale);
			}
			else {
				throw new ClassCastException("The value that corresponds to the specified name is not \"Date\".");
			}
		}

		return null;
	}

	/**
	 * 指定されたオブジェクトを{@link Date}型オブジェクトに変換します.<br>
	 *
	 * [1]許容する型<br>
	 * {@link String}<br>
	 * <br>
	 * 変換規則<br>
	 * [1]{@link Date}型とその派生クラスが引数に渡された場合、引数と同一のインスタンスを返します。<br>
	 * [2]{@link Calendar}型とその派生クラスが引数に渡された場合、{@link Date}インスタンスを返します。<br>
	 * [3]{@link String}型が引数に渡された場合、<code>ge-framework.property</code>ファイルで定義された
	 * フォーマット文字列を元に、{@link Date}インスタンスを生成して返します。<br>
	 * [4]引数に渡された{@link String}型インスタンスで{@link Date}インスタンスが生成できなかった場合は、
	 * {@link ClassCastException}をスロウします。<br>
	 * [5]<code>null</code>又は空文字が渡された場合、<code>null</code>を返します。<br>
	 * [6]上記以外のインスタンスが渡された場合、{@link ClassCastException}をスロウします。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GDateFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2007/04/16
	 * @param value 変換対象文字列
	 * @param locale ロケール
	 * @return フォーマット付文字列
	 * @author aono
	 * @since 3.0.0
	 */
	public static Date toDate(String value, Locale locale) {
		GDateFormatter formatter = getDateFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 指定されたオブジェクトを{@link Date}型オブジェクトに変換します.<br>
	 *
	 * [1]許容する型<br>
	 * {@link String}<br>
	 * <br>
	 * 変換規則<br>
	 * [1]{@link Date}型とその派生クラスが引数に渡された場合、引数と同一のインスタンスを返します。<br>
	 * [2]{@link Calendar}型とその派生クラスが引数に渡された場合、{@link Date}インスタンスを返します。<br>
	 * [3]{@link String}型が引数に渡された場合、<code>ge-framework.property</code>ファイルで定義された
	 * フォーマット文字列を元に、{@link Date}インスタンスを生成して返します。<br>
	 * [4]引数に渡された{@link String}型インスタンスで{@link Date}インスタンスが生成できなかった場合は、
	 * {@link ClassCastException}をスロウします。<br>
	 * [5]<code>null</code>又は空文字が渡された場合、<code>null</code>を返します。<br>
	 * [6]上記以外のインスタンスが渡された場合、{@link ClassCastException}をスロウします。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GDateFormatter}の実装クラスを利用しています。<br>
	 * @deprecated {@link #toDate(String, Locale)}を利用してください。
	 * @create 2007/04/16
	 * @param value 変換対象文字列
	 * @param locale ロケール
	 * @param lenient 検証緩和フラグ
	 * @return フォーマット付文字列
	 * @author aono
	 * @since 3.0.0
	 */
	public static Date toDate(String value, Locale locale, boolean lenient) {
		GMultiPatternDateFormatter formatter = new GMultiPatternDateFormatter(new GPropDateMultiPatternProvider());
		try {
			return formatter.parse(value, locale, lenient);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 指定された値を{@link Double}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GDoubleFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link Double}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Double toDouble(Object value) {
		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			Locale locale = getLocale();
			return toDouble((String) value, locale);
		}
		else if (value instanceof Number) {
			return ((Number) value).doubleValue();
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"Double\".");
		}
	}

	/**
	 * 指定された値を{@link Double}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GDoubleFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link Double}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Double toDouble(String value, Locale locale) {
		GDoubleFormatter formatter = getDoubleFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * 指定された値を{@link Float}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GFloatFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link Float}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Float toFloat(Object value) {
		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			Locale locale = getLocale();
			return toFloat((String) value, locale);
		}
		else if (value instanceof Number) {
			return ((Number) value).floatValue();
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"Float\".");
		}
	}

	/**
	 * 指定された値を{@link Float}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GFloatFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link Float}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Float toFloat(String value, Locale locale) {
		GFloatFormatter formatter = getFloatFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * 指定された値を{@link Integer}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GIntegerFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link Integer}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Integer toInteger(Object value) {
		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			Locale locale = getLocale();
			return toInteger((String) value, locale);
		}
		else if (value instanceof Number) {
			return ((Number) value).intValue();
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"Integer\".");
		}
	}

	/**
	 * 指定された値を{@link Integer}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GIntegerFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link Integer}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Integer toInteger(String value, Locale locale) {
		GIntegerFormatter formatter = getIntegerFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * 指定された値を{@link Long}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GLongFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link Long}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Long toLong(Object value) {
		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			Locale locale = getLocale();
			return toLong((String) value, locale);
		}
		else if (value instanceof Number) {
			return ((Number) value).longValue();
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"Long\".");
		}
	}

	/**
	 * 指定された値を{@link Long}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GLongFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link Long}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Long toLong(String value, Locale locale) {
		GLongFormatter formatter = getLongFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * 指定された値を{@link Short}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * ・変換の際のロケールには、{@link GFrameworkContext#getLocale()}で取得されたロケールを使用します。<br>
	 * ・変換にはDIで定義されている{@link GShortFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @return {@link Short}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Short toShort(Object value) {
		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			Locale locale = getLocale();
			return toShort((String) value, locale);
		}
		else if (value instanceof Number) {
			return ((Number) value).shortValue();
		}
		else {
			throw new ClassCastException("The type that corresponds to the specified value is not \"Short\".");
		}
	}

	/**
	 * 指定された値を{@link Short}に変換して取得します.<br>
	 * [1]許容する型<br>
	 * <code>String</code>/<code>Number</code>型<br>
	 * [2]注意<br>
	 * 格納されている値の型が<code>null</code>又は空文字の場合は<code>null</code>が返されます。<br>
	 * <br>
	 * 補足事項<br>
	 * 変換にはDIで定義されている{@link GShortFormatter}の実装クラスを利用しています。<br>
	 *
	 * @create 2006/04/11
	 * @param value 値
	 * @param locale ロケール
	 * @return {@link Short}値
	 * @author aono
	 * @since 3.0.0
	 */
	public static Short toShort(String value, Locale locale) {
		GShortFormatter formatter = getShortFormatter();
		try {
			return formatter.parse(value, locale);
		} catch (ParseException e) {
			throw new NumberFormatException(e.getMessage());
		}
	}

	/**
	 * {@link GBigDecimalFormatter}を取得します.<br>
	 * 
	 * @return GBigDecimalFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GBigDecimalFormatter getBigDecimalFormatter() {
		if (bigDecimalFormatter == null){
			bigDecimalFormatter =  GFrameworkUtils.getComponent(GBigDecimalFormatter.class.getName());
		}
		return bigDecimalFormatter;
	}

	/**
	 * {@link GBigIntegerFormatter}を取得します.<br>
	 * 
	 * @return GBigIntegerFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GBigIntegerFormatter getBigIntegerFormatter() {
		if (bigIntegerFormatter == null){
			bigIntegerFormatter =  GFrameworkUtils.getComponent(GBigIntegerFormatter.class.getName());
		}
		return bigIntegerFormatter;
	}

	/**
	 * {@link GBooleanFormatter}を取得します.<br>
	 * 
	 * @return GBooleanFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GBooleanFormatter getBooleanFormatter() {
		if (booleanFormatter == null){
			booleanFormatter =  GFrameworkUtils.getComponent(GBooleanFormatter.class.getName());
		}
		return booleanFormatter;
	}

	/**
	 * {@link GByteFormatter}を取得します.<br>
	 * 
	 * @return GByteFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GByteFormatter getByteFormatter() {
		if (byteFormatter == null){
			byteFormatter =  GFrameworkUtils.getComponent(GByteFormatter.class.getName());
		}
		return byteFormatter;
	}

	/**
	 * {@link GDateFormatter}を取得します.<br>
	 * 
	 * @return GDateFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GDateFormatter getDateFormatter() {
		if (dateFormatter == null){
			dateFormatter =  GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		}
		return dateFormatter;
	}

	/**
	 * {@link GDoubleFormatter}を取得します.<br>
	 * 
	 * @return GDoubleFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GDoubleFormatter getDoubleFormatter() {
		if (doubleFormatter == null){
			doubleFormatter =  GFrameworkUtils.getComponent(GDoubleFormatter.class.getName());
		}
		return doubleFormatter;
	}

	/**
	 * {@link GFloatFormatter}を取得します.<br>
	 * 
	 * @return GFloatFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GFloatFormatter getFloatFormatter() {
		if (floatFormatter == null){
			floatFormatter =  GFrameworkUtils.getComponent(GFloatFormatter.class.getName());
		}
		return floatFormatter;
	}

	/**
	 * {@link GIntegerFormatter}を取得します.<br>
	 * 
	 * @return GIntegerFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GIntegerFormatter getIntegerFormatter() {
		if (integerFormatter == null){
			integerFormatter =  GFrameworkUtils.getComponent(GIntegerFormatter.class.getName());
		}
		return integerFormatter;
	}

	/**
	 * {@link GLongFormatter}を取得します.<br>
	 * 
	 * @return GLongFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GLongFormatter getLongFormatter() {
		if (longFormatter == null){
			longFormatter =  GFrameworkUtils.getComponent(GLongFormatter.class.getName());
		}
		return longFormatter;
	}

	/**
	 * {@link GShortFormatter}を取得します.<br>
	 * 
	 * @return GShortFormatter フォーマッター
	 * @author KCCS N.Nishimura
	 * @create 2015/03/30
	 * @since 3.15.0
	 */
	private static GShortFormatter getShortFormatter() {
		if (shortFormatter == null){
			shortFormatter =  GFrameworkUtils.getComponent(GShortFormatter.class.getName());
		}
		return shortFormatter;
	}

}
