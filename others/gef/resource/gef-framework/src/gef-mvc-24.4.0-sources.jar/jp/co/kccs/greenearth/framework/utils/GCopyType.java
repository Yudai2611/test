/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

/**
 * オブジェクト間のコピーのタイプを表します.
 * 
 * @create 2007/02/20
 * @author fujikawa
 * @since 3.0.0
 */
public enum GCopyType {
	/** 全ての項目をコピー. */
	ALL_COPY,
	/** 空文字値を<code>null</code>に変換してコピー. */
	BLANK_TO_NULL,
	/** 空文字項目はコピーしない. */
	EXCEPT_BLANK
}
