/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * Core Frameworkを利用するアプリケーションで共通する処理をまとめたユーティリティクラスです.
 * 
 * @create 2007/03/14
 * @author kitamura
 * @since 3.0.0
 */
public final class GCoreUtils {

//	/** リソース取得用デフォルトロケール. */
//	private static final Locale DEFAULT_LOCALE = new Locale("");

	/**
	 * Don't let anyone instantiate this class.
	 *
	 * @create 2007/04/06
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GCoreUtils() {
	}
	
	/**
	 * エラーメッセージを取得します.<br/>
	 * エラーメッセージが取得できない場合は、<code>null</code>値を返却します。<br/>
	 * 
	 * @create 2010/09/28
	 * @param code エラーコード
	 * @return エラーメッセージ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static GErrorMessage getErrorMessage(String code) {
		return GErrorMessages.getErrorMessage(code, GFrameworkContext.getInstance().getLocale());
	}
	
	/**
	 * ロケール文字列から{@link Locale}オブジェクトを取得します.
	 *
	 * @create 2011/06/24
	 * @param locale ロケール文字列
	 * @return
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static Locale getLocale(String locale) {
		GFrameworkContext context = GFrameworkContext.getInstance();
		return GStringUtils.isEmpty(locale) ? context.getLocale() : GLocaleUtils.getLocale(locale);
	}

//	/**
//	 * ログインしたロケールを取得します.<br>
//	 * ロケールが有効な状態にない場合は、サーバーロケールを返します。<br>
//	 *
//	 * <b>【ロケールが有効でない場合】</b>
//	 * [1]{@link GWebContext}にセッションが設定されていない（セッションが生成されていない）
//	 * [2]{@link GSession}が停止状態の場合
//	 * [3]{@link GSession}にロケールが設定されていない場合
//	 *
//	 * @deprecated 利用しないようにしてください。
//	 * @create 2007/04/19
//	 * @return ログインロケール
//	 * @author kitamura
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	public static Locale getLocale() {
//		GWebContext context = GWebContext.getInstance();
//		return getLocale(context.getSession());
//	}

//	/**
//	 * ログインしたロケールを取得します.<br>
//	 * ロケールが有効な状態にない場合は、サーバーロケールを返します。<br>
//	 *
//	 * <b>【ロケールが有効でない場合】</b>
//	 * [1]{@link GSession}が<code>null</code>の場合
//	 * [2]{@link GSession}が停止状態の場合
//	 * [3]{@link GSession}にロケールが設定されていない場合
//	 *
//	 * @deprecated 利用しないようにしてください。
//	 * @create 2007/04/19
//	 * @param session セッション
//	 * @return ログインロケール
//	 * @author kitamura
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	public static Locale getLocale(GSession session) {
//		Locale locale = Locale.getDefault();
//		if (session != null && !session.isInvalid() && session.getLocale() != null) {
//			locale = session.getLocale();
//		}
//		return locale;
//	}

//	/**
//	 * ログインしたロケールを取得します.<br>
//	 * ロケールが有効な状態にない場合は、リソース取得用のデフォルトロケール[<code>new Locale("")</code>]を返します。<br>
//	 *
//	 * <b>【ロケールが有効でない場合】</b>
//	 * [1]{@link GWebContext}にセッションが設定されていない（セッションが生成されていない）
//	 * [2]{@link GSession}が停止状態の場合
//	 * [3]{@link GSession}にロケールが設定されていない場合
//	 *
//	 * @deprecated 利用しないようにしてください。
//	 * @create 2007/04/19
//	 * @return ログインロケール
//	 * @author kitamura
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	public static Locale getLocaleForResource() {
//		GWebContext context = GWebContext.getInstance();
//		Locale locale = DEFAULT_LOCALE;
//		if (context.getLocale() != null) {
//			locale = context.getLocale();
//		}
//		return locale;
//	}

//	/**
//	 * ログインしたロケールを取得します.<br>
//	 * ロケールが有効な状態にない場合は、リソース取得用のデフォルトロケール[<code>new Locale("")</code>]を返します。<br>
//	 *
//	 * <b>【ロケールが有効でない場合】</b>
//	 * [1]{@link GWebContext}にセッションが設定されていない（セッションが生成されていない）
//	 * [2]{@link GSession}が停止状態の場合
//	 * [3]{@link GSession}にロケールが設定されていない場合
//	 *
//	 * @deprecated 利用しないようにしてください。
//	 * @create 2007/04/19
//	 * @param session セッション
//	 * @return ログインロケール
//	 * @author kitamura
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	public static Locale getLocaleForResource(GSession session) {
//		Locale locale = DEFAULT_LOCALE;
//		if (session != null && !session.isInvalid() && session.getLocale() != null) {
//			locale = session.getLocale();
//		}
//		return locale;
//	}
}
