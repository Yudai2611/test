/*
 * Copyright 2009-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;

/**
 * ダウンロードファイルを{@link HttpServletResponse}に書き込む処理を簡素化するユーティリティです。
 * 
 * @create 2009/07/24
 * @author kitamura
 * @since 3.6.0
 */
public class GFileDownloadUtils {
	
	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GFileDownloadUtils.class);
	
	/**
	 * インスタンス化させません。
	 * 
	 * @create 2009/07/24
	 * @auther kitamura
	 * @since 3.6.0
	 */
	private GFileDownloadUtils() {
	}

	/**
	 * 指定された{@link GDownloadFile}に該当するコンテントタイプを取得します。<br>
	 * {@link GDownloadFile}にコンテントタイプが指定されていればその値を、
	 * 指定されていなければ、{@link ServletContext}からファイル名に該当するMimeTypeを取得します。<br>
	 * {@link ServletContext}から取得されるMimeTypeはアプリケーションサーバーのMimeTypeの指定を参照してください。
	 * 
	 * @create 2009/07/24
	 * @param file ダウンロードファイル
	 * @param servletContext サーブレットコンテキスト
	 * @return コンテントタイプ
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static String getDownloadContentType(GDownloadFile file, ServletContext servletContext) {
		String contenttype = file.getContentType();
		if (contenttype == null && servletContext != null && file.getName() != null) {
			contenttype = servletContext.getMimeType(file.getName());
		}
		return contenttype;
	}
	
	/**
	 * 指定した{@link GDownloadFile}の情報を、{@link HttpServletResponse}に書き込みます。<br>
	 * 書き込みの際のバッファリングサイズは、指定した{@link GDownloadFile#getBufferSize()}が適用されます。<br>
	 * コンテントタイプは、{@link GDownloadFile}にコンテントタイプを指定した場合その値を、
	 * 指定していない場合は、引数に指定した{@link ServletContext}よりMimeTypeを取得し利用します。<br>
	 * 
	 * @create 2009/07/24
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param file ダウンロードファイル
	 * @throws IOException レスポンスの書き込みに失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static void writeResponse(HttpServletRequest request, HttpServletResponse response, GDownloadFile file) throws IOException {
		ServletOutputStream out = null;
		InputStream in = null;
		
		try {
			ServletContext servletContext = request.getSession().getServletContext();
			response.setContentType(getDownloadContentType(file, servletContext));
			if (file.getContentLength() != -1) {
				response.setHeader("Content-Length", String.valueOf(file.getContentLength()));
			}
			StringBuilder value = new StringBuilder();
			value.append(file.getDisplayType().toString());
			value.append("; ");
			value.append("filename*=utf-8''");
			value.append(getEncodeStringForPlusToSapce(file.getName()));

			response.setHeader("Content-disposition", value.toString());

			out = response.getOutputStream();
			in = file.getInputStream();
			int size;
			byte[] buffer = new byte[file.getBufferSize()];
			while ((size = in.read(buffer)) != -1) {
				out.write(buffer, 0, size);
				out.flush();
			}
		} catch (IOException e) {
			if (response.isCommitted()) {
				// キャンセルボタンが押されたときの処理
				LOGGER.warn("Download canceled. (" + e + ")");
			} else {
				// 例外処理
				throw e;
			}
		} finally {
			IOException ex = null;
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					ex = e;
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					ex = e;
				}
			}
			// ファイルの削除
			if (file != null) {
				file.delete();
			}
			if (null != ex) {
				throw ex;
			}
		}
	}

	/**
	 * 半角+を空白に変換します。<br/>
	 * 
	 * @param fileName ファイル名
	 * @return 半角+を空白にエンコードしたファイル名
	 * @throws UnsupportedEncodingException
	 * @author yangfeng
	 * @since 20.9.0
	 */
	static String getEncodeStringForPlusToSapce(String fileName) throws UnsupportedEncodingException {
		return URLEncoder.encode(GStringUtils.nullToBlank(fileName), "UTF-8").replaceAll("\\+", "%20");
	}

}
