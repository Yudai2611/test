/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import jp.co.kccs.greenearth.commons.GApplicationException;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;

/**
 * リクエストパラメータに禁止文字が含まれていた場合の例外を通知するクラスです.
 * 
 * @create 2010/09/10
 * @author yamashita
 * @since 3.9.0
 */
public class GProhibitionParameterException extends GApplicationException {

	// ----- 定数 -----------------------------------------------
	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4066720602379814507L;
	
	/**
	 * {@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException() {
	}

	/**
	 * エラーコード、メッセージを指定して{@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(String errorCode, String message) {
		super(errorCode, message);
	}
	
	/**
	 * エラーコード、メッセージ、エラータイプを指定して{@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(String errorCode, String message, GErrorType type) {
		super(errorCode, message, type);
	}

	/**
	 * エラーコード、メッセージ、エラータイプ、詳細情報を指定して{@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @param description 詳細情報
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(String errorCode, String message, GErrorType type, String description) {
		super(errorCode, message, type, description);
	}
	
	/**
	 * エラーコード、メッセージ、原因となった例外を指定して{@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param cause 原因となった例外
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}
	
	/**
	 * エラーコード、メッセージ、エラータイプ、原因となった例外を指定して{@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @param cause 原因となった例外
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(String errorCode, String message, GErrorType type, Throwable cause) {
		super(errorCode, message, type, cause);
	}
	
	/**
	 * エラーコード、メッセージ、エラータイプ、詳細情報、原因となった例外を指定して{@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param errorCode エラーコード
	 * @param message メッセージ
	 * @param type エラータイプ
	 * @param description 詳細情報
	 * @param cause 原因となった例外
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(String errorCode, String message, GErrorType type, String description, Throwable cause) {
		super(errorCode, message, type, description, cause);
	}
	
	/**
	 * エラーメッセージを指定して{@link GProhibitionParameterException}インスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param message エラーメッセージ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(GErrorMessage message) {
		this(message.getCode(), message.getMessage(), message.getType());
	}
	
	/**
	 * エラーメッセージリソース、詳細情報を指定し、{@link GProhibitionParameterException}のインスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param message エラーメッセージリソース
	 * @param description 詳細情報
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(GErrorMessage message, String description) {
		this(message.getCode(), message.getMessage(), message.getType(), description);
	}
	
	/**
	 * エラーメッセージリソース、原因となった例外を指定し、{@link GProhibitionParameterException}のインスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param message エラーメッセージリソース
	 * @param cause 原因となった例外
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(GErrorMessage message, Throwable cause) {
		this(message.getCode(), message.getMessage(), message.getType(), cause);
	}

	/**
	 * エラーメッセージリソース、詳細情報、原因となった例外を指定し、{@link GProhibitionParameterException}のインスタンスを初期化します.
	 * 
	 * @create 2010/09/08
	 * @param message エラーメッセージリソース
	 * @param description 詳細情報
	 * @param cause 原因となった例外
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GProhibitionParameterException(GErrorMessage message, String description, Throwable cause) {
		this(message.getCode(), message.getMessage(), message.getType(), description, cause);
	}
}
