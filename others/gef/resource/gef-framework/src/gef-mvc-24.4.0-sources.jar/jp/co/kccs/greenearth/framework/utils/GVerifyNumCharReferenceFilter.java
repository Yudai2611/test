/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFacadeFilter;
import jp.co.kccs.greenearth.framework.GResponseFilter;


/**
 * 数値文字参照の入力を禁止します.<br/>
 * リクエストパラメータ内の値に数値文字参照(10進表記 or 16進表記)が含まれた場合、その値をエラーとします。<br/>
 * ※文字実体参照(たとえば"&quot;"など)はチェック対象外です。<br/>
 * 
 * <br/><br/>
 * web.xml<br/>
 * {@link GVerifyProhibitionParameterFilter}は、{@link GFacadeFilter}, {@link GResponseFilter}の後に設定して下さい。<br/>
 * <pre>
 * &lt;filter&gt;
 *    &lt;filter-name&gt;VerifyNumCharReferenceFilter&lt;/filter-name&gt;
 *    &lt;filter-class&gt;jp.co.kccs.greenearth.framework.GVerifyNumCharReferenceFilter&lt;/filter-class&gt;
 *    &lt;init-param&gt;
 *       &lt;param-name&gt;error-code&lt;/param-name&gt;
 *       &lt;param-value&gt;GEF-000017&lt;/param-value&gt;
 *    &lt;/init-param&gt;
 * &lt;/filter&gt;
 * 
 * &lt;filter-mapping&gt;
 *    &lt;filter-name&gt;VerifyNumCharReferenceFilter&lt;/filter-name&gt;
 *    &lt;url-pattern&gt;*.view-action&lt;/url-pattern&gt;
 *    &lt;dispatcher&gt;REQUEST&lt;/dispatcher&gt;
 * &lt;/filter-mapping&gt; 
 * &lt;filter-mapping&gt;
 *    &lt;filter-name&gt;VerifyNumCharReferenceFilter&lt;/filter-name&gt;
 *    &lt;url-pattern&gt;*.jsp&lt;/url-pattern&gt;
 *    &lt;dispatcher&gt;REQUEST&lt;/dispatcher&gt;
 * &lt;/filter-mapping&gt; 
 * </pre>
 * 
 * <br/>
 * 
 * @create 2010/09/08
 * @author yamashita
 */
public class GVerifyNumCharReferenceFilter extends GVerifyProhibitionParameterFilter {

	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2010/09/08
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GVerifyNumCharReferenceFilter() {
	}

	/**
	 * 指定した文字列内に数値文字参照が含まれているかどうかを検証を行います.<br/>
	 * 含まれている場合、{@link GProhibitionParameterException}をスローします。<br/>
	 * "&#10進数;"または"&#16進数;"をそれぞれ数値文字参照と判断します。<br/>
	 * 
	 * @create 2010/09/10
	 * @see jp.co.kccs.greenearth.framework.utils.GVerifyProhibitionParameterFilter#verify(java.lang.String)
	 * @param value 検証値
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void verify(String value) {
        if (value == null || value.equals("")) {
            return;
        }
		boolean isNumCharReferenceMacher = GStringUtils.checkNumCharReference(value);
		if (isNumCharReferenceMacher) {
			throw createException();
		}
	}
}
