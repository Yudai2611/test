/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.Map;
import java.util.MissingResourceException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.filter.GExcludableFilter;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GFacadeFilter;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GResponseFilter;
import jp.co.kccs.greenearth.framework.GUploadFile;

/**
 * 禁止文字の入力を検証するフィルターです.<br/>
 * クエリパラメータとファイル名に対して検証を行います。<br/>
 * <br/><br/>
 * web.xml<br/>
 * {@link GVerifyProhibitionParameterFilter}は、{@link GFacadeFilter}, {@link GResponseFilter}の後に設定して下さい。<br/>
 * <pre>
 * &lt;filter&gt;
 *    &lt;filter-name&gt;FooFilter&lt;/filter-name&gt;
 *    &lt;filter-class&gt;sample.FooFilter&lt;/filter-class&gt;
 *    &lt;init-param&gt;
 *       &lt;param-name&gt;error-code&lt;/param-name&gt;
 *       &lt;param-value&gt;GEF-000017&lt;/param-value&gt;
 *    &lt;/init-param&gt;
 * &lt;/filter&gt;
 * 
 * &lt;filter-mapping&gt;
 *    &lt;filter-name&gt;FooFilter&lt;/filter-name&gt;
 *    &lt;url-pattern&gt;*&lt;/url-pattern&gt;
 * &lt;/filter-mapping&gt; 
 * </pre>
 * 
 * ※sample.FooFilterは{@link GVerifyProhibitionParameterFilter}を継承しています。<br/>
 * <br/>
 * 
 * @create 2010/09/08
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GVerifyProhibitionParameterFilter extends GExcludableFilter {

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000017";
	/** エラーコード. */
	private String _errorCode = DEFAULT_ERROR_CODE;

	/**
	 * デフォルトコンストラクタ.<br/>
	 * 
	 * @create 2010/09/08
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GVerifyProhibitionParameterFilter() {
	}

	/**
	 * 初期化パラメータより、エラーコード情報を読み取っています.<br>
	 * 検証エラー発生時は、error-codeパラメータに設定されているパラメータに基づいて例外をスローします。<br>
	 * 
	 * @create 2010/09/09
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#init(jakarta.servlet.FilterConfig)
	 * @param filterConfig フィルタ設定情報
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);
		String errorCode = filterConfig.getInitParameter("error-code");
		_errorCode = errorCode == null ? DEFAULT_ERROR_CODE : errorCode;
	}

	/**
	 * クエリパラメータとファイル名に対して禁止文字の検証を行います.<br/>
	 * 具体的な禁止文字の検証内容については、サブクラスに委ねられます。<br/>
	 * 検証エラーが発生した場合、{@link GProhibitionParameterException}をラップして{@link ServerException}をスローします。<br/>
	 * 
	 * @create 2010/09/09
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#doFilter(jakarta.servlet.http.HttpServletRequest, jakarta.servlet.http.HttpServletResponse, jakarta.servlet.FilterChain)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param chain フィルターチェーン
	 * @throws IOException 未認証時のエラーページ遷移に失敗した場合
	 * @throws ServletException 未認証時のエラーページ遷移に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
		GParameter parameter = (GParameter)request.getAttribute(GConstants.PARAMETER_KEY);
		try {
			verifyValues(parameter);
			verifyFiles(parameter);
		} catch (GProhibitionParameterException e) {
			throw new ServletException(e);
		}

		// Pass control on to the next filter
		chain.doFilter(request, response);
	}

	/**
	 * エラーコードを取得します.<br/>
	 * 
	 * @create 2010/09/08
	 * @return エラーコード
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getCode() {
		return _errorCode;
	}
	
	/**
	 * エラーコードを設定します.<br/>
	 * 
	 * @create 2010/09/08
	 * @param errorCode エラーコード
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setCode(String errorCode) {
		_errorCode = errorCode;
	}

	/**
	 * {@link GProhibitionParameterException}インスタンスを生成します.<br/>
	 * 
	 * @create 2010/09/09
	 * @return {@link GProhibitionParameterException}インスタンス
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected GProhibitionParameterException createException() {
		GErrorMessage errorMessage = GErrorMessages.getErrorMessage(getCode(), GFrameworkContext.getInstance().getLocale());
		if (errorMessage == null) {
			throw new MissingResourceException("Error message resource not found. key " + getCode(), this.getClass().getName(), getCode());
		}

		return new GProhibitionParameterException(errorMessage);
	}

	/**
	 * 指定した文字列内に禁止文字が含まれているかどうかを検証を行います.<br/>
	 * 
	 * @create 2010/09/09
	 * @param value 検証値
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected abstract void verify(String value);

	/**
	 * 指定したリクエストパラメータに設定されているファイル名に対して、禁止文字の検証を行います.<br/>
	 * 
	 * @create 2010/09/09
	 * @param parameter リクエストパラメータ
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void verifyFiles(GParameter parameter) {
		Map<String, GUploadFile[]> valuesMap = parameter.getFilesMap();
		for (Map.Entry<String, GUploadFile[]> pair : valuesMap.entrySet()) {
			GUploadFile[] values = pair.getValue();
			for (GUploadFile value : values) {
				verify(value.getName());
			}
		}
	}

	/**
	 * 指定したリクエストパラメータに設定されている値に対して、禁止文字の検証を行います.<br/>
	 * 
	 * @create 2010/09/09
	 * @param parameter リクエストパラメータ
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void verifyValues(GParameter parameter) {
		Map<String, String[]> valuesMap = parameter.getValuesMap();
		for (Map.Entry<String, String[]> pair : valuesMap.entrySet()) {
			String[] values = pair.getValue();
			for (String value : values) {
				verify(value);
			}
		}
	}
}
