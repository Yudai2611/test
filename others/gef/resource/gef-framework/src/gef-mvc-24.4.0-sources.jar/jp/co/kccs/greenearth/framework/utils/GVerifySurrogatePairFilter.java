/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.utils;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFacadeFilter;
import jp.co.kccs.greenearth.framework.GResponseFilter;

/**
 * サロゲートペア文字の入力を禁止します.<br/>
 * リクエストパラメータ内の値にサロゲートペア文字が含まれた場合、その値をエラーとします。<br/>
 * 
 * <br/><br/>
 * web.xml<br/>
 * {@link GVerifyProhibitionParameterFilter}は、{@link GFacadeFilter}, {@link GResponseFilter}の後に設定して下さい。<br/>
 * <pre>
 * &lt;filter&gt;
 *    &lt;filter-name&gt;VerifySurrogatePairFilter&lt;/filter-name&gt;
 *    &lt;filter-class&gt;jp.co.kccs.greenearth.framework.GVerifySurrogatePairFilter&lt;/filter-class&gt;
 *    &lt;init-param&gt;
 *       &lt;param-name&gt;error-code&lt;/param-name&gt;
 *       &lt;param-value&gt;GEF-000017&lt;/param-value&gt;
 *    &lt;/init-param&gt;
 * &lt;/filter&gt;
 * 
 * &lt;filter-mapping&gt;
 *    &lt;filter-name&gt;VerifySurrogatePairFilter&lt;/filter-name&gt;
 *    &lt;url-pattern&gt;*.view-action&lt;/url-pattern&gt;
 *    &lt;dispatcher&gt;REQUEST&lt;/dispatcher&gt;
 * &lt;/filter-mapping&gt; 
 * &lt;filter-mapping&gt;
 *    &lt;filter-name&gt;VerifySurrogatePairFilter&lt;/filter-name&gt;
 *    &lt;url-pattern&gt;*.jsp&lt;/url-pattern&gt;
 *    &lt;dispatcher&gt;REQUEST&lt;/dispatcher&gt;
 * &lt;/filter-mapping&gt; 
 * </pre>
 * 
 * <br/>
 * 
 * @create 2010/09/15
 * @author yamashita
 * @since 3.9.0
 */
public class GVerifySurrogatePairFilter extends GVerifyProhibitionParameterFilter {

	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2010/09/15
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GVerifySurrogatePairFilter() {
	}

	/**
	 * 指定した文字列内にサロゲートペア文字が含まれているかどうかを検証を行います.<br/>
	 * 含まれている場合、{@link GProhibitionParameterException}をスローします。<br/>
	 * 
	 * @create 2010/09/15
	 * @see jp.co.kccs.greenearth.framework.utils.GVerifyProhibitionParameterFilter#verify(java.lang.String)
	 * @param value 検証値
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void verify(String value) {
        if (value == null || value.equals("")) {
            return;
        }
		boolean isSurrogatePair = GStringUtils.checkSurrogatePair(value);
		if (isSurrogatePair) {  
			throw createException();
		}
	}
}
