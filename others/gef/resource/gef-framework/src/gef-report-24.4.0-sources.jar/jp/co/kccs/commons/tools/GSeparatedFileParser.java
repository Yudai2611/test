/*
 * Copyright 2004-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.commons.tools;

import java.util.ArrayList;
import java.util.List;

import org.apache.oro.text.perl.Perl5Util;
import org.apache.oro.text.regex.PatternMatcherInput;

/**
 * CSV/TSV形式のファイルの解析を行うクラスです。<BR>
 * 
 * @create 2004/09/01
 * @author kusakari
 * @since 0.3.0
 */
public class GSeparatedFileParser {

	/** Csv 正規表現 */
	private static final String PATTERN_CSV = "/(\"(?:[^\"]|\"\")*\"|[^,]*)/";
	/** Tsv 正規表現 */
	private static final String PATTERN_TSV = "/(\"(?:[^\"]|\"\")*\"|[^\t]*)/";
	/** CSV ファイル */
	public static final int TYPE_CSV = 0;
	/** TSV ファイル */
	public static final int TYPE_TSV = 1;
	/** 区切りパターン */
	private String _pattern = PATTERN_CSV;

	/** セパレートタイプ */
	private int _type = TYPE_CSV;

	/** 正規表現用制御オブジェクト */
	private Perl5Util _util = null;

	/**
	 * GTsvFileParserを初期化します。
	 * 
	 * @param type 
	 * @create 2004/09/01
	 * @author kusakari
	 * @since 0.3.0
	 */
	public GSeparatedFileParser(int type) {
		_util = new Perl5Util();
		_type = type;
		_pattern = getOptimazePattern(type);
	}
	
	/**
	 * タイプから適切なパターンを判断し返却します.<br>
	 * 
	 * @param type タイプ
	 * @return パターン
	 * @create 2015/03/04
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private String getOptimazePattern(int type) {

		if (type == TYPE_CSV) {
			return PATTERN_CSV;
		}
		
		if (type == TYPE_TSV) {
			return PATTERN_TSV;
		}

		throw new IllegalArgumentException("Illegal type : " + type);
	}

	/**
	 * 解析値を取得します。
	 * 
	 * @param value 
	 * @return value.replaceAll("\"\"", "\"")
	 * @create 2004/09/01
	 * @author kusakari
	 * @since 0.3.0
	 */
	protected String getParseValue(String value) {
		if (value.startsWith("\"") && value.endsWith("\"")) {
			value = value.substring(1, value.length() - 1);
		}
		return value.replaceAll("\"\"", "\"");
	}

	/**
	 * 解析パターンを取得します。
	 * 
	 * @return _pattern
	 * @create 2004/09/01
	 * @author kusakari
	 * @since 0.3.0
	 */
	public String getPattern() {
		return _pattern;
	}

	/**
	 * セパレートタイプを取得します。
	 * 
	 * @return _type
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 0.3.0
	 */
	public int getType() {
		return _type;
	}

	/**
	 * 与えられた文字列を解析します。
	 * 
	 * @param line 
	 * @return parse(line, 0, -1)
	 * @create 2004/09/01
	 * @author kusakari
	 * @since 0.3.0
	 */
	public String[] parse(String line) {
		return parse(line, 0, -1);
	}

	/**
	 * 与えられた文字列を解析します。
	 * 
	 * @param line 
	 * @param start_index 
	 * @param end_index 
	 * @return vals
	 * @create 2004/09/01
	 * @author kusakari
	 * @since 0.3.0
	 */
	public String[] parse(String line, int start_index, int end_index) {
		if (line == null || line.equals("")) {
			return null;
		}
		List<String> list = new ArrayList<String>();
		final PatternMatcherInput input = new PatternMatcherInput(line);


		while (_util.match(getPattern(), input)) {
			list.add(_util.group(1));
		}
		int count = list.size();
		if (end_index == -1) {
			end_index = count;
		}
		count = end_index - start_index;

		String[] vals = new String[count];
		int index = 0;
		for (int i = start_index; i < end_index; i++) {
			vals[index] = getParseValue(list.get(i).toString());
			index++;
		}
		return vals;
	}
}
