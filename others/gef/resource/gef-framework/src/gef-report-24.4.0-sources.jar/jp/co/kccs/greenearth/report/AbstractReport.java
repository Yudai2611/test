/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import jp.co.kccs.greenearth.report.repository.IReportInfo;
import jp.co.kccs.greenearth.report.repository.IRepositoryFactory;
import jp.co.kccs.greenearth.report.repository.ISectionInfo;

/**
 * 【役割】レポート抽象クラスです。<BR>
 * 【生成】生成されません。<BR>
 * 【解放】<BR>
 * 【備考】Setter を作らせたくないメソッドは GStdReportなどで実装しています。<BR>
 * 
 * @create 2004/06/02
 * @author kusakari
 * @since 1.0.1
 */
public abstract class AbstractReport implements IReport {

	/** 現在の行数または列数 */
	private int _line_count = 0;
	/** 印刷方向 */
	private int _print_direction = IReportInfo.PRINT_DIRECTION_VIRTICAL;
	/** 任意に帳票出力パスを指定しているかを表す値 */
	private boolean _is_specified_file_path = false;
	/** 任意に帳票出力パスを指定した場合のパス */
	private String _specified_file_path = null;
	/** ライター */
	private IReportWriter _writer = null;

	/** 静的なレポート情報 */
	private IReportInfo _static_info = null;
	
	/** 帳票情報を提供するファクトリ */
	private IRepositoryFactory repositoryFactory = null;


	/**
	 * レポートライターの初期化をします。
	 * 
	 * @see jp.co.kccs.greenearth.report.AbstractReport#init(jp.co.kccs.greenearth.report.IReportWriter)
	 * @param writer レポートライター
	 * @throws GReportException Report Framework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public void init(IReportWriter writer) throws GReportException {
		setWriter(writer);
	}
	
	/**
	 * レポート情報を設定します。<BR>
	 * 
	 * @param reportInfo レポート情報
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void setReportInfo(IReportInfo reportInfo) {
		_static_info = reportInfo;
	}

	/**
	 * レポート情報を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReport#getReportInfo()
	 * @return レポート情報
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public IReportInfo getReportInfo() {
		return _static_info;
	}
	
	/**
	 * レポートライターを設定します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReport#setWriter(jp.co.kccs.greenearth.report.IReportWriter)
	 * @param writer レポートライター
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public void setWriter(IReportWriter writer) {
		_writer = writer;
	}
	
	/**
	 * レポートライターを取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReport#getWriter()
	 * @return	 レポートライター
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public IReportWriter getWriter() {
		if (_writer == null) {
			throw new GReportRuntimeException("the report writer have to be set up.");
		}
		return _writer;
	}

	/**
	 * 任意に帳票出力パスを指定しているかを表す値を取得します。<BR>
	 * 
	 * @return 真偽値
	 * @create 2006/03/21
	 * @author kitamura
	 * @since 1.1.0
	 */
	public boolean isSpecifiedFilePath() {
		return _is_specified_file_path;
	}

	/**
	 * 任意に帳票出力パスを指定しているかを表す値を設定します。<BR>
	 * 
	 * @param is_specified 真偽値
	 * @create 2006/03/21
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setIsSpecifiedFilePath(boolean is_specified) {
		_is_specified_file_path = is_specified;
	}

	/**
	 * 任意に帳票出力パスを指定した場合のパスを取得します。<BR>
	 * 
	 * @return ファイルパス
	 * @create 2006/03/21
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getSpecifiedFilePath() {
		return _specified_file_path;
	}

	/**
	 * 出力先のファイルパスを取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReport#getOutputFilePath()
	 * @return ファイルパス
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public String getOutputFilePath() {
		return getSpecifiedFilePath();
	}

	/**
	 * 任意に帳票出力パスを指定する場合のパスを設定します。<BR>
	 * 
	 * @param file_path ファイルパス
	 * @create 2006/03/21
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setSpecifiedFilePath(String file_path) {
		_specified_file_path = file_path;
		setIsSpecifiedFilePath(true);
	}

	/**
	 * 出力先のファイルパスを取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReport#setOutputFilePath(java.lang.String)
	 * @param outputFilePath ファイルパス
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public void setOutputFilePath(String outputFilePath) {
		setSpecifiedFilePath(outputFilePath);
	}

	/**
	 * 【機能】指定行数改行を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param count 行数
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public void addLineCount(int count) {
		_line_count += count;
	}

	/**
	 * 【機能】現在の行数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 現在行数
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public int getLineCount() {
		return _line_count;
	}

	/**
	 * 【機能】印刷方向を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 印刷方向
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public int getPrintDirection() {
		return _print_direction;
	}

	/**
	 * 【機能】レポート情報が初期化される際、呼び出される拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】印刷前に設定しておきたい処理を記述して下さい。<BR>
	 * 
	 * @throws GReportException ReportFrameowrk例外
	 * @create 2004/07/01
	 * @author
	 * @since 1.0.2
	 */
	public void initReportInfo() throws GReportException {
	}

	/**
	 * 【機能】指定行へ移動します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param count 行数
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public void setLineCount(int count) {
		_line_count = count;
	}

	/**
	 * 【機能】印刷方向を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>内部的に setLineCount(0) が呼び出されます。</B><BR>
	 * 
	 * @param direction 印刷方向
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void setPrintDirection(int direction) {
		setLineCount(0);
		_print_direction = direction;
	}

	/**
	 * 【機能】他の帳票レイアウト上のセクションを自身に追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】他の帳票レイアウトに同じ名前のセクションが定義されていてもマージされず、レポートID毎に紐付けられます。<BR>
	 * これにより、複数のレイアウトを切り替えながら帳票を出力可能となります。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReport#appendSections(java.lang.String)
	 * @param report_id レポートID
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public void appendSections(String report_id) throws GReportException {
		IReportInfo reportInfo = getRepositoryFactory().get(report_id);
		ISectionInfo[] sectionInfos = reportInfo.getSectionInfos();
		getReportInfo().appendSections(report_id, sectionInfos);
	}
	
	/**
	 * 帳票情報を提供するファクトリを取得します.
	 * 
	 * @return IRepositoryFactory 帳票情報を提供するファクトリ
	 * @create 2015/03/30
	 * @author KCCS hashimoto
	 * @since 3.15.0
	 */
	protected IRepositoryFactory getRepositoryFactory() {
		if (repositoryFactory == null) {
			repositoryFactory = IRepositoryFactory.Factory.getInstance();
		}
		return repositoryFactory;
	}
}
