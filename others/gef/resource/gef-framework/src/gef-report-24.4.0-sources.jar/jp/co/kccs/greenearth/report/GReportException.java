/*
 * Copyright 2014-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

/**
 * ReportFrameowrkで取り扱われる共通例外です。<BR>
 * ReportFramework内で発生した例外は基本的にはGReportExceptionに格納されて取り扱われます。
 *
 * @create 2006/01/26
 * @author kitamura
 * @since 1.1.0
 */
public class GReportException extends Exception {

	/** serial version */
	private static final long serialVersionUID = 1362105808420558438L;

	/**
	 * 詳細メッセージに <code>null</code> を使用して、新しい実行時例外を構築します。
	 *
	 * @create 2006/01/26
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GReportException() {
		super();
	}

	/**
	 * 指定された詳細メッセージを使用して、新しい実行時例外を構築します。
	 *
	 * @param message メッセージ
	 * @create 2006/01/26
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GReportException(final String message) {
		super(message);
	}

	/**
	 * 指定された詳細メッセージおよび原因を使用して新しい実行時例外を構築します。
	 *
	 * @param message メッセージ
	 * @param cause 例外原因
	 * @create 2006/01/26
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GReportException(final String message, final Throwable cause) {
		super(message, cause);
	}

	/**
	 * <tt>(cause==null ? null : cause.toString())</tt>
	 * の指定された原因および詳細メッセージを使用して新しい実行時例外を構築します。
	 *
	 * @param cause 例外原因
	 * @create 2006/01/26
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GReportException(final Throwable cause) {
		super(cause);
	}
}
