/*
 * Copyright 2014-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

/**
 * レポートを生成するファクトリーを表します。<br>
 *
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public class GReportFactory {

	/**
	 * ライターを取得します。<br>
	 *
	 * @param <T> ライタークラス
	 * @param writerClazz ライタークラス
	 * @return ライター
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/10
	 * @author KCCS yamashita
	 * @since 2.0.0
	 */
	private static <T extends IReportWriter> T get(Class<T> writerClazz) throws GReportException {
		try {
			return (T) writerClazz.newInstance();
		} catch (IllegalAccessException | InstantiationException e) {
			throw new GReportException("error at creating report writer class.", e);
		}
	}

	/**
	 * レポートを取得します。<br>
	 *
	 * @param <T> 帳票クラス
	 * @param reportClazzName 帳票クラス名
	 * @param writer ライター
	 * @return レポート
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public static <T extends IReport> T get(String reportClazzName, IReportWriter writer) throws GReportException {
		try {
			@SuppressWarnings("unchecked")
			T report = (T) Class.forName(reportClazzName).newInstance();
			report.init(writer);
			return report;
		} catch (IllegalAccessException | InstantiationException | ClassNotFoundException e) {
			throw new GReportException("create report error.", e);
		}
	}

	/**
	 * レポートを取得します。<br>
	 *
	 * @param <T> 帳票クラス
	 * @param reportClazz 帳票クラス
	 * @param writerClazz ライタークラス
	 * @return レポート
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public static <T extends IReport> T get(Class<T> reportClazz, Class< ? extends IReportWriter> writerClazz) throws GReportException {
		return get(reportClazz.getName(), get(writerClazz));
	}

	/**
	 * レポートを取得します。<br>
	 *
	 * @param <T> 帳票クラス
	 * @param reportClazz レポートクラス
	 * @param writerClazz ライタークラス
	 * @param outputFilePath 出力ファイルパス
	 * @return レポート
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public static <T extends IReport> T get(Class<T> reportClazz, Class< ? extends IReportWriter> writerClazz, String outputFilePath) throws GReportException {
		T report = get(reportClazz, writerClazz);
		report.setOutputFilePath(outputFilePath);
		return report;
	}
}
