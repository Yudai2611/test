/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

/**
 * 実行時例外クラスです.
 * 
 * @create
 * @author KCCS
 * @since 1.0.0
 */
public class GReportRuntimeException extends RuntimeException {

	/** シリアルバージョンID */
	private static final long serialVersionUID = -84000012499421906L;

	/**
	 * コンストラクタ.<br>
	 * 
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public GReportRuntimeException() {
		super();
	}

	/**
	 * コンストラクタ.<br>
	 * 
	 * @param message メッセージ
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public GReportRuntimeException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ.<br>
	 * 
	 * @param cause 例外原因
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public GReportRuntimeException(Throwable cause) {
		super(cause);
	}

	/**
	 * コンストラクタ.<br>
	 * 
	 * @param message メッセージ
	 * @param cause 例外原因
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public GReportRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

}
