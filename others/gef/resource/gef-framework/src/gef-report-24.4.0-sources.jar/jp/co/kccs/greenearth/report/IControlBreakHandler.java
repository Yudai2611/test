/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import jp.co.kccs.greenearth.report.repository.IControlBreakInfo;

/**
 * 【役割】コントロールブレイクマネージャインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IControlBreakHandler {

	/**
	 * 【機能】ブレイク情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR
	 * >
	 * @param break_info ブレイクキー情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setBreakInfo(IControlBreakInfo[] break_info);

	/**
	 * 【機能】ブレイク情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return ブレイクキー情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IControlBreakInfo[] getBreakInfo();

	/**
	 * 【機能】レポート参照を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param report レポート
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setReport(IReport report);

	/**
	 * 【機能】現在のレコードでキーブレイクが起こればキーブレイクイベントを発生させます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param record IReportRecord
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void keyBreak(IReportRecord record) throws GReportException;

	/**
	 * 【機能】次のレコードのブレイクキー名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 次のレコードのブレイクキー名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getNextBreakKeyName();

	/**
	 * 【機能】次のレコードでキーブレイクが起こるか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】優先順位が高いブレイクキーでブレイクします。<BR>
	 * 最後のレコードでは優先順位一位のキーでキーブレイクが発生します。<BR>
	 * 
	 * @param record IReportRecord
	 * @return 次のレコードでキーブレイクが起こるかの真偽値
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean nextKeyBreak(IReportRecord record) throws GReportException;

	/**
	 * 【機能】指定キーブレイクの一つ前の値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param break_key_name ブレイクキー
	 * @return 前回のキーブレイク値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getPreBreakValue(String break_key_name);

	/**
	 * 【機能】抑止値をフィールド名指定で削除します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param field_name フィールド名
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void removeOmitValue(String field_name);

	/**
	 * 【機能】抑止値をクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void clearOmitValue();

	/**
	 * 【機能】以前のブレイク情報をクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void clear();
}
