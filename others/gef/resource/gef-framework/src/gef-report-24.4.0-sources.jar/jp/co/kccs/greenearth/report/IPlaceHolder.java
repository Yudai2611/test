/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

/**
 * 【役割】プレースホルダインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IPlaceHolder {

	/**
	 * 【機能】セクションのプリントに必要な情報を保持します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param line_cnt 現在行
	 * @param section IReportSection
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setParamters(int line_cnt, IReportSection section);

	/**
	 * 【機能】このプレースホルダを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void print() throws GReportException;
}
