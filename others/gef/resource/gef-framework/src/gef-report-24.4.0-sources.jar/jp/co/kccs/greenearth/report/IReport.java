/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import java.io.File;

import jp.co.kccs.greenearth.report.repository.IReportInfo;

/**
 * 【役割】レポートインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReport {

	/**
	 * 【機能】セクションを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param section_name セクション名称
	 * @return セクション
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportSection getSection(String section_name) throws GReportException;

	/**
	 * 【機能】改ページを行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void pageBreak() throws GReportException;

	/**
	 * 【機能】IReportListからレポートの印刷を行います。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @param list_data IReportList
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void print(IReportList list_data) throws GReportException;

	/**
	 * 【機能】レポートの印刷を行います。<BR>
	 * 【呼出】アクションビーン<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void print() throws GReportException;

	/**
	 * 【機能】現在のレコードを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return レポートレコード
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportRecord getCurrentRecord();

	/**
	 * 【機能】レポートファイルを取得します。<BR>
	 * 【呼出】アクションビーン<BR>
	 * 【備考】<BR>
	 * 
	 * @return ファイル
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	File getFile();

	/**
	 * 【機能】各ページの終わりに呼ばれる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】フッターの印刷や小計値の印刷などにご利用下さい。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void endPage() throws GReportException;

	/**
	 * 【機能】レポートの印刷終了時に一度だけ呼ばれる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】合計値の出力や印刷終了時に行い処理などにご利用下さい。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void endReport() throws GReportException;

	/**
	 * 【機能】レコード毎に呼び出されるメインの実行ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】明細の印刷などにご利用下さい。<BR>
	 * 
	 * @param record レポートレコード
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void execute(IReportRecord record) throws GReportException;

	/**
	 * 【機能】現在のレコードがキーブレイクする場合、呼ばれる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】現在のレコードでキーブレイクが起こった場合の処理の記述にご利用下さい。<BR>
	 * 
	 * @param key_name ブレイクキー名
	 * @param record レポートレコード
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void keyBreak(String key_name, IReportRecord record) throws GReportException;

	/**
	 * 【機能】次のレコードがキーブレイクする場合、呼ばれる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】次のレコードでキーブレイクが起こった場合の処理の記述にご利用下さい。<BR>
	 * 
	 * @param key_name ブレイクキー名
	 * @param record レポートレコード
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void nextKeyBreak(String key_name, IReportRecord record) throws GReportException;

	/**
	 * 【機能】レコード読み込み後に呼ばれる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】execute(IReportRecord)が呼ばれる直前に呼び出されます。レコードへの値の設定などにご利用下さい。<BR>
	 * 
	 * @param record レポートレコード
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void postGetData(IReportRecord record) throws GReportException;

	/**
	 * 【機能】各ページの開始時に呼ばれる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】ヘッダーの印刷やページごとの初期化処理などにご利用下さい。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void startPage() throws GReportException;

	/**
	 * 【機能】レポート印刷開始時に一度だけ呼ばれる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】セクションの取得や、フォーマットの設定、不変の値の設定などにご利用下さい。。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void startReport() throws GReportException;

	/**
	 * 【機能】他の帳票レイアウト上のセクションを自身に追加します。BR> 【戻値】<BR>
	 * 【備考】他の帳票レイアウトに同じ名前のセクションが定義されていてもマージされず、レポートID毎に紐付けられます。<BR>
	 * これにより、複数のレイアウトを切り替えながら帳票を出力可能となります。<BR>
	 * 
	 * @param report_id 他の帳票レイアウトのレポートID
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void appendSections(String report_id) throws GReportException;

	/**
	 * 【機能】他の帳票レイアウトから自身に追加したセクションを取得します。BR> 【戻値】<BR>
	 * 【備考】予め、IReport#appendSectionsによりセクションを追加しておく必要があります。<BR>
	 * レポートIDとして自身のレイアウトのレポートIDを指定しても構いません。<BR>
	 * 
	 * @param report_id 他の帳票レイアウトのレポートID
	 * @param section_name セクション名
	 * @return セクション
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportSection getSection(String report_id, String section_name) throws GReportException;
	
	/**
	 * 帳票出力パスを設定します。<br>
	 * 
	 * @param outputFilePath String
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOutputFilePath(String outputFilePath);

	/**
	 * 帳票出力パスを取得します。<br>
	 * 
	 * @return 帳票出力パス
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getOutputFilePath();

	/**
	 * ライターをセットします。<br>
	 * 
	 * @param writer ライター
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setWriter(IReportWriter writer);
	
	/**
	 * ライターを取得します。<br>
	 * 
	 * @return レポートライター
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportWriter getWriter();

	/**
	 * レポート情報を取得します。<br>
	 * 
	 * @return レポート情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportInfo getReportInfo();

	/**
	 * レポートライターの初期化をします。
	 * 
	 * @see jp.co.kccs.greenearth.report.AbstractReport#init(jp.co.kccs.greenearth.report.IReportWriter)
	 * @param writer レポートライター
	 * @throws GReportException Report Framework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void init(IReportWriter writer) throws GReportException;
}
