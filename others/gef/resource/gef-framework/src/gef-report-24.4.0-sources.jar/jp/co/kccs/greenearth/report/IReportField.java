/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import java.awt.Color;

import jp.co.kccs.greenearth.report.repository.IFieldInfo;

/**
 * 【役割】フィールドインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReportField extends IFieldInfo {

	/** 許可値 */
	static final int TYPE_PERMISSION_VALUE = 0;
	/** 許可値名称 */
	static final int TYPE_PERMISSION_NAME = 1;
	/** 許可値・名称 */
	static final int TYPE_PERMISSION_BOTH = 2;

	/**
	 * 【機能】初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】すべての設定が初期化されます。<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void initialize();

	/**
	 * 情報をロードします。<br>
	 * 
	 * @param info フィールド情報
	 * @param section セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(IFieldInfo info, IReportSection section);

	/**
	 * 【機能】文字列長に合わせて長さが動的に変化するアンダーラインを生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】フィールド内部にアンダーラインが生成されます。<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void createUnderLine();

	/**
	 * 【機能】アンダーラインを消去します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】フィールド内部のアンダーラインを消去します。<BR>

	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void removeUnderLine();

	/**
	 * 【機能】このフィールドを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void print() throws GReportException;
	
	/**
	 * 【機能】セクションプレースホルダを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】このメソッドが呼び出されるまでに、このフィールド名で設定されているすべてのプレースホルダに値を印刷します。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2015/03/06
	 * @author KCSS LiuXunan
	 * @since 2.0.0
	 */
	void printPlaceHolder() throws GReportException;

	/**
	 * 【機能】プレースホルダに値を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】このメソッドが呼び出されるまでに、このフィールド名で設定されているすべてのプレースホルダに値を印刷します。<BR>
	 * 
	 * @param place_holder_value 値
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void printPlaceHolder(Object place_holder_value) throws GReportException;

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getName()
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	String getName();

	/**
	 * 【機能】表示/非表示を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getOutput()
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	boolean getOutput();

	/**
	 * 【機能】左端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getLeft()
	 * @return 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	int getLeft();

	/**
	 * 【機能】高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getHeight()
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	int getHeight();

	/**
	 * 【機能】上端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getTop()
	 * @return 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	int getTop();

	/**
	 * 【機能】幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getWidth()
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	int getWidth();

	/**
	 * 【機能】タイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getType()
	 * @return タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	String getType();

	/**
	 * 【機能】値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getValue()
	 * @return 値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	String getValue();

	/**
	 * 【機能】アンダーラインを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getUnderLine()
	 * @return アンダーライン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	IReportLine getUnderLine();

	/**
	 * 【機能】複数行フラグを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getMultiLine()
	 * @return フラグ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	boolean getMultiLine();

	/**
	 * 【機能】高さを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param height 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setHeight(int height);

	/**
	 * 【機能】幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param width 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setWidth(int width);

	/**
	 * 【機能】上端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param top 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTop(int top);

	/**
	 * 【機能】左端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param left 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setLeft(int left);

	/**
	 * 【機能】背景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param color カラー
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setBackGroundColor(Color color);

	/**
	 * 【機能】前景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param color カラー
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setForeColor(Color color);

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param output 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOutput(boolean output);

	/**
	 * 【機能】プレースホルダを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>プレースホルダは同名のフィールド全てに設定することは出来ません。</B><BR>
	 * プレースホルダを設定する場合、レポート全体で一意なフィールド名である必要があります。<BR>
	 * フィールド名が一意でない場合、予期しない動作をする場合があるので注意してください。<BR>
	 * ----------------------------------------------------------------------<BR>
	 * ■使い方<BR>
	 * <BR>
	 * ①<CODE>IReportField#setPlaceHolder()</CODE>により指定フィールドにプレースホルダを設定します。<BR>
	 * ②プレースホルダを設定したフィールドを含むセクションを印刷します。<BR>
	 * ③<CODE>IReportField#printPlaceHolder(Object)</CODE>によりプレースホルダに値を書き込みます。<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setPlaceHolder();

	/**
	 * 【機能】値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param value 値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setValue(Object value);

	/**
	 * 【機能】日付フォーマットを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>一度設定するとレポート出力終了まで保持されます。</B><BR>
	 * 同じ名前のフィールドすべてに反映されます。<BR>
	 * 
	 * @param in_format 入力フォーマット
	 * @param out_format 出力フォーマット
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setDateFormat(String in_format, String out_format);

	/**
	 * 【機能】数値フォーマットを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>一度設定するとレポート出力終了まで保持されます。</B><BR>
	 * 同じ名前のフィールドすべてに反映されます。<BR>
	 * 
	 * @param format フォーマット
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setDecimalFormat(String format);

	/**
	 * 【機能】許可値表示タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>フィールドのタイプが Data でなければ許可値表示タイプを設定出来ません。</B><BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param type 表示タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public void setPermissionDisplayType(int type);

	/**
	 * 【機能】複数行フラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param flag フラグ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setMultiLine(boolean flag);
}
