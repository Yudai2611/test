/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import jp.co.kccs.greenearth.report.repository.IBarcodeInfo;
import jp.co.kccs.greenearth.report.repository.IImageInfo;

/**
 * 【役割】イメージインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReportImage {

	/**
	 * 【機能】バーコードタイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードタイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getBarcodeType();

	/**
	 * 【機能】バーコード固有の情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコード固有情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IBarcodeInfo getBarcodeInfo();

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 【機能】左端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getLeft();

	/**
	 * 【機能】高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getHeight();

	/**
	 * 【機能】上端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getTop();

	/**
	 * 【機能】幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getWidth();

	/**
	 * 【機能】高さを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param height 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setHeight(int height);

	/**
	 * 【機能】幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param width 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setWidth(int width);

	/**
	 * 【機能】上端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param top 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTop(int top);

	/**
	 * 【機能】左端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param left 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setLeft(int left);

	/**
	 * 【機能】表示/非表示を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getOutput();

	/**
	 * 【機能】タイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getType();

	/**
	 * 【機能】値を取得します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @return 値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getValue();

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param output 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOutput(boolean output);

	/**
	 * 【機能】値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param value 値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setValue(Object value);

	/**
	 * プレースホルダを印刷します。<br>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void printPlaceHolder() throws GReportException;

	/**
	 * 印刷します。<br>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void print() throws GReportException;

	/**
	 * 情報をロードします。<br>
	 * 
	 * @param info イメージ情報
	 * @param section セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(IImageInfo info, IReportSection section);
}
