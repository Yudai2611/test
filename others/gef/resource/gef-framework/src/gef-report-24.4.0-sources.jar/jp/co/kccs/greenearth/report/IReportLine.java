/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import java.awt.Color;

import jp.co.kccs.greenearth.report.repository.ILineDashInfo;
import jp.co.kccs.greenearth.report.repository.ILineInfo;

/**
 * 【役割】ラインインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReportLine {

	/**
	 * 情報をロードします。<br>
	 * 
	 * @param info ライン情報
	 * @param section セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(ILineInfo info, IReportSection section);

	/**
	 * プレースホルダを印刷します。<br>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void printPlaceHolder() throws GReportException;

	/**
	 * 印刷します。<br>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void print() throws GReportException;

	/**
	 * 【機能】カラーを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return カラー
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	Color getColor();

	/**
	 * 【機能】点線情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 点線情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	ILineDashInfo getDashInfo();

	/**
	 * 【機能】点線の間隔を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<b>GLineInfo.TYPE_DASH は setDash(4, 2)、GLineInfo.TYPE_DOT は
	 * setDash(2, 2)にそれぞれ相当します。</b><BR>
	 * 
	 * @param units_on オンの間隔
	 * @param phase フェーズ値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setDash(int units_on, int phase);

	/**
	 * 【機能】ライン幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return ライン幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	double getLineWidth();

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 【機能】表示/非表示を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getOutput();

	/**
	 * 【機能】タイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getType();

	/**
	 * 【機能】左端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getLeft();

	/**
	 * 【機能】高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getHeight();

	/**
	 * 【機能】上端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getTop();

	/**
	 * 【機能】幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getWidth();

	/**
	 * 【機能】カラーを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param color カラー
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setColor(Color color);

	/**
	 * 【機能】高さを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param height 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setHeight(int height);

	/**
	 * 【機能】幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param width 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setWidth(int width);

	/**
	 * 【機能】上端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param top 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTop(int top);

	/**
	 * 【機能】左端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドすべてに反映されます。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param left 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setLeft(int left);

	/**
	 * 【機能】ライン幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param line_width ライン幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setLineWidth(double line_width);

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param output 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOutput(boolean output);

	/**
	 * 【機能】タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param type タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setType(int type);

	/**
	 * 【機能】二重線フラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param flag フラグ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setDouble(boolean flag);

	/**
	 * 【機能】二重線フラグを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フラグ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getDouble();
}
