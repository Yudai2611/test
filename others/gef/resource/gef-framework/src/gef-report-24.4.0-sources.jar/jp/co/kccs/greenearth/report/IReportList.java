/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

/**
 * 【役割】レポートリストインターフェースを表します。<BR>
 * 【生成】レポートクラスにより生成されます。<BR>
 * 【解放】レポート印刷後に開放されます。<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReportList {

	/**
	 * 【機能】要素数を返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 要素数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int size();

	/**
	 * 【機能】カーソルを先頭行の前（-1）に移動します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】カーソルが-1の状態でデータを参照することはできません。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void resetCursor() throws GReportException;

	/**
	 * 【機能】レポートレコードを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return レポートレコード
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportRecord get() throws GReportException;

	/**
	 * 【機能】次データにカーソルを移動させ、移動先の行にデータが存在するどうかを判定します。<BR>
	 * 【戻値】データが存在するかの真偽値<BR>
	 * 【備考】<BR>
	 * 
	 * @return データが存在するかの真偽値
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean next() throws GReportException;
}
