/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;


/**
 * 【役割】レポートレコードインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReportRecord extends Cloneable {

	/**
	 * 【機能】クローンレコードを生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return レポートレコード
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportRecord getClone();

	/**
	 * 【機能】項目名指定で値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param column_name 項目名
	 * @return 値
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	Object getVariable(String column_name) throws GReportException;

	/**
	 * 【機能】項目名指定で値文字列を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param column_name 項目名
	 * @return 値文字列
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getVariableString(String column_name) throws GReportException;

	/**
	 * 【機能】項目名指定で値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param column_name 項目名
	 * @param value 値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setVariable(String column_name, Object value);
}