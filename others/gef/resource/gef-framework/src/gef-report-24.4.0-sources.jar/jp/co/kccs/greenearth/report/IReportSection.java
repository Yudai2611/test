/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import java.awt.Color;

import jp.co.kccs.greenearth.report.repository.ISectionInfo;

/**
 * 【役割】セクションインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReportSection {

	/**
	 * 【機能】初期化を行います。<BR>
	 * 【呼出】<BR>
	 * 【備考】XMLに設定されているパラメータに戻ります。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void initialize() throws GReportException;

	/**
	 * 情報をロードします。<br>
	 * 
	 * @param sectionInfo セクション情報
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(ISectionInfo sectionInfo) throws GReportException;

	/**
	 * 【機能】印刷を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void print() throws GReportException;

	/**
	 * 【機能】網掛け背景付き印刷を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】メソッドが呼ばれるたびに交互にセクション全体に背景色がつきます。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void printBorder() throws GReportException;

	/**
	 * レポートをセットします。<br>
	 * 
	 * @param report レポート
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setReport(IReport report);

	/**
	 * レポートを取得します。<br>
	 * 
	 * @return レポート
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReport getReport();

	/**
	 * 【機能】このセクションの保持するフィールド、サークル、イメージ、ラインのうち名前がobject_nameの表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param object_name オブジェクト名
	 * @param output 表示/非表示の真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOutput(String object_name, boolean output);

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param output 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOutput(boolean output);

	/**
	 * 【機能】フィールドを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name フィールド名
	 * @return フィールド
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportField getField(String name) throws GReportException;

	/**
	 * 【機能】左端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getLeft();

	/**
	 * 【機能】左端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param left 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setLeft(int left);

	/**
	 * 【機能】上端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getTop();

	/**
	 * 【機能】上端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param top 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTop(int top);
	
	/**
	 * 背景色を設定します。<BR>
	 * 
	 * @param color 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 * @see {@link GColor} 
	 */
	void setBackGroundColor(Color color);
	
	/**
	 * 背景色取得します。<BR>
	 * 
	 * @return 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	Color getBackGroundColor();

	/**
	 * 【機能】サークルを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name サークル名
	 * @return サークル
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportCircle getCircle(String name) throws GReportException;

	/**
	 * 【機能】イメージを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name イメージ名
	 * @return イメージ
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportImage getImage(String name) throws GReportException;

	/**
	 * 【機能】ラインを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name ライン名
	 * @return ライン
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportLine getLine(String name) throws GReportException;

	/**
	 * 【機能】レクタングルを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name レクタングル名
	 * @return レクタングル
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportRectangle getRectangle(String name) throws GReportException;

	/**
	 * 【機能】このセクションの幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public int getWidth();

	/**
	 * 【機能】空のセクション（フィールド以外のデータ）を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void printEmpty() throws GReportException;

	/**
	 * 【機能】このセクションの高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getHeight();

	/**
	 * 名称を取得します。<br>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 表示/非表示を取得します。<br>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getOutput();
}