/*
 * Copyright 2014-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

import java.awt.Color;

import jp.co.kccs.greenearth.report.repository.IBarcodeInfo;
import jp.co.kccs.greenearth.report.repository.ILineDashInfo;

/**
 * 【役割】レポートライターインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IReportWriter {

	/** 用紙向き横 */
	public static final int ORIENTATION_HORIZONTAL = 1;
	/** 用紙向き縦 */
	public static final int ORIENTATION_VERTICAL = 2;

	/**
	 * 【機能】ページブレイク（改ページ）を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void pageBreak() throws GReportException;

	/**
	 * 【機能】用紙の縦横を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param value 値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOrientation(int value);

	/**
	 * 【機能】ドキュメントをオープンします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param path ドキュメントパス
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void open(String path) throws GReportException;

	/**
	 * 【機能】ドキュメントをクローズします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void close() throws GReportException;

	/**
	 * 【機能】イメージを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param image_name イメージ名称
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeImage(float left, float top, float width, float height, String image_name) throws GReportException;

	/**
	 * 【機能】ラインを印刷します。二重線の出力が可能です。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param color カラー
	 * @param dashInfo 点線情報
	 * @param isDouble 二重線フラグ
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeLine(float left, float top, float width, float height, double size, int type, Color color, ILineDashInfo dashInfo, boolean isDouble) throws GReportException;

	/**
	 * 【機能】四角形を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param radius 角丸長方形の角の半径
	 * @param dashInfo 点線情報
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeRectangle(float left, float top, float width, float height, double size, int type, int radius, ILineDashInfo dashInfo) throws GReportException;

	/**
	 * 【機能】複数行の文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】データには、各行に対する文字列を要素とする配列を渡します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param data データ(フィールド内の各行に対する文字列を要素とする配列)
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param fieldWidth 幅
	 * @param fontFace フォントフェイス
	 * @param fontHeight フォント高さ
	 * @param height 高さ
	 * @param foreColor 前景色
	 * @param backColor 背景色
	 * @param underLine 下線
	 * @param positionAdjustmentX  縦位置微調整
	 * @param positionAdjustmentY 横位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	void writeString(float left, float top, String[] data, int zoom, String align, float fieldWidth, int fontFace, int fontHeight, float height, Color foreColor, Color backColor, IReportLine underLine, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException;

	/**
	 * 【機能】ピッチを無視して複数行の文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】データには、各行に対する文字列を要素とする配列を渡します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param data データ
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param fieldWidth 幅
	 * @param fontFace フォントフェイス
	 * @param size フォントサイズ
	 * @param interval 文字間隔(幅)
	 * @param fontHeight 文字間隔(高さ)
	 * @param height 高さ
	 * @param foreColor 前景色
	 * @param backColor 背景色
	 * @param underLine 下線
	 * @param positionAdjustmentX 縦位置微調整
	 * @param positionAdjustmentY 横位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeNonGridString(float left, float top, String[] data, int zoom, String align, float fieldWidth, int fontFace, int size, int interval, int fontHeight, float height, Color foreColor, Color backColor, IReportLine underLine, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException;

	/**
	 * 【機能】バーコードを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type タイプ
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param value 値
	 * @param info バーコード情報
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeBarcode(int type, float left, float top, float width, float height, String value, IBarcodeInfo info) throws GReportException;

	/**
	 * 【機能】サークルを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param height 高さ
	 * @param width 幅
	 * @param size 線幅
	 * @param type 線種
	 * @param trueCircle 正円オプション
	 * @param info 点線情報
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeCircle(float left, float top, float height, float width, double size, int type, int trueCircle, ILineDashInfo info) throws GReportException;

	/**
	 * 【機能】最大行数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 行数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getRowCount();

	/**
	 * 【機能】最大幅数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 幅数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getColumnCount();

	/**
	 * 【機能】デバッグフラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param isDebug デバッグフラグ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setDebug(boolean isDebug);

	/**
	 * 【機能】列数と行数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param colCount 列数
	 * @param rowCount 行数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setColumnAndRow(int colCount, int rowCount);

	/**
	 * 【機能】マージンを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param leftMargin 左マージン
	 * @param rightMargin 右マージン
	 * @param topMargin 上マージン
	 * @param bottomMargin 下マージン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setMargins(float leftMargin, float rightMargin, float topMargin, float bottomMargin);

	/**
	 * 【機能】用紙サイズを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param paper_size 用紙サイズ文字列
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setParperSize(String paper_size);

//	/**
//	 * 【機能】背景色を設定します。<BR>
//	 * 【呼出】API<BR>
//	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
//	 * 
//	 * @param left 左
//	 * @param top 上
//	 * @param width 幅
//	 * @param height 高さ
//	 * @create 2014/09/29
//	 * @author yamashita
//	 * @since 2.0.0
//	 */
//	@Deprecated
//	void setBackGroundColor(float left, float top, float width, float height);
//
	/**
	 * 背景色を印刷します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param backGroundColor 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	void writeBackGroundColor(float left, float top, float width, float height, Color backGroundColor);

	/**
	 * 【機能】グリッドラインを表示します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param output 表示/非表示の真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setRuledLine(boolean output);

	/**
	 * 【機能】ページカウントをリセットします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】最大ページカウントにも影響します。<BR>
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void resetPageCount() throws GReportException;

	/**
	 * 【機能】ページ数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param count ページ数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setPageCount(int count);

	/**
	 * 【機能】最大ページカウントを書き込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】内部的にはこの段階では書き込みません。<BR>
	 * resetPageCount()が呼び出された時、またはドキュメントを閉じる時に自動的に書き込まれます。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param size サイズ
	 * @param align アラインメント
	 * @param width 幅
	 * @param height 高さ
	 * @param font_face フォントフェイス
	 * @param format フォーマット
	 * @param fontSize フォントサイズ
	 * @param fontInterval フォントインターバル
	 * @param fontHeight フォント高さ
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTemplateMaxPage(float left, float top, int size, String align, float width, float height, int font_face, String format, int fontSize, int fontInterval, int fontHeight) throws GReportException;

	/**
	 * 【機能】テンプレートを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param zoom サイズ
	 * @param align アラインメント
	 * @param width 幅
	 * @param height 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTemplateField(String templateName, float left, float top, int zoom, String align, float width, float height);

	/**
	 * 【機能】テンプレートを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】セクションテンプレート用です。<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTemplateSection(String templateName, float left, float top, float width, float height);

	/**
	 * 【機能】ピッチを無視して文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param templateName テンプレート名
	 * @param left 左
	 * @param top 上
	 * @param value データ
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param fontFace フォントフェイス
	 * @param fontSize フォントサイズ
	 * @param interval 文字間隔
	 * @param fontHeight フォント高さ
	 * @param height 高さ
	 * @param backColor 背景色
	 * @param positionAdjustmentX 縦位置微調整
	 * @param positionAdjustmentY 横位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplateNonGrid(String templateName, float left, float top, String value, int zoom, String align, float width, int fontFace, int fontSize, int interval, int fontHeight, float height, Color backColor, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException;

	
	/**
	 * 【機能】テンプレートをクリアします。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void clearTemplate(String templateName);

	/**
	 * 【機能】テンプレートにイメージを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param imageName イメージ名称
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplateImage(String templateName, float left, float top, float width, float height, String imageName) throws GReportException;

	/**
	 * 【機能】テンプレートにラインを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param color カラー
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplateLine(String templateName, float left, float top, float width, float height, double size, int type, Color color) throws GReportException;

	/**
	 * 【機能】テンプレートに四角を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param radius 角丸長方形の角の半径
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplateRectangle(String templateName, float left, float top, float width, float height, double size, int type, int radius) throws GReportException;


	/**
	 * 【機能】テンプレートに文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param value 値
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param fontFace フォントフェイス
	 * @param fontHeight フォント高さ
	 * @param positionAdjustmentX 縦位置微調整
	 * @param positionAdjustmentY 横位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplate(String templateName, float left, float top, String value, int zoom, String align, float width, int fontFace, int fontHeight, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException;

	/**
	 * 【機能】テンプレートにバーコードを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param type タイプ
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param value 値
	 * @param info バーコード情報
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplateBarcode(String templateName, int type, float left, float top, float width, float height, String value, IBarcodeInfo info) throws GReportException;

	/**
	 * 【機能】テンプレートにサークルを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param height 高さ
	 * @param width 幅
	 * @param size 線幅
	 * @param type 線種
	 * @param trueCircle 正円オプション
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplateCircle(String templateName, float left, float top, float height, float width, double size, int type, int trueCircle) throws GReportException;

	/**
	 * 【機能】ドキュメントをオープンせずに初期化を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void initialize();

	/**
	 * 【機能】PDFにパスワードを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param password パスワード文字列
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setPassword(String password);

	/**
	 * 【機能】PDFオープン時に自動的に印刷画面が開くように設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】JavaScriptの機能で実現しています。PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setOnLoadPrint();

	/**
	 * 【機能】指定のJavaScriptを埋め込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param script JavaScript
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setJavaScript(String script);

	/**
	 * 【機能】アウトラインを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @param outline アウトライン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeOutline(String outline);

	/**
	 * 【機能】1グリッドの幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @return 1グリッドの幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	float getGridWidth();

	/**
	 * 【機能】1グリッドの高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】PDFDriverしか使わない。後方互換のため残します。<BR>
	 * 
	 * @create 2006/09/15
	 * @return 1グリッドの高さ
	 * @since 1.2.0
	 */
	float getGridHeight();

	/**
	 * 最大ページ数を印刷します。
	 * 
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void writeTemplateMaxPage() throws GReportException;

	/**
	 * 帳票ファイル名に使用する拡張子を設定します。
	 * 
	 * @param extension 拡張子
	 * @create 2014/11/21
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	void setExtension(String extension);
	
	/**
	 * 帳票ファイル名に使用する拡張子を取得します。
	 * 
	 * @return 拡張子
	 * @create 2014/11/21
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	String getExtension();
}
