/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

/**
 * 【役割】レポート構成要素のグループを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface ISectionElementGroup {

	/**
	 * 名称をセットします。<br>
	 * 
	 * @param name 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setName(String name);

	/**
	 * 名称を取得します。<br>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * レポート構成要素をリストに追加します。
	 * 
	 * @param o レポート構成要素
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void add(Object o);

	/**
	 * リストをクリアします。<br>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void clear();

	/**
	 * リストからインデックス指定でレポート構成要素を取得します。<br>
	 * 
	 * @param index インデックス
	 * @return レポート構成要素
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	Object get(int index);

	/**
	 * リスト内の要素数を取得します。<br>
	 * 
	 * @return サイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int size();
}
