/*
 * Copyright 2014-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report;

/**
 * ヴァージョン情報を保持するクラスです.
 *
 * @create
 * @author KCCS
 * @since 1.0.0
 */
public final class Version {

	/** バージョン. */
	public static final String VERSION = "22.9.0";

	/**
	 * コンストラクタ.<br>
	 *
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private Version() {
	}
}
