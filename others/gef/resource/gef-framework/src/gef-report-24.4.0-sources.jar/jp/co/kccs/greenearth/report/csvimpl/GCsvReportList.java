/*
 * Copyright 2004-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.csvimpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReportList;
import jp.co.kccs.greenearth.report.IReportRecord;
import jp.co.kccs.greenearth.report.utility.GCsvParser;
import jp.co.kccs.greenearth.report.utility.GReportFileUtility;

/**
 * 【役割】CSVレポートリストを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 *
 * @create 2004/07/25
 * @author kusakari
 * @since 1.0.3
 */
public class GCsvReportList implements IReportList {

	/** 実体 */
	protected BufferedReader _reader = null;
	/** ファイルタイプ */
	protected int _type = GCsvParser.TYPE_CSV;
	/** CSV, TSV ファイル */
	protected File _file = null;
	/** エンコーディング */
	protected String _encoding = null;
	/** 読み終わったら消します */
	protected boolean _is_delete = false;
	/** CSV パーサ */
	protected GCsvParser _parser = null;

	/** ヘッダー項目 */
	protected String[] _header_columns = null;
	/** 現在のデータ */
	protected String _current_data = null;

	/**
	 * 【役割】レポートリストを生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】このデフォルトコンストラクタは拡張時に利用します。<BR>
	 *
	 * @create 2004/09/01
	 * @since 1.0.3
	 */
	public GCsvReportList() {
	}

	/**
	 * 【役割】レポートリストを生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】ファイルパスが存在しない場合や不正なエンコーディングが指定された場合、例外がスローされる場合があります。<BR>
	 *
	 * @param file ファイルパス
	 * @param encoding エンコード
	 * @param type タイプ
	 * @param is_delete 自動削除フラグ
	 * @throws GReportException 例外
	 * @create 2004/07/26
	 * @since 1.0.3
	 */
	public GCsvReportList(File file, String encoding, int type, boolean is_delete) throws GReportException {
		_file = file;
		_encoding = (encoding == null) ? "SJIS" : encoding;
		_is_delete = is_delete;
		_type = type;
		_parser = new GCsvParser(_type);
		open(true);
	}

	/**
	 * 【機能】削除フラグが true の場合、ファイルを削除します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param is_retry リトライフラグ
	 * @throws GReportException 例外
	 * @create 2004/09/03
	 * @since 1.0.3
	 */
	protected void deleteFile(boolean is_retry) throws GReportException {
		GReportFileUtility.deleteFile(_file, is_retry);
	}

	/**
	 * 【機能】Reader を閉じます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @create 2004/09/01
	 * @since 1.0.3
	 */
	public void close() {
		close(_is_delete);
	}

	/**
	 * データの読込を終了する
	 * ファイルリーダーを閉じる、現在のヘッダーとデータをクリア、元データファイルを削除
	 *
	 * @param isDelete true：元のファイルを削除 false:削除しない
	 * @throws GReportException
	 * @create 2014/11/14
	 * @author tou
	 * @since 2.0.0
	 */
	protected void close(boolean isDelete) {
		try {
			closeReader();
		} catch (IOException e) {
			throw new GReportRuntimeException(e);
		}
		_header_columns = null;
		_current_data = null;
		if (isDelete) {
			try {
				deleteFile(true);
			} catch (GReportException e) {
				throw new GReportRuntimeException(e);
			}
		}
	}

	/**
	 * ファイルリーダーを閉じます。
	 *
	 * @throws IOException IO例外
	 * @create 2014/11/14
	 * @author KCSS tangwenjun
	 * @since 2.0.0
	 */
	private void closeReader() throws IOException {
		if (_reader == null) {
			return;
		}

		try {
			_reader.close();
		} catch (IOException e) {
			_reader.close();
		}
	}

	/**
	 * 【機能】ファイルをオープンします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param isParseHeader ヘッダー処理するかどうかのフラグ
	 * @throws GReportException 例外
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public void open(boolean isParseHeader) throws GReportException {
		try {
			Objects.requireNonNull(_file);
			FileInputStream in = new FileInputStream(_file);
			InputStreamReader isr = new InputStreamReader(in, _encoding);
			_reader = new BufferedReader(isr);
			if (isParseHeader) {
				String[] headerColumns = _parser.parse(_reader.readLine());
				_header_columns = headerColumns;
			} else {
				_reader.readLine();
			}
		} catch (IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】要素数を返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#size()
	 * @return 要素数
	 * @since 1.0.3
	 */
	public int size() {
		return 0;
	}

	/**
	 * 【機能】カーソルを先頭行の前（-1）に移動します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】カーソルが-1の状態でデータを参照することはできません。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#resetCursor()
	 * @throws GReportException 例外
	 * @since 1.0.3
	 */
	@Override
	public void resetCursor() throws GReportException {
		close(false);
		open(true);
	}

	/**
	 * 【機能】レポートレコードを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#get()
	 * @return レポートレコード
	 * @throws GReportException 例外
	 * @since 1.0.3
	 */
	@Override
	public IReportRecord get() throws GReportException {
		if (_current_data == null) {
			return null;
		}

		String[] columns = _header_columns;
		String[] vals = null;
		vals = _parser.parse(_current_data);
		Map<String, Object> m = new HashMap<String, Object>();
		for (int i = 0; i < vals.length; i++) {
			m.put(columns[i], vals[i]);
		}
		return new GCsvReportRecord(m);
	}

	/**
	 * 【機能】次データにカーソルを移動させ、移動先の行にデータが存在するどうかを判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#next()
	 * @return データが存在するかの真偽値
	 * @throws GReportException 例外
	 * @since 1.0.3
	 */
	@Override
	public boolean next() throws GReportException {
		try {
			_current_data = _reader.readLine();
			if (_current_data == null) {
				close();
				return false;
			}
		} catch (IOException | RuntimeException e) {
			close();
			throw new GReportException(e);
		}
		return true;
	}
}