/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.csvimpl;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReportRecord;

/**
 * 【役割】CSVレコードを表します。<BR>
 * 【生成】レポートクラスにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 * 
 * @create 2004/07/25
 * @author kusakari
 * @since 1.0.3
 */
public class GCsvReportRecord implements IReportRecord {

	/** 実体 */
	private Map<String, Object> _columns = null;

	/**
	 * コンストラクター
	 */
	public GCsvReportRecord() {
	}

	/**
	 * 【役割】レポートレコードを生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 * 
	 * @param columns 実体マップオブジェクト
	 * @create 2004/07/25
	 * @since 1.0.3
	 */
	public GCsvReportRecord(Map<String, Object> columns) {
		setColumns(columns);
	}

	/**
	 * 実体マップの設定する.<br>
	 * 
	 * @param columns 実体マップオブジェクト
	 * @create 2004/07/25
	 * @author 
	 * @since 1.0.3
	 */
	void setColumns(Map<String, Object> columns) {
		_columns = columns;
	}
	
	/**
	 * 【機能】クローンレコードを生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getClone()
	 * @return レポートレコード
	 * @create 2004/07/25
	 * @author 
	 * @since 1.0.3
	 */
	@Override
	public IReportRecord getClone() {
		GCsvReportRecord clonedReportRecord;
		try {
			clonedReportRecord = (GCsvReportRecord) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new GReportRuntimeException(e);
		}
		
		if (_columns != null) {
			Map<String, Object> clonedColumns = new HashMap<String, Object>();
			clonedColumns.putAll(_columns);
			clonedReportRecord.setColumns(clonedColumns);
		}
		return clonedReportRecord;
	}

	/**
	 * 【機能】指定ヘッダー項目名の値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getVariable(java.lang.String)
	 * @param column_name ヘッダー項目名
	 * @return 値
	 * @create 2004/07/25
	 * @author 
	 * @since 1.0.3
	 */
	@Override
	public Object getVariable(String column_name) {
		if (column_name == null) {
			return null;
		}
		return getMap().get(column_name);
	}

	/**
	 * 【機能】指定ヘッダー項目名の値文字列を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getVariableString(java.lang.String)
	 * @param column_name ヘッダー項目名
	 * @return 値文字列
	 * @create 2004/07/25
	 * @author 
	 * @since 1.0.3
	 */
	@Override
	public String getVariableString(String column_name) {
		if (column_name == null) {
			return null;
		}
		
		Object ret = getMap().get(column_name);
		if (ret == null) {
			return null;
		}
		return ret.toString();
	}

	/**
	 * 【機能】ヘッダー項目名指定で値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#setVariable(java.lang.String, java.lang.Object)
	 * @param column_name ヘッダー項目名
	 * @param value 値
	 * @create 2004/07/25S
	 * @author 
	 * @since 1.0.3
	 */
	@Override
	public void setVariable(String column_name, Object value) {
		if (column_name == null) {
			return;
		}
		getMap().put(column_name, value);
	}

	/**
	 * 【機能】Mapを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 実体マップオブジェクト
	 * @create 2004/07/25
	 * @author 
	 * @since 1.0.3
	 */
	Map<String, Object> getMap() {
		if (_columns == null) {
			_columns = new HashMap<String, Object>();
		}
		return _columns;
	}
}
