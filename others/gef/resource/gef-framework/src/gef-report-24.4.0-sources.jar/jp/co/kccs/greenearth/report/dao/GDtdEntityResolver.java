/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao;

import java.io.IOException;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * ReportFrameworkで定義されたDTDを解決するためのEntityResolverです。
 * 
 * @create 2006/03/02
 * @author kitamura
 * @since 1.1.0
 */
public class GDtdEntityResolver implements EntityResolver {

	/** エンティティURL(DTDのURL) */
	private String _entity_url = null;
	/** 公開識別子 */
	private String _public_id = null;
	/** URLマッピングキー */
	private String _url_mapping_key = null;

	/**
	 * デフォルトコンストラクタ
	 * 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GDtdEntityResolver() {
	}

	/**
	 * 公開識別子、エンティティURL、URLマッピングキーを指定して、GDtdEntityResolverインスタンスを初期化します。
	 * 
	 * @param public_id 公開識別子
	 * @param entity_url エンティティURL
	 * @param url_mapping_key URLマッピングキー
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GDtdEntityResolver(String public_id, String entity_url, String url_mapping_key) {
		_public_id = public_id;
		_entity_url = entity_url;
		_url_mapping_key = url_mapping_key;
	}

	/**
	 * エンティティURLを取得します。
	 * 
	 * @return エンティティURL
	 * @create 2006/03/02
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getEntityUrl() {
		return _entity_url;
	}

	/**
	 * 公開識別子を取得します。
	 * @return 公開識別子
	 * @create 2006/03/02
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getPublicId() {
		return _public_id;
	}

	/**
	 * URLマッピングキーを取得します。
	 * 
	 * @return URLマッピングキー
	 * @create 2006/03/02
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getUrlMappingKey() {
		return _url_mapping_key;
	}

	/**
	 * アプリケーションが外部エンティティを解決できるようにします。<BR>
	 * 引数に指定された値(DOCTYPEに指定された値)が、DefaultPublicID、UrlMappingKeyに一致した場合は、
	 * SystemIDをENTITY_URIにすりかえます。
	 * 
	 * @see org.xml.sax.EntityResolver#resolveEntity(java.lang.String, java.lang.String)
	 * @param public_id 公開識別子
	 * @param system_id システムID
	 * @return InputSource インップトソース
	 * @throws SAXException SAXエラー
	 * @throws IOException IOエラー
	 * @create 2006/03/02
	 * @author kitamura
	 * @since 1.1.0
	 */
	public InputSource resolveEntity(String public_id, String system_id) throws SAXException, IOException {
		if (_public_id != null && _public_id.equals(public_id) && _url_mapping_key != null && _url_mapping_key.equals(system_id)) {
			InputSource src = new InputSource();
			src.setPublicId(public_id);
			src.setSystemId(_entity_url);
			return src;
		} else {
			throw new SAXException("Specification of DOCTYPE is wrong.");
		}
	}

	/**
	 * エンティティURLを設定します。
	 * 
	 * @param url エンティティURL
	 * @create 2006/03/02
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setEntityUrl(String url) {
		_entity_url = url;
	}

	/**
	 * 公開識別子を設定します。
	 * 
	 * @param id 公開識別子
	 * @create 2006/03/02
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setPublicId(String id) {
		_public_id = id;
	}

	/**
	 * URLマッピングキーを設定します。
	 * 
	 * @param key URLマッピングキー
	 * @create 2006/03/02
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setUrlMappingKey(String key) {
		_url_mapping_key = key;
	}

}
