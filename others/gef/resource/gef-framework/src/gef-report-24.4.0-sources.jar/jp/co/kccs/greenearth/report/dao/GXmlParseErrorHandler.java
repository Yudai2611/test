/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * ReportFrameowrk内で利用するXMLの解析用エラーハンドラークラスです。<BR>
 * 主にDTDを利用したXMLの解析時に発生するエラーをハンドリングします。
 * 
 * @create 2006/03/01
 * @author kitamura
 * @since 1.1.0
 */
public class GXmlParseErrorHandler implements ErrorHandler {

	/**
	 * デフォルトコンストラクタ
	 * 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GXmlParseErrorHandler() {
	}

	/**
	 * 回復可能なエラーの通知を受け取ります。
	 * 
	 * @see org.xml.sax.ErrorHandler#error(org.xml.sax.SAXParseException)
	 * @param exception XML解析例外
	 * @throws SAXException XML処理例外
	 * @create 2006/03/01
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void error(SAXParseException exception) throws SAXException {
		throw exception;
	}

	/**
	 * 回復できないエラーの通知を受け取ります。
	 * 
	 * @see org.xml.sax.ErrorHandler#fatalError(org.xml.sax.SAXParseException)
	 * @param exception XML解析例外
	 * @throws SAXException XML処理例外
	 * @create 2006/03/01
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void fatalError(SAXParseException exception) throws SAXException {
		throw exception;
	}

	/**
	 * 警告の通知を受け取ります。
	 * 
	 * @see org.xml.sax.ErrorHandler#warning(org.xml.sax.SAXParseException)
	 * @param exception XML解析例外
	 * @throws SAXException XML処理例外
	 * @create 2006/03/01
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void warning(SAXParseException exception) throws SAXException {
		throw exception;
	}

}
