/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao;

/**
 * データソースリストの項目を表すインターフェースです。
 * 
 * @create 2006/02/07
 * @author kitamura
 * @since 1.1.0
 */
public interface IReportColumn {

	/** 日付型 */
	public static final int TYPE_DATETIME = 3;
	/** 実数型 */
	public static final int TYPE_DECIMAL = 5;
	/** Integer型 */
	public static final int TYPE_INTEGER = 0;
	/** Long型 */
	public static final int TYPE_LONG = 6;
	/** NString型 */
	public static final int TYPE_NSTRING = 2;
	/** 文字列型 */
	public static final int TYPE_STRING = 1;
	/** YM型 */
	public static final int TYPE_YM = 4;

	/**
	 * この項目が関連づくListオブジェクトを取得します。
	 * 
	 * @create 2006/03/10
	 * @return リスト
	 * @author kitamura
	 * @since 1.1.0
	 */
	IReportList getList();

	/**
	 * 項目名を取得します。
	 * 
	 * @create 2006/03/10
	 * @return 項目名
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getName();

	/**
	 * 項目のデータタイプを取得します。
	 * 
	 * @create 2006/03/10
	 * @return データタイプ
	 * @author kitamura
	 * @since 1.1.0
	 */
	int getType();
}
