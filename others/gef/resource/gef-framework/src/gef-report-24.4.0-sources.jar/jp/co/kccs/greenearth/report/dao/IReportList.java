/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao;

import jp.co.kccs.greenearth.report.GReportException;

/**
 * データソースリストを表すインターフェースです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public interface IReportList {

	/**
	 * リストを閉じます。
	 * 
	 * @create 2006/03/10
	 * @throws GReportException ReportEngie例外
	 * @author kitamura
	 * @since 1.1.0
	 */
	void close() throws GReportException;

	/**
	 * 指定した項目名の項目オブジェクトを取得します.<BR>
	 * 
	 * @create 2006/03/10
	 * @param column_name 項目名
	 * @return 項目オブジェクト
	 * @author kitamura
	 * @since 1.1.0
	 */
	IReportColumn getColumn(String column_name);

	/**
	 * リストに紐づく項目オブジェクトの配列を取得します.<BR>
	 * 項目は、データソース内に出現する順番にソートされています。
	 * 
	 * @create 2006/03/10
	 * @return 項目オブジェクトの配列
	 * @author kitamura
	 * @since 1.1.0
	 */
	IReportColumn[] getColumnArray();

	/**
	 * 現在作業対象となっている行のレコードを取得します。
	 * 
	 * @create 2006/03/10
	 * @return 現在作業対象となっている行
	 * @throws GReportException ReportEngine例外
	 * @author kitamura
	 * @since 1.1.0
	 */
	IReportRecord getRecord() throws GReportException;

	/**
	 * リストが既に開かれているかを表す値を取得します。
	 * 
	 * @create 2006/03/10
	 * @return 既に開かれている場合はtrue、閉じている場合はfalse
	 * @author kitamura
	 * @since 1.1.0
	 */
	boolean isOpen();

	/**
	 * 作業対象行を次の行へ移動させます。
	 * 
	 * @create 2006/03/10
	 * @return 次の行が存在する場合はtrue、最終行の場合はfalse
	 * @throws GReportException ReportEngie例外
	 * @author kitamura
	 * @since 1.1.0
	 */
	boolean next() throws GReportException;

	/**
	 * リストを開きます。
	 * 
	 * @create 2006/03/10
	 * @throws GReportException ReportEngie例外
	 * @author kitamura
	 * @since 1.1.0
	 */
	void open() throws GReportException;
}
