/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao;

/**
 * データソースリストの行を表すインターフェースです。
 * 
 * @create 2006/01/26
 * @author kitamura
 * @since 1.1.0
 */
public interface IReportRecord {

	/**
	 * この項目が関連づくListオブジェクトを取得します。
	 * 
	 * @create 2006/03/10
	 * @return リスト
	 * @author kitamura
	 * @since 1.1.0
	 */
	IReportList getList();

	/**
	 * 指定した項目の値を取得します。
	 * 
	 * @create 2006/03/10
	 * @param column_name 項目名
	 * @return 値
	 * @author kitamura
	 * @since 1.1.0
	 */
	Object getVariable(String column_name);

	/**
	 * 指定した項目の値を文字列表現で取得します。
	 * 
	 * @create 2006/03/10
	 * @param column_name 項目名
	 * @return 文字列表現された値
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getVariableString(String column_name);

	/**
	 * 指定された項目に、指定された値を設定します。
	 * 
	 * @create 2006/03/10
	 * @param column_name 項目名
	 * @param value 値
	 * @author kitamura
	 * @since 1.1.0
	 */
	void setVariable(String column_name, Object value);
}
