/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.fixedlength;

import jp.co.kccs.greenearth.report.dao.IReportColumn;

import org.w3c.dom.Element;

/**
 * 固定長データリストの項目を表すインターフェースです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public interface IFixedLengthColumn extends IReportColumn {

	/**
	 * 少数部の桁数を取得します。
	 * 
	 * @create 2006/03/10
	 * @return 少数部の桁数
	 * @author kitamura
	 * @since 1.1.0
	 */
	int getDecimalLength();

	/**
	 * 日付フォーマットを取得します。
	 * 
	 * @create 2006/03/10
	 * @return 日付フォーマット
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getFormat();

	/**
	 * 項目長(バイト数)を取得します.<BR>
	 * 
	 * @create 2006/03/10
	 * @return 項目長(バイト数)
	 * @author kitamura
	 * @since 1.1.0
	 */
	int getLength();

	/**
	 * 項目情報が積まれたXMLエレメントを元にインスタンスを初期化します。
	 * 
	 * @create 2006/03/10
	 * @param list オーナーリスト
	 * @param element 項目情報が積まれたXMLエレメント
	 * @author kitamura
	 * @since 1.1.0
	 */
	void initialize(IFixedLengthList list, Element element);

	/**
	 * データ内に少数点を含むかを表す値を取得します。
	 * 
	 * @create 2006/03/10
	 * @return 含む:true、含まない:false
	 * @author kitamura
	 * @since 1.1.0
	 */
	boolean isPoint();

	/**
	 * データの左スペースをトリムするかを表す値を取得します。
	 * 
	 * @create 2006/03/10
	 * @return トリムする:true、トリムしない:false
	 * @author kitamura
	 * @since 1.1.0
	 */
	boolean isTrim();
}
