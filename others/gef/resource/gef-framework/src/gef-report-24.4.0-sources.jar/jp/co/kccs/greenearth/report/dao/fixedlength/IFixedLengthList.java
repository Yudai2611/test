/*
 * Copyright 2006-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.fixedlength;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.dao.IReportList;

import java.net.URI;

/**
 * 固定長データリストを表すインターフェースです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public interface IFixedLengthList extends IReportList {

	/**
	 * インプットデータのエンコードタイプを取得します。
	 * 
	 * @create 2006/03/10
	 * @return エンコードタイプ
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getEncoding();

	/**
	 * データソースとなるファイルのファイル名を取得します。
	 * 
	 * @create 2006/03/10
	 * @return ファイル名
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getInputFileName();

	/**
	 * レイアウト定義ファイルのファイル名を取得します。
	 * 
	 * @create 2006/03/10
	 * @return レイアウト定義ファイルのファイル名
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getLayoutFileName();

	/**
	 * レコード長(バイト数)を取得します。
	 * 
	 * @create 2006/03/10
	 * @return レコード長(バイト数)
	 * @author kitamura
	 * @since 1.1.0
	 */
	int getLineLength();

	/**
	 * レイアウト定義ファイルを指定して、インスタンスを初期化します.<br>
	 *
	 * layoutFilePathとinputFilePathは、以下二つパターンを対応できる。<br>
	 * <パターン１＞ 相対パス指定（"dir/file.txt"）<br>
	 * <パターン２＞ 絶対パス指定（fileObj.getAbsolutePath(): "c:/dir/file.txt"）<br>
	 *
	 * @param layoutFilePath レイアウト定義ファイルのファイルパス
	 * @param inputFilePath データソースとなるファイルのファイルパス
	 * @param delete close後自動削除するかどうかのフラグ
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Deprecated
	void initialize(String layoutFilePath, String inputFilePath, boolean delete) throws GReportException;

	/**
	 * レイアウト定義ファイルを指定して、インスタンスを初期化します.<br>
	 *
	 * @param layoutFile レイアウト定義ファイルのURI
	 * @param inputFile データソースとなるファイルのURI
	 * @param delete close後自動削除するかどうかのフラグ
	 * @throws GReportException 例外
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	void initialize(URI layoutFile, URI inputFile, boolean delete) throws GReportException;

	/**
	 * リストを閉じた後、インプットファイルを削除するかを表す値を取得します。
	 * 
	 * @create 2006/03/10
	 * @return 削除する:true、削除しない:false
	 * @author kitamura
	 * @since 1.1.0
	 */
	boolean isDelete();

	/**
	 * レコードの区切りを改行とするかを表す値を取得します。
	 * 
	 * @create 2006/03/10
	 * @return レコード区切りを改行とする:true、レコード長にする:false
	 * @author kitamura
	 * @since 1.1.0
	 */
	boolean isLineSeparate();

	// v1.6.0
	/**
	 * 読み飛ばしバイト数を取得します。
	 * 
	 * @create 2010/01/26
	 * @return 読み飛ばしバイト数
	 * @author takaishi
	 * @since 1.6.0
	 */
	int getSkipBytes();

	/**
	 * IFixedLengthListのファクトリークラスです。
	 * 
	 * @create 2006/02/08
	 * @author kitamura
	 * @since 1.1.0
	 */
	class Factory {

		/**
		 * IFixedLengthListを生成します.<br>
		 * 
		 * @create 2006/03/10
		 * @param layoutFilePath レイアウト定義ファイル名
		 * @param inputFilePath インプットファイル名
		 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
		 * @return リスト
		 * @throws GReportException ReportEngine例外
		 * @author kitamura
		 * @since 1.1.0
		 */
		@Deprecated
		public static IFixedLengthList createList(String layoutFilePath, String inputFilePath, boolean delete)
			throws GReportException {
			return createList(GFileUtils.createURI(layoutFilePath), GFileUtils.createURI(inputFilePath), delete);
		}

		/**
		 * IFixedLengthListを生成します.<br>
		 *
		 * @param layoutFile レイアウト定義ファイルのURI
		 * @param inputFile データソースとなるファイルのURI
		 * @param delete close後自動削除するかどうかのフラグ
		 * @throws GReportException 例外
		 * @return リスト
		 * @create 2023/10/25
		 * @author KCSS yangfeng
		 * @since 23.10.0
		 */
		public static IFixedLengthList createList(URI layoutFile, URI inputFile, boolean delete)
			throws GReportException {
			IFixedLengthList list = GFrameworkUtils.getComponent("FixedLengthList");
			list.initialize(layoutFile, inputFile, delete);
			return list;
		}
	}
}
