/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.fixedlength;

import jp.co.kccs.greenearth.report.dao.IReportRecord;

/**
 * 固定長データリストの行を表すインターフェースです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public interface IFixedLengthRecord extends IReportRecord {

	/**
	 * 行の項目値を指定して、インスタンスを初期化します。
	 * 
	 * @create 2006/02/09
	 * @param list オーナーリスト
	 * @param values 各列の項目値
	 * @author kitamura
	 * @since 1.1.0
	 */
	void initialize(IFixedLengthList list, String[] values);
}
