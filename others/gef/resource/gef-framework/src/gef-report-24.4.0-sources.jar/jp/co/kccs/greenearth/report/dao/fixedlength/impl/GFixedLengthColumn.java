/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.fixedlength.impl;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.report.dao.IReportList;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthList;

import org.w3c.dom.Attr;
import org.w3c.dom.Element;

/**
 * 固定長データリストの項目のデフォルト実装クラスです。
 * 
 * @create 2006/02/07
 * @author kitamura
 * @since 1.1.0
 */
public class GFixedLengthColumn implements IFixedLengthColumn {

	/** XMLタグ属性の定数 type */
	private static final String ATTRIBUTE_TYPE = "type";
	/** XMLタグ属性の定数 trim */
	private static final String ATTRIBUTE_TRIM = "trim";
	/** XMLタグ属性の定数 point */
	private static final String ATTRIBUTE_POINT = "point";
	/** XMLタグ属性の定数 point */
	private static final String ATTRIBUTE_NAME = "name";
	/** XMLタグ属性の定数 point */
	private static final String ATTRIBUTE_LENGTH = "length";
	/** XMLタグ属性の定数 point */
	private static final String ATTRIBUTE_FORMAT = "format";
	/** XMLタグ属性の定数 point */
	private static final String ATTRIBUTE_DECIMAL_LENGTH = "decimallength";
	
	/** 小数部の桁数 */
	private int _decimal_length = 0;
	/** 日付フォーマット */
	private String _format = null;
	/** データ内に少数点を含むかを表す値 */
	private boolean _is_point = true;
	/** データの左スペースをトリムするかを表す値 */
	private boolean _is_trim = true;
	/** 項目長(バイト数) */
	private int _length = 0;
	/** オーナーリスト */
	private IFixedLengthList _list = null;
	/** 項目名 */
	private String _name = null;
	/** データタイプ */
	private int _type = TYPE_STRING;

	/**
	 * デフォルトコンストラクタ
	 * 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GFixedLengthColumn() {
	}

	/**
	 * 小数部の桁数を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn#getDecimalLength()
	 * @return 小数部の桁数
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */ 
	@Override
	public int getDecimalLength() {
		return _decimal_length;
	}

	/**
	 * propertiesファイルよりgeframe.report.Convert.Datasource.DefaultDateFormatを取得します。
	 * 
	 * @return propertiesファイルよりgeframe.report.Convert.Datasource.DefaultDateFormat
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected String getDefaultDateFormat() {
		return GFrameworkUtils.getProperty("geframe.report.Convert.Datasource.DefaultDateFormat");
	}

	/**
	 * 日付フォーマットを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn#getFormat()
	 * @return 日付フォーマット
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getFormat() {
		return _format;
	}

	/**
	 * 項目長(バイト数)を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn#getLength()
	 * @return 項目長(バイト数)
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public int getLength() {
		return _length;
	}

	/**
	 * オーナーリストを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportColumn#getList()
	 * @return オーナーリスト
	 * @create 2006/02/23
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public IReportList getList() {
		return _list;
	}

	/**
	 * 項目名を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportColumn#getName()
	 * @return 項目名
	 * @create 2006/02/07
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * データタイプを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportColumn#getType()
	 * @return データタイプ
	 * @create 2006/02/07
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public int getType() {
		return _type;
	}

	/**
	 * 項目情報が積まれたXMLエレメントを元にインスタンスを初期化します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn#initialize(jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthList, org.w3c.dom.Element)
	 * @param list リスト
	 * @param element XMLエレメント
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void initialize(IFixedLengthList list, Element element) {
		if (element == null || list == null) {
			return;
		}

		_list = list;

		initializeName(element);
		initializeType(element);
		initializeFormat(element);
		initializeLength(element);
		initializePoint(element);
		initializeDecimalLength(element);
		initializeTrim(element);
	}

	/**
	 * 小数部桁数の初期化を行います。
	 * 
	 * @param element XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void initializeDecimalLength(Element element) {
		Attr decimallengthAttr = element.getAttributeNode(GFixedLengthColumn.ATTRIBUTE_DECIMAL_LENGTH);
		if (decimallengthAttr != null) {
			int decimalLength = Integer.parseInt(decimallengthAttr.getValue());

			if (decimalLength == 0 || _length < decimalLength) {
				throw new IllegalArgumentException("decimallength should be larger than 0, and be smaller than length.");
			}

			_decimal_length = decimalLength;
		}
	}

	/**
	 * 日付フォーマットの初期化を行います。
	 * 
	 * @param element XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void initializeFormat(Element element) {
		Attr formatAttr = element.getAttributeNode(GFixedLengthColumn.ATTRIBUTE_FORMAT);
		if (formatAttr != null) {
			_format = formatAttr.getValue();
		} else {
			_format = getDefaultDateFormat();
		}
	}

	/**
	 * 項目長の初期化を行います。
	 * 
	 * @param element  XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void initializeLength(Element element) {
		Attr lengthAttr = element.getAttributeNode(GFixedLengthColumn.ATTRIBUTE_LENGTH);
		if (lengthAttr != null) {
			int length = Integer.parseInt(lengthAttr.getValue());

			if (length < 0) {
				throw new IllegalArgumentException("column length should be larger than 0.");
			}

			_length = length;
		}
	}

	/**
	 * 項目名の初期化を行います。
	 * 
	 * @param element  XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void initializeName(Element element) {
		Attr nameAttr = element.getAttributeNode(GFixedLengthColumn.ATTRIBUTE_NAME);
		if (nameAttr != null) {
			_name = nameAttr.getValue();
		}
	}

	/**
	 * データ内に少数点を含むかを表す値の初期化を行います。
	 * 
	 * @param element  XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void initializePoint(Element element) {
		Attr pointAttr = element.getAttributeNode(GFixedLengthColumn.ATTRIBUTE_POINT);
		if (pointAttr != null) {
			_is_point = Boolean.valueOf(pointAttr.getValue()).booleanValue();
		}
	}

	/**
	 * データの左スペースをトリムするかを表す値の初期化を行います。
	 * 
	 * @param element  XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void initializeTrim(Element element) {
		Attr trimAttr = element.getAttributeNode(GFixedLengthColumn.ATTRIBUTE_TRIM);
		if (trimAttr != null) {
			_is_trim = Boolean.valueOf(trimAttr.getValue()).booleanValue();
		}
	}

	/**
	 * データタイプの初期化を行います。
	 * 
	 * @param element  XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void initializeType(Element element) {
		Attr typeAttr = element.getAttributeNode(GFixedLengthColumn.ATTRIBUTE_TYPE);
		if (typeAttr != null) {
			_type = Integer.parseInt(typeAttr.getValue());
		}
	}

	/**
	 * データ内に少数点を含むかを表す値を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn#isPoint()
	 * @return true:少数点を含む/false：少数点を含まない
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public boolean isPoint() {
		return _is_point;
	}

	/**
	 * データの左スペースをトリムするかを表す値を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn#isTrim()
	 * @return true:トリムする/false:トリムしない
	 * @create 2006/02/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public boolean isTrim() {
		return _is_trim;
	}

	/**
	 * 小数部桁数を設定します。
	 * 
	 * @param length 桁数
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setDecimalLength(int length) {
		_decimal_length = length;
	}

	/**
	 * 日付フォーマットを指定します。
	 * 
	 * @param format 日付フォーマット
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setFormat(String format) {
		_format = format;
	}

	/**
	 * データ内に少数点を含むかを表す値を設定します。
	 * 
	 * @param is_point  少数点を含むかのフラグ
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsPoint(boolean is_point) {
		_is_point = is_point;
	}

	/**
	 * データの左スペースをトリムするかを表す値を設定します。
	 * 
	 * @param is_trim 左スペースをトリムするかのフラグ
	 * @create 2006/02/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsTrim(boolean is_trim) {
		_is_trim = is_trim;
	}

	/**
	 * 項目長(バイト数)を指定します。
	 * 
	 * @param length 項目長
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setLength(int length) {
		_length = length;
	}

	/**
	 * オーナーリストを設定します。
	 * 
	 * @param list オーナーリスト
	 * @create 2006/02/23
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setList(IFixedLengthList list) {
		_list = list;
	}

	/**
	 * 項目名を設定します。
	 * 
	 * @param name 項目名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setName(String name) {
		_name = name;
	}

	/**
	 * データタイプを設定します。
	 * 
	 * @param type データタイプ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setType(int type) {
		_type = type;
	}

	/**
	 * 項目情報を"|"(パイプ)区切りで出力します.<BR>
	 * フォーマット 項目名|データタイプ|項目長|トリムするか|小数点を含むか|小数部桁数|フォーマット
	 * 
	 * @see java.lang.Object#toString()
	 * @return 出力する文字列
	 * @create 2006/02/11
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		return buf.append(getName())
				.append("|" + getType())
				.append("|" + getLength())
				.append("|" + isTrim())
				.append("|" + isPoint())
				.append("|" + getDecimalLength())
				.append("|" + getFormat())
				.toString();
	}
}