/*
 * Copyright 2006-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.fixedlength.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.io.File;
import java.net.URI;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GURIScheme;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.dao.IReportColumn;
import jp.co.kccs.greenearth.report.dao.IReportRecord;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthList;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthRecord;
import jp.co.kccs.greenearth.report.utility.GReportFileUtility;
import jp.co.kccs.greenearth.report.utility.GXmlParser;

/**
 * 固定長データリストのデフォルト実装クラスです。
 *
 * @create 2006/02/07
 * @author kitamura
 * @since 1.1.0
 */
public class GFixedLengthList implements IFixedLengthList {

	/** XMLタグ名 encoding **/
	private static final String TAG_NAME_ENCODING = "encoding";
	/** XMLタグ名 skipbytes **/
	private static final String TAG_NAME_SKIP_BYTES = "skipbytes";
	/** XMLタグ名 linelength **/
	private static final String TAG_NAME_LINE_LENGTH = "linelength";
	/** XMLタグ名 lineseparate **/
	private static final String TAG_NAME_LINE_SEPARATE = "lineseparate";
	/** XMLタグ名 list **/
	private static final String TAG_NAME_LIST = "list";
	/** XMLタグ名 column **/
	private static final String TAG_NAME_COLUMN = "column";

	/** DTD **/
	private static final String DTD_DATA_SOURCE_FIXED_LENGTH_EN = "-//KCCS//DTD GreenEARTH ReportFramework DataSource FixedLength//EN";
	/** リソースキー **/
	private static final String RESOURCE_KEY_FIXED_LENGTH_DATASOURCE_FL_DTD = "jp/co/kccs/greenearth/report/dao/fixedlength/datasource-fl.dtd";
	/** URLキー **/
	private static final String URL_KEY_DATASOURCE_FL_DTD = "http://www.kccs.co.jp/greenearth/report/dtds/datasource-fl.dtd";

	/** Logger **/
	protected static Log log = LogFactory.getLog(GFixedLengthList.class);

	/** 項目リスト */
	private IFixedLengthColumn[] _column_array = null;
	/** カレントレコード */
	private IFixedLengthRecord _current_record = null;
	/** エンコーディング */
	private String _encoding = null;
	/** ファイルリーダー */
	private BufferedReader _file_reader = null;
	/** ファイルストリーム */
	private InputStream _file_stream = null;

	/** インプットファイルのURI情報 */
	private URI _input_file_uri = null;
	/** クローズ時にインプットファイルを削除するかを表す値 */
	private boolean _is_delete = false;
	/** レコードの区切りを改行とするかを表す値 */
	private boolean _is_line_separate = true;
	/** ファイルが開いているかを表す値 */
	private boolean _is_open = false;
	/** レイアウト定義ファイル名 */
	private String _layout_file = null;
	/** レコード長(バイト数) */
	private int _line_length = 0;

	/** 読み飛ばしバイト数 */
	private int _skip_bytes = 0;

	/**
	 * リストを閉じます。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#close()
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void close() throws GReportException {
		close(_is_delete);
	}

	/**
	 * インプットファイルを削除するかを指定してリストを閉じます。
	 *
	 * @param is_delete 削除フラグ
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void close(boolean is_delete) throws GReportException {
		try {
			if (_file_reader != null) {
				_file_reader.close();
			}
			if (_file_stream != null) {
				_file_stream.close();
			}
		} catch (IOException e) {
			throw new GReportException(e);
		}
		_file_stream = null;
		_file_reader = null;
		_is_open = false;
		_current_record = null;
		log.info("Data source list is closed. file=\"" + _input_file_uri.toString() + "\"");
		if (is_delete) {
			deleteFile(true);
		}
	}

	/**
	 * 新規レコードを生成します。
	 *
	 * @param line レコード文字列
	 * @return レコードデータ
	 * @throws UnsupportedEncodingException エンコードサポートしない例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected IFixedLengthRecord createRecord(String line) throws UnsupportedEncodingException {
		String[] values = parse(line);
		IFixedLengthRecord record = new GFixedLengthRecord();
		record.initialize(this, values);
		return record;
	}

	/**
	 * 削除フラグが true の場合、ファイルを削除します。
	 *
	 * @param is_retry リトライ
	 * @throws GReportException 例外
	 * @create 2006/02/08
	 * @author kusakari
	 * @since 1.1.0
	 */
	protected void deleteFile(boolean is_retry) throws GReportException {
		// TODO 2022/09/09 KCSS
		// "jar"、"vfs"スキームは、zipファイルにあるファイルを示す。is_deleteフラグを付けるのは、ありえない
		// 今後、GReportFileUtilityは、GFileUtilsに入れる予定。
		// Schemeタイプの判断は、不要。deleteFile()は、GFileUtilsに委譲する。
		if (GURIScheme.FILE.getValue().equals(_input_file_uri.getScheme())) {
			GReportFileUtility.deleteFile(new File(_input_file_uri.getPath()), is_retry);
		}
	}

	/**
	 * 指定した項目名の項目オブジェクトを取得します.<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#getColumn(String)
	 * @param name 項目名
	 * @return 項目オブジェクト
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public IReportColumn getColumn(String name) {
		if (name == null) {
			return null;
		}

		IReportColumn[] columnArray = getColumnArray();
		for (int i = 0; i < columnArray.length; i++) {
			if (name.equals(columnArray[i].getName())) {
				return columnArray[i];
			}
		}

		return null;
	}

	/**
	 * リストに紐づく項目オブジェクトの配列を取得します.<BR>
	 * 項目は、データソース内に出現する順番にソートされています。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#getColumnArray()
	 * @return 項目オブジェクトの配列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public IReportColumn[] getColumnArray() {
		return _column_array;
	}

	/**
	 * インプットデータのエンコードタイプを取得します。
	 *
	 * @see IFixedLengthList#getEncoding()
	 * @return のエンコードタイプ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getEncoding() {
		return _encoding;
	}

	/**
	 * ファイルリーダーを取得します。
	 *
	 * @return ファイルリーダー
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected BufferedReader getFileReader() {
		return _file_reader;
	}

	/**
	 * ファイルストリームを取得します。
	 *
	 * @return ファイルストリーム
	 * @create 2006/02/13
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected InputStream getFileStream() {
		return _file_stream;
	}

	/**
	 * データソースとなるファイルのファイル名を取得します。
	 *
	 * @see IFixedLengthList#getInputFileName()
	 * @return データソースとなるファイルのファイル名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getInputFileName() {
		return GFileUtils.getAbsolutePath(_input_file_uri);
	}

	/**
	 * レイアウト定義ファイルのファイル名を取得します。
	 *
	 * @see IFixedLengthList#getLayoutFileName()
	 * @return レイアウト定義ファイルのファイル名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getLayoutFileName() {
		return _layout_file;
	}

	/**
	 * レコード長(バイト数)を取得します。
	 *
	 * @see IFixedLengthList#getLineLength()
	 * @return レコード長(バイト数)
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public int getLineLength() {
		return _line_length;
	}

	/**
	 * 現在作業対象となっている行のレコードを取得します。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#getRecord()
	 * @return 現在作業対象となっている行のレコード
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public IReportRecord getRecord() throws GReportException {
		return _current_record;
	}

	/**
	 * レイアウト定義ファイルを指定して、インスタンスを初期化します。<br>
	 * 
	 * @see IFixedLengthList#initialize(String, String, boolean)
	 * @param layoutFilePath レイアウト定義ファイルのファイルパス
	 * @param inputFilePath データソースとなるファイルのファイルパス
	 * @param delete close後自動削除するかどうかのフラグ
	 * @throws GReportException
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	@Deprecated
	public void initialize(String layoutFilePath, String inputFilePath, boolean delete) throws GReportException {
		initialize(GFileUtils.createURI(layoutFilePath), GFileUtils.createURI(inputFilePath), delete);
	}

	/**
	 * uriがnull、の場合、IllegalArgumentExceptionを発生させる。<br>
	 * 
	 * @param uri URIオブジェクト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	private void checkNull(URI uri) {
		if (uri == null) {
			throw new IllegalArgumentException("The specified uri cannot be null.");
		}
	}

	/**
	 * レイアウト定義ファイルを指定して、インスタンスを初期化します.<br>
	 *
	 * @see IFixedLengthList#initialize(URI, URI, boolean)
	 * @param layoutFile レイアウト定義ファイルのURI
	 * @param inputFile データソースとなるファイルのURI
	 * @param delete close後自動削除するかどうかのフラグ
	 * @throws GReportException
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public void initialize(URI layoutFile, URI inputFile, boolean delete) throws GReportException {
		checkNull(layoutFile);
		checkNull(inputFile);

		try {
			// フィールド値の設定
			_input_file_uri = inputFile;
			_layout_file = layoutFile.toString();

			_is_delete = delete;

			// XMLの解析
			Document doc = parseXmlDocument(_layout_file);

			// ルート要素を取得
			Element docRootNode = doc.getDocumentElement();

			// -------------------
			// recordノードの取得
			// -------------------
			xmlNodeDeSerialize4List(docRootNode);

			// --------------------
			// columnノードの取得
			// --------------------
			xmlNodeDeSerialize4Column(docRootNode);

			log.info("Data source list is initialized. file=\"" + _layout_file + "\"");

		} catch (ParserConfigurationException | SAXException | IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * リストを閉じた後、インプットファイルを削除するかを表す値を取得します。
	 *
	 * @see IFixedLengthList#isDelete()
	 * @return リストをドジた後に自動削除するかどうかのフラグ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public boolean isDelete() {
		return _is_delete;
	}

	/**
	 * レコードの区切りを改行とするかを表す値を取得します。
	 *
	 * @see IFixedLengthList#isLineSeparate()
	 * @return レコードの区切りを改行とするかどうかのフラグ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public boolean isLineSeparate() {
		return _is_line_separate;
	}

	/**
	 * 読み飛ばしバイト数を取得します。
	 *
	 * @see IFixedLengthList#getSkipBytes()
	 * @return 読み飛ばしバイト数
	 * @create 2010/01/26
	 * @author takaishi
	 * @since 1.6.0
	 */
	@Override
	public int getSkipBytes() {
		return _skip_bytes;
	}

	/**
	 * リストが既に開かれているかを表す値を取得します。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#isOpen()
	 * @return リストが既に開かれているか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public boolean isOpen() {
		return _is_open;
	}

	/**
	 * 作業対象行を次の行へ移動させます。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#next()
	 * @return true:最終行でない時/false:最終行時
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public boolean next() throws GReportException {
		try {
			String currentData = null;

			if (!isLineSeparate()) {
				// --------------
				// 改行なし
				// --------------
				if (_file_stream == null) {
					return false;
				}

				byte[] b = new byte[getLineLength()];
				int i = _file_stream.read(b);
				// データが無くなった場合
				if (i == -1) {
					return false;
				}

				if (getEncoding() != null) {
					currentData = new String(b, getEncoding());
				} else {
					currentData = new String(b);
				}

			} else {
				// --------------
				// 改行あり
				// --------------
				if (_file_reader == null) {
					return false;
				}

				currentData = _file_reader.readLine();
				// データが無くなった場合
				if (currentData == null) {
					return false;
				}
			}

			_current_record = createRecord(currentData);
		} catch (IOException e) {
			throw new GReportException(e);
		}

		return true;
	}

	/**
	 * リストを開きます。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#open()
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void open() throws GReportException {
		if (_input_file_uri == null) {
			return;
		}

		InputStreamReader isr = null;
		try {
			// 既に開いている場合は一度閉じます。
			if (_file_stream != null) {
				close();
			}
			_file_stream = _input_file_uri.toURL().openStream();

			// v1.6.0
			if (0 < _skip_bytes && _skip_bytes <= _file_stream.available()) {
				for (int i = 0; i < _skip_bytes; i++) {
					_file_stream.read();
				}
			}

			if (isLineSeparate()) {
				// 改行区切りの場合はBufferedReaderを利用する
				if (getEncoding() != null) {
					isr = new InputStreamReader(_file_stream, getEncoding());
				} else {
					isr = new InputStreamReader(_file_stream);
				}
				_file_reader = new BufferedReader(isr);
			}

			_is_open = true;
			log.info("Data source list is opened. file=\"" + _input_file_uri.toString() + "\"");
		} catch (IOException | RuntimeException e) {
			try {
				if (_file_stream != null) {
					_file_stream.close();
				}
				if (isr != null) {
					isr.close();
				}
				if (_file_reader != null) {
					_file_reader.close();
				}
			} catch (IOException ex) {
				log.error("file close error.", ex);
			}

			throw new GReportException(e);
		}
	}

	/**
	 * 指定された文字列行データを解析し、項目値配列を取得します。
	 *
	 * @param currentData 行データ
	 * @return 項目値配列
	 * @throws UnsupportedEncodingException エンコードサポートしない例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected String[] parse(String currentData) throws UnsupportedEncodingException {
		byte[] currentDataBytes = null;
		if (getEncoding() != null) {
			currentDataBytes = currentData.getBytes(getEncoding());
		} else {
			currentDataBytes = currentData.getBytes();
		}
		// 行のバイト数チェック
		if (currentDataBytes.length < getLineLength()) {
			throw new IllegalArgumentException("This data doesn't fill the record length. : " + currentData);
		}

		IFixedLengthColumn[] columns = (IFixedLengthColumn[]) getColumnArray();
		String[] values = new String[columns.length];
		int byteCnt = 0;
		for (int i = 0; i < columns.length; i++) {
			IFixedLengthColumn col = columns[i];
			byte[] colBytes = new byte[col.getLength()];
			// 配列の部分コピー
			System.arraycopy(currentDataBytes, byteCnt, colBytes, 0, col.getLength());

			String value = null;
			if (getEncoding() != null) {
				value = new String(colBytes, getEncoding());
			} else {
				value = new String(colBytes);
			}

			values[i] = value;
			byteCnt += col.getLength();
		}

		return values;
	}

	/**
	 * 指定されたレイアウト定義ファイルを解析し、Documentオブジェクトを取得します。
	 *
	 * @param layout_file レイアウト定義ファイルのファイル名
	 * @return Documentオブジェクト
	 * @throws ParserConfigurationException 変換例外
	 * @throws SAXException SAX例外
	 * @throws IOException IO例外
	 * @create create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected Document parseXmlDocument(String layout_file)
		throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilder builder = GXmlParser.createDocumentBuilder(DTD_DATA_SOURCE_FIXED_LENGTH_EN,
			RESOURCE_KEY_FIXED_LENGTH_DATASOURCE_FL_DTD, URL_KEY_DATASOURCE_FL_DTD);
		return builder.parse(layout_file);
	}

	/**
	 * 作業行をリセットします.<BR>
	 * 内部的にいったんファイルをクローズし、またオープンしています。
	 *
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void reset() throws GReportException {
		close(false);
		open();
	}

	/**
	 * 項目配列を設定します。
	 *
	 * @param array 項目配列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setColumnArray(IFixedLengthColumn[] array) {
		_column_array = array;
	}

	/**
	 * 現在作業対象中のレコードを設定します。
	 *
	 * @param record 現在作業対象中のレコード
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setCurrentRecord(IFixedLengthRecord record) {
		_current_record = record;
	}

	/**
	 * インプットデータのエンコードタイプを設定します。
	 *
	 * @param encoding インプットデータのエンコードタイプ
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setEncoding(String encoding) {
		_encoding = encoding;
	}

	/**
	 * ファイルリーダーを設定します。
	 *
	 * @param reader ファイルリーダー
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setFileReader(BufferedReader reader) {
		_file_reader = reader;
	}

	/**
	 * ファイルストリームを設定します。
	 *
	 * @param stream ファイルストリーム
	 * @create 2006/02/13
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setFileStream(InputStream stream) {
		_file_stream = stream;
	}

	/**
	 * クローズ時にインプットファイルを削除するかを表す値を設定します。
	 *
	 * @param is_delete クローズ時にインプットファイルを削除するか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsDelete(boolean is_delete) {
		_is_delete = is_delete;
	}

	/**
	 * レコードの区切りを改行とするかを表す値を設定します。
	 *
	 * @param is_line_separate レコードの区切りを改行とするか
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsLineSeparate(boolean is_line_separate) {
		_is_line_separate = is_line_separate;
	}

	/**
	 * ファイルが開いているかを表す値を設定します。
	 *
	 * @param is_open ファイルが開いているか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsOpen(boolean is_open) {
		_is_open = is_open;
	}

	/**
	 * レイアウト定義ファイル名を設定します。
	 *
	 * @param filename レイアウト定義ファイル名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setLayoutFileName(String filename) {
		_layout_file = filename;
	}

	/**
	 * レコード長(バイト数)を設定します。
	 *
	 * @param length レコード長(バイト数)
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setLineLength(int length) {
		_line_length = length;
	}

	/**
	 * 項目情報が詰まれたXMLエレメントから、項目オブジェクトを生成します。
	 *
	 * @param doc_root_node XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void xmlNodeDeSerialize4Column(Element doc_root_node) {
		int recordLengthCnt = 0;
		NodeList columnNodeList = doc_root_node.getElementsByTagName(GFixedLengthList.TAG_NAME_COLUMN);
		if (columnNodeList != null && columnNodeList.getLength() > 0) {
			IFixedLengthColumn[] columnArray = new IFixedLengthColumn[columnNodeList.getLength()];
			for (int i = 0; i < columnNodeList.getLength(); i++) {
				Element columnNode = (Element) columnNodeList.item(i);
				IFixedLengthColumn column = new GFixedLengthColumn();
				column.initialize(this, columnNode);
				columnArray[i] = column;
				recordLengthCnt += column.getLength();
			}

			_column_array = columnArray;
		} else {
			_column_array = new IFixedLengthColumn[0];
		}

		// レコード長チェック
		if (_line_length < recordLengthCnt) {
			throw new IllegalArgumentException(
				"The record lengths are smaller than totals of the column length. : " + _line_length);
		}
	}

	/**
	 * 指定されたXMLエレメントからリスト情報を抽出し展開します。
	 *
	 * @param doc_root_node XMLエレメント
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void xmlNodeDeSerialize4List(Element doc_root_node) {
		NodeList listNodeList = doc_root_node.getElementsByTagName(GFixedLengthList.TAG_NAME_LIST);

		Element listNode = (Element) listNodeList.item(0);
		if (listNode != null) {
			// lineseparate
			Attr lineseparateAttr = listNode.getAttributeNode(GFixedLengthList.TAG_NAME_LINE_SEPARATE);
			if (lineseparateAttr != null) {
				String lineseparate = lineseparateAttr.getValue();
				if (lineseparate != null) {
					_is_line_separate = Boolean.valueOf(lineseparate).booleanValue();
				}
			}

			// linelength
			Attr linelengthAttr = listNode.getAttributeNode(GFixedLengthList.TAG_NAME_LINE_LENGTH);
			if (linelengthAttr != null) {
				int lineLength = Integer.parseInt(linelengthAttr.getValue());
				if (lineLength <= 0) {
					throw new IllegalArgumentException("record length should be larger than 0.");
				}
				_line_length = lineLength;
			}

			// skipbytes
			Attr skipbytesAttr = listNode.getAttributeNode(GFixedLengthList.TAG_NAME_SKIP_BYTES);
			if (skipbytesAttr != null) {
				int skipBytes = Integer.parseInt(skipbytesAttr.getValue());
				if (skipBytes <= 0) {
					throw new IllegalArgumentException("skip bytes should be larger than 0.");
				}
				_skip_bytes = skipBytes;
			}

			// encoding
			Attr encodingAttr = listNode.getAttributeNode(GFixedLengthList.TAG_NAME_ENCODING);
			if (encodingAttr != null) {
				setEncoding(encodingAttr.getValue());
			}
		}
	}
}
