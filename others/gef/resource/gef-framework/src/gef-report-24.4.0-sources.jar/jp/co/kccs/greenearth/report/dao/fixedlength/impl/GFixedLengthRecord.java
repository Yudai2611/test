/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.fixedlength.impl;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.report.dao.IReportColumn;
import jp.co.kccs.greenearth.report.dao.IReportList;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthList;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthRecord;

/**
 * 固定長データリストの行のデフォルト実装クラスです。
 * 
 * @create 2006/02/07
 * @author kitamura
 * @since 1.1.0
 */
public class GFixedLengthRecord implements IFixedLengthRecord {

	/** オーナーリスト */
	private IFixedLengthList _list = null;
	/** 項目値マップ */
	private Map<String, GFixedLengthVariant> _variant_map = null;

	/**
	 * 行の項目値を指定して、インスタンスを初期化します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthRecord#initialize(jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthList, java.lang.String[])
	 * @param list リスト
	 * @param values 項目値の配列
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void initialize(IFixedLengthList list, String[] values) {
		_list = list;
		IFixedLengthColumn[] columns = (IFixedLengthColumn[]) list.getColumnArray();
		for (int i = 0; i < columns.length; i++) {
			GFixedLengthVariant variant = new GFixedLengthVariant(columns[i], values[i]);
			getMap().put(columns[i].getName(), variant);
		}
	}

	/**
	 * この項目が関連づくListオブジェクトを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#getList()
	 * @return Listオブジェクト
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public IReportList getList() {
		return _list;
	}

	/**
	 * 指定した項目の値を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#getVariable(java.lang.String)
	 * @param name 項目名
	 * @return 項目の値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public Object getVariable(String name) {
		if (name == null) {
			return null;
		}
		GFixedLengthVariant variant = getMap().get(name);
		if (variant == null) {
			return null;
		}
		return variant.getValue();
	}

	/**
	 * 指定した項目の値を文字列表現で取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#getVariableString(java.lang.String)
	 * @param name 項目名
	 * @return 項目の値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getVariableString(String name) {
		if (name == null) {
			return null;
		}
		GFixedLengthVariant variant = getMap().get(name);
		if (variant == null) {
			return null;
		}
		return variant.getString();
	}

	/**
	 * オーナーリストを設定します。
	 * 
	 * @param list オーナーリスト
	 * @create 2006/02/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setList(IFixedLengthList list) {
		_list = list;
	}

	/**
	 * 指定された項目に、指定された値を設定します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#setVariable(java.lang.String, java.lang.Object)
	 * @param name 項目名
	 * @param value 項目の値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void setVariable(String name, Object value) {
		if (name == null) {
			return;
		}
		GFixedLengthVariant variant = (GFixedLengthVariant) getMap().get(name);
		if (variant == null) {
			return;
		}
		variant.setValue(value);
	}

	/**
	 * レコードの各項目値を文字列として取得します.<BR>
	 * フォーマット 項目値|項目値|項目値...<BR>
	 * 各項目値は内部的にgetVariableString(String)メソッドを用いて取得しています。
	 * 
	 * @see java.lang.Object#toString()
	 * @return レコードの各項目値を文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String toString() {
		if (_list != null) {
			StringBuilder buf = new StringBuilder();
			IReportColumn[] colArray = (IReportColumn[]) _list.getColumnArray();
			for (int i = 0; i < colArray.length; i++) {
				buf.append(getVariableString(colArray[i].getName()) + "|");
			}
			String s = buf.toString();
			if (s.length() > 0) {
				s = s.substring(0, s.length() - 1);
			}
			return s;
		} else {
			return "list is null.";
		}
	}
	
	/**
	 * 【機能】Mapを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return マップオブジェクト
	 * @since 1.0.0
	 * @create 
	 * @author 
	 * @since 
	 */
	Map<String, GFixedLengthVariant> getMap() {
		if (_variant_map == null) {
			_variant_map = new HashMap<String, GFixedLengthVariant>();
		}
		return _variant_map;
	}
}
