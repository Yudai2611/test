/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.fixedlength.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

import jp.co.kccs.greenearth.commons.utils.GDateUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthColumn;

/**
 * 固定長データの項目値を表すクラスです。
 * 
 * @create 2006/02/08
 * @author kitamura
 * @since 1.1.0
 */
public class GFixedLengthVariant {

	/** 項目情報 */
	private IFixedLengthColumn _column = null;
	/** 値 */
	private Object _value = null;

	/**
	 * 項目情報と値を指定して、GFixedLengthVariantインスタンスを初期化します。
	 * 
	 * @param column 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	GFixedLengthVariant(IFixedLengthColumn column, String value) {
		_column = column;
		setString(value);
	}

	/**
	 * 項目情報を取得します。
	 * 
	 * @return 項目情報
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public IFixedLengthColumn getColumn() {
		return _column;
	}

	/**
	 * 項目情報を取得します。
	 * 
	 * @return 項目情報
	 * @create 2014/12/16
	 * @author KCCS Inakagi
	 * @since 2.0.0
	 */
	public IFixedLengthColumn getColumnWithNullCheck() {
		if (_column == null) {
			throw new GReportRuntimeException("A Column is Null.");
		}
		return _column;
	}
	
	/**
	 * 項目値を文字列として取得します.<BR>
	 * 基本的にはtoString()した値ですが、日付型に関しては指定されたフォーマットで整形した値を取得します。
	 * 
	 * @return 文字列に変換した項目値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getString() {
		if (_value == null) {
			return null;
		} 
		if (IFixedLengthColumn.TYPE_DATETIME == getColumnWithNullCheck().getType()) {
			return GDateUtils.formatToString((Date) _value , GStringUtils.nullToBlank(getColumnWithNullCheck().getFormat()));
		} 

		return _value.toString();
	}

	/**
	 * 項目値を取得します。
	 * 
	 * @return 項目値
	 * @create 2006/02/08
	 * @author kitamura
	 * @since 1.1.0
	 */
	public Object getValue() {
		return _value;
	}

	/**
	 * 項目情報を設定します。
	 * 
	 * @param column 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setColumn(IFixedLengthColumn column) {
		_column = column;
	}

	/**
	 * 文字列で項目値を設定します.<BR>
	 * 各型に応じて値が整形されセットされます。
	 * 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setString(String value) {
		if (value == null) {
			_value = null;
		} else if (IFixedLengthColumn.TYPE_INTEGER == getColumnWithNullCheck().getType()) {
			setString4Integer(value);
		} else if (IFixedLengthColumn.TYPE_STRING == getColumnWithNullCheck().getType()) {
			setString4String(value);
		} else if (IFixedLengthColumn.TYPE_NSTRING == getColumnWithNullCheck().getType()) {
			setString4String(value);
		} else if (IFixedLengthColumn.TYPE_DATETIME == getColumnWithNullCheck().getType()) {
			setString4DateTime(value);
		} else if (IFixedLengthColumn.TYPE_YM == getColumnWithNullCheck().getType()) {
			setString4String(value);
		} else if (IFixedLengthColumn.TYPE_DECIMAL == getColumnWithNullCheck().getType()) {
			setString4Decimal(value);
		} else if (IFixedLengthColumn.TYPE_LONG == getColumnWithNullCheck().getType()) {
			setString4Long(value);
		} else {
			throw new IllegalArgumentException("Illegal type. : " + getColumnWithNullCheck().getType());
		}
	}

	/**
	 * 日付型の項目に文字列で値を設定します。<BR>
	 * 日付として認識できない場合は例外を発生します。
	 * 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4DateTime(String value) {
		if ("".equals(trimLeft(value))) {
			_value = null;
		} else {
			try {
				_value = GDateUtils.toDate(value, GStringUtils.nullToBlank(getColumnWithNullCheck().getFormat()));
			} catch (ParseException e) {
				throw new GReportRuntimeException(e);
			}
		}
	}

	/**
	 * 実数型の項目に文字列で値を設定します。<BR>
	 * 実数として認識できない場合は例外を発生します。
	 * 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4Decimal(String value) {
		if ("".equals(trimLeft(value))) {
			_value = null;
		} else {
			if (getColumnWithNullCheck().isPoint()) {
				value = trimLeft((String) value);
				_value = new BigDecimal((String) value);
			} else {
				String s = value.toString();
				String intNum = s.substring(0, getColumnWithNullCheck().getLength() - getColumnWithNullCheck().getDecimalLength());
				intNum = trimLeft(intNum);
				intNum = trimPlus(intNum);
				String decNum = s.substring(getColumnWithNullCheck().getLength() - getColumnWithNullCheck().getDecimalLength(), s.length());
				decNum = trimZeroRight(decNum);
				if (decNum.length() == 0) {
					decNum = "0";
				}
				_value = new BigDecimal(intNum + "." + decNum);
			}
		}
	}

	/**
	 * Integer型の項目に文字列で値を設定します。<BR>
	 * Integer値として認識できない場合は例外を発生します。
	 * 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4Integer(String value) {
		// 空白をトリムします
		value = trimLeft(value);

		if ("".equals(value)) {
			_value = null;
		} else {
			value = trimPlus(value);
			_value = new Integer(value);
		}
	}

	/**
	 * Long型の項目に文字列で値を設定します。<BR>
	 * Long値として認識できない場合は例外を発生します。
	 * 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4Long(String value) {
		value = trimLeft(value);

		if ("".equals(value)) {
			_value = null;
		} else {
			value = trimPlus(value);
			_value = new Long((String) value);
		}
	}

	/**
	 * 文字列型の項目に文字列で値を設定します。
	 * 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4String(String value) {

		if (getColumnWithNullCheck().isTrim()) {
			value = trimRight(value);
		}

		_value = value;
	}

	/**
	 * 項目値を設定します。<BR>
	 * データタイプにマッチする形式の値でない場合は例外が発生します。
	 * 
	 * @param value 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setValue(Object value) {
		if (value == null) {
			_value = null;
		} else if (IFixedLengthColumn.TYPE_INTEGER == getColumnWithNullCheck().getType()) {
			if (value instanceof Integer) {
				_value = value;
			}
			else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (IFixedLengthColumn.TYPE_STRING == getColumnWithNullCheck().getType()) {
			if (value instanceof String) {
				_value = value;
			}
			else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (IFixedLengthColumn.TYPE_NSTRING == getColumnWithNullCheck().getType()) {
			if (value instanceof String) {
				_value = value;
			}
			else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (IFixedLengthColumn.TYPE_DATETIME == getColumnWithNullCheck().getType()) {
			if (value instanceof Date) {
				_value = value;
			}
			else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (IFixedLengthColumn.TYPE_YM == getColumnWithNullCheck().getType()) {
			if (value instanceof String) {
				_value = value;
			}
			else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (IFixedLengthColumn.TYPE_DECIMAL == getColumnWithNullCheck().getType()) {
			if (value instanceof BigDecimal) {
				_value = value;
			}
			else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (IFixedLengthColumn.TYPE_LONG == getColumnWithNullCheck().getType()) {
			if (value instanceof Long) {
				_value = value;
			}
			else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else {
			throw new IllegalArgumentException("Illegal type. : " + getColumnWithNullCheck().getType());
		}
	}

	/**
	 * 数値項目の先頭にある符号の"+"をトリムします。
	 * 
	 * @param s 
	 * @return プラスをトリムした文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected String trimPlus(String s) {
		if (s.indexOf("+") == 0) {
			s = s.substring(1);
		}

		return s;
	}

	/**
	 * LTrim を実行します.<BR>
	 * GTextUtility#trimLeft(String)をコピーしています。
	 * 
	 * @param str 
	 * @return 左の空白をトリムした文字列
	 * @create 2004/07/06
	 * @author kusakari
	 * @since 0.3.0
	 */
	private String trimLeft(String str) {
		if (str == null) {
			return null;
		}
		if ("".equals(str)) {
			return "";
		}

		String s = str;
		int idx = str.length();
		char[] c = s.toCharArray();
		for (int i = 0; i < s.length(); i++) {
			if (c[i] != ' ') {
				idx = i;
				break;
			}
		}
		return s.substring(idx);
	}

	/**
	 * RTrim を実行します.<BR>
	 * GTextUtility#trimRight(String)をコピーしています。
	 * 
	 * @param str 
	 * @return 右の空白をトリムした文字列
	 * @create 2004/07/06
	 * @author kusakari
	 * @since 0.3.0
	 */
	private String trimRight(String str) {
		if (str == null) {
			return null;
		}
		if ("".equals(str)) {
			return "";
		}

		String s = str;
		int idx = -1;
		char[] c = s.toCharArray();
		int size = s.length() - 1;
		for (int i = size; 0 <= i; i--) {
			if (c[i] != ' ') {
				idx = i;
				break;
			}
		}

		// ' 'ではない文字は含めます
		return s.substring(0, idx + 1);
	}

	/**
	 * 右端の'0'をトリムします。
	 * 
	 * @param str 
	 * @return 右の0をトリムした文字列
	 * @create 2006/02/12
	 * @author kitamura
	 * @since 0.3.0
	 */
	private String trimZeroRight(String str) {
		if (str == null) {
			return null;
		}
		
		if (str.equals("")) {
			return "";
		}

		String s = str;
		int idx = -1;
		char[] c = s.toCharArray();
		int size = s.length() - 1;
		for (int i = size; 0 <= i; i--) {
			if (c[i] != '0') {
				idx = i;
				break;
			}
		}

		return s.substring(0, idx + 1);
	}
}
