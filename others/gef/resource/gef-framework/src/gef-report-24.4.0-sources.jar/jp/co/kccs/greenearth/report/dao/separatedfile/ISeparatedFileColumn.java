/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.separatedfile;

import jp.co.kccs.greenearth.report.dao.IReportColumn;

import org.w3c.dom.Element;

/**
 * セパレートファイルデータリストの項目を表すインターフェースです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public interface ISeparatedFileColumn extends IReportColumn {

	/**
	 * 日付フォーマットを取得します。
	 * 
	 * @create 2006/03/10
	 * @return 日付フォーマット
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getFormat();

	/**
	 * 項目名を元にインスタンスを初期化します。
	 * 
	 * @create 2006/03/10
	 * @param list オーナーリスト
	 * @param column_name 項目名
	 * @author kitamura
	 * @since 1.1.0
	 */
	void initialize(ISeparatedFileList list, String column_name);

	/**
	 * 項目情報が積まれたXMLエレメントを元にインスタンスを初期化します。
	 * 
	 * @create 2006/03/10
	 * @param list オーナーリスト
	 * @param element 項目情報が積まれたXMLエレメント
	 * @author kitamura
	 * @since 1.1.0
	 */
	void initialize(ISeparatedFileList list, Element element);
}
