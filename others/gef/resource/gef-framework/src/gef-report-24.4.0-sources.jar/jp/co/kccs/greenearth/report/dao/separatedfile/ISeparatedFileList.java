/*
 * Copyright 2006-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.separatedfile;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.dao.IReportList;

import java.net.URI;

/**
 * セパレートファイルデータリストを表すインターフェースです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public interface ISeparatedFileList extends IReportList {

	/** カンマ区切り */
	public static final int TYPE_CSV = 0;
	/** タブ区切り */
	public static final int TYPE_TSV = 1;

	/**
	 * インプットデータのエンコードタイプを取得します。
	 * 
	 * @create 2006/03/10
	 * @return エンコードタイプ
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getEncoding();

	/**
	 * データソースとなるファイルのファイル名を取得します。
	 * 
	 * @create 2006/03/10
	 * @return ファイル名
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getInputFileName();

	/**
	 * レイアウト定義ファイルのファイル名を取得します。
	 * 
	 * @create 2006/03/10
	 * @return レイアウト定義ファイルのファイル名
	 * @author kitamura
	 * @since 1.1.0
	 */
	String getLayoutFileName();

	/**
	 * セパレートタイプを取得します。
	 * 
	 * @create 2006/03/10
	 * @return セパレートタイプ
	 * @author kitamura
	 * @since 1.1.0
	 */
	int getSeparatedType();

	/**
	 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
	 * inputFilePathは、以下二つパターンを対応できる<br>
	 * <パターン１＞ 相対パス指定（"dir/file.txt"）<br>
	 * <パターン２＞ 絶対パス指定（fileObj.getAbsolutePath(): "c:/dir/file.txt"）<br>
	 * 
	 * @param inputFilePath データソースとなるファイルのファイルパス
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param encoding インプットデータのエンコードタイプ
	 * @param separatedType セパレートタイプ
	 * @throws GReportException ReportEngine例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Deprecated
	void initialize(String inputFilePath, boolean delete, String encoding, int separatedType) throws GReportException;

	/**
	 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
	 *
	 * @param inputFile データソースとなるファイルのURI
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param encoding インプットデータのエンコードタイプ
	 * @param separatedType セパレートタイプ
	 * @throws GReportException ReportEngine例外
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	void initialize(URI inputFile, boolean delete, String encoding, int separatedType) throws GReportException;

	/**
	 * レイアウト定義ファイルを指定して、インスタンスを初期化します.<br>
	 * layoutFilePathとinputFilePathは、以下二つパターンを対応できる<br>
	 * <パターン１＞ 相対パス指定（"dir/file.txt"）<br>
	 * <パターン２＞ 絶対パス指定（fileObj.getAbsolutePath(): "c:/dir/file.txt"）<br>
	 * 
	 * @param layoutFilePath レイアウト定義ファイルのファイルパス
	 * @param inputFilePath データソースとなるファイルのファイルパス
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param separatedType セパレートタイプ
	 * @throws GReportException ReportEngine例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Deprecated
	void initialize(String layoutFilePath, String inputFilePath, boolean delete, int separatedType)
		throws GReportException;

	/**
	 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
	 *
	 * @param inputFile データソースとなるファイルのURI
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param separatedType セパレートタイプ
	 * @throws GReportException ReportEngine例外
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	void initialize(URI layoutFile, URI inputFile, boolean delete, int separatedType) throws GReportException;

	/**
	 * リストを閉じた後、インプットファイルを削除するかを表す値を取得します。
	 * 
	 * @create 2006/03/10
	 * @return 削除する:true、削除しない:false
	 * @author kitamura
	 * @since 1.1.0
	 */
	boolean isDelete();

	// v1.6.0
	/**
	 * 読み飛ばしバイト数を取得します。
	 * 
	 * @create 2010/01/26
	 * @return 読み飛ばしバイト数
	 * @author takaishi
	 * @since 1.6.0
	 */
	int getSkipBytes();

	/**
	 * ISeparatedFileListのファクトリークラスです。
	 * 
	 * @create 2006/02/08
	 * @author kitamura
	 * @since 2.0.0
	 */
	class Factory {

		/**
		 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
		 * 
		 * @create 2006/03/10
		 * @param inputFilePath データソースとなるファイルのファイルパス
		 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
		 * @param encoding インプットデータのエンコードタイプ
		 * @param separatedType セパレートタイプ
		 * @return リスト
		 * @throws GReportException ReportEngine例外
		 * @author kitamura
		 * @since 1.1.0
		 */
		@Deprecated
		public static ISeparatedFileList createList(String inputFilePath, boolean delete, String encoding,
			int separatedType) throws GReportException {
			return createList(GFileUtils.createURI(inputFilePath), delete, encoding, separatedType);
		}

		/**
		 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
		 *
		 * @param inputFile データソースとなるファイルのファイルパス
		 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
		 * @param encoding インプットデータのエンコードタイプ
		 * @param separatedType セパレートタイプ
		 * @return リスト
		 * @throws GReportException ReportEngine例外
		 * @create 2023/10/25
		 * @author KCSS yangfeng
		 * @since 23.10.0
		 */
		public static ISeparatedFileList createList(URI inputFile, boolean delete, String encoding, int separatedType)
			throws GReportException {
			ISeparatedFileList list = GFrameworkUtils.getComponent("SeparatedFileList");
			list.initialize(inputFile, delete, encoding, separatedType);
			return list;
		}

		/**
		 * ISeparatedFileListを生成します.<br>
		 * 
		 * @create 2006/03/10
		 * @param layoutFilePath レイアウト定義ファイルのファイルパス
		 * @param inputFilePath データソースとなるファイルのファイルパス
		 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
		 * @param separatedType セパレートタイプ
		 * @return リスト
		 * @throws GReportException ReportEngine例外
		 * @author kitamura
		 * @since 1.1
		 */
		@Deprecated
		public static ISeparatedFileList createList(String layoutFilePath, String inputFilePath, boolean delete,
			int separatedType) throws GReportException {
			return createList(GFileUtils.createURI(layoutFilePath), GFileUtils.createURI(inputFilePath), delete,
				separatedType);
		}

		/**
		 * ISeparatedFileListを生成します.<br>
		 *
		 * @param layoutFile レイアウト定義ファイルのファイルパス
		 * @param inputFile データソースとなるファイルのファイルパス
		 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
		 * @param separatedType セパレートタイプ
		 * @return リスト
		 * @throws GReportException ReportEngine例外
		 * @create 2023/10/25
		 * @author KCSS yangfeng
		 * @since 23.10.0
		 */
		public static ISeparatedFileList createList(URI layoutFile, URI inputFile, boolean delete, int separatedType)
			throws GReportException {
			ISeparatedFileList list = GFrameworkUtils.getComponent("SeparatedFileList");
			list.initialize(layoutFile, inputFile, delete, separatedType);
			return list;
		}
	}
}
