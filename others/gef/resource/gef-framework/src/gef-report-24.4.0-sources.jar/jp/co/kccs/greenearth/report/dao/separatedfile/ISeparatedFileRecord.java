/*
 * Copyright 2006 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.separatedfile;

import jp.co.kccs.greenearth.report.dao.IReportRecord;

/**
 * セパレートファイルデータリストの行を表すインターフェースです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public interface ISeparatedFileRecord extends IReportRecord {

	/**
	 * 行の項目値を指定して、インスタンスを初期化します。
	 * 
	 * @create 2006/02/08
	 * @param list セパレートファイルデータリスト
	 * @param values 値の配列
	 * @author kitamura
	 * @since 1.1.0
	 */
	void initialize(ISeparatedFileList list, String[] values);
}
