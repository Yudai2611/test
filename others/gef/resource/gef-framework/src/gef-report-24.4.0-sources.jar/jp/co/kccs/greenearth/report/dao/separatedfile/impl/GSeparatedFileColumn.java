/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.separatedfile.impl;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.report.dao.IReportList;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileColumn;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileList;

import org.w3c.dom.Attr;
import org.w3c.dom.Element;

/**
 * セパレートファイルデータリストの項目のデフォルト実装クラスです。
 * 
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public class GSeparatedFileColumn implements ISeparatedFileColumn {
	/** 属性名 type */
	private static final String ATTRIBUTE_TYPE = "type";
	/** 属性名 name */
	private static final String ATTRIBUTE_NAME = "name";
	/** 属性名 format */
	private static final String ATTRIBUTE_FORMAT = "format";
	
	/** 日付フォーマット */
	private String _format = null;
	/** オーナーリスト */
	private ISeparatedFileList _list = null;
	/** 項目名 */
	private String _name = null;
	/** データタイプ */
	private int _type = TYPE_STRING;

	/**
	 * デフォルトコンストラクタ
	 * 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GSeparatedFileColumn() {
	}

	/**
	 * propertiesファイルよりgeframe.report.Convert.Datasource.DefaultDateFormatを取得します。
	 * 
	 * @return propertiesファイルよりgeframe.report.Convert.Datasource.DefaultDateFormat
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected String getDefaultDateFormat() {
		return GFrameworkUtils.getProperty("geframe.report.Convert.Datasource.DefaultDateFormat");
	}

	/**
	 * 日付フォーマットを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileColumn#getFormat()
	 * @return 日付フォーマット
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getFormat() {
		return _format;
	}

	/**
	 * オーナーリストを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportColumn#getList()
	 * @return オーナーリスト
	 * @create 2006/02/23
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public IReportList getList() {
		return _list;
	}

	/**
	 * 項目名を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportColumn#getName()
	 * @return 項目名
	 * @create 2006/02/07
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * データタイプを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportColumn#getType()
	 * @return データタイプ
	 * @create 2006/02/07
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public int getType() {
		return _type;
	}

	/**
	 * 項目情報が積まれたXMLエレメントを元にインスタンスを初期化します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileColumn#initialize(jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileList, org.w3c.dom.Element)
	 * @param list オーナーリスト
	 * @param element XMLエレメン
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void initialize(ISeparatedFileList list, Element element) {
		if (element == null || list == null) {
			return;
		}

		_list = list;

		// name
		Attr nameAttr = element.getAttributeNode(ATTRIBUTE_NAME);
		if (nameAttr != null) {
			_name = nameAttr.getValue();
		}

		// type
		Attr typeAttr = element.getAttributeNode(ATTRIBUTE_TYPE);
		if (typeAttr != null) {
			_type = Integer.parseInt(typeAttr.getValue());
		}
		
		// format
		Attr formatAttr = element.getAttributeNode(ATTRIBUTE_FORMAT);
		if (formatAttr != null) {
			_format = formatAttr.getValue();
		} else {
			_format = getDefaultDateFormat();
		}
	}

	/**
	 * 項目名を元にインスタンスを初期化します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileColumn#initialize(jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileList, java.lang.String)
	 * @param list オーナーリスト
	 * @param column_name 項目名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void initialize(ISeparatedFileList list, String column_name) {
		if (list == null) {
			return;
		}

		_list = list;

		_name = column_name;

		_type = TYPE_STRING;
	}
	
	/**
	 * 日付フォーマットの初期化を行います。
	 * 
	 * @param format 日付フォーマット
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setFormat(String format) {
		_format = format;
	}

	/**
	 * オーナーリストを設定します。
	 * 
	 * @param list オーナーリスト
	 * @create 2006/02/23
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setList(ISeparatedFileList list) {
		_list = list;
	}

	/**
	 * 項目名を設定します。
	 * 
	 * @param name 項目名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setName(String name) {
		_name = name;
	}

	/**
	 * データタイプを設定します。
	 * 
	 * @param type データタイプ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setType(int type) {
		_type = type;
	}

	/**
	 * 項目情報を"|"(パイプ)区切りで出力します.<BR>
	 * フォーマット 項目名|データタイプ|フォーマット
	 * 
	 * @see java.lang.Object#toString()
	 * @return 出力文字列
	 * @create 2006/02/11
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		buf.append(getName());
		buf.append("|" + getType());
		buf.append("|" + getFormat());

		return buf.toString();
	}
}
