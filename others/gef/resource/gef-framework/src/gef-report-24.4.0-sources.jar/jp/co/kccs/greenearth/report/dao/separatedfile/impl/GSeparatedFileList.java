/*
 * Copyright 2006-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.separatedfile.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.commons.utils.GURIScheme;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import jp.co.kccs.commons.tools.GSeparatedFileParser;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.dao.IReportColumn;
import jp.co.kccs.greenearth.report.dao.IReportRecord;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileColumn;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileList;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileRecord;
import jp.co.kccs.greenearth.report.utility.GReportFileUtility;
import jp.co.kccs.greenearth.report.utility.GXmlParser;

/**
 * セパレートファイルデータリストのデフォルト実装クラスです。
 *
 * @create 2006/03/10
 * @author kitamura
 * @since 1.1.0
 */
public class GSeparatedFileList implements ISeparatedFileList {

	/** タグ名 encoding **/
	private static final String TAG_NAME_ENCODING = "encoding";
	/** タグ名 skipbytes **/
	private static final String TAG_NAME_SKIP_BYTES = "skipbytes";
	/** タグ名 list **/
	private static final String TAG_NAME_LIST = "list";
	/** タグ名 column **/
	private static final String TAG_NAME_COLUMN = "column";

	/** URLキー **/
	private static final String URL_KEY_DATASOURCE_SF_DTD = "http://www.kccs.co.jp/greenearth/report/dtds/datasource-sf.dtd";
	/** リソースキー **/
	private static final String RESOURCE_KEY_SEPARATEDFILE_DATASOURCE_SF_DTD = "jp/co/kccs/greenearth/report/dao/separatedfile/datasource-sf.dtd";
	/** DTD **/
	private static final String DTD_DATA_SOURCE_SEPARATED_FILE_EN = "-//KCCS//DTD GreenEARTH ReportFramework DataSource SeparatedFile//EN";

	/** Logger **/
	protected static Log log = LogFactory.getLog(GSeparatedFileList.class);

	/** 項目リスト */
	private ISeparatedFileColumn[] _column_array = null;
	/** 現在のデータ */
	private ISeparatedFileRecord _current_record = null;
	/** エンコーディング */
	private String _encoding = null;
	/** ファイルリーダー */
	private BufferedReader _file_reader = null;
	/** インプットファイルのURI情報 */
	private URI _input_file_uri = null;
	/** クローズ時にインプットファイルを削除するかを表す値 */
	private boolean _is_delete = false;
	/** ヘッダー情報を含むかを表す値 */
	private boolean _is_include_header = false;
	/** ファイルが開いているかを表す値 */
	private boolean _is_open = false;
	/** レイアウト定義ファイル名 */
	private String _layout_file = null;
	/** 区切り文字 パーサ */
	private GSeparatedFileParser _parser = null;
	/** セパレートタイプ */
	private int _separated_type = ISeparatedFileList.TYPE_CSV;

	// v1.6.0
	/** 読み飛ばしバイト数 */
	private int _skip_bytes = 0;

	/**
	 * リストを閉じます。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#close()
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void close() throws GReportException {
		close(_is_delete);
	}

	/**
	 * インプットファイルを削除するかを指定してリストを閉じます。
	 *
	 * @param is_delete 自動削除フラグ
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void close(boolean is_delete) throws GReportException {
		if (_file_reader != null) {
			try {
				_file_reader.close();
			} catch (IOException e) {
				throw new GReportException(e);
			}
		}

		_current_record = null;
		_file_reader = null;
		_is_open = false;

		log.info("Data source list is closed. file=\"" + _input_file_uri.toString() + "\"");

		if (is_delete) {
			deleteFile(true);
		}
	}

	/**
	 * 新規レコードを生成します。
	 *
	 * @param line 行データ
	 * @return レコードデータ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected ISeparatedFileRecord createRecord(String line) {
		String[] values = _parser.parse(line);
		if (values == null || values.length < getColumnArray().length) {
			throw new IllegalArgumentException("This data doesn't fill the record length. : " + line);
		}
		ISeparatedFileRecord record = new GSeparatedFileRecord();
		record.initialize(this, values);
		return record;
	}

	/**
	 * 削除フラグが true の場合、ファイルを削除します。
	 *
	 * @param is_retry リトライフラグ
	 * @throws GReportException 例外
	 * @create 2006/02/08
	 * @author kusakari
	 * @since 1.1.0
	 */
	protected void deleteFile(boolean is_retry) throws GReportException {
		// TODO 2022/09/09 KCSS
		// "jar"、"vfs"スキームは、zipファイルにあるファイルを示す。is_deleteフラグを付けるのは、ありえない
		// 今後、GReportFileUtilityは、GFileUtilsに入れる予定。
		// Schemeタイプの判断は、不要。deleteFile()は、GFileUtilsに委譲する。
		if (GURIScheme.FILE.getValue().equals(_input_file_uri.getScheme())) {
			GReportFileUtility.deleteFile(new File(_input_file_uri.getPath()), is_retry);
		}
	}

	/**
	 * 指定した項目名の項目オブジェクトを取得します.<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#getColumn(String)
	 * @param name 項目名
	 * @return 項目オブジェクト
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public IReportColumn getColumn(String name) {
		if (name == null) {
			return null;
		}

		for (int i = 0; i < _column_array.length; i++) {
			if (name.equals(_column_array[i].getName())) {
				return _column_array[i];
			}
		}

		return null;
	}

	/**
	 * リストに紐づく項目オブジェクトの配列を取得します.<BR>
	 * 項目は、データソース内に出現する順番にソートされています。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#getColumnArray()
	 * @return 項目オブジェクトの配列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public IReportColumn[] getColumnArray() {
		return _column_array;
	}

	/**
	 * インプットデータのエンコードタイプを取得します。
	 *
	 * @see ISeparatedFileList#getEncoding()
	 * @return インプットデータのエンコードタイプ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getEncoding() {
		return _encoding;
	}

	// v1.6.0
	/**
	 * 読み飛ばしバイト数を取得します。
	 *
	 * @see ISeparatedFileList#getSkipBytes()
	 * @return 読み飛ばしバイト数
	 * @create 2010/01/26
	 * @author takaishi
	 * @since 1.6.0
	 */
	public int getSkipBytes() {
		return _skip_bytes;
	}

	/**
	 * ファイルパーサーを取得します。
	 *
	 * @return ファイルパーサー
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected GSeparatedFileParser getFileParser() {
		return _parser;
	}

	/**
	 * ファイルリーダーを取得します。
	 *
	 * @return ファイルリーダー
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected BufferedReader getFileReader() {
		return _file_reader;
	}

	/**
	 * データソースとなるファイルのファイル名を取得します。
	 *
	 * @see ISeparatedFileList#getInputFileName()
	 * @return データソースとなるファイルのファイル名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getInputFileName() {
		return GFileUtils.getAbsolutePath(_input_file_uri);
	}

	/**
	 * レイアウト定義ファイルのファイル名を取得します。
	 *
	 * @see ISeparatedFileList#getLayoutFileName()
	 * @return レイアウト定義ファイルのファイル名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getLayoutFileName() {
		return _layout_file;
	}

	/**
	 * 現在作業対象となっている行のレコードを取得します。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#getRecord()
	 * @return レコード
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public IReportRecord getRecord() throws GReportException {
		return _current_record;
	}

	/**
	 * @see ISeparatedFileList#getSeparatedType()
	 * @return タイプ
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public int getSeparatedType() {
		return _separated_type;
	}

	/**
	 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
	 * 
	 * @see ISeparatedFileList#initialize(String, boolean, String, int)
	 * 
	 * @param inputFilePath データソースとなるファイルのファイルパス
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param encoding インプットデータのエンコードタイプ
	 * @param separatedType セパレートタイプ
	 * @throws GReportException
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	@Deprecated
	public void initialize(String inputFilePath, boolean delete, String encoding, int separatedType)
		throws GReportException {
		initialize(GFileUtils.createURI(inputFilePath), delete, encoding, separatedType);
	}

	/**
	 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
	 * 
	 * @see ISeparatedFileList#initialize(URI, boolean, String, int)
	 *
	 * @param inputFile データソースとなるファイルのファイルパス
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param encoding インプットデータのエンコードタイプ
	 * @param separatedType セパレートタイプ
	 * @throws GReportException
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public void initialize(URI inputFile, boolean delete, String encoding, int separatedType) throws GReportException {
		checkNull(inputFile);

		_input_file_uri = inputFile;

		_is_delete = delete;
		_parser = new GSeparatedFileParser(separatedType);
		_separated_type = separatedType;
		_encoding = encoding;
		_is_include_header = true;
		_column_array = getColumnsFromHeaderLine();
	}

	/**
	 * インプットファイルのヘッダー項目からカラム情報を取得する。
	 *
	 * @throws GReportException 例外
	 * @return インプットファイルのヘッダー項目からカラム情報
	 * @create 2014/11/18
	 * @author tou
	 * @since 2.0.0
	 */
	private ISeparatedFileColumn[] getColumnsFromHeaderLine() throws GReportException {
		try {
			open(false);

			// ヘッダー情報の読み込み
			String[] headerColumns = _parser.parse(_file_reader.readLine());
			ISeparatedFileColumn[] columnArray = new ISeparatedFileColumn[headerColumns.length];
			for (int i = 0; i < headerColumns.length; i++) {
				ISeparatedFileColumn column = new GSeparatedFileColumn();
				column.initialize(this, headerColumns[i]);
				columnArray[i] = column;
			}

			log.info("Data source list is initialized. file=\"" + _input_file_uri.toString() + "\"");
			return columnArray;
		} catch (IOException e) {
			throw new GReportException(e);
		} finally {
			close(false);
		}
	}

	/**
	 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
	 * 
	 * @see ISeparatedFileList#initialize(String, String, boolean, int)
	 * 
	 * @param layoutFilePath レイアウト定義ファイルのファイルパス
	 * @param inputFilePath データソースとなるファイルのファイルパス
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param separatedType セパレートタイプ
	 * @throws GReportException
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	@Deprecated
	public void initialize(String layoutFilePath, String inputFilePath, boolean delete, int separatedType)
		throws GReportException {
		initialize(GFileUtils.createURI(layoutFilePath), GFileUtils.createURI(inputFilePath), delete, separatedType);
	}

	/**
	 * uriがnull、の場合、IllegalArgumentExceptionを発生させる.<br>
	 * 
	 * @param uri URIオブジェクト
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	private void checkNull(URI uri) {
		if (uri == null) {
			throw new IllegalArgumentException("The specified uri cannot be null.");
		}
	}

	/**
	 * インプットファイルのヘッダー項目を元にインスタンスを初期化します.<br>
	 * 
	 * @see ISeparatedFileList#initialize(URI, URI, boolean, int)
	 *
	 * @param layoutFile レイアウト定義ファイルのファイルパス
	 * @param inputFile データソースとなるファイルのファイルパス
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param separatedType セパレートタイプ
	 * @throws GReportException
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public void initialize(URI layoutFile, URI inputFile, boolean delete, int separatedType) throws GReportException {
		checkNull(layoutFile);
		checkNull(inputFile);

		try {
			_input_file_uri = inputFile;
			_is_delete = delete;
			_layout_file = layoutFile.toString();
			_parser = new GSeparatedFileParser(separatedType);
			_separated_type = separatedType;
			_is_include_header = false;

			// レイアウトファイルのrecordノードとcolumnノードからリスト情報とカラム情報をロードする
			// XMLの解析
			Document doc = parseXmlDocument(_layout_file);

			// ルート要素を取得
			Element docRootNode = doc.getDocumentElement();

			// recordノードの取得
			loadListElement(docRootNode);

			// columnノードの取得
			loadColumnElement(docRootNode);

			log.info("Data source list is initialized. file=\"" + _layout_file + "\"");
		} catch (ParserConfigurationException | SAXException | IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 項目情報が詰まれたXMLエレメントから、項目オブジェクトを生成します。
	 *
	 * @param doc_root_node XMLエレメント
	 * @create 2014/11/18
	 * @author tou
	 * @since 2.0.0
	 */
	protected void loadColumnElement(Element doc_root_node) {
		NodeList columnNodeList = doc_root_node.getElementsByTagName(GSeparatedFileList.TAG_NAME_COLUMN);
		if (columnNodeList != null && columnNodeList.getLength() > 0) {
			ISeparatedFileColumn[] columnArray = new ISeparatedFileColumn[columnNodeList.getLength()];
			for (int i = 0; i < columnNodeList.getLength(); i++) {
				Element columnNode = (Element) columnNodeList.item(i);
				ISeparatedFileColumn column = new GSeparatedFileColumn();
				column.initialize(this, columnNode);
				columnArray[i] = column;
			}
			_column_array = columnArray;
		} else {
			_column_array = new ISeparatedFileColumn[0];
		}
	}

	/**
	 * 指定されたXMLエレメントからリスト情報を抽出し展開します。
	 *
	 * @param doc_root_node XMLエレメント
	 * @create 2014/11/18
	 * @author tou
	 * @since 2.0.0
	 */
	protected void loadListElement(Element doc_root_node) {
		NodeList listNodeList = doc_root_node.getElementsByTagName(GSeparatedFileList.TAG_NAME_LIST);

		Element listNode = (Element) listNodeList.item(0);
		if (listNode != null) {
			// v1.6.0
			// skipbytes
			Attr skipbytesAttr = listNode.getAttributeNode(GSeparatedFileList.TAG_NAME_SKIP_BYTES);
			if (skipbytesAttr != null) {
				int skipBytes = Integer.parseInt(skipbytesAttr.getValue());
				if (skipBytes <= 0) {
					throw new IllegalArgumentException("skip bytes should be larger than 0.");
				}
				_skip_bytes = skipBytes;
			}

			// encoding
			Attr encodingAttr = listNode.getAttributeNode(GSeparatedFileList.TAG_NAME_ENCODING);
			if (encodingAttr != null) {
				setEncoding(encodingAttr.getValue());
			}
		}
	}


	/**
	 * リストを閉じた後、インプットファイルを削除するかを表す値を取得します。
	 *
	 * @see ISeparatedFileList#isDelete()
	 * @return インプットファイルを削除する
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public boolean isDelete() {
		return _is_delete;
	}

	/**
	 * インプットファイルにヘッダー情報が含まれるかを表す値を取得します。
	 *
	 * @return インプットファイルにヘッダー情報が含まれるか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected boolean isIncludeHeader() {
		return _is_include_header;
	}

	/**
	 * リストが既に開かれているかを表す値を取得します。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#isOpen()
	 * @return リストが既に開かれているか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public boolean isOpen() {
		return _is_open;
	}

	/**
	 * 作業対象行を次の行へ移動させます。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#next()
	 * @return 最後のであればfalse、その他はtrue
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public boolean next() throws GReportException {
		if (_file_reader == null) {
			return false;
		}
		try {
			// 改行あり
			String currentData = _file_reader.readLine();
			// データが無くなった場合
			if (currentData == null) {
				return false;
			}

			_current_record = createRecord(currentData);
		} catch (IOException e) {
			throw new GReportException(e);
		}

		return true;
	}

	/**
	 * リストを開きます。
	 *
	 * @see jp.co.kccs.greenearth.report.dao.IReportList#open()
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void open() throws GReportException {
		open(_is_include_header);
	}

	/**
	 * リストを開きます、指定によりヘッダーをスキップします。。
	 *
	 * @param isSkipHeaderLine true:ヘッダー行をスキップ、false:ヘッダー行をスキップしない
	 * @throws GReportException 例外
	 * @create 2014/11/18
	 * @author tou
	 * @since 2.0.0
	 */
	protected void open(boolean isSkipHeaderLine) throws GReportException {
		if (_input_file_uri == null) {
			return;
		}

		InputStream in = null;
		InputStreamReader isr = null;
		try {
			in = _input_file_uri.toURL().openStream();

			if (0 < _skip_bytes && _skip_bytes <= in.available()) {
				for (int i = 0; i < _skip_bytes; i++) {
					in.read();
				}
			}

			if (GStringUtils.isEmpty(getEncoding())) {
				isr = new InputStreamReader(in);
			} else {
				isr = new InputStreamReader(in, getEncoding());
			}

			_file_reader = new BufferedReader(isr);

			_is_open = true;
			log.info("Data source list is opened. file=\"" + _input_file_uri.toString() + "\"");

			// ヘッダー情報を含む場合は、一行(ヘッダー部を)読み飛ばす
			if (isSkipHeaderLine) {
				_file_reader.readLine();
			}
		} catch (IOException | RuntimeException e) {
			try {
				if (in != null) {
					in.close();
				}
				if (isr != null) {
					isr.close();
				}
				if (_file_reader != null) {
					_file_reader.close();
				}
			} catch (IOException ex) {
				log.error("file close error.", ex);
				throw new GReportException(ex);
			}

			throw new GReportException(e);
		}
	}

	/**
	 * 指定されたレイアウト定義ファイルを解析し、Documentオブジェクトを取得します。
	 *
	 * @param layout_file レイアウト定義ファイル
	 * @return Documentオブジェクト
	 * @throws ParserConfigurationException Parse例外
	 * @throws SAXException XML例外
	 * @throws IOException IO例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected Document parseXmlDocument(String layout_file)
		throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilder builder = GXmlParser.createDocumentBuilder(DTD_DATA_SOURCE_SEPARATED_FILE_EN,
			RESOURCE_KEY_SEPARATEDFILE_DATASOURCE_SF_DTD, URL_KEY_DATASOURCE_SF_DTD);
		// XMLの解析
		Document doc = builder.parse(layout_file);

		return doc;
	}

	/**
	 * 作業行をリセットします.<BR>
	 * 内部的にいったんファイルをクローズし、またオープンしています。
	 *
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void reset() throws GReportException {
		close(false);
		open();
	}

	/**
	 * 項目配列を設定します。
	 *
	 * @param array 項目配列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setColumnArray(ISeparatedFileColumn[] array) {
		_column_array = array;
	}

	/**
	 * 現在作業対象中のレコードを取得します。
	 *
	 * @param record 現在作業対象中のレコード
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setCurrentRecord(ISeparatedFileRecord record) {
		_current_record = record;
	}

	/**
	 * インプットデータのエンコードタイプを設定します。
	 *
	 * @param encoding インプットデータのエンコードタイプ
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setEncoding(String encoding) {
		_encoding = encoding;
	}

	/**
	 * ファイルパーサーを設定します。
	 *
	 * @param parser ファイルパーサー
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setFileParser(GSeparatedFileParser parser) {
		_parser = parser;
	}

	/**
	 * ファイルリーダーを設定します。
	 *
	 * @param reader ファイルリーダー
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setFileReader(BufferedReader reader) {
		_file_reader = reader;
	}

	/**
	 * クローズ時にインプットファイルを削除するかを表す値を設定します。
	 *
	 * @param is_delete クローズ時にインプットファイルを削除するか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsDelete(boolean is_delete) {
		_is_delete = is_delete;
	}

	/**
	 * インプットデータにヘッダーを含むかを表す値を設定します。
	 *
	 * @param is_include_header インプットデータにヘッダーを含むか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsIncludeHeader(boolean is_include_header) {
		_is_include_header = is_include_header;
	}

	/**
	 * ファイルが開いているかを表す値を設定します。
	 *
	 * @param is_open ファイルが開いているか
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setIsOpen(boolean is_open) {
		_is_open = is_open;
	}

	/**
	 * レイアウト定義ファイル名を設定します。
	 *
	 * @param fileName レイアウト定義ファイル名
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setLayoutFileName(String fileName) {
		_layout_file = fileName;
	}

	/**
	 * セパレートタイプを設定します。
	 *
	 * @param type セパレートタイプ
	 * @create 2006/02/15
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setSeparatedType(int type) {
		_separated_type = type;
	}

}
