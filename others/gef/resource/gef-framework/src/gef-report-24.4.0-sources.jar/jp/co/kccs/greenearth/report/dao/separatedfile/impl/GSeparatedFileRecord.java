/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.separatedfile.impl;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.report.dao.IReportColumn;
import jp.co.kccs.greenearth.report.dao.IReportList;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileColumn;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileList;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileRecord;

/**
 * セパレートファイルデータリストの行のデフォルト実装クラスです。
 * 
 * @create 2006/02/07
 * @author kitamura
 * @since 1.1.0
 */
public class GSeparatedFileRecord implements ISeparatedFileRecord {

	/** オーナーリスト */
	private ISeparatedFileList _list = null;
	/** 項目値マップ */
	private Map<String, GSeparatedFileVariant> _variant_map = null;

	/**
	 * この項目が関連づくListオブジェクトを取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#getList()
	 * @return Listオブジェクト
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public IReportList getList() {
		return _list;
	}

	/**
	 * 指定した項目の値を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#getVariable(java.lang.String)
	 * @param column_name 項目名
	 * @return 項目の値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public Object getVariable(String column_name) {
		if (column_name == null) {
			return null;
		}
		GSeparatedFileVariant variant = getMap().get(column_name);
		if (variant == null) {
			return null;
		}
		return variant.getValue();
	}

	/**
	 * 指定した項目の値を文字列表現で取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#getVariableString(java.lang.String)
	 * @param column_name 項目名
	 * @return 項目の値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String getVariableString(String column_name) {
		if (column_name == null) {
			return null;
		}
		GSeparatedFileVariant variant = getMap().get(column_name);
		if (variant == null) {
			return null;
		}
		return variant.getString();
	}

	/**
	 * 行の項目値を指定して、インスタンスを初期化します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileRecord#initialize(jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileList, java.lang.String[])
	 * @param list リスト
	 * @param values 項目値の配列
	 * @create 2006/02/09
	 * @author kitamura
	 * @since 1.1.
	 */
	@Override
	public void initialize(ISeparatedFileList list, String[] values) {
		_list = list;
		ISeparatedFileColumn[] columns = (ISeparatedFileColumn[]) list.getColumnArray();
		for (int i = 0; i < columns.length; i++) {
			GSeparatedFileVariant variant = new GSeparatedFileVariant(columns[i], values[i]);
			getMap().put(columns[i].getName(), variant);
		}
	}

	/**
	 * オーナーリストを設定します。
	 * 
	 * @param list オーナーリスト
	 * @create 2006/02/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setList(ISeparatedFileList list) {
		_list = list;
	}

	/**
	 * 指定された項目に、指定された値を設定します。
	 * 
	 * @see jp.co.kccs.greenearth.report.dao.IReportRecord#setVariable(java.lang.String, java.lang.Object)
	 * @param name 項目名
	 * @param value 項目の値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void setVariable(String name, Object value) {
		if (name == null) {
			return;
		}
		GSeparatedFileVariant variant = getMap().get(name);
		if (variant == null) {
			return;
		}
		variant.setValue(value);
	}

	/**
	 * レコードの各項目値を文字列として取得します.<BR>
	 * フォーマット 項目値|項目値|項目値...<BR>
	 * 各項目値は内部的にgetVariableString(String)メソッドを用いて取得しています。
	 * 
	 * @see java.lang.Object#toString()
	 * @return レコードの各項目値を文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public String toString() {
		if (_list != null) {
			StringBuilder buf = new StringBuilder();
			IReportColumn[] colArray = (IReportColumn[]) _list.getColumnArray();
			for (int i = 0; i < colArray.length; i++) {
				buf.append(getVariableString(colArray[i].getName()) + "|");
			}
			String s = buf.toString();
			if (s.length() > 0) {
				s = s.substring(0, s.length() - 1);
			}
			return s;
		} else {
			return "list is null.";
		}
	}
	
	/**
	 * 【機能】Mapを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return マップオブジェクト
	 * @since 1.0.0
	 */
	Map<String, GSeparatedFileVariant> getMap() {
		if (_variant_map == null) {
			_variant_map = new HashMap<String, GSeparatedFileVariant>();
		}
		return _variant_map;
	}
}
