/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.dao.separatedfile.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileColumn;

/**
 * セパレートファイルデータの項目値を表すクラスです。
 * 
 * @create 2006/02/08
 * @author kitamura
 * @since 1.1.0
 */
public class GSeparatedFileVariant {

	/** 項目情報 */
	private ISeparatedFileColumn _column = null;
	/** 値 */
	private Object _value = null;

	/**
	 * 項目情報と値を指定して、GSeparatedFileVariantインスタンスを初期化します。
	 * 
	 * @param column 項目情報
	 * @param value 値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	GSeparatedFileVariant(ISeparatedFileColumn column, String value) {
		_column = column;
		setString(value);
	}

	/**
	 * 項目情報を取得します。
	 * 
	 * @return 項目情報
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public ISeparatedFileColumn getColumn() {
		if (_column == null) {
			throw new GReportRuntimeException("column is not set.");
		}
		return _column;
	}

	/**
	 * 項目値を文字列として取得します.<BR>
	 * 基本的にはtoString()した値ですが、日付型に関しては指定されたフォーマットで整形した値を取得します。
	 * 
	 * @return 文字列化項目値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getString() {
		if (_value == null) {
			return null;
		} else if (ISeparatedFileColumn.TYPE_DATETIME == getColumn().getType()) {
			SimpleDateFormat format = new SimpleDateFormat(getColumn().getFormat());
			return format.format((Date) _value);
		} else {
			return _value.toString();
		}
	}

	/**
	 * 項目値を取得します。
	 * 
	 * @return 項目値
	 * @create 2006/02/08
	 * @author kitamura
	 * @since 1.1.0
	 */
	public Object getValue() {
		return _value;
	}

	/**
	 * 項目情報を設定します。
	 * 
	 * @param column 項目情報
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setColumn(ISeparatedFileColumn column) {
		_column = column;
	}

	/**
	 * 文字列で項目値を設定します.<BR>
	 * 各型に応じて値が整形されセットされます。
	 * 
	 * @param value 文字列形式項目値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setString(String value) {
		if (value == null) {
			_value = null;
		} else if (ISeparatedFileColumn.TYPE_INTEGER == getColumn().getType()) {
			setString4Integer(value);
		} else if (ISeparatedFileColumn.TYPE_STRING == getColumn().getType()) {
			setString4String(value);
		} else if (ISeparatedFileColumn.TYPE_NSTRING == getColumn().getType()) {
			setString4String(value);
		} else if (ISeparatedFileColumn.TYPE_DATETIME == getColumn().getType()) {
			setString4DateTime(value);
		} else if (ISeparatedFileColumn.TYPE_YM == getColumn().getType()) {
			setString4String(value);
		} else if (ISeparatedFileColumn.TYPE_DECIMAL == getColumn().getType()) {
			setString4Decimal(value);
		} else if (ISeparatedFileColumn.TYPE_LONG == getColumn().getType()) {
			setString4Long(value);
		} else {
			throw new IllegalArgumentException("Illegal type. : " + getColumn().getType());
		}
	}

	/**
	 * 日付型の項目に文字列で値を設定します。<BR>
	 * 日付として認識できない場合は例外を発生します。
	 * 
	 * @param value 日付型文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4DateTime(String value) {
		if (GStringUtils.isEmpty(value)) {
			_value = null;
		} else {
			String formatString = "";
			if (_column != null && getColumn().getFormat() != null) {
				formatString =  getColumn().getFormat();
			}
			SimpleDateFormat format = new SimpleDateFormat(formatString);
			try {
				_value = format.parse(value);
			} catch (ParseException e) {
				throw new IllegalArgumentException(e.getMessage());
			}
		}
	}

	/**
	 * 実数型の項目に文字列で値を設定します。<BR>
	 * 実数として認識できない場合は例外を発生します。
	 * 
	 * @param value 実数型文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4Decimal(String value) {
		if (GStringUtils.isEmpty(value)) {
			_value = null;
		} else {
			_value = new BigDecimal(value);
		}
	}

	/**
	 * Integer型の項目に文字列で値を設定します。<BR>
	 * Integer値として認識できない場合は例外を発生します。
	 * 
	 * @param value Integer型文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4Integer(String value) {
		if (GStringUtils.isEmpty(value)) {
			_value = null;
		} else {
			_value = new Integer(value);
		}
	}

	/**
	 * Long型の項目に文字列で値を設定します。<BR>
	 * Long値として認識できない場合は例外を発生します。
	 * 
	 * @param value Long型文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4Long(String value) {
		if (GStringUtils.isEmpty(value)) {
			_value = null;
		} else {
			_value = new Long(value);
		}
	}

	/**
	 * 文字列型の項目に文字列で値を設定します。
	 * 
	 * @param value 文字列
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void setString4String(String value) {
		_value = value;
	}

	/**
	 * 項目値を設定します。<BR>
	 * データタイプにマッチする形式の値でない場合は例外が発生します。
	 * 
	 * @param value 項目値
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setValue(Object value) {
		if (value == null) {
			_value = null;
		} else if (ISeparatedFileColumn.TYPE_INTEGER == getColumn().getType()) {
			if (value instanceof Integer) {
				_value = value;
			} else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (ISeparatedFileColumn.TYPE_STRING == getColumn().getType()) {
			if (value instanceof String) {
				_value = value;
			} else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (ISeparatedFileColumn.TYPE_NSTRING == getColumn().getType()) {
			if (value instanceof String) {
				_value = value;
			} else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (ISeparatedFileColumn.TYPE_DATETIME == getColumn().getType()) {
			if (value instanceof Date) {
				_value = value;
			} else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (ISeparatedFileColumn.TYPE_YM == getColumn().getType()) {
			if (value instanceof String) {
				_value = value;
			} else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (ISeparatedFileColumn.TYPE_DECIMAL == getColumn().getType()) {
			if (value instanceof BigDecimal) {
				_value = value;
			} else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else if (ISeparatedFileColumn.TYPE_LONG == getColumn().getType()) {
			if (value instanceof Long) {
				_value = value;
			} else {
				throw new IllegalArgumentException("指定された値はVariantの型にマッチしません : " + value.toString());
			}
		} else {
			throw new IllegalArgumentException("Illegal type. : " + getColumn().getType());
		}
	}
}
