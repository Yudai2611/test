/*
 * Copyright 2006-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.driver;

import static jp.co.kccs.greenearth.commons.utils.GStringUtils.isEmpty;
import static jp.co.kccs.greenearth.commons.utils.GStringUtils.isSurrogatePairChar;

/**
 * Utilityクラスです。
 * @author KCCS
 * 
 */
class GDriverUtils {

	/**
	 * 文字列に含まれる文字数を半角文字換算でカウントします。<BR>
	 * ASCIIコード準拠文字と、半角カタカナを半角、それ以外を全角とみなすようにしています。<BR>
	 * 現状は日本語にしか対応していません。 半角文字の範囲を指定するのではなく、全角文字の範囲を判定するようにするべきかもしれません。
	 * また、TAB、BEL、DELなどは半角としてみなされてしまいます。
	 * 
	 * @param str 対象文字列
	 * @return 文字数
	 * @create 2006/04/09
	 * @author takaishi
	 * @since 0.3.0
	 */
	static int getCharCountByHalfWidth(String str) {
		if (isEmpty(str)) {
			return 0;
		}
		
		int size = 0;

		char tempChar;
		for (int i = 0; i < str.length(); i++) {
			tempChar = str.charAt(i);

			// 7Bit ASCII + \ + ~
			if (tempChar < 0x80 || tempChar == 0x00A5 || tempChar == 0x203E) {
				size += 1;
			} else if (tempChar >= 0xff61 && tempChar <= 0xff9f) {
				size += 1;
			} else {
				size += 2;

				if (isSurrogatePairChar(tempChar)) {
					if (i + 1 < str.length()) {
						if (isSurrogatePairChar(str.charAt(i + 1))) {
							i++;
						}
					}
				}
			}
		}

		return size;
	}
}
