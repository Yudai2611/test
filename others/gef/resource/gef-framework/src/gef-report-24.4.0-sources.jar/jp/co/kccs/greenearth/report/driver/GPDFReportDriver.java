/*
 * Copyright 2014-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.driver;

import static jp.co.kccs.greenearth.commons.utils.GStringUtils.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.Barcode128;
import com.itextpdf.text.pdf.Barcode39;
import com.itextpdf.text.pdf.BarcodeCodabar;
import com.itextpdf.text.pdf.BarcodeEAN;
import com.itextpdf.text.pdf.BarcodeEANSUPP;
import com.itextpdf.text.pdf.BarcodeInter25;
import com.itextpdf.text.pdf.BarcodePDF417;
import com.itextpdf.text.pdf.BarcodePostnet;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfDestination;
import com.itextpdf.text.pdf.PdfEncryptor;
import com.itextpdf.text.pdf.PdfOutline;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReportLine;
import jp.co.kccs.greenearth.report.IReportWriter;
import jp.co.kccs.greenearth.report.repository.IBarcodeInfo;
import jp.co.kccs.greenearth.report.repository.ICircleInfo;
import jp.co.kccs.greenearth.report.repository.IFieldInfo;
import jp.co.kccs.greenearth.report.repository.ILineDashInfo;
import jp.co.kccs.greenearth.report.repository.ILineInfo;
import jp.co.kccs.greenearth.report.repository.IMaxPageInfo;
import jp.co.kccs.greenearth.report.repository.IRectangleInfo;
import jp.co.kccs.greenearth.report.utility.GColor;
import jp.co.kccs.greenearth.report.utility.GReportFileUtility;

/**
 * 【役割】PDFドライバを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 *
 * @create 2003/12/01
 * @author kubo
 * @since 1.0.0
 */
public class GPDFReportDriver implements IReportWriter {

	/** スタートページ */
	private static final int PDF_START_PAGE = 1;
	/** フォント名のデフォルト値 */
	private static final String DEFAURT_FONT_NAME = "HeiseiKakuGo-W5";
	/** フォントエンコーディングのデフォルト値 */
	private static final String DEFAURT_FONT_ENCODING = "UniJIS-UTF16-H";
	/** フォントファイルのパスのプロパティキー */
	private static final String FONT_DIRECTORY = "geframe.report.FontDirectory";
	/** デフォルトフォントサイズ */
	private static final float DEFAURT_FONT_SIZE = 8;
	/** 認証一時ファイル名サフィックス*/
	static final String CERTIFICATION_TEMP_SUFFIX = "_auth";

	/** ファイルパス */
	private String _file_name = "C:\\Temp\\Sample.pdf";
	/** 用紙サイズ */
	private String _paper_size = "a4";
	/** PDFドキュメント */
	private Document _doc_pdf;
	/** PDFライター */
	private PdfWriter _pdf_writer;
	/** 標準フォント */
	private BaseFont _base_font;
	/** ボールドフォント */
	private BaseFont _base_font_b;
	/** イタリックフォント */
	private BaseFont _base_font_i;
	/** 用紙縦横指定 */
	private int _orientation = ORIENTATION_HORIZONTAL;
	/** 縦方向行数 */
	private int _row_count = 0;
	/** 横方向行数 */
	private int _col_count = 0;
	/** グリッドの幅 */
	private float _col_pitch = 6.0f;
	/** グリッドの高さ */
	private float _row_pitch = DEFAURT_FONT_SIZE;
	/** 上マージン */
	private float _top_margin = 32;
	/** 下マージン */
	private float _bottom_margin = 32;
	/** 左マージン */
	private float _left_margin = 12;
	/** 右マージン */
	private float _right_margin = 12;
	/** フォントサイズ */
	private float _font_size = DEFAURT_FONT_SIZE;
	/** フォント名 */
	private String _font_name = null;
	/** フォント名(Bold) */
	private String _font_name_bold = null;
	/** フォント名(Italic) */
	private String _font_name_italic = null;

	/** 外部ファイル指定 */
	private String _use_font_file = "false";

	/** フォントエンコーディング */
	private String _font_encoding = null;
	/** PDFに文字列表示する際の文字表示が低すぎるのを調整します */
	private static final float BUFFER = 1.0f;
	/** バックスラッシュのバイトコード */
	public static final char BACK_SLASH = '\u005c\u005c';
	/** 円マークのバイトコード */
	public static final char EN_MARK = '\u00a5';

	/** テンプレートマップ */
	private Map<String, PdfTemplate> _template_map = new Hashtable<String, PdfTemplate>();
	/** PDFテンプレート */
	private PdfTemplate _maxpage_template = null;
	/** PDFテンプレートを生成するか判定 */
	private boolean _is_create_maxpage_template = true;
	/** アウトラインの表示設定 */
	private boolean _show_outline = false;
	/** グローバルページ数 */
	private int _grobal_page_count = 0;
	/** グリッドラインの表示設定 */
	private boolean _print_ruled_line = false;
	/** PDF印刷時に印刷画面を表示する判定 */
	private boolean _on_load_print = false;
	/** デバッグフラグ */
	private static boolean isDebug = false;
	/** 最大ページ設定情報 */
	private IMaxPageInfo _maxpage_info = null;
	/** パスワード */
	private String _passwd = null;
	/** MaxPage印字位置用フラグ */
	private static boolean maxpageFlag = false;

	/** デフォルト拡張子 */
	private String extension = ".pdf";

	static {
		try {
			maxpageFlag = Boolean.valueOf((GFrameworkUtils.getProperty("ADJUST_MAXPAGE_POS"))).booleanValue();
		} catch (MissingResourceException mre) {
			maxpageFlag = false;
		}
	}

	/** 文字列を一旦溜め込む */
	private List<WriteStringInfo> _strbuff = new ArrayList<WriteStringInfo>();

	/** フィールドのフォント情報を保持するクラス */
	private FieldFonts fieldFonts = null;


	/**
	 * 【機能】デバッグモードか判断します。<BR>
	 * 【戻値】デバッグフラグ<BR>
	 * 【備考】<BR>
	 *
	 * @return デバッグモード
	 */
	private boolean isDebug() {
		return isDebug;
	}

	/**
	 * 【機能】ドキュメントをオープンします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】ドキュメントの初期化も行います。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#open(java.lang.String)
	 * @param path ファイルのパス
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void open(String path) throws GReportException {
		_file_name = path;
		initializeForOpen();
	}

	/**
	 * 【機能】最大ページ数をテンプレートに印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeMaxPage()
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeTemplateMaxPage() throws GReportException {

		if (_maxpage_template == null) {
			return;
		}

		IMaxPageInfo maxPageInfo = getMaxPageInfo();

		if (isOutOfRangeVertical(maxPageInfo.getTop())) {
			return;
		}

		if (maxPageInfo.getFontSize() == -1) {
			writeMaxPageCount();
		} else {
			writeMaxPageCountNonGrid();
		}
	}

	/**
	 * 【機能】最大ページ数を書き込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @since 1.0.2
	 */
	private void writeMaxPageCount() {

		IMaxPageInfo maxPageInfo = getMaxPageInfo();
		String pageCount = null;

		if (maxPageInfo.getFormat() != null) {
			DecimalFormat decimal = new DecimalFormat(maxPageInfo.getFormat());
			String beforeFormat = String.valueOf(_doc_pdf.getPageNumber());
			pageCount = decimal.format(Integer.parseInt(beforeFormat));
		} else {
			pageCount = String.valueOf(_doc_pdf.getPageNumber());
		}

		IMaxPageInfo maxpageInfo = getMaxPageInfo();
		float fontZoom = maxpageInfo.getFontZoom();
		float zoomedFontSize = _font_size * (float) fontZoom;
		float zoomedColPitch = _col_pitch * (float) fontZoom;
		float buffer = getBuffer(fontZoom);

		BaseFont baseFont = getBaseFont((int) maxpageInfo.getFontFace());
		_maxpage_template.setFontAndSize(baseFont, zoomedFontSize);
		_maxpage_template.setColorFill(BaseColor.BLACK);

		float colIndex = 0;

		int valueBytes = GDriverUtils.getCharCountByHalfWidth(pageCount);
		if (isRightAlignment(maxpageInfo.getAlignment())) {
			float endCol = colIndex + maxpageInfo.getWidth();
			colIndex = endCol - valueBytes * maxpageInfo.getFontZoom();
		}

		if (isCenterAlignment(maxpageInfo.getAlignment())) {
			float rest = maxpageInfo.getWidth() - valueBytes * maxpageInfo.getFontZoom();
			if (rest > 1) {
				colIndex = colIndex + (int) (rest / 2);
			}
		}

		_maxpage_template.beginText();
		for (int i = 0; i < pageCount.length(); i++) {
			String text = pageCount.substring(i, i + 1);

			if (isOutOfRangeHorizontal(colIndex)) {
				break;
			}

			if (GDriverUtils.getCharCountByHalfWidth(text) > 1) {
				_maxpage_template.showTextAligned(PdfContentByte.ALIGN_CENTER, text, colIndex * _col_pitch + zoomedColPitch, buffer, 0.0f);
				colIndex = colIndex + (2 * maxpageInfo.getFontZoom());
			} else {
				_maxpage_template.showTextAligned(PdfContentByte.ALIGN_CENTER, text, colIndex * _col_pitch + zoomedColPitch / 2.0f, buffer, 0);
				colIndex = colIndex + (1 * maxpageInfo.getFontZoom());
			}
		}
		_maxpage_template.endText();

		_is_create_maxpage_template = true;
		_maxpage_template = null;
	}

	/**
	 * グリッドに則らずに最大ページ数を書き込みます。
	 *
	 * @create
	 * @author
	 * @since
	 */
	private void writeMaxPageCountNonGrid() {
		IMaxPageInfo maxpageInfo = getMaxPageInfo();
		String pageCount = null;

		if (maxpageInfo.getFormat() != null) {
			DecimalFormat decimal = new DecimalFormat(maxpageInfo.getFormat());
			String beforeFormat = String.valueOf(_doc_pdf.getPageNumber());
			pageCount = decimal.format(Integer.parseInt(beforeFormat));
		} else {
			pageCount = String.valueOf(_doc_pdf.getPageNumber());
		}

		float fontSize = maxpageInfo.getFontSize();
		float rowPitch = 0.0f;

		if (maxpageFlag) {
			rowPitch = _row_pitch;
		} else {
			rowPitch = _row_pitch * maxpageInfo.getFontZoom();
		}

		// ここではgetBuf()の値は考慮しません。
		int buffer = 0 - maxpageInfo.getFontHeight() + (int) fontSize / (int) DEFAURT_FONT_SIZE;

		BaseFont baseFont = getBaseFont(maxpageInfo.getFontFace());
		_maxpage_template.setFontAndSize(baseFont, fontSize);
		_maxpage_template.setColorFill(BaseColor.BLACK);

		float startPoint = 0;
		int valueLength = pageCount.length();
		float valueSize = 0;

		// とりあえず int でキャストします。直すときはデザイナと同時に。
		for (int i = 0; i < valueLength; i++) {
			if (i < valueLength - 1) {
				valueSize += (int) (baseFont.getWidthPoint(pageCount.substring(i, i + 1), fontSize) + maxpageInfo.getFontInterval());
			} else {
				valueSize += (int) (baseFont.getWidthPoint(pageCount.substring(i, i + 1), fontSize));
			}
		}

		if (isCenterAlignment(maxpageInfo.getAlignment())) {
			float rest = maxpageInfo.getWidth() * _col_pitch - valueSize;
			if (rest > 1) {
				startPoint = startPoint + (float) Math.round(rest / 2);
			}
		}

		if (isRightAlignment(maxpageInfo.getAlignment())) {
			float endPoint = startPoint + maxpageInfo.getWidth() * _col_pitch;
			startPoint = endPoint - valueSize;
		}

		float endColumnPoint = _col_count * _col_pitch;

		_maxpage_template.beginText();
		for (int i = 0; i < valueLength; i++) {

			String text = pageCount.substring(i, i + 1);

			// ページの範囲を超えるものは出力しない
			if (startPoint < 0 || startPoint >= endColumnPoint) {
				break;
			}

			float startX = startPoint;
			float startY = 0;

			if (maxpageFlag) {
				startY = rowPitch * maxpageInfo.getHeight() - fontSize + buffer;
			} else {
				startY = rowPitch - fontSize + buffer;
			}

			_maxpage_template.showTextAligned(PdfContentByte.ALIGN_LEFT, text, startX, startY, 0);

			// 次回開始位置
			// とりあえずデザイナに合わせます
			// 次期リリースで修正
			// デザイナでは fontSize/2 で小数点以下が落ちています
			startPoint += (int) baseFont.getWidthPoint(text, fontSize) + maxpageInfo.getFontInterval();
		}
		_maxpage_template.endText();

		_maxpage_template = null;
		_is_create_maxpage_template = true;
	}

	/**
	 * 【機能】ピッチを無視して文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param templateName テンプレート名
	 * @param left 左
	 * @param top 上
	 * @param value データ
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param fontFace フォントフェイス
	 * @param fontSize フォントサイズ
	 * @param interval 文字間隔
	 * @param fontHeight フォント高さ
	 * @param height 高さ
	 * @param backColor 背景色
	 * @param positionAdjustmentX 縦位置微調整
	 * @param positionAdjustmentY 横位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramewrk例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public void writeTemplateNonGrid(String templateName, float left, float top, String value, int zoom, String align, float width, int fontFace, int fontSize, int interval, int fontHeight, float height, Color backColor, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException {

		if (discontinueToWriteTemplate(templateName, value)) {
			return;
		}

		if (isOutOfRangeVertical(top)) {
			return;
		}

		fieldFonts = new FieldFonts(fontEncoding, fontName, fontNameBold, fontNameItalic, useFontFile);

		BaseFont font = getFontForField(fontFace);

		PdfTemplate template = _template_map.get(templateName);
		template.setFontAndSize(font, fontSize);
		template.setColorFill(BaseColor.BLACK);

		// ここではgetBuf()の値は考慮しません。
		int buf = 0 - fontHeight + (int) fontSize / (int) DEFAURT_FONT_SIZE;

		float startPoint = 0;
		float valueSize = 0;
		int valueLength = value.length();

		// とりあえず int でキャストします。直すときはデザイナと同時に。
		for (int i = 0; i < valueLength; i++) {
			if (i < valueLength - 1) {
				valueSize += (int) (font.getWidthPoint(value.substring(i, i + 1), fontSize) + interval);
			} else {
				valueSize += (int) (font.getWidthPoint(value.substring(i, i + 1), fontSize));
			}
		}

		if (isCenterAlignment(align)) {
			float rest = width * _col_pitch - valueSize;
			if (rest > 1) {
				startPoint = (float) Math.round(rest / 2);
			}
		}

		if (isRightAlignment(align)) {
			startPoint = (width * _col_pitch) - valueSize;
		}

		template.beginText();
		for (int i = 0; i < valueLength; i++) {
			String text = value.substring(i, i + 1);

			if (startPoint < 0 || startPoint >= (_col_count * _col_pitch)) {
				break;
			}

			text = convertToYENMark(text, useFontFile);

			if (isSurrogatePairChar(text.charAt(0))) {
				if (i + 1 < value.length()) {
					if (isSurrogatePairChar(value.charAt(i + 1))) {
						text = value.substring(i, i + 2);
						i++;
					}
				}
			}

			float startX = startPoint + left * _col_pitch + positionAdjustmentX;
			float startY = template.getHeight() - top * _row_pitch - fontSize + buf + positionAdjustmentY;
			template.showTextAligned(PdfContentByte.ALIGN_LEFT, text, startX, startY, 0);

			// 次回開始位置
			// とりあえずデザイナに合わせます
			// 次期リリースで修正
			// デザイナでは fontSize/2 で小数点以下が落ちています
			startPoint += (int) font.getWidthPoint(text, fontSize) + interval;
		}

		template.endText();
	}

	/**
	 * 【機能】テンプレートに文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeTemplateString(java.lang.String, float, float, java.lang.String, int, java.lang.String, float, int, int, int, int)
	 * @param template_name テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param value 値
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param font_face フォントフェイス
	 * @param font_height フォント高さ
	 * @param positionAdjustmentX 縦位置微調整
	 * @param positionAdjustmentY 横位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeTemplate(String template_name, float left, float top, String value, int zoom, String align, float width, int font_face, int font_height, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException {

		if (discontinueToWriteTemplate(template_name, value)) {
			return;
		}

		if (isOutOfRangeVertical(top)) {
			return;
		}

		float zoomedFontSize = _font_size * (float) zoom;
		float zoomedColPitch = _col_pitch * (float) zoom;
		float zoomedRowPitch = _row_pitch * (float) zoom;

		fieldFonts = new FieldFonts(fontEncoding, fontName, fontNameBold, fontNameItalic, useFontFile);

		PdfTemplate template = _template_map.get(template_name);
		template.setFontAndSize(getFontForField(font_face), zoomedFontSize);
		template.setColorFill(BaseColor.BLACK);

		float colIndex = left;

		int valueBytes = GDriverUtils.getCharCountByHalfWidth(value);
		if (isRightAlignment(align)) {
			float endCol = colIndex + width;
			colIndex = endCol - valueBytes * zoom;
		}

		if (isCenterAlignment(align)) {
			float rest = width - valueBytes * zoom;
			if (rest > 1) {
				colIndex = colIndex + (int) (rest / 2);
			}
		}

		float buffer = getBuffer(zoom);
		float startY = template.getHeight() - (top * _row_pitch) - zoomedRowPitch + buffer + positionAdjustmentY;
		template.beginText();

		for (int i = 0; i < value.length(); i++) {
			String text = value.substring(i, i + 1);

			if (isOutOfRangeHorizontal(colIndex)) {
				break;
			}

			text = convertToYENMark(text, useFontFile);

			// 書き込み時に_bufを引いているのはテンプレートを_buf分大きく確保しているため
			if (GDriverUtils.getCharCountByHalfWidth(text) > 1) {
				if (isSurrogatePairChar(text.charAt(0))) {
					if (i + 1 < value.length()) {
						if (isSurrogatePairChar(value.charAt(i + 1))) {
							text = value.substring(i, i + 2);
							i++;
						}
					}
				}

				template.showTextAligned(PdfContentByte.ALIGN_CENTER, text, colIndex * _col_pitch + zoomedColPitch + positionAdjustmentX, startY, 0);
				colIndex = colIndex + (2 * zoom);
			} else {
				template.showTextAligned(PdfContentByte.ALIGN_CENTER, text, colIndex * _col_pitch + zoomedColPitch / 2 + positionAdjustmentX, startY, 0);

				colIndex = colIndex + (1 * zoom);
			}
		}
		template.endText();
	}

	/**
	 * 【機能】テンプレートにイメージを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeTemplateImage(java.lang.String, float, float, float, float, java.lang.String)
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param source ソース
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeTemplateImage(String templateName, float left, float top, float width, float height, String source) throws GReportException {

		if (discontinueToWriteTemplate(templateName, source)) {
			return;
		}

		PdfTemplate template = _template_map.get(templateName);
		Image img = getImageInstance(source);
		addImageTemplate(template, img, left, top, width, height);
	}

	/**
	 * 【機能】テンプレートにバーコードを印刷します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeTemplateBarcode(java.lang.String, int, float, float, float, float, java.lang.String)
	 * @param templateName テンプレート名称
	 * @param type タイプ
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param value 値
	 * @param info バーコード情報
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeTemplateBarcode(String templateName, int type, float left, float top, float width, float height, String value, IBarcodeInfo info) throws GReportException {

		if (discontinueToWriteTemplate(templateName, value)) {
			return;
		}

		PdfTemplate template = _template_map.get(templateName);

		Image img = createImageWithBarcode(template, type, left, top, width, height, value, info);
		if (img == null) {
			return;
		}

		addImageTemplate(template, img, left, top, width, height);
	}

	/**
	 * テンプレートにイメージを書き出します.
	 *
	 * @param template テンプレート
	 * @param image イメージ
	 * @param left 左
	 * @param top 上
	 * @param rowCountOfWidth 幅
	 * @param rowCountOfHeight 高さ
	 * @throws GReportException 帳票フレームワーク例外
	 * @create 2015/03/13
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void addImageTemplate(PdfTemplate template, Image image, float left, float top, float rowCountOfWidth, float rowCountOfHeight) throws GReportException {

		float startX = left * _col_pitch;
		float fixedTop = top * _row_pitch;
		float widthOfImage = rowCountOfWidth * _col_pitch;
		float heightOfImage = rowCountOfHeight * _row_pitch;
		float startY = template.getHeight() - fixedTop - heightOfImage;

		try {
			template.addImage(image, widthOfImage, 0, 0, heightOfImage, startX, startY);
		} catch (DocumentException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】用紙の縦横を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setOrientation(int)
	 * @param orientation 用紙の縦横
	 */
	@Override
	public void setOrientation(int orientation) {
		_orientation = orientation;
	}

	/**
	 * 【機能】パスワードを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setPassword(java.lang.String)
	 * @param password パスワード文字列
	 * @create 2004/04/03
	 * @since 1.0.0
	 */
	@Override
	public void setPassword(String password) {
		_passwd = password;
	}

	/**
	 * 【機能】PDFオープン時に印刷画面を自動的に起動するよう設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】JavaScriptで実現しています。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setOnLoadPrint()
	 */
	@Override
	public void setOnLoadPrint() {
		_on_load_print = true;
	}

	/**
	 * 【機能】暗号化されたPDFファイルを生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @throws DocumentException ファイル操作例外
	 * @throws IOException ファイル操作例外
	 * @create 2004/07/29
	 * @since 1.0.3
	 */
	private void createAuthFile() throws DocumentException, IOException {
		int permissions = 10;
		String authFileName = getAuthFileName();
		PdfReader reader = null;
		try (FileInputStream inputStream = new FileInputStream(authFileName); OutputStream stream = new FileOutputStream(_file_name)) {
			reader = new PdfReader(inputStream);
			PdfEncryptor.encrypt(reader, stream, _passwd.getBytes(), _passwd.getBytes(), permissions, true);
			File file = new File(authFileName);
			if (file.exists()) {
				file.delete();
			}
		} finally {
			if (reader != null) {
				reader.close();
			}
			_passwd = null;
		}
	}

	/**
	 * 【機能】認証付PDFの“仮”ファイル名を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>認証付PDFの場合、仮ファイル名で通常のPDFファイルが生成され、そのPDFファイルを元に認証付PDFを生成します。</B><BR>
	 *
	 * @return ファイル名
	 * @create 2004/07/29
	 * @since 1.0.3
	 */
	private String getAuthFileName() {

		String dirPath = GReportFileUtility.getDirPath(_file_name);
		String fileName = GReportFileUtility.getFileNameWithoutExtension(_file_name);
		String ext = GReportFileUtility.getExtension(_file_name);

		return dirPath + fileName + "_auth" + ext;
	}

	/**
	 * 【機能】マージンを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setMargins(float, float, float, float)
	 * @param leftMargin 左マージン
	 * @param rightMargin 右マージン
	 * @param topMargin 上マージン
	 * @param bottomMargin 下マージン
	 */
	@Override
	public void setMargins(float leftMargin, float rightMargin, float topMargin, float bottomMargin) {
		_left_margin = leftMargin;
		_right_margin = rightMargin;
		_top_margin = topMargin;
		_bottom_margin = bottomMargin;
	}

	/**
	 * 【機能】最大ページ数表示用のテンプレートを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】この時点では最大ページ数は印刷されません。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeMaxPageTemplate(float, float, int, java.lang.String, float, float, int, java.lang.String, int, int, int)
	 * @param left 左
	 * @param top 上
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param height 高さ
	 * @param font_face フォントフェイス
	 * @param format フォーマット
	 * @param font_size フォントサイズ
	 * @param font_interval フォント横間隔
	 * @param font_height フォント縦間隔
	 */
	@Override
	public void setTemplateMaxPage(float left, float top, int zoom, String align, float width, float height, int font_face, String format, int font_size, int font_interval, int font_height) {

		PdfContentByte cb = _pdf_writer.getDirectContent();

		float zoomedFontSize = _font_size * (float) zoom;
		float zoomedColPitch = _col_pitch * (float) zoom;
		float zoomedRowPitch = _row_pitch * (float) zoom;
		cb.setFontAndSize(_base_font, zoomedFontSize);

		cb.setColorFill(BaseColor.BLACK);

		IMaxPageInfo maxpageInfo = getMaxPageInfo();

		maxpageInfo.setTop((int) top);
		maxpageInfo.setFontZoom(zoom);
		maxpageInfo.setAlignment(align);
		maxpageInfo.setWidth(width);
		maxpageInfo.setHeight(height);
		maxpageInfo.setFontFace(font_face);
		maxpageInfo.setFormat(format);
		maxpageInfo.setFontHeight(font_height);
		maxpageInfo.setFontInterval(font_interval);
		maxpageInfo.setFontSize(font_size);

		if (_is_create_maxpage_template) {

			float templateWith = width * zoomedColPitch;
			float templateHeight = height * zoomedRowPitch;

			_maxpage_template = cb.createTemplate(templateWith, templateHeight);

			_is_create_maxpage_template = false;
		}

		if (maxpageFlag) {
			cb.addTemplate(_maxpage_template, _doc_pdf.left() + left * _col_pitch, _doc_pdf.top() - ((top + height) * _row_pitch));
		} else {
			cb.addTemplate(_maxpage_template, _doc_pdf.left() + left * _col_pitch, _doc_pdf.top() - ((top + BUFFER) * _row_pitch));
		}
	}


	/**
	 * 【機能】テンプレートを設定します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setTemplate(java.lang.String, float, float, int, java.lang.String, float, float)
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param height 高さ
	 */
	@Override
	public void setTemplateField(String templateName, float left, float top, int zoom, String align, float width, float height) {

		if (templateName == null) {
			return;
		}

		PdfContentByte cb = _pdf_writer.getDirectContent();
		float zoomedRowPitch = _row_pitch * (float) zoom;

		if (!_template_map.containsKey(templateName)) {
			// テンプレートを作成する
			float templateWith = width * _col_pitch;
			float templateHeight = height * zoomedRowPitch;
			createTemplate(cb, templateName, templateWith, templateHeight);
		}

		PdfTemplate template = _template_map.get(templateName);

		// テンプレートをページに埋め込む（四角型テンプレートの左下角のXY座標位置を表す）
		float startXLocation = _doc_pdf.left() + (left * _col_pitch);
		float startYLocation = _doc_pdf.top() - (top * _row_pitch + height * zoomedRowPitch);

		cb.addTemplate(template, startXLocation, startYLocation);
	}

	/**
	 * 【機能】テンプレートを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】セクション用です。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setTemplate(java.lang.String, float, float, float, float)
	 * @param templateName テンプレート名称
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 */
	@Override
	public void setTemplateSection(String templateName, float left, float top, float width, float height) {

		if (templateName == null) {
			return;
		}

		PdfContentByte cb = _pdf_writer.getDirectContent();
		cb.setFontAndSize(_base_font, _font_size);

		cb.setColorFill(BaseColor.BLACK);

		if (!_template_map.containsKey(templateName)) {
			// テンプレートを作成する（大きめに作らなければ線が切れる）
			float templateWith = width * _col_pitch + BUFFER;
			float templateHeight = height * _row_pitch + BUFFER;
			createTemplate(cb, templateName, templateWith, templateHeight);
		}

		PdfTemplate template = _template_map.get(templateName);

		float startX = _doc_pdf.left() + left * _col_pitch;
		float startY = _doc_pdf.top() - (top * _row_pitch) - template.getHeight();
		cb.addTemplate(template, startX, startY);
	}

	/**
	 * テンプレートを生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param cb pdfコンテント
	 * @param template_name テンプレート名称
	 * @param width 幅
	 * @param height 高さ
	 */
	private void createTemplate(PdfContentByte cb, String template_name, float width, float height) {
		PdfTemplate template = cb.createTemplate(width, height);
		_template_map.put(template_name, template);
	}

	/**
	 * 【機能】ページ数をリセットします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】現在ページ数は0になります。最大ページ数もリセットします。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#resetPageCount()
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void resetPageCount() throws GReportException {
		if (_maxpage_template != null) {
			writeTemplateMaxPage();
		}
		_doc_pdf.setPageCount(0);
	}

	/**
	 * 【機能】背景色を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】フィールドには適用できません<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setBackGroundColor(float, float, float, float)
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 */
	public void setBackGroundColor(float left, float top, float width, float height) {
		Graphics2D graphic = createGraphic();
		graphic.setColor(GColor.gLightGray);
		graphic.fill(new Rectangle2D.Float(left * _col_pitch, top * _row_pitch, width * _col_pitch, height * _row_pitch));
		disposeGraphic(graphic);
	}

	/**
	 * 背景色を印刷します。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setBackGroundColor(float, float, float, float)
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param backColor 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	@Override
	public void writeBackGroundColor(float left, float top, float width, float height, Color backGroundColor) {
		if (backGroundColor == null) {
			return;
		}
		Graphics2D graphic = createGraphic();
		graphic.setColor(backGroundColor);
		graphic.fill(new Rectangle2D.Float(left * _col_pitch, top * _row_pitch, width * _col_pitch, height * _row_pitch));
		disposeGraphic(graphic);
	}

	/**
	 * 【機能】フィールドに背景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param startX 左
	 * @param startY 上
	 * @param width 幅
	 * @param height 高さ
	 * @param backColor 背景色
	 */
	private void setBackGroundColor4Field(float startX, float startY, float width, float height, Color backColor) {

		if (backColor == null) {
			return;
		}
		if (GColor.white == backColor) {
			return;
		}

		Graphics2D graphic = createGraphic();
		graphic.setColor(backColor);
		graphic.fill(new Rectangle2D.Float(startX * _col_pitch, startY * _row_pitch, width * _col_pitch, height * _row_pitch));

		disposeGraphic(graphic);
	}

	/**
	 * 【機能】最大幅数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getColumnCount()
	 * @return 最大幅数
	 */
	@Override
	public int getColumnCount() {
		return _col_count;
	}

	/**
	 * 【機能】最大行数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getRowCount()
	 * @return 最大行数
	 */
	@Override
	public int getRowCount() {
		return _row_count;
	}

	/**
	 * 【機能】デバッグフラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setDebug(boolean)
	 * @param is_debug デバッグフラグ
	 * @since 1.0
	 */
	@Override
	public void setDebug(boolean is_debug) {
		isDebug = is_debug;
	}

	/**
	 * 【機能】標準フォント名、サイズを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setDefaultFont(java.lang.String, java.lang.String, int)
	 * @param font_name フォント名
	 * @param font_encoding フォントエンコーディング
	 * @param font_size サイズ
	 */
	public void setDefaultFont(String font_name, String font_encoding, int font_size) {
		_font_name = font_name;
		_font_encoding = font_encoding;
		_font_size = font_size;
	}

	/**
	 * 【機能】フォント名を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return フォント名
	 * @create 2005/01/04
	 * @since 1.1.0
	 * @author kusakari
	 */
	protected String getFontName() {
		return _font_name;
	}

	/**
	 * 【機能】フォント名(Bold)を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return フォント名(Bold)
	 * @create 2008/08/01
	 * @since 1.4.1
	 * @author takaishi
	 */
	public String getFontNameBold() {
		return _font_name_bold;
	}

	/**
	 * 【機能】フォント名を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param fontName フォント名
	 * @create 2010/03/05
	 * @since 1.7.0
	 * @author kyo
	 */
	public void setFontName(String fontName) {
		_font_name = fontName;
	}

	/**
	 * 【機能】フォント名(Bold)を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param fontNameBold フォント名(Bold)
	 * @create 2008/08/01
	 * @since 1.4.1
	 * @author takaishi
	 */
	public void setFontNameBold(String fontNameBold) {
		_font_name_bold = fontNameBold;
	}

	/**
	 * 【機能】フォント名(Italic)を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return フォント名(Italic)
	 * @create 2008/08/01
	 * @since 1.4.1
	 * @author takaishi
	 */
	public String getFontNameItalic() {
		return _font_name_italic;
	}

	/**
	 * 【機能】フォント名(Italic)を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param fontNameItalic フォント名(Italic)
	 * @create 2008/08/01
	 * @since 1.4.1
	 * @author takaishi
	 */
	public void setFontNameItalic(String fontNameItalic) {
		_font_name_italic = fontNameItalic;
	}

	/**
	 * 【機能】外部フォントファイル使用するかどうかを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 判定結果
	 * @create 2009/01/05
	 * @since 1.5.0
	 * @author kyo
	 */
	public String getUseFontFile() {
		return _use_font_file;
	}

	/**
	 * 【機能】外部フォントファイル使用するかどうかを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param useFontFile 外部フォントファイル使用フラグ
	 * @create 2009/01/05
	 * @author kyo
	 * @since 1.5.0
	 */
	public void setUseFontFile(String useFontFile) {
		_use_font_file = useFontFile;
	}

	/**
	 * 【機能】フォントエンコーディングを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param fontEncoding フォントエンコーディング
	 * @create 2010/03/05
	 * @since 1.7.0
	 * @author kyo
	 */
	public void setFontEncoding(String fontEncoding) {
		_font_encoding = fontEncoding;
	}

	/**
	 * 【機能】フォントエンコーディングを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return フォントエンコーディング
	 * @create 2005/01/04
	 * @since 1.1.0
	 * @author kusakari
	 */
	protected String getFontEncoding() {
		return _font_encoding;
	}

	/**
	 * 【機能】列数と行数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setColumnAndRow(int, int)
	 * @param col_count 列数
	 * @param row_count 行数
	 * @create 2004/08/30
	 * @since 1.0.3
	 */
	@Override
	public void setColumnAndRow(int col_count, int row_count) {
		_row_count = row_count;
		_col_count = col_count;
		float width = _doc_pdf.right() - _doc_pdf.left();
		float height = _doc_pdf.top() - _doc_pdf.bottom();
		_col_pitch = width / (float) col_count;
		_row_pitch = height / (float) row_count;

		try {
			writeRuledLines();
		} catch (GReportException e) {
			throw new GReportRuntimeException(e);
		}

		if (isDebug()) {
			StringBuilder s = new StringBuilder();
			s.append("set column pitch:" + _col_pitch);
			s.append(System.lineSeparator());
			s.append("set row pitch:" + _row_pitch);
			System.out.println(s.toString());
		}
	}

	/**
	 * 【機能】ドキュメントをオープンしない初期化を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#initialize()
	 * @create 2004/07/20
	 * @since 1.0.3
	 */
	@Override
	public void initialize() {
		_doc_pdf.setMargins(_left_margin, _right_margin, _top_margin, _bottom_margin);
		_col_count = 0;
		_row_count = 0;
	}

	/**
	 * 【機能】用紙サイズを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setParperSize(java.lang.String)
	 * @param paper_size 用紙サイズ
	 */
	public void setParperSize(String paper_size) {
		_paper_size = paper_size;
	}

	/**
	 * 【機能】ベースフォントを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param fontFace フォントフェイス
	 * @return ベースフォント
	 */
	private BaseFont getBaseFont(int fontFace) {
		if (fontFace == IFieldInfo.FONT_FACE_BOLD) {
			return  _base_font_b;
		}

		if (fontFace == IFieldInfo.FONT_FACE_ITALIC) {
			return _base_font_i;
		}

		return  _base_font;
	}

	/**
	 * 【機能】高さを調節する値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param fontZoom 拡大率
	 * @return 調整値
	 * @create 2004/04/21
	 * @since 1.0.0
	 */
	private float getBuffer(float fontZoom) {
		float buffer = BUFFER * fontZoom;
		float padding = (_row_pitch - _font_size) * fontZoom / 2.0f;
		return (padding + buffer);
	}

	/**
	 * 【機能】複数行の文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】データには、各行に対する文字列を要素とする配列を渡します。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeString(float, float, java.lang.String[], int, java.lang.String, float, int, int, float, java.awt.Color, java.awt.Color, jp.co.kccs.greenearth.report.IReportLine, int, int)
	 * @param left 左
	 * @param top 上
	 * @param value データ
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param fontFace フォントフェイス
	 * @param fontHeight フォント高さ
	 * @param height 高さ
	 * @param foreColor 前景色
	 * @param backColor 背景色
	 * @param underLine 下線
	 * @param positionAdjustX 横位置微調整
	 * @param positionAdjustY 縦位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	@Override
	public void writeString(float left, float top, String[] value, int zoom, String align, float width, int fontFace, int fontHeight, float height, Color foreColor, Color backColor, IReportLine underLine, int positionAdjustX, int positionAdjustY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException {
		writeString(left, top, value, zoom, align, width, fontFace, fontHeight, height, foreColor, backColor, underLine, positionAdjustX, positionAdjustY, fontEncoding, fontName, fontNameBold, fontNameItalic, useFontFile, false);
	}

	/**
	 *
	 * @param left 左
	 * @param top 上
	 * @param value データ
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param fontFace フォントフェイス
	 * @param fontHeight フォント高さ
	 * @param height 高さ
	 * @param foreColor 前景色
	 * @param backColor 背景色
	 * @param underLine 下線
	 * @param positionAdjustX 横位置微調整
	 * @param positionAdjustY 縦位置微調整
	 * @param font_encoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @param printBuffStringFlag バッファフラグ
	 * @throws GReportException ReportFramework例外
	 * @create
	 * @author
	 * @since
	 */
	private void writeString(float left, float top, String[] value, int zoom, String align, float width, int fontFace, int fontHeight, float height, Color foreColor, Color backColor, IReportLine underLine, int positionAdjustX, int positionAdjustY, String font_encoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile, boolean printBuffStringFlag) throws GReportException {

		if (isOutOfRangeVertical(top)) {
			return;
		}

		float zoomedFontSize = _font_size * (float) zoom;
		float zoomedColPitch = _col_pitch * (float) zoom;
		float zoomedRowPitch = _row_pitch * (float) zoom;
		float buffer = getBuffer(zoom);

		if (!printBuffStringFlag) {
			// 背景色を文字列より先に印刷しておく
			setBackGroundColor4Field(left, top, width, height, backColor);
			// 文字列の印刷情報を一旦溜め込む
			WriteStringInfoImp writeStringInfoImp = new WriteStringInfoImp(
					left, top, value, zoom, align, width, fontFace,
					fontHeight, height, foreColor, backColor, underLine,
					positionAdjustX, positionAdjustY, font_encoding,
					fontName, fontNameBold, fontNameItalic, useFontFile);
			_strbuff.add(writeStringInfoImp);
			return;
		}

		PdfContentByte cb = _pdf_writer.getDirectContent();

		fieldFonts = new FieldFonts(font_encoding, fontName, fontNameBold, fontNameItalic, useFontFile);
		BaseFont font = getFontForField(fontFace);
		cb.setFontAndSize(font, zoomedFontSize);
		setColorFill(cb, foreColor);

		float emptyLineHeight = 0f;
		for (int j = 0; j < value.length; j++) {
			emptyLineHeight = -(_row_pitch * zoom * j);
			String str = value[j];

			float colIndex = left;
			int valueBytes = GDriverUtils.getCharCountByHalfWidth(str);

			if (isRightAlignment(align)) {
				float endCol = colIndex + width;
				colIndex = endCol - valueBytes * zoom;
			}

			if (isCenterAlignment(align)) {
				float rest = width - valueBytes * zoom;
				if (rest > 1) {
					colIndex = colIndex + (int) (rest / 2);
				}
			}

			if (underLine != null && underLine.getOutput()) {

				float startX = colIndex * _col_pitch;
				float endX = startX + valueBytes * zoomedColPitch;
				float startY = top * _row_pitch + zoomedRowPitch - buffer + zoomedFontSize / DEFAURT_FONT_SIZE;
				float endY = startY;

				writeUnderLine(startX, endX, startY - emptyLineHeight, endY - emptyLineHeight, underLine);
			}

			cb.beginText();
			float startY = _doc_pdf.top() - top * _row_pitch - zoomedRowPitch + buffer + emptyLineHeight + positionAdjustY;

			for (int i = 0; i < str.length(); i++) {
				String text = str.substring(i, i + 1);

				if (isOutOfRangeHorizontal(colIndex)) {
					break;
				}

				text = convertToYENMark(text, useFontFile);

				// ダブルバイトチェック
				if (GDriverUtils.getCharCountByHalfWidth(text) > 1) {
					// 文字列の出力(ダブルバイト)

					// サロゲート文字
					if (isSurrogatePairChar(text.charAt(0))) {
						if (i + 1 < str.length()) {
							if (isSurrogatePairChar(str.charAt(i + 1))) {
								text = str.substring(i, i + 2);
								i++;
							}
						}
					}

					cb.showTextAligned(PdfContentByte.ALIGN_CENTER, text, _doc_pdf.left() + colIndex * _col_pitch + zoomedColPitch + positionAdjustX, startY, 0);
					colIndex = colIndex + (2 * zoom);

				} else {
					cb.showTextAligned(PdfContentByte.ALIGN_CENTER, text, _doc_pdf.left() + colIndex * _col_pitch + zoomedColPitch / 2.0f + positionAdjustX, startY, 0);
					colIndex = colIndex + (1 * zoom);
				}
			}
			cb.endText();
		}
	}

	/**
	 * 【機能】アンダーラインを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param start_x 開始X
	 * @param end_x 終了X
	 * @param start_y 開始Y
	 * @param end_y 終了Y
	 * @param under_line ライン
	 * @throws GReportException ReportFramework例外
	 * @create 2004/06/29
	 * @since 1.0.2
	 */
	public void writeUnderLine(float start_x, float end_x, float start_y, float end_y, IReportLine under_line) throws GReportException {

		if (under_line == null) {
			return;
		}

		Graphics2D graphic = createGraphic();

		ILineDashInfo dashInfo = under_line.getDashInfo();
		int type = under_line.getType();
		// -------------------------------------
		// 線種（DashInfo）
		// -------------------------------------
		// LineDashInfo があれば最優先

		BasicStroke bs = null;

		if (dashInfo != null) {
			bs = new BasicStroke(under_line.getWidth(), BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {dashInfo.getUnitsOn(), dashInfo.getPhase()}, 0);
		} else if (ILineInfo.TYPE_DASH == type) {
			bs = new BasicStroke(under_line.getWidth(), BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {4, 2}, 0);
		} else if (ILineInfo.TYPE_DOT == type) {
			bs = new BasicStroke(under_line.getWidth(), BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {2, 2}, 0);
		} else if (ILineInfo.TYPE_DOUBLE == type) {

			bs = new BasicStroke(under_line.getWidth());
			graphic.setStroke(bs);
			graphic.setColor(under_line.getColor());

			if ((end_x - start_x) == 0) {
				graphic.draw(new Line2D.Float(start_x - 1, start_y, end_x - 1, end_y));
				graphic.draw(new Line2D.Float(start_x + 1, start_y, end_x + 1, end_y));
			} else if ((end_y - start_y) == 0) {
				graphic.draw(new Line2D.Float(start_x, start_y - 1, end_x, end_y - 1));
				graphic.draw(new Line2D.Float(start_x, end_y + 1, end_x, end_y + 1));
			}

			disposeGraphic(graphic);

			return;
		}

		else {
			bs = new BasicStroke(under_line.getWidth());
		}

		graphic.setStroke(bs);
		graphic.setColor(under_line.getColor());
		graphic.draw(new Line2D.Float(start_x, start_y, end_x, end_y));
		disposeGraphic(graphic);
	}

	/**
	 * 【機能】ピッチを無視して複数行の文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】データには、各行に対する文字列を要素とする配列を渡します。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeNonGridString(float, float, java.lang.String[], int, java.lang.String, float, int, int, int, int, float, java.awt.Color, java.awt.Color, jp.co.kccs.greenearth.report.IReportLine, int, int)
	 * @param left 左
	 * @param top 上
	 * @param value データ
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param font_face フォントフェイス
	 * @param size フォントサイズ
	 * @param interval 文字間隔(幅)
	 * @param font_height 文字間隔(高さ)
	 * @param height 高さ
	 * @param fore_color 前景色
	 * @param back_color 背景色
	 * @param under_line 下線
	 * @param position_adjust_x 横位置微調整
	 * @param position_adjust_y 縦位置微調整
	 * @param font_encoding フォントエンコーディング
	 * @param font_name フォント名
	 * @param font_name_bold フォント名（ボールド）
	 * @param font_name_italic フォント名（イタリック）
	 * @param use_font_file 外部フォントファイル利用有無
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeNonGridString(float left, float top, String[] value, int zoom, String align, float width, int font_face, int size, int interval, int font_height, float height, Color fore_color, Color back_color, IReportLine under_line, int position_adjust_x, int position_adjust_y, String font_encoding, String font_name, String font_name_bold, String font_name_italic, boolean use_font_file) throws GReportException {
		writeNonGridString(left, top, value, zoom, align, width, font_face, size, interval, font_height, height, fore_color, back_color, under_line, position_adjust_x, position_adjust_y, font_encoding, font_name, font_name_bold, font_name_italic, use_font_file, false);
	}

	/**
	 * グリッドに関係なく文字を出力します。
	 *
	 * @param left 左
	 * @param top 上
	 * @param value データ
	 * @param zoom 拡大率
	 * @param align アラインメント
	 * @param width 幅
	 * @param fontFace フォントフェイス
	 * @param fontSize フォントサイズ
	 * @param interval 文字間隔(幅)
	 * @param fontHeight 文字間隔(高さ)
	 * @param height 高さ
	 * @param foreColor 前景色
	 * @param backColor 背景色
	 * @param underLine 下線
	 * @param positionAdjustmentX 横位置微調整
	 * @param positionAdjustmentY 縦位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @param printStringBuffFlag バッファフラグ
	 * @throws GReportException ReportFramework例外
	 * @create
	 * @author
	 * @since
	 */
	public void writeNonGridString(float left, float top, String[] value, int zoom, String align, float width, int fontFace, int fontSize, int interval, int fontHeight, float height, Color foreColor, Color backColor, IReportLine underLine, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile, boolean printStringBuffFlag) throws GReportException {

		if (isOutOfRangeVertical(top)) {
			return;
		}

		// ここではgetBuf()の値は考慮しません。
		int buffer = 0 - fontHeight + (int) fontSize / (int) DEFAURT_FONT_SIZE;

		if (!printStringBuffFlag) {
			// 背景色を文字列より先に印刷しておく
			setBackGroundColor4Field(left, top, width, height, backColor);
			// 文字列の印刷情報を一旦溜め込む
			WriteNonGridStringInfoImp writeNonGridStringInfoImp = new WriteNonGridStringInfoImp(
					left, top, value, zoom, align, width, fontFace, fontSize,
					interval, fontHeight, height, foreColor, backColor,
					underLine, positionAdjustmentX, positionAdjustmentY,
					fontEncoding, fontName, fontNameBold, fontNameItalic,
					useFontFile);
			_strbuff.add(writeNonGridStringInfoImp);

			return;
		}

		PdfContentByte cb = _pdf_writer.getDirectContent();

		fieldFonts = new FieldFonts(fontEncoding, fontName, fontNameBold, fontNameItalic, useFontFile);
		BaseFont font = getFontForField(fontFace);
		cb.setFontAndSize(font, fontSize);
		setColorFill(cb, foreColor);

		float emptyLineHeight = 0f;
		for (int j = 0; j < value.length; j++) {

			emptyLineHeight = -((fontHeight + fontSize) * j);
			String str = value[j];

			float startPoint = _doc_pdf.left() + left * _col_pitch;
			int valueLength = str.length();
			int valueSize = 0;

			float endColumnPoint = _col_count * _col_pitch + _doc_pdf.left();
			float rowPoint = _doc_pdf.top() - top * _row_pitch - fontSize + buffer;

			// とりあえず int でキャストします。直すときはデザイナと同時に。
			for (int i = 0; i < valueLength; i++) {
				if (i < valueLength - 1) {
					valueSize += (int) (font.getWidthPoint(str.substring(i, i + 1), fontSize) + interval);
				} else {
					valueSize += (int) (font.getWidthPoint(str.substring(i, i + 1), fontSize));
				}
			}

			if (isCenterAlignment(align)) {
				float rest = width * _col_pitch - valueSize;
				if (rest > 1) {
					startPoint = startPoint + (float) Math.round(rest / 2);
				}
			}

			if (isRightAlignment(align)) {
				float endPoint = startPoint + width * _col_pitch;
				startPoint = endPoint - valueSize;
			}

			if (underLine != null && underLine.getOutput()) {
				float endPoint = (valueLength - 1) * interval + startPoint + font.getWidthPoint(str, fontSize);
				float heightPoint = (top * _row_pitch + fontSize - buffer) + fontSize / DEFAURT_FONT_SIZE;

				writeUnderLine(startPoint - _doc_pdf.left(), endPoint - _doc_pdf.left(), heightPoint - emptyLineHeight, heightPoint - emptyLineHeight, underLine);
			}

			cb.beginText();
			for (int i = 0; i < valueLength; i++) {
				String s = str.substring(i, i + 1);
				// ページの範囲を超えるものは出力しない
				if (startPoint < 0 || startPoint >= endColumnPoint) {
					break;
				}

				s = convertToYENMark(s, useFontFile);

				if (isSurrogatePairChar(s.charAt(0))) {
					if (i + 1 < str.length()) {
						if (isSurrogatePairChar(str.charAt(i + 1))) {
							s = str.substring(i, i + 2);
							i++;
						}
					}
				}

				cb.showTextAligned(PdfContentByte.ALIGN_LEFT, s, startPoint + positionAdjustmentX, rowPoint + emptyLineHeight + positionAdjustmentY, 0); // ####

				// 次回開始位置
				// デザイナに合わせます
				startPoint += (int) font.getWidthPoint(s, fontSize) + interval;
			}

			cb.endText();
		}
	}

	/**
	 * 色を設定します。
	 *
	 * @param contentByte {@link PdfContentByte}インスタンス
	 * @param color 色
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void setColorFill(PdfContentByte contentByte, Color color) {

		if (color == null) {
			contentByte.setColorFill(BaseColor.BLACK);
			return;
		}

		contentByte.setColorFill(new BaseColor(color.getRGB()));
	}

	/**
	 * 【機能】1グリッドの幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getGridWidth()
	 * @return 1グリッドの幅
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	@Override
	public float getGridWidth() {
		return _col_pitch;
	}

	/**
	 * 【機能】1グリッドの高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getGridHeight()
	 * @return 1グリッドの高さ
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	@Override
	public float getGridHeight() {
		return _row_pitch;
	}

	/**
	 * 【機能】ページ数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return ページ数
	 */
	public int getPageCount() {
		return _pdf_writer.getPageNumber();
	}

	/**
	 * 【機能】ページ数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setPageCount(int)
	 * @param count ページ数
	 * @create 2004/05/31
	 * @since 1.0.1
	 */
	@Override
	public void setPageCount(int count) {
		_pdf_writer.setPageCount(count);
	}

	/**
	 * 【機能】用紙サイズを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 用紙サイズ
	 */
	private Rectangle getPaperSize() {
		String paperSize = _paper_size;
		int index = paperSize.indexOf(',');
		if (index != -1) {
			paperSize = paperSize.substring(0, index);
		}

		// よく使うと思われるものは前へ
		if (paperSize.equals("a4")) {
			return PageSize.A4;
		}

		if (paperSize.equals("a5")) {
			return PageSize.A5;
		}

		if (paperSize.equals("b4")) {
			return PageSize.B4;
		}

		if (paperSize.equals("b5")) {
			return PageSize.B5;
		}

		if (paperSize.equals("a0")) {
			return PageSize.A0;
		}

		if (paperSize.equals("a1")) {
			return PageSize.A1;
		}

		if (paperSize.equals("a2")) {
			return PageSize.A2;
		}

		if (paperSize.equals("a3")) {
			return PageSize.A3;
		}

		if (paperSize.equals("a6")) {
			return PageSize.A6;
		}

		if (paperSize.equals("a7")) {
			return PageSize.A7;
		}

		if (paperSize.equals("a8")) {
			return PageSize.A8;
		}

		if (paperSize.equals("a9")) {
			return PageSize.A9;
		}

		if (paperSize.equals("a10")) {
			return PageSize.A10;
		}

		if (paperSize.equals("b0")) {
			return PageSize.B0;
		}

		if (paperSize.equals("b1")) {
			return PageSize.B1;
		}

		if (paperSize.equals("b2")) {
			return PageSize.B2;
		}

		if (paperSize.equals("b3")) {
			return PageSize.B3;
		}

		if (paperSize.equals("archa_a")) {
			return PageSize.ARCH_A;
		}

		if (paperSize.equals("archa_b")) {
			return PageSize.ARCH_B;
		}

		if (paperSize.equals("archa_c")) {
			return PageSize.ARCH_C;
		}

		if (paperSize.equals("archa_d")) {
			return PageSize.ARCH_D;
		}

		if (paperSize.equals("archa_e")) {
			return PageSize.ARCH_E;
		}

		if (paperSize.equals("flsa")) {
			return PageSize.FLSA;
		}

		if (paperSize.equals("flse")) {
			return PageSize.FLSE;
		}

		if (paperSize.equals("halfletter")) {
			return PageSize.HALFLETTER;
		}

		if (paperSize.equals("11_17")) {
			return PageSize._11X17;
		}

		if (paperSize.equals("ledger")) {
			return PageSize.LEDGER;
		}

		if (paperSize.equals("custom")) {
			paperSize = _paper_size;
			int height = 0;
			int width = 0;
			index++;
			int nextIndex = _paper_size.indexOf(',', index);
			width = Integer.parseInt(paperSize.substring(index, nextIndex));
			nextIndex++;
			height = Integer.parseInt(paperSize.substring(nextIndex));
			return new Rectangle(height, width);
		}

		return PageSize.A4;
	}

	/**
	 * 【機能】イメージを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeImage(float, float, float, float, java.lang.String)
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param source ソース
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeImage(float left, float top, float width, float height, String source) throws GReportException {

		if (isEmpty(source)) {
			return;
		}

		Image img = getImageInstance(source);

		addImage(img, left, top, width, height);
	}

	/**
	 * 【機能】バーコードを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeBarcode(int, float, float, float, float, java.lang.String, jp.co.kccs.greenearth.report.repository.IBarcodeInfo)
	 * @param type タイプ
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param value 値
	 * @param info バーコード情報
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeBarcode(int type, float left, float top, float width, float height, String value, IBarcodeInfo info) throws GReportException {

		if (isEmpty(value)) {
			return;
		}

		PdfContentByte cb = _pdf_writer.getDirectContent();
		// バーコードイメージの作成
		Image img = createImageWithBarcode(cb, type, left, top, width, height, value, info);
		if (img == null) {
		    return;
		}
		addImage(img, left, top, width, height);
	}

	/**
	 * 【機能】バーコードイメージを作成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param pdfContent pdfコンテント
	 * @param type タイプ
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param value 値
	 * @param info バーコード情報
	 * @return バーコードイメージ
	 * @throws GReportException ReportFramework例外
	 * @create 2015/03/16
	 * @since 1.0.3
	 */
	private Image createImageWithBarcode(PdfContentByte pdfContent, int type, float left, float top, float width, float height, String value, IBarcodeInfo info) throws GReportException {

		Image img = null;
		if (type == IBarcodeInfo.BARCODE_TYPE_EAN) {
			BarcodeEAN ean = new BarcodeEAN();
			ean.setCode(value);
			ean.setCodeType(info.getEan().getCodeType());

			img = ean.createImageWithBarcode(pdfContent, BaseColor.BLACK, BaseColor.BLACK);
		} else if (type == IBarcodeInfo.BARCODE_TYPE_128) {
			Barcode128 b128 = new Barcode128();
			b128.setCode(value);
			b128.setCodeType(info.getCode128().getCodeType());

			img = b128.createImageWithBarcode(pdfContent, BaseColor.BLACK, BaseColor.BLACK);
		} else if (type == IBarcodeInfo.BARCODE_TYPE_39) {
			Barcode39 b39 = new Barcode39();
			b39.setCode(value);
			b39.setExtended(info.getCode39().getExtended());
			b39.setGenerateChecksum(info.getCode39().getGenerateCheckSum());
			if (!info.getCode39().isCodeVisible()) {
				b39.setFont(null);
			}

			img = b39.createImageWithBarcode(pdfContent, BaseColor.BLACK, BaseColor.BLACK);
		} else if (type == IBarcodeInfo.BARCODE_TYPE_CODABAR) {
			BarcodeCodabar codabar = new BarcodeCodabar();
			codabar.setCode(value);
			codabar.setGenerateChecksum(info.getCodabar().getGenerateCheckSum());

			img = codabar.createImageWithBarcode(pdfContent, BaseColor.BLACK, BaseColor.BLACK);
		} else if (type == IBarcodeInfo.BARCODE_TYPE_INTER25) {
			BarcodeInter25 inter25 = new BarcodeInter25();
			inter25.setCode(value);
			inter25.setGenerateChecksum(info.getInter25().getGenerateCheckSum());

			img = inter25.createImageWithBarcode(pdfContent, BaseColor.BLACK, BaseColor.BLACK);
		} else if (type == IBarcodeInfo.BARCODE_TYPE_POSTNET) {
			BarcodePostnet postnet = new BarcodePostnet();
			postnet.setCode(value);
			postnet.setCodeType(info.getPostnet().getCodeType());

			img = postnet.createImageWithBarcode(pdfContent, BaseColor.BLACK, BaseColor.BLACK);
		} else if (type == IBarcodeInfo.BARCODE_TYPE_EAN_SUPP) {
			BarcodeEAN ean = new BarcodeEAN();
			ean.setCodeType(info.getEanSupp().getCodeType());
			ean.setCode(value);

			BarcodeEAN supp = new BarcodeEAN();
			supp.setCodeType(info.getEanSupp().getSuppCodeType());
			supp.setCode(info.getEanSupp().getSuppValue());

			BarcodeEANSUPP ensupp = new BarcodeEANSUPP(ean, supp);
			img = ensupp.createImageWithBarcode(pdfContent, BaseColor.BLACK, BaseColor.BLACK);
		} else if (type == IBarcodeInfo.BARCODE_TYPE_PDF417) {
			BarcodePDF417 barPdf417 = new BarcodePDF417();
			barPdf417.setCodeColumns(info.getPdf417().getColumnCount());
			barPdf417.setCodeRows(info.getPdf417().getRowCount());
			barPdf417.setText(value);

			// バーコードイメージの作成
			java.awt.Image im = barPdf417.createAwtImage(Color.black, Color.white);
			// バーコードイメージの作成
			img = getImageInstance(im);

		} else if (type == IBarcodeInfo.BARCODE_TYPE_QR) {
			PdfTemplate template = null;
			if (pdfContent instanceof PdfTemplate) {
				template = (PdfTemplate) pdfContent;
			}
			// QR コードを出力します
			writeBarcode4QR(template, left, top, width, height, value, info);
		}

		return img;
	}

	/**
	 * 【機能】QR コードを出力します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param template テンプレート
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @param value 値
	 * @param info バーコード情報
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	private void writeBarcode4QR(PdfTemplate template, float left, float top, float width, float height, String value, IBarcodeInfo info) {

		Graphics2D g = null;

		if (template == null) {
			g = createGraphic();
		} else {
			g = createGraphic4Template(template);
		}

		boolean[][] isDisp = info.getQRCode().calQrcode(value.getBytes());

		float startX = left * _col_pitch;
		float startY = top * _row_pitch;

		float pixX = width * _col_pitch / (float) isDisp.length;
		float pixY = height * _row_pitch / (float) isDisp[0].length;

		for (int i = 0; i < isDisp.length; i++) {
			for (int j = 0; j < isDisp[i].length; j++) {
				if (isDisp[j][i]) {

					g.setColor(Color.black);
					g.fill(new Rectangle2D.Float(startX + j * pixX, startY + i * pixY, pixX, pixY));

				}
			}
		}

		if (template == null) {
			disposeGraphic(g);
		} else {
			disposeGraphic4Template(template, g);
		}

	}

	/**
	 * 【機能】イメージをドキュメントに追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param img イメージ
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @throws GReportException ReportFramework例外
	 */
	private void addImage(Image img, float left, float top, float width, float height) throws GReportException {
		float fixedLeft = left * _col_pitch;
		float fixedTop = top * _row_pitch;
		float fixedWidth = width * _col_pitch;
		float fixedHieght = height * _row_pitch;

		PdfContentByte cb = _pdf_writer.getDirectContent();

		try {
			cb.addImage(img, fixedWidth, 0, 0, fixedHieght, _doc_pdf.left() + fixedLeft, _doc_pdf.top() - fixedTop - fixedHieght);
		} catch (DocumentException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】ラインを印刷します。二重線の出力が可能です。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeLine(float, float, float, float, double, int, java.awt.Color, jp.co.kccs.greenearth.report.repository.ILineDashInfo, boolean)
	 * @param startX 左
	 * @param startY 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param color カラー
	 * @param dashInfo 点線情報
	 * @param isDouble 二重線フラグ
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeLine(float startX, float startY, float width, float height, double size, int type, Color color, ILineDashInfo dashInfo, boolean isDouble) throws GReportException {

		float lineSize = (float) size;

		if (isDouble) {
			lineSize /= 3;
		}

		float fixedStartX = calculateStartX(startX);
		float fixedEndX = calculateEndX(startX, width);
		float fixedStartY = calculateStartY(startY);
		float fixedEndY = calculateEndY(startY, height);

		Graphics2D line = createGraphic();

		setColor(line, color);

		// #### 互換性のため、残しておく。
		if (ILineInfo.TYPE_DOUBLE == type) {

			line.setStroke(new BasicStroke(lineSize));

			if ((fixedEndX - fixedStartX) == 0) {
				line.draw(new Line2D.Float(fixedStartX - 1, fixedStartY, fixedEndX - 1, fixedEndY));
				line.draw(new Line2D.Float(fixedStartX + 1, fixedStartY, fixedEndX + 1, fixedEndY));
			} else if ((fixedEndY - fixedStartY) == 0) {
				line.draw(new Line2D.Float(fixedStartX, fixedStartY - 1, fixedEndX, fixedEndY - 1));
				line.draw(new Line2D.Float(fixedStartX, fixedStartY + 1, fixedEndX, fixedEndY + 1));
			}

			disposeGraphic(line);

			return;
		}

		line.setStroke(getStroke4Line(lineSize, type, dashInfo));

		if (isDouble) {

			// #### オリジナルに対する各二重線の相対座標を計算
			float totalLineWidth = lineSize * 3; // 二重線トータルの幅
			float doubleLineWidth = totalLineWidth / 3; // 構成線一本の幅

			float dx = 0f; // オリジナル座標Xからの構成線のx方向平行移動値
			float dy = 0f; // オリジナル座標Yからの構成線のy方向平行移動値

			if (height != 0) {

				double angle = Math.atan(Math.abs((double) width) / Math.abs((double) height));
				dx = doubleLineWidth * (float) Math.cos(angle);
				dy = doubleLineWidth * (float) Math.sin(angle);
			}

			if (width == 0) {
				// 垂直線
				line.draw(new Line2D.Float(fixedStartX + doubleLineWidth, fixedStartY, fixedEndX + doubleLineWidth, fixedEndY));
				line.draw(new Line2D.Float(fixedStartX - doubleLineWidth, fixedStartY, fixedEndX - doubleLineWidth, fixedEndY));
			} else if (height == 0) {
				// 水平線
				line.draw(new Line2D.Float(fixedStartX, fixedStartY + doubleLineWidth, fixedEndX, fixedEndY + doubleLineWidth));
				line.draw(new Line2D.Float(fixedStartX, fixedStartY - doubleLineWidth, fixedEndX, fixedEndY - doubleLineWidth));
			} else if (width > 0 && height > 0 || width < 0 && height < 0) {
				// 右下がりの線
				line.draw(new Line2D.Float(fixedStartX + dx, fixedStartY - dy, fixedEndX + dx, fixedEndY - dy));
				line.draw(new Line2D.Float(fixedStartX - dx, fixedStartY + dy, fixedEndX - dx, fixedEndY + dy));
			} else {
				// 右上がりの線
				line.draw(new Line2D.Float(fixedStartX + dx, fixedStartY + dy, fixedEndX + dx, fixedEndY + dy));
				line.draw(new Line2D.Float(fixedStartX - dx, fixedStartY - dy, fixedEndX - dx, fixedEndY - dy));
			}

		} else {
			line.draw(new Line2D.Float(fixedStartX, fixedStartY, fixedEndX, fixedEndY));
		}

		disposeGraphic(line);
	}

	/**
	 * 色を設定します.
	 *
	 * @param graphic 対象図形
	 * @param color 色
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void setColor(Graphics2D graphic, Color color) {
		if (color == null) {
			graphic.setColor(GColor.black);
			return;
		}

		graphic.setColor(color);
	}

	/**
	 * {@link BasicStroke}のインスタンスを取得します.
	 *
	 * @param lineSize 線サイズ
	 * @param type タイプ
	 * @param dashInfo 破線情報
	 * @return {@link BasicStroke}のインスタンス
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private BasicStroke getStroke4Line(float lineSize, int type, ILineDashInfo dashInfo) {

		if (ILineInfo.TYPE_CUSTOM_DASH == type) {
			if (dashInfo == null) {
				return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f);
			}
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {dashInfo.getUnitsOn(), dashInfo.getPhase()}, 0);
		}

		if (ILineInfo.TYPE_DASH == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {4, 2}, 0);
		}

		if (ILineInfo.TYPE_DOT == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {2, 2}, 0);
		}

		return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f);
	}

	/**
	 * 横軸開始位置を再計算します.
	 *
	 * @param startX 横軸開始位置
	 * @return 横軸開始位置
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private float calculateStartX(float startX) {

		if (startX < 0) {
			startX = 0;
		}
		if (startX > _col_count) {
			startX = _col_count;
		}

		return startX * _col_pitch;
	}

	/**
	 * 縦軸開始位置を再計算します.
	 *
	 * @param startY 縦軸開始位置
	 * @return 縦軸開始位置
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private float calculateStartY(float startY) {

		if (startY < 0) {
			startY = 0;
		}
		if (startY > _row_count) {
			startY = _row_count;
		}

		return startY * _row_pitch;
	}

	/**
	 * 横軸終了位置を再計算します.
	 *
	 * @param startX 横軸開始位置
	 * @param width 幅
	 * @return 横軸開始位置
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private float calculateEndX(float startX, float width) {

		float endX = startX + width;

		if (endX < 0) {
			endX = 0;
		}
		if (endX > _col_count) {
			endX = _col_count;
		}

		return endX * _col_pitch;
	}

	/**
	 * 縦軸終了位置を再計算します.
	 *
	 * @param startY 縦軸開始位置
	 * @param height 高さ
	 * @return 縦軸開始位置
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private float calculateEndY(float startY, float height) {

		float endY = startY + height;

		if (endY < 0) {
			endY = 0;
		}
		if (endY > _row_count) {
			endY =  _row_count;
		}

		return endY * _row_pitch;
	}

	/**
	 * 【機能】四角形を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeRectangle(float, float, float, float, double, int, int, jp.co.kccs.greenearth.report.repository.ILineDashInfo)
	 * @param startX 左
	 * @param startY 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param radius 角丸長方形の角の半径
	 * @param dash_info 点線情報
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeRectangle(float startX, float startY, float width, float height, double size, int type, int radius, ILineDashInfo dash_info) throws GReportException {

		Graphics2D graphic = createGraphic();

		// 表示位置を計算
		float fixedStartX = calculateStartX(startX);
		float fixedStartY = calculateStartY(startY);
		float fixedWidth = width * _col_pitch;
		float fixedHeight = height * _row_pitch;

		graphic.setStroke(getStroke4Rectangle((float) size, type, dash_info));
		graphic.setColor(GColor.black);

		if (radius > 0) {
			graphic.draw(new RoundRectangle2D.Float(fixedStartX, fixedStartY, fixedWidth, fixedHeight, radius, radius));
		} else {
			graphic.draw(new Rectangle2D.Float(fixedStartX, fixedStartY, fixedWidth, fixedHeight));
		}

		disposeGraphic(graphic);
	}

	/**
	 * {@link BasicStroke}のインスタンスを取得します.
	 *
	 * @param lineSize 線サイズ
	 * @param type タイプ
	 * @param dashInfo 破線情報
	 * @return {@link BasicStroke}のインスタンス
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private BasicStroke getStroke4Rectangle(float lineSize, int type, ILineDashInfo dashInfo) {

		if (IRectangleInfo.TYPE_CUSTOM_DASH == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {dashInfo.getUnitsOn(), dashInfo.getPhase()}, 0);
		}

		if (IRectangleInfo.TYPE_DASH == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {4, 2}, 0);
		}

		if (IRectangleInfo.TYPE_DOT == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {2, 2}, 0);
		}

		return new BasicStroke(lineSize);
	}

	/**
	 * 【機能】グリッドラインを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param startX 左
	 * @param startY 上
	 * @param endX 幅
	 * @param endY 高さ
	 */
	private void writeRuledLine(float startX, float startY, float endX, float endY) {

		Graphics2D graphic = createGraphic();
		BasicStroke basicStroke = null;

		if ((startX == 0 && endX == 0) || (startX == getColumnCount() && endX == getColumnCount()) || (startY == 0 && endY == 0) || (startY == getRowCount() && endY == getRowCount())) {
			graphic.setColor(GColor.gray);
			basicStroke = new BasicStroke(1);
		} else {
			graphic.setColor(GColor.gray);
			basicStroke = new BasicStroke(0, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {2, 2}, 0);
		}

		graphic.setStroke(basicStroke);

		startX = startX * _col_pitch;
		endX = endX * _col_pitch;
		startY = startY * _row_pitch;
		endY = endY * _row_pitch;

		graphic.draw(new Line2D.Float(startX, startY, endX, endY));
		disposeGraphic(graphic);
	}

	/**
	 * 【機能】サークルを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeCircle(float, float, float, float, double, int, int, jp.co.kccs.greenearth.report.repository.ILineDashInfo)
	 * @param startX 左
	 * @param startY 上
	 * @param height 高さ
	 * @param width 幅
	 * @param line_width 線幅
	 * @param type タイプ
	 * @param true_circle 正円オプション
	 * @param dash_info 点線情報
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeCircle(float startX, float startY, float height, float width, double line_width, int type, int true_circle, ILineDashInfo dash_info) throws GReportException {
		float lineSize = (float) line_width;

		Graphics2D g = createGraphic();

		BasicStroke bs = getStroke4Cirle(lineSize, type, dash_info);
		g.setColor(GColor.black);
		g.setStroke(bs);

		// #### デザイナと同じロジックに
		float sx = calculateStartX(startX);
		float ex = calculateEndX(startX, width);
		float sy = calculateStartY(startY);
		float ey = calculateEndY(startY, height);

		// 表示位置を計算
		// 正円オプションがある場合は正円にします。
		// 正円は必ず中心に表示します。
		if (true_circle == ICircleInfo.TRUE_CIRCLE_VIRTICAL) {
			ex = sx + height * _row_pitch;
		} else if (true_circle == ICircleInfo.TRUE_CIRCLE_HORIZONTAL) {
			ey = sy + width * _col_pitch;
		}

		g.draw(new Arc2D.Float(sx, sy, ex - sx, ey - sy, 0, 360, Arc2D.OPEN));
		disposeGraphic(g);
	}

	/**
	 * {@link BasicStroke}のインスタンスを取得します.
	 *
	 * @param lineSize 線サイズ
	 * @param type タイプ
	 * @param dashInfo 破線情報
	 * @return {@link BasicStroke}のインスタンス
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private BasicStroke getStroke4Cirle(float lineSize, int type, ILineDashInfo dashInfo) {

		if (ICircleInfo.TYPE_CUSTOM_DASH == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {dashInfo.getUnitsOn(), dashInfo.getPhase()}, 0);
		}

		if (ICircleInfo.TYPE_DASH == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {4, 2}, 0);
		}

		if (ICircleInfo.TYPE_DOT == type) {
			return new BasicStroke(lineSize, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10f, new float[] {2, 2}, 0);
		}

		return new BasicStroke(lineSize);
	}

	/**
	 * 【機能】1ページ分のグリッドラインを表示します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @throws GReportException ReportFramework例外
	 */
	protected void writeRuledLines() throws GReportException {
		if (_print_ruled_line) {
			for (int i = 0; i < getRowCount() + 1; i++) {
				writeRuledLine(0, i, getColumnCount(), i);
			}
			for (int i = 0; i < getColumnCount() + 1; i++) {
				writeRuledLine(i, 0, i, getRowCount());
			}
		}
	}

	/**
	 * 【機能】グリッドラインを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setRuledLine(boolean)
	 * @param bool グリッドラインを印刷するかの真偽値
	 */
	@Override
	public void setRuledLine(boolean bool) {
		_print_ruled_line = bool;
	}

	/**
	 * 【機能】ページブレイク（改ページ）を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#pageBreak()
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void pageBreak() throws GReportException {

		// 溜め込んだ文字列を印刷する
		printBuffString();

		_grobal_page_count++;
		// =================================================
		// とりあえず100枚ごとに
		// if ( isDebug() ) {
		// if ( ( _grobal_page_count % 100 ) == 0 ) {
		// _pdf_writer.flushTemplate();
		// System.out.println("flush!: "+_grobal_page_count);
		// }
		// }
		// =================================================
		_doc_pdf.newPage();
		_doc_pdf.setPageCount(_doc_pdf.getPageNumber() + 1);
		if (_show_outline) {
			writeOutline(String.valueOf(_grobal_page_count));
		}

		writeRuledLines();
	}

	/**
	 * 【機能】溜め込んだ文字列を印刷します。<BR>
	 * 改ページ(pageBreak)とクローズ(close)のタイミングで印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @throws GReportException ReportFramework例外
	 */
	private void printBuffString() throws GReportException {
		int listSize = _strbuff.size();
		if (listSize > 0) {
			for (int i = 0; i < listSize; i++) {
				WriteStringInfo writeStringInfo = _strbuff.get(i);
				writeStringInfo.write();
			}
			_strbuff.clear();
		}
	}

	/**
	 * 【機能】アウトラインを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 */
	public void setOutline() {
		_show_outline = true;
	}

	@Override
	public void writeOutline(String outline_str) {
		if (isEmpty(outline_str)) {
			return;
		}
		PdfContentByte cb = _pdf_writer.getDirectContent();
		PdfDestination destination = new PdfDestination(PdfDestination.FITH, 1);
		PdfOutline outline = new PdfOutline(cb.getRootOutline(), destination, outline_str);
		cb.addOutline(outline, outline_str);
	}

	/**
	 * 【機能】ドキュメントオープン時の初期化を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @throws GReportException ReportFramework例外
	 * @create 2004/07/20
	 * @since 1.0.0
	 */
	private void initializeForOpen() throws GReportException {

		createAndSetFontsForReport();
		setOrientation();
		_doc_pdf.setMargins(_left_margin, _right_margin, _top_margin, _bottom_margin);
		createAndSetPdfWriter();

		outputDebugLog();

		_doc_pdf.open();
		_doc_pdf.setPageCount(PDF_START_PAGE);
	}

	/**
	 * 帳票全体のフォントを生成し設定します。
	 *
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void createAndSetFontsForReport() throws GReportException {

		// フォントの設定
		String fixedFontEncoding = null;
		String fixedFontName = null;
		String fixedFontNameBold = null;
		String fixedFontNameItalic = null;

		if (Boolean.valueOf(getUseFontFile()).booleanValue()) {
			fixedFontEncoding = optimizeValue(getFontEncoding(), BaseFont.IDENTITY_H);
			fixedFontName = appendPath(getFontName());
			fixedFontNameBold = appendPath(optimizeValue(getFontNameBold(), getFontName()));
			fixedFontNameItalic = appendPath(optimizeValue(getFontNameItalic(), getFontName()));
		} else {
			fixedFontEncoding = convertFontEncoding(getFontEncoding());
			fixedFontName = optimizeValue(getFontName(), DEFAURT_FONT_NAME);
			fixedFontNameBold = optimizeValue(getFontNameBold(), fixedFontName + ",Bold");
			fixedFontNameItalic = optimizeValue(getFontNameItalic(), fixedFontName + ",Italic");
		}

		try {

			createAndSetFonts(fixedFontEncoding, fixedFontName, fixedFontNameBold, fixedFontNameItalic);

		} catch (MissingResourceException mre) {
			// 外部フォントファイル利用で名前にパスが含まれている場合はパスを付与せずにフォントを作成する
			fixedFontEncoding = optimizeValue(getFontEncoding(), BaseFont.IDENTITY_H);
			fixedFontName = getFontName();
			fixedFontNameBold = optimizeValue(getFontNameBold(), getFontName());
			fixedFontNameItalic = optimizeValue(getFontNameItalic(), getFontName());

			createAndSetFonts(fixedFontEncoding, fixedFontName, fixedFontNameBold, fixedFontNameItalic);
		}
	}

	/**
	 * フォントを生成し設定します。
	 *
	 * @param encoding エンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名ボールド
	 * @param fontNameItalic フォント名イタリック
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void createAndSetFonts(String encoding, String fontName, String fontNameBold, String fontNameItalic) throws GReportException {
		try {
			_base_font = BaseFont.createFont(fontName, encoding, BaseFont.NOT_EMBEDDED);
			_base_font_b = BaseFont.createFont(fontNameBold, encoding, BaseFont.NOT_EMBEDDED);
			_base_font_i = BaseFont.createFont(fontNameItalic, encoding, BaseFont.NOT_EMBEDDED);
		} catch (DocumentException | IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 印刷向きを設定します.
	 *
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void setOrientation() {
		if (_orientation == ORIENTATION_HORIZONTAL) {
			_doc_pdf = new Document(getPaperSize().rotate());
		} else {
			_doc_pdf = new Document(getPaperSize());
		}
	}

	/**
	 * {@link PdfWriter}のインスタンスを生成し設定します.
	 *
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/20
	 * @author KCCS hashimoto
	 * @since  2.0.0
	 */
	private void createAndSetPdfWriter() throws GReportException {
		try {

			String fileName;
			if (_passwd != null) {
				fileName = getAuthFileName();
			} else {
				fileName = _file_name;
			}
			_pdf_writer = PdfWriter.getInstance(_doc_pdf, new FileOutputStream(fileName));

		} catch (DocumentException | FileNotFoundException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * デバック用ログを標準出力へ出力する.
	 *
	 * @create
	 * @author
	 * @since
	 */
	private void outputDebugLog() {
		if (isDebug()) {
			String lineSeparator = System.getProperty("line.separator", System.lineSeparator());

			StringBuilder stringBuilder = new StringBuilder("**************************************************");
			stringBuilder.append(lineSeparator);
			stringBuilder.append("		Initialize report driver start.");
			stringBuilder.append(lineSeparator);
			stringBuilder.append("**************************************************");
			stringBuilder.append(lineSeparator);
			stringBuilder.append("top:" + _doc_pdf.top());
			stringBuilder.append(lineSeparator);
			stringBuilder.append("left:" + _doc_pdf.left());
			stringBuilder.append(lineSeparator);
			stringBuilder.append("right:" + _doc_pdf.right());
			stringBuilder.append(lineSeparator);
			stringBuilder.append("bottom:" + _doc_pdf.bottom());
			stringBuilder.append(lineSeparator);
			stringBuilder.append("top_margin:" + _top_margin);
			stringBuilder.append(lineSeparator);
			stringBuilder.append("left_margin:" + _left_margin);
			stringBuilder.append(lineSeparator);
			stringBuilder.append("right_margin:" + _right_margin);
			stringBuilder.append(lineSeparator);
			stringBuilder.append("bottom_margin:" + _bottom_margin);
			stringBuilder.append(lineSeparator);
			stringBuilder.append("paper_size:" + _paper_size);
			stringBuilder.append(lineSeparator);
			stringBuilder.append("font_size:" + _font_size);
			stringBuilder.append(lineSeparator);
			if (_orientation == ORIENTATION_HORIZONTAL) {
				stringBuilder.append("orientation:horizontal");
			} else {
				stringBuilder.append("orientation:vartical");
			}
			stringBuilder.append(lineSeparator);
			stringBuilder.append("**************************************************");
			stringBuilder.append(lineSeparator);
			stringBuilder.append("		Initialize report driver finish.");
			stringBuilder.append(lineSeparator);
			stringBuilder.append("**************************************************");

			System.out.println(stringBuilder.toString());
		}
	}

	/**
	 * 【機能】PDFにJavaScriptを埋め込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setJavaScript(java.lang.String)
	 * @param script JavaScript
	 */
	@Override
	public void setJavaScript(String script) {
		if (isEmpty(script)) {
			return;
		}
		PdfAction jsAction = PdfAction.javaScript(script, _pdf_writer);
		_pdf_writer.addJavaScript(jsAction);
	}

	/**
	 * 【機能】バックスラッシュを半角円マークに変換します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】 UNICODE コードポイントがバックスラッシュであれば半角円マークに変換します。<BR>
	 * ただし、外部ファイルを使用する（フォントを埋め込む）場合は、変換しません。<BR>
	 *
	 * @param str 変換対象となる文字列
	 * @param useFontFile 外部ファイルを使用する（フォントを埋め込む）か
	 * @return 変換後の文字列
	 * @create 2004/06/28
	 * @since 1.0.2
	 */
	private String convertToYENMark(String str, boolean useFontFile) {
		if (isUseFontFile(useFontFile)) {
			return str;
		}
		String s = str;
		// ----------------------------------------
		// 文字が \ かつ UNICODE コードポイントがバックスラッシュであれば
		// 円マークに変換します
		// ----------------------------------------
		if (s.equals("\\") && (s.charAt(0) == BACK_SLASH)) {
			char bs = BACK_SLASH;
			char c = s.charAt(0);
			if (c == bs) {
				s = String.valueOf(EN_MARK);
			}
		}
		return s;
	}

	/**
	 * 【機能】Graphics2Dを作成します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @return Graphics2Dのインスタンス
	 * @create 2010/01/29
	 * @author takaishi
	 * @since 1.6.0
	 */
	private Graphics2D createGraphic() {
		PdfContentByte cb = _pdf_writer.getDirectContent();
		cb.saveState();
		cb.concatCTM(1, 0, 0, 1, _doc_pdf.leftMargin(), -_doc_pdf.topMargin());
		Graphics2D graphic = cb.createGraphics(_doc_pdf.getPageSize().getWidth(), _doc_pdf.getPageSize().getHeight());
		return graphic;
	}

	/**
	 * 【機能】Graphics2Dを破棄します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @param graphic Graphics2Dのインスタンス
	 * @create 2010/01/29
	 * @author takaishi
	 * @since 1.6.0
	 */
	private void disposeGraphic(Graphics2D graphic) {
		PdfContentByte cb = _pdf_writer.getDirectContent();
		graphic.dispose();
		cb.restoreState();
	}

	/**
	 * 【機能】Graphics2Dを作成します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @param template テンプレート
	 * @return Graphics2Dのインスタンス
	 * @create 2015/03/20
	 * @author KCSS LiuXunAn
	 * @since 1.6.0
	 */
	private Graphics2D createGraphic4Template(PdfTemplate template) {
		template.saveState();
		template.concatCTM(1, 0, 0, 1, 0, 0);
		Graphics2D graphic = template.createGraphics(template.getWidth(), template.getHeight());
		return graphic;
	}

	/**
	 * 【機能】Graphics2Dを破棄します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @param template テンプレート
	 * @param graphic Graphics2Dのインスタンス
	 * @create 2015/03/20
	 * @author KCSS LiuXunAn
	 * @since 1.6.0
	 */
	private void disposeGraphic4Template(PdfTemplate template, Graphics2D graphic) {
		graphic.dispose();
		template.restoreState();
	}

	/**
	 * {@link IMaxPageInfo}のインスタンスを取得する。
	 *
	 * @return {@link IMaxPageInfo}のインスタンス
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since 2.0.0
	 */
	protected IMaxPageInfo getMaxPageInfo() {
		if (_maxpage_info == null) {
			_maxpage_info = GFrameworkUtils.getComponent(IMaxPageInfo.class.getName());
		}
		return _maxpage_info;
	}

	/**
	 * フィールド用に個別に使用する最適なフォントを取得する。
	 *
	 * @param fontFace フォントフェイス
	 * @return フィールド用に個別に使用する最適なフォント
	 * @throws GReportException ReportFramework例外
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since 2.0.0
	 */
	private BaseFont getFontForField(int fontFace) throws GReportException {

		if (needFontForField()) {

			String fixedFontEncoding = null;
			String fixedFontName = null;
			String fixedFontNameBold = null;
			String fixedFontNameItalic = null;

			if (fieldFonts.isUseFontFile()) {
				fixedFontEncoding = optimizeValue(fieldFonts.getFontEncoding(), BaseFont.IDENTITY_H);
				fixedFontName = appendPath(fieldFonts.getFontName());
				fixedFontNameBold = appendPath(optimizeValue(fieldFonts.getFontNameBold(), fieldFonts.getFontName()));
				fixedFontNameItalic = appendPath(optimizeValue(fieldFonts.getFontNameItalic(), fieldFonts.getFontName()));
			} else {
				fixedFontEncoding = convertFontEncoding(fieldFonts.getFontEncoding());
				fixedFontName = optimizeValue(fieldFonts.getFontName(), DEFAURT_FONT_NAME);
				fixedFontNameBold = optimizeValue(fieldFonts.getFontNameBold(), fixedFontName + ",Bold");
				fixedFontNameItalic = optimizeValue(fieldFonts.getFontNameItalic(), fixedFontName + ",Italic");
			}

			try {

				return createFontsForExecute(fontFace, fixedFontEncoding, fixedFontName, fixedFontNameBold, fixedFontNameItalic);

			} catch (MissingResourceException mre) {
				// 外部フォントファイル利用で名前にパスが含まれている場合はパスを付与せずにフォントを作成する
				fixedFontEncoding = optimizeValue(fieldFonts.getFontEncoding(), BaseFont.IDENTITY_H);
				fixedFontName = fieldFonts.getFontName();
				fixedFontNameBold = optimizeValue(fieldFonts.getFontNameBold(), fieldFonts.getFontName());
				fixedFontNameItalic = optimizeValue(fieldFonts.getFontNameItalic(), fieldFonts.getFontName());

				return createFontsForExecute(fontFace, fixedFontEncoding, fixedFontName, fixedFontNameBold, fixedFontNameItalic);
			}
		}

		return getBaseFont(fontFace);
	}

	/**
	 * 外部フォントが指定されているかどうか判定する.
	 *
	 * フィールドに対して指定されているかの判定結果を、<br>
	 * フィールドに指定されていなければ、スペーシングチャートに指定されているかの判定結果を返します。<br>
	 *
	 * @return 外部フォントが指定されている場合はtrue。それ以外はfalse。
	 * @create 2018/1/24
	 * @author hashimoto
	 * @since  2.3.3
	 */
	private boolean isUseFontFile(boolean useFontFile) {
		return needFontForField() ? useFontFile : Boolean.valueOf(getUseFontFile()).booleanValue();
	}

	/**
	 * フィールド用に個別に使用するフォントを作成する必要があるか判定する.
	 *
	 * @return 判定結果
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since  2.0.0
	 */
	private boolean needFontForField() {
		if (!isEmpty(fieldFonts.getFontEncoding())) {
			return true;
		}

		if (!isEmpty(fieldFonts.getFontName())) {
			return true;
		}

		if (!isEmpty(fieldFonts.getFontNameBold())) {
			return true;
		}

		if (!isEmpty(fieldFonts.getFontNameItalic())) {
			return true;
		}

		if (fieldFonts.isUseFontFile()) {
			return true;
		}

		return false;
	}

	/**
	 * 値が設定されていない場合にデフォルト値を適用する.
	 *
	 * @param value 値
	 * @param defaurtValue デフォルト値
	 * @return 最適化した値
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since 2.0.0
	 */
	private String optimizeValue(String value, String defaurtValue) {
		if (isEmpty(value)) {
			return defaurtValue;
		}
		return value;
	}

	/**
	 * 実際に出力する際に使用するフォントを作成する。
	 *
	 * @param fontFace フォントフェイス
	 * @param encoding エンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名ボールド
	 * @param fontNameItalic フォント名イタリック
	 * @return 実際に出力する際に使用するフォント
	 * @throws GReportException ReportFramework例外
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since 2.0.0
	 */
	private BaseFont createFontsForExecute(int fontFace, String encoding, String fontName, String fontNameBold, String fontNameItalic) throws GReportException {
		try {
			if (fontFace == IFieldInfo.FONT_FACE_BOLD) {
				return BaseFont.createFont(fontNameBold, encoding, BaseFont.NOT_EMBEDDED);
			}
			if (fontFace == IFieldInfo.FONT_FACE_ITALIC) {
				return BaseFont.createFont(fontNameItalic, encoding, BaseFont.NOT_EMBEDDED);
			}
			return BaseFont.createFont(fontName, encoding, BaseFont.NOT_EMBEDDED);
		} catch (IOException | DocumentException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】ドキュメントをクローズします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#close()
	 * @throws GReportException ReportFramework例外
	 * @create 2004/08/03
	 * @since 1.0.0
	 */
	@Override
	public void close() throws GReportException {
		try {
			if (_show_outline) {
				writeOutline(String.valueOf(++_grobal_page_count));
			}

			if (_on_load_print) {
				PdfAction jsAction = PdfAction.javaScript("this.print();", _pdf_writer);
				_pdf_writer.addJavaScript(jsAction);
			}

			if (_maxpage_template != null) {
				writeTemplateMaxPage();
			}

			printBuffString();

			_template_map.clear();

			_doc_pdf.close();

			if (_passwd != null) {
				createAuthFile();
			}
		} catch (DocumentException | IOException e) {
			throw new GReportException(e);
		} catch (RuntimeException e) {
			if (!e.getMessage().equals("The document has no pages.")) {	// データが書き込まれている場合は投げます⇒TODO 旧ｺｰﾄﾞのｺﾒﾝﾄに仕様が記載。ただし、現行ﾒﾝﾃをする上で、この仕様の意図が理解できないままです。
				throw new GReportException(e);
			}
		} finally {
			if (_doc_pdf != null) {
				_doc_pdf.close();
			}
			if (_pdf_writer != null) {
				_pdf_writer.close();
			}
		}
	}

	/**
	 * 帳票ファイル名に使用する拡張子を設定します.
	 *
	 * @param extension 拡張子
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since 2.0.0
	 */
	@Override
	public void setExtension(String extension) {
		this.extension = extension;
	}

	/**
	 * 帳票ファイル名に使用する拡張子を取得します.
	 *
	 * @return 拡張子
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since 2.0.0
	 */
	@Override
	public String getExtension() {
		return extension;
	}

	/**
	 * フォントファイル名にプロパティーで設定したパスを付与する。
	 *
	 * @param fontName フォントファイル名
	 * @return パスを付与したフォントファイル名
	 * @throws MissingResourceException プロパティーからパスを読めない
	 * @create 2014/11/21
	 * @author hashimoto
	 * @since 2.0.0
	 */
	private String appendPath(String fontName) throws MissingResourceException {
		return GFrameworkUtils.getProperty(FONT_DIRECTORY) + File.separator + fontName;
	}


	/**
	 * プレイスホルダの書き出しを実行するか判断します。
	 *
	 * @param template_name プレイスホルダ名
	 * @param value 書き出す値
	 * @return 判定結果 true:続行/false:中断
	 * @create 2015/2/2
	 * @author hashimoto
	 * @since 2.0.0
	 */
	private boolean discontinueToWriteTemplate(String template_name, String value) {

		if (isEmpty(value)) {
			return true;
		}

		if (template_name == null) {
			return true;
		}

		if (!_template_map.containsKey(template_name)) {
			return true;
		}

		return false;
	}

	/**
	 * アラインメントが右詰かどうか判断します.
	 *
	 * @param alignment アラインメント
	 * @return 判定結果 true:右詰/false:右詰でない
	 * @create 2015/02/02
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private boolean isRightAlignment(String alignment) {
		if (isEmpty(alignment)) {
			return false;
		}
		if (alignment.equals("right")) {
			return true;
		}
		return false;
	}

	/**
	 * アラインメントが中央寄かどうか判断します.
	 *
	 * @param alignment アラインメント
	 * @return 判定結果 true:中央寄/false:中央寄でない
	 * @create 2015/02/02
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private boolean isCenterAlignment(String alignment) {
		if (isEmpty(alignment)) {
			return false;
		}
		if (alignment.equals("center")) {
			return true;
		}
		return false;
	}

	/**
	 * 縦方向で印刷範囲外かどうか判定します.<br>
	 *
	 * @param top 上端
	 * @return 判定結果
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 * @since
	 */
	private boolean isOutOfRangeVertical(float top) {
		return (top < 0 || top >= _row_count);
	}

	/**
	 * 横方向で印刷範囲外かどうか判定します.<br>
	 *
	 * @param colIndex カラムインデックス
	 * @return 判定結果
	 * @create 2015/03/06
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private boolean isOutOfRangeHorizontal(float colIndex) {
		return (colIndex < 0 || colIndex >= _col_count);
	}

	/**
	 * 【機能】テンプレートにサークルを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeTemplateCircle(java.lang.String, float, float, float, float, double, int, int)
	 * @param template_name テンプレート名称
	 * @param startX 左
	 * @param startY 上
	 * @param height 高さ
	 * @param width 幅
	 * @param line_width 線幅
	 * @param type 線種
	 * @param true_circle 正円オプション
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeTemplateCircle(String template_name, float startX, float startY, float height, float width, double line_width, int type, int true_circle) throws GReportException {
		// v1.6.0 元々全く意図しない位置に出力される不具合がある為、要望が出るまで実装なしとする。
	}

	/**
	 * 【機能】テンプレートにラインを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeTemplateLine(java.lang.String, float, float, float, float, double, int, java.awt.Color)
	 * @param template_name テンプレート名称
	 * @param startX 左
	 * @param startY 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param color 色
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeTemplateLine(String template_name, float startX, float startY, float width, float height, double size, int type, Color color) throws GReportException {
		// v1.6.0 元々全く意図しない位置に出力される不具合がある為、要望が出るまで実装なしとする。

	}

	/**
	 * 【機能】テンプレートに四角形を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeTemplateRectangle(java.lang.String, float, float, float, float, double, int, int)
	 * @param template_name 】テンプレート名称
	 * @param startX 左
	 * @param startY 上
	 * @param width 幅
	 * @param height 高さ
	 * @param size サイズ
	 * @param type タイプ
	 * @param radius 角丸長方形の角の半径
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeTemplateRectangle(String template_name, float startX, float startY, float width, float height, double size, int type, int radius) throws GReportException {
		// v1.6.0 元々全く意図しない位置に出力される不具合がある為、要望が出るまで実装なしとする。
	}

	/**
	 * 文字列印刷情報を保持する.
	 *
	 * @create
	 * @author
	 * @since
	 */
	private interface WriteStringInfo {
		/**
		 *
		 * @throws GReportException ReportFramework例外
		 * @create
		 * @author
		 * @since
		 */
		public void write() throws GReportException;
	}

	/**
	 * グリッド上に印字する文字列の印刷情報を保持します。
	 *
	 * @create
	 * @author
	 * @since
	 */
	private class WriteStringInfoImp implements WriteStringInfo {

		/**  */
		public float iLeft;
		/**  */
		public float iTop;
		/**  */
		public String[] iValue;
		/**  */
		public int iZoom;
		/**  */
		public String iAlign;
		/**  */
		public float iWidth;
		/**  */
		public int iFont_face;
		/**  */
		public int iFont_height;
		/**  */
		public float iHeight;
		/**  */
		public Color iFore_color;
		/**  */
		public Color iBack_color;
		/**  */
		public IReportLine iUnder_line;
		/**  */
		public int iPositionAdjustmentX;
		/**  */
		public int iPositionAdjustmentY;
		/**  */
		public String iFontEncoding;
		/**  */
		public String iFontName;
		/**  */
		public String iFontNameBold;
		/**  */
		public String iFontNameItalic;
		/**  */
		public boolean iUseFontFile;

		/**
		 * コンストラクタ.
		 *
		 * @param left 左
		 * @param top 上
		 * @param value 値
		 * @param zoom 拡大率
		 * @param align アライメント
		 * @param width 幅
		 * @param font_face フォント名
		 * @param font_height フォント高さ
		 * @param height 高さ
		 * @param fore_color 前景色
		 * @param back_color 背景色
		 * @param under_line 下線
		 * @param positionAdjustmentX 横位置微調整
		 * @param positionAdjustmentY 縦位置微調整
		 * @param fontEncoding フォントエンコーディング
		 * @param fontName フォント名
		 * @param fontNameBold フォント名ボールド
		 * @param fontNameItalic フォント名イタリック
		 * @param useFontFile 外部フォントファイル使用有無
		 * @create
		 * @author
		 * @since
		 */
		public WriteStringInfoImp(float left, float top, String[] value, int zoom, String align, float width, int font_face, int font_height, float height, Color fore_color, Color back_color, IReportLine under_line, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) {
			iLeft = left;
			iTop = top;
			iValue = value;
			iZoom = zoom;
			iAlign = align;
			iWidth = width;
			iFont_face = font_face;
			iFont_height = font_height;
			iHeight = height;
			iFore_color = fore_color;
			iBack_color = back_color;
			iUnder_line = under_line;
			iPositionAdjustmentX = positionAdjustmentX;
			iPositionAdjustmentY = positionAdjustmentY;
			iFontEncoding = fontEncoding;
			iFontName = fontName;
			iFontNameBold = fontNameBold;
			iFontNameItalic = fontNameItalic;
			iUseFontFile = useFontFile;
		}

		@Override
		public void write() throws GReportException {
			writeString(iLeft, iTop, iValue, iZoom, iAlign, iWidth, iFont_face, iFont_height, iHeight, iFore_color, iBack_color, iUnder_line, iPositionAdjustmentX, iPositionAdjustmentY, iFontEncoding, iFontName, iFontNameBold, iFontNameItalic, iUseFontFile, true);
		}
	}

	/**
	 * グリッドを無視する文字列の印刷情報を保持します。
	 *
	 * @create
	 * @author
	 * @since
	 */
	private class WriteNonGridStringInfoImp implements WriteStringInfo {

		/** 左 */
		public float iLeft;
		/** 上 */
		public float iTop;
		/** 値 */
		public String[] iValue;
		/** 拡大率 */
		public int iZoom;
		/** アライメント */
		public String iAlign;
		/** 幅 */
		public float iWidth;
		/** フォントフェイス */
		public int iFont_face;
		/** サイズ */
		public int iSize;
		/** 文字間隔 */
		public int iInterval;
		/** フォント高さ */
		public int iFont_height;
		/** 高さ */
		public float iHeight;
		/** 前景色 */
		public Color iFore_color;
		/** 背景色 */
		public Color iBack_color;
		/** 下線 */
		public IReportLine iUnder_line;
		/** 横位置微調整 */
		public int iPositionAdjustmentX;
		/** 縦位置微調整 */
		public int iPositionAdjustmentY;
		/** エンコーディング */
		public String iFontEncoding;
		/** フォント名 */
		public String iFontName;
		/** フォント名ボールド */
		public String iFontNameBold;
		/** フォント名イタリック */
		public String iFontNameItalic;
		/** 外部フォントファイル使用有無 */
		public boolean iUseFontFile;

		/**
		 * コンストラクタ.
		 *
		 * @param left 左
		 * @param top 上
		 * @param value 値
		 * @param zoom 拡大率
		 * @param align アライメント
		 * @param width 幅
		 * @param font_face フォントフェイス
		 * @param size サイズ
		 * @param interval 文字間隔
		 * @param font_height フォント高さ
		 * @param height 高さ
		 * @param fore_color 前景色
		 * @param back_color 背景色
		 * @param under_line 下線
		 * @param positionAdjustmentX 横位置微調整
		 * @param positionAdjustmentY 縦位置微調整
		 * @param fontEncoding エンコーディング
		 * @param fontName フォント名
		 * @param fontNameBold フォント名ボールド
		 * @param fontNameItalic フォント名イタリック
		 * @param useFontFile 外部フォントファイル使用有無
		 * @create
		 * @author
		 * @since
		 */
		public WriteNonGridStringInfoImp(float left, float top, String[] value, int zoom, String align, float width, int font_face, int size, int interval, int font_height, float height, Color fore_color, Color back_color, IReportLine under_line, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile)
		{
			iLeft = left;
			iTop = top;
			iValue = value;
			iZoom = zoom;
			iAlign = align;
			iWidth = width;
			iFont_face = font_face;
			iSize = size;
			iInterval = interval;
			iFont_height = font_height;
			iHeight = height;
			iFore_color = fore_color;
			iBack_color = back_color;
			iUnder_line = under_line;
			iPositionAdjustmentX = positionAdjustmentX;
			iPositionAdjustmentY = positionAdjustmentY;
			iFontEncoding = fontEncoding;
			iFontName = fontName;
			iFontNameBold = fontNameBold;
			iFontNameItalic = fontNameItalic;
			iUseFontFile = useFontFile;
		}

		@Override
		public void write() throws GReportException {
			writeNonGridString(iLeft, iTop, iValue, iZoom, iAlign, iWidth, iFont_face, iSize, iInterval, iFont_height, iHeight, iFore_color, iBack_color, iUnder_line, iPositionAdjustmentX, iPositionAdjustmentY, iFontEncoding, iFontName, iFontNameBold, iFontNameItalic, iUseFontFile, true);
		}
	}

	/**
	 * 【機能】テンプレートを初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportWriter#clearTemlate(java.lang.String)
	 * @param template_name テンプレート名称
	 */
	@Override
	public void clearTemplate(String template_name) {
		_template_map.remove(template_name);
	}

	/**
	 * フィールド用のフォントクラス.
	 *
	 * @create 2014/12/19
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private class FieldFonts {

		/** エンコーディング */
		private String fontEncoding;
		/** フォント名 */
		private String fontName;
		/** フォント名（ボールド） */
		private String fontNameBolc;
		/** フォント名（イタリック） */
		private String fontNameItalic;
		/** フォントファイル使用有無 */
		private boolean useFontFile;

		/**
		 * コンストラクタ.
		 *
		 * @param fontEncoding エンコーディング
		 * @param fontName フォント名
		 * @param fontNameBold フォント名（ボールド）
		 * @param fontNameItalic フォント名（イタリック）
		 * @param useFontFile フォントファイル使用有無
		 * @create 2014/12/19
		 * @author KCCS hashimoto
		 * @since 2.0.0
		 */
		public FieldFonts(String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) {
			this.fontEncoding = fontEncoding;
			this.fontName = fontName;
			this.fontNameBolc = fontNameBold;
			this.fontNameItalic = fontNameItalic;
			this.useFontFile = useFontFile;
		}

		/**
		 * エンコーディングを取得します.
		 *
		 * @return エンコーディング
		 * @create 2014/12/19
		 * @author KCCS hashimoto
		 * @since 2.0.0
		 */
		public String getFontEncoding() {
			return fontEncoding;
		}

		/**
		 * フォント名を取得します.
		 *
		 * @return フォント名
		 * @create 2014/12/19
		 * @author KCCS hashimoto
		 * @since 2.0.0
		 */
		public String getFontName() {
			return fontName;
		}

		/**
		 * フォント名（ボールド）を取得します.
		 *
		 * @return フォント名（ボールド）
		 * @create 2014/12/19
		 * @author KCCS hashimoto
		 * @since 2.0.0
		 */
		public String getFontNameBold() {
			return fontNameBolc;
		}

		/**
		 * フォント名（イタリック）を取得します.
		 *
		 * @return フォント名（イタリック）
		 * @create 2014/12/19
		 * @author KCCS hashimoto
		 * @since 2.0.0
		 */
		public String getFontNameItalic() {
			return fontNameItalic;
		}

		/**
		 * フォントファイル使用有無を取得します.
		 *
		 * @return フォントファイル使用有無
		 * @create 2014/12/19
		 * @author KCCS hashimoto
		 * @since 2.0.0
		 */
		public boolean isUseFontFile() {
			return useFontFile;
		}
	}

	/**
	 * イメージインスタンスを取得します.
	 *
	 * @param source ソースのパス
	 * @return イメージインスタンス
	 * @throws GReportException 帳票フレームワーク例外
	 * @create 2015/03/13
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private Image getImageInstance(String source) throws GReportException {
		try {
			return Image.getInstance(source);
		} catch (BadElementException | IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * イメージインスタンスを取得します.
	 *
	 * @param img イメージ
	 * @return イメージインスタンス
	 * @throws GReportException 帳票フレームワーク例外
	 * @create 2015/03/13
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private Image getImageInstance(java.awt.Image img) throws GReportException {
		try {
			return Image.getInstance(img, Color.black);
		} catch (BadElementException | IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * エンコードを変換します。
	 *
	 * itextの仕様変更に伴い、UniJIS-UCS2-XXをUniJIS-UTF16に変換します。
	 *
	 * @create 2016/02/12
	 * @since 1.9.1
	 */
	protected String convertFontEncoding(String fontEncoding) {
		if (isEmpty(fontEncoding) || "UniJIS-UCS2-H".equals(fontEncoding) || "UniJIS-UCS2-HW-H".equals(fontEncoding)) {
			return DEFAURT_FONT_ENCODING;
		} else if  ("UniJIS-UCS2-V".equals(fontEncoding) || "UniJIS-UCS2-HW-V".equals(fontEncoding)) {
			return "UniJIS-UTF16-V";
		}
		return fontEncoding;
	}
}
