/*
 * Copyright 2014-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.driver;

import static jp.co.kccs.greenearth.commons.utils.GStringUtils.*;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReportLine;
import jp.co.kccs.greenearth.report.IReportWriter;
import jp.co.kccs.greenearth.report.repository.IBarcodeInfo;
import jp.co.kccs.greenearth.report.repository.ILineDashInfo;

/**
 * 【役割】テキストドライバを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2006/03/19
 * @author takaishi
 * @since 1.1.0
 */
public class GTextReportDriver implements IReportWriter {

	/** スタートページ */
	private final int START_PAGE = 1;
	/** 縦方向行数 */
	private int _row_count = 0;
	/** 横方向行数 */
	private int _col_count = 0;

	/** 文字コード */
	private String SPACE = "\u0020";
	/** Unicodeのアスタリスク */
	private final String ASTERISK = "\u002a";
	/** スペースのサイズ */
	private int _space_size = 0;
	/** 最大ページ数 */
	private int maxPageCount = 0;

	/** デバッグフラグ */
	private static boolean isDebug = false;

	/** 改行コード */
	private byte[] newLineCharBytes = null;
	/** 改ページコード */
	private byte[] newPageCharBytes = null;
	/** 出力ファイルの文字コード */
	private String characterCode = null;
	/** プレースホルダ利用フラグ */
	private boolean _use_field_placeholder = false;

	/** プレイスホルダを使用しない帳票の場合に使用する */
	private FileOutputStream sequentialAccessFile = null;
	/** プレイスホルダを使用する帳票の場合に使用する */
	private RandomAccessFile randomAccessFile = null;
	/** ファイルのlength */
	private int contentsTotalLengthInFile = -1;

	/** ページバッファ管理 ページ上のフィールドの一覧。要素数は _row_count * _row_count */
	private String[][] pageBuffer = null;

	/** BOM */
	private byte[] _bom = null;

	/** CRの正規表現 */
	private final String REGULAR_EXP_CR = "\r";
	/** LFの正規表現 */
	private final String REGULAR_EXP_LF = "\n";
	/** FFの正規表現 */
	private final String REGULAR_EXP_FF = "\f";
	/** ページバッファに１行も存在しないことを表す */
	private final int NO_LOWS_IN_PAGE_BUFFER = -1;
	
	/** 帳票のデフォルト拡張子 */
	private String extension = ".txt";

	/**
	 * カレントページ上のプレースホルダ管理表<BR>
	 *  キー：プレースホルダ名、値：同名プレースホルダの一覧<BR>
	 */
	private HashMap<String, List<PlaceHolder>> placeHoldersMap = null;
	/** プレースホルダ管理表のキー（プレースホルダ名）一覧 */
	private String[][] placeHolderNameKeys = null;

	/** 最大ページ用プレースホルダの情報 */
	private String MAXPAGE = "jp.co.kccs.greenearth.report.driver.TextReportDriver.MaxPage";
	/** 最大ページ用フォーマット */
	private String _max_page_format = null;
	/** 最大ページ用幅 */
	private float _max_page_width = 0;
	/** 最大ページ用アライン */
	private String _max_page_align = "right";

	/**
	 * 【役割】1つのプレースホルダを表します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 * 
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	private class PlaceHolder {
		/** 上位置 */
		public int top = -1;
		/** 左位置 */
		public int left = -1;
		/** ファイルオフセット位置 */
		public int offset = -1;
		/** ページバッファ上に存在するか */
		public boolean on_memory = true;
	}

	/**
	 * 【機能】テキストドライバ固有のパラメータを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】プレースホルダ出力フラグにfalseを指定すると、出力ファイルはシーケンシャルアクセスとなり、高速出力されます。<BR>
	 * 
	 * @param newLine 改行コード
	 * @param newPage 改ページコード
	 * @param characterCode 出力の文字コード
	 * @param usePlaceholderFlag プレースホルダ出力フラグ
	 * @param bom BOM
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.6.0
	 */
	public void setParameter(String newLine, String newPage, String characterCode, boolean usePlaceholderFlag, byte[] bom) throws GReportException {
		_bom = bom;
		setParameter(newLine, newPage, characterCode, usePlaceholderFlag);
	}

	/**
	 * 【機能】テキストドライバ固有のパラメータを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】プレースホルダ出力フラグにfalseを指定すると、出力ファイルはシーケンシャルアクセスとなり、高速出力されます。<BR>
	 * 
	 * @param newLine 改行コード
	 * @param newPage 改ページコード
	 * @param characterCode 出力の文字コード
	 * @param usePlaceholderFlag プレースホルダ出力フラグ
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	public void setParameter(String newLine, String newPage, String characterCode, boolean usePlaceholderFlag) throws GReportException {
	
		emptyCheckForParams(newLine, newPage, characterCode);
		
		if (isDebug()) {
			SPACE = ASTERISK;
		}

		this.characterCode = characterCode;
		this.newLineCharBytes = convertNewLineCharToBytes(newLine);
		this.newPageCharBytes = convertNewPageCharToBytes(newPage);
		this._use_field_placeholder = usePlaceholderFlag;
		setBytesSizeOfSpace();
	}
	
	/**
	 * 各引数がEmptyであるか判定します。<BR>
	 * Emptyの場合例外をスローします。<BR>
	 * 
	 * @param newLine 改行コード
	 * @param newPage 改ページコード
	 * @param characterCode 出力の文字コード
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void emptyCheckForParams(String newLine, String newPage, String characterCode) {
		if (isEmpty(newLine)) {
			throw new GReportRuntimeException("A newline character is null or empty.");
		}
		if (isEmpty(newPage)) {
			throw new GReportRuntimeException("A newpage character is null or empty.");
		}
		if (isEmpty(characterCode)) {
			throw new GReportRuntimeException("A characterCode is null or empty.");
		}
		
	}
	
	/**
	 * 改行コードをバイト配列に変換します。<BR>
	 * 
	 * @param newLineChar 改行コード
	 * @return 改行コードのバイト配列
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private byte[] convertNewLineCharToBytes(String newLineChar) throws GReportException {
		try {
			if (newLineChar.equals("CR")) {
				return REGULAR_EXP_CR.getBytes(getCharacterCode());
			} 
			if (newLineChar.equals("LF")) {
				return REGULAR_EXP_LF.getBytes(getCharacterCode());
			}
			if (newLineChar.equals("CRLF")) {
				return (REGULAR_EXP_CR + REGULAR_EXP_LF).getBytes(getCharacterCode());
			}

			throw new IllegalArgumentException("unsupported value of new_line : " + newLineChar);

		} catch (UnsupportedEncodingException e) {
			throw new GReportException(e);
		}
	}
	
	/**
	 * 改ページコードをバイト配列に変換します。<BR>
	 * 
	 * @param newPageChar 改ページコード
	 * @return 改行コードのバイト配列
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private byte[] convertNewPageCharToBytes(String newPageChar) throws GReportException {
		try {
			if (newPageChar.equals("FF")) {
				return REGULAR_EXP_FF.getBytes(getCharacterCode());
			} 
			
			if (newPageChar.equals("CRFF") && isDebug()) {
				return ("(改頁)" + REGULAR_EXP_CR + REGULAR_EXP_LF).getBytes(getCharacterCode());
			} else if (newPageChar.equals("CRFF")) {
				return (REGULAR_EXP_CR + REGULAR_EXP_FF).getBytes(getCharacterCode());
			}

			throw new IllegalArgumentException("unsupported value of new_page : " + newPageChar);

		} catch (UnsupportedEncodingException e) {
			throw new GReportException(e);
		}
	}
	
	/**
	 * スペースのバイトサイズを設定する。<BR>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void setBytesSizeOfSpace() throws GReportException {
		try {
			_space_size = SPACE.getBytes(getCharacterCode()).length;
		} catch (UnsupportedEncodingException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】ドキュメントをオープンします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#open(java.lang.String)
	 * @param path ファイルのパス
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void open(final String path) throws GReportException {
		maxPageCount = START_PAGE;
		initialize();
		deleteAlreadyExistFile(path);
		createFile(path);
		writeBOM();
	}

	/**
	 * 【機能】ドキュメントをオープンせずに初期化を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#initialize()
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void initialize() {
		if (pageBuffer != null) {
			clearPageBuffer();
		}
		placeHoldersMap = null;
	}

	/**
	 * 既に存在するファイルを削除します。<BR>
	 * 
	 * @param path ファイルのパス
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void deleteAlreadyExistFile(String path) {
		File file = new File(path);
		if (file.exists()) {
			file.delete();
		}
	}
	
	/**
	 * ファイルを作成します。<BR>
	 * 
	 * @param path ファイルのパス
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void createFile(String path) throws GReportException {
		try {
			if (_use_field_placeholder) {
				randomAccessFile = new RandomAccessFile(path, "rw");
			} else {
				sequentialAccessFile = new FileOutputStream(path, false);
			}
		} catch (FileNotFoundException e) {
			throw new GReportException(e);
		}
		contentsTotalLengthInFile = (int) new File(path).length();
	}

	/**
	 * BOMを書き出します。<BR>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void writeBOM() throws GReportException {
		
		if (_bom == null) {
			return;
		}

		try {
			executeWrite(_bom);
		} catch (IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】列数と行数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setColumnAndRow(int, int)
	 * @param col_count カラム数
	 * @param row_count 行数
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void setColumnAndRow(int col_count, int row_count) {
		_row_count = row_count;
		_col_count = col_count;
		pageBuffer = new String[_row_count][_col_count];
		placeHolderNameKeys = new String[_row_count][_col_count];
	}

	/**
	 * 【機能】最大ページカウントを書き込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】内部的にはこの段階では書き込みません。<BR>
	 * resetPageCount()が呼び出された時、またはドキュメントを閉じる時に自動的に書き込まれます。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setMaxPageTemplate(float, float, int, java.lang.String, float, float, int, java.lang.String, int, int, int)
	 * @param left 左
	 * @param top 上
	 * @param size サイズ
	 * @param align アラインメント
	 * @param width 幅
	 * @param height 高さ
	 * @param font_face フォントフェイス
	 * @param format フォーマット
	 * @param font_size フォントサイズ
	 * @param font_interval フォント間隔
	 * @param font_height フォント高さ
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void setTemplateMaxPage(float left, float top, int size, String align, float width, float height, int font_face, String format, int font_size, int font_interval, int font_height) throws GReportException {
		_max_page_format = format;
		_max_page_align = align;
		_max_page_width = width;
		setTemplateSection(MAXPAGE, left, top, width, height);
	}

	/**
	 * 【機能】プレイスホルダを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setTemplate(java.lang.String, float, float, int, java.lang.String, float, float)
	 * @param template_name プレイスホルダ名称
	 * @param left 左
	 * @param top 上
	 * @param zoom ズーム
	 * @param align アラインメント
	 * @param width 幅
	 * @param height 高さ
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void setTemplateField(String template_name, float left, float top, int zoom, String align, float width, float height) {
		setTemplateSection(template_name, left, top, width, height);
	}

	/**
	 * 【機能】プレイスホルダを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】セクションプレイスホルダ用です。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setTemplate(java.lang.String, float, float, float, float)
	 * @param placeHolderName プレイスホルダ名
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void setTemplateSection(String placeHolderName, float left, float top, float width, float height) {
		PlaceHolder newPlaceHolder = createPlaceHolder(left, top, width, height);
		List<PlaceHolder> sameNameList = getSameNamePlaceHolders(placeHolderName);
		sameNameList.add(newPlaceHolder);
		setSameNamePlaceHolders(left, top, placeHolderName, sameNameList);
		setSpaceToPageBuffer(left, top, width);
	}
	
	/**
	 * プレイスホルダを生成します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @param height 高さ
	 * @return プレイスホルダ
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private PlaceHolder createPlaceHolder(float left, float top, float width, float height) {
		PlaceHolder newPlaceHolder = new PlaceHolder();
		newPlaceHolder.top = (int) top;
		newPlaceHolder.left = (int) left;
		newPlaceHolder.offset = -1;
		newPlaceHolder.on_memory = true;
		return newPlaceHolder;
	}
	
	/**
	 * 同じ名前のプレイスホルダを取得します。<BR>
	 * 
	 * @param name プレイスホルダ名
	 * @return プレイスホルダのリスト
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private List<PlaceHolder> getSameNamePlaceHolders(String name) {
		if (placeHoldersMap == null) {
			placeHoldersMap = new HashMap<String, List<PlaceHolder>>();
		}
		List<PlaceHolder> placeHolder = placeHoldersMap.get(name);
		if (placeHolder == null) {
			placeHolder = new ArrayList<PlaceHolder>();
		}
		return placeHolder;
	}

	/**
	 * 同じ名前のプレイスホルダを設定します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param placeHolderName プレイスホルダ名
	 * @param sameNameList 同じ名前のプレイスホルダのリスト
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void setSameNamePlaceHolders(float left, float top,
			String placeHolderName, List<PlaceHolder> sameNameList) {
		placeHoldersMap.put(placeHolderName, sameNameList);
		placeHolderNameKeys[(int) top][(int) left] = placeHolderName;
	}
	
	/**
	 * ページバッファにスペースを出力します。<BR>
	 * 
	 * @param left 左
	 * @param top 上
	 * @param width 幅
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void setSpaceToPageBuffer(float left, float top, float width) {
		StringBuilder spaces = new StringBuilder();
		for (int i = 0; i < width; i++) {
			spaces.append(SPACE);
		}
		pageBuffer[(int) top][(int) left] = spaces.toString();
	}

	/**
	 * 【機能】最大ページ数をテンプレートに印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeMaxPageTemplate()
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void writeTemplateMaxPage() throws GReportException {
		writeTemplate(MAXPAGE, -1, -1, getFormatedMaxPageString(), -1, _max_page_align, _max_page_width, -1, -1, 0, 0, null, null, null, null, false);
	}

	/**
	 * 最大ページの文字列をフォーマットします。<BR>
	 * 
	 * @return フォーマットされた最大ページの文字列
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private String getFormatedMaxPageString() {
		if (_max_page_format == null) {
			return String.valueOf(maxPageCount);
		} 
		
		DecimalFormat df = new DecimalFormat(_max_page_format);
		return df.format(maxPageCount);		
	}

	@Override
	public void writeTemplateNonGrid(String placeHolderName, float left, float top, String value, int zoom, String align, float width, int fontFace, int fontSize, int interval, int fontHeight, float height, Color backColor, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException {
		writeTemplate(placeHolderName, left, top, value, 0, align, width, fontFace, (int) height, positionAdjustmentX, positionAdjustmentY, fontEncoding, fontName, fontNameBold, fontNameItalic, useFontFile);
	}

	/**
	 * 【機能】プレイスホルダを印刷します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeTemplate(java.lang.String, float, float, java.lang.String, int, java.lang.String, float, int, float, int, int)
	 * @param placeHolderName プレイスホルダ名称
	 * @param left 左
	 * @param top 上
	 * @param data データ
	 * @param size サイズ
	 * @param align アラインメント
	 * @param fieldWidth 幅
	 * @param fontFace フォントフェイス
	 * @param height 高さ
	 * @param positionAdjustmentX 横位置微調整
	 * @param positionAdjustmentY 縦位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void writeTemplate(String placeHolderName, float left, float top, String data, int size, String align, float fieldWidth, int fontFace, int height, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException {

		if (placeHoldersMap == null) {
			return;
		}
		
		if (!_use_field_placeholder) {
			clearTemplate(placeHolderName);
			return;
		}
		
		// 名前指定でプレースホルダ情報を取得
		List<PlaceHolder> placeHolderList = placeHoldersMap.get(placeHolderName);
		if (placeHolderList == null) {
			return;
		}

		try {
			for (PlaceHolder placeHolder : placeHolderList) {
				String alignedString = getAlignedString(data, align, (int) fieldWidth);

				if (placeHolder.on_memory) {
					pageBuffer[placeHolder.top][placeHolder.left] = alignedString;
				} else {
					if (randomAccessFile != null) {
						randomAccessFile.seek(placeHolder.offset);
						randomAccessFile.write(alignedString.getBytes(getCharacterCode()));
					}
				}
			}
			randomAccessFile.seek(contentsTotalLengthInFile);
		} catch (IOException ioe) {
			throw new GReportException(ioe);
		}

		/*
		 * PDFドライバの仕様に合わせ、書き込んだらテンプレートの登録を解除する
		 */
		clearTemplate(placeHolderName);

	}

	/**
	 * 【機能】テンプレートをクリアします。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#clearTemplate(java.lang.String)
	 * @param placeHolderName プレイスホルダ名
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void clearTemplate(String placeHolderName) {

		if (placeHoldersMap == null) {
			return;
		}

		List<PlaceHolder> sameNamePlaceHolderList = placeHoldersMap.get(placeHolderName);
		if (sameNamePlaceHolderList == null) {
			return;
		}

		placeHoldersMap.remove(placeHolderName);

		// カレントページ上のプレースホルダ解除
		String placeHolderNameKey = null;
		for (int i = 0; i < _row_count; i++) {
			for (int j = 0; j < _col_count; j++) {
				placeHolderNameKey = placeHolderNameKeys[i][j];
				if (placeHolderNameKey != null && placeHolderNameKey.equals(placeHolderName)) {
					placeHolderNameKeys[i][j] = null;
				}
			}
		}
	}

	@Override
	public void writeNonGridString(float left, float top, String[] data, int zoom, String align, float field_width, int font_face, int size, int interval, int font_height, float height, Color fore_color, Color back_color, IReportLine under_line, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException {
		writeString(left, top, data, zoom, align, field_width, font_face, font_height, height, fore_color, back_color, under_line, positionAdjustmentX, positionAdjustmentY, fontEncoding, fontName, fontNameBold, fontNameItalic, useFontFile);
	}

	/**
	 * 【機能】複数行の文字列を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】テキストドライバでは、1行目のみが出力されます。<BR>
	 *      ここではバッファに書き込むだけです。<BR>
	 *      
	 * @see jp.co.kccs.greenearth.report.IReportWriter#writeString(float, float, java.lang.String[], int, java.lang.String, float, int, int, float, java.awt.Color, java.awt.Color, jp.co.kccs.greenearth.report.IReportLine, int, int)
	 * @param left 左
	 * @param top 上
	 * @param data データ
	 * @param zoom 拡大率
	 * @param align アライメント
	 * @param field_width 幅
	 * @param font_face フォントフェイス
	 * @param font_height フォント高さ
	 * @param height 高さ
	 * @param fore_color 前景色
	 * @param back_color 背景色
	 * @param under_line 下線
	 * @param positionAdjustmentX 縦位置微調整
	 * @param positionAdjustmentY 横位置微調整
	 * @param fontEncoding フォントエンコーディング
	 * @param fontName フォント名
	 * @param fontNameBold フォント名（ボールド）
	 * @param fontNameItalic フォント名（イタリック）
	 * @param useFontFile 外部フォントファイル利用有無
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void writeString(float left, float top, String[] data, int zoom, String align, float field_width, int font_face, int font_height, float height,  Color fore_color, Color back_color, IReportLine under_line, int positionAdjustmentX, int positionAdjustmentY, String fontEncoding, String fontName, String fontNameBold, String fontNameItalic, boolean useFontFile) throws GReportException {
		pageBuffer[(int) top][(int) left] = getAlignedString(data[0], align, (int) field_width);
	}


	/**
	 * 【機能】アライメント調整されたフィールド値を取得します<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param str 文字列
	 * @param align アライメント
	 * @param field_width フィールド幅
	 * @return アライメント調整されたフィールド値
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	private String getAlignedString(String str, String align, int field_width) {
		StringBuilder alignedString = new StringBuilder();
		int diff = (int) field_width - GDriverUtils.getCharCountByHalfWidth(str);
		if (diff <= 0 || align.equals("left")) {
			alignedString.append(str);
		} else {
			if (align.equals("center")) {
				diff /= 2;
			}
			for (int i = 0; i < diff; i++) {
				alignedString.append(SPACE);
			}
			alignedString.append(str);
		}
		return alignedString.toString();
	}

	/**
	 * 【機能】ページブレイク（改ページ）を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#pageBreak()
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void pageBreak() throws GReportException {
		flushPageBuffer();
		clearPageBuffer();
		maxPageCount++;
	}

	/**
	 * 【機能】ドキュメントをクローズします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#close()
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void close() throws GReportException {
		if (noNeedToClose()) {
			return;
		}

		flushPageBuffer();
		writeTemplateMaxPage();
		closeFile();
	}
	
	/**
	 * ファイルをクローズする必要がないか判定します。<BR>
	 * 
	 * @return 判定結果
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private boolean noNeedToClose() {
		return (_use_field_placeholder && randomAccessFile == null)
				|| (!_use_field_placeholder && sequentialAccessFile == null);
	}
	
	/**
	 * ファイルをクローズします。<BR>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void closeFile() throws GReportException {
		try {
			if (_use_field_placeholder) {
				randomAccessFile.close();
				randomAccessFile = null;
			} else {
				sequentialAccessFile.close();
				sequentialAccessFile = null;
			}
		} catch (IOException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】ページバッファの内容をファイルに書き込みます<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	private void flushPageBuffer() throws GReportException {

		int maxLowInPageBuffer = countLowsInPageBuffer();

		try {
			for (int row = 0; row <= maxLowInPageBuffer; row++) {
				updatePlaceHolderMap(pageBuffer[row], row);
				String line = createLineBuffer(pageBuffer[row]);
				executeWrite(line.getBytes(getCharacterCode()));
				if (row < maxLowInPageBuffer) {
					executeWrite(getNewLineCharacter());
				}
			}

			if (maxLowInPageBuffer != NO_LOWS_IN_PAGE_BUFFER) {
				executeWrite(getNewPageCharacter());
			}

		} catch (IOException e) {
			throw new GReportException(e);
		}
	}
	
	/**
	 * ページバッファ中の行数を取得します。<BR>
	 * 
	 * @return 行数
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private int countLowsInPageBuffer() {
		int maxLowNumber = NO_LOWS_IN_PAGE_BUFFER;
		String[] fields = null;

		for (int row = 0; row < _row_count; row++) {
			fields = pageBuffer[row];
			for (int column = 0; column < _col_count; column++) {
				if (fields[column] != null) {
					maxLowNumber = row;
					break;
				}
			}
		}
		
		return maxLowNumber;
	}

	/**
	 * 【機能】プレースホルダ管理テーブルの更新をおこないます<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param fields フィールドの配列
	 * @param row_count 行数
	 * @throws UnsupportedEncodingException サポート外のエンコーディング例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	private void updatePlaceHolderMap(String[] fields, int row_count) throws UnsupportedEncodingException {

		int offset = 0;
		int charCountByHalfWidth = 0;

		for (int i = 0; i < fields.length; i++) {
			if (!isEmpty(fields[i])) {

				charCountByHalfWidth += GDriverUtils.getCharCountByHalfWidth(fields[i]);

				String placeHolderName = placeHolderNameKeys[row_count][i];
				
				if (placeHolderName != null) {

					List<PlaceHolder> placeHolderList = placeHoldersMap.get(placeHolderName);
					if (placeHolderList == null) {
						continue;
					}

					for (PlaceHolder placeHolder : placeHolderList) {
						if (placeHolder.on_memory && placeHolder.top == row_count) {
							placeHolder.top = -1;
							placeHolder.left = -1;
							placeHolder.offset = contentsTotalLengthInFile + offset;
							placeHolder.on_memory = false;
						}
					}
				}

				offset += fields[i].getBytes(getCharacterCode()).length;
				
			} else {

				if (charCountByHalfWidth <= i) {
					offset += _space_size;
					charCountByHalfWidth += 1;
				}
			}
		}
	}

	/**
	 * 【機能】ファイル書き込み用の行バッファ文字列を取得します<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param fields フィールドの配列
	 * @return 行バッファ文字列
	 * @throws UnsupportedEncodingException サポート外のエンコーディング例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	private String createLineBuffer(String[] fields) throws UnsupportedEncodingException {

		int lastFieldIndex = getIndexOfLastField(fields);

		int writtenCount = 0;
		StringBuilder lineBuffer = new StringBuilder();
		
		for (int index = 0; index <= lastFieldIndex; index++) {
			
			if (isEmpty(fields[index])) {
				if (writtenCount <= index) {
					lineBuffer.append(SPACE);
					writtenCount += 1;
				}
			} else {
				lineBuffer.append(fields[index]);
				writtenCount += GDriverUtils.getCharCountByHalfWidth(fields[index]);
			}
		}

		return lineBuffer.toString();
	}
	
	/**
	 * 最後のフィールドのインデックスを取得します。<BR>
	 * 
	 * @param fields フィールドの配列
	 * @return インデックス
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private int getIndexOfLastField(String[] fields) {
		
		int lastFieldIndex = -1;

		for (int index = 0; index < fields.length; index++) {
			if (fields[index] != null) {
				lastFieldIndex = index;
			}
		}

		return lastFieldIndex;
	}
	
	/**
	 * バイト配列を書き出します。<BR>
	 * 
	 * @param raw_line バイト配列
	 * @throws IOException ファイル書き出しの例外
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private void executeWrite(byte[] raw_line) throws IOException {
		if (_use_field_placeholder) {
			randomAccessFile.write(raw_line);
		} else {
			sequentialAccessFile.write(raw_line);
		}
		
		contentsTotalLengthInFile += raw_line.length;
	}

	/**
	 * 【機能】ページカウントをリセットします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】最大ページカウントにも影響します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#resetPageCount()
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void resetPageCount() throws GReportException {
		setPageCount(0);
	}

	/**
	 * 【機能】ページバッファのクリアを行います<BR>
	 * 【呼出】API<BR>
	 * 【備考】
	 * 
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	private void clearPageBuffer() {
		for (int row = 0; row < _row_count; row++) {
			for (int column = 0; column < _col_count; column++) {
				pageBuffer[row][column] = null;
				placeHolderNameKeys[row][column] = null;
			}
		}
	}

	/**
	 * 【機能】ページ数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return ページ数
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	public int getPageCount() {
		return maxPageCount;
	}

	/**
	 * 【機能】ページ数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setPageCount(int)
	 * @param count ページ数
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public void setPageCount(int count) {
		try {
			writeTemplateMaxPage();
		} catch (GReportException e) {
			throw new GReportRuntimeException(e);
		}
		maxPageCount = count;
	}

	/**
	 * 【機能】最大行数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getRowCount()
	 * @return 最大行数
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public final int getRowCount() {
		return _row_count;
	}

	/**
	 * 【機能】最大幅数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getColumnCount()
	 * @return 最大幅数
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public final int getColumnCount() {
		return _col_count;
	}

	/**
	 * 【機能】1グリッドの幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】テキストドライバではサポートされません。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getGridWidth()
	 * @return 常に0を返します
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	@Override
	public float getGridWidth() {
		return 0;
	}

	/**
	 * 【機能】1グリッドの高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】テキストドライバではサポートされません。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getGridHeight()
	 * @return 常に0を返します
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	@Override
	public float getGridHeight() {
		return 0;
	}

	/**
	 * 【機能】デバッグフラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setDebug(boolean)
	 * @param is_debug デバッグフラグ
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	@Override
	public final void setDebug(boolean is_debug) {
		isDebug = is_debug;
	}

	/**
	 * 【機能】デバッグモードかの判断です。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return デバッグモードフラグ
	 * @create 2006/03/27
	 * @author takaishi
	 * @since 1.1.0
	 */
	private final boolean isDebug() {
		return isDebug;
	}
	
	/**
	 * 帳票ファイル名に使用する拡張子を設定します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#setExtension(java.lang.String)
	 * @param extension 拡張子
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	@Override
	public void setExtension(String extension) {
		this.extension = extension;
	}
	
	/**
	 * 帳票ファイル名に使用する拡張子を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportWriter#getExtension()
	 * @return 拡張子
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	@Override
	public String getExtension() {
		return this.extension;
	}
	
	/**
	 * 文字コードのバイト配列を取得する。<BR>
	 * 
	 * @return 文字コードのバイト配列
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private String getCharacterCode() {
		if (isEmpty(characterCode)) {
			throw new GReportRuntimeException("A characterCode is null or empty.");
		}
		return characterCode;
	}
	
	
	/**
	 * 改行コードのバイト配列を取得する。<BR>
	 * 
	 * @return 改行コードのバイト配列
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private byte[] getNewLineCharacter() {
		if (newLineCharBytes == null || newLineCharBytes.length == 0) {
			throw new GReportRuntimeException("A newLineCharacter is null or empty.");
		}
		return newLineCharBytes;
	}
	
	/**
	 * 改ページコードのバイト配列を取得する。<BR>
	 * 
	 * @return 改ページコードのバイト配列
	 * @create 2014/12/10
	 * @author KCCS Hashimoto
	 * @since 2.0.0
	 */
	private byte[] getNewPageCharacter() {
		if (newPageCharBytes == null || newPageCharBytes.length == 0) {
			throw new GReportRuntimeException("A newPageCharBytes is null or empty.");
		}
		return newPageCharBytes;
	}
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// テキストドライバで利用できない機能は空実装

	@Override
	public void setOrientation(int value) {
	}

	@Override
	public void setMargins(float left_margin, float right_margin, float top_margin, float bottom_margin) {
	}

	@Override
	public void setParperSize(String paper_size) {
	}

//	@Deprecated
//	@Override
//	public void setBackGroundColor(float left, float top, float width, float height) {
//	}

	@Override
	public void writeBackGroundColor(float left, float top, float width, float height, Color backGroundColor) {
	}

	@Override
	public void setRuledLine(boolean output) {
	}

	@Override
	public void setPassword(String password) {
	}

	@Override
	public void setOnLoadPrint() {
	}

	@Override
	public void setJavaScript(String script) {
	}

	@Override
	public void writeOutline(String outline) {
	}

	@Override
	public void writeImage(float left, float top, float width, float height, String image_name) throws GReportException {
	}
	
	@Override
	public void writeLine(float left, float top, float width, float height, double size, int type, Color color, ILineDashInfo dashInfo, boolean isDouble) throws GReportException {
	}

	@Override
	public void writeRectangle(float left, float top, float width, float height, double size, int type, int radius, ILineDashInfo dash_info) throws GReportException {
	}

	@Override
	public void writeBarcode(int type, float left, float top, float width, float height, String value, IBarcodeInfo info) throws GReportException {
	}

	@Override
	public void writeCircle(float left, float top, float height, float width, double size, int type, int true_circle, ILineDashInfo info) throws GReportException {
	}

	@Override
	public void writeTemplateImage(String template_name, float left, float top, float width, float height, String image_name) throws GReportException {
	}

	@Override
	public void writeTemplateLine(String template_name, float left, float top, float width, float height, double size, int type, Color color) throws GReportException {
	}

	@Override
	public void writeTemplateRectangle(String template_name, float left, float top, float width, float height, double size, int type, int radius) throws GReportException {
	}

	@Override
	public void writeTemplateBarcode(String template_name, int type, float left, float top, float width, float height, String value, IBarcodeInfo info) throws GReportException {
	}

	@Override
	public void writeTemplateCircle(String template_name, float left, float top, float height, float width, double size, int type, int true_circle) throws GReportException {
	}
}
