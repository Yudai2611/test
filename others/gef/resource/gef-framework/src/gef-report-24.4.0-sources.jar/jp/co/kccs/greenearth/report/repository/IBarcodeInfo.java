/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

import org.w3c.dom.Node;

import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GCodabar;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GCode128;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GCode39;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GEan;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GEan128;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GEanSupp;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GInter25;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GPdf417;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GPostnet;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GQRcode;

/**
 * 【役割】バーコード固有の情報インターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface IBarcodeInfo {

	/** 128 */
	public static final int BARCODE_TYPE_128 = 1;
	/** 39 */
	public static final int BARCODE_TYPE_39 = 2;
	/** Codabar */
	public static final int BARCODE_TYPE_CODABAR = 3;
	/** EAN */
	public static final int BARCODE_TYPE_EAN = 4;
	/** Inter25 */
	public static final int BARCODE_TYPE_INTER25 = 5;
	/** Postnet */
	public static final int BARCODE_TYPE_POSTNET = 6;
	/** PDF417 */
	public static final int BARCODE_TYPE_PDF417 = 7;
	/** QR */
	public static final int BARCODE_TYPE_QR = 8;
	/** EAN SUPP */
	public static final int BARCODE_TYPE_EAN_SUPP = 9;
	/** EAN 128 */
	public static final int BARCODE_TYPE_EAN_128 = 10;

	/** CODE TYPE: EAN13 */
	public static final int CODE_TYPE_EAN13 = 1;
	/** CODE TYPE: EAN8 */
	public static final int CODE_TYPE_EAN8 = 2;
	/** CODE TYPE: UPCA */
	public static final int CODE_TYPE_UPCA = 3;
	/** CODE TYPE: UPCE */
	public static final int CODE_TYPE_UPCE = 4;
	/** CODE TYPE: SUPP2 */
	public static final int CODE_TYPE_SUPP2 = 5;
	/** CODE TYPE: SUPP5 */
	public static final int CODE_TYPE_SUPP5 = 6;
	/** CODE TYPE: POSTNET */
	public static final int CODE_TYPE_POSTNET = 7;
	/** CODE TYPE: PLANET */
	public static final int CODE_TYPE_PLANET = 8;
	/** CODE TYPE: CODE128 */
	public static final int CODE_TYPE_CODE128 = 9;
	/** CODE TYPE: CODE_128_UCC */
	public static final int CODE_TYPE_CODE128_UCC = 10;
	/** CODE TYPE: CODE_128_UCC */
	public static final int CODE_TYPE_CODE128_RAW = 11;
	/** CODE TYPE: CODABAR */
	public static final int CODE_TYPE_CODABAR = 12;

	/**
	 * ノードをロードします。<BR>
	 * 
	 * @param node ノード
	 * @param type タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(Node node, int type);

	/**
	 * 【機能】バーコードタイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getType();

	/**
	 * 【機能】Code39 を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @return
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GCode39 getCode39();

	/**
	 * 【機能】Code128 を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @create 2004/09/16
	 * @return バーコードオブジェクト
	 * @since 1.0.3
	 */
	GCode128 getCode128();

	/**
	 * 【機能】Ean を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GEan getEan();

	/**
	 * 【機能】Ean128 を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GEan128 getEan128();

	/**
	 * 【機能】Codabar を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GCodabar getCodabar();

	/**
	 * 【機能】Postnet を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GPostnet getPostnet();

	/**
	 * 【機能】Inter25 を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GInter25 getInter25();

	/**
	 * 【機能】EanSupp を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GEanSupp getEanSupp();

	/**
	 * 【機能】Pdf417 を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GPdf417 getPdf417();

	/**
	 * 【機能】QRCode を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return バーコードオブジェクト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	GQRcode getQRCode();
}
