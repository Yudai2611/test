/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

import org.w3c.dom.Node;

/**
 * 【役割】コントロールブレイク情報インターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */

public interface IControlBreakInfo {

	/**
	 * ノードをロードします。<BR>
	 * 
	 * @param node ノード
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(Node node);

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 【機能】名称を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setName(String name);
}
