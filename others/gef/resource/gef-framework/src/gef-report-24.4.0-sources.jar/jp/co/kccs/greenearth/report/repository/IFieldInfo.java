/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

import java.awt.Color;

import org.w3c.dom.Node;

import jp.co.kccs.greenearth.report.IReportLine;

/**
 * 【役割】フィールド情報インターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */

public interface IFieldInfo {

	/** PlainText */
	public static final String TYPE_PLAIN_TEXT = "plaintext";
	/** Label */
	public static final String TYPE_LABEL = "label";
	/** Resource */
	public static final String TYPE_RESOURCE = "resource";
	/** SysDate */
	public static final String TYPE_SYS_DATE = "sysdate";
	/** Page */
	public static final String TYPE_PAGE = "page";
	/** MaxPage */
	public static final String TYPE_MAX_PAGE = "maxpage";
	/** Data */
	public static final String TYPE_DATA = "data";

	/** フォントフェイス（標準） */
	public static final int FONT_FACE_DEFAULT = 0;
	/** フォントフェイス（ボールド） */
	public static final int FONT_FACE_BOLD = 1;
	/** フォントフェイス（イタリック） */
	public static final int FONT_FACE_ITALIC = 2;

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 【機能】背景色を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return カラー
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	Color getBackGroundColor();

	/**
	 * 【機能】前景色を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return カラー
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	Color getForeColor();

	/**
	 * 【機能】タイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getType();

	/**
	 * 【機能】値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getValue();

	/**
	 * 【機能】アラインメントを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return アラインメント
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getAlignment();

	/**
	 * 【機能】フォーマットを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォーマット
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFormat();

	/**
	 * 【機能】入力フォーマットを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 入力フォーマット
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getInputFormat();

	/**
	 * 【機能】フォントサイズを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォントサイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontSize();

	/**
	 * 【機能】フォントフェイスを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォントフェイス
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontFace();

	/**
	 * 【機能】フォント拡大率を取得します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォント拡大率
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontZoom();

	/**
	 * 【機能】フォント間隔を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォント間隔
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontInterval();

	/**
	 * 【機能】フォントの高さを調節する値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォント高さ調節値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontHeight();

	/**
	 * 【機能】高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getHeight();

	/**
	 * 【機能】幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getWidth();

	/**
	 * 【機能】左端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getLeft();

	/**
	 * 【機能】回転角度を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 回転角度
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getRotation();

	/**
	 * 【機能】上端を取得します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @return 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getTop();

	/**
	 * 【機能】抑止の値が前回と同じか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getOmitSameValue();

	/**
	 * 【機能】表示/非表示の真偽値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getOutput();

	/**
	 * 【機能】アンダーラインを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return アンダーライン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportLine getUnderLine();

	/**
	 * 【機能】アンダーライン情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return ライン情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	ILineInfo getUnderLineInfo();

	/**
	 * 【機能】複数行フラグを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フラグ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getMultiLine();

	/**
	 * 【機能】横位置微調整値（Pixel）を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】単位はPixel<BR>
	 * 
	 * @return 横位置微調整値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getPositionAdjustmentX();	

	/**
	 * 【機能】縦位置微調整値（Pixel）を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】単位はPixel<BR>
	 * 
	 * @return 縦位置微調整値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getPositionAdjustmentY();	

	/**
	 * ノードをロードします。<BR>
	 * 
	 * @param node ノード
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(Node node);
	
	/**
	 * FontFaceを設定します。<BR>
	 * 
	 * @param fontFace フォントフェイス
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontFace(int fontFace);
	
	/**
	 * FontNameを設定します。<BR>
	 * 
	 * @param fontName フォント名
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontName(String fontName);
	
	/**
	 * FontNameを取得します。<BR>
	 * 
	 * @return FontName フォント名
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontName();
	
	/**
	 * FontSizeを設定します。<BR>
	 * 
	 * @param fontSize フォントサイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontSize(int fontSize);
	
	/**
	 * FontNameBoldを設定します。<BR>
	 * 
	 * @param fontName フォント名(Bold)
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontNameBold(String fontName);
	
	/**
	 * FontNameBoldを取得します。<BR>
	 * 
	 * @return FontNameBold フォント名(Bold)
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontNameBold();
	
	/**
	 * FontNameItalicを設定します。<BR>
	 * 
	 * @param fontName フォント名(Italic)
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontNameItalic(String fontName);
	
	/**
	 * FontNameItalicを取得します。<BR>
	 * 
	 * @return FontNameItalic フォント名(Italic)
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontNameItalic();
	
	/**
	 * UseFontFileを設定します。<BR>
	 * 
	 * @param useFontFile ユーズフォントファイル
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setUseFontFile(boolean useFontFile);
	
	/**
	 * UseFontFileの真偽値を取得します。<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean isUseFontFile();
	
	/**
	 * FontEncodingを設定します。<BR>
	 * 
	 * @param encoding フォントエンコーディング
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontEncoding(String encoding);
	
	/**
	 * FontEncodingを取得します。<BR>
	 * 
	 * @return FontEncoding フォントエンコーディング
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontEncoding();
	
	/**
	 * FontIntervalWidthを設定します。<BR>
	 * 
	 * @param fontIntervalWidth フォントインターバル幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontIntervalWidth(int fontIntervalWidth);
	
	/**
	 * FontIntervalWidthを設定します。<BR>
	 * 
	 * @return FontIntervalWidth フォントインターバル幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontIntervalWidth();
	
	/**
	 * FontIntervalHeightを設定します。<BR>
	 * 
	 * @param fontintervalHeight フォントインターバル高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontIntervalHeight(int fontintervalHeight);
	
	/**
	 * FontIntervalHeightを取得します。<BR>
	 * 
	 * @return FontIntervalHeight フォントインターバル高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontIntervalHeight();
}