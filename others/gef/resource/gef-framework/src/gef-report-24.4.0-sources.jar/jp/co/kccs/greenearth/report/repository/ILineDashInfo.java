/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

/**
 * 【役割】ダッシュライン情報を表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface ILineDashInfo {

	/**
	 * UnitsOnを設定します。<BR>
	 * 
	 * @param units_on ユニッツオン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setUnitsOn(int units_on);

	/**
	 * UnitsOnを取得します。<BR>
	 * 
	 * @return UnitsOn ユニッツオン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getUnitsOn();

	/**
	 * Phaseを設定します。<BR>
	 * 
	 * @param phase フェーズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setPhase(int phase);

	/**
	 * Phaseを取得します。<BR>
	 * 
	 * @return Phase フェーズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getPhase();
}
