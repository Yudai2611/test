/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

/**
 * 【役割】最大ページ情報インターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */

public interface IMaxPageInfo {

	/**
	 * Widthを設定します。<BR>
	 * 
	 * @param width 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setWidth(float width);

	/**
	 * Heightを設定します。<BR>
	 * 
	 * @param height 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setHeight(float height);

	/**
	 * Topを設定します。<BR>
	 * 
	 * @param top 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setTop(int top);

	/**
	 * FontSizeを設定します。<BR>
	 * 
	 * @param font_size フォントサイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontSize(int font_size);

	/**
	 * FontZoomを設定します。<BR>
	 * 
	 * @param font_zoom フォントズーム
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontZoom(int font_zoom);

	/**
	 * FontFaceを設定します。<BR>
	 * 
	 * @param font_face フォントフェイス
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontFace(int font_face);

	/**
	 * FontIntervalを設定します。<BR>
	 * 
	 * @param font_interval フォントインターバル
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontInterval(int font_interval);

	/**
	 * FontHeightを設定します。<BR>
	 * 
	 * @param font_height フォント高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontHeight(int font_height);

	/**
	 * Alignmentを設定します。<BR>
	 * 
	 * @param align アライン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setAlignment(String align);

	/**
	 * Formatを設定します。<BR>
	 * 
	 * @param format フォーマット
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFormat(String format);

	/**
	 * Widthを取得します。<BR>
	 * 
	 * @return Width 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public float getWidth();

	/**
	 * Heightを取得します。<BR>
	 * 
	 * @return Height 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public float getHeight();

	/**
	 * Topを取得します。<BR>
	 * 
	 * @return Top 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public int getTop();

	/**
	 * FontSizeを取得します。<BR>
	 * 
	 * @return FontSize フォントサイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public int getFontSize();

	/**
	 * FontZoomを取得します。<BR>
	 * 
	 * @return FontZoom フォントズーム
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public int getFontZoom();

	/**
	 * FontFaceを取得します。<BR>
	 * 
	 * @return FontFace フォントフェイス
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public int getFontFace();

	/**
	 * FontHeightを取得します。<BR>
	 * 
	 * @return FontHeight フォント高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public int getFontHeight();

	/**
	 * FontIntervalを取得します。<BR>
	 * 
	 * @return FontInterval フォントインターバル
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public int getFontInterval();

	/**
	 * Alignmentを取得します。<BR>
	 * 
	 * @return Alignment アライン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public String getAlignment();

	/**
	 * Formatを取得します。<BR>
	 * 
	 * @return Format フォーマット
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public String getFormat();
}
