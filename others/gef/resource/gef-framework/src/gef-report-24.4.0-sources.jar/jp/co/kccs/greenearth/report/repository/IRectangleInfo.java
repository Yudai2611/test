/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

import org.w3c.dom.Node;

/**
 * 【役割】レクタングル情報インターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */

public interface IRectangleInfo {

	/** 標準線 */
	public static final int TYPE_SOLID = 0;
	/** 破線 */
	public static final int TYPE_DASH = 1;
	/** 点線 */
	public static final int TYPE_DOT = 2;
	/** カスタム点線 */
	public static final int TYPE_CUSTOM_DASH = 3;

	/**
	 * 【機能】点線情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 点線情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public ILineDashInfo getDashInfo();

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 【機能】角丸長方形の角の半径を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 角丸長方形の角の半径
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getRadius();

	/**
	 * 【機能】タイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return タイプ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getType();

	/**
	 * 【機能】高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getHeight();

	/**
	 * 【機能】幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getWidth();

	/**
	 * 【機能】左端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 左端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getLeft();

	/**
	 * 【機能】上端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 上端
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getTop();

	/**
	 * 【機能】線幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 線幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	double getLineWidth();

	/**
	 * 【機能】表示/非表示の真偽値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getOutput();

	/**
	 * ノードをロードします。<BR>
	 * 
	 * @param node ノード
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(Node node);
}
