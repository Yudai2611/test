/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

import java.util.List;

import org.w3c.dom.Node;

/**
 * 【役割】レポート情報インターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */

public interface IReportInfo {

	/** 横用紙 */
	public static final int ORIENT_HORIZONTAL = 1;
	/** 縦用紙 */
	public static final int ORIENT_VIRTICAL = 2;
	/** 相対位置指定 */
	public static final int BASE_POSITION_NEXTLINE = 0;
	/** 絶対位置指定 */
	public static final int BASE_POSITION_ABSOLUTE = 1;
	/** 縦印刷 */
	public static final int PRINT_DIRECTION_VIRTICAL = 0;
	/** 横印刷 */
	public static final int PRINT_DIRECTION_HORIZONTAL = 1;

	/**
	 * ノードをロードします。<BR>
	 * 
	 * @param node ノード
	 * @param name ネーム
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(Node node, String name);

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 【機能】位置を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 位置
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getPosition();

	/**
	 * 【機能】印刷方向を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 印刷方向
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getPrintDirection();

	/**
	 * 【機能】ベースポジションを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return ベースポジション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getBasePosition();

	/**
	 * 【機能】用紙サイズを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 用紙サイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getPaperSize();

	/**
	 * 【機能】用紙の縦横を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 縦横
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getOrientation();

	/**
	 * 【機能】文字と線の縦の幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 縦幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getRowPad();

	/**
	 * 【機能】文字と線の横の幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 横幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getColPad();

	/**
	 * 【機能】列数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 列数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getColumnCount();

	/**
	 * 【機能】行数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 行数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getRowCount();

	/**
	 * 【機能】右マージンを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 右マージン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getRightMargin();

	/**
	 * 【機能】上マージンを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 上マージン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getTopMargin();

	/**
	 * 【機能】左マージンを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 左マージン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getLeftMargin();

	/**
	 * 【機能】下マージンを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 下マージン
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getBottomMargin();

	/**
	 * 【機能】フォントサイズを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォントサイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getFontSize();

	/**
	 * 【機能】フォント名を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォント名
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontName();

	/**
	 * 【機能】フォント名(Bold)を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォント名(Bold)
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontNameBold();

	/**
	 * 【機能】フォント名(Italic)を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォント名(Italic)
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontNameItalic();

	/**
	 * 【機能】外部フォントファイル使用するかどうかを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return _use_font_file
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getUseFontFile();

	/**
	 * 【機能】フォントエンコーディングを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フォントエンコーディング
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getFontEncoding();

	/**
	 * 【機能】セクション情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param section_name セクション名称
	 * @return セクション情報
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	ISectionInfo getSectionInfo(String section_name);

	/**
	 * 【機能】セクション情報の配列を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return セクション情報の配列
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	ISectionInfo[] getSectionInfos();

	/**
	 * 【機能】コントロールブレイク情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return java.util.List
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	List<IControlBreakInfo> getControlBreakList();

	/**
	 * 【機能】外部キーリストを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return リスト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	List<String> getForeignKeyList();

	/**
	 * 【機能】他の帳票レイアウト上のセクションを追加します。BR> 【戻値】<BR>
	 * 【呼出】API<BR>
	 * 【備考】追加後は、GReportInfo#getSectionInfoおよび getSectionsにより<BR>
	 * 該当セクション情報を取得可能とします。<BR>
	 * その際のセクション名は、"レポートID\tセクション名"とします。<BR>
	 * 
	 * @param report_id 他の帳票レイアウトのレポートID
	 * @param section_infos セクション情報の配列
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void appendSections(String report_id, ISectionInfo[] section_infos);
	
	/**
	 * FontNameを設定します。<BR>
	 * 
	 * @param fontName フォントネーム
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontName(String fontName);
	
	/**
	 * FontSizeを設定します。<BR>
	 * 
	 * @param size フォントサイズ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontSize(int size);
	
	/**
	 * FontNameBoldを設定します。<BR>
	 * 
	 * @param fontName 太字のフォントネーム
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontNameBold(String fontName);
	
	/**
	 * FontNameItalicを設定します。<BR>
	 * 
	 * @param fontName 斜字のフォントネーム
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontNameItalic(String fontName);
	
	/**
	 * UseFontFileを設定します。<BR>
	 * 
	 * @param useFontFile ユーズフォントファイル
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setUseFontFile(boolean useFontFile);
	
	/**
	 * UseFontFileの真偽値を取得します。<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean isUseFontFile();
	
	/**
	 * FontEncodingを設定します。<BR>
	 * 
	 * @param encoding エンコーディング
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setFontEncoding(String encoding);
}
