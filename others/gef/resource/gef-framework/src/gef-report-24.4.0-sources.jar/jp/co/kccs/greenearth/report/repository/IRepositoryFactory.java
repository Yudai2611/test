/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.report.GReportException;

/**
 * 【役割】リポジトリファクトリインターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */

public interface IRepositoryFactory {

	/**
	 * 【機能】XML情報を元に生成したリポジトリ情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param reportID レポートID
	 * @return レポート情報
	 * @throws GReportException ReportFramework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportInfo get(String reportID) throws GReportException;

	/**
	 * 【機能】レポート情報のキャッシュをクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @create 2014/10/31
	 * @author hashimoto
	 * @since 2.0.0
	 */
	void clear();

	/**
	 * 指定したレポートIDに関連付けられたレポート定義のキャッシュをクリアします。
	 * 
	 * @create 2014/12/15
	 * @author yamashita
	 * @since 2.0.0
	 * @param reportID 
	 */
	public void clear(String reportID);

	/**
	 *{@link IRepositoryFactory}インスタンスの ファクトリークラスです。
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	public static class Factory {

		/**
		 * DIに定義された{@link IRepositoryFactory}のインスタンスを取得します。<BR>
		 * 
		 * @return {@link IRepositoryFactory}インスタンス
		 * @create 2014/09/29
		 * @author yamashita
		 * @since 2.0.0
		 */
		public static IRepositoryFactory getInstance() {
			return GFrameworkUtils.getComponent(IRepositoryFactory.class.getName());
		}
	}
}
