/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository;

import java.awt.Color;
import java.util.List;

import org.w3c.dom.Node;

/**
 * 【役割】セクション情報インターフェースを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface ISectionInfo {

	/** 相対位置指定 */
	static final int BASE_POSITION_NEXTLINE = 0;
	/** 絶対位置指定 */
	static final int BASE_POSITION_ABSOLUTE = 1;

	/**
	 * nodeをロードします。
	 * 
	 * @param node ノード
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void load(Node node);

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	String getName();

	/**
	 * 【機能】名称を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name 名称
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void setName(String name);

	/**
	 * 【機能】高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getHeight();

	/**
	 * 【機能】幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getWidth();

	/**
	 * 【機能】左を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 左
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getLeft();

	/**
	 * 【機能】上を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 上
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getTop();

	/**
	 * 【機能】ベースポジションを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return ベースポジション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getBasePosition();

	/**
	 * 【機能】表示/非表示を判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getOutput();

	/**
	 * 【機能】網掛け印刷するかを判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	boolean getAlternate();

	/**
	 * 【機能】フィールドリストを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return フィールドリスト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	List<Object> getFieldList();

	/**
	 * 【機能】ラインリストを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return ラインリスト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	List<Object> getLineList();

	/**
	 * 【機能】イメージリストを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return イメージリスト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	List<Object> getImageList();

	/**
	 * 【機能】サークルリストを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return サークルリスト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	List<Object> getCircleList();

	/**
	 * 【機能】四角形リストを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 四角形リスト
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	List<Object> getRectangleList();

	/**
	 * 背景色を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	Color getBackGroundColor();
}
