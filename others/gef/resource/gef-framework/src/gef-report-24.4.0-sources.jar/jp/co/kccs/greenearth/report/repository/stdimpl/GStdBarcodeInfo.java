/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GNumberUtils;
import jp.co.kccs.greenearth.report.repository.IBarcodeInfo;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GCodabar;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GCode128;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GCode39;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GEan;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GEan128;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GEanSupp;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GInter25;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GPdf417;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GPostnet;
import jp.co.kccs.greenearth.report.repository.stdimpl.barcode.GQRcode;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】バーコード固有の情報を表します。<BR>
 * 【生成】GStdImageInfo により生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】Xml を元に生成した情報です。<BR>
 * 
 * @create 2004/08/31
 * @author kusakari
 * @since 1.0.3
 */
public class GStdBarcodeInfo implements IBarcodeInfo {

	/** タイプ */
	private int _type = 0;
	/** バーコード Code39 */
	private GCode39 _code_39 = null;
	/** バーコード Code128 */
	private GCode128 _code_128 = null;
	/** バーコード EAN */
	private GEan _ean = null;
	/** バーコード EAN128 */
	private GEan128 _ean128 = null;
	/** バーコード EAN SUPP */
	private GEanSupp _ean_supp = null;
	/** バーコード Postnet */
	private GPostnet _postnet = null;
	/** バーコード Codabar */
	private GCodabar _codabar = null;
	/** バーコード Pdf417 */
	private GPdf417 _pdf_417 = null;
	/** バーコード Inter25 */
	private GInter25 _inter_25 = null;
	/** バーコード QR */
	private GQRcode _qrcode = null;

	/**
	 * XMLから値をロードします.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#load(org.w3c.dom.Node, int)
	 * @param node ノード
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void load(Node node, int type) {
		setType(type);
		load(node);
	}

	/**
	 * XMLから値をロードします.
	 * 
	 * @param node ノード
	 * @create 
	 * @author 
	 * @since 
	 */
	private void load(Node node) {
		if (node == null) { 
			return; 
		}
		NodeList list = node.getChildNodes();
		int count = list.getLength();
		for (int i = 0; i < count; i++) {
			int type = list.item(i).getNodeType();
			if (type == 3) {
				continue;
			}

			String nodeName = list.item(i).getNodeName();
			String value = "";
			if (list.item(i).getChildNodes().getLength() > 0) {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}
			if (nodeName.equals("Error")) {
				_qrcode.setErrorLevel(value);
			} else if (nodeName.equals("Mode")) {
				_qrcode.setEncodeMode(value);
			} else if (nodeName.equals("Version")) {
				_qrcode.setVersion(value);
			} else if (nodeName.equals("ColumnCount")) {
				_pdf_417.setColumnCount(value);
			} else if (nodeName.equals("RowCount")) {
				_pdf_417.setRowCount(value);
			} else if (nodeName.equals("Extended")) {
				_code_39.setExtended(value);
			} else if (nodeName.equals("GenerateChecksum")) {
				setGenerateCheckSum(value);
			} else if (nodeName.equals("CodeType")) {
				setCodeType(value);
			} else if (nodeName.equals("SuppValue")) {
				_ean_supp.setSuppValue(value);
			} else if (nodeName.equals("SuppCodeType")) {
				_ean_supp.setSuppCodeType(value);
			}
		}
	}

	/**
	 * バーコード Code39を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getCode39()
	 * @return GCode39 39
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GCode39 getCode39() {
		return _code_39;
	}

	/**
	 * バーコード Code128を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getCode128()
	 * @return GCode128 128
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GCode128 getCode128() {
		return _code_128;
	}

	/**
	 * バーコード EANを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getEan()
	 * @return GEan EAN
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GEan getEan() {
		return _ean;
	}

	/**
	 * バーコード EAN128を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getEan128()
	 * @return GEan128 EAN128
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GEan128 getEan128() {
		return _ean128;
	}

	/**
	 * バーコード Codabarを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getCodabar()
	 * @return GCodabar Codabar
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GCodabar getCodabar() {
		return _codabar;
	}

	/**
	 * バーコード Postnetを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getPostnet()
	 * @return GPostnet Postnet
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GPostnet getPostnet() {
		return _postnet;
	}

	/**
	 * バーコード EAN SUPPを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getInter25()
	 * @return GInter25 INTER25
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GInter25 getInter25() {
		return _inter_25;
	}

	/**
	 * バーコード Pdf417を取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getEanSupp()
	 * @return GEanSupp EAN SUPP
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GEanSupp getEanSupp() {
		return _ean_supp;
	}

	/**
	 * バーコード Pdf417取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getPdf417()
	 * @return GPdf417 PDF417
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GPdf417 getPdf417() {
		return _pdf_417;
	}

	/**
	 * QRコードを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getQRCode()
	 * @return GQRcode QR
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public GQRcode getQRCode() {
		return _qrcode;
	}

	/**
	 * タイプを設定します.<BR>
	 * 
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setType(int type) {
		_type = type;
		if (type == IBarcodeInfo.BARCODE_TYPE_39) {
			_code_39 = new GCode39();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_128) {
			_code_128 = new GCode128();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_CODABAR) {
			_codabar = new GCodabar();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_EAN) {
			_ean = new GEan();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_INTER25) {
			_inter_25 = new GInter25();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_PDF417) {
			_pdf_417 = new GPdf417();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_POSTNET) {
			_postnet = new GPostnet();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_QR) {
			_qrcode = new GQRcode();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_EAN_SUPP) {
			_ean_supp = new GEanSupp();
		} else if (type == IBarcodeInfo.BARCODE_TYPE_EAN_128) {
			_ean128 = new GEan128();
		}
	}

	/**
	 * タイプを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IBarcodeInfo#getType()
	 * @return int タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getType() {
		return _type;
	}

	/**
	 * コードタイプ自動修正を設定します。<BR>
	 * 
	 * @param code_type ｺｰﾄﾞタイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setCodeType(String code_type) {
		setCodeType(GNumberUtils.toInteger(code_type, 0));
	}

	/**
	 * コードタイプ自動修正を設定します。<BR>
	 * 
	 * @param code_type ｺｰﾄﾞタイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setCodeType(int code_type) {
		if (_type == IBarcodeInfo.BARCODE_TYPE_128) {
			_code_128.setCodeType(code_type);
		} else if (_type == IBarcodeInfo.BARCODE_TYPE_EAN) {
			_ean.setCodeType(code_type);
		} else if (_type == IBarcodeInfo.BARCODE_TYPE_EAN_SUPP) {
			_ean_supp.setCodeType(code_type);
		} else if (_type == IBarcodeInfo.BARCODE_TYPE_POSTNET) {
			_postnet.setCodeType(code_type);
		}
	}

	/**
	 * チェックサム自動修正を設定します。<BR>
	 * 
	 * @param bool チェックサム自動修正
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setGenerateCheckSum(String bool) {
		setGenerateCheckSum(GBooleanUtils.toBoolean(bool, false));
	}

	/**
	 * チェックサム自動修正を設定します。<BR>
	 * 
	 * @param bool チェックサム自動修正
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setGenerateCheckSum(boolean bool) {
		if (_type == IBarcodeInfo.BARCODE_TYPE_CODABAR) {
			_codabar.setGenerateCheckSum(bool);
		} else if (_type == IBarcodeInfo.BARCODE_TYPE_39) {
			_code_39.setGenerateCheckSum(bool);
		} else if (_type == IBarcodeInfo.BARCODE_TYPE_INTER25) {
			_inter_25.setGenerateCheckSum(bool);
		}
	}
}
