/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GNumberUtils;
import jp.co.kccs.greenearth.report.repository.ICircleInfo;
import jp.co.kccs.greenearth.report.repository.ILineDashInfo;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】サークル情報を表します。<BR>
 * 【生成】GRepositoryFactory により XMLファイルごとに生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】XML情報を元に生成した情報です。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdCircleInfo implements ICircleInfo {

	/** 名称 */
	private String _name = null;
	/** タイプ */
	private int _type = ICircleInfo.TYPE_SOLID;
	/** 上 */
	private int _top = 0;
	/** 左 */
	private int _left = 0;
	/** 幅 */
	private int _width = 0;
	/** 高さ */
	private int _height = 0;
	/** 線幅 */
	private double _line_width = 0;
	/** 正円オプション */
	private int _true_circle = ICircleInfo.TRUE_CIRCLE_NONE;
	/** 表示 */
	private boolean _is_output = true;
	/** カスタム点線情報 */
	private ILineDashInfo _custom_dash = null;

	/**
	 * 【機能】情報をロードします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#load(org.w3c.dom.Node)
	 * @param node ノード
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void load(Node node) {
		if (node == null) {
			return;
		}

		NodeList list = node.getChildNodes();
		int count = list.getLength();
		for (int i = 0; i < count; i++) {
			int type = list.item(i).getNodeType();
			if (type == 3) {
				continue;
			}

			String nodeName = list.item(i).getNodeName();

			String value = "";
			if (list.item(i).getChildNodes().getLength() > 0) {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}

			if (nodeName.equals("Name")) {
				setName(value);
			} else if (nodeName.equals("Left")) {
				setLeft(value);
			} else if (nodeName.equals("Top")) {
				setTop(value);
			} else if (nodeName.equals("Height")) {
				setHeight(value);
			} else if (nodeName.equals("Width")) {
				setWidth(value);
			} else if (nodeName.equals("Type")) {
				setType(value);
			} else if (nodeName.equals("IsOutput")) {
				setOutput(value);
			} else if (nodeName.equals("LineWidth")) {
				setLineWidth(value);
			} else if (nodeName.equals("TrueCircle")) {
				setTrueCircle(value);
			} else if (nodeName.equals("Dash")) {
				setDash(value);
			} else if (nodeName.equals("Gap")) {
				setGap(value);
			}
		}
	}

	/**
	 * 【機能】点線情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param info ILineDashInfo
	 * @create 2004/08/31
	 * @author 
	 * @since 1.0.3
	 */
	public void setDashInfo(ILineDashInfo info) {
		_custom_dash = info;
	}

	/**
	 * 【機能】点線情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getDashInfo()
	 * @return ILineDashInfo 点線情報
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	@Override
	public ILineDashInfo getDashInfo() {
		return _custom_dash;
	}

	/**
	 * 線幅を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param lineWidth 線幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLineWidth(String lineWidth) {
		setLineWidth(GNumberUtils.toDouble(lineWidth, 0D));
	}

	/**
	 * 【機能】線幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param lineWidth 線幅
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setLineWidth(double lineWidth) {
		this._line_width = lineWidth;
	}

	/**
	 * 【機能】線幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getLineWidth()
	 * @return double タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public double getLineWidth() {
		return _line_width;
	}

	/**
	 * 【機能】名称を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param name 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setName(String name) {
		this._name = name;
	}

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getName()
	 * @return String 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * 左を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLeft(String left) {
		setLeft(GNumberUtils.toInteger(left, 0));
	}

	/**
	 * 【機能】左を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setLeft(int left) {
		this._left = left;
	}

	/**
	 * 【機能】左を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getLeft()
	 * @return int 左
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getLeft() {
		return _left;
	}

	/**
	 * 上を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	void setTop(String top) {
		setTop(GNumberUtils.toInteger(top, 0));
	}

	/**
	 * 【機能】上を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setTop(int top) {
		this._top = top;
	}

	/**
	 * 【機能】上を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getTop()
	 * @return int 上
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getTop() {
		return _top;
	}

	/**
	 * 【機能】正円オプションを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param true_circle 正円オプション
	 * @create 
	 * @author 
	 * @since 1.0.1
	 */
	private final void setTrueCircle(String true_circle) {
		
		if ("vertical".equals(true_circle)) {
			setTrueCircle(ICircleInfo.TRUE_CIRCLE_VIRTICAL);
			return;
		}
		
		if ("horizontal".equals(true_circle)) {
			setTrueCircle(ICircleInfo.TRUE_CIRCLE_HORIZONTAL);
			return;
		}
		
		setTrueCircle(ICircleInfo.TRUE_CIRCLE_NONE);
	}

	/**
	 * 【機能】正円オプションを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param true_circle 正円オプション
	 * @create 
	 * @author 
	 * @since 1.0
	 */
	public void setTrueCircle(int true_circle) {
		_true_circle = true_circle;
	}

	/**
	 * 【機能】正円オプションを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getTrueCircle()
	 * @return int 正円オプション
	 * @create 
	 * @author 
	 * @since 1.0
	 */
	@Override
	public int getTrueCircle() {
		return _true_circle;
	}

	/**
	 * 表示を設定します。<BR>
	 * デフォールト値はtrue。<BR>
	 * 
	 * @param bool 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	void setOutput(String bool) {
		setOutput(GBooleanUtils.toBoolean(bool, true));
	}

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param bool 表示/非表示
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setOutput(boolean bool) {
		_is_output = bool;
	}

	/**
	 * 【機能】表示/非表示を判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getOutput()
	 * @return boolean 表示/非表示
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean getOutput() {
		return _is_output;
	}

	/**
	 * 幅を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setWidth(String width) {
		setWidth(GNumberUtils.toInteger(width, 0));
	}

	/**
	 * 【機能】幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 * @since 1.0
	 */
	public void setWidth(int width) {
		_width = width;
	}

	/**
	 * 【機能】幅を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getWidth()
	 * @return int 幅
	 * @create 
	 * @author 
	 * @since 1.0
	 */
	@Override
	public int getWidth() {
		return _width;
	}

	/**
	 * 高さを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setHeight(String height) {
		setHeight(GNumberUtils.toInteger(height, 0));
	}

	/**
	 * 【機能】高さを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 1.0
	 */
	public void setHeight(int height) {
		_height = height;
	}

	/**
	 * 【機能】高さを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getHeight()
	 * @return int 高さ
	 * @create 
	 * @author 
	 * @since 1.0
	 */
	@Override
	public int getHeight() {
		return _height;
	}

	/**
	 * 【機能】タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 1.0.1
	 */
	private final void setType(String type) {
		if ("dash".equals(type)) {
			setType(ICircleInfo.TYPE_DASH);
		} else if ("dot".equals(type)) {
			setType(ICircleInfo.TYPE_DOT);
		} else if ("customdash".equals(type)) {
			setType(ICircleInfo.TYPE_CUSTOM_DASH);
		} else {
			setType(ICircleInfo.TYPE_SOLID);
		}
	}

	/**
	 * 【機能】タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setType(int type) {
		_type = type;
	}

	/**
	 * 【機能】タイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ICircleInfo#getType()
	 * @return int タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getType() {
		return _type;
	}

	/**
	 * ユニッツオンを設定します。<BR>
	 * デフォールト値は2。<BR>
	 * 
	 * @param dash ユニッツオン
	 * @create 
	 * @author 
	 * @since 
	 */
	void setDash(String dash) {
		setDash(GNumberUtils.toInteger(dash, 2));
	}

	/**
	 * 【機能】Dashを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param dash dash
	 * @create 2004/08/31
	 * @author 
	 * @since 1.0.3
	 */
	public void setDash(int dash) {
		if (_custom_dash == null) {
			_custom_dash = createLineDashInfo();
		}
		_custom_dash.setUnitsOn(dash);
	}

	/**
	 * フェーズを設定します。<BR>
	 * デフォールト値は2。<BR>
	 * 
	 * @param gap フェーズ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setGap(String gap) {
		setGap(GNumberUtils.toInteger(gap, 2));
	}

	/**
	 * 【機能】Gapを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param gap Gap
	 * @create 2004/08/31
	 * @author 
	 * @since 1.0.3
	 */
	public void setGap(int gap) {
		if (_custom_dash == null) {
			_custom_dash = createLineDashInfo();
		}
		_custom_dash.setPhase(gap);
	}

	/**
	 * 破線情報を生成します.
	 * 
	 * @return ILineDashInfo LineDashInfo
	 * @create 
	 * @author 
	 * @since 
	 */
	protected ILineDashInfo createLineDashInfo() {
		return GFrameworkUtils.getComponent(ILineDashInfo.class.getName());
	}
}
