/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import jp.co.kccs.greenearth.report.repository.IControlBreakInfo;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】コントロールブレイク情報を表します。<BR>
 * 【生成】GRepositoryFactory により XMLファイルごとに生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】XML情報を元に生成した情報です。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdControlBreakInfo implements IControlBreakInfo {

	/** 名称 */
	private String _name = null;

	/**
	 * 【機能】xmlファイルを読み込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IControlBreakInfo#load(org.w3c.dom.Node)
	 * @param node ノード
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public void load(Node node) {
		if (node == null) {
			return;
		}

		NodeList list = node.getChildNodes();
		final int count = list.getLength();

		for (int i = 0; i < count; i++) {
			int type = list.item(i).getNodeType();
			if (type == 3) {
				continue;
			}

			String nodeName = list.item(i).getNodeName();
			String value = "";
			if (list.item(i).getChildNodes().getLength() > 0) {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}

			if (nodeName.equals("Name")) {
				setName(value);
			}
		}
	}

	/**
	 * 【機能】名称を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IControlBreakInfo#setName(java.lang.String)
	 * @param name 名称
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public final void setName(String name) {
		_name = name;
	}

	/**
	 * 【機能】名称を取得します。<BR>
	 * 【引数】<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IControlBreakInfo#getName()
	 * @return 名称
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public String getName() {
		return _name;
	}
}
