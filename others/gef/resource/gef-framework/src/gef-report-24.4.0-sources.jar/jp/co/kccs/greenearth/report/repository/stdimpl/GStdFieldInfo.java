/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import java.awt.Color;
import java.util.MissingResourceException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GNumberUtils;
import jp.co.kccs.greenearth.report.IReportLine;
import jp.co.kccs.greenearth.report.repository.IFieldInfo;
import jp.co.kccs.greenearth.report.repository.ILineInfo;
import jp.co.kccs.greenearth.report.utility.GColor;
import jp.co.kccs.greenearth.report.utility.GReportXMLUtils;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】フィールド情報を表します。<BR>
 * 【生成】GRepositoryFactory により XMLファイルごとに生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】XML情報を元に生成した情報です。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdFieldInfo implements IFieldInfo {

	/** 上 */
	private int _top = -1;
	/** 左 */
	private int _left = -1;
	/** 幅 */
	private int _width = -1;
	/** 高さ */
	private int _height = -1;
	/** フォントサイズ */
	private int _font_size = -1;
	/** フォントフェース */
	private int _font_face = 0;
	/** フォント拡大率 */
	private int _font_zoom = 1;
	/** フォントインターバル */
	private int _font_interval = 0;
	/** フォント高さ */
	private int _font_height = 0;
	/** 名称 */
	private String _name = null;
	/** アラインメント */
	private String _alignment = null;
	/** 値 */
	private String _value = null;
	/** タイプ */
	private String _type = null;
	/** フォーマット */
	private String _format = null;
	/** 入力フォーマット */
	private String _input_format = null;
	/** 背景色 */
	private Color _back_color = GColor.white;
	/** 前景色 */
	private Color _fore_color = null;
	/** 抑止 */
	private boolean _is_omit_same_value = false;
	/** 表示 */
	private boolean _is_output = true;
	/** アンダーライン */
	private IReportLine _under_line = null;
	/** アンダーライン情報 */
	private ILineInfo _under_line_info = null;
	/** 回転の角度 */
	private int _rotation = 0;
	/** 複数行フラグ */
	private boolean _multi_line = false;
	
	/** フィールドの外部フォントファイル使用有無 */
	private String _useFontFile = null;
	/** フィールドのエンコーディング */
	private String _fontEncoding = null;
	/** フィールドのフォント名 */
	private String _fontName = null;
	/** フィールドのボールドフォント名 */
	private String _fontNameBold = null;
	/** フィールドのイタリックフォント名 */
	private String _fontNameItalic = null;

	/** 横位置微調整 */
	private int _position_adjustment_x = 0;
	/** 縦位置微調整 */
	private int _position_adjustment_y = 0;

	/**
	 * 【機能】アンダーラインを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param under_line アンダーライン
	 * @create 2004/06/15
	 * @since 1.0.2
	 */
	public void setUnderLine(IReportLine under_line) {
		_under_line = under_line;
	}

	/**
	 * アンダーラインを設定します.<BR>
	 * 
	 * @param under_line_info アンダーラインInfo
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setUnderLineInfo(ILineInfo under_line_info) {
		_under_line_info = under_line_info;
	}

	/**
	 * アンダーラインを設定します.<BR>
	 * 
	 * @param line アンダーライン情報
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setUnderLine2(String line) {
		if ("true".equals(line)) {
			setUnderLineInfo(createLineInfo());
		} else {
			setUnderLineInfo(null);
		}
	}

	/**
	 * 線情報を作成します.<BR>
	 * 
	 * @return 線情報
	 * @create 
	 * @author 
	 * @since 
	 */
	protected ILineInfo createLineInfo() {
		return GFrameworkUtils.getComponent(ILineInfo.class.getName());
	}

	/**
	 * Sets the name.
	 * 
	 * @param value 値
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setValue(String value) {
		_value = value;
	}

	/**
	 * Sets the name.
	 * 
	 * @param name 名前
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * 【機能】フォーマットを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】デザイナで指定されたフォーマットを設定します。<BR>
	 * 
	 * @param format フォーマット
	 * @create 2004/04/20
	 * @since 1.0.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * 【機能】入力フォーマットを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】デザイナで指定されたフォーマットを設定します。<BR>
	 * 
	 * @param format 入力フォーマット
	 * @create 2004/04/20
	 * @since 1.0.3
	 */
	public void setInputFormat(String format) {
		_input_format = format;
	}

	/**
	 * 【機能】フォーマットを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】デザイナで指定されたフォーマットを設定します。<BR>
	 * 
	 * @param format フォーマット
	 * @create 2004/04/20
	 * @since 1.0.0
	 * @author kusakari
	 */
	private final void setFormat2(String format) {
		setFormat(GReportXMLUtils.getXMLValidString(format));
	}

	/**
	 * フォーマットを設定します.<BR>
	 * 
	 * @param format 入力フォーマット
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setInputFormat2(String format) {
		String myformat = format;
		while (myformat.indexOf(" ") != -1) {
			myformat = myformat.replaceFirst(" ", "");
		}

		if (myformat.equals("\n")) {
			String isEmulate = null;
			try {
				isEmulate = GFrameworkUtils.getProperty("geframe.report.Emulate_V10");
			} catch (MissingResourceException mre) {
				isEmulate = "false";
			}

			if (GBooleanUtils.toBoolean(isEmulate, false)) {
				setFormat(null);
			} else {
				setInputFormat(null);
			}

		} else {
			setInputFormat(format);
		}
	}

	/**
	 * 【機能】背景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param back_color 背景色
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setBackGroundColor(Color back_color) {
		_back_color = back_color;
	}

	/**
	 * 【機能】背景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param back_color 背景色
	 * @since 1.0.1
	 */
	private final void setBackGroundColor(String back_color) {
		final String color = back_color.toLowerCase();

		if (color.equals("glightgray")) {
			setBackGroundColor(GColor.gLightGray);
		} else if (color.equals("ggray")) {
			setBackGroundColor(GColor.gGray);
		} else if (color.equals("gdarkgray")) {
			setBackGroundColor(GColor.gDarkGray);
		} else if (color.equals("gsuperlightgray")) {
			setBackGroundColor(GColor.gSuperLightGray);
		} else if (color.equals("lightgray")) {
			setBackGroundColor(GColor.lightGray);
		} else if (color.equals("gray")) {
			setBackGroundColor(GColor.gray);
		} else if (color.equals("blue")) {
			setBackGroundColor(GColor.blue);
		} else if (color.equals("red")) {
			setBackGroundColor(GColor.red);
		} else if (color.equals("yellow")) {
			setBackGroundColor(GColor.yellow);
		} else if (color.equals("cyan")) {
			setBackGroundColor(GColor.cyan);
		} else if (color.equals("magenta")) {
			setBackGroundColor(GColor.magenta);
		} else if (back_color.equals("black")) {
			setBackGroundColor(GColor.black);
		} else if (color.equals("green")) {
			setBackGroundColor(GColor.green);
		} else if (color.equals("orange")) {
			setBackGroundColor(GColor.orange);
		} else if (color.equals("pink")) {
			setBackGroundColor(GColor.pink);
		} else {
			setBackGroundColor(GColor.white);
		}
	}

	/**
	 * 【機能】前景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param fore_color 前景色
	 * @create 2010/08/03
	 * @author KCCS murashige
	 * @since 1.8.0
	 */
	public void setForeColor(Color fore_color) {
		_fore_color = fore_color;
	}

	/**
	 * 名前を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getName()
	 * @return 名前
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * 値を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getValue()
	 * @return 値
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getValue() {
		return _value;
	}

	/**
	 * タイプを設定します.<BR>
	 * 
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setType(String type) {
		_type = type;
	}

	/**
	 * タイプを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getType()
	 * @return タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getType() {
		return _type;
	}

	/**
	 * フォントサイズを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontSize()
	 * @return フォントサイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontSize() {
		return _font_size;
	}

	/**
	 * フォントフェイスを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontFace()
	 * @return フォントフェイス
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontFace() {
		return _font_face;
	}

	/**
	 * 文字の横間隔を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontInterval()
	 * @return 文字の横間隔
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontInterval() {
		return getFontIntervalWidth();
	}

	/**
	 * 【機能】フォントの高さを調節する値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontHeight()
	 * @return フォントの高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontHeight() {
		return getFontIntervalHeight();
	}

	/**
	 * 【機能】フォントフェイスを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontFace(int)
	 * @param font_face フォントフェイス
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontFace(int font_face) {
		_font_face = font_face;
	}

	/**
	 * 【機能】フォントフェイスを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param font_face フォントフェイス
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setFontFace(String font_face) {
		if ("bold".equals(font_face)) {
			setFontFace(IFieldInfo.FONT_FACE_BOLD);
		} else if ("italic".equals(font_face)) {
			setFontFace(IFieldInfo.FONT_FACE_ITALIC);
		} else {
			setFontFace(IFieldInfo.FONT_FACE_DEFAULT);
		}
	}

	/**
	 * 【機能】フォントの拡大率を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param font_zoom フォントの拡大率
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setFontZoom(int font_zoom) {
		_font_zoom = font_zoom;
	}

	/**
	 * フォントの拡大率を設定します。<BR>
	 * デフォールト値は1。<BR>
	 * 
	 * @param font_zoom フォントの拡大率
	 * @create 
	 * @author 
	 * @since 
	 */
	void setFontZoom(String font_zoom) {
		setFontZoom(GNumberUtils.toInteger(font_zoom, 1));
	}

	/**
	 * フォントの拡大率を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontZoom()
	 * @return フォントの拡大率
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontZoom() {
		return _font_zoom;
	}

	/**
	 * 【機能】フォントサイズを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】-1がデフォルトです。-1の場合は無視されます。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontSize(int)
	 * @param fontSize フォントサイズ
	 */
	@Override
	public void setFontSize(int fontSize) {
		_font_size = fontSize;
	}

	/**
	 * フォントサイズを設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param fontSize フォントサイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setFontSize(String fontSize) {
		setFontSize(GNumberUtils.toInteger(fontSize, -1));
	}

	/**
	 * 【機能】文字の横間隔を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param font_interval 文字の横間隔
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setFontInterval(int font_interval) {
		setFontIntervalWidth(font_interval);
	}

	/**
	 * 文字の横間隔を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param font_interval 文字の横間隔
	 * @create 
	 * @author 
	 * @since 
	 */
	void setFontInterval(String font_interval) {
		setFontInterval(GNumberUtils.toInteger(font_interval, 0));
	}

	/**
	 * 【機能】フォントの高さを調節する値を取得します<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param font_height フォント間隔高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setFontHeight(int font_height) {
		setFontIntervalHeight(font_height);
	}

	/**
	 * フォント間隔高さを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param font_height フォント間隔高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setFontHeight(String font_height) {
		setFontHeight(GNumberUtils.toInteger(font_height, 0));
	}

	/**
	 * フォーマットを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFormat()
	 * @return フォーマット
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getFormat() {
		return _format;
	}

	/**
	 * 【機能】入力フォーマットを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getInputFormat()
	 * @return 入力フォーマット
	 * @create 2004/08/03
	 * @since 1.0.3
	 */
	@Override
	public String getInputFormat() {
		return _input_format;
	}

	/**
	 * Sets the height.
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setHeight(int height) {
		this._height = height;
	}

	/**
	 * 高さを設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setHeight(String height) {
		setHeight(GNumberUtils.toInteger(height, -1));
	}

	/**
	 * 高さを取得します.<BR>
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getHeight()
	 * @return 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getHeight() {
		return _height;
	}

	/**
	 * Sets the width.
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setWidth(int width) {
		this._width = width;
	}

	/**
	 * 幅を設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setWidth(String width) {
		setWidth(GNumberUtils.toInteger(width, -1));
	}

	/**
	 * 幅を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getWidth()
	 * @return 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getWidth() {
		return _width;
	}

	/**
	 * Sets the left.
	 * 
	 * @param left 左
	 */
	public void setLeft(int left) {
		this._left = left;
	}

	/**
	 * 左を設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLeft(String left) {
		setLeft(GNumberUtils.toInteger(left, -1));
	}

	/**
	 * 左位置を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getLeft()
	 * @return 左
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getLeft() {
		return _left;
	}

	/**
	 * Sets the top.
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setTop(int top) {
		this._top = top;
	}

	/**
	 * 上を設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	void setTop(String top) {
		setTop(GNumberUtils.toInteger(top, -1));
	}

	/**
	 * 上位置を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getTop()
	 * @return 上
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getTop() {
		return _top;
	}

	/**
	 * 出力要否を設定します.<BR>
	 * 
	 * @param bool 出力要否
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setOutput(boolean bool) {
		_is_output = bool;
	}

	/**
	 * 表示を設定します。<BR>
	 * デフォールト値はtrue。<BR>
	 * 
	 * @param bool 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	void setOutput(String bool) {
		setOutput(GBooleanUtils.toBoolean(bool, true));
	}

	/**
	 * 出力要否を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getOutput()
	 * @return 出力要否
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean getOutput() {
		return _is_output;
	}

	/**
	 * 【機能】回転の角度を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param rotation 回転角度
	 * @create 2004/09/03
	 * @since 1.0.3
	 */
	public void setRotation(int rotation) {
		_rotation = rotation;
	}

	/**
	 * 回転角度を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param rotation 回転角度
	 * @create 2014/12/17
	 * @since 2.0.0
	 */
	void setRotation(String rotation) {
		setRotation(GNumberUtils.toInteger(rotation, 0));
	}

	/**
	 * 【機能】回転角度を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getRotation()
	 * @return 回転角度
	 * @create 2004/09/03
	 * @since 1.0.3
	 */
	@Override
	public int getRotation() {
		return _rotation;
	}

	/**
	 * 【機能】アンダーラインを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getUnderLine()
	 * @return 下線インスタンス
	 * @create 2004/06/15
	 * @since 1.0.2
	 */
	@Override
	public IReportLine getUnderLine() {
		return _under_line;
	}

	/**
	 * 下線情報インスタンスを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getUnderLineInfo()
	 * @return 下線情報インスタンス
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public ILineInfo getUnderLineInfo() {
		return _under_line_info;
	}

	/**
	 * Sets the omitSameValue.
	 * 
	 * @param omit_same_value 抑止判定
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setOmitSameValue(boolean omit_same_value) {
		_is_omit_same_value = omit_same_value;
	}

	/**
	 * 抑止判定を設定します。<BR>
	 * デフォールト値はfalse。<BR>
	 * 
	 * @param omit_same_value 抑止判定
	 * @create 
	 * @author 
	 * @since 
	 */
	void setOmitSameValue(String omit_same_value) {
		setOmitSameValue(GBooleanUtils.toBoolean(omit_same_value, false));
	}

	/**
	 * 抑止判定を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getOmitSameValue()
	 * @return 抑止判定
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean getOmitSameValue() {
		return _is_omit_same_value;
	}

	/**
	 * Sets the alignment.
	 * 
	 * @param alignment アライメント
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setAlignment(String alignment) {
		_alignment = alignment;
	}

	/**
	 * アライメントを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getAlignment()
	 * @return アライメント
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getAlignment() {
		return _alignment;
	}

	/**
	 * 【機能】背景色を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getBackGroundColor()
	 * @return 背景色
	 */
	@Override
	public Color getBackGroundColor() {
		return _back_color;
	}

	/**
	 * 【機能】前景色を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getForeColor()
	 * @return 前景色
	 * @create 2010/08/03
	 * @author KCCS murashige
	 * @since 1.8.0
	 */
	@Override
	public Color getForeColor() {
		return _fore_color;
	}

	/**
	 * 【機能】複数行フラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param flag 複数行フラグ
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	public void setMultiLine(boolean flag) {
		_multi_line = flag;
	}

	/**
	 * 複数行フラグを設定します.<BR>
	 * デフォールト値はfalse。<BR>
	 * 
	 * @param flag 複数行フラグ
	 * @create 2014/12/17
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	void setMultiLine(String flag) {
		setMultiLine(GBooleanUtils.toBoolean(flag, false));
	}

	/**
	 * 【機能】複数行フラグを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getMultiLine()
	 * @return 複数行フラグ
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	@Override
	public boolean getMultiLine() {
		return _multi_line;
	}

	/**
	 * 【機能】横位置微調整値（Pixel）を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】単位はPixel<BR>
	 * 
	 * @param position_adjustment_x 横位置微調整値（Pixel）
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	public void setPositionAdjustmentX(int position_adjustment_x) {
		_position_adjustment_x = position_adjustment_x;
	}

	/**
	 * 横位置微調整値（Pixel）を設定します.<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param position_adjustment_x 横位置微調整値（Pixel）
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	void setPositionAdjustmentX(String position_adjustment_x) {
		setPositionAdjustmentX(GNumberUtils.toInteger(position_adjustment_x, 0));
	}

	/**
	 * 【機能】横位置微調整値（Pixel）を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】単位はPixel<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getPositionAdjustmentX()
	 * @return 横位置微調整値（Pixel）
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	@Override
	public int getPositionAdjustmentX() {
		return _position_adjustment_x;
	}

	/**
	 * 【機能】縦位置微調整値（Pixel）を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】単位はPixel<BR>
	 * 
	 * @param position_adjustment_y 縦位置微調整値（Pixel）
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	public void setPositionAdjustmentY(int position_adjustment_y) {
		_position_adjustment_y = position_adjustment_y;
	}

	/**
	 * 縦位置微調整値（Pixel）を設定します.<BR>
	 * デフォールト値は0<BR>
	 * 
	 * @param position_adjustment_y 縦位置微調整値（Pixel）
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	void setPositionAdjustmentY(String position_adjustment_y) {
		setPositionAdjustmentY(GNumberUtils.toInteger(position_adjustment_y, 0));
	}

	/**
	 * 【機能】縦位置微調整値（Pixel）を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】単位はPixel<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getPositionAdjustmentY()
	 * @return 縦位置微調整値（Pixel）
	 * @create 2014/09/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	@Override
	public int getPositionAdjustmentY() {
		return _position_adjustment_y;
	}

	/**
	 * XMLからフィールドに値をロードします.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#load(org.w3c.dom.Node)
	 * @param node XMLノード
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void load(Node node) {
		if (node == null) {
			return;
		}

		NodeList list = node.getChildNodes();
		int count = list.getLength();
		for (int i = 0; i < count; i++) {
			int type = list.item(i).getNodeType();
			if (type == 3) {
				continue;
			}

			String nodeName = list.item(i).getNodeName();
			String value = null;
			if (list.item(i).getChildNodes().getLength() == 0) {
				value = "";
			} else {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}

			if (nodeName.equals("Name")) {
				setName(value);
			} else if (nodeName.equals("Type")) {
				setType(value);
			} else if (nodeName.equals("Value")) {
				setValue(value);
			} else if (nodeName.equals("Top")) {
				setTop(value);
			} else if (nodeName.equals("Left")) {
				setLeft(value);
			} else if (nodeName.equals("Width")) {
				setWidth(value);
			} else if (nodeName.equals("Height")) {
				setHeight(value);
			} else if (nodeName.equals("FontSize")) {
				setFontSize(value);
			} else if (nodeName.equals("FontFace")) {
				setFontFace(value);
			} else if (nodeName.equals("FontInterval")) {
				setFontInterval(value);
			} else if (nodeName.equals("FontHeight")) {
				setFontHeight(value);
			} else if (nodeName.equals("FontZoom")) {
				setFontZoom(value);
			} else if (nodeName.equals("Format")) {
				setFormat2(value);
			} else if (nodeName.equals("InputFormat")) {
				setInputFormat2(value);
			} else if (nodeName.equals("Alignment")) {
				setAlignment(value);
			} else if (nodeName.equals("IsOutput")) {
				setOutput(value);
			} else if (nodeName.equals("UnderLine")) {
				setUnderLine2(value);
			} else if (nodeName.equals("BackGroundColor")) {
				setBackGroundColor(value);
			} else if (nodeName.equals("OmitSameValue")) {
				setOmitSameValue(value);
			} else if (nodeName.equals("Rotation")) {
				setRotation(value);
			} else if (nodeName.equals("MultiLine")) {
				setMultiLine(value);
			} else if (nodeName.equals("FontName")) {
				setFontName2(value);
			} else if (nodeName.equals("FontEncoding")) {
				setFontEncoding2(value);
			} else if (nodeName.equals("FontNameBold")) {
				setFontNameBold2(value);
			} else if (nodeName.equals("FontNameItalic")) {
				setFontNameItalic2(value);
			} else if (nodeName.equals("UseFontFile")) {
				setUseFontFile(value);
			} else if (nodeName.equals("PositionAdjustmentX")) {
				setPositionAdjustmentX(value);
			} else if (nodeName.equals("PositionAdjustmentY")) {
				setPositionAdjustmentY(value);
			}
		}
	}

	/**
	 * フォント名を設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontName(java.lang.String)
	 * @param fontName フォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontName(String fontName) {
		_fontName = fontName;
	}

	/**
	 * ボールドフォント名を設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontNameBold(java.lang.String)
	 * @param fontName ボールドフォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontNameBold(String fontName) {
		_fontNameBold = fontName;
	}

	/**
	 * イタリックフォント名を設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontNameItalic(java.lang.String)
	 * @param fontName イタリックフォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontNameItalic(String fontName) {
		_fontNameItalic = fontName;
	}

	/**
	 * 外部フォント使用有無を設定します.<BR>>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setUseFontFile(boolean)
	 * @param useFontFile 外部フォント使用有無
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setUseFontFile(boolean useFontFile) {
		setUseFontFile(String.valueOf(useFontFile));
	}

	/**
	 * 外部フォント使用有無を設定します.<BR>>
	 * 
	 * @param useFontFile 外部フォント使用有無
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setUseFontFile(String useFontFile) {
		_useFontFile = useFontFile;
	}

	/**
	 * 外部フォント使用有無を判定します.
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#isUseFontFile()
	 * @return 外部フォント使用有無
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean isUseFontFile() {
		return GBooleanUtils.toBoolean(_useFontFile);
	}

	/**
	 * フォントエンコーディングを設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontEncoding(java.lang.String)
	 * @param encoding フォントエンコーディング
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontEncoding(String encoding) {
		_fontEncoding = encoding;
	}

	/**
	 * フォント名を設定します.<BR>
	 * 
	 * @param font_name フォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setFontName2(String font_name) {
		setFontName(GReportXMLUtils.getXMLValidString(font_name));
	}

	/**
	 * フォントエンコーディングを設定します.<BR>
	 * 
	 * @param font_encoding フォントエンコーディング
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setFontEncoding2(String font_encoding) {
		setFontEncoding(GReportXMLUtils.getXMLValidString(font_encoding));
	}

	/**
	 * ボールドフォント名を設定します.<BR>
	 * 
	 * @param font_name ボールドフォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setFontNameBold2(String font_name) {
		setFontNameBold(GReportXMLUtils.getXMLValidString(font_name));
	}

	/**
	 * イタリックフォント名を設定します.<BR>
	 * 
	 * @param font_name イタリックフォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setFontNameItalic2(String font_name) {
		setFontNameItalic(GReportXMLUtils.getXMLValidString(font_name));
	}

	/**
	 * フォント名を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontName()
	 * @return フォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getFontName() {
		return _fontName;
	}

	/**
	 * ボールドフォント名を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontNameBold()
	 * @return ボールドフォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getFontNameBold() {
		return _fontNameBold;
	}

	/**
	 * イタリックフォント名を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontNameItalic()
	 * @return イタリックフォント名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getFontNameItalic() {
		return _fontNameItalic;
	}

	/**
	 * フォントエンコーディングを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontEncoding()
	 * @return フォントエンコーディング
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getFontEncoding() {
		return _fontEncoding;
	}

	/**
	 * フォント間隔高さを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontIntervalHeight()
	 * @return フォント間隔高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontIntervalHeight() {
		return _font_height;
	}

	/**
	 * フォント間隔高さを設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontIntervalHeight(int)
	 * @param fontIntervalHeight フォント間隔高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontIntervalHeight(int fontIntervalHeight) {
		_font_height = fontIntervalHeight;
	}

	/**
	 * フォント間隔幅を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#getFontIntervalWidth()
	 * @return フォント間隔幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontIntervalWidth() {
		return _font_interval;
	}

	/**
	 * フォント間隔幅を設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IFieldInfo#setFontIntervalWidth(int)
	 * @param fontIntervalWidth フォント間隔幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontIntervalWidth(int fontIntervalWidth) {
		_font_interval = fontIntervalWidth;
	}
}
