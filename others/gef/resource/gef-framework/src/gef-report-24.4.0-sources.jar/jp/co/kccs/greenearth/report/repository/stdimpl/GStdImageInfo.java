/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GNumberUtils;
import jp.co.kccs.greenearth.report.repository.IBarcodeInfo;
import jp.co.kccs.greenearth.report.repository.IImageInfo;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】イメージ情報を表します。<BR>
 * 【生成】GRepositoryFactory により XMLファイルごとに生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】XML情報を元に生成した情報です。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdImageInfo implements IImageInfo {

	/** 名称 */
	private String _name = null;
	/** 値 */
	private String _value = null;
	/** タイプ */
	private String _type = null;
	/** 上 */
	private int _top = -1;
	/** 左 */
	private int _left = -1;
	/** 幅 */
	private int _width = -1;
	/** 高さ */
	private int _height = -1;
	/** バーコードタイプ */
	private int _barcode_type = 2;
	/** 表示 */
	private boolean _is_output = true;
	/** バーコード詳細情報 */
	private IBarcodeInfo _barcode_info = null;

	/**
	 * XMLから項目をロードします.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#load(org.w3c.dom.Node)
	 * @param node 
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void load(Node node) {
		
		if (node == null) {
			return;
		}

		NodeList list = node.getChildNodes();
		
		for (int i = 0; i < list.getLength(); i++) {
			
			if (list.item(i).getNodeType() == 3) {
				continue;
			}

			String nodeName = list.item(i).getNodeName();
			String value = null;
			if (list.item(i).getChildNodes().getLength() == 0) {
				value = "";
			} else {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}
			if (nodeName.equals("Name")) {
				setName(value);
			} else if (nodeName.equals("Type")) {
				setType(value);
			} else if (nodeName.equals("Value")) {
				setValue(value);
			} else if (nodeName.equals("Top")) {
				setTop(value);
			} else if (nodeName.equals("Left")) {
				setLeft(value);
			} else if (nodeName.equals("Width")) {
				setWidth(value);
			} else if (nodeName.equals("Height")) {
				setHeight(value);
			} else if (nodeName.equals("IsOutput")) {
				setOutput(value);
			} else if (nodeName.equals("BarcodeType")) {
				setBarcodeType(value);
			} else if (nodeName.equals("BarcodeInfo")) {
				setBarcodeInfo(createBarcodeInfo(list.item(i), getBarcodeType()));
			}
		}
	}

	/**
	 * 高さを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setHeight(String height) {
		setHeight(GNumberUtils.toInteger(height, 0));
	}

	/**
	 * Sets the height.
	 * 
	 * @param height 
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setHeight(int height) {
		this._height = height;
	}

	/**
	 * 高さを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getHeight()
	 * @return _height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getHeight() {
		return _height;
	}

	/**
	 * 左を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLeft(String left) {
		setLeft(GNumberUtils.toInteger(left, 0));
	}

	/**
	 * Sets the left.
	 * 
	 * @param left 
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setLeft(int left) {
		this._left = left;
	}

	/**
	 * 左位置を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getLeft()
	 * @return _left 左位置
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getLeft() {
		return _left;
	}

	/**
	 * Sets the name.
	 * 
	 * @param name 
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * 名前を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getName()
	 * @return _name 名前
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * Sets the name.
	 * 
	 * @param value 
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setValue(String value) {
		_value = value;
	}

	/**
	 * 値を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getValue()
	 * @return _value 値
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getValue() {
		return _value;
	}

	/**
	 * 上を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	void setTop(String top) {
		setTop(GNumberUtils.toInteger(top, 0));
	}

	/**
	 * Sets the top.
	 * 
	 * @param top 
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setTop(int top) {
		this._top = top;
	}

	/**
	 * 上位置を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getTop()
	 * @return _top 上位置
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getTop() {
		return _top;
	}

	/**
	 * 幅を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setWidth(String width) {
		setWidth(GNumberUtils.toInteger(width, 0));
	}

	/**
	 * Sets the width.
	 * 
	 * @param width 
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setWidth(int width) {
		this._width = width;
	}

	/**
	 * 幅を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getWidth()
	 * @return _width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getWidth() {
		return _width;
	}

	/**
	 * タイプを設定します.<BR>
	 * 
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setType(String type) {
		_type = type;
	}

	/**
	 * タイプを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getType()
	 * @return _type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getType() {
		return _type;
	}

	/**
	 * 出力要否を設定します。<BR>
	 * デフォールト値はtrue。<BR>
	 * 
	 * @param bool 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	void setOutput(String bool) {
		setOutput(GBooleanUtils.toBoolean(bool, true));
	}

	/**
	 * 出力要否を設定します.<BR>
	 * 
	 * @param bool 出力要否
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setOutput(boolean bool) {
		_is_output = bool;
	}

	/**
	 * 出力要否を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getOutput()
	 * @return _is_output 出力要否
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean getOutput() {
		return _is_output;
	}

	/**
	 * バーコードタイプを設定します.<BR>
	 * 
	 * @param barcode_type 
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setBarcodeType(String barcode_type) {
		if (barcode_type.equals("128")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_128);
		} else if (barcode_type.equals("39")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_39);
		} else if (barcode_type.equals("codabar")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_CODABAR);
		} else if (barcode_type.equals("ean")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_EAN);
		} else if (barcode_type.equals("inter25")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_INTER25);
		} else if (barcode_type.equals("postnet")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_POSTNET);
		} else if (barcode_type.equals("qr")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_QR);
		} else if (barcode_type.equals("pdf417")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_PDF417);
		} else if (barcode_type.equals("eansupp")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_EAN_SUPP);
		} else if (barcode_type.equals("ean128")) {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_EAN_128);
		} else {
			setBarcodeType(IBarcodeInfo.BARCODE_TYPE_39);
		}
	}

	/**
	 * バーコードタイプを設定します.<BR>
	 * 
	 * @param barcode_type バーコードタイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setBarcodeType(int barcode_type) {
		_barcode_type = barcode_type;
	}

	/**
	 * バーコードタイプを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getBarcodeType()
	 * @return _barcode_type バーコードタイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getBarcodeType() {
		return _barcode_type;
	}

	/**
	 * バーコード情報を設定します.<BR>
	 * 
	 * @param barcode_info バーコード情報
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setBarcodeInfo(IBarcodeInfo barcode_info) {
		_barcode_info = barcode_info;
	}

	/**
	 * バーコード情報を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IImageInfo#getBarcodeInfo()
	 * @return _barcode_info バーコード情報
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public IBarcodeInfo getBarcodeInfo() {
		return _barcode_info;
	}

	/**
	 * バーコード情報を作成します.<BR>
	 * 
	 * @param node ノード
	 * @param type タイプ
	 * @return barcode バーコード情報
	 * @create 
	 * @author 
	 * @since 
	 */
	protected IBarcodeInfo createBarcodeInfo(Node node, int type) {
		IBarcodeInfo barcode = GFrameworkUtils.getComponent(IBarcodeInfo.class.getName());
		barcode.load(node, type);
		return barcode;
	}
}
