/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import jp.co.kccs.greenearth.report.repository.ILineDashInfo;

/**
 * 【役割】ダッシュライン情報を表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/06/09
 * @author kusakari
 * @since 1.0.2
 */
public class GStdLineDashInfo implements ILineDashInfo {
	
	/** ユニッツオン */
	private int _units_on = 2;
	/** フェーズ */
	private int _phase = 2;

	/**
	 * ユニッツオンを設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineDashInfo#setUnitsOn(int)
	 * @param units_on ユニッツオン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setUnitsOn(int units_on) {
		_units_on = units_on;
	}

	/**
	 * ユニッツオンを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineDashInfo#getUnitsOn()
	 * @return int ユニッツオン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getUnitsOn() {
		return _units_on;
	}

	/**
	 * フェーズを設定します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineDashInfo#setPhase(int)
	 * @param phase フェーズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setPhase(int phase) {
		_phase = phase;
	}

	/**
	 * フェーズを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineDashInfo#getPhase()
	 * @return int フェーズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getPhase() {
		return _phase;
	}
}
