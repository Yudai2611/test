/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import java.awt.Color;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GNumberUtils;
import jp.co.kccs.greenearth.report.repository.ILineDashInfo;
import jp.co.kccs.greenearth.report.repository.ILineInfo;
import jp.co.kccs.greenearth.report.utility.GColor;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】ライン情報を表します。<BR>
 * 【生成】GRepositoryFactory により XMLファイルごとに生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】XML情報を元に生成した情報です。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdLineInfo implements ILineInfo {

	/** 名称 */
	private String _name = null;
	/** タイプ */
	private int _type = ILineInfo.TYPE_SOLID;
	/** 上 */
	private int _top = 0;
	/** 左 */
	private int _left = 0;
	/** 幅 */
	private int _width = 0;
	/** 高さ */
	private int _height = 0;
	/** 線幅 */
	private double _line_width = 0;
	/** 表示 */
	private boolean _is_output = true;
	/** カラー */
	private Color _color = GColor.black;
	/** カスタム点線情報 */
	private ILineDashInfo _custom_dash = null;

	/** 二重線フラグ */
	private boolean _isDouble = false;

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#load(org.w3c.dom.Node)
	 * @param node ノード
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void load(Node node) {
		
		if (node == null) {
			return;
		}

		NodeList list = node.getChildNodes();
		
		for (int i = 0; i < list.getLength(); i++) {
			
			if (list.item(i).getNodeType() == 3) {
				continue;
			}

			String nodeName = list.item(i).getNodeName();
			String value = "";
			if (list.item(i).getChildNodes().getLength() > 0) {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}

			if (nodeName.equals("Name")) {
				setName(value);
			} else if (nodeName.equals("Height")) {
				setHeight(value);
			} else if (nodeName.equals("Width")) {
				setWidth(value);
			} else if (nodeName.equals("Left")) {
				setLeft(value);
			} else if (nodeName.equals("Top")) {
				setTop(value);
			} else if (nodeName.equals("Type")) {
				setType(value);
			} else if (nodeName.equals("IsOutput")) {
				setOutput(value);
			} else if (nodeName.equals("LineWidth")) {
				setLineWidth(value);
			} else if (nodeName.equals("Dash")) {
				setDash(value);
			} else if (nodeName.equals("Gap")) {
				setGap(value);
			} else if (nodeName.equals("Double")) {
				setDouble(value);
			}
		}
	}

	/**
	 * 【機能】カラーを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param color カラー
	 * @create 2004/06/01
	 * @author 
	 * @since 1.0.1
	 */
	public void setColor(Color color) {
		_color = color;
	}

	/**
	 * 【機能】カラーを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return カラー
	 * @create 2004/06/01
	 * @author 
	 * @since 1.0.1
	 */
	public Color getColor() {
		return _color;
	}

	/**
	 * 線幅を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param lineWidth 線幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLineWidth(String lineWidth) {
		setLineWidth(GNumberUtils.toDouble(lineWidth, 0D));
	}

	/**
	 * 線幅を設定します。<BR>
	 * 
	 * @param lineWidth 線幅
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setLineWidth(double lineWidth) {
		this._line_width = lineWidth;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getLineWidth()
	 * @return 線幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public double getLineWidth() {
		return _line_width;
	}

	/**
	 * 高さを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setHeight(String height) {
		setHeight(GNumberUtils.toInteger(height, 0));
	}

	/**
	 * 高さを設定します。<BR>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setHeight(int height) {
		this._height = height;
	}

	/**
	 * 高さを取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getHeight()
	 * @return 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getHeight() {
		return _height;
	}

	/**
	 * 名称を設定します。<BR>
	 * 
	 * @param name 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setName(String name) {
		this._name = name;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getName()
	 * @return 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * 左を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLeft(String left) {
		setLeft(GNumberUtils.toInteger(left, 0));
	}

	/**
	 * 左を設定します。<BR>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setLeft(int left) {
		this._left = left;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getLeft()
	 * @return 左
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getLeft() {
		return _left;
	}

	/**
	 * 上を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	void setTop(String top) {
		setTop(GNumberUtils.toInteger(top, 0));
	}

	/**
	 * 上を設定します。<BR>
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setTop(int top) {
		this._top = top;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getTop()
	 * @return 上
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getTop() {
		return _top;
	}

	/**
	 * 幅を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setWidth(String width) {
		setWidth(GNumberUtils.toInteger(width, 0));
	}

	/**
	 * 幅を設定します。<BR>
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setWidth(int width) {
		this._width = width;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getWidth()
	 * @return 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getWidth() {
		return _width;
	}

	/**
	 * 表示を設定します。<BR>
	 * デフォールト値はtrue。<BR>
	 * 
	 * @param bool 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	void setOutput(String bool) {
		setOutput(GBooleanUtils.toBoolean(bool, true));
	}

	/**
	 * 表示を設定します。<BR>
	 * 
	 * @param bool 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setOutput(boolean bool) {
		_is_output = bool;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getOutput()
	 * @return 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean getOutput() {
		return _is_output;
	}

	/**
	 * 【機能】点線情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param info 点線情報
	 * @create 2004/08/31
	 * @author 
	 * @since 1.0.3
	 */
	public void setDashInfo(ILineDashInfo info) {
		_custom_dash = info;
	}

	/**
	 * 【機能】点線情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getDashInfo()
	 * @return カスタム点線情報
	 * @create 2004/08/31
	 * @author 
	 * @since 1.0.3
	 */
	@Override
	public ILineDashInfo getDashInfo() {
		return _custom_dash;
	}

	/**
	 * タイプを設定します。<BR>
	 * 
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setType(String type) {
		if ("dash".equals(type)) {
			setType(ILineInfo.TYPE_DASH);
		} else if ("dot".equals(type)) {
			setType(ILineInfo.TYPE_DOT);
		} else if ("double".equals(type)) {
			setType(ILineInfo.TYPE_DOUBLE);
		} else if ("customdash".equals(type)) {
			setType(ILineInfo.TYPE_CUSTOM_DASH);
		} else {
			setType(ILineInfo.TYPE_SOLID);
		}
	}

	/**
	 * タイプを設定します。<BR>
	 * 
	 * @param type タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setType(int type) {
		_type = type;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getType()
	 * @return タイプ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getType() {
		return _type;
	}

	/**
	 * ダッシュを設定します。<BR>
	 * デフォールト値は2。<BR>
	 * 
	 * @param dash ダッシュ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setDash(String dash) {
		setDash(GNumberUtils.toInteger(dash, 2));
	}

	/**
	 * 【機能】Dashを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param dash ダッシュ
	 * @create 2004/08/31
	 * @author yamashita
	 * @since 1.0.3
	 */
	public void setDash(int dash) {
		if (_custom_dash == null) {
			_custom_dash = createLineDashInfo();
		}
		_custom_dash.setUnitsOn(dash);
	}

	/**
	 * フェーズを設定します。<BR>
	 * デフォールト値は2。<BR>
	 * 
	 * @param gap フェーズ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setGap(String gap) {
		setGap(GNumberUtils.toInteger(gap, 2));
	}

	/**
	 * 【機能】Gapを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param gap フェーズ
	 * @create 2004/08/31
	 * @author 
	 * @since 1.0.3
	 */
	public void setGap(int gap) {
		if (_custom_dash == null) {
			_custom_dash = createLineDashInfo();
		}
		_custom_dash.setPhase(gap);
	}

	/**
	 * 二重線フラグを設定します。<BR>
	 * デフォールト値はfalse。<BR>
	 * 
	 * @param flag 二重線フラグ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setDouble(String flag) {
		setDouble(GBooleanUtils.toBoolean(flag, false));
	}

	/**
	 * 【機能】二重線フラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#setDouble(boolean)
	 * @param flag 二重線フラグ
	 * @create 2006/09/24
	 * @author 
	 * @since 1.2.0
	 */
	@Override
	public void setDouble(boolean flag) {
		_isDouble = flag;
	}

	/**
	 * 【機能】二重線フラグを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ILineInfo#getDouble()
	 * @return 二重線フラグ
	 * @create 2006/09/24
	 * @author 
	 * @since 1.2.0
	 */
	@Override
	public boolean getDouble() {
		return _isDouble;
	}

	/**
	 * ダッシュライン情報を生成します。<BR>
	 * 
	 * @return ダッシュライン情報
	 * @create 
	 * @author 
	 * @since 
	 */
	protected ILineDashInfo createLineDashInfo() {
		return GFrameworkUtils.getComponent(ILineDashInfo.class.getName());
	}
}
