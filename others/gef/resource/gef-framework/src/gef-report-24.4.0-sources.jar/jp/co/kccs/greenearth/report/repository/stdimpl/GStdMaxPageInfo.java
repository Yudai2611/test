/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import jp.co.kccs.greenearth.report.repository.IMaxPageInfo;

/**
 * 【役割】最大ページ情報を表します。<BR>
 * 【生成】レポートドライバによりリクエストごとに生成されます。<BR>
 * 【解放】レポート印刷後に解放されます。<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdMaxPageInfo implements IMaxPageInfo {

	/** 幅 */
	private float _width = 0;
	/** 高さ */
	private float _height = 0;
	/** 上端 */
	private int _top = 0;
	/** フォントサイズ*/
	private int _font_size = -1;
	/** フォントズーム */
	private int _font_zoom = 0;
	/** フォントインターバル */
	private int _font_interval = 0;
	/** フォント高さ*/
	private int _font_height = 0;
	/** フォントフェイス */
	private int _font_face = 0;
	/** アライン */
	private String _align = null;
	/** フォーマット*/
	private String _format = null;

	/**
	 * 幅を設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setWidth(float)
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setWidth(float width) {
		_width = width;
	}

	/**
	 * 幅を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getWidth()
	 * @return 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public float getWidth() {
		return _width;
	}

	/**
	 * 高さを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setHeight(float)
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setHeight(float height) {
		_height = height;
	}

	/**
	 * 高さを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getHeight()
	 * @return 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public float getHeight() {
		return _height;
	}

	/**
	 * 上端を設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setTop(int)
	 * @param top 上端
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setTop(int top) {
		_top = top;
	}

	/**
	 * 上端を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getTop()
	 * @return 上端
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getTop() {
		return _top;
	}

	/**
	 * フォントサイズを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setFontSize(int)
	 * @param font_size フォントサイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontSize(int font_size) {
		_font_size = font_size;
	}

	/**
	 * フォントサイズを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getFontSize()
	 * @return フォントサイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontSize() {
		return _font_size;
	}

	/**
	 * フォントズームを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setFontZoom(int)
	 * @param font_zoom フォントズーム
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontZoom(int font_zoom) {
		_font_zoom = font_zoom;
	}

	/**
	 * フォントズームを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getFontZoom()
	 * @return フォントズーム
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontZoom() {
		return _font_zoom;
	}

	/**
	 * フォントフェイスを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setFontFace(int)
	 * @param font_face フォントフェイス
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontFace(int font_face) {
		_font_face = font_face;
	}

	/**
	 * フォントフェイスを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getFontFace()
	 * @return フォントフェイス
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontFace() {
		return _font_face;
	}

	/**
	 * アラインを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setAlignment(java.lang.String)
	 * @param align アライン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setAlignment(String align) {
		_align = align;
	}

	/**
	 * アラインを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getAlignment()
	 * @return アライン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getAlignment() {
		return _align;
	}

	/**
	 * フォーマットを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setFormat(java.lang.String)
	 * @param format フォーマット
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * フォーマットを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getFormat()
	 * @return フォーマット
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getFormat() {
		return _format;
	}

	/**
	 * フォントインターバルを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setFontInterval(int)
	 * @param font_interval フォントインターバル
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontInterval(int font_interval) {
		_font_interval = font_interval;
	}

	/**
	 * フォントインターバルを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getFontInterval()
	 * @return フォントインターバル
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontInterval() {
		return _font_interval;
	}

	/**
	 * フォント高さを設定します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#setFontHeight(int)
	 * @param font_height フォント高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontHeight(int font_height) {
		_font_height = font_height;
	}

	/**
	 * フォント高さを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IMaxPageInfo#getFontHeight()
	 * @return フォント高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontHeight() {
		return _font_height;
	}
}
