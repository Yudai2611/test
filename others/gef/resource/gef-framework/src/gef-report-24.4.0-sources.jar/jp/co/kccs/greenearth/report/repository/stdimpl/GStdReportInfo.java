/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GNumberUtils;
import jp.co.kccs.greenearth.report.repository.IControlBreakInfo;
import jp.co.kccs.greenearth.report.repository.IReportInfo;
import jp.co.kccs.greenearth.report.repository.ISectionInfo;
import jp.co.kccs.greenearth.report.utility.GReportXMLUtils;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】レポート情報を表します。<BR>
 * 【生成】GRepositoryFactory により XMLファイルごとに生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】XML情報を元に生成した情報です。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdReportInfo implements IReportInfo {

	/** タグ 上マージン */
	private static final String TAG_TOP_MARGIN = "TopMargin";
	/** タグ 下マージン */
	private static final String TAG_BOTTOM_MARGIN = "BottomMargin";
	/** タグ 左マージン */
	private static final String TAG_LEFT_MARGIN = "LeftMargin";
	/** タグ 右マージン */
	private static final String TAG_RIGHT_MARGIN = "RightMargin";
	/** タグ VEのオブジェクトID */
	private static final String TAG_VE_OBJECT_ID = "VEObjectID";
	/** タグ ブレイク情報 */
	private static final String TAG_CONTROL_BREAK_KEY_INFO = "ControlBreakKeyInfo";
	/** タグ セクション情報 */
	private static final String TAG_SECTION_INFO = "SectionInfo";
	/** タグ バージョン */
	private static final String TAG_VERSION = "Version";
	/** タグ 用紙の縦横 */
	private static final String TAG_ORIENTATION = "Orientation";
	/** タグ 用紙サイズ */
	private static final String TAG_PAPER_SIZE = "PaperSize";
	/** タグ フォントサイズ */
	private static final String TAG_FONT_SIZE = "FontSize";
	/** タグ 並べ */
	private static final String TAG_ALINMENT = "Alignment";
	/** タグ 外部キー */
	private static final String TAG_FOREIGN_KEY = "ForeignKey";
	/** タグ ベースポジション */
	private static final String TAG_BASE_POSITION = "BasePosition";
	/** タグ 文字と線の縦の幅 */
	private static final String TAG_ROW_PAD = "RowPad";
	/** 文字と線の縦の幅 */
	private static final String TAG_COL_PAD = "ColumnPad";
	/** タグ 印刷方向 */
	private static final String TAG_PRINT_DIRECTION = "PrintDirection";
	/** タグ 列数 */
	private static final String TAG_COLUMN_COUNT = "ColumnCount";
	/** タグ 行数 */
	private static final String TAG_ROW_COUNT = "RowCount";
	/** タグ フォント名 */
	private static final String TAG_FONT_NAME = "FontName";
	/** タグ フォント名(Bold) */
	private static final String TAG_FONT_NAME_BOLD = "FontNameBold";
	/** タグ フォント名(Italic) */
	private static final String TAG_FONT_NAME_ITALIC = "FontNameItalic";
	/** タグ フォントエンコーディング */
	private static final String TAG_FONT_ENCODING = "FontEncoding";
	/** タグ 名称 */
	private static final String TAG_NAME = "Name";
	/** タグ 外部フォントファイル */
	private static final String TAG_USE_FONT_FILE = "UseFontFile"; // 1.5.0

	/** ベースポジション */
	private int _base_position = 0;
	/** VEのオブジェクトID */
	private String _ve_object_id = null;
	/** 名称 */
	private String _name = null;
	/** オブジェクトID */
	private String _object_id = null;
	/** 用紙の縦横 */
	private String _orientation = null;
	/** 位置 */
	private String _position = null;
	/** バージョン */
	private String _version = null;
	/** 用紙サイズ */
	private String _paper_size = null;
	/** 並べ */
	private String _alinement = null;

	/** 上マージン */
	private int _top_margin = 0;
	/** 左マージン */
	private int _left_margin = 0;
	/** 右マージン */
	private int _right_margin = 0;
	/** 下マージン */
	private int _bottom_margin = 0;
	/** 文字と線の縦の幅 */
	private int _row_pad = 0;
	/** 文字と線の横の幅 */
	private int _col_pad = 0;
	/** フォントサイズ */
	private int _font_size = 8;
	/** 印刷方向 */
	private int _print_direction = IReportInfo.PRINT_DIRECTION_VIRTICAL;
	/** セクション情報の配列 */
	private Map<String, ISectionInfo> _section_map = new HashMap<String, ISectionInfo>();
	/** ブレイク情報配列 */
	private List<IControlBreakInfo> _control_break_list = new ArrayList<IControlBreakInfo>();
	/** 外部キーリスト */
	private List<String> _foreign_key_list = new ArrayList<String>();

	/** 列数 */
	private int _column_count = 0;
	/** 行数 */
	private int _row_count = 0;
	/** フォント名 */
	private String _font_name = null;

	/** フォント名(Bold) */
	private String _font_name_bold = null;
	/** フォント名(Italic) */
	private String _font_name_italic = null;

	/** 外部フォントファイル */
	private String _use_font_file = null;

	/** フォントエンコーディング */
	private String _font_encoding = null;

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#load(org.w3c.dom.Node, java.lang.String)
	 * @param node ノード
	 * @param name 名前
	 */
	@Override
	public void load(Node node, String name) {
		load(node);
		setName(name);
	}

	/**
	 * ノードをロードします。<BR>
	 * 
	 * @param node ノード
	 * @create 
	 * @author 
	 * @since 
	 */
	public void load(Node node) {
		
		if (node == null) {
			return;
		}

		_section_map = new HashMap<String, ISectionInfo>();
		_control_break_list = new ArrayList<IControlBreakInfo>();
		_foreign_key_list = new ArrayList<String>();

		NodeList list = node.getChildNodes();
		
		for (int i = 0; i < list.getLength(); i++) {
			
			if (list.item(i).getNodeType() == 3) {
				continue;
			}
			
			String tagName = list.item(i).getNodeName();

			String value = "";
			if (list.item(i).getChildNodes().getLength() > 0) {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}

			if (tagName.equals(TAG_TOP_MARGIN)) {
				setTopMargin(value);
			} else if (tagName.equals(TAG_LEFT_MARGIN)) {
				setLeftMargin(value);
			} else if (tagName.equals(TAG_RIGHT_MARGIN)) {
				setRightMargin(value);
			} else if (tagName.equals(TAG_BOTTOM_MARGIN)) {
				setBottomMargin(value);
			} else if (tagName.equals(TAG_VE_OBJECT_ID)) {
				setVEObjectIDAdapter(value);
			} else if (tagName.equals(TAG_VERSION)) {
				setVersion(value);
			} else if (tagName.equals(TAG_ORIENTATION)) {
				setOrientation(value);
			} else if (tagName.equals(TAG_PAPER_SIZE)) {
				setPaperSize(value);
			} else if (tagName.equals(TAG_FONT_SIZE)) {
				setFontSize(value);
			} else if (tagName.equals(TAG_ALINMENT)) {
				setAlignment(value);
			} else if (tagName.equals(TAG_FOREIGN_KEY)) {
				setForeignKey(value);
			} else if (tagName.equals(TAG_BASE_POSITION)) {
				setBasePosition(value);
			} else if (tagName.equals(TAG_ROW_PAD)) {
				setRowPad(value);
			} else if (tagName.equals(TAG_COL_PAD)) {
				setColPad(value);
			} else if (tagName.equals(TAG_PRINT_DIRECTION)) {
				setPrintDirection(value);
			} else if (tagName.equals(TAG_COLUMN_COUNT)) {
				setColumnCount(value);
			} else if (tagName.equals(TAG_ROW_COUNT)) {
				setRowCount(value);
			} else if (tagName.equals(TAG_FONT_NAME)) {
				setFontNameAdapter(value);
			} else if (tagName.equals(TAG_FONT_ENCODING)) {
				setFontEncodingAdapter(value);
			} else if (tagName.equals(TAG_FONT_NAME_BOLD)) {
				setFontNameBoldAdapter(value);
			} else if (tagName.equals(TAG_FONT_NAME_ITALIC)) {
				setFontNameItalicAdapter(value);
			} else if (tagName.equals(TAG_USE_FONT_FILE)) {
				setUseFontFile(value);
			} else if (tagName.equals(TAG_CONTROL_BREAK_KEY_INFO)) {
				if (list.item(i).getChildNodes().getLength() == 0) {
					continue;
				}
				final IControlBreakInfo breakInfo = createControlBreakInfo(list.item(i));
				this.addBreakInfo(breakInfo);
			} else if (tagName.equals(TAG_SECTION_INFO)) {
				if (list.item(i).getChildNodes().getLength() == 0) {
					continue;
				}
				final ISectionInfo section = createSectionInfo(list.item(i));
				this.addSectionInfo(section);
			} else if (tagName.equals(TAG_NAME)) {
				setName(value);
			}
		}
	}

	/**
	 * コントロールプレイク情報を作成します.<br>
	 * 
	 * @param node ノード
	 * @return コントロールブレイク情報
	 * @create 
	 * @author 
	 * @since 
	 */
	protected IControlBreakInfo createControlBreakInfo(Node node) {
		IControlBreakInfo breakInfo = GFrameworkUtils.getComponent(IControlBreakInfo.class.getName());
		breakInfo.load(node);
		return breakInfo;
	}
	
	/**
	 * セクション情報を作成します.<br>
	 * 
	 * @param node ノード
	 * @return セクション情報
	 * @create 
	 * @author 
	 * @since 
	 */
	protected ISectionInfo createSectionInfo(Node node) {
		ISectionInfo info = GFrameworkUtils.getComponent(ISectionInfo.class.getName());
		info.load(node);
		return info;
	}

	/**
	 * バージョンをセットします。<BR>
	 * 
	 * @param version バージョン
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setVersion(String version) {
		this._version = version;
	}

	/**
	 * 
	 * 
	 * @return バージョン
	 * @create 
	 * @author 
	 * @since 
	 */
	public String getVersion() {
		return _version;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getSectionInfo(java.lang.String)
	 * @param section_name セクション名称
	 * @return セクション情報
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public ISectionInfo getSectionInfo(String section_name) {
		return getSectionMap().get(section_name);
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getSectionInfos()
	 * @return セクション情報の配列
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public ISectionInfo[] getSectionInfos() {
		Map<String, ISectionInfo> sectionMap = getSectionMap();
		ISectionInfo[] secInfos = new ISectionInfo[sectionMap.size()];

		Object[] keys = sectionMap.keySet().toArray();
		
		for (int i = 0; i < sectionMap.size(); i++) {
			secInfos[i] = sectionMap.get(keys[i]);
			secInfos[i].setName((String) keys[i]);
		}
		
		return secInfos;
	}

	/**
	 * 列数を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param column_count 列数
	 * @create 
	 * @author 
	 * @since 
	 */
	void setColumnCount(String column_count) {
		setColumnCount(GNumberUtils.toInteger(column_count, 0));
	}

	/**
	 * 列数をセットします。<BR>
	 * 
	 * @param column_count 列数
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setColumnCount(int column_count) {
		_column_count = column_count;
	}

	/**
	 * 列数を取得します.<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getColumnCount()
	 * @return 列数
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getColumnCount() {
		return _column_count;
	}

	/**
	 * 行数を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param row_count 行数
	 * @create 
	 * @author 
	 * @since 
	 */
	void setRowCount(String row_count) {
		setRowCount(GNumberUtils.toInteger(row_count, 0));
	}

	/**
	 * 行数をセットします。<BR>
	 * 
	 * @param row_count 行数
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setRowCount(int row_count) {
		_row_count = row_count;
	}

	/**
	 * 行数を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getRowCount()
	 * @return 行数
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getRowCount() {
		return _row_count;
	}

	/**
	 * 【機能】ブレイク情報を追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param breakInfo ブレイク情報
	 * @create 2004/04/01
	 * @author 
	 * @since 1.0.0
	 */
	protected final void addBreakInfo(IControlBreakInfo breakInfo) {
		_control_break_list.add(breakInfo);
	}

	/**
	 * 【機能】コントロールブレイク情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getControlBreakList()
	 * @return ブレイク情報配列
	 * @create 2004/04/01
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public List<IControlBreakInfo> getControlBreakList() {
		return _control_break_list;
	}

	/**
	 * オブジェクトIDを設定します。<BR>
	 * 
	 * @param _object_id オブジェクトID
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setObjectID(String _object_id) {
		this._object_id = _object_id;
	}

	/**
	 * オブジェクトIDを取得します。<BR>
	 * 
	 * @return オブジェクトID
	 * @create 
	 * @author 
	 * @since 
	 */
	public String getObjectID() {
		return _object_id;
	}

	/**
	 * 名称を設定します。<BR>
	 * 
	 * @param _name 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setName(String _name) {
		this._name = _name;
	}

	/**
	 * 名称を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getName()
	 * @return 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * VEのオブジェクトIDをセットします。<BR>
	 * デザイナ側では""指定の項目には「""\n」という文字が指定されているため、nullに置換しています。
	 * 
	 * @param ve_object_id VEのオブジェクトID
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setVEObjectIDAdapter(String ve_object_id) {
		setVEObjectID(GReportXMLUtils.getXMLValidString(ve_object_id));
	}

	/**
	 * VEのオブジェクトIDをセットします。<BR>
	 * 
	 * @param ve_object_id VEのオブジェクトID
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setVEObjectID(String ve_object_id) {
		_ve_object_id = ve_object_id;
	}

	/**
	 * VEのオブジェクトIDを取得します。<BR>
	 * 
	 * @return VEのオブジェクトID
	 * @create 
	 * @author 
	 * @since 
	 */
	public String getVEObjectID() {
		return _ve_object_id;
	}

	/**
	 * 位置を設定します。<BR>
	 * 
	 * @param _position 位置
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setPosition(String _position) {
		this._position = _position;
	}

	/**
	 * 位置を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getPosition()
	 * @return 位置
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getPosition() {
		return _position;
	}

	/**
	 * 【機能】印刷方向を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param print_direction 印刷方向
	 * @create 
	 * @author 
	 * @since 1.0.1
	 */
	private final void setPrintDirection(String print_direction) {
		if ("vertical".equals(print_direction)) {
			setPrintDirection(IReportInfo.PRINT_DIRECTION_VIRTICAL);
			return;
		}
		
		if ("horizontal".equals(print_direction)) {
			setPrintDirection(IReportInfo.PRINT_DIRECTION_HORIZONTAL);
			return;
		}

		setPrintDirection(IReportInfo.PRINT_DIRECTION_VIRTICAL);
	}

	/**
	 * 【機能】印刷方向を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param print_direction 印刷方向
	 * @create 
	 * @author 
	 * @since 1.0
	 */
	public final void setPrintDirection(int print_direction) {
		_print_direction = print_direction;
	}

	/**
	 * 【機能】印刷方向を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getPrintDirection()
	 * @return 印刷方向
	 * @create 
	 * @author 
	 * @since 1.0
	 */
	@Override
	public int getPrintDirection() {
		return _print_direction;
	}

	/**
	 * ベースポジションをセットします。<BR>
	 * 
	 * @param base_position ベースポジション
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setBasePosition(int base_position) {
		_base_position = base_position;
	}

	/**
	 * ベースポジションを取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getBasePosition()
	 * @return ベースポジション
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getBasePosition() {
		return _base_position;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getOrientation()
	 * @return 用紙の縦横
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getOrientation() {
		if ("vertical".equals(_orientation)) {
			return IReportInfo.ORIENT_VIRTICAL;
		} else {
			return IReportInfo.ORIENT_HORIZONTAL;
		}
	}

	/**
	 * 左マージンを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param leftMargin 左マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLeftMargin(String leftMargin) {
		setLeftMargin(GNumberUtils.toInteger(leftMargin, 0));
	}

	/**
	 * 左マージンを設定します.<br>
	 * 
	 * @param leftMargin 左マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setLeftMargin(int leftMargin) {
		this._left_margin = leftMargin;
	}

	/**
	 * 左マージンを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getLeftMargin()
	 * @return 左マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getLeftMargin() {
		return _left_margin;
	}

	/**
	 * 文字と線の縦の幅を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param row_pad 文字と線の縦の幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setRowPad(String row_pad) {
		setRowPad(GNumberUtils.toInteger(row_pad, 0));
	}

	/**
	 * 文字と線の縦の幅をセットします。<BR>
	 * 
	 * @param row_pad 文字と線の縦の幅
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setRowPad(int row_pad) {
		_row_pad = row_pad;
	}

	/**
	 * 文字と線の縦の幅を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getRowPad()
	 * @return 文字と線の縦の幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getRowPad() {
		return _row_pad;
	}

	/**
	 * 文字と線の横の幅を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param col_pad 文字と線の横の幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setColPad(String col_pad) {
		setColPad(GNumberUtils.toInteger(col_pad, 0));
	}

	/**
	 * 文字と線の横の幅をセットします。<BR>
	 * 
	 * @param col_pad 文字と線の横の幅
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setColPad(int col_pad) {
		_col_pad = col_pad;
	}

	/**
	 * 文字と線の横の幅を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getColPad()
	 * @return 文字と線の横の幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getColPad() {
		return _col_pad;
	}

	/**
	 * 右マージンを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param rightMargin 右マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	void setRightMargin(String rightMargin) {
		setRightMargin(GNumberUtils.toInteger(rightMargin, 0));
	}

	/**
	 * 右マージンを設定します。<BR>
	 * 
	 * @param rightMargin 右マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setRightMargin(int rightMargin) {
		this._right_margin = rightMargin;
	}

	/**
	 * 右マージンを取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getRightMargin()
	 * @return 右マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getRightMargin() {
		return _right_margin;
	}

	/**
	 * 下マージンを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param bottomMargin 下マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	void setBottomMargin(String bottomMargin) {
		setBottomMargin(GNumberUtils.toInteger(bottomMargin, 0));
	}

	/**
	 * 
	 * 
	 * @param bottomMargin 下マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setBottomMargin(int bottomMargin) {
		this._bottom_margin = bottomMargin;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getBottomMargin()
	 * @return 下マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getBottomMargin() {
		return _bottom_margin;
	}

	/**
	 * 上マージンを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param topMargin 上マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	void setTopMargin(String topMargin) {
		setTopMargin(GNumberUtils.toInteger(topMargin, 0));
	}

	/**
	 * 
	 * 
	 * @param topMargin 上マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setTopMargin(int topMargin) {
		this._top_margin = topMargin;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getTopMargin()
	 * @return 上マージン
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getTopMargin() {
		return _top_margin;
	}

	/**
	 * フォントサイズを設定します。<BR>
	 * デフォールト値は8。<BR>
	 * 
	 * @param fontSize フォントサイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setFontSize(String fontSize) {
		setFontSize(GNumberUtils.toInteger(fontSize, 8));
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#setFontSize(int)
	 * @param fontSize フォントサイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontSize(int fontSize) {
		this._font_size = fontSize;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getFontSize()
	 * @return フォントサイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getFontSize() {
		return _font_size;
	}

	/**
	 * 【機能】用紙サイズを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】1.0.3 より a4,800,600 のような形式に変わりました。<BR>
	 * 
	 * @param paper_size 用紙サイズ
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	public void setPaperSize(String paper_size) {
		_paper_size = paper_size;
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getPaperSize()
	 * @return 用紙サイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getPaperSize() {
		return _paper_size;
	}

	/**
	 * ベースポジションをセットします。<BR>
	 * 
	 * @param base_position ベースポジション
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setBasePosition(String base_position) {
		if ("nextline".equals(base_position)) {
			setBasePosition(IReportInfo.BASE_POSITION_NEXTLINE);
		} else {
			setBasePosition(IReportInfo.BASE_POSITION_ABSOLUTE);
		}
	}

	/**
	 * 用紙の縦横をセットします。<BR>
	 * 
	 * @param orientation 用紙の縦横
	 * @create 
	 * @author 
	 * @since 
	 */
	public final void setOrientation(String orientation) {
		this._orientation = orientation;
	}

	/**
	 * 並べをセットします。<BR>
	 * 
	 * @param align 並べ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setAlignment(String align) {
		this._alinement = align;
	}

	/**
	 * 並べを取得します。<BR>
	 * 
	 * @return 並べ
	 * @create 
	 * @author 
	 * @since 
	 */
	public String getAlignment() {
		return this._alinement;
	}

	/**
	 * 
	 * 
	 * @param foreign_key 外部キーリスト
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setForeignKey(String foreign_key) {
		this._foreign_key_list.add(foreign_key);
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getForeignKeyList()
	 * @return 外部キーリスト
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public List<String> getForeignKeyList() {
		if (_foreign_key_list.size() == 0) {
			return null;
		}
		
		return _foreign_key_list;
	}

	/**
	 * フォント名を設定します。<BR>
	 * デザイナ側では""指定の項目には「""\n」という文字が指定されているため、nullに置換しています。
	 * 
	 * @param font_name フォント名
	 * @create 2006/04/03
	 * @author kitamura
	 * @since 1.1.0
	 */
	private final void setFontNameAdapter(String font_name) {
		setFontName(GReportXMLUtils.getXMLValidString(font_name));
	}

	/**
	 * 【機能】フォント名を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#setFontName(java.lang.String)
	 * @param font_name フォント名
	 * @create 2005/01/04
	 * @author kusakari
	 * @since 1.1.0
	 */
	@Override
	public void setFontName(String font_name) {
		_font_name = font_name;
	}

	/**
	 * 【機能】フォント名を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getFontName()
	 * @return フォント名
	 * @create 2005/01/04
	 * @since 1.1.0
	 * @author kusakari
	 */
	@Override
	public String getFontName() {
		return _font_name;
	}

	/**
	 * フォント名(Bold)を設定します。<BR>
	 * デザイナ側では""指定の項目には「""\n」という文字が指定されているため、nullに置換しています。
	 * 
	 * @param font_name フォント名(Bold)
	 * @create 2008/08/01
	 * @author takaishi
	 * @since 1.4.1
	 */
	private final void setFontNameBoldAdapter(String font_name) {
		setFontNameBold(GReportXMLUtils.getXMLValidString(font_name));
	}

	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#setFontNameBold(java.lang.String)
	 * @param fontName フォント名(Bold)
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontNameBold(String fontName) {
		_font_name_bold = fontName;
	}

	/**
	 * 【機能】フォント名(Bold)を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getFontNameBold()
	 * @return フォント名(Bold)
	 * @create 2008/08/01
	 * @since 1.4.1
	 * @author takaishi
	 */
	@Override
	public String getFontNameBold() {
		return _font_name_bold;
	}

	/**
	 * フォント名(Italic)を設定します。<BR>
	 * デザイナ側では""指定の項目には「""\n」という文字が指定されているため、nullに置換しています。
	 * 
	 * @param font_name フォント名(Italic)
	 * @create 2008/08/01
	 * @author takaishi
	 * @since 1.4.1
	 */
	private final void setFontNameItalicAdapter(String font_name) {
		setFontNameItalic(GReportXMLUtils.getXMLValidString(font_name));
	}

	/**
	 * フォント名(Italic)を設定します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#setFontNameItalic(java.lang.String)
	 * @param fontName フォント名(Italic)
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setFontNameItalic(String fontName) {
		_font_name_italic = fontName;
	}

	/**
	 * 【機能】フォント名(Italic)を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getFontNameItalic()
	 * @return フォント名(Italic)
	 * @create 2008/08/01
	 * @since 1.4.1
	 * @author takaishi
	 */
	@Override
	public String getFontNameItalic() {
		return _font_name_italic;
	}

	/**
	 * 外部フォントファイル使用有無を設定します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#setUseFontFile(boolean)
	 * @param useFontFile 外部フォントファイル使用するか
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setUseFontFile(boolean useFontFile) {
		setUseFontFile(String.valueOf(useFontFile));
	}

	/**
	 * 外部フォントファイル使用有無を設定します。<BR>
	 * 
	 * @param use_font_file 外部フォントファイルパス
	 * @create 2009/01/05
	 * @author kyo
	 * @since 1.5.0
	 */
	private final void setUseFontFile(String use_font_file) {
		_use_font_file = use_font_file;
	}

	/**
	 * 外部フォントファイル使用有無を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#isUseFontFile()
	 * @return 外部フォントファイル使用するかどうか
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean isUseFontFile() {
		return GBooleanUtils.toBoolean(_use_font_file);
	}

	/**
	 * 【機能】外部フォントファイル使用有無を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getUseFontFile()
	 * @return 外部フォントファイルパス
	 * @create 2009/01/05
	 * @since 1.5.0
	 * @author kyo
	 */
	@Override
	public String getUseFontFile() {
		return _use_font_file;
	}

	/**
	 * フォントエンコーディングを設定します。<BR>
	 * デザイナ側では""指定の項目には「""\n」という文字が指定されているため、nullに置換しています。
	 * 
	 * @param font_encoding フォントエンコーディング
	 * @create 2006/04/03
	 * @author kitamura
	 * @since 1.1.0
	 */
	private final void setFontEncodingAdapter(String font_encoding) {
		setFontEncoding(GReportXMLUtils.getXMLValidString(font_encoding));
	}

	/**
	 * 【機能】フォントエンコーディングを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#setFontEncoding(java.lang.String)
	 * @param encoding フォントエンコーディング
	 * @create 2005/01/04
	 * @since 1.1.0
	 * @author kusakari
	 */
	@Override
	public final void setFontEncoding(String encoding) {
		_font_encoding = encoding;
	}

	/**
	 * 【機能】フォントエンコーディングを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#getFontEncoding()
	 * @return フォントエンコーディング
	 * @create 2005/01/04
	 * @since 1.1.0
	 * @author kusakari
	 */
	@Override
	public String getFontEncoding() {
		return _font_encoding;
	}

	/**
	 * 【機能】他の帳票レイアウト上のセクションを追加します。BR> 【戻値】<BR>
	 * 【備考】追加後は、GReportInfo#getSectionInfoおよび getSectionsにより<BR>
	 * 該当セクション情報を取得可能とします。<BR>
	 * その際のセクション名は、"レポートID\tセクション名"とします。
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.IReportInfo#appendSections(java.lang.String, jp.co.kccs.greenearth.report.repository.ISectionInfo[])
	 * @param report_id 他の帳票レイアウトのレポートID
	 * @param section_infos セクション情報の配列
	 * @create 2006/09/10
	 * @author takaishi
	 * @since 1.2.0
	 */
	@Override
	public void appendSections(String report_id, ISectionInfo[] section_infos) {
		if (section_infos == null || section_infos.length == 0) {
			return;
		}
		for (int i = 0; i < section_infos.length; i++) {
			if (section_infos[i] == null) {
				continue;
			}
			getSectionMap().put(report_id + '\t' + section_infos[i].getName(), section_infos[i]);
		}
	}

	/**
	 * セクション情報をセットします。<BR>
	 * 
	 * @param sectionInfo セクション情報
	 * @create 
	 * @author 
	 * @since 
	 */
	protected final void addSectionInfo(ISectionInfo sectionInfo) {
		getSectionMap().put(sectionInfo.getName(), sectionInfo);
	}

	/**
	 * セクションが格納されたマップを取得します.<br>
	 * 
	 * @return セクションのマップ
	 * @create 2014/12/19
	 * @author KCCS xie
	 * @since 2.0.0
	 */
	Map<String, ISectionInfo> getSectionMap() {
		if (_section_map == null) {
			_section_map = new HashMap<String, ISectionInfo>();
		}
		return _section_map;
	}
}
