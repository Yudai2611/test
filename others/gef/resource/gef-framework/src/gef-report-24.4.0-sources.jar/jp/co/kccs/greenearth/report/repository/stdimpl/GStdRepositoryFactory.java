/*
 * Copyright 2014-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.repository.IReportInfo;
import jp.co.kccs.greenearth.report.repository.IRepositoryFactory;

/**
 * 【役割】リポジトリファクトリを表します。<BR>
 * 【生成】レポートクラスによりリクストごとに生成されます。<BR>
 * 【解放】レポート印刷後に解放されます。<BR>
 * 【備考】<BR>
 *
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdRepositoryFactory implements IRepositoryFactory {

	/** レポート情報タグ名 */
	private final static String TAG_REPORT_INFO = "ReportInfo";
	/** レポート情報マップ */
	private Map<String, Document> _domcache = new HashMap<String, Document>();	// TODO: [2014/09][yamashita] できれば将来、ReportInfoのクローンを返却するようにすること

	/**
	 * 【機能】レポートIDからxmlファイルを解析し、Document を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param report_id レポートID
	 * @return レポート情報
	 * @throws GReportException ReportFramework例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public final Document loadXmlDocument(String report_id) throws GReportException {
		try {
			final DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			final String file_path = GFrameworkUtils.getProperty("geframe.report.XmlDirectory") + File.separator + report_id + ".xml";
			Document xmlDocument = builder.parse(new File(file_path));
			return xmlDocument;
		} catch (IOException | ParserConfigurationException | SAXException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】レポート情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.repository.IRepositoryFactory#get(java.lang.String)
	 * @param report_id レポートID
	 * @return レポート情報
	 * @throws GReportException ReportFramework例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public synchronized IReportInfo get(String report_id) throws GReportException {
		return create(report_id);	// マルチスレッドでアクセスされた場合を想定し、IReportInfoインスタンスは毎回新しく生成。※内部のレイアウトDOMはキャッシュされている。
	}

	/**
	 * 【機能】レポート情報を生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param report_id レポートID
	 * @return レポート情報
	 * @throws GReportException ReportFramework例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private final IReportInfo create(String report_id) throws GReportException {
		if (!getMap().containsKey(report_id)) {
			getMap().put(report_id, loadXmlDocument(report_id));
		}
		final Document doc = getMap().get(report_id);
		final NodeList report_node_list = doc.getElementsByTagName(TAG_REPORT_INFO);
		IReportInfo reportInfo = createReportInfo(report_node_list.item(0), report_id);

		return reportInfo;
	}

	/**
	 * ノードからレポート情報を生成します。<BR>
	 *
	 * @param node ノード
	 * @param name ネーム
	 * @return レポート情報
	 * @create
	 * @author
	 * @since
	 */
	protected IReportInfo createReportInfo(Node node, String name) {
		IReportInfo reportInfo = GFrameworkUtils.getComponent(IReportInfo.class.getName());
		reportInfo.load(node, name);
		return reportInfo;
	}

	/**
	 * 【機能】レポート情報のキャッシュをクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public synchronized final void clear() {
		getMap().clear();
	}

	/**
	 * 指定したレポートIDに関連付けられたレポート定義のキャッシュをクリアします。
	 *
	 * @param reportID
	 * @create 2014/12/15
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public void clear(String reportID) {
		if (getMap().containsKey(reportID)) {
			getMap().remove(reportID);
		}
	}

	/**
	 * マップを取得します.<br>
	 *
	 * @return セクションのマップ
	 * @create 2014/12/19
	 * @author KCCS xie
	 * @since 2.0.0
	 */
	Map<String, Document> getMap() {
		if (_domcache == null) {
			_domcache = new HashMap<String, Document>();
		}
		return _domcache;
	}
}
