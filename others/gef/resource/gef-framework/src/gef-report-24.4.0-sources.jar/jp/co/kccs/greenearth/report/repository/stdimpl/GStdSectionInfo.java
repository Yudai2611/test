/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GNumberUtils;
import jp.co.kccs.greenearth.report.repository.ICircleInfo;
import jp.co.kccs.greenearth.report.repository.IFieldInfo;
import jp.co.kccs.greenearth.report.repository.IImageInfo;
import jp.co.kccs.greenearth.report.repository.ILineInfo;
import jp.co.kccs.greenearth.report.repository.IRectangleInfo;
import jp.co.kccs.greenearth.report.repository.ISectionInfo;
import jp.co.kccs.greenearth.report.utility.GColor;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 【役割】セクション情報を表します。<BR>
 * 【生成】GRepositoryFactory により XMLファイルごとに生成されます。<BR>
 * 【解放】アプリケーションサーバ終了時、GStdRepositoryFactory.clear()のどちらかのタイミングで解放されます。<BR>
 * 【備考】XML情報を元に生成した情報です。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdSectionInfo implements ISectionInfo {

	/** 名称 */
	private String _name = null;
	/** 上 */
	private int _top = -1;
	/** 左 */
	private int _left = -1;
	/** 高さ */
	private int _height = -1;
	/** 幅 */
	private int _width = -1;
	/** 位置 */
	private int _base_position = 0;
	/** 出力フラグ */
	private boolean _is_output = true;
	/** 吹き出し*/
	private boolean _is_alternate = false;
	/** Fieldリスト */
	private List<Object> _fieldList = new ArrayList<Object>();
	/** Lineリスト */
	private List<Object> _lineList = new ArrayList<Object>();
	/** Imageリスト */
	private List<Object> _imageList = new ArrayList<Object>();
	/** Circleリスト */
	private List<Object> _circleList = new ArrayList<Object>();
	/** Rectangleリスト */
	private List<Object> _rec_list = new ArrayList<Object>();
	/** 背景色 */
	private Color _back_color = GColor.white;

	/**
	 * nodeをロードします。
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#load(org.w3c.dom.Node)
	 * @param node ノード
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void load(Node node) {
		
		if (node == null) {
			return;
		}

		_fieldList = new ArrayList<Object>();
		_lineList = new ArrayList<Object>();
		_imageList = new ArrayList<Object>();
		_circleList = new ArrayList<Object>();
		_rec_list = new ArrayList<Object>();

		NodeList list = node.getChildNodes();
		
		for (int i = 0; i < list.getLength(); i++) {
			
			if (list.item(i).getNodeType() == 3) {
				continue;
			}

			String nodeName = list.item(i).getNodeName();
			String value = "";
			
			if (list.item(i).getChildNodes().getLength() > 0) {
				value = list.item(i).getChildNodes().item(0).getNodeValue();
			}

			if (nodeName.equals("Name")) {
				setName(value);
			} else if (nodeName.equals("Top")) {
				setTop(value);
			} else if (nodeName.equals("Left")) {
				setLeft(value);
			} else if (nodeName.equals("Height")) {
				setHeight(value);
			} else if (nodeName.equals("Width")) {
				setWidth(value);
			} else if (nodeName.equals("BasePosition")) {
				setBasePosition(value);
			} else if (nodeName.equals("IsOutput")) {
				setOutput(value);
			} else if (nodeName.equals("Alternate")) {
				setAlternate(value);
			} else if (nodeName.equals("FieldInfo")) {
				if (list.item(i).getChildNodes().getLength() == 0) {
					continue;
				}
				final IFieldInfo field = createFieldInfo(list.item(i));
				addFieldInfo(field);
			} else if (nodeName.equals("LineInfo")) {
				if (list.item(i).getChildNodes().getLength() == 0) {
					continue;
				}
				final ILineInfo line = createLineInfo(list.item(i));
				addLineInfo(line);
			} else if (nodeName.equals("RectangleInfo")) {
				if (list.item(i).getChildNodes().getLength() == 0) {
					continue;
				}
				final IRectangleInfo rec = createRectangleInfo(list.item(i));
				addRectangleInfo(rec);
			} else if (nodeName.equals("CircleInfo")) {
				if (list.item(i).getChildNodes().getLength() == 0) {
					continue;
				}
				final ICircleInfo circle = createCircleInfo(list.item(i));
				addCircleInfo(circle);
			} else if (nodeName.equals("ImageInfo")) {
				if (list.item(i).getChildNodes().getLength() == 0) {
					continue;
				}
				final IImageInfo image = createImageInfo(list.item(i));
				addImageInfo(image);
			}
		}
	}

	/**
	 * フィールド情報を作成します.<br>
	 * 
	 * @param node ノード
	 * @return IFieldInfo IFieldInfo
	 * @create 
	 * @author 
	 * @since 
	 */
	protected IFieldInfo createFieldInfo(Node node) {
		IFieldInfo fieldInfo = GFrameworkUtils.getComponent(IFieldInfo.class.getName());
		fieldInfo.load(node);
		return fieldInfo;
	}

	/**
	 * 線情報を作成します.<br>
	 * 
	 * @param node ノード
	 * @return ILineInfo ILineInfo
	 * @create 
	 * @author 
	 * @since 
	 */
	protected ILineInfo createLineInfo(Node node) {
		ILineInfo lineInfo = GFrameworkUtils.getComponent(ILineInfo.class.getName());
		lineInfo.load(node);
		return lineInfo;

	}

	/**
	 * 四角情報を作成します.<br>
	 * 
	 * @param node ノード
	 * @return IRectangleInfo IRectangleInfo
	 * @create 
	 * @author 
	 * @since 
	 */
	protected IRectangleInfo createRectangleInfo(Node node) {
		IRectangleInfo rectangleInfo = GFrameworkUtils.getComponent(IRectangleInfo.class.getName());
		rectangleInfo.load(node);
		return rectangleInfo;

	}

	/**
	 * 円情報を作成します.<br>
	 * 
	 * @param node ノード
	 * @return ICircleInfo ICircleInfo
	 * @create 
	 * @author 
	 * @since 
	 */
	protected ICircleInfo createCircleInfo(Node node) {
		ICircleInfo circleInfo = GFrameworkUtils.getComponent(ICircleInfo.class.getName());
		circleInfo.load(node);
		return circleInfo;

	}

	/**
	 * イメージ情報を作成します.<br>
	 * 
	 * @param node ノード
	 * @return IImageInfo IImageInfo
	 * @create 
	 * @author 
	 * @since 
	 */
	protected IImageInfo createImageInfo(Node node) {
		IImageInfo imageInfo = GFrameworkUtils.getComponent(IImageInfo.class.getName());
		imageInfo.load(node);
		return imageInfo;
	}

	/**
	 * フィールド情報をリストに追加をします.<br>
	 * 
	 * @param fieldInfo Object
	 * @create: (2003/11/05 21:06:14)
	 * @author: nishiduka (Administrator)
	 * @since 
	 */
	public void addFieldInfo(Object fieldInfo) {
		_fieldList.add(fieldInfo);
	}

	/**
	 * フィールド情報のリストを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getFieldList()
	 * @return List _fieldList
	 * @create: (2003/11/05 21:06:14)
	 * @author: nishiduka (Administrator)
	 * @since 
	 */
	@Override
	public final List<Object> getFieldList() {
		return _fieldList;
	}

	/**
	 * イメージ情報をリストに追加をします.<br>
	 * 
	 * @param imageInfo Object
	 * @create: (2003/11/05 21:06:14)
	 * @author: nishiduka (Administrator)
	 * @since 
	 */
	public void addImageInfo(Object imageInfo) {
		_imageList.add(imageInfo);
	}

	/**
	 * イメージ情報のリストを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getImageList()
	 * @return List _imageList
	 * @create: (2003/11/05 21:06:14)
	 * @author: nishiduka (Administrator)
	 * @since 
	 */
	@Override
	public final List<Object> getImageList() {
		return _imageList;
	}

	/**
	 * 線情報をリストに追加をします.<br>
	 * 
	 * @param lineInfo Object
	 * @create: (2003/11/05 21:06:14)
	 * @author: nishiduka (Administrator)
	 * @since 
	 */
	public void addLineInfo(Object lineInfo) {
		_lineList.add(lineInfo);
	}

	/**
	 * 線情報のリストを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getLineList()
	 * @return List _lineList
	 * @create: (2003/11/05 21:06:14)
	 * @author: nishiduka (Administrator)
	 * @since 
	 */
	@Override
	public final List<Object> getLineList() {
		return _lineList;
	}

	/**
	 * 四角情報をリストに追加をします.<br>
	 * 
	 * @param rec_info Object
	 * @create 
	 * @author 
	 * @since 
	 */
	public void addRectangleInfo(Object rec_info) {
		_rec_list.add(rec_info);
	}

	/**
	 * 四角情報のリストを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getRectangleList()
	 * @return List _rec_list
	 * @since 
	 */
	@Override
	public final List<Object> getRectangleList() {
		return _rec_list;
	}

	/**
	 * 円情報をリストに追加をします.<br>
	 * 
	 * @param circle_info Object
	 * @create 
	 * @author 
	 * @since 
	 */
	public void addCircleInfo(Object circle_info) {
		_circleList.add(circle_info);
	}

	/**
	 * 円情報のリストを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getCircleList()
	 * @return List _circleList
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public final List<Object> getCircleList() {
		return _circleList;
	}

	/**
	 * 高さを設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	void setHeight(String height) {
		setHeight(GNumberUtils.toInteger(height, -1));
	}

	/**
	 * Sets the height.<br>
	 * 
	 * @param height 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setHeight(int height) {
		this._height = height;
	}

	/**
	 * 高さを取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getHeight()
	 * @return int 高さ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getHeight() {
		return _height;
	}

	/**
	 * 左を設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	void setLeft(String left) {
		setLeft(GNumberUtils.toInteger(left, -1));
	}

	/**
	 * Sets the left.<br>
	 * 
	 * @param left 左
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setLeft(int left) {
		this._left = left;
	}

	/**
	 * 左を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getLeft()
	 * @return int 左
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getLeft() {
		return _left;
	}

	/**
	 * Sets the name.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#setName(java.lang.String)
	 * @param name 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setName(String name) {
		this._name = name;
	}

	/**
	 * 名称を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getName()
	 * @return String 名称
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * 上を設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	void setTop(String top) {
		setTop(GNumberUtils.toInteger(top, -1));
	}

	/**
	 * Sets the top.
	 * 
	 * @param top 上
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setTop(int top) {
		this._top = top;
	}

	/**
	 * 上を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getTop()
	 * @return int 上
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getTop() {
		return _top;
	}

	/**
	 * 幅を設定します。<BR>
	 * デフォールト値は-1。<BR>
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	void setWidth(String width) {
		setWidth(GNumberUtils.toInteger(width, -1));
	}

	/**
	 * Sets the width.
	 * 
	 * @param width 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setWidth(int width) {
		this._width = width;
	}

	/**
	 * 幅を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getWidth()
	 * @return int 幅
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getWidth() {
		return _width;
	}

	/**
	 * Sets the BasePostion.
	 * 
	 * @param base_position String
	 * @create 
	 * @author 
	 * @since 
	 */
	private final void setBasePosition(String base_position) {
		if ("nextline".equals(base_position)) {
			setBasePosition(ISectionInfo.BASE_POSITION_NEXTLINE);
		} else {
			setBasePosition(ISectionInfo.BASE_POSITION_ABSOLUTE);
		}
	}

	/**
	 * Sets the BasePostion.
	 * 
	 * @param base_position 位置
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setBasePosition(int base_position) {
		_base_position = base_position;
	}

	/**
	 * 位置を取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getBasePosition()
	 * @return int 位置
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int getBasePosition() {
		return _base_position;
	}

	/**
	 * 表示を設定します。<BR>
	 * デフォールト値はtrue。<BR>
	 * 
	 * @param bool 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	void setOutput(String bool) {
		setOutput(GBooleanUtils.toBoolean(bool, true));
	}

	/**
	 * 表示を設定します。<BR>
	 * 
	 * @param bool 出力フラグ
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setOutput(boolean bool) {
		_is_output = bool;
	}

	/**
	 * 表示を取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getOutput()
	 * @return boolean 出力フラグ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean getOutput() {
		return _is_output;
	}

	/**
	 * 吹き出しを設定します。<BR>
	 * デフォールト値はfalse。<BR>
	 * 
	 * @param bool 表示
	 * @create 
	 * @author 
	 * @since 
	 */
	void setAlternate(String bool) {
		setAlternate(GBooleanUtils.toBoolean(bool, false));
	}

	/**
	 * 吹き出しを設定します。<BR>
	 * 
	 * @param bool _is_alternate
	 * @create 
	 * @author 
	 * @since 
	 */
	public void setAlternate(boolean bool) {
		_is_alternate = bool;
	}

	/**
	 * 吹き出しを取得します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.ISectionInfo#getAlternate()
	 * @return boolean _is_alternate
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean getAlternate() {
		return _is_alternate;
	}

	/**
	 * 背景色を設定します。<br>
	 * 
	 * @param backGroundColor 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	public void setBackGroundColor(Color backGroundColor) {
		this._back_color = backGroundColor;
	}

	/**
	 * 背景色を取得します。<br>
	 * 
	 * @return 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	@Override
	public Color getBackGroundColor() {
		return _back_color;
	}
}
