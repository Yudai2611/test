/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl.barcode;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * 【役割】バーコード Code39 を表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/09/02
 * @author kusakari
 * @since 1.0.3
 */
public class GCode39 {

	/** 拡張 */
	private boolean _is_extended = false;
	/** チェックサム自動修正 */
	private boolean _is_generate_check_sum = false;
	/** コードを表示するかどうかのフラグ */
	private boolean _is_code_visible = true;

	/**
	 * 【機能】拡張に設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param bool 真偽値
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public void setExtended(boolean bool) {
		_is_extended = bool;
	}

	/**
	 * 拡張に設定します。<BR>
	 * 
	 * @param bool 真偽値
	 * @create 2014/12/22
	 * @author KCCS XieHeping
	 * @since 2.0.0
	 */
	public void setExtended(String bool) {
		setExtended(GBooleanUtils.toBoolean(bool, false));
	}

	/**
	 * 【機能】拡張かの真偽値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public boolean getExtended() {
		return _is_extended;
	}

	/**
	 * 【機能】チェックサム自動修正を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param bool 真偽値
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public void setGenerateCheckSum(boolean bool) {
		_is_generate_check_sum = bool;
	}

	/**
	 * チェックサム自動修正を設定します。<BR>
	 * デフォールト値はfalse。<BR>
	 * 
	 * @param bool 真偽値
	 * @create 2014/12/22
	 * @author KCCS XieHeping
	 * @since 2.0.0
	*/
	public void setGenerateCheckSum(String bool) {
		setGenerateCheckSum(GBooleanUtils.toBoolean(bool, false));
	}

	/**
	 * 【機能】コードを表示するかどうかのフラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param isCodeVisible コードを表示するかどうかのフラグ
	 * @create 2012/01/07
	 * @author KCCS H.Murashige
	 * @since 1.9.0
	 */
	public void setCodeVisible(boolean isCodeVisible) {
		_is_code_visible = isCodeVisible;
	}

	/**
	 * 【機能】チェックサム自動修正を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public boolean getGenerateCheckSum() {
		return _is_generate_check_sum;
	}

	/**
	 * 【機能】コードを表示するかどうかのフラグを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2012/01/07
	 * @author KCCS H.Murashige
	 * @since 1.9.0
	 */
	public boolean isCodeVisible() {
		return _is_code_visible;
	}

}
