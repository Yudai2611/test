/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl.barcode;

/**
 * 【役割】バーコード Ean128 を表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/09/02
 * @author kusakari
 * @since 1.0.3
 */
public class GEan128 {

	/** コードタイプ */
	private int _code_type = 0;

	/**
	 * 【機能】コードタイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type コードタイプ
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public void setCodeType(int type) {
		_code_type = type;
	}

	/**
	 * 【機能】コードタイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return コードタイプ
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public int getCodeType() {
		return _code_type;
	}
}
