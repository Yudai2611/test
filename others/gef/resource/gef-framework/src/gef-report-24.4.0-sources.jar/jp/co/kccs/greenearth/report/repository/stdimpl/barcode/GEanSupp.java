/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl.barcode;

import jp.co.kccs.greenearth.commons.utils.GNumberUtils;

/**
 * 【役割】バーコード EanSupp を表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/09/02
 * @author kusakari
 * @since 1.0.3
 */
public class GEanSupp {

	/** コードタイプ */
	private int _code_type = 0;
	/** suppコードタイプ */
	private int _supp_code_type = 0;
	/** supp値 */
	private String _supp_value = null;

	/**
	 * 【機能】コードタイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type コードタイプ
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public void setCodeType(int type) {
		_code_type = type;
	}

	/**
	 * コードタイプを設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param type コードタイプ
	 * @create 2014/12/22
	 * @author KCCS XieHeping
	 * @since 2.0.0
	 */
	public void setCodeType(String type) {
		setCodeType(GNumberUtils.toInteger(type, 0));
	}

	/**
	 * 【機能】コードタイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return コードタイプ
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public int getCodeType() {
		return _code_type;
	}

	/**
	 * 【機能】SuppCodeType を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type suppコードタイプ
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public void setSuppCodeType(int type) {
		_supp_code_type = type;
	}

	/**
	 * SuppCodeType を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param type タイプ
	 * @create 2014/12/22
	 * @author KCCS XieHeping
	 * @since 2.0.0
	 */
	public void setSuppCodeType(String type) {
		setSuppCodeType(GNumberUtils.toInteger(type, 0));
	}

	/**
	 * 【機能】SuppValue を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param val supp値
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public void setSuppValue(String val) {
		_supp_value = val;
	}

	/**
	 * 【機能】SuppCodeType を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return suppコードタイプ
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public int getSuppCodeType() {
		return _supp_code_type;
	}

	/**
	 * 【機能】SuppValue を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return supp値
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public String getSuppValue() {
		return _supp_value;
	}
}
