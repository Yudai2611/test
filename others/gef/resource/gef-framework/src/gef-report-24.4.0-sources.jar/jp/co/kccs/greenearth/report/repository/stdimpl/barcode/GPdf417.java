/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.repository.stdimpl.barcode;

import jp.co.kccs.greenearth.commons.utils.GNumberUtils;

/**
 * 【役割】バーコード Pdf417 を表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/09/02
 * @author kusakari
 * @since 1.0.3
 */
public class GPdf417 {

	/** [Pdf417]列数 */
	private int _col_count = 0;
	/** [Pdf417]行数 */
	private int _row_count = 0;

	/**
	 * 【機能】行数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 行数
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	public int getRowCount() {
		return _row_count;
	}

	/**
	 * 【機能】列数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 列数
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	public int getColumnCount() {
		return _col_count;
	}

	/**
	 * 【機能】列数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param i 列数
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	public void setColumnCount(int i) {
		_col_count = i;
	}

	/**
	 * 列数を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param i 列数
	 * @create 2014/12/22
	 * @author KCCS XieHeping
	 * @since 2.0.0
	 */
	public void setColumnCount(String i) {
		setColumnCount(GNumberUtils.toInteger(i, 0));
	}

	/**
	 * 【機能】行数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param i 行数
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	public void setRowCount(int i) {
		_row_count = i;
	}

	/**
	 * 行数を設定します。<BR>
	 * デフォールト値は0。<BR>
	 * 
	 * @param i 行数
	 * @create 2014/12/22
	 * @author KCCS XieHeping
	 * @since 2.0.0
	 */
	public void setRowCount(String i) {
		setRowCount(GNumberUtils.toInteger(i, 0));
	}
}
