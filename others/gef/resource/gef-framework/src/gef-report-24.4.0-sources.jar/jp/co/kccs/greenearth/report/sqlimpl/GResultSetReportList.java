/*
 * Copyright 2014-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.sqlimpl;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Map;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReportList;
import jp.co.kccs.greenearth.report.IReportRecord;
import jp.co.kccs.greenearth.report.stdimpl.GStdReportRecord;

/**
 * 【役割】レポートリストを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 *
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GResultSetReportList implements IReportList {

	/** ResultSet */
	private ResultSet _rs = null;
	/** 自動クローズ */
	private boolean _is_auto_close = false;

	/**
	 * 【役割】レポートリストを生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 *
	 * @param rs 結果セット
	 * @create 2004/03/25
	 * @since 1.0.0
	 */
	public GResultSetReportList(ResultSet rs) {
		_rs = rs;
	}

	/**
	 * 【機能】要素数を返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#size()
	 * @return 要素数
	 * @since 1.0.0
	 */
	@Override
	public int size() {
		return 0;
	}

	/**
	 * 【機能】カーソルを先頭行の前（-1）に移動します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】カーソルが-1の状態でデータを参照することはできません。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#resetCursor()
	 * @since 1.0.0
	 */
	@Override
	public void resetCursor() {
		try {
			_rs.beforeFirst();
		// CHECKSTYLE:OFF
		} catch (Exception e) {
		// CHECKSTYLE:ON
			close();
			if (e instanceof GReportRuntimeException) {
				throw (GReportRuntimeException) e;
			}
			throw new GReportRuntimeException(e);
		}
	}

	/**
	 * 【機能】レポートレコードを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#get()
	 * @return レポートレコード
	 * @throws GReportException ReportFramework例外
	 * @since 1.0.0
	 */
	@Override
	public IReportRecord get() throws GReportException {
		ResultSet rs = _rs;

		Map<String, Object> map = new Hashtable<String, Object>();
		try {
			ResultSetMetaData meta = rs.getMetaData();
			for (int i = 1; i <= meta.getColumnCount(); i++) {
				Object value = rs.getObject(i);
				if (value == null) {
					value = "";
				}
				map.put(meta.getColumnLabel(i).toUpperCase(), value);
			}
		// CHECKSTYLE:OFF
		} catch (Exception e) {
		// CHECKSTYLE:ON
//			se.printStackTrace();
			close();
		}
		return new GStdReportRecord(map);
	}

	/**
	 * 【機能】次データにカーソルを移動させ、移動先の行にデータが存在するどうかを判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】自動クローズが有効の場合、移動先の行が存在しなければResultSetをクローズします。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#next()
	 * @return データが存在するかの真偽値
	 * @throws GReportException ReportFramework例外
	 * @since 1.0.0
	 */
	@Override
	public boolean next() throws GReportException {
		try {
			boolean hasNext = _rs.next();
			if (isAutoClose() && !hasNext) {
				close();
			}
			return hasNext;
		// CHECKSTYLE:OFF
		} catch (Exception e) {
		// CHECKSTYLE:ON
			close();
			if (e instanceof GReportException) {
				throw (GReportException) e;
			}
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】自動的にクローズされるとき、これを待つのではなく、ただちに ResultSet オブジェクトのデータベースと JDBC
	 * リソースを解放します。 <BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 *
	 * @since 1.0.0
	 */
	public void close() {
		try {
			_rs.close();
		// CHECKSTYLE:OFF
		} catch (Exception e) {
		// CHECKSTYLE:ON
			try {
				_rs.close();
			} catch (SQLException ex) {
				throw new GReportRuntimeException(ex);
			}
			if (e instanceof GReportRuntimeException) {
				throw (GReportRuntimeException) e;
			}
			throw new GReportRuntimeException(e);
		}
	}

	/**
	 * 【機能】自動クローズするか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 自動クローズするかの真偽値
	 * @since 1.0.0
	 */
	public boolean isAutoClose() {
		return _is_auto_close;
	}

	/**
	 * 【機能】自動クローズするか設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param is_auto_close 自動クローズするかの真偽値
	 * @since 1.0.0
	 */
	public void setAutoClose(boolean is_auto_close) {
		_is_auto_close = is_auto_close;
	}
}