/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.IControlBreakHandler;
import jp.co.kccs.greenearth.report.IReport;
import jp.co.kccs.greenearth.report.IReportRecord;
import jp.co.kccs.greenearth.report.repository.IControlBreakInfo;

/**
 * 【役割】コントロールブレイクマネージャを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdControlBreakHandler implements IControlBreakHandler {

	/** コントロールブレイク情報リスト */
	private IControlBreakInfo[] _break_info = null;
	/** 前回のブレイク値マップ */
	private Map<String, String> _pre_break_value_map = new HashMap<String, String>();
	/** ブレイク値マップ */
	private Map<String, String> _break_value_map = new HashMap<String, String>();
	/** 次のブレイク値マップ */
	private Map<String, String> _next_break_value_map = new HashMap<String, String>();
	/** 次回ブレイクするキー名称 */
	private String _next_break_name = null;
	/** レポート参照 */
	private IReport _report = null;

	/**
	 * 【機能】以前のブレイク情報をクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#clear()
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void clear() {
		_pre_break_value_map.clear();
		_break_value_map.clear();
		_next_break_value_map.clear();
	}

	/**
	 * 前回のブレイク値マップを取得します.
	 * 
	 * @return 前回のブレイク値マップ
	 * @create
	 * @author
	 * @since 
	 */
	Map<String, String> getPreBreakValueMap() {
		return _pre_break_value_map;
	}
	
	/**
	 * ブレイク値マップを取得します. 
	 * 
	 * @return ブレイク値マップ
	 * @create
	 * @author
	 * @since 
	 */
	Map<String, String> getBreakValueMap() {
		return _break_value_map;
	}

	/**
	 * 次のブレイク値マップを取得します.
	 * 
	 * @return 次のブレイク値マップ
	 * @create 2014/12/24
	 * @author
	 * @since 
	 */
	Map<String, String> getNextBreakValueMap() {
		return _next_break_value_map;
	}

	/**
	 * 【機能】ブレイク情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#setBreakInfo(jp.co.kccs.greenearth.report.repository.IControlBreakInfo[])
	 * @param break_info ブレイクキー情報
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setBreakInfo(IControlBreakInfo[] break_info) {
		_break_info = break_info;
	}

	/**
	 * 【機能】ブレイク情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#getBreakInfo()
	 * @return ブレイクキー情報
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public IControlBreakInfo[] getBreakInfo() {
		return _break_info;
	}

	/**
	 * 【機能】キーブレイクが起こるかどうか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】内部的にブレイク値マップに値を保持しています。<BR>
	 * 
	 * @param breakInfo ブレイクキー情報
	 * @param record レコード
	 * @return キーブレイクが起こるかの真偽値
	 * @throws GReportException 例外
	 * @create 
	 * @author 
	 * @since 
	 */
	protected boolean isBreak(final IControlBreakInfo breakInfo, final IReportRecord record) throws GReportException {
		if (breakInfo == null || record == null) {
			return false;
		}
		
		final String name = breakInfo.getName();
		if (name == null) {
			return false;
		}

		String fullValue = record.getVariableString(name);

		// ------------------------------------------
		// キーがない場合追加する
		// ------------------------------------------
		if (!getBreakValueMap().containsKey(name)) {
			getBreakValueMap().put(name, fullValue);
			return false;
		}
		// ------------------------------------------
		// キーがある場合違えば追加する
		// ------------------------------------------
		else {
			String preValue = (String) getBreakValueMap().get(name);
			if (preValue == null && fullValue == null) {
				return false;
			} else if (preValue != null) {
				if (preValue.equals(fullValue)) {
					return false;
				}
			}
		}
		// 保持
		getPreBreakValueMap().put(name, getBreakValueMap().get(name));
		getBreakValueMap().put(name, fullValue);
		// 抑止を解除します
		removeOmitValue(name);
		return true;
	}

	/**
	 * 【機能】ブレイクキーと値を保持します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】次回ブレイク時の比較用です。<BR>
	 * 
	 * @param breakInfo ブレイクキー情報
	 * @param record レコード
	 * @throws GReportException 例外
	 * @create 
	 * @author 
	 * @since 
	 */
	protected void setBreakValue(final IControlBreakInfo breakInfo, final IReportRecord record) throws GReportException {
		if (!isBreak(breakInfo, record)) {
			// 抑止を解除します
			removeOmitValue(breakInfo.getName());
		}
	}

	/**
	 * 【機能】次回のブレイクキーと値を保持します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】次回の次回のブレイク時の比較用です。<BR>
	 * 
	 * @param breakInfo ブレイクキー情報
	 * @param record レコード
	 * @throws GReportException 例外
	 * @create 
	 * @author 
	 * @since 
	 */
	protected void setNextBreakValue(final IControlBreakInfo breakInfo, final IReportRecord record) throws GReportException {
		isNextBreak(breakInfo, record);
	}

	/**
	 * 【機能】コントロールブレイクマネージャに関連付けられたレポートを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return レポートオブジェクト
	 * @create 2004/06/02
	 * @author 
	 * @since 1.0.1
	 */
	public IReport getReport() {
		return _report;
	}

	/**
	 * 【機能】レポート参照を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#setReport(jp.co.kccs.greenearth.report.IReport)
	 * @param report レポートオブジェクト
	 * @create 2004/06/02
	 * @author 
	 * @since 1.0.1
	 */
	@Override
	public void setReport(IReport report) {
		_report = report;
	}

	/**
	 * 【機能】現在のレコードでキーブレイクが起こればキーブレイクイベントを発生させます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#keyBreak(jp.co.kccs.greenearth.report.IReportRecord)
	 * @param record レポートオブジェクト
	 * @throws GReportException 例外
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void keyBreak(final IReportRecord record) throws GReportException {
		if (record == null) {
			return;
		}
		IControlBreakInfo[] breakInfos = getBreakInfo();
		final int size = breakInfos.length;
		for (int i = 0; i < size; i++) {
			IControlBreakInfo breakInfo = breakInfos[i];

			if (isBreak(breakInfo, record)) {
				// --------------------------------------------------
				// 拡張ポイント - keyBreak
				// --------------------------------------------------
				getReport().keyBreak(breakInfo.getName(), record);
				// ----------------------------------------------
				// 優先順位が高いものがブレイクしたら抜けます。
				// ただし、比較用の値だけはセットします。
				// また、抑止は解除されます。
				// ----------------------------------------------
				if (i != size) {
					for (int j = i + 1; j < size; j++) {
						setBreakValue(breakInfos[j], record);
					}
				}
				break;
			}
		}
	}

	/**
	 * 【機能】次のレコードのブレイクキー名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#getNextBreakKeyName()
	 * @return 次のレコードのブレイクキー名称
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getNextBreakKeyName() {
		return _next_break_name;
	}

	/**
	 * 次のブレイクキー名を設定します.
	 * 
	 * @param nextBreakKeyName 次のブレイクキー名
	 * @create
	 * @author
	 * @since 
	 */
	void setNextBreakKeyName(String nextBreakKeyName) {
		_next_break_name = nextBreakKeyName;
	}
	
	/**
	 * 【機能】次のレコードでキーブレイクが起こるか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】優先順位が高いブレイクキーでブレイクします。<BR>
	 * 最後のレコードでは優先順位一位のキーでキーブレイクが発生します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#nextKeyBreak(jp.co.kccs.greenearth.report.IReportRecord)
	 * @param record レポートオブジェクト
	 * @return 次のレコードでキーブレイクが起こるかの真偽値
	 * @throws GReportException 例外
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public boolean nextKeyBreak(final IReportRecord record) throws GReportException {
		// break_key_name 初期化
		setNextBreakKeyName(null);

		IControlBreakInfo[] breakInfos = getBreakInfo();
		if (breakInfos == null) {
			return false;
		}
		// ----------------------------------------------
		// 最後のレコードなら最優先キーでブレイクします
		// ----------------------------------------------
		if (record == null) {
			if (breakInfos.length != 0) {
				setNextBreakKeyName(breakInfos[0].getName());
			} else {
				setNextBreakKeyName(null);
			}
			return true;
		}

		final int size = breakInfos.length;
		for (int i = 0; i < size; i++) {
			IControlBreakInfo breakInfo = breakInfos[i];
			if (isNextBreak(breakInfo, record)) {
				setNextBreakKeyName(breakInfo.getName());
				// この段階では呼び出さないようにしました。
				// nextKeyBreakの呼び出しはreport#loadNextRecord内で行われます。
				// これは拡張ポイントの呼び出す順番をエンジン側で制御するためです。
				// report.nextKeyBreak( breakInfo.getName(), record );
				// ----------------------------------------------
				// 優先順位が高いものがブレイクしたら抜けます
				// ただし、比較用の値だけはセットします
				// ----------------------------------------------
				if (i != size) {
					for (int j = i + 1; j < size; j++) {
						setNextBreakValue(breakInfos[j], record);
					}
				}
				return true;
			}
		}
		return false;
	}

	/**
	 * 【機能】次のレコードでキーブレイクが起こるかどうか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】内部的に次のブレイク値マップに値を保持しています。<BR>
	 * 
	 * @param breakInfo ブレイクキー情報
	 * @param record レコード
	 * @throws GReportException 例外
	 * @return 次のレコードでキーブレイクが起こるかの真偽値
	 * @create 
	 * @author 
	 * @since 
	 */
	protected boolean isNextBreak(final IControlBreakInfo breakInfo, final IReportRecord record) throws GReportException {
		if (breakInfo == null || record == null) {
			return false;
		}
		final String name = breakInfo.getName();
		if (name == null) {
			return false;
		}

		String fullValue = record.getVariableString(name);

		// ------------------------------------------
		// キーがない場合追加する
		// ------------------------------------------
		if (!getNextBreakValueMap().containsKey(name)) {
			getNextBreakValueMap().put(name, fullValue);
			return false;
		}
		// ------------------------------------------
		// キーがある場合違えば追加する
		// ------------------------------------------
		else {
			String preValue = (String) getNextBreakValueMap().get(name);
			if (preValue == null && fullValue == null) {
				return false;
			} else if (preValue != null) {
				if (preValue.equals(fullValue)) {
					return false;
				}
			}
		}
		// 保持
		getNextBreakValueMap().put(name, fullValue);
		return true;
	}

	/**
	 * 【機能】GControlBreakManagerが保持する指定キーブレイクの一つ前の値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#getPreBreakValue(java.lang.String)
	 * @param breakKeyName ブレイクキー
	 * @return 前回のキーブレイク値
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getPreBreakValue(String breakKeyName) {
		Object o = getPreBreakValueMap().get(breakKeyName);
		if (o == null) {
			return null;
		} else {
			return o.toString();
		}
	}

	/**
	 * 【機能】抑止値をフィールド名指定で削除します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#removeOmitValue(java.lang.String)
	 * @param fieldName フィールド名
	 * @create 2004/06/02
	 * @author 
	 * @since 1.0.1
	 */
	@Override
	public void removeOmitValue(String fieldName) {
		if (null == getReport()) {
			return;
		}
		
		((GStdReport) getReport()).removeOmitValue(fieldName);
	}

	/**
	 * 【機能】抑止値をクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IControlBreakHandler#clearOmitValue()
	 * @create 2004/06/02
	 * @author 
	 * @since 1.0.1
	 */
	@Override
	public void clearOmitValue() {
		if (null == getReport()) {
			return;
		}
		
		((GStdReport) getReport()).clearOmitValue();
	}
}
