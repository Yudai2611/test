/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.report.ISectionElementGroup;

/**
 * 【役割】レポート構成要素のグループを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/07/01
 * @author kusakari
 * @since 1.0.2
 */
public class GStdGroup implements ISectionElementGroup {

	/** リスト */
	private List<Object> _list = new ArrayList<Object>();
	/** 名称 */
	private String _name = null;

	/**
	 * コンストラクタ.<br>
	 * 
	 * @create 
	 * @author 
	 * @since 
	 */
	public GStdGroup() {
	}

	/**
	 * コンストラクタ.<br>
	 * 
	 * @param name グループ名
	 * @create 
	 * @author 
	 * @since 
	 */
	public GStdGroup(String name) {
		setName(name);
	}

	/**
	 * 名称をセットします。<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.ISectionElementGroup#setName(java.lang.String)
	 * @param name グループ名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void setName(String name) {
		_name = name;
	}

	/**
	 * 名称を取得します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.ISectionElementGroup#getName()
	 * @return グループ名
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public String getName() {
		return _name;
	}

	/**
	 * レポート構成要素をリストに追加します。
	 * 
	 * @see jp.co.kccs.greenearth.report.ISectionElementGroup#add(java.lang.Object)
	 * @param element エレメント
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void add(Object element) {
		_list.add(element);
	}

	/**
	 * リストをクリアします。<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.ISectionElementGroup#clear()
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public void clear() {
		_list.clear();
	}

	/**
	 * リストからインデックス指定でレポート構成要素を取得します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.ISectionElementGroup#get(int)
	 * @param index インデックス
	 * @return エレメント
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public Object get(int index) {
		return _list.get(index);
	}

	/**
	 * リスト内の要素数を取得します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.report.ISectionElementGroup#size()
	 * @return サイズ
	 * @create 
	 * @author 
	 * @since 
	 */
	@Override
	public int size() {
		return _list.size();
	}
}
