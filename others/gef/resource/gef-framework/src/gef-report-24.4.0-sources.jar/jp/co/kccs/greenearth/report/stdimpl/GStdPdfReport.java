/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;


/**
 * 【役割】PDFレポートを表します。<BR>
 * 【生成】レポートマネージャによりリクエストごとに生成されます。<BR>
 * 【解放】レポート印刷後に解放されます。<BR>
 * 【備考】このクラスを継承することで、通常のレポート機能に加えてPDF固有の機能を利用することが出来ます。<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @version 1.0.0
 * @since 1.0.0
 */
public abstract class GStdPdfReport extends GStdReport {

	/**
	 * 【役割】PDFレポートを生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 * 
	 * @param report_id レポートID
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public GStdPdfReport(String report_id) {
		super(report_id);
	}

	/**
	 * 【機能】PDFにパスワードを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>initReportInfo 拡張ポイントにてご利用下さい。</B><BR>
	 * パスワードを設定するとパスワードを入力しなければドキュメントを見ることが出来ません。<BR>
	 * 
	 * @param password パスワード
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void setPassword(String password) {
		getWriter().setPassword(password);
	}

	/**
	 * 【機能】PDFを開いたときに自動的に印刷画面が立ち上がるようにします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】JavaScriptを埋め込むことで実現しています。<BR>
	 * 
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void setOnLoadPrint() {
		getWriter().setOnLoadPrint();
	}

	/**
	 * 【機能】PDFにJavaScriptを埋め込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param script JavaScript
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void setJavaScript(String script) {
		getWriter().setJavaScript(script);
	}

	/**
	 * 【機能】PDFにアウトラインを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param outline アウトライン
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void setOutline(String outline) {
		getWriter().writeOutline(outline);
	}
}
