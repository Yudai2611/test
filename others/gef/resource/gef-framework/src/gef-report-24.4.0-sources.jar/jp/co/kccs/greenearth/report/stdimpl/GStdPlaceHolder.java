/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IPlaceHolder;
import jp.co.kccs.greenearth.report.IReportCircle;
import jp.co.kccs.greenearth.report.IReportField;
import jp.co.kccs.greenearth.report.IReportImage;
import jp.co.kccs.greenearth.report.IReportLine;
import jp.co.kccs.greenearth.report.IReportSection;

/**
 * 【役割】プレースホルダを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdPlaceHolder implements IPlaceHolder {

	/** セクション */
	private GStdReportSection _section = null;
	/** 現在行数 */
	private int _line_count = 1;

	/** フィールドリスト */
	private List<Object> _field_list = null;
	/** ラインリスト */
	private List<Object> _line_list = null;
	/** イメージリスト */
	private List<Object> _image_list = null;
	/** サークルリスト */
	private List<Object> _circle_list = null;

	/**
	 * 現在行数を取得します.
	 * 
	 * @return 現在行数
	 * @create 
	 * @author 
	 * @since 
	 */
	int getLineCount() {
		return _line_count;
	}

	/**
	 * 【機能】セクションのプリントに必要な情報を保持します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IPlaceHolder#setParamters(int, jp.co.kccs.greenearth.report.IReportSection)
	 * @param line_cnt 現在行
	 * @param section セクション
	 * @since 1.0
	 */
	@Override
	public void setParamters(int line_cnt, IReportSection section) {
		_line_count = line_cnt;

		_section = (GStdReportSection) section;

		_image_list = getSection().getImageList();
		_circle_list = getSection().getCircleList();
		_field_list = getSection().getFieldList();
		_line_list = getSection().getLineList();

	}

	/**
	 * セクションを取得します.
	 * 
	 * @return セクション
	 * @create
	 * @author
	 * @since 
	 */
	GStdReportSection getSection() {
		if (_section == null) {
			throw new GReportRuntimeException("section is not set.");
		}
		return _section;
	}
	
	/**
	 * イメージリストを取得します.
	 * 
	 * @return イメージリスト
	 * @create
	 * @author
	 * @since 
	 */
	List<Object> getImageList() {
		if (_image_list == null) {
			_image_list = new ArrayList<Object>();
		}
		return _image_list;
	}
	
	/**
	 * サークルリストを取得します.
	 * 
	 * @return サークルリスト
	 * @create
	 * @author
	 * @since 
	 */
	List<Object> getCircleList() {
		if (_circle_list == null) {
			_circle_list = new ArrayList<Object>();
		}
		return _circle_list;
	}
	
	/**
	 * フィールドリストを取得します.
	 * 
	 * @return フィールドリスト
	 * @create
	 * @author
	 * @since 
	 */
	List<Object> getFieldList() {
		if (_field_list == null) {
			_field_list = new ArrayList<Object>();
		}
		return _field_list;
	}
	
	/**
	 * ラインリストを取得します.
	 * 
	 * @return ラインリスト
	 * @create
	 * @author
	 * @since 
	 */
	List<Object> getLineList() {
		if (_line_list == null) {
			_line_list = new ArrayList<Object>();
		}
		return _line_list;
	}
	
	/**
	 * 【機能】このプレースホルダを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IPlaceHolder#print()
	 * @throws GReportException ReportFremework例外
	 * @since 1.0
	 */
	public void print() throws GReportException {
		this.printSection();
	}

	/**
	 * 【機能】セクションプレースホルダを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFremework例外
	 * @since 1.0
	 */
	protected void printSection() throws GReportException {
		final GStdReport report = (GStdReport) getSection().getReport();

		// 非表示
		if (!getSection().getOutput()) {
			report.addLineCount(getSection().getHeight());
			return;
		}

		// Print Field
		for (int i = 0; i < getFieldList().size(); i++) {
			IReportField field = (IReportField) getFieldList().get(i);
			field.printPlaceHolder();
		}

		// Print Line
		for (int i = 0; i < getLineList().size(); i++) {
			IReportLine line = (IReportLine) getLineList().get(i);
			line.printPlaceHolder();
		}

		// Print Circle
		for (int i = 0; i < getCircleList().size(); i++) {
			IReportCircle circle = (IReportCircle) getCircleList().get(i);
			circle.printPlaceHolder();
		}

		// Print Image
		for (int i = 0; i < getImageList().size(); i++) {
			IReportImage image = (IReportImage) getImageList().get(i);
			image.printPlaceHolder();
		}
	}
}
