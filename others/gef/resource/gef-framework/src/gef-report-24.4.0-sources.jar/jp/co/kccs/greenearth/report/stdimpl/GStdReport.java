/*
 * Copyright 2014-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.report.AbstractReport;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportFactory;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IControlBreakHandler;
import jp.co.kccs.greenearth.report.IReport;
import jp.co.kccs.greenearth.report.IReportList;
import jp.co.kccs.greenearth.report.IReportRecord;
import jp.co.kccs.greenearth.report.IReportSection;
import jp.co.kccs.greenearth.report.IReportWriter;
import jp.co.kccs.greenearth.report.Version;
import jp.co.kccs.greenearth.report.driver.GPDFReportDriver;
import jp.co.kccs.greenearth.report.repository.IControlBreakInfo;
import jp.co.kccs.greenearth.report.repository.IReportInfo;
import jp.co.kccs.greenearth.report.repository.ISectionInfo;
import jp.co.kccs.greenearth.report.utility.ISectionList;

/**
 * 【役割】レポートクラスを表します。<BR>
 * 【生成】レポートマネージャによりリクエストごとに生成されます。<BR>
 * 【解放】レポート印刷後に解放されます。<BR>
 * 【備考】<BR>
 *
 * @create 2004/03/25
 * @author kusakari
 * @version 1.0.0
 * @since 1.0.0
 */
public abstract class GStdReport extends AbstractReport {

	/** リストデータ */
	private IReportList _current_list = null;
	/** レポートレコード */
	private IReportRecord _record = null;
	/** コントロールブレイクマネージャ */
	private IControlBreakHandler _break_manager = null;
	/** 次のレコード */
	private IReportRecord _next_record = null;
	/** 一つ前のレコード */
	private IReportRecord _pre_record = null;
	/** デバッグフラグ */
	private static boolean isDebug = false;

	// --------------------------------------
	// 動的なレポート情報
	// --------------------------------------
	/** レポートID */
	private String _report_id = null;
	/** 最大高 */
	private int _max_height = 0;
	/** 最大幅 */
	private int _max_width = 0;
	/** 網掛けカウント */
	private int _border_count = 0;
	/** ページ数 */
	private int _page_count = 1;
	/** 追記フラグ */
	private boolean _is_postscript = false;
	/** 印刷日付 */
	private Date _print_date = null;
	/** 初回フラグ */
	private boolean _is_first_load = true;
	/** 次回ブレイクするかの真偽値 */
	private boolean _is_next_break = false;
	/** ファイルパス */
	private String _file_path = null;
	/** 画像ディレクトリ */
	private String _image_dir = null;
	/** コントロールブレイクキー情報 */
	private IControlBreakInfo[] _break_info = null;
	/** セクション情報マップ */
	private Map<String, IReportSection> _section_map = new HashMap<String, IReportSection>();
	/** 抑止情報マップ */
	Map<String, String> preOmitTable = new HashMap<String, String>();

	/**
	 * 【役割】レポートを生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 *
	 * @param report_id レポートID
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public GStdReport(String report_id) {
		super();
		_report_id = report_id;
	}

	/**
	 * レポートライターの初期化をします。
	 *
	 * @see jp.co.kccs.greenearth.report.AbstractReport#init(jp.co.kccs.greenearth.report.IReportWriter)
	 * @param writer レポートライター
	 * @throws GReportException Report Framework例外
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public void init(IReportWriter writer) throws GReportException {
		super.init(writer);
		initialize();
	}


	/**
	 * 【機能】最大行数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 最大行数
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public int getMaxHeight() {
		return _max_height;
	}

	/**
	 * 【機能】最大幅数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 最大行数
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public int getMaxWidth() {
		return _max_width;
	}

	/**
	 * 【機能】セクションをプリントする領域が残っているか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param section セクション
	 * @return 真偽値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected boolean canPrint(IReportSection section) {

		if (getPrintDirection() == IReportInfo.PRINT_DIRECTION_HORIZONTAL) {
			int pageWidth = getMaxWidth();
			return (getLineCount() + section.getWidth() <= pageWidth);
		}

		int pageHeight = getMaxHeight();
		return (getLineCount() + section.getHeight() <= pageHeight);
	}

	/**
	 * 【機能】セクションリストに含まれるセクションをプリントする領域が残っているか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param section_list セクションリスト
	 * @return 真偽値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected boolean canPrint(ISectionList section_list) {
		boolean canPrint = false;
		int current = getLineCount();
		if (getPrintDirection() == IReportInfo.PRINT_DIRECTION_HORIZONTAL) {
			int pageWidth = getMaxWidth();
			canPrint = (current + section_list.getWidth() <= pageWidth);
		} else {
			int pageHeight = getMaxHeight();
			canPrint = (current + section_list.getHeight() <= pageHeight);
		}
		return canPrint;
	}

	/**
	 * プロパティー値を出力します。<BR>
	 *
	 * @param key キー
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void systemOutPropertyValue(String key) {
		try {
			System.out.print(key + ": ");
			System.out.println(GFrameworkUtils.getProperty(key) + " [OK]");
		} catch (MissingResourceException e) {
			System.out.println("[undefined]");
		}
	}

	/**
	 * 【機能】レポートの初期化を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスからこのメソッドを使用しないで下さい。<BR>
	 *
	 * @create
	 * @author
	 * @throws GReportException ReportFrameowrk例外
	 * @since 1.0.0
	 */
	void initialize() throws GReportException {

		boolean isDebug = false;
		try {
			isDebug = Boolean.valueOf(GFrameworkUtils.getProperty("geframe.report.DebugMode")).booleanValue();
		} catch (MissingResourceException e) {
			isDebug = false;
		}

		setDebug(isDebug);

		try {
			_image_dir = GFrameworkUtils.getProperty("geframe.report.ImageDirectory");
		} catch (MissingResourceException e) {
			_image_dir = null;
		}

		if (isDebug) {
			System.out.println("**************************************************");
			System.out.println("		Report Engine Version: " + Version.VERSION);
			System.out.println("**************************************************");

			systemOutPropertyValue("geframe.report.DebugMode");
			systemOutPropertyValue("geframe.report.XmlDirectory");
			systemOutPropertyValue("geframe.report.OutputDirectory");
			systemOutPropertyValue("geframe.report.ImageDirectory");
			systemOutPropertyValue("geframe.report.FontDirectory");
		}

		// --------------------------------------------------
		// 拡張ポイント - initReportInfo
		// --------------------------------------------------
		initReportInfo();

	}

	/**
	 * ライターをセットします。
	 *
	 * @see jp.co.kccs.greenearth.report.AbstractReport#setWriter(jp.co.kccs.greenearth.report.IReportWriter)
	 * @param writer ライター
	 * @create 2014/12/09
	 * @author KCCS yamashita
	 * @since 2.0.0
	 */
	public void setWriter(IReportWriter writer) {
		super.setWriter(writer);
		writer.setDebug(isDebug);
		writer.setRuledLine(setRuledLine());
	}

	/**
	 * 【機能】デバッグフラグを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return デバッグフラグ
	 * @create 2004/04/16
	 * @author
	 * @since 1.0.0
	 */
	protected boolean isDebug() {
		return isDebug;
	}

	/**
	 * 【機能】セクションを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReport#getSection(java.lang.String)
	 * @param section_name セクション名称
	 * @return セクション
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public IReportSection getSection(String section_name) throws GReportException {
		return _section_map.get(section_name);
	}

	/**
	 * 【機能】「他の帳票レイアウトから自身に追加したセクション」を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】予め、GReport#appendSectionsによりセクションを追加しておく必要があります。<BR>
	 * レポートIDとして自身のレイアウトのレポートIDを指定しても構いません。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReport#getSection(java.lang.String, java.lang.String)
	 * @param report_id レポートID
	 * @param section_name セクション名称
	 * @return セクション
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public IReportSection getSection(String report_id, String section_name) throws GReportException {

		if (getReportInfo().getName().equals(report_id)) {
			return getSection(section_name);
		}

		IReportSection section = _section_map.get(report_id + '\t' + section_name);

		return section;
	}

	/**
	 * 【機能】キーブレイクの判定を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスからこのメソッドを使用することは推奨されません。<BR>
	 *
	 * @param record レポートレコード
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	void keyBreak(IReportRecord record) throws GReportException {
		if (_break_manager == null) {
			_break_manager = createControlBreakHandler(getBreakInfo());
		}

		_break_manager.keyBreak(getCurrentRecord());
	}

	/**
	 * コントロールブレイクマネージャーを生成します。<BR>
	 *
	 * @param breakInfos コントロールブレイクキー配列
	 * @return コントロールブレイクマネージャー
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected IControlBreakHandler createControlBreakHandler(IControlBreakInfo[] breakInfos) {
		IControlBreakHandler ctrBreakHandler = GFrameworkUtils.getComponent(IControlBreakHandler.class.getName());
		ctrBreakHandler.setReport(this);
		ctrBreakHandler.setBreakInfo(breakInfos);
		return ctrBreakHandler;
	}

	/**
	 * 【機能】次のレコードでキーブレイクが起こるかの情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスからこのメソッドを使用することは推奨されません。<BR>
	 *
	 * @param record レポートレコード
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void nextKeyBreak(IReportRecord record) throws GReportException {
		if (_break_manager == null) {
			_break_manager = createControlBreakHandler(getBreakInfo());
		}

		if (_break_manager.nextKeyBreak(record)) {
			_is_next_break = true;
		} else {
			_is_next_break = false;
		}
	}

	/**
	 * 【機能】次のレコードでキーブレイクが起こるか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】最後のレコードが読み込まれた場合、このメソッドの戻値は常に真になります。<BR>
	 *
	 * @return 真偽値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected boolean isNextBreak() {
		return _is_next_break;
	}

	/**
	 * 【機能】印刷対象データが存在するか判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】印刷対象となるレコードが一件でもあった場合、true となります。<BR>
	 *
	 * @return 真偽値
	 * @create 2004/06/03
	 * @author
	 * @since 1.0.1
	 */
	protected boolean isNoData() {
		if (_current_list.size() == 0) {
			return true;
		}
		return false;
	}

	/**
	 *
	 * 【機能】次のレコードでキーブレイクが起こる場合のキー名称を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】優先順位が高いブレイクキーでブレイクします。<BR>
	 * 最後のレコードでは必ず優先順位一位のキーでキーブレイクが発生します。<BR>
	 * キーブレイクが起こらない場合nullが返ります。
	 *
	 * @return ブレイクキー名称
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected String getNextKeyBreakName() {
		return _break_manager.getNextBreakKeyName();
	}

	/**
	 * 【機能】一つ先読みしたレコードを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートレコードがまだ読み込まれていない場合と、最後のレコードが読み込まれた場合、nullが返されます。<BR>
	 *
	 * @return レポートレコード
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected IReportRecord getNextRecord() {
		return _next_record;
	}

	/**
	 * 【機能】次のレコードが存在するかどうか判断します。<BR>
	 * 存在すれば次のレコードをロードします。次レコードがない場合はfalseを返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】内部的にpostGetData(), keyBreak(), nextKeyBreak()がこの順番で呼ばれます。<BR>
	 * 初回のみstartPage()が呼ばれます。（それ以後はpageBreak()時に呼ばれます）<BR>
	 *
	 * @return 真偽値
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	boolean loadNextRecord() throws GReportException {
		IReportList list = _current_list;
		/** 読み込み成功フラグ */
		boolean isLoadSuccess = false;

		if (list == null) {
			return false;
		}

		// --------------------------------------------------
		// カレントレコードのセットと拡張ポイント呼び出し
		// --------------------------------------------------
		if (_is_first_load) {
			if (list.next()) {
				_record = list.get();

				// 次のレコードを読みます
				loadNextAgain(list, _is_first_load);

				// --------------------------------------------------
				// 拡張ポイント - postGetData
				// --------------------------------------------------
				postGetData(getCurrentRecord());
				// --------------------------------------------------
				// 拡張ポイント - keyBreak
				// --------------------------------------------------
				keyBreak(getCurrentRecord());
				// --------------------------------------------------
				// 拡張ポイント - nextKeyBreak
				// --------------------------------------------------
				if (isNextBreak()) {
					nextKeyBreak(getNextKeyBreakName(), getNextRecord());
				}
				// --------------------------------------------------
				// 初回読み込み時のみnewPage()を呼びます。
				// ここで呼び出すのはレコードを読み込んだ後、startPage()を呼ぶためです。
				// --------------------------------------------------
				startPage();

				_is_first_load = false;

				isLoadSuccess = true;
			} else {
				isLoadSuccess = false;
			}
		}
		// 二回目以降
		else {
			if (_next_record == null) {
				isLoadSuccess = false;
			} else {
				_pre_record = _record;
				_record = _next_record;

				// 次のレコードを読みます
				loadNextAgain(list, _is_first_load);

				// --------------------------------------------------
				// 拡張ポイント - postGetData
				// --------------------------------------------------
				postGetData(getCurrentRecord());
				// --------------------------------------------------
				// 拡張ポイント - keyBreak
				// --------------------------------------------------
				keyBreak(getCurrentRecord());
				// --------------------------------------------------
				// 拡張ポイント - nextKeyBreak
				// --------------------------------------------------
				if (isNextBreak()) {
					nextKeyBreak(getNextKeyBreakName(), getNextRecord());
				}

				isLoadSuccess = true;
			}
		}

		return isLoadSuccess;
	}

	/**
	 * 【機能】現在レコードからさらに次のレコードを読み込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】初回のみ次回ブレイク用の初回情報を生成します。<BR>
	 *
	 * @param list レポートリスト
	 * @param is_first 初回フラグ
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void loadNextAgain(IReportList list, boolean is_first) throws GReportException {
		// 次のレコードを読み込みます
		if (list.next()) {
			_next_record = list.get();
		} else {
			_next_record = null;
		}
		// 初回情報生成
		if (is_first) {
			nextKeyBreak(getCurrentRecord());
		}
		// ブレイクするかの情報を作ります
		nextKeyBreak(getNextRecord());
	}

	/**
	 * 【機能】ページブレイク（改ページ）します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】内部的にendPage(),startPage()がこの順番で呼ばれます。また、現在行数と抑止はクリアされます。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReport#pageBreak()
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public void pageBreak() throws GReportException {
		// --------------------------------------------------
		// 拡張ポイント - endPage
		// --------------------------------------------------
		endPage();

		getWriter().pageBreak();

		// --------------------------------------------------
		// 初期化
		// --------------------------------------------------
		setLineCount(0);
		_border_count = 0;
		preOmitTable.clear();
		// ページ数+1
		_page_count++;

		// --------------------------------------------------
		// 拡張ポイント - startPage
		// --------------------------------------------------
		startPage();
	}

	/**
	 * 【機能】ページブレイク（改ページ）を行うと同時にページ数もリセットします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】内部的にendPage(),startPage()がこの順番で呼ばれます。<BR>
	 * ページ数、現在行数、抑止、最大ページ数はリセットされます。<BR>
	 *
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public void resetPageBreak() throws GReportException {
		resetPageCount();

		// --------------------------------------------------
		// 拡張ポイント - endPage
		// --------------------------------------------------
		endPage();
		getWriter().pageBreak();

		// --------------------------------------------------
		// 初期化
		// --------------------------------------------------
		setLineCount(0);
		_border_count = 0;
		preOmitTable.clear();
		// ページ数+1
		_page_count++;

		// --------------------------------------------------
		// 拡張ポイント - startPage
		// --------------------------------------------------
		startPage();
	}

	/**
	 * 【機能】各パラメータを初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】追記の際のみ呼ばれます<BR>
	 *
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void clearParameter() throws GReportException {
		getWriter().pageBreak();

		if (_break_manager != null) {
			_break_manager.clear();
		}
		preOmitTable.clear();
		setLineCount(0);
		_border_count = 0;
		_is_first_load = true;
		_is_next_break = false;
		_record = null;
		_pre_record = null;
		_next_record = null;
	}

	/**
	 * 【機能】GReportListに従ってレポートを印刷します。<BR>
	 * 【呼出】アクションビーン<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReport#print(jp.co.kccs.greenearth.report.IReportList)
	 * @param list_data レポートリスト
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public void print(IReportList list_data) throws GReportException {
		boolean isDebug = isDebug();
		GStopWatch gw = null;

		open();

		try {
			_current_list = list_data;

			if (isDebug) {
				gw = new GStopWatch();
				System.out.println("create active report info start.");
				gw.start();
			}
			create();
			if (isDebug) {
				System.out.println("create active report info success. [" + gw.stop() + "ms]");
				System.out.println("print start.");
				gw.start();
			}
			startReport();

			// 初回のstartPage()はloadNextRecord()内で呼ばれます
			while (loadNextRecord()) {
				execute(getCurrentRecord());
			}

			endPage();

			checkPostScript();

			endReport();

			// 追記でなければ閉じる
			if (!_is_postscript) {
				close();
				if (isDebug) {
					long t = gw.stop();
					System.out.println("print finish. [" + t + "ms](" + (t / 1000.0) + "s)");
				}
			}
		// CHECKSTYLE:OFF
		} catch (Exception e) {
		// CHECKSTYLE:ON
			close();
			if (e instanceof GReportException) {
				throw e;
			}
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】このレポートを追記型に変更し、他のレポートクラス使って引き続き印刷を実行します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>このメソッドは GReport#endReport() 拡張ポイントでのみ使用して下さい。</B><BR>
	 *
	 * @param report_class_name レポートクラス名
	 * @param is_next_page 真偽値
	 * @throws GReportException ReportFrameowrk例外
	 * @create 2004/05/31
	 * @author
	 * @since 1.0.1
	 */
	public void printPostScript(String report_class_name, boolean is_next_page) throws GReportException {
		IReport report = createReport4PostScript(report_class_name, is_next_page);
		report.print();
	}

	/**
	 * 【機能】このレポートを追記型に変更し、他のレポートクラスとレポートリスト使って引き続き印刷を実行します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>このメソッドは GReport#endReport() 拡張ポイントでのみ使用して下さい。</B><BR>
	 *
	 * @param report_class_name レポートクラス名
	 * @param is_next_page 今のページ数を引き継ぐかの真偽値
	 * @param list_data レポートリスト
	 * @throws GReportException ReportFrameowrk例外
	 * @create 2010/08/03
	 * @author KCCS murashige
	 * @since 1.8.0
	 */
	public void printPostScript(String report_class_name, boolean is_next_page, IReportList list_data) throws GReportException {
		if (list_data == null) {
			throw new IllegalArgumentException("list_data is not found!");
		}
		IReport report = createReport4PostScript(report_class_name, is_next_page);
		report.print(list_data);
	}

	/**
	 * 【機能】VEを読み込まずレポートを印刷します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReport#print()
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public void print() throws GReportException {
		boolean isDebug = isDebug();
		GStopWatch gw = null;

		open();

		try {
			if (isDebug) {
				gw = new GStopWatch();
				System.out.println("create active report info start.");
				gw.start();
			}
			create();
			if (isDebug) {
				System.out.println("create active report info success. [" + gw.stop() + "ms]");
				System.out.println("print start.");
				gw.start();
			}
			startReport();

			// 初回のstartPage()はloadNextRecord()内で呼ばれます
			while (loadNextRecord()) {
				execute(getCurrentRecord());
			}

			endPage();

			checkPostScript();

			endReport();

			// 追記でなければ閉じる
			if (!_is_postscript) {
				close();
				if (isDebug) {
					long t = gw.stop();
					System.out.println("print finish. [" + t + "ms](" + (t / 1000.0) + "s)");
				}
			}
		// CHECKSTYLE:OFF
		} catch (Exception e) {
		// CHECKSTYLE:ON
			close();
			if (e instanceof GReportException) {
				throw e;
			}
			throw new GReportException(e);
		}
	}

	/**
	 * 【機能】レポートファイルを取得します。<BR>
	 * 【呼出】アクションビーン<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReport#getFile()
	 * @return ファイルオブジェクト
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public java.io.File getFile() {
		return new File(_file_path);
	}

	/**
	 * 【機能】endReport()直前に呼ばれ、追記フラグがオンならオフに変更します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void checkPostScript() {
		if (_is_postscript) {
			_is_postscript = false;
		}
	}

	/**
	 * 【機能】このレポートを追記型に変更します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】新たにprint()メソッドが呼ばれてもドキュメントをオープンしません。<BR>
	 * ドキュメントのクローズは自動的に呼ばれます。<BR>
	 * <B>このメソッドは GReport#endReport() 拡張ポイントでのみ使用して下さい。</B><BR>
	 *
	 * @param is_next_page ページ数を引き継ぐかの真偽値
	 * @throws GReportException ReportFrameowrk例外
	 * @create 2004/05/31
	 * @author
	 * @since 1.0.1
	 */
	protected void setPostScript(boolean is_next_page) throws GReportException {
		if (is_next_page) {
			setPageCount(getPageCount() + 1);
		} else {
			setPageCount(0);
			_page_count = 1;
		}

		_is_postscript = true;
	}

	/**
	 * 【機能】印刷日付を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param print_date 印刷日付
	 * @create 2004/05/31
	 * @author
	 * @since 1.0.1
	 */
	protected void setPrintDate(Date print_date) {
		_print_date = print_date;
	}

	/**
	 * 【機能】ドキュメントをオープンします。<BR>
	 * 【呼出】<BR>
	 * 【備考】ファイル名称の生成や初期値の設定も行っています。<BR>
	 *
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void open() throws GReportException {
		IReportWriter writer = getWriter();
		IReportInfo reportInfo = getReportInfo();

		_max_height = reportInfo.getRowCount();
		_max_width = reportInfo.getColumnCount();

		if (writer instanceof GPDFReportDriver) {
			((GPDFReportDriver) writer).setDefaultFont(reportInfo.getFontName(), reportInfo.getFontEncoding(), reportInfo.getFontSize());
			((GPDFReportDriver) writer).setFontNameBold(reportInfo.getFontNameBold());
			((GPDFReportDriver) writer).setFontNameItalic(reportInfo.getFontNameItalic());
			if (reportInfo.getUseFontFile() != null) {
				((GPDFReportDriver) writer).setUseFontFile(reportInfo.getUseFontFile());
			}
		}

		writer.setMargins(reportInfo.getLeftMargin(), reportInfo.getRightMargin(), reportInfo.getTopMargin(), reportInfo.getBottomMargin());

		int printDirection = getReportInfo().getPrintDirection();
		setPrintDirection(printDirection);
		if (isDebug()) {
			if (printDirection == IReportInfo.PRINT_DIRECTION_HORIZONTAL) {
				System.out.println("print direction:horizontal");
			} else {
				System.out.println("print direction:virtical");
			}
		}

		if (_is_postscript) {

			// --------------------------------------------------
			// 追記ならドキュメントオープンは行いません
			// --------------------------------------------------
			writer.initialize();
			writer.setColumnAndRow(_max_width, _max_height);
			clearParameter();
			return;

		}

		// --------------------------------------------------
		// ドライバをオープン前に初期化しておきます
		// --------------------------------------------------
		writer.setParperSize(reportInfo.getPaperSize());
		writer.setOrientation(reportInfo.getOrientation());

		setPringDate();
		setOutFilePath();

		writer.open(_file_path);
		writer.setColumnAndRow(_max_width, _max_height);
	}

	/**
	 * 帳票出力先のパスを設定します.
	 *
	 * @create 2014/12/23
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void setOutFilePath() {
		if (isSpecifiedFilePath()) {
			_file_path = getSpecifiedFilePath();

			File f = new File(_file_path);
			File parent = f.getParentFile();
			if (parent != null) {
				parent.mkdirs();
			}
			return;
		}

		String fileName = getFileName();
		StringBuilder filePath = new StringBuilder(GFrameworkUtils.getProperty("geframe.report.OutputDirectory"));
		filePath.append(java.io.File.separator);
		filePath.append(fileName);
		_file_path = filePath.toString();
	}

	/**
	 * 帳票出力日付を設定します.
	 *
	 * @create 2014/12/23
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void setPringDate() {
		Calendar c = Calendar.getInstance();
		_print_date = c.getTime();
	}

	/**
	 * 【機能】デバッグフラグを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param is_debug デバッグフラグ
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	void setDebug(boolean is_debug) {
		isDebug = is_debug;
	}

	/**
	 * 【機能】ファイル名を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】デフォルトは‘report_id-日付-16桁ランダム文字列.pdf’となります。<BR>
	 * オーバーライドしてご利用下さい。<BR>
	 *
	 * @return ファイル名
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected String getFileName() {
		String df = "yyyyMMddHHmmss";
		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat(df);
		String sysdate = format.format(getPrintDate());
		StringBuilder s = new StringBuilder();
		s.append(_report_id);
		s.append("-");
		s.append(sysdate);
		s.append("-");
		s.append(getRandomString(16));
		s.append(getWriter().getExtension());
		return s.toString();
	}

	/**
	 * 【機能】指定文字数のランダムに生成された文字列を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】ファイル名生成で使用しています。<BR>
	 *
	 * @param length 文字数
	 * @return 指定文字数のランダム文字列
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected String getRandomString(int length) {
		StringBuilder sb = new StringBuilder();
		final char[] ch = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
		for (int i = 0; i < length; i++) {
			int rand = (int) Math.round(Math.random() * (ch.length - 1));
			sb.append(ch[rand]);
		}
		return sb.toString();
	}

	/**
	 * 【機能】イメージディレクトリパスを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return イメージディレクトリパス
	 * @create 2004/04/20
	 * @author
	 * @since 1.0.0
	 */
	public String getImageDirectory() {
		return _image_dir;
	}

	/**
	 * 【機能】レポートにグリッドラインを表示することのできる拡張ポイントです。<BR>
	 * 【呼出】API<BR>
	 * 【備考】オーバーライドしてご利用ください。<BR>
	 *
	 * @return 真偽値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public boolean setRuledLine() {
		return false;
	}

	/**
	 * 【機能】ドキュメントをクローズします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void close() throws GReportException {
		getWriter().close();
	}

	/**
	 * 【機能】印刷日時を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 印刷日付
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public Date getPrintDate() {
		return _print_date;
	}

	/**
	 * 【機能】現在のページ数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return ページ数
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public int getPageCount() {
		return _page_count;
	}

	/**
	 * 【機能】現在のページ数を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param count ページ数
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public void setPageCount(int count) throws GReportException {
		_page_count = count;

		if (count == 0) {
			getWriter().resetPageCount();
			return;
		}

		getWriter().setPageCount(count);
	}

	/**
	 * 【機能】ページ数をリセットします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】pageBreak()直前で呼び出してください。<BR>
	 * 最大ページ数はリセットされます。<BR>
	 *
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public void resetPageCount() throws GReportException {
		setPageCount(0);
	}

	/**
	 * 【機能】抑止の値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスからこのメソッドを使用することは推奨されません。<BR>
	 *
	 * @param key 抑止キー
	 * @return 抑止値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	Object getOmitValue(Object key) {
		return (String) preOmitTable.get(key);
	}

	/**
	 * 【機能】抑止用の値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスからこのメソッドを使用することは推奨されません。<BR>
	 *
	 * @param key 抑止キー
	 * @param value 抑止値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	void setOmitValue(Object key, Object value) {
		if (value == null) {
			value = "";
		}
		preOmitTable.put((String) key, (String) value);
	}

	/**
	 * 【機能】抑止キーが既に登録されているか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスからこのメソッドを使用することは推奨されません。<BR>
	 *
	 * @param key 抑止キー
	 * @return 真偽値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	boolean hasOmitKey(Object key) {
		return preOmitTable.containsKey(key);
	}

	/**
	 * 【機能】抑止の値をすべてクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void clearOmitValue() {
		preOmitTable.clear();
	}

	/**
	 * 【機能】抑止の値をフィールド名指定でクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param field_name フィールド名
	 * @create 2004/06/01
	 * @author
	 * @since 1.0.1
	 */
	protected void removeOmitValue(String field_name) {
		preOmitTable.remove(field_name);
	}

	/**
	 * 【機能】網掛け用カウントをリセットします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected void resetBorderCount() {
		_border_count = 0;
	}

	/**
	 * 【機能】網掛け用カウントの値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 網掛け用カウント
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	int getBorderCount() {
		return _border_count;
	}

	/**
	 * 【機能】コントロールブレイクキーの配列を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return コントロールブレイクキー配列
	 * @create 2004/06/30
	 * @author
	 * @since 1.0.2
	 */
	IControlBreakInfo[] getBreakInfo() {
		return _break_info;
	}

	/**
	 * 【機能】網掛け用カウントの値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param count 加算値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	void addBorderCount(int count) {
		_border_count += count;
	}

	/**
	 * 【機能】ユーザ別のレポート情報を生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	private void create() throws GReportException {

		createActiveInfo();

		for (ISectionInfo sectionInfo : getReportInfo().getSectionInfos()) {
			IReportSection section = createReportSection(sectionInfo);
			_section_map.put(sectionInfo.getName(), section);
		}
	}

	/**
	 * セクションを生成します。<BR>
	 *
	 * @param sectionInfo セクション情報
	 * @return セクション
	 * @throws GReportException ReportFrameowrk例外
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected IReportSection createReportSection(ISectionInfo sectionInfo) throws GReportException {
		IReportSection section = GFrameworkUtils.getComponent(IReportSection.class.getName());
		section.setReport(this);
		section.load(sectionInfo);
		return section;
	}

	/**
	 * 【機能】アクティブな情報を生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスによって保持されます。<BR>
	 *
	 * @throws GReportException ReportFrameowrk例外
	 * @create 2004/06/30
	 * @author
	 * @since 1.0.2
	 */
	private void createActiveInfo() throws GReportException {

		setControlBreakInfo();

		try {
			_image_dir = GFrameworkUtils.getProperty("geframe.report.ImageDirectory") + File.separator;
		} catch (MissingResourceException e) {
			_image_dir = null;
		}
	}

	/**
	 * コントロールブレイク情報を設定します.
	 *
	 * @create 2014/12/23
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private void setControlBreakInfo() {
		List<IControlBreakInfo> breakList = getReportInfo().getControlBreakList();
		int size = breakList.size();
		IControlBreakInfo[] breakInfo = new IControlBreakInfo[size];
		for (int i = 0; i < size; i++) {
			breakInfo[i] = createControlBreakInfo(breakList.get(i).getName());
		}
		_break_info = breakInfo;
	}

	/**
	 * コントロールブレイクキー情報を生成します。<BR>
	 *
	 * @param name 名称
	 * @return コントロールブレイクキー情報
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected IControlBreakInfo createControlBreakInfo(String name) {
		IControlBreakInfo ctrBreakInfo = GFrameworkUtils.getComponent(IControlBreakInfo.class.getName());
		ctrBreakInfo.setName(name);
		return ctrBreakInfo;
	}

	/**
	 * 【機能】追記用レポートクラスを生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスには、マネージャ、印刷日時、 各種フラグ( ドキュメントを閉じない&新規オープンしない)、ページ数をセットします。<BR>
	 *
	 * @param report_class_name レポートクラス名
	 * @param is_next_page 真偽値
	 * @return レポートクラス
	 * @throws GReportException ReportFrameowrk例外
	 * @create 2010/08/03
	 * @author KCCS murashige
	 * @since 1.8.0
	 */
	protected IReport createReport4PostScript(String report_class_name, boolean is_next_page) throws GReportException {
		// ----------------------------------------
		// パラメータ設定
		// ----------------------------------------
		// このドキュメントは閉じない
		_is_postscript = true;
		GStdReport report = GReportFactory.get(report_class_name, getWriter());
		// パラメータを引き継ぐ
		report.setPrintDate(getPrintDate());
		// ドキュメントを新規オープンしない
		report.setPostScript(true);
		// ----------------------------------------
		// ページ数をリセットします
		// ----------------------------------------
		if (is_next_page) {
			int page = getPageCount() + 1;
			report.setPageCount(page);
			report.getWriter().setPageCount(page);
		} else {
			report.getWriter().resetPageCount();
			report.setPageCount(1);
		}
		return report;
	}

	@Override
	public IReportInfo getReportInfo() {
		IReportInfo reportInfo = super.getReportInfo();
		if (reportInfo == null) {
			try {
				reportInfo = getRepositoryFactory().get(_report_id);
				setReportInfo(reportInfo);
			} catch (GReportException e) {
				throw new GReportRuntimeException(e);
			}
		}
		return reportInfo;
	}

	/**
	 * 【機能】レポートIDを設定し、レポート情報を生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートIDからレポート情報を生成します。内部的にサービスも生成されます。<BR>
	 * <B>このメソッドは以下の①、②以外では使用しないで下さい。予期しない動作をする可能性があります。</B><BR>
	 * ①print()メソッドの呼び出し以前。（例えばアクションビーンやgetOutput系の拡張ポイントから呼び出し）<BR>
	 * ②endReport()拡張ポイント<BR>
	 *
	 * @param report_id レポートID
	 * @throws GReportException ReportFrameowrk例外
	 * @create 2004/05/08
	 * @author
	 * @since 1.0.1
	 */
	public void setReportID(String report_id) throws GReportException {
		GStopWatch gw = null;

		_report_id = report_id;

		if (isDebug()) {
			System.out.println("REPORT_ID: [" + _report_id + "]");
			gw = new GStopWatch();
			System.out.println("create report info start.");
			gw.start();
		}

		setReportInfo(getRepositoryFactory().get(_report_id));

		if (isDebug()) {
			System.out.println("create report info success. [" + gw.stop() + "ms]");
		}
	}

	/**
	 * 【機能】現在のレポートレコードを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReport#getCurrentRecord()
	 * @return レポートレコード
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Override
	public IReportRecord getCurrentRecord() {
		return _record;
	}

	/**
	 * 【機能】現在のレポートレコードを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスからこのメソッドを使用することは推奨されません。<BR>
	 *
	 * @param record レポートレコード
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	void setCurrentRecord(IReportRecord record) {
		_record = record;
	}

	/**
	 * 【機能】現在のレコードが最後のレコードか判定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return 真偽値
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected boolean isLastRecord() {

		if (_is_first_load) {
			return false;
		}

		if (_next_record == null) {
			return true;
		}

		return false;
	}

	/**
	 * 【機能】指定ブレイクキーの一つ前の値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param break_key_name ブレイクキー名称
	 * @return ブレイクキー
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected String getPreBreakValue(String break_key_name) {
		return _break_manager.getPreBreakValue(break_key_name);
	}

	/**
	 * 【機能】一つ前のレコードを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートレコードがまだ読み込まれていない場合、nullが返されます。<BR>
	 *
	 * @return レポートレコード
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	protected IReportRecord getPreRecord() {
		return _pre_record;
	}

	/**
	 * 【機能】他の帳票レイアウト上のセクションを自身に追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】他の帳票レイアウトに同じ名前のセクションが定義されていてもマージされず、レポートID毎に紐付けられます。<BR>
	 * これにより、複数のレイアウトを切り替えながら帳票を出力可能となります。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.AbstractReport#appendSections(java.lang.String)
	 * @param report_id レポートID
	 * @throws GReportException ReportFramework例外
	 * @create 2006/09/26
	 * @author takaishi
	 * @since 1.2.0
	 */
	@Override
	public void appendSections(String report_id) throws GReportException {

		super.appendSections(report_id);

		for (ISectionInfo sectionInfo: getReportInfo().getSectionInfos()) {

			if (_section_map.get(sectionInfo.getName()) != null) {
				continue;
			}

			IReportSection section = createReportSection(sectionInfo);
			_section_map.put(sectionInfo.getName(), section);
		}
	}
}
