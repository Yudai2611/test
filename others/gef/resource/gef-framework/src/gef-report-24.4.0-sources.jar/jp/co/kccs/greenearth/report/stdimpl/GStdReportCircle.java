/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReport;
import jp.co.kccs.greenearth.report.IReportCircle;
import jp.co.kccs.greenearth.report.IReportSection;
import jp.co.kccs.greenearth.report.ISectionElementGroup;
import jp.co.kccs.greenearth.report.repository.ICircleInfo;
import jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo;

/**
 * 【役割】サークルを表します。<BR>
 * 【生成】リクエストごとにセクションにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdReportCircle extends GStdCircleInfo implements IReportCircle {

	/** セクション */
	private GStdReportSection _section = null;
	/** 静的情報 */
	private ICircleInfo _static_info = null;

	/**
	 * @see jp.co.kccs.greenearth.report.IReportCircle#load(jp.co.kccs.greenearth.report.repository.ICircleInfo, jp.co.kccs.greenearth.report.IReportSection)
	 * @param info サークル情報
	 * @param section セクション
	 */
	@Override
	public void load(ICircleInfo info, IReportSection section) {
		createActiveInfo(info, section);
	}

	/**
	 * セクションを取得します.
	 * 
	 * @return セクション
	 * @create
	 * @author
	 * @since 
	 */
	GStdReportSection getSection() {
		if (_section == null) {
			throw new GReportRuntimeException("section is not set.");
		}
		return _section;
	}
	
	/**
	 * サークル情報を取得します.
	 * 
	 * @return サークル情報
	 * @create
	 * @author
	 * @since 
	 */
	ICircleInfo getCircleInfo() {
		return _static_info;
	}
	
	/**
	 * 【機能】動的情報を生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param info サークル情報
	 * @param section セクション
	 */
	protected void createActiveInfo(ICircleInfo info, IReportSection section) {
		_section = (GStdReportSection) section;
		_static_info = info;

		initialize();
	}

	/**
	 * 【機能】サークル情報を初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】XML情報に初期化します。<BR>
	 * 
	 * @create 2004/07/01
	 * @since 1.0.2
	 */
	public void initialize() {
		super.setName(getCircleInfo().getName());
		super.setTop(getCircleInfo().getTop());
		super.setType(getCircleInfo().getType());
		super.setLeft(getCircleInfo().getLeft());
		super.setHeight(getCircleInfo().getHeight());
		super.setWidth(getCircleInfo().getWidth());
		super.setLineWidth(getCircleInfo().getLineWidth());
		super.setOutput(getCircleInfo().getOutput());
		super.setTrueCircle(getCircleInfo().getTrueCircle());
		super.setDashInfo(getCircleInfo().getDashInfo());
	}

	/**
	 * 【機能】点線情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param units_on ユニッツオン
	 * @param phase フェーズ
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	protected void setDashInfo(int units_on, int phase) {
		super.setDash(units_on);
		super.setGap(phase);
	}

	/**
	 * 【機能】点線を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param units_on ユニッツオン
	 * @param phase フェーズ
	 * @create 2004/08/31
	 * @since 1.0.3
	 */
	public void setDash(int units_on, int phase) {
		if (_section == null) {
			setDashInfo(units_on, phase);
			setType(ICircleInfo.TYPE_CUSTOM_DASH);
			return;
		}

		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setDashInfo(units_on, phase);
				circle.setType(ICircleInfo.TYPE_CUSTOM_DASH);
			}
		} else {
			setDashInfo(units_on, phase);
		}
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setHeight(int)
	 * @param height 高さ
	 */
	@Override
	public void setHeight(int height) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setHeightInfo(height);
			}
		} else {
			setHeightInfo(height);
		}
	}

	/**
	 * 高さを設定します。
	 * 
	 * @param height 高さ
	 */
	protected void setHeightInfo(int height) {
		super.setHeight(height);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setLeft(int)
	 * @param left 左端
	 */
	@Override
	public void setLeft(int left) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setLeftInfo(left);
			}
		} else {
			setLeftInfo(left);
		}
	}

	/**
	 * 左端を設定します。
	 * 
	 * @param left 左端
	 */
	protected void setLeftInfo(int left) {
		super.setLeft(left);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setTop(int)
	 * @param top 上端
	 */
	@Override
	public void setTop(int top) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setTopInfo(top);
			}
		} else {
			setTopInfo(top);
		}
	}

	/**
	 * 上端を設定します。
	 * 
	 * @param top 上端
	 */
	protected void setTopInfo(int top) {
		super.setTop(top);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setWidth(int)
	 * @param width 幅
	 */
	@Override
	public void setWidth(int width) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setWidthInfo(width);
			}
		} else {
			setWidthInfo(width);
		}
	}

	/**
	 * 幅を設定します。
	 * 
	 * @param width 幅
	 */
	protected void setWidthInfo(int width) {
		super.setWidth(width);
	}

	/**
	 * 【機能】ライン幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setLineWidth(double)
	 * @param line_width ライン幅
	 * @since 1.0.0
	 */
	@Override
	public void setLineWidth(double line_width) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setLineWidthInfo(line_width);
			}
		} else {
			setLineWidthInfo(line_width);
		}
	}

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setOutput(boolean)
	 * @param output 表示/非表示
	 * @since 1.0
	 */
	@Override
	public void setOutput(boolean output) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setOutputInfo(output);
			}
		} else {
			setOutputInfo(output);
		}
	}

	/**
	 * 【機能】正円に設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setTrueCircle(int)
	 * @param option 正円オプション
	 * @since 1.0
	 */
	@Override
	public void setTrueCircle(int option) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setTrueCircleInfo(option);
			}
		} else {
			setTrueCircleInfo(option);
		}
	}

	/**
	 * 【機能】タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdCircleInfo#setType(int)
	 * @param type タイプ
	 * @since 1.0
	 */
	@Override
	public void setType(int type) {
		ISectionElementGroup group = getSection().getCircleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportCircle circle = (GStdReportCircle) group.get(i);
				circle.setTypeInfo(type);
			}
		} else {
			setTypeInfo(type);
		}
	}

	/**
	 * 【機能】ライン幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param line_width ライン幅
	 * @since 1.0.0
	 */
	protected void setLineWidthInfo(double line_width) {
		super.setLineWidth(line_width);
	}

	/**
	 * 【機能】フィールド変数の表示値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param output 表示/非表示
	 * @since 1.0.0
	 */
	protected void setOutputInfo(boolean output) {
		super.setOutput(output);
	}

	/**
	 * 【機能】正円に設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param option 正円オプション
	 * @since 1.0.0
	 */
	protected void setTrueCircleInfo(int option) {
		super.setTrueCircle(option);
	}

	/**
	 * 【機能】タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type タイプ
	 * @since 1.0.0
	 */
	protected void setTypeInfo(int type) {
		super.setType(type);
	}

	/**
	 * 【機能】サークルを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportCircle#print()
	 * @throws GReportException ReportFramework例外
	 * @since 1.0.0
	 */
	@Override
	public void print() throws GReportException {

		if (!getOutput()) {
			return;
		}

		getSection().calcAbsolutePosition();

		IReport report = getSection().getReport();
		report.getWriter().writeCircle(getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), getHeight(), getWidth(), getLineWidth(), getType(), getTrueCircle(), getDashInfo());
	}

	/**
	 * 【機能】プレースホルダを印刷します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportCircle#printPlaceHolder()
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void printPlaceHolder() throws GReportException {

		if (!getOutput()) {
			return;
		}

		IReport report = getSection().getReport();
		report.getWriter().writeTemplateCircle(getSection().getName(), getLeft(), getTop(), getHeight(), getWidth(), getLineWidth(), getType(), getTrueCircle());
	}
}
