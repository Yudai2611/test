/*
 * Copyright 2014-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.awt.Color;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReportField;
import jp.co.kccs.greenearth.report.IReportLine;
import jp.co.kccs.greenearth.report.IReportRecord;
import jp.co.kccs.greenearth.report.IReportSection;
import jp.co.kccs.greenearth.report.IReportWriter;
import jp.co.kccs.greenearth.report.ISectionElementGroup;
import jp.co.kccs.greenearth.report.repository.IFieldInfo;
import jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo;

/**
 * 【役割】フィールドを表します。<BR>
 * 【生成】セクションにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 *
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdReportField extends GStdFieldInfo implements IReportField {

	/* 変数 */
	/** セクション */
	private GStdReportSection _section = null;
	/** 静的情報 */
	private IFieldInfo _static_info = null;

	/* 動的情報 */
	/**
	 * 日付フォーマット文字列<BR>
	 * [0] インプットフォーマット<BR>
	 * [1] アウトプットフォーマット<BR>
	 */
	private String[] _date_format = null;
	/** 数値フォーマット文字列 */
	private String _decimal_format = null;
	/** 追加フォーマット */
	private boolean _add_format = false;
	/** プレースホルダ */
	private String _place_holder = null;

	/**
	 * 静的情報をロードします.
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#load(jp.co.kccs.greenearth.report.repository.IFieldInfo, jp.co.kccs.greenearth.report.IReportSection)
	 * @param info フィールド情報
	 * @param section セクション
	 * @create
	 * @author
	 * @since
	 */
	@Override
	public void load(IFieldInfo info, IReportSection section) {
		createActiveInfo(info, section);
	}

	/**
	 * 【機能】動的情報を生成します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @param info フィールド情報
	 * @param section セクション
	 */
	protected void createActiveInfo(IFieldInfo info, IReportSection section) {
		_section = (GStdReportSection) section;
		_static_info = info;

		initialize();
	}

	/**
	 * セクションを取得します.
	 *
	 * @return セクション
	 * @create
	 * @author
	 * @since
	 *
	 */
	GStdReportSection getSection() {
		if (_section == null) {
			throw new GReportRuntimeException("section is not set.");
		}
		return _section;
	}

	/**
	 * 【機能】フィールドを初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】XML情報に初期化されます。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#initialize()
	 * @create 2004/07/01
	 * @since 1.0.2
	 */
	public void initialize() {
		IFieldInfo info = _static_info;
		super.setAlignment(info.getAlignment());
		super.setTop(info.getTop());
		super.setLeft(info.getLeft());
		super.setWidth(info.getWidth());
		super.setHeight(info.getHeight());
		super.setFontZoom(info.getFontZoom());
		super.setFontInterval(info.getFontInterval());
		super.setFontHeight(info.getFontHeight());
		super.setFontSize(info.getFontSize());
		super.setName(info.getName());
		super.setValue(info.getValue());
		super.setType(info.getType());
		super.setFormat(info.getFormat());
		super.setInputFormat(info.getInputFormat());
		super.setOmitSameValue(info.getOmitSameValue());
		super.setOutput(info.getOutput());
		super.setFontFace(info.getFontFace());
		super.setBackGroundColor(info.getBackGroundColor());
		super.setRotation(info.getRotation());
		super.setFontEncoding(info.getFontEncoding());
		super.setFontName(info.getFontName());
		super.setFontNameBold(info.getFontNameBold());
		super.setFontNameItalic(info.getFontNameItalic());
		super.setUseFontFile(info.isUseFontFile());
		super.setPositionAdjustmentX(info.getPositionAdjustmentX());
		super.setPositionAdjustmentY(info.getPositionAdjustmentY());
		if (info.getUnderLineInfo() != null) {
			createUnderLine();
		}
		super.setMultiLine(info.getMultiLine());

		_place_holder = null;
		resetFormat();
	}

	/**
	 * 【機能】アンダーラインを消去します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#removeUnderLine()
	 * @create 2004/07/05
	 * @since 1.0.2
	 */
	@Override
	public void removeUnderLine() {
		super.setUnderLine(null);
	}

	/**
	 * 【機能】設定フォーマットをリセットします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】レポートクラスで設定したフォーマットがリセットされます。<BR>
	 *
	 * @create 2004/06/30
	 * @since 1.0.2
	 */
	public void resetFormat() {
		_date_format = null;
		_decimal_format = null;
		_add_format = false;
	}

	/**
	 * 【機能】背景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setBackGroundColor(java.awt.Color)
	 * @param color 背景色
	 * @create 2004/07/05
	 * @since 1.0.2
	 */
	@Override
	public void setBackGroundColor(Color color) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setBackGroundColorInfo(color);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setBackGroundColorInfo(color);
		}
	}

	/**
	 * 【機能】前景色を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setForeColor(java.awt.Color)
	 * @param color 前景色
	 * @create 2010/08/03
	 * @author KCCS murashige
	 * @since 1.8.0
	 */
	@Override
	public void setForeColor(Color color) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setForeColorInfo(color);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setForeColorInfo(color);
		}
	}

	/**
	 * 高さを設定します.
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setHeight(int)
	 * @param height 高さ
	 * @create
	 * @author
	 * @since
	 */
	@Override
	public void setHeight(int height) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setHeightInfo(height);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setHeightInfo(height);
		}
	}

	/**
	 * 左位置を設定します.
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setLeft(int)
	 * @param left 左
	 * @create
	 * @author
	 * @since
	 */
	@Override
	public void setLeft(int left) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setLeftInfo(left);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField field = (GStdReportField) group.get(i);
			field.setLeftInfo(left);
		}
	}

	/**
	 * 高さを設定します.
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setTop(int)
	 * @param top 高さ
	 * @create
	 * @author
	 * @since
	 */
	@Override
	public void setTop(int top) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setTopInfo(top);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setTopInfo(top);
		}
	}

	/**
	 * 幅を設定します.
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setWidth(int)
	 * @param width 幅
	 * @create
	 * @author
	 * @since
	 */
	@Override
	public void setWidth(int width) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setWidthInfo(width);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setWidthInfo(width);
		}
	}

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setOutput(boolean)
	 * @param output 表示/非表示フラグ
	 * @since 1.0.0
	 */
	@Override
	public void setOutput(boolean output) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setOutputInfo(output);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setOutputInfo(output);
		}
	}

	/**
	 * 【機能】数値フォーマットを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#setDecimalFormat(java.lang.String)
	 * @param format フォーマット
	 * @since 1.0.0
	 */
	@Override
	public void setDecimalFormat(String format) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setFormat(null, format);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setFormat(null, format);
		}
	}

	/**
	 * 【機能】日付フォーマットを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#setDateFormat(java.lang.String, java.lang.String)
	 * @param in_format 入力フォーマット
	 * @param out_format 出力フォーマット
	 * @create 2004/05/20
	 * @since 1.0.1
	 */
	@Override
	public void setDateFormat(String in_format, String out_format) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setFormat(in_format, out_format);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setFormat(in_format, out_format);
		}
	}

	/**
	 * ローテーションを設定します.
	 *
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdFieldInfo#setRotation(int)
	 * @param rotation ローテーション
	 * @create
	 * @author
	 * @since
	 */
	@Override
	public void setRotation(int rotation) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {
			setRotationInfo(rotation);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField f = (GStdReportField) group.get(i);
			f.setRotationInfo(rotation);
		}

	}

	/**
	 * 【機能】背景色情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param color 前景色
	 * @create 2004/07/05
	 * @since 1.0.2
	 */
	protected void setBackGroundColorInfo(Color color) {
		super.setBackGroundColor(color);
	}

	/**
	 * 【機能】前景色情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param color 前景色
	 * @create 2010/08/03
	 * @author KCCS murashige
	 * @since 1.8.0
	 */
	protected void setForeColorInfo(Color color) {
		super.setForeColor(color);
	}

	/**
	 * 高さを設定します.
	 *
	 * @param height 高さ
	 * @create
	 * @author
	 * @since
	 */
	protected void setHeightInfo(int height) {
		super.setHeight(height);
	}

	/**
	 * 左位置を設定します.
	 *
	 * @param left 左
	 * @create
	 * @author
	 * @since
	 */
	protected void setLeftInfo(int left) {
		super.setLeft(left);
	}

	/**
	 * 高さ位置を設定します.
	 *
	 * @param top 高さ
	 * @create
	 * @author
	 * @since
	 */
	protected void setTopInfo(int top) {
		super.setTop(top);
	}

	/**
	 * 幅を設定します.
	 *
	 * @param width 幅
	 * @create
	 * @author
	 * @since
	 */
	protected void setWidthInfo(int width) {
		super.setWidth(width);
	}

	/**
	 * 【機能】プレースホルダを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @return プレースホルダ
	 * @create 2004/03/30
	 * @since 1.0.0
	 */
	public String getPlaceHolder() {
		return _place_holder;
	}

	/**
	 * 【機能】フォーマットを指定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】in/out共に設定されていると日付フォーマットとみなす。outだけだと数値フォーマットとみなす。<BR>
	 *
	 * @param in_format 入力フォーマット
	 * @param out_format 出力フォーマット
	 * @since 1.0.0
	 */
	protected void setFormat(String in_format, String out_format) {
		_add_format = true;

		if (in_format != null) {
			_date_format = new String[2];
			_date_format[0] = in_format;
			_date_format[1] = out_format;
		} else {
			_decimal_format = out_format;
		}
	}

	/**
	 * 【機能】アンダーラインを生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#createUnderLine()
	 * @create 2004/06/15
	 * @since 1.0.2
	 */
	@Override
	public void createUnderLine() {
		super.setUnderLine(createReportLine());
	}

	/**
	 * @return 線
	 */
	protected IReportLine createReportLine() {
		return GFrameworkUtils.getComponent(IReportLine.class.getName());
	}

	/**
	 * 【機能】値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】同じ名前のフィールドの値はすべて書き換えられます。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#setValue(java.lang.Object)
	 * @param value 値
	 * @since 1.0.0
	 */
	@Override
	public void setValue(Object value) {

		ISectionElementGroup group = getSection().getFieldGroup(getName());

		if (group == null) {

			if (getType().equals(IFieldInfo.TYPE_DATA)) {
				final IReportRecord record = getSection().getReport().getCurrentRecord();
				record.setVariable(getName(), value);
				return;
			}

			setValueInfo(value);
			return;
		}

		for (int i = 0; i < group.size(); i++) {
			GStdReportField field = (GStdReportField) group.get(i);

			if (field.getType().equals(IFieldInfo.TYPE_DATA)) {
				final IReportRecord record = getSection().getReport().getCurrentRecord();
				record.setVariable(getName(), value);
			} else {
				field.setValueInfo(value);
			}
		}
	}

	/**
	 * 【機能】フィールド変数の値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param value 値
	 * @since 1.0.0
	 * @author kusakari
	 */
	protected void setValueInfo(Object value) {
		if (value == null) {
			super.setValue("");
			return;
		}

		super.setValue(value.toString());
	}

	/**
	 * 【機能】フィールド変数の表示値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param output 表示/非表示フラグ
	 * @since 1.0.0
	 */
	protected void setOutputInfo(boolean output) {
		super.setOutput(output);
	}

	/**
	 * 【機能】許可値表示タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>サポートしません。
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#setPermissionDisplayType(int)
	 * @param type タイプ
	 * @since 1.0.0
	 */
	@Override
	public void setPermissionDisplayType(int type) {
	}

	/**
	 * 【機能】プレースホルダを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】プレースホルダを設定するフィールドは一意な名前が付けられている必要があります。<BR>
	 *      複数の同名フィールドにプレースホルダを設定しようとした場合、最初に見つかったフィールドにだけプレースホルダが設定されます。<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#setPlaceHolder()
	 * @since 1.0.0
	 */
	@Override
	public void setPlaceHolder() {
		_place_holder = getName();
	}

	/**
	 * @param rotation ローテーション
	 */
	protected void setRotationInfo(int rotation) {
		super.setRotation(rotation);
	}

	/**
	 * 【機能】このフィールドを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#print()
	 * @throws GReportException ReportFramework例外
	 * @author kusakari
	 */
	@Override
	public void print() throws GReportException {

		if (!getOutput()) {
			return;
		}

		GStdReport report = (GStdReport) getSection().getReport();
		IReportWriter writer = report.getWriter();

		String data = getData(report, writer, true);
		if (data == null) {
			return;
		}

		writeString(writer, data);
	}

	/**
	 * 【機能】セクションプレースホルダの印刷用です。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @throws GReportException ReportFramework例外
	 * @author kusakari
	 */
	@Override
	public void printPlaceHolder() throws GReportException {

		if (!getOutput()) {
			return;
		}

		GStdReport report = (GStdReport) getSection().getReport();
		IReportWriter writer = report.getWriter();

		String data = getData(report, writer, false);
		if (data == null) {
			return;
		}

		if (getFontSize() == -1) {
			writer.writeTemplate(getSection().getName(), getLeft(), getTop(), data, getFontZoom(), getAlignment(), getWidth(), getFontFace(), getFontHeight(), getPositionAdjustmentX(), getPositionAdjustmentY(), getFontEncoding(), getFontName(), getFontNameBold(), getFontNameItalic(), isUseFontFile());
		} else {
			writer.writeTemplateNonGrid(getSection().getName(), getLeft(), getTop(), data, getFontZoom(), getAlignment(), getWidth(), getFontFace(), getFontSize(), getFontInterval(), getFontHeight(), getHeight(), getBackGroundColor(), getPositionAdjustmentX(), getPositionAdjustmentY(), getFontEncoding(), getFontName(), getFontNameBold(), getFontNameItalic(), isUseFontFile());
		}
	}

	/**
	 * 【機能】設定済みプレースホルダに文字列を書き込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @see jp.co.kccs.greenearth.report.IReportField#printPlaceHolder(java.lang.Object)
	 * @param placeHolderValue 書き込む文字列
	 * @throws GReportException ReportFramework例外
	 * @author kusakari
	 */
	@Override
	public void printPlaceHolder(Object placeHolderValue) throws GReportException {
		if (getPlaceHolder() == null) {
			return;
		}

		GStdReport report = (GStdReport) getSection().getReport();
		IReportWriter writer = report.getWriter();

		String value = formatValueForData(placeHolderValue.toString());

		if (getFontSize() == -1) {
			writer.writeTemplate(getPlaceHolder(), 0, 0, value, getFontZoom(), getAlignment(), getWidth(), getFontFace(), getHeight(), getPositionAdjustmentX(), getPositionAdjustmentY(), getFontEncoding(), getFontName(), getFontNameBold(), getFontNameItalic(), isUseFontFile());
		} else {
			writer.writeTemplateNonGrid(getPlaceHolder(), 0, 0, value, getFontZoom(), getAlignment(), getWidth(), getFontFace(), getFontSize(), getFontInterval(), getFontHeight(), getHeight(), getBackGroundColor(), getPositionAdjustmentX(), getPositionAdjustmentY(), getFontEncoding(), getFontName(), getFontNameBold(), getFontNameItalic(), isUseFontFile());
		}

		writer.clearTemplate(getPlaceHolder());
	}

	/**
	 * 値をフォーマットします（汎用）.
	 *
	 * @param data フォーマットする値
	 * @return フォーマットした値
	 * @create 2014/12/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private String formatValueForData(String data) {
		// Formatが指定されていた場合
		if (_add_format) {
			return getFormatValue(data);
		}

		// デザイナフォーマット(input)
		if (getInputFormat() != null) {
			_decimal_format = null;
			_date_format = new String[2];
			_date_format[0] = getInputFormat();
			if (getFormat() != null) {
				_date_format[1] = getFormat();
			} else {
				_date_format[1] = getDefaultDateFormat();
			}
			return getFormatValue(data);
		}

		// デザイナフォーマット
		if (getFormat() != null) {
			_decimal_format = getFormat();
			return getFormatValue(data);
		}

		return data;
	}

	/**
	 * 数値をフォーマットします.
	 *
	 * @param data フォーマットする値
	 * @return フォーマットした値
	 * @create 2014/12/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private String formatValueForNumber(String data) {
		if (_add_format) {
			return getFormatValue(data);
		} else if (getFormat() != null) {
			_decimal_format = getFormat();
			return getFormatValue(data);
		}
		return data;
	}

	/**
	 * 日付をフォーマットします.
	 *
	 * @param data フォーマットする値
	 * @return フォーマットした値
	 * @create 2014/12/25
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private String formatValueForDate(Date data) {

		SimpleDateFormat format = null;

		if (_add_format) {
			format = new SimpleDateFormat(_date_format[1]);
		} else if (getFormat() == null) {
			format = new SimpleDateFormat(getDefaultDateFormat());
		} else {
			format = new SimpleDateFormat(getFormat());
		}

		return format.format(data);
	}

	/**
	 * 【機能】フォーマット変換された文字列を返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<B>優先順位はレポートクラス＞デザイナです。</B><BR>
	 *      数値フォーマットor日付フォーマット<BR>
	 *
	 * @param work_data 対象文字列
	 * @return 変換後文字列
	 * @author kusakari
	 */
	protected String getFormatValue(String work_data) {
		if (work_data == null || work_data.length() < 1) {
			return "";
		}

		try {
			if (_decimal_format != null) {

				DecimalFormat decimal = new DecimalFormat(_decimal_format);

				return decimal.format(new BigDecimal(work_data));
			}

			if (_date_format != null) {

				SimpleDateFormat inFormat = new SimpleDateFormat(_date_format[0]);
				SimpleDateFormat outFormat = new SimpleDateFormat(_date_format[1]);
				Date date = inFormat.parse(work_data);

				return outFormat.format(date);
			}
		} catch (NumberFormatException | ParseException e) {
			throw new GReportRuntimeException(e);
		}

		return "format error.:" + getName();
	}

	/**
	 * 抑止用に値を最適化する.
	 *
	 * @param value 最適化する値
	 * @return 最適化した値
	 * @create 2014/12/25
	 * @author KCCS hashimoto
	 * @throws GReportException ReportFramework例外
	 * @since
	 */
	private String optimazeValueForOmit(String value) throws GReportException {
		if (getOmitSameValue()) {
			return omit(value);
		}

		return value;
	}

	/**
	 * 【機能】文字列を書き込みます。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param writer レポートライター
	 * @param data 文字列
	 * @throws GReportException ReportFramework例外
	 * @since 1.0.0
	 */
	protected void writeString(IReportWriter writer, String data) throws GReportException {
		if (data == null) {
			data = "";
		}

		String[] lines = null;
		if (writer instanceof jp.co.kccs.greenearth.report.driver.GPDFReportDriver && getMultiLine()) {
			lines = createMultiLineString(data, getWidth(), getHeight(), getFontSize(), getFontZoom(), getFontInterval(), getFontHeight(), writer.getGridWidth(), writer.getGridHeight());
		} else {
			lines = new String[1];
			lines[0] = data;
		}

		if (getFontSize() == -1) {
			writer.writeString(getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), lines, getFontZoom(), getAlignment(), getWidth(), getFontFace(), getFontHeight(), getHeight(), getForeColor() == null ? Color.BLACK : getForeColor(), getBackGroundColor(), getUnderLine(), getPositionAdjustmentX(), getPositionAdjustmentY(), getFontEncoding(), getFontName(), getFontNameBold(), getFontNameItalic(), isUseFontFile());
		} else {
			writer.writeNonGridString(getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), lines, getFontZoom(), getAlignment(), getWidth(), getFontFace(), getFontSize(), getFontInterval(), getFontHeight(), getHeight(), getForeColor() == null ? Color.BLACK : getForeColor(), getBackGroundColor(), getUnderLine(), getPositionAdjustmentX(), getPositionAdjustmentY(), getFontEncoding(), getFontName(), getFontNameBold(), getFontNameItalic(), isUseFontFile());
		}
	}

	/**
	 * 【機能】フィールド内で折り返し出力を行うため、文字列を分割します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param str 文字列
	 * @param chartSizeWidth 幅
	 * @param chartSizeHeight 高さ
	 * @param fontSize フォントサイズ
	 * @param fontZoom 拡大率
	 * @param fontIntervalWidth 間隔幅
	 * @param fontIntervalHeight 間隔高さ
	 * @param gridWidth グリッド幅
	 * @param gridHeight グリッド高さ
	 * @return 分割後の文字列の配列
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	String[] createMultiLineString(String str, int chartSizeWidth, int chartSizeHeight, int fontSize, int fontZoom, int fontIntervalWidth, int fontIntervalHeight, float gridWidth, float gridHeight) {

		// フィールドの実サイズ
		float fieldHeight = 0f;
		for (int i = 0; i < (int) chartSizeHeight; i++) {
			fieldHeight += gridHeight;
		}
		float fieldWidth = 0f;
		for (int i = 0; i < (int) chartSizeWidth; i++) {
			fieldWidth += gridWidth;
		}

		// フィールド内へ出力可能な最大行数
		int maxLineCount = fontSize == -1 ? (int) (chartSizeHeight / fontZoom) : (int) (fieldHeight / (fontIntervalHeight + fontSize));

		// 文字列の実幅を確認しながら複数行に振り分ける
		int tempLineCount = 1;
		float tempStrWidth = 0;
		float tempCharWidth = 0;
		StringBuilder tempStr = new StringBuilder();
		List<String> lines = new ArrayList<String>();
		boolean needLineFeed = false;

		for (int i = 0; i < str.length() && tempLineCount <= maxLineCount; i++) {
			needLineFeed = false;

			// 改行コード
			if (str.charAt(i) == '\r') {
				continue;
			}
			if (str.charAt(i) == '\n') {
				lines.add(tempStr.toString());
				tempLineCount++;
				tempStrWidth = 0f;
				tempStr = new StringBuilder();
				continue;
			}

			// 文字列の幅チェック
			if (fontSize == -1) {
				// 半角かどうかの判定(サロゲートペアの場合は半角文字のコードポイント対象外となり全角判定となる。)
				tempCharWidth = isHalfWidth(str.charAt(i)) ? gridWidth : gridWidth * 2;
				tempCharWidth *= fontZoom;
				tempStrWidth += tempCharWidth;
				if (tempStrWidth > fieldWidth) {
					needLineFeed = true;
				}
			} else {
				// 半角かどうかの判定(サロゲートペアの場合は半角文字のコードポイント対象外となり全角判定となる。)
				tempCharWidth = isHalfWidth(str.charAt(i)) ? fontSize / 2 : fontSize;
				tempStrWidth += tempCharWidth + (i == 0 ? 0 : fontIntervalWidth);
				if (tempStrWidth > fieldWidth) {
					needLineFeed = true;
				}
			}

			// 改行
			if (needLineFeed) {
				lines.add(tempStr.toString());
				tempLineCount++;
				tempStrWidth = 0f;
				tempStr = new StringBuilder();
				i--;
				continue;
			}

			tempStr.append(str.charAt(i));

			// サロゲート文字の場合はさらに１個先のchar値が下位サロゲートペアか判定し、
			// 下位サロゲートペアであれば残りのchar値を一時文字列に追加し、カウントをインクリメントする
			if (GStringUtils.isSurrogatePairChar(str.charAt(i))) {
				if (i + 1 < str.length()) {
					if (GStringUtils.isSurrogatePairChar(str.charAt(i + 1))) {
						tempStr.append(str.charAt(i + 1));
						i++;
					}
				}
			}
		}

		if (tempStr.length() > 0) {
			lines.add(tempStr.toString());
		}

		String[] result = new String[lines.size()];
		for (int i = 0; i < lines.size(); i++) {
			result[i] = (String) lines.get(i);
		}
		return result;
	}

	/**
	 * 【機能】指定した文字が半角であるか<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param character 対象文字
	 * @return 判定結果
	 * @create 2006/09/15
	 * @since 1.2.0
	 */
	boolean isHalfWidth(char character) {
		// 7Bit ASCII + \ + ~
		if (character < 0x80 || character == 0x00A5 || character == 0x203E) {
			return true;
		}

		if (character >= 0xff61 && character <= 0xff9f) {
			return true;
		}

		return false;
	}

	/**
	 * 【機能】抑止を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param data 文字列
	 * @return 文字列
	 * @throws GReportException ReportFramework例外
	 * @since 1.0.0
	 */
	protected String omit(String data) throws GReportException {

		GStdReport report = (GStdReport) getSection().getReport();

		String preValue = (String) report.getOmitValue(getName());
		if (report.hasOmitKey(getName()) && preValue.equals(data)) {
			return "";
		}

		report.setOmitValue(getName(), data);

		return data;
	}

	/**
	 * 印刷する値を取得します.
	 *
	 * @return 印刷する値
	 * @throws GReportException ReportFramework例外
	 * @create
	 * @author
	 * @since
	 */
	public String getPrintValue() throws GReportException {
		return formatValueForData(getSection().getVariableString(getName()));
	}

	/**
	 * デフォルトの日付フォーマットを取得します.
	 *
	 * @return propertiesファイルよりgeframe.report.Convert.Print.DefaultDateFormat
	 * @create 2014/12/25
	 * @author hashimoto
	 * @since 2.0.0
	 */
	private String getDefaultDateFormat() {
		return GFrameworkUtils.getProperty("geframe.report.Convert.Print.DefaultDateFormat");
	}

	/**
	 * 印刷する値を取得します.
	 *
	 * @param report レポート
	 * @param writer レポートライター
	 * @param printFlag 印刷フラグ printの場合true, printPlaceHolderの場合false
	 * @return data 印刷する値
	 * @throws GReportException ReportFramework例外
	 * @create 2015/03/24
	 * @author KCSS LiuXunAn
	 * @since 2.0.0
	 */
	private String getData(GStdReport report, IReportWriter writer, boolean printFlag) throws GReportException {

		String data = null;
		final String type = getType();

		getSection().calcAbsolutePosition();

		if (IFieldInfo.TYPE_MAX_PAGE.equals(type)) {
			writer.setTemplateMaxPage(getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), getFontZoom(), getAlignment(), getWidth(), getHeight(), getFontFace(), getFormat(), getFontSize(), getFontInterval(), getFontHeight());
			return data;
		}

		if (IFieldInfo.TYPE_PLAIN_TEXT.equals(type) || IFieldInfo.TYPE_LABEL.equals(type) || IFieldInfo.TYPE_RESOURCE.equals(type)) {

			if (printFlag && getPlaceHolder() != null) {
				writer.setTemplateField(getPlaceHolder(), getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), getFontZoom(), getAlignment(), getWidth(), getHeight());
				return data;
			}
			data = formatValueForData(getValue());

		} else if (IFieldInfo.TYPE_SYS_DATE.equals(type)) {

			data = formatValueForDate(report.getPrintDate());

		} else if (IFieldInfo.TYPE_PAGE.equals(type)) {

			data = formatValueForNumber(String.valueOf(report.getPageCount()));

		} else if (IFieldInfo.TYPE_DATA.equals(type)) {

			data = getSection().getVariableString(getName());
			data = formatValueForData(data);
			data = optimazeValueForOmit(data);

		} else {
			data = getValue();
		}

		if (data == null) {
			data = "";
		}

		return data;
	}
}
