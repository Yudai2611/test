/*
 * Copyright 2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReport;
import jp.co.kccs.greenearth.report.IReportImage;
import jp.co.kccs.greenearth.report.IReportSection;
import jp.co.kccs.greenearth.report.IReportWriter;
import jp.co.kccs.greenearth.report.ISectionElementGroup;
import jp.co.kccs.greenearth.report.repository.IImageInfo;
import jp.co.kccs.greenearth.report.repository.stdimpl.GStdImageInfo;

/**
 * 【役割】イメージを表します。<BR>
 * 【生成】リクエストごとにセクションにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 *
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdReportImage extends GStdImageInfo implements IReportImage {

	/** セクション */
	private GStdReportSection _section = null;
	/** 静的情報 */
	private IImageInfo _static_info = null;

	/**
	 * @see jp.co.kccs.greenearth.report.IReportImage#load(jp.co.kccs.greenearth.report.repository.IImageInfo, jp.co.kccs.greenearth.report.IReportSection)
	 * @param info
	 * @param section
	 */
	@Override
	public void load(IImageInfo info, IReportSection section) {
		createActiveInfo(info, section);
	}

	/**
	 * 【機能】動的情報を生成します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 *
	 * @param info イメージ情報
	 * @param section セクション
	 */
	protected void createActiveInfo(IImageInfo info, IReportSection section) {
		_section = (GStdReportSection) section;
		_static_info = info;

		initialize();
	}

	/**
	 * セクション情報を取得します.
	 *
	 * @return セクション
	 */
	GStdReportSection getSection() {
		if (_section == null) {
			throw new GReportRuntimeException("section is not set.");
		}
		return _section;
	}

	/**
	 * 【機能】イメージ情報を初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】XML情報に初期化されます。<BR>
	 *
	 * @create 2004/07/01
	 * @since 1.0.2
	 */
	public void initialize() {

		if (_static_info == null) {
			throw new GReportRuntimeException("ImageInfo is Null.");
		}

		super.setName(_static_info.getName());
		super.setValue(_static_info.getValue());
		super.setType(_static_info.getType());
		super.setTop(_static_info.getTop());
		super.setLeft(_static_info.getLeft());
		super.setWidth(_static_info.getWidth());
		super.setHeight(_static_info.getHeight());
		super.setBarcodeType(_static_info.getBarcodeType());
		super.setOutput(_static_info.getOutput());
		super.setBarcodeInfo(_static_info.getBarcodeInfo());
	}

	/**
	 * 【機能】値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * @see jp.co.kccs.greenearth.report.IReportImage#setValue(java.lang.Object)
	 * @param value 値
	 * @since 1.0.0
	 */
	@Override
	public void setValue(Object value) {

		ISectionElementGroup group = getSection().getImageGroup(getName());
		if (group != null) {
			// グループすべてを書き換えます
			for (int i = 0; i < group.size(); i++) {
				GStdReportImage img = (GStdReportImage) group.get(i);
				img.setValueInfo(value);
			}
		} else {
			setValueInfo(value);
		}
	}

	/**
	 * 【機能】フィールド変数の値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param value 値
	 * @since 1.0.0
	 */
	protected void setValueInfo(Object value) {
		super.setValue(value.toString());
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdImageInfo#setHeight(int)
	 * @param height
	 */
	@Override
	public void setHeight(int height) {

		ISectionElementGroup group = getSection().getImageGroup(getName());
		if (group != null) {
			// グループすべてを書き換えます
			for (int i = 0; i < group.size(); i++) {
				GStdReportImage img = (GStdReportImage) group.get(i);
				img.setHeightInfo(height);
			}
		} else {
			setHeightInfo(height);
		}
	}

	/**
	 * @param height
	 */
	protected void setHeightInfo(int height) {
		super.setHeight(height);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdImageInfo#setLeft(int)
	 * @param left
	 */
	@Override
	public void setLeft(int left) {

		ISectionElementGroup group = getSection().getImageGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportImage img = (GStdReportImage) group.get(i);
				img.setLeftInfo(left);
			}
		} else {
			setLeftInfo(left);
		}
	}

	/**
	 * @param left
	 */
	protected void setLeftInfo(int left) {
		super.setLeft(left);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdImageInfo#setTop(int)
	 * @param top
	 */
	@Override
	public void setTop(int top) {

		ISectionElementGroup group = getSection().getImageGroup(getName());
		if (group != null) {
			// グループすべてを書き換えます
			for (int i = 0; i < group.size(); i++) {
				GStdReportImage img = (GStdReportImage) group.get(i);
				img.setTopInfo(top);
			}
		} else {
			setTopInfo(top);
		}
	}

	/**
	 * @param top
	 */
	protected void setTopInfo(int top) {
		super.setTop(top);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdImageInfo#setWidth(int)
	 * @param width
	 */
	@Override
	public void setWidth(int width) {

		ISectionElementGroup group = getSection().getImageGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportImage img = (GStdReportImage) group.get(i);
				img.setWidthInfo(width);
			}
		} else {
			setWidthInfo(width);
		}
	}

	/**
	 * @param width
	 */
	protected void setWidthInfo(int width) {
		super.setWidth(width);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdImageInfo#setOutput(boolean)
	 * @param output
	 */
	@Override
	public void setOutput(boolean output) {

		ISectionElementGroup group = getSection().getImageGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportImage img = (GStdReportImage) group.get(i);
				img.setOutputInfo(output);
			}
		} else {
			setOutputInfo(output);
		}
	}

	/**
	 * 【機能】フィールド変数の表示値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param output 真偽値
	 * @since 1.0.0
	 */
	protected void setOutputInfo(boolean output) {
		super.setOutput(output);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.IReportImage#print()
	 * @throws GReportException
	 */
	@Override
	public void print() throws GReportException {

		if (!getOutput()) {
			return;
		}

		getSection().calcAbsolutePosition();
		IReport report = getSection().getReport();

		writeImage(report.getWriter(), getValue());
	}

	/**
	 * 【機能】画像を印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param writer レポートライター
	 * @param data 文字列
	 * @throws GReportException
	 * @since 1.0
	 */
	protected void writeImage(IReportWriter writer, String data) throws GReportException {

		if (getType().equals(IImageInfo.TYPE_BARCODE)) {
			writer.writeBarcode(getBarcodeType(), getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), getWidth(), getHeight(), data, getBarcodeInfo());
			return;
		}

		String filePath = appendDirPath(getValue());
		writer.writeImage(getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), getWidth(), getHeight(), filePath);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.IReportImage#printPlaceHolder()
	 * @throws GReportException
	 */
	@Override
	public void printPlaceHolder() throws GReportException {

		if (!getOutput()) {
			return;
		}

		IReportWriter writer = getSection().getReport().getWriter();

		if (getType().equals(IImageInfo.TYPE_BARCODE)) {
			String data = getValue();
			writer.writeTemplateBarcode(getSection().getName(), getBarcodeType(), getLeft(), getTop(), getWidth(), getHeight(), data, getBarcodeInfo());
			return;
		}

		String filePath = appendDirPath(getValue());
		writer.writeTemplateImage(getSection().getName(), getLeft(), getTop(), getWidth(), getHeight(), filePath);
	}

	/**
	 * 画像ファイルが格納されているディレクトリのパスを取得しファイルの絶対パスを生成します.
	 *
	 * @param fileName ファイル名
	 * @return ファイルの絶対パス
	 * @create 2015/03/19
	 * @author KCCS hashimoto
	 * @since 2.0.0
	 */
	private String appendDirPath(String fileName) {

		if (!jp.co.kccs.greenearth.report.utility.GReportFileUtility.isAbsolute(fileName)) {
			final GStdReport report = (GStdReport) getSection().getReport();
			String imageDir = report.getImageDirectory();
			return imageDir + fileName;
		}
		return fileName;
	}
}
