/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.awt.Color;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReport;
import jp.co.kccs.greenearth.report.IReportLine;
import jp.co.kccs.greenearth.report.IReportSection;
import jp.co.kccs.greenearth.report.ISectionElementGroup;
import jp.co.kccs.greenearth.report.repository.ILineInfo;
import jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo;

/**
 * 【役割】ラインを表します。<BR>
 * 【生成】リクエストごとにセクションにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0
 */
public class GStdReportLine extends GStdLineInfo implements IReportLine {

	/** セクション */
	private GStdReportSection _section = null;
	/** 静的情報 */
	private ILineInfo _static_info = null;

	/**
	 * @see jp.co.kccs.greenearth.report.IReportLine#load(jp.co.kccs.greenearth.report.repository.ILineInfo, jp.co.kccs.greenearth.report.IReportSection)
	 * @param info ライン情報
	 * @param section セクション
	 */
	@Override
	public void load(ILineInfo info, IReportSection section) {
		createActiveInfo(info, section);
	}

	/**
	 * 【機能】動的情報を生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param info ライン情報
	 * @param section セクション
	 */
	protected void createActiveInfo(ILineInfo info, IReportSection section) {
		_section = (GStdReportSection) section;
		_static_info = info;
		initialize();
	}


	/**
	 * ライン情報を取得します.
	 * 
	 * @return ライン情報
	 * @create
	 * @author
	 * @since 
	 */
	ILineInfo getLineInfo() {
		return _static_info;
	}
	

	/**
	 * セクション情報を取得します.
	 * 
	 * @return セクション
	 * @create
	 * @author
	 * @since 
	 */
	GStdReportSection getSection() {
		if (_section == null) {
			throw new GReportRuntimeException("section is not set.");
		}
		return _section;
	}
	
	/**
	 * 【機能】ライン情報を初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】XML情報に初期化します。<BR>
	 * 
	 * @create 2004/07/01
	 * @since 1.0.2
	 */
	public void initialize() {
		super.setName(getLineInfo().getName());
		super.setType(getLineInfo().getType());
		super.setTop(getLineInfo().getTop());
		super.setLeft(getLineInfo().getLeft());
		super.setWidth(getLineInfo().getWidth());
		super.setHeight(getLineInfo().getHeight());
		super.setLineWidth(getLineInfo().getLineWidth());
		super.setOutput(getLineInfo().getOutput());
		super.setDashInfo(getLineInfo().getDashInfo());
		super.setDouble(getLineInfo().getDouble());
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setHeight(int)
	 * @param height 高さ
	 */
	@Override
	public void setHeight(int height) {
		if (_section == null) {
			setHeightInfo(height);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setHeightInfo(height);
			}
		} else {
			setHeightInfo(height);
		}
	}

	/**
	 * 高さを設定します。
	 * 
	 * @param height 高さ
	 */
	protected void setHeightInfo(int height) {
		super.setHeight(height);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setLeft(int)
	 * @param left 左端
	 */
	@Override
	public void setLeft(int left) {
		if (_section == null) {
			setLeftInfo(left);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setLeftInfo(left);
			}
		} else {
			setLeftInfo(left);
		}
	}

	/**
	 * 左端を設定します。
	 * 
	 * @param left 左端
	 */
	protected void setLeftInfo(int left) {
		super.setLeft(left);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setTop(int)
	 * @param top 上端
	 */
	@Override
	public void setTop(int top) {
		if (_section == null) {
			setTopInfo(top);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setTopInfo(top);
			}
		} else {
			setTopInfo(top);
		}
	}

	/**
	 * 上端を設定します。
	 * 
	 * @param top 上端
	 */
	protected void setTopInfo(int top) {
		super.setTop(top);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setWidth(int)
	 * @param width 幅
	 */
	@Override
	public void setWidth(int width) {
		if (_section == null) {
			setWidthInfo(width);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setWidthInfo(width);
			}
		} else {
			setWidthInfo(width);
		}
	}

	/**
	 * 幅を設定します。
	 * 
	 * @param width 幅
	 */
	protected void setWidthInfo(int width) {
		super.setWidth(width);
	}

	/**
	 * 【機能】カラーを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param color カラー
	 * @create 2004/06/01
	 * @since 1.0.1
	 */
	protected void setColorInfo(Color color) {
		super.setColor(color);
	}

	/**
	 * 【機能】点線情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param units_on オンの間隔
	 * @param phase フェーズ値
	 * @create 2004/07/05
	 * @since 1.0.2
	 */
	protected void setDashInfo(int units_on, int phase) {
		super.setDash(units_on);
		super.setGap(phase);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.IReportLine#setDash(int, int)
	 * @param units_on オンの間隔
	 * @param phase フェーズ値
	 */
	@Override
	public void setDash(int units_on, int phase) {
		if (_section == null) {
			setDashInfo(units_on, phase);
			setType(ILineInfo.TYPE_CUSTOM_DASH);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setDashInfo(units_on, phase);
				line.setType(ILineInfo.TYPE_CUSTOM_DASH);
			}
		} else {
			setDashInfo(units_on, phase);
		}
	}

	/**
	 * 【機能】カラーを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setColor(java.awt.Color)
	 * @param color カラー
	 * @create 2004/06/01
	 * @since 1.0.1
	 */
	@Override
	public void setColor(Color color) {
		if (_section == null) {
			setColorInfo(color);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setColorInfo(color);
			}
		} else {
			setColorInfo(color);
		}
	}

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setOutput(boolean)
	 * @param output 表示/非表示
	 * @since 1.0.0
	 */
	@Override
	public void setOutput(boolean output) {
		if (_section == null) {
			setOutputInfo(output);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setOutputInfo(output);
			}
		} else {
			setOutputInfo(output);
		}
	}

	/**
	 * 【機能】ラインタイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setType(int)
	 * @param type ラインタイプ
	 * @since 1.0.0
	 */
	@Override
	public void setType(int type) {
		if (_section == null) {
			setTypeInfo(type);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setTypeInfo(type);
			}
		} else {
			setTypeInfo(type);
		}
	}

	/**
	 * 【機能】タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type タイプ
	 * @since 1.0.0
	 */
	protected void setTypeInfo(int type) {
		super.setType(type);
	}

	/**
	 * 【機能】フィールド変数の表示値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param output 表示/非表示
	 * @since 1.0.0
	 */
	protected void setOutputInfo(boolean output) {
		super.setOutput(output);
	}

	/**
	 * 【機能】ライン幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdLineInfo#setLineWidth(double)
	 * @param line_width ライン幅
	 * @since 1.0.0
	 */
	@Override
	public void setLineWidth(double line_width) {
		if (_section == null) {
			setLineWidthInfo(line_width);
			return;
		}

		ISectionElementGroup group = getSection().getLineGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportLine line = (GStdReportLine) group.get(i);
				line.setLineWidthInfo(line_width);
			}
		} else {
			setLineWidthInfo(line_width);
		}
	}

	/**
	 * 【機能】フィールド変数のライン幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param line_width ライン幅
	 * @since 1.0.0
	 */
	protected void setLineWidthInfo(double line_width) {
		super.setLineWidth(line_width);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.IReportLine#print()
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void print() throws GReportException {

		if (!getOutput()) {
			return;
		}

		getSection().calcAbsolutePosition();

		IReport report = getSection().getReport();
		report.getWriter().writeLine(getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), getWidth(), getHeight(), getLineWidth(), getType(), getColor(), getDashInfo(), getDouble());
	}

	/**
	 * @see jp.co.kccs.greenearth.report.IReportLine#printPlaceHolder()
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void printPlaceHolder() throws GReportException {

		if (!getOutput()) {
			return;
		}
		
		IReport report = getSection().getReport();
		report.getWriter().writeTemplateLine(getSection().getName(), getLeft(), getTop(), getWidth(), getHeight(), getLineWidth(), getType(), getColor());
	}
}