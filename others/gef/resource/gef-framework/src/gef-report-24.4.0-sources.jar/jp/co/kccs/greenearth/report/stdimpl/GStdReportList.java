/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.util.Iterator;
import java.util.List;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.IReportList;
import jp.co.kccs.greenearth.report.IReportRecord;

/**
 * レポートリストを表します.<br/>
 * 
 * @create 2014/11/20
 * @author yamashita
 * @since 2.0.0
 */
public class GStdReportList implements IReportList {

	/** レポートリスト */
	private List<IReportRecord> _list;
	/** 現在のレコード */
	private IReportRecord _current;
	/** レポートリストのカーソル */
	private Iterator<IReportRecord> _iterator;

	/**
	 * レポートリストを生成します.<br/>
	 * 
	 * @param list レポートリスト
	 * @create 2014/11/20
	 * @author yamashita
	 * @since 2.0.0
	 */
	public GStdReportList(List<IReportRecord> list) {
		_list = list;
		_iterator = list.iterator();
	}

	/**
	 * リストの行数を取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportList#size()
	 * @return リストの行数
	 * @create 2014/11/20
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public int size() {
		return _list.size();
	}

	/**
	 * カーソルを先頭に戻します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportList#resetCursor()
	 * @create 2014/11/20
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public void resetCursor() {
		_current = null;
		_iterator = _list.iterator();
	}

	/**
	 * 現在のレコードを取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportList#get()
	 * @return カレントレコード
	 * @throws GReportException ReportFramework例外
	 * @create 2014/11/20
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public IReportRecord get() throws GReportException {
		return _current;
	}

	/**
	 * 次のレコードにカーソルを移動します.<br/>
	 * カーソルが最終行に到達している場合、<code>false</code>を返却します。<br/>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportList#next()
	 * @return レコードが存在するかどうか
	 * @throws GReportException ReportFramework例外
	 * @create 2014/11/20
	 * @author yamashita
	 * @since 2.0.0
	 */
	@Override
	public boolean next() throws GReportException {
		boolean hasNext = _iterator.hasNext();
		if (hasNext) {
			_current = _iterator.next();
		}
		return hasNext;
	}
}