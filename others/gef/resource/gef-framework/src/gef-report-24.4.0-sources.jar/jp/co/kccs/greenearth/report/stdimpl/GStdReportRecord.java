/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReportRecord;

/**
 * 
 ******************************************************************************** <BR>
 * 【役割】レコードを表します。<BR>
 * 【生成】レポートクラスにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 ******************************************************************************** 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */
public class GStdReportRecord implements IReportRecord {

	/** マップ  */
	private Map<String, Object> _columns = null;

	/**
	 * コンストラクター
	 */
	public GStdReportRecord() {
	}

	/**
	 * 
	 ******************************************************************************** 
	 【役割】レポートレコードを生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 ******************************************************************************** 
	 * @param columns マップ
	 * @create 2004/03/25
	 * @since 1.0.3
	 */
	public GStdReportRecord(Map<String, Object> columns) {
		setColumns(columns);
	}

	/**
	 * マップオブジェクトを設定します。<BR>
	 * 
	 * @param columns マップ
	 */
	void setColumns(Map<String, Object> columns) {
		_columns = columns;
	}
	
	/**
	 * 
	 ******************************************************************************** <BR>
	 * 【機能】クローンレコードを生成します。<BR>
	 * 【戻値】レポートレコード<BR>
	 * 【引数】<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 ******************************************************************************** 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getClone()
	 * @return クローンオブジェクト
	 * @create 2004/04/15
	 * @since 1.0.0
	 */
	@Override
	public IReportRecord getClone() {
		try {
			return (IReportRecord) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new GReportRuntimeException(e);
		}
	}

	/**
	 * 
	 ******************************************************************************** <BR>
	 * 【機能】項目名の値文字列を取得します。<BR>
	 * 【戻値】値文字列<BR>
	 * 【引数】カラム名<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 ******************************************************************************** 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getVariableString(java.lang.String)
	 * @param column_name カラム名
	 * @return 値文字列
	 */
	@Override
	public String getVariableString(String column_name) {
		Object ret = getVariable(column_name);
		if (ret == null) {
			return null;
		}
		return ret.toString();
	}

	/**
	 * 
	 ******************************************************************************** <BR>
	 * 【機能】項目名の値を取得します。<BR>
	 * 【戻値】値<BR>
	 * 【引数】カラム名<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 ******************************************************************************** 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getVariable(java.lang.String)
	 * @param column_name カラム名
	 * @return 値
	 */
	@Override
	public Object getVariable(String column_name) {
		if (column_name == null) {
			return null;
		}
		return getMap().get(column_name.toUpperCase());
	}

	/**
	 * 
	 ******************************************************************************** <BR>
	 * 【機能】項目名指定で値を設定します。<BR>
	 * 【戻値】<BR>
	 * 【引数】カラム名、値<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 ******************************************************************************** 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#setVariable(java.lang.String, java.lang.Object)
	 * @param column_name カラム名
	 * @param value 値
	 */
	@Override
	public void setVariable(String column_name, Object value) {
		if (column_name == null) {
			return;
		}
		getMap().put(column_name.toUpperCase(), value);
	}

	/**
	 * 
	 ******************************************************************************** <BR>
	 * 【機能】マップを取得します。<BR>
	 * 【戻値】java.util.Map<BR>
	 * 【引数】<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 ******************************************************************************** 
	 * @return マップオブジェクト
	 * @since 1.0.0
	 */
	Map<String, Object> getMap() {
		if (_columns == null) {
			_columns = new HashMap<String, Object>();
		}
		return _columns;
	}
}
