/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.IReport;
import jp.co.kccs.greenearth.report.IReportRectangle;
import jp.co.kccs.greenearth.report.IReportSection;
import jp.co.kccs.greenearth.report.ISectionElementGroup;
import jp.co.kccs.greenearth.report.repository.IRectangleInfo;
import jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo;

/**
 * 【役割】レクタングルを表します。<BR>
 * 【生成】リクエストごとにセクションにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0
 */
public class GStdReportRectangle extends GStdRectangleInfo implements IReportRectangle {

	/** セクション */
	private GStdReportSection _section = null;
	/** 静的情報 */
	private IRectangleInfo _static_info = null;

	/**
	 * @see jp.co.kccs.greenearth.report.IReportRectangle#load(jp.co.kccs.greenearth.report.repository.IRectangleInfo, jp.co.kccs.greenearth.report.IReportSection)
	 * @param info レクタングル情報
	 * @param section セクション
	 */
	@Override
	public void load(IRectangleInfo info, IReportSection section) {
		createActiveInfo(info, section);
	}

	/**
	 * 【機能】動的情報を生成します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @param info レクタングル情報
	 * @param section セクション
	 */
	protected void createActiveInfo(IRectangleInfo info, IReportSection section) {
		_section = (GStdReportSection) section;
		_static_info = info;
		initialize();
	}


	/**
	 * 四角情報を取得します.
	 * 
	 * @return 四角情報
	 * @create
	 * @author
	 * @since 
	 */
	IRectangleInfo getRectangleInfo() {
		return _static_info;
	}
	
	/**
	 * セクション情報を取得します.
	 * 
	 * @return セクション
	 * @create
	 * @author
	 * @since 
	 */
	GStdReportSection getSection() {
		if (_section == null) {
			throw new GReportRuntimeException("section is not set.");
		}
		return _section;
	}
	
	/**
	 * 【機能】レクタングル情報を初期化します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】XML情報に初期化します。<BR>
	 * 
	 * @create 2004/07/01
	 * @since 1.0.2
	 */
	public void initialize() {
		super.setName(getRectangleInfo().getName());
		super.setType(getRectangleInfo().getType());
		super.setTop(getRectangleInfo().getTop());
		super.setLeft(getRectangleInfo().getLeft());
		super.setWidth(getRectangleInfo().getWidth());
		super.setHeight(getRectangleInfo().getHeight());
		super.setLineWidth(getRectangleInfo().getLineWidth());
		super.setOutput(getRectangleInfo().getOutput());
		super.setRadius(getRectangleInfo().getRadius());
		super.setDashInfo(getRectangleInfo().getDashInfo());
	}

	/**
	 * 【機能】表示/非表示を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo#setOutput(boolean)
	 * @param output 表示/非表示
	 * @since 1.0.0
	 */
	public void setOutput(boolean output) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setOutputInfo(output);
			}
		} else {
			setOutputInfo(output);
		}
	}

	/**
	 * 【機能】タイプを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo#setType(int)
	 * @param type タイプ
	 * @since 1.0.0
	 */
	public void setType(int type) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setTypeInfo(type);
			}
		} else {
			setTypeInfo(type);
		}
	}

	/**
	 * 【機能】フィールド変数の表示値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param output 表示/非表示
	 * @since 1.0.0
	 */
	protected void setOutputInfo(boolean output) {
		super.setOutput(output);
	}

	/**
	 * 【機能】タイプを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param type タイプ
	 * @since 1.0.0
	 */
	protected void setTypeInfo(int type) {
		super.setType(type);
	}

	/**
	 * 【機能】角丸長方形の角の半径を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】デフォルトは0です。<BR>
	 * 
	 * @return 角丸長方形の角の半径
	 * @since 1.0.0
	 */
	public int getCornerRadius() {
		return getRadius();
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo#setHeight(int)
	 * @param height 高さ
	 */
	public void setHeight(int height) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setHeightInfo(height);
			}
		} else {
			setHeightInfo(height);
		}
	}

	/**
	 * 高さを設定します。
	 * 
	 * @param height 高さを
	 */
	protected void setHeightInfo(int height) {
		super.setHeight(height);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo#setLeft(int)
	 * @param left 左端
	 */
	public void setLeft(int left) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setLeftInfo(left);
			}
		} else {
			setLeftInfo(left);
		}
	}

	/**
	 * 左端を設定します。
	 * 
	 * @param left 左端
	 */
	protected void setLeftInfo(int left) {
		super.setLeft(left);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo#setTop(int)
	 * @param top 上端
	 */
	public void setTop(int top) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setTopInfo(top);
			}
		} else {
			setTopInfo(top);
		}
	}

	/**
	 * 上端を設定します。
	 * 
	 * @param top 上端
	 */
	protected void setTopInfo(int top) {
		super.setTop(top);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo#setWidth(int)
	 * @param width 幅
	 */
	public void setWidth(int width) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setWidthInfo(width);
			}
		} else {
			setWidthInfo(width);
		}
	}

	/**
	 * 幅を設定します。
	 * 
	 * @param width 幅
	 */
	protected void setWidthInfo(int width) {
		super.setWidth(width);
	}

	/**
	 * 【機能】長方形を角丸長方形に設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】角丸長方形の角の半径値はグリッド単位でなく、ピクセル単位であることに注意して下さい。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRectangle#setCornerRound(int)
	 * @param radius 角丸長方形の角の半径
	 * @since 1.0.0
	 */
	public void setCornerRound(int radius) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setCornerRoundInfo(radius);
			}
		} else {
			setCornerRoundInfo(radius);
		}
	}

	/**
	 * 【機能】線幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdRectangleInfo#setLineWidth(double)
	 * @param line_width 線幅
	 * @since 1.0
	 */
	public void setLineWidth(double line_width) {
		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setLineWidthInfo(line_width);
			}
		} else {
			setLineWidthInfo(line_width);
		}
	}

	/**
	 * 【機能】長方形を角丸長方形に設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】角丸長方形の角の半径値はグリッド単位でなく、ピクセル単位であることに注意して下さい。<BR>
	 * 一度設定するとレポート出力終了まで保持されます。<BR>
	 * 
	 * @param radius 角丸長方形の角の半径
	 * @since 1.0.0
	 */
	protected void setCornerRoundInfo(int radius) {
		setRadius(radius);
	}

	/**
	 * 【機能】点線情報を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param units_on オンの間隔
	 * @param phase フェーズ値
	 * @create 2004/07/05
	 * @since 1.0.2
	 */
	protected void setDashInfo(int units_on, int phase) {
		super.setDash(units_on);
		super.setGap(phase);
	}

	/**
	 * 【機能】点線を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param units_on オンの間隔
	 * @param phase フェーズ値
	 * @create 2004/07/05
	 * @since 1.0.2
	 */
	public void setDash(int units_on, int phase) {
		if (_section == null) {
			setDashInfo(units_on, phase);
			setType(IRectangleInfo.TYPE_CUSTOM_DASH);
			return;
		}

		ISectionElementGroup group = getSection().getRectangleGroup(getName());
		if (group != null) {
			for (int i = 0; i < group.size(); i++) {
				GStdReportRectangle rec = (GStdReportRectangle) group.get(i);
				rec.setDashInfo(units_on, phase);
				rec.setType(IRectangleInfo.TYPE_CUSTOM_DASH);
			}
		} else {
			setDashInfo(units_on, phase);
		}
	}

	/**
	 * 【機能】フィールド変数の線幅を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param line_width 線幅
	 * @since 1.0.0
	 */
	protected void setLineWidthInfo(double line_width) {
		super.setLineWidth(line_width);
	}

	/**
	 * @see jp.co.kccs.greenearth.report.IReportRectangle#print()
	 * @throws GReportException ReportFramework例外
	 */
	@Override
	public void print() throws GReportException {

		if (!getOutput()) {
			return;
		}

		getSection().calcAbsolutePosition();

		IReport report = getSection().getReport();
		report.getWriter().writeRectangle(getSection().getAbsoluteLeft() + getLeft(), getSection().getAbsoluteTop() + getTop(), getWidth(), getHeight(), getLineWidth(), getType(), getCornerRadius(), getDashInfo());
	}

	/**
	 * @param row_no 行番号
	 * @throws GReportException ReportFramework例外
	 */
	public void printTemplate(int row_no) throws GReportException {

		if (!getOutput()) {
			return;
		}
		
		IReport report = getSection().getReport();
		report.getWriter().writeTemplateRectangle(getSection().getName(), getLeft(), getTop(), getWidth(), getHeight(), getLineWidth(), getType(), getCornerRadius());
	}
}