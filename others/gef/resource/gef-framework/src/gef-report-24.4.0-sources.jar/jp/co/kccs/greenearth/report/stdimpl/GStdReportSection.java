/*
 * Copyright 2014-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.stdimpl;

import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.MissingResourceException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.IPlaceHolder;
import jp.co.kccs.greenearth.report.IReport;
import jp.co.kccs.greenearth.report.IReportCircle;
import jp.co.kccs.greenearth.report.IReportField;
import jp.co.kccs.greenearth.report.IReportImage;
import jp.co.kccs.greenearth.report.IReportLine;
import jp.co.kccs.greenearth.report.IReportRectangle;
import jp.co.kccs.greenearth.report.IReportSection;
import jp.co.kccs.greenearth.report.IReportWriter;
import jp.co.kccs.greenearth.report.ISectionElementGroup;
import jp.co.kccs.greenearth.report.repository.ICircleInfo;
import jp.co.kccs.greenearth.report.repository.IFieldInfo;
import jp.co.kccs.greenearth.report.repository.IImageInfo;
import jp.co.kccs.greenearth.report.repository.ILineInfo;
import jp.co.kccs.greenearth.report.repository.IRectangleInfo;
import jp.co.kccs.greenearth.report.repository.IReportInfo;
import jp.co.kccs.greenearth.report.repository.ISectionInfo;
import jp.co.kccs.greenearth.report.repository.stdimpl.GStdSectionInfo;
import jp.co.kccs.greenearth.report.utility.GColor;

/**
 * 【役割】セクションを表します。<BR>
 * 【生成】リクエストごとにレポートクラスにより生成されます。<BR>
 * 【解放】レポート印刷後、解放されます。<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/25
 * @author kusakari
 * @since 1.0.0
 */

public class GStdReportSection extends GStdSectionInfo implements IReportSection {

	/** レポートインスタンス */
	private IReport _report = null;
	/** セッションプレースホルダ */
	private IPlaceHolder _place_holder = null;
	/** 空印刷フラグ */
	private boolean _is_empty = false;

	/** 絶対位置の上 */
	private int _absolute_top = 0;
	/** 絶対位置の左 */
	private int _absolute_left = 0;

	/** 静的なセクション情報 */
	private ISectionInfo _static_info = null;

	/** フィールドグループ */
	private Map<String, ISectionElementGroup> _field_group_map = new HashMap<String, ISectionElementGroup>();
	/** レクタングルグループ */
	private Map<String, ISectionElementGroup> _rec_group_map = new HashMap<String, ISectionElementGroup>();
	/** サークルグループ */
	private Map<String, ISectionElementGroup> _circle_group_map = new HashMap<String, ISectionElementGroup>();
	/** ライングループ */
	private Map<String, ISectionElementGroup> _line_group_map = new HashMap<String, ISectionElementGroup>();
	/** イメージグループ */
	private Map<String, ISectionElementGroup> _image_group_map = new HashMap<String, ISectionElementGroup>();

	/** 座標縦 */
	private int _mutable_top = -1;
	/** 座標横 */
	private int _mutable_left = -1;
	
	/**
	 * 【機能】テンポラリマップに登録されていればグループに追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param temp_map テンポラリマップ
	 * @param group_map グループマップ
	 * @param key キー
	 * @create 2004/07/01
	 * @since 1.0.2
	 */
	protected void addGroup(Map<String, Object> temp_map, Map<String, ISectionElementGroup> group_map, String key) {
		if (temp_map.containsKey(key)) {
			ISectionElementGroup group = (ISectionElementGroup) group_map.get(key);
			if (group == null) {
				group = createSectionElementGroup(key);
				group_map.put(key, group);
			}
			group.add(temp_map.get(key));
		}
	}

	/**
	 * {@link ISectionElementGroup}のインスタンスを生成します.<br>
	 * 
	 * @param name エレメントグループ名
	 * @return エレメントグループ
	 * @create 
	 * @author  
	 * @since 
	 */
	protected ISectionElementGroup createSectionElementGroup(String name) {
		ISectionElementGroup group = GFrameworkUtils.getComponent(ISectionElementGroup.class.getName());
		group.setName(name);
		return group;
	}

	/**
	 * 帳票のラインカウント（現在作業中の行数)を移動させます。<BR>
	 * 印刷方向、ベースポジション属性をみて適切にラインを移動させます。<br>
	 * 
	 * @create 2006/04/09
	 * @author kitamura
	 * @since 1.1.0
	 */
	protected void moveLineCount() {
		GStdReport report = (GStdReport) getReport();

		String isEmulate = null;
		try {
			isEmulate = GFrameworkUtils.getProperty("geframe.report.Emulate_V10");
		} catch (MissingResourceException mre) {
			isEmulate = "false";
		}

		if (getBasePosition() == BASE_POSITION_NEXTLINE || GBooleanUtils.toBoolean(isEmulate, false)) {
			if (report.getPrintDirection() == IReportInfo.PRINT_DIRECTION_VIRTICAL) {
				report.addLineCount(getHeight());
				return;
			}
			if (report.getPrintDirection() == IReportInfo.PRINT_DIRECTION_HORIZONTAL) {
				report.addLineCount(getWidth());
				return;
			} 
			throw new IllegalArgumentException("Illegal print direction type. : " + report.getPrintDirection());
		} 
		
		if (getBasePosition() == BASE_POSITION_ABSOLUTE) {
			if (report.getPrintDirection() == IReportInfo.PRINT_DIRECTION_VIRTICAL) {
				report.setLineCount(getTop() + getHeight());
				return;
			} 
			if (report.getPrintDirection() == IReportInfo.PRINT_DIRECTION_HORIZONTAL) {
				report.setLineCount(getLeft() + getWidth());
				return;
			}
			throw new IllegalArgumentException("Illegal print direction type. : " + report.getPrintDirection());
		} 

		throw new IllegalArgumentException("Illegal base position type. : " + getBasePosition());
	}

	/**
	 * 【機能】レポートを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#getReport()
	 * @return レポート
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	@Override
	public IReport getReport() {
		return _report;
	}

	/**
	 * 【機能】フィールドを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#getField(java.lang.String)
	 * @param field_name フィールド名
	 * @return フィールド
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	@Override
	public IReportField getField(String field_name) throws GReportException {

		for (Object fieldObj : getFieldList()) {
			IReportField field = (IReportField) fieldObj;
			if (field.getName().equals(field_name)) {
				return field;
			}
		}

		return null;
	}

	/**
	 * 【機能】グループを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】存在しなければ null が返ります。<BR>
	 * 
	 * @param name 名称
	 * @return グループ
	 * @create 2004/07/01
	 * @author  
	 * @since 1.0.2
	 */
	public ISectionElementGroup getFieldGroup(String name) {
		return _field_group_map.get(name);
	}

	/**
	 * 【機能】グループを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】存在しなければ null が返ります。<BR>
	 * 
	 * @param name 名称
	 * @return グループ
	 * @create 2004/07/01
	 * @author  
	 * @since 1.0.2
	 */
	public ISectionElementGroup getImageGroup(String name) {
		return _image_group_map.get(name);
	}

	/**
	 * 【機能】グループを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】存在しなければ null が返ります。<BR>
	 * 
	 * @param name 名称
	 * @return グループ
	 * @create 2004/07/01
	 * @author  
	 * @since 1.0.2
	 */
	public ISectionElementGroup getRectangleGroup(String name) {
		return _rec_group_map.get(name);
	}

	/**
	 * 【機能】グループを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】存在しなければ null が返ります。<BR>
	 * 
	 * @param name 名称
	 * @return グループ
	 * @create 2004/07/01
	 * @author  
	 * @since 1.0.2
	 */
	public ISectionElementGroup getLineGroup(String name) {
		return _line_group_map.get(name);
	}

	/**
	 * 【機能】グループを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】存在しなければ null が返ります。<BR>
	 * 
	 * @param name 名称
	 * @return グループ
	 * @create 2004/07/01
	 * @author  
	 * @since 1.0.2
	 */
	public ISectionElementGroup getCircleGroup(String name) {
		return _circle_group_map.get(name);
	}

	/**
	 * 【機能】レポートを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#setReport(jp.co.kccs.greenearth.report.IReport)
	 * @param report レポート
	 * @create 2004/03/30
	 * @author  
	 * @since 1.0.0
	 */
	@Override
	public void setReport(IReport report) {
		_report = report;
	}

	/**
	 * 【機能】網掛け印刷を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#printBorder()
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	@Override
	public void printBorder() throws GReportException {
		final GStdReport report = (GStdReport) getReport();
		final IReportWriter writer = report.getWriter();

		calcAbsolutePosition();
		
		if (report.getBorderCount() % 2 == 1) {
			writer.writeBackGroundColor(getAbsoluteLeft(), getAbsoluteTop(), getWidth(), getHeight(), GColor.gLightGray);
		}
		
		report.addBorderCount(1);

		this.printSection();
	}

	/**
	 * 【機能】セクションの印刷を行います。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#print()
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	@Override
	public void print() throws GReportException {

		printBackGroundColor();

		if (getPlaceHolder() != null) {
			return;
		}
		
		if (getAlternate()) {
			this.printBorder();
			return;
		}
		
		this.printSection();
	}

	/**
	 * 【機能】空セクションを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】枠だけは印刷されます。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#printEmpty()
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	@Override
	public void printEmpty() throws GReportException {
		_is_empty = true;
		print();
	}

	/**
	 * 【機能】セクションを印刷します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 2004/03/25
	 * @author kusakari
	 * @since 1.0.0
	 */
	protected final void printSection() throws GReportException {

		if (!getOutput()) {
			moveLineCount();
			return;
		}

		if (!isEmpty()) {
			for (Object fieldObj : getFieldList()) {
				IReportField field = (IReportField) fieldObj;
				field.print();
			}
		}

		_is_empty = false;

		for (Object rectangleObj : getRectangleList()) {
			IReportRectangle rec = (IReportRectangle) rectangleObj;
			rec.print();
		}

		for (Object lineObj : getLineList()) {
			IReportLine line = (IReportLine) lineObj;
			line.print();
		}

		for (Object circleObj : getCircleList()) {
			IReportCircle circle = (IReportCircle) circleObj;
			circle.print();
		}

		for (Object imageObj : getImageList()) {
			IReportImage image = (IReportImage) imageObj;
			image.print();
		}

		moveLineCount();
	}

	/**
	 * 【機能】項目に値を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param field_name 項目名
	 * @param value 値
	 * @create 
	 * @author  
	 * @since 
	 */
	public void setVariable(String field_name, Object value) {
		getReport().getCurrentRecord().setVariable(field_name, value);
	}

	/**
	 * 【機能】静的情報を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 静的情報
	 * @create 2004/06/30
	 * @since 1.0.0
	 */
	protected ISectionInfo getStaticInfo() {
		return _static_info;
	}

	/**
	 * 【機能】仮想項目名指定で値文字列を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param column_name 仮想項目名
	 * @return 値文字列
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	public String getVariableString(String column_name) throws GReportException {
		return getReport().getCurrentRecord().getVariableString(column_name);
	}

	/**
	 * 【機能】仮想項目名指定で値を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param column_name 仮想項目名
	 * @return 値
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	public Object getVariable(String column_name) throws GReportException {
		return getReport().getCurrentRecord().getVariable(column_name);
	}

	/**
	 * 【機能】ベースポジションが絶対値か判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	protected boolean isBaseAbsolute() {
		
		if (getBasePosition() == ISectionInfo.BASE_POSITION_ABSOLUTE) {
			return true;
		}

		return false;
	}

	/**
	 * 【機能】空印刷かを判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 真偽値
	 * @create 2004/06/30
	 * @author  
	 * @since 1.0.0
	 */
	protected boolean isEmpty() {
		return _is_empty;
	}

	/**
	 * 【機能】フィールドを追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * @param field フィールド
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	protected void addReportField(IReportField field) {
		addFieldInfo(field);
	}

	/**
	 * 【機能】ラインを追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param line ライン
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	protected void addReportLine(IReportLine line) {
		addLineInfo(line);
	}

	/**
	 * 【機能】イメージを追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param image イメージ
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	protected void addReportImage(IReportImage image) {
		addImageInfo(image);
	}

	/**
	 * 【機能】サークルを追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param circle 円
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	protected void addReportCircle(IReportCircle circle) {
		addCircleInfo(circle);
	}

	/**
	 * 【機能】四角形を追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param rec 四角形
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	protected void addReportRectangle(IReportRectangle rec) {
		addRectangleInfo(rec);
	}

	/**
	 * 【機能】表示位置を計算します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】現在の横位置、縦位置が決定されます。<BR>
	 * 
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	public void calcAbsolutePosition() {
		final GStdReport report = (GStdReport) getReport();

		if (report.getPrintDirection() == IReportInfo.PRINT_DIRECTION_VIRTICAL) {
			_absolute_left = getLeft();

			if (isBaseAbsolute()) {
				_absolute_top = getTop();
			} else {
				_absolute_top = report.getLineCount();
			}
		} else {
			_absolute_top = getTop();

			if (isBaseAbsolute()) {
				_absolute_left = getLeft();
			} else {
				_absolute_left = report.getLineCount();
			}
		}
	}

	/**
	 * 【機能】上端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdSectionInfo#setTop(int)
	 * @param top 上端
	 * @create 2006/04/05
	 * @author  
	 * @since 1.1.0
	 */
	@Override
	public void setTop(int top) {
		_mutable_top = top;
	}

	/**
	 * 【機能】上端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdSectionInfo#getTop()
	 * @return 上端
	 * @create 2006/04/05
	 * @author  
	 * @since 1.1.0
	 */
	@Override
	public int getTop() {
		if (_mutable_top == -1) {
			_mutable_top = super.getTop();
		}
		return _mutable_top;
	}

	/**
	 * 【機能】左端を設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdSectionInfo#setLeft(int)
	 * @param left 左端
	 * @create 2006/04/05
	 * @author  
	 * @since 1.1.0
	 */
	@Override
	public void setLeft(int left) {
		_mutable_left = left;
	}

	/**
	 * 【機能】左端を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.repository.stdimpl.GStdSectionInfo#getLeft()
	 * @return 左端
	 * @create 2006/04/05
	 * @author  
	 * @since 1.1.0
	 */
	@Override
	public int getLeft() {
		if (_mutable_left == -1) {
			_mutable_left = super.getLeft();
		}
		return _mutable_left;
	}

	/**
	 * 【機能】<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @create 
	 * @author  
	 * @since 
	 */
	public void setPlaceHolder() {
		GStdReport report = (GStdReport) getReport();
		IReportWriter writer = report.getWriter();

		IPlaceHolder placeHolder = createPlaceHolder(report.getLineCount());

		int top = 0;
		if (isBaseAbsolute()) {
			top = getTop();
		} else {
			top = report.getLineCount();
		}

		writer.setTemplateSection(getName(), getLeft(), top, getWidth(), getHeight());

		_place_holder = placeHolder;
	}
	
	/**
	 * 【機能】プレイスホルダを取得します.<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @return プレイスホルダ
	 * @create 2015/3/12
	 * @author  wan
	 * @since 2.0.0
	 * 
	 */
	private IPlaceHolder getPlaceHolder() {
		return _place_holder;
	}

	/**
	 * 【機能】<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	public void printPlaceHolder() throws GReportException {
		_place_holder.print();
	}

	/**
	 * プレイスホルダのインスタンスを作成します.
	 * 
	 * @param lineCount 行数
	 * @return プレースホルダ
	 * @create 
	 * @author  
	 * @since 
	 */
	protected IPlaceHolder createPlaceHolder(int lineCount) {
		IPlaceHolder placeHolder = GFrameworkUtils.getComponent(IPlaceHolder.class.getName());
		placeHolder.setParamters(lineCount, this);
		return placeHolder;
	}

	/**
	 * フィールドを作成します.
	 * 
	 * @param fieldInfo フィールド情報
	 * @return フィールド
	 * @create 
	 * @author  
	 * @since 
	 */
	protected IReportField createReportField(IFieldInfo fieldInfo) {
		IReportField field = GFrameworkUtils.getComponent(IReportField.class.getName());
		field.load(fieldInfo, this);
		return field;
	}

	/**
	 * 四角インスタンスを作成します.
	 * 
	 * @param rectangleInfo 四角情報
	 * @return 四角
	 * @create 
	 * @author  
	 * @since 
	 */
	protected IReportRectangle createReportRectangle(IRectangleInfo rectangleInfo) {
		IReportRectangle rectangle = GFrameworkUtils.getComponent(IReportRectangle.class.getName());
		rectangle.load(rectangleInfo, this);
		return rectangle;
	}

	/**
	 * ラインインスタンスを作成します.
	 * 
	 * @param lineInfo ライン情報
	 * @return ライン
	 * @create 
	 * @author  
	 * @since 
	 */
	protected IReportLine createReportLine(ILineInfo lineInfo) {
		IReportLine line = GFrameworkUtils.getComponent(IReportLine.class.getName());
		line.load(lineInfo, this);
		return line;
	}

	/**
	 * 円イスタンスを作成します.
	 * 
	 * @param circleInfo 円情報
	 * @return 円
	 * @create 
	 * @author  
	 * @since 
	 */
	protected IReportCircle createReportCircle(ICircleInfo circleInfo) {
		IReportCircle circle = GFrameworkUtils.getComponent(IReportCircle.class.getName());
		circle.load(circleInfo, this);
		return circle;
	}

	/**
	 * イメージンスタンスを作成します.
	 * 
	 * 
	 * @param imageInfo イメージ情報
	 * @return イメージ
	 * @create 
	 * @author  
	 * @since 
	 */
	protected IReportImage createReportImage(IImageInfo imageInfo) {
		IReportImage image = GFrameworkUtils.getComponent(IReportImage.class.getName());
		image.load(imageInfo, this);
		return image;

	}

	/**
	 * 【機能】セクション情報からGStdReportSection内部情報を生成します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @param sec_info セクション情報
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	protected void create(ISectionInfo sec_info) throws GReportException {

		createActiveInfo(sec_info);

		// 一時テーブルにキーを入れます。
		// 重複するエレメントのみグループに追加します。
		// 一時テーブル
		Map<String, Object> tempMap = new HashMap<String, Object>();

		{ // Rectangle
			for (Object rectangleObj : sec_info.getRectangleList()) {
				IRectangleInfo recInfo = (IRectangleInfo) rectangleObj;
				IReportRectangle rec = createReportRectangle(recInfo);
				addReportRectangle(rec);

				addGroup(tempMap, _rec_group_map, recInfo.getName());
				tempMap.put(rec.getName(), rec);
			}
			
			Iterator<String> it = tempMap.keySet().iterator();
			while (it.hasNext()) {
				addGroup(tempMap, _rec_group_map, it.next().toString());
			}
			
			tempMap.clear();
		}

		{ // Line
			for (Object lineObj : sec_info.getLineList()) {
				ILineInfo lineInfo = (ILineInfo) lineObj;
				IReportLine line = createReportLine(lineInfo);
				addReportLine(line);

				addGroup(tempMap, _line_group_map, lineInfo.getName());
				tempMap.put(line.getName(), line);
			}
			
			Iterator<String> it = tempMap.keySet().iterator();
			while (it.hasNext()) {
				addGroup(tempMap, _line_group_map, it.next().toString());
			}
			
			tempMap.clear();
		}

		{ // Circle
			for (Object circleObj : sec_info.getCircleList()) {
				ICircleInfo circleInfo = (ICircleInfo) circleObj;
				IReportCircle circle = createReportCircle(circleInfo);
				addReportCircle(circle);

				addGroup(tempMap, _circle_group_map, circleInfo.getName());
				tempMap.put(circle.getName(), circle);
			}

			Iterator<String> it = tempMap.keySet().iterator();
			while (it.hasNext()) {
				addGroup(tempMap, _circle_group_map, it.next().toString());
			}
			
			tempMap.clear();
		}

		{ // Field
			for (Object fieldObj : sec_info.getFieldList()) {
				IFieldInfo fieldInfo = (IFieldInfo) fieldObj;
				IReportField field = createReportField(fieldInfo);
				addReportField(field);

				addGroup(tempMap, _field_group_map, fieldInfo.getName());
				tempMap.put(field.getName(), field);
			}
			
			Iterator<String> it = tempMap.keySet().iterator();
			while (it.hasNext()) {
				addGroup(tempMap, _field_group_map, it.next().toString());
			}
			tempMap.clear();
		}

		{ // Image
			for (Object imageObj : sec_info.getImageList()) {
				IImageInfo imageInfo = (IImageInfo) imageObj;
				IReportImage image = createReportImage(imageInfo);
				addReportImage(image);

				addGroup(tempMap, _image_group_map, imageInfo.getName());
				tempMap.put(image.getName(), image);
			}
			
			Iterator<String> it = tempMap.keySet().iterator();
			while (it.hasNext()) {
				addGroup(tempMap, _image_group_map, it.next().toString());
			}
			tempMap.clear();
		}
	}

	/**
	 * セクション情報をロードします.
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#load(jp.co.kccs.greenearth.report.repository.ISectionInfo)
	 * @param sectionInfo セクション情報
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	@Override
	public void load(ISectionInfo sectionInfo) throws GReportException {
		create(sectionInfo);
	}

	/**
	 * 【機能】動的情報を生成します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param sectionInfo セクション情報
	 * @create 
	 * @author  
	 * @since 
	 */
	protected void createActiveInfo(ISectionInfo sectionInfo) {
		_static_info = sectionInfo;

		super.setName(sectionInfo.getName());
		super.setTop(sectionInfo.getTop());
		super.setHeight(sectionInfo.getHeight());
		super.setLeft(sectionInfo.getLeft());
		super.setWidth(sectionInfo.getWidth());
		super.setBasePosition(sectionInfo.getBasePosition());
		super.setOutput(sectionInfo.getOutput());
		super.setAlternate(sectionInfo.getAlternate());
		super.setBackGroundColor(sectionInfo.getBackGroundColor());
	}

	/**
	 * 【機能】セクションの動的情報を初期化します。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#initialize()
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 
	 */
	@Override
	public void initialize() throws GReportException {
		getFieldList().clear();
		getCircleList().clear();
		getImageList().clear();
		getLineList().clear();
		getRectangleList().clear();

		create(getStaticInfo());
	}

	/**
	 * 【機能】フィールドの出力要否を設定します.<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#setOutput(java.lang.String, boolean)
	 * @param object_name オブジェクト名
	 * @param output 表示非表示フラグ
	 * @create 
	 * @author  
	 * @since 
	 */
	@Override
	public void setOutput(String object_name, boolean output) {
		
		for (Object fieldObj : getFieldList()) {
			GStdReportField field = (GStdReportField) fieldObj;
			if (field.getName().equals(object_name)) {
				field.setOutputInfo(output);
			}
		}
		
		for (Object imageObj : getImageList()) {
			GStdReportImage image = (GStdReportImage) imageObj;
			if (image.getName().equals(object_name)) {
				image.setOutputInfo(output);
			}
		}

		for (Object rectangleObj : getRectangleList()) {
			GStdReportRectangle rectangle = (GStdReportRectangle) rectangleObj;
			if (rectangle.getName().equals(object_name)) {
				rectangle.setOutputInfo(output);
			}
		}

		for (Object lineObj : getLineList()) {
			GStdReportLine line = (GStdReportLine) lineObj;
			if (line.getName().equals(object_name)) {
				line.setOutputInfo(output);
			}
		}

		for (Object circleObj : getCircleList()) {
			GStdReportCircle circle = (GStdReportCircle) circleObj;
			if (circle.getName().equals(object_name)) {
				circle.setOutputInfo(output);
			}
		}
	}

	/**
	 * 【機能】サークルを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#getCircle(java.lang.String)
	 * @param circle_name サークル名
	 * @return サークル
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 1.0.0
	 */
	@Override
	public IReportCircle getCircle(String circle_name) throws GReportException {
		for (Object circleObj : getCircleList()) {
			IReportCircle circle = (IReportCircle) circleObj;
			if (circle.getName().equals(circle_name)) {
				return circle;
			}
		}
		return null;
	}

	/**
	 * 【機能】イメージを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#getImage(java.lang.String)
	 * @param image_name イメージ名
	 * @return イメージ
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 1.0
	 */
	@Override
	public IReportImage getImage(String image_name) throws GReportException {
		for (Object imageObj : getImageList()) {
			IReportImage image = (IReportImage) imageObj;
			if (image.getName().equals(image_name)) {
				return image;
			}
		}
		return null;
	}

	/**
	 * 【機能】ラインを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#getLine(java.lang.String)
	 * @param line_name ライン名
	 * @return ライン
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 1.0
	 */
	@Override
	public IReportLine getLine(String line_name) throws GReportException {
		for (Object lineObj : getLineList()) {
			IReportLine line = (IReportLine) lineObj;
			if (line.getName().equals(line_name)) {
				return line;
			}
		}
		return null;
	}

	/**
	 * 【機能】四角形を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportSection#getRectangle(java.lang.String)
	 * @param rec_name 四角形名
	 * @return 四角形
	 * @throws GReportException ReportFramework例外
	 * @create 
	 * @author  
	 * @since 1.0
	 */
	@Override
	public IReportRectangle getRectangle(String rec_name) throws GReportException {
		for (Object rectangleObj : getRectangleList()) {
			IReportRectangle rectangle = (IReportRectangle) rectangleObj;
			if (rectangle.getName().equals(rec_name)) {
				return rectangle;
			}
		}
		return null;
	}

	/**
	 * 【機能】絶対位置上を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 絶対位置上
	 * @create 2004/06/30
	 * @since 1.0.2
	 */
	public int getAbsoluteTop() {
		return _absolute_top;
	}

	/**
	 * 【機能】絶対位置左を取得します。<BR>
	 * 【戻値】絶対位置左<BR>
	 * 【備考】<BR>
	 * 
	 * @return 絶対位置左
	 * @create 2004/06/30
	 * @author  
	 * @since 1.0.2
	 */
	public int getAbsoluteLeft() {
		return _absolute_left;
	}

	/**
	 * セクションの背景色を設定します。<BR>
	 * 
	 * @param 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	@Override
	public void setBackGroundColor(Color backGroundColor) {
		super.setBackGroundColor(backGroundColor);
	}

	/**
	 * セクションの背景色を取得します。<BR>
	 * 
	 * @return 背景色
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	@Override
	public Color getBackGroundColor() {
		return super.getBackGroundColor();
	}

	/**
	 * セクションの背景色を印刷します。<BR>
	 * 
	 * @create 2015/12/17
	 * @author hashimoto
	 * @since 2.3.0
	 */
	private void printBackGroundColor() {
		
		//背景色白は背景色なしと同義です。よって、背景色白の場合は背景色を印刷しません。
		if (GColor.white == getBackGroundColor()) {
			return;
		}
		
		GStdReport report = (GStdReport) getReport();
		IReportWriter writer = report.getWriter();
		calcAbsolutePosition();
		writer.writeBackGroundColor(getAbsoluteLeft(), getAbsoluteTop(), getWidth(), getHeight(), getBackGroundColor());
	}
}
