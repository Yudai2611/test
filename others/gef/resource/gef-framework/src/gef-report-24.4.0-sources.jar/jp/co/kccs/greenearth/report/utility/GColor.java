/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import java.awt.Color;

/**
 * 【役割】GColorを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/04/14
 * @author kusakari
 * @since 1.0.0
 */
public class GColor extends Color {

	/** serial version */
	private static final long serialVersionUID = -4019654670955118965L;
	// CHECKSTYLE:OFF
	/** 帳票出力用に調整されたダークグレイです。 */
	public static final Color gDarkGray = getHSBColor(0, 0, 0.80f);
	/** 帳票出力用に調整されたグレイです。 */
	public static final Color gGray = getHSBColor(0, 0, 0.85f);
	/** 帳票出力用に調整されたライトグレイです。 */
	public static final Color gLightGray = getHSBColor(0, 0, 0.90f);
	/** 帳票出力用に調整された非常に薄いライトグレイです。 */
	public static final Color gSuperLightGray = getHSBColor(0, 0, 0.95f);
	// CHECKSTYLE:ON

	/**
	 * 範囲 (0 - 255) の指定された赤、緑、青およびアルファの値を使って、不透明な sRGB カラーを作成します。アルファはデフォルトで 255
	 * に設定されます。実際の 表示に使用される色は、特定の出力デバイスで使用可能な色の中でもっと も近いものとなります。
	 * 
	 * @param r 赤
	 * @param g 緑
	 * @param b 青
	 * @param a 透明
	 * @create 2004/04/14
	 * @since 1.0
	 */
	public GColor(int r, int g, int b, int a) {
		super(r, g, b, a);
	}

	/**
	 * 範囲 (0 - 255) の指定された赤、緑、青の値を使って、不透明な sRGB カラーを作成します。アルファはデフォルトで 255
	 * に設定されます。実際の 表示に使用される色は、特定の出力デバイスで使用可能な色の中でもっと も近いものとなります。
	 * 
	 * @param r 赤
	 * @param g 緑
	 * @param b 青
	 * @create 2004/04/14
	 * @since 1.0
	 */
	public GColor(int r, int g, int b) {
		super(r, g, b);
	}

	/**
	 * 範囲 (0.0 - 1.0) の指定された赤、緑、青およびアルファの値を使って、不透明な sRGB カラーを作成します。アルファはデフォルトで
	 * 1.0 に設定されます。実際の 表示に使用される色は、特定の出力デバイスで使用可能な色の中でもっと も近いものとなります。
	 * 
	 * @param r 赤
	 * @param g 緑
	 * @param b 青
	 * @param a 透明
	 * @create 2004/04/14
	 * @since 1.0
	 */
	public GColor(float r, float g, float b, float a) {
		super(r, g, b, a);
	}

	/**
	 * 範囲 (0.0 - 1.0) の指定された赤、緑、青の値を使って、不透明な sRGB カラーを作成します。アルファはデフォルトで 1.0
	 * に設定されます。実際の 表示に使用される色は、特定の出力デバイスで使用可能な色の中でもっと も近いものとなります。
	 * 
	 * @param r 赤
	 * @param g 緑
	 * @param b 青
	 * @create 2004/04/14
	 * @since 1.0
	 */
	public GColor(float r, float g, float b) {
		super(r, g, b);
	}
}
