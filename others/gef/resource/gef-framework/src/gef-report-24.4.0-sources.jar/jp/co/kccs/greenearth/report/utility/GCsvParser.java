/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import static jp.co.kccs.greenearth.commons.utils.GStringUtils.isEmpty;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.report.GReportRuntimeException;

import org.apache.oro.text.perl.Perl5Util;
import org.apache.oro.text.regex.PatternMatcherInput;

/**
 * 【役割】Csv解析を行うクラスです。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】Tsvも扱うことができます<BR>
 * 
 * @create 2004/09/01
 * @author kusakari
 * @since 1.0.3
 */
public class GCsvParser {

	/** CSV ファイル */
	public static final int TYPE_CSV = 0;
	/** TSV ファイル */
	public static final int TYPE_TSV = 1;
	/** Tsv 正規表現 */
	private static final String PATTERN_TSV = "/(\"(?:[^\"]|\"\")*\"|[^\t]*)/";
	/** Csv 正規表現 */
	private static final String PATTERN_CSV = "/(\"(?:[^\"]|\"\")*\"|[^,]*)/";

	/** タイプ */
	private String _pattern = null;

	/**
	 * 【役割】CsvParser を生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 * 
	 * @param type ファイルタイプ
	 * @create 2004/09/01
	 * @since 1.0.3
	 */
	public GCsvParser(int type) {
		if (type == TYPE_CSV) {
			_pattern = PATTERN_CSV;
		} else if (type == TYPE_TSV) {
			_pattern = PATTERN_TSV;
		} else {
			throw new GReportRuntimeException("A Parameter is an unsupported type.");
		}
	}

	/**
	 * 【機能】解析パターンを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 解析パターン
	 * @create 2004/09/01
	 * @since 1.0.3
	 */
	public String getPattern() {
		return _pattern;
	}

	/**
	 * 【機能】与えられた文字列を解析します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param line 解析する文字列
	 * @return 解析後の文字列の配列
	 * @create 2004/09/01
	 * @since 1.0.3
	 */
	public String[] parse(String line) {
		return parse(line, 0, -1);
	}

	/**
	 * 【機能】与えられた文字列を解析します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】終了インデックス「-1」は全値が対象となります。<BR>
	 * 
	 * @param line 文字列
	 * @param start_index 開始インデックス
	 * @param end_index 終了インデックス
	 * @return 解析後の値の配列
	 * @create 2004/09/02
	 * @since 1.0.3
	 */
	public String[] parse(String line, int start_index, int end_index) {
		
		if (isEmpty(line)) {
			return null;
		}
		
		if (start_index < 0) {
			throw new GReportRuntimeException("The StartIndex must be a positive number or 0.");
		}
		
		List<String> valuesList = convertToValuesList(line);
		
		if (end_index == -1 || end_index > valuesList.size()) {
			end_index = valuesList.size();
		}
		
		List<String> temp = new ArrayList<String>();
		for (int i = start_index; i < end_index; i++) {
			temp.add(getParseValue(valuesList.get(i).toString()));
		}
		
		return (String[]) temp.toArray(new String[0]);
	}

	/**
	 * 【機能】レコード１行分から値のリストへ変換します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param line レコード１行分
	 * @return レコード１行分の値のリスト
	 * @create 2004/09/01
	 * @since 1.0.3
	 */
	private List<String> convertToValuesList(String line) {
		final PatternMatcherInput input = new PatternMatcherInput(line);
		Perl5Util util = new Perl5Util();
		List<String> list = new ArrayList<String>();

		while (util.match(_pattern, input)) {
			list.add(util.group(1));
		}
		
		return list;
	}

	/**
	 * 【機能】値から二重引用符のエスケープシーケンスを除去します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param value 二重引用符のエスケープシーケンスを除去する値
	 * @return 二重引用符のエスケープシーケンスを除去した値
	 * @create 2004/09/01
	 * @since 1.0.3
	 */
	protected String getParseValue(String value) {
		if (value.startsWith("\"") && value.endsWith("\"")) {
			return removeEscapeForDoubleQuotes(value.substring(1, value.length() - 1));
		}
		
		return removeEscapeForDoubleQuotes(value);
	}

	/**
	 * 【機能】二重引用符のエスケープシーケンスを除去ます。<BR>
	 * 【呼出】<BR>
	 * 【備考】<BR>
	 * 
	 * @param value 文字列
	 * @return 二重引用符のエスケープシーケンスを除去した文字列
	 * @create 2014/12/08
	 * @author Hashimoto
	 * @since 2.0.0
	 */
	private String removeEscapeForDoubleQuotes(String value) {
		return value.replaceAll("\"\"", "\"");
	}

}
