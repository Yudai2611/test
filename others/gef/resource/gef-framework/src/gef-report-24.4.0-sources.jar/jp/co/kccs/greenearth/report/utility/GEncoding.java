/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import java.io.UnsupportedEncodingException;

import jp.co.kccs.greenearth.report.GReportRuntimeException;

/**
 * 【役割】GEncodingを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2004/03/01
 * @author kusakari
 * @since 1.0.0
 */
public class GEncoding {

	/** Shift_JIS */
	public static final String SHIFT_JIS = "Shift_JIS";
	/** UTF-8 */
	public static final String UTF8 = "UTF-8";
	/** EUC_JP */
	public static final String EUC_JP = "EUC_JP";
	/** Windows-31J */
	public static final String WINDOWS_31J = "Windows-31J";
	/** SJIS */
	public static final String SJIS = "SJIS";
	/** Cp943C */
	public static final String CP943C = "Cp943C";
	/** MS932 */
	public static final String MS932 = "MS932";

	/** ISO-8859-1 */
	public static final String ISO_8859_1 = "iso-8859-1";
	/** 指定エンコード */
	private String _encoding = null;

	/**
	 * 【役割】GEncoding を生成します。<BR>
	 * 【生成】<BR>
	 * 【解放】<BR>
	 * 【備考】<BR>
	 * 
	 * @param encode エンコード
	 * @create 2004/03/01
	 * @author 
	 * @since 1.0.0
	 */
	private GEncoding(String encode) {
		_encoding = encode;
	}

	/**
	 * 【機能】指定エンコードを取得します。<BR>
	 * GEncodingのフィールド定数を利用して下さい。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param encode エンコード
	 * @return GEncoding エンコード
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	public static GEncoding getEncoding(String encode) {
		if (encode == null) {
			return null;
		}
		GEncoding e = new GEncoding(encode);
		return e;
	}

	/**
	 * 【機能】エンコード後の文字列を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】エンコード対象文字列がnullな場合はnullが返ります。<BR>
	 * 
	 * @param str 対象文字列
	 * @return String エンコード後の文字列
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	public String getString(String str) {
		if (str == null) {
			return null;
		}
		
		try {
			return new String(str.getBytes(getSpecifiedEncoding()), getSpecifiedEncoding());
		} catch (UnsupportedEncodingException ue) {
			throw new GReportRuntimeException(str + " is not supported.", ue);
		}
	}

	/**
	 * 【機能】エンコード後の文字列のバイト数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】エンコードに失敗した場合は0が返ります。<BR>
	 * エンコード対象文字列がnullな場合は0が返ります。<BR>
	 * 
	 * @param str 対象文字列
	 * @return int 文字列のバイト数
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	public int getBytesLength(String str) {
		try {
			if (str == null) {
				return 0;
			}
			return str.getBytes(getSpecifiedEncoding()).length;
		} catch (UnsupportedEncodingException ue) {
			throw new GReportRuntimeException(str + " is not supported.", ue);
		}
	}

	/**
	 * 【機能】このGEncodingを破棄します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	public void destroy() {
		_encoding = null;
	}
	
	/**
	 * 指定されているエンコードを取得します.
	 * @return エンコード
	 * @create 2014/12/16
	 * @author KCCS Hashimoto
	 * @since 
	 */
	String getSpecifiedEncoding() {
		if (_encoding == null) {
			throw new GReportRuntimeException("An encoding is not specified.");
		}
		return _encoding;
	}
}
