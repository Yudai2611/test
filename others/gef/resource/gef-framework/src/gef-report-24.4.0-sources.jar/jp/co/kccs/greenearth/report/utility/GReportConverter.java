/*
 * Copyright 2004-2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import java.io.File;
import java.net.URI;
import java.sql.ResultSet;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.IReportList;
import jp.co.kccs.greenearth.report.IReportRecord;
import jp.co.kccs.greenearth.report.csvimpl.GCsvReportList;
import jp.co.kccs.greenearth.report.dao.fixedlength.IFixedLengthList;
import jp.co.kccs.greenearth.report.dao.separatedfile.ISeparatedFileList;
import jp.co.kccs.greenearth.report.sqlimpl.GResultSetReportList;
import jp.co.kccs.greenearth.report.stdimpl.GStdReportList;

/**
 * 【役割】レポートコンバータを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】Report Framework オブジェクトを取得する際に利用するコンバータです。<BR>
 *
 * @create 2004/03/29
 * @author kusakari
 * @since 1.0.0
 */
public class GReportConverter {

	/**
	 * 【機能】java.io.File を IReportList に変換します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * <b>ファイルの一行目はヘッダー項目としなければなりません。</b><BR>
	 * エンコーディング文字列例・・・Cp943C / MS932 / SJIS<BR>
	 * ファイルタイプ例・・・GCsvParser.TYPE_CSV,GCsvParser.TYPE_TSV<BR>
	 *
	 * @param file ファイルパス
	 * @param encoding エンコード
	 * @param type タイプ
	 * @param is_delete 自動削除フラグ
	 * @return レポートリスト
	 * @throws GReportException ReportFramework例外
	 * @create 2004/09/02
	 * @author
	 * @since 1.0.3
	 */
	public static IReportList convertToCsvReportList(File file, String encoding, int type, boolean is_delete) throws GReportException {
		return new GCsvReportList(file, encoding, type, is_delete);
	}

	/**
	 * {@link IReportList}に変換します.<br/>
	 *
	 * @param list リスト
	 * @return レポートリスト
	 * @create 2014/11/20
	 * @author yamashita
	 * @since 2.0.0
	 */
	public static IReportList convertToReportList(List<IReportRecord> list) {
		if (list == null) {
			return null;
		}
		return new GStdReportList(list);
	}

	/**
	 * 【機能】java.sql.ResultSet を IReportList に変換します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param rs ResultSet
	 * @param is_close ResultSetを自動クローズするかの真偽値
	 * @return レポートリスト
	 * @throws GReportException ReportFramework例外
	 * @create
	 * @author
	 * @since 1.0.2
	 */
	public static IReportList convertToResultSetReportList(ResultSet rs, boolean is_close) throws GReportException {
		GResultSetReportList list = new GResultSetReportList(rs);
		list.setAutoClose(is_close);
		return list;
	}

	/**
	 * {@link jp.co.kccs.greenearth.report.dao.IReportList}を{@link jp.co.kccs.greenearth.report.IReportList}に変換します。<BR>
	 *
	 * @param list レポートリスト
	 * @return レポートリストアダプター
	 * @throws GReportException ReportFramework例外
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	public static IReportList convertToReportList(jp.co.kccs.greenearth.report.dao.IReportList list) throws GReportException {
		GReportListAdapter adapter = new GReportListAdapter(list);
		return adapter;
	}

	/**
	 * レイアウト定義ファイルを元にセパレートファイルリストを生成します.<br>
	 *
	 * @param layoutFilePath レイアウト定義ファイル名
	 * @param inputFilePath インプットファイル名
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param separatedType セパレートタイプ
	 * @return セパレートファイルリスト
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Deprecated
	public static IReportList convertToSeparatedFileList(String layoutFilePath, String inputFilePath, boolean delete,
		int separatedType) throws GReportException {
		return convertToSeparatedFileList(GFileUtils.createURI(layoutFilePath), GFileUtils.createURI(inputFilePath),
			delete, separatedType);
	}

	/**
	 * レイアウト定義ファイルを元にセパレートファイルリストを生成します.<br>
	 *
	 * @param layoutFile レイアウト定義ファイル名
	 * @param inputFile インプットファイル名
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param separatedType セパレートタイプ
	 * @return セパレートファイルリスト
	 * @throws GReportException ReportFramework例外
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static IReportList convertToSeparatedFileList(URI layoutFile, URI inputFile, boolean delete,
		int separatedType) throws GReportException {
		jp.co.kccs.greenearth.report.dao.IReportList list =
			ISeparatedFileList.Factory.createList(layoutFile, inputFile, delete, separatedType);
		return convertToReportList(list);
	}

	/**
	 * ヘッダーを元にセパレートファイルリストを生成します.<br>
	 *
	 * @param inputFilePath インプットファイル名
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param encoding インプットデータのエンコードタイプ
	 * @param separatedType セパレートタイプ
	 * @return セパレートファイルリスト
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Deprecated
	public static IReportList convertToSeparatedFileList(String inputFilePath, boolean delete, String encoding,
		int separatedType) throws GReportException {
		return convertToSeparatedFileList(GFileUtils.createURI(inputFilePath), delete, encoding, separatedType);
	}

	/**
	 * ヘッダーを元にセパレートファイルリストを生成します.<br>
	 *
	 * @param inputFile インプットファイル名
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @param encoding インプットデータのエンコードタイプ
	 * @param separatedType セパレートタイプ
	 * @return セパレートファイルリスト
	 * @throws GReportException ReportFramework例外
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static IReportList convertToSeparatedFileList(URI inputFile, boolean delete, String encoding,
		int separatedType) throws GReportException {
		jp.co.kccs.greenearth.report.dao.IReportList list =
			ISeparatedFileList.Factory.createList(inputFile, delete, encoding, separatedType);
		return convertToReportList(list);
	}

	/**
	 * 固定長リストを生成します.<br>
	 *
	 * @param layoutFilePath レイアウト定義ファイル名
	 * @param inputFilePath インプットファイル名
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @return 固定長リスト
	 * @throws GReportException ReportFramework例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Deprecated
	public static IReportList convertToFixedLengthList(String layoutFilePath, String inputFilePath, boolean delete)
		throws GReportException {
		return convertToFixedLengthList(GFileUtils.createURI(layoutFilePath), GFileUtils.createURI(inputFilePath),
			delete);
	}

	/**
	 * 固定長リストを生成します.<br>
	 *
	 * @param layoutFile レイアウト定義ファイルのURI
	 * @param inputFile インプットファイルのURI
	 * @param delete リストを閉じた後、インプットファイルを削除するかを表す値。削除する:true、削除しない:false
	 * @return 固定長リスト
	 * @throws GReportException ReportFramework例外
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public static IReportList convertToFixedLengthList(URI layoutFile, URI inputFile, boolean delete)
		throws GReportException {
		jp.co.kccs.greenearth.report.dao.IReportList list =
			IFixedLengthList.Factory.createList(layoutFile, inputFile, delete);
		return convertToReportList(list);
	}
}
