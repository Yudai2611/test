/*
 * Copyright 2004-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import java.io.File;

import jp.co.kccs.greenearth.report.GReportException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 【役割】レポート用ファイルユーティリティを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】各種パスの取得や圧縮機能をサポートしています。<BR>
 *
 * @create 2004/03/03
 * @author kusakari
 * @since 1.0.0
 */
public class GReportFileUtility {

	/** Logger **/
	protected static Log log = LogFactory.getLog(GReportFileUtility.class);

	/**
	 * 【機能】ディレクトリパスを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param file_path ファイルパス
	 * @return String ディレクトリパス
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public static String getDirPath(String file_path) {
		String dirPath = file_path;
		if (dirPath == null) {
			return dirPath;
		}
		int index = dirPath.lastIndexOf(File.separator);
		if (index != -1) {
			return dirPath.substring(0, index + 1);
		}
		return dirPath;
	}

	/**
	 * 【機能】ファイル名を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param file_path ファイルパス
	 * @return String ファイル名
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public static String getFileName(String file_path) {
		String fileName = file_path;
		if (fileName == null) {
			return fileName;
		}
		int index = fileName.lastIndexOf(File.separator);
		if (index != -1) {
			return fileName.substring(index + 1);
		}
		return fileName;
	}

	/**
	 * 【機能】ファイル名（拡張子なし）を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param file_path ファイルパス
	 * @return String ファイル名
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public static String getFileNameWithoutExtension(String file_path) {
		String fileName = file_path;
		if (fileName == null) {
			return fileName;
		}
		int index = file_path.lastIndexOf(File.separator);
		if (index != -1) {
			String tempName = file_path.substring(index + 1);
			index = tempName.lastIndexOf('.');
			if (index != -1) {
				return tempName.substring(0, index);
			}
		}
		return fileName;
	}

	/**
	 * 【機能】拡張子を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param file_path ファイルパス
	 * @return String 拡張子
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	public static String getExtension(String file_path) {
		String extension = file_path;
		if (extension == null) {
			return extension;
		}
		int index = extension.lastIndexOf(File.separator);
		if (index != -1) {
			String tempName = extension.substring(index + 1);
			index = tempName.lastIndexOf('.');
			if (index != -1) {
				return tempName.substring(index);
			}
		}
		return extension;
	}

	/**
	 * 【機能】与えられた文字列がファイル名か判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】ファイルパスに File.separator が含まれるかどうかで判断しています。<BR>
	 *
	 * @param file_path ファイルパス
	 * @return boolean ファイルであればtrue , ファイル名と判断出来なければfalse
	 * @create
	 * @author
	 * @since 1.0.0
	 */
	@Deprecated
	public static boolean isFileName(String file_path) {
		String fileName = file_path;
		if (fileName == null || fileName.equals("")) {
			return false;
		}
		int index = fileName.lastIndexOf(File.separator);
		if (index == -1) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 【機能】与えられた文字列が絶対パスか判断します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 *
	 * @param file_path ファイルパス
	 * @return boolean 絶対パスであればture
	 * @create 2015/08/19
	 * @author KCCS nakamura
	 * @since 2.2.0
	 */
	public static boolean isAbsolute(String file_path) {
		String fileName = file_path;
		if (fileName == null || fileName.equals("")) {
			return false;
		}
		File file = new File(fileName);
		return file.isAbsolute();
	}
	/**
	 * ファイルを削除します。
	 *
	 * @param file 削除対象ファイル
	 *
	 * @throws GReportException
	 * @return boolean 削除されるtrue , 削除されないfalse
	 * @create 2014/11/13
	 * @author tou
	 * @since 2.0.0
	 *
	 */
	private static boolean deleteFile(File file) throws GReportException {
		try {
			if (file.delete()) {
				log.info("file is deleted. file=\"" + file.getName() + "\"");
				return true;
			}

			return false;
		} catch (SecurityException e) {
			throw new GReportException(e);
		}
	}

	/**
	 * ファイルを削除します。 ※1回目削除失敗の場合は3秒後再度削除します。
	 *
	 * @param file
	 *            削除対象ファイル
	 *
	 * @throws GReportException
	 * @return boolean 削除されるtrue , 削除されないfalse
	 * @create 2014/11/13
	 * @author tou
	 * @since 2.0.0
	 *
	 */
	private static boolean deleteFileRetry(File file) throws GReportException {
		try {
			if (deleteFile(file)) {
				return true;
			}
		} catch (GReportException e) { // to retry
			;
		}

		try {
			// 3秒待って再試行
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			throw new GReportException(e);
		}

		return deleteFile(file);
	}

	/**
	 * ファイルを削除します。 リトライ指定の場合は3秒後再度削除します。
	 *
	 * @param file 削除対象ファイル
	 * @param isRetry true：リトライする、false:リトライしない
	 * @return boolean 削除されるtrue , 削除されないfalse
	 * @throws GReportException
	 * @create 2014/11/13
	 * @author tou
	 * @since 2.0.0
	 *
	 */
	public static boolean deleteFile(File file, boolean isRetry) throws GReportException {
		if (file == null) {
			return false;
		}
		return isRetry ? deleteFileRetry(file) : deleteFile(file);
	}
}
