/*
 * Copyright 2006-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.dao.IReportList;
import jp.co.kccs.greenearth.report.dao.IReportRecord;

/**
 * IReportListをGReportListとして振舞わせるためのアダプタークラスです。
 *
 * @create 2006/02/14
 * @author kitamura
 * @since 1.1.0
 */
public class GReportListAdapter implements
		jp.co.kccs.greenearth.report.IReportList {

	/** 実態となるIReportList */
	private IReportList _list = null;

	/**
	 * 実態となるIReportListを指定して、GReportListAdapterインスタンスを初期化します。
	 *
	 * @param list リスト
	 * @throws GReportException 例外
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GReportListAdapter(IReportList list) throws GReportException {
		try {
			_list = list;
			list.open();
		// CHECKSTYLE:OFF
		} catch (Exception e) {
		// CHECKSTYLE:ON
			if (_list != null) {
				_list.close();
			}
			if (e instanceof GReportException) {
				throw e;
			}
			throw new GReportException(e);
		}
	}

	/**
	 * 要素数を返します。<BR>
	 * 実装されていません。 常に0を返します。
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#size()
	 * @return 要素数
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public int size() {
		return 0;
	}

	/**
	 * カーソルを先頭行の前（-1）に移動します。<BR>
	 * 実装されていません。
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#resetCursor()
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public void resetCursor() {
	}

	/**
	 * レポートレコードを取得します。<BR>
	 * 読み直しは行いません。 内部的にget()が呼ばれています。
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#get()
	 * @return レポートレコード
	 * @throws GReportException 例外
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public jp.co.kccs.greenearth.report.IReportRecord get() throws GReportException {
		try {
			IReportRecord record = _list.getRecord();
			GReportRecordAdapter recordAdapter = new GReportRecordAdapter(record);
			return recordAdapter;
		} catch (GReportException e) {
			if (_list != null) {
				_list.close();
			}
			throw e;
		}
	}

	/**
	 * 次データにカーソルを移動させ、移動先の行にデータが存在するどうかを判定します。
	 *
	 * @see jp.co.kccs.greenearth.report.IReportList#next()
	 * @return 移動先の行にデータが存在するどうか
	 * @throws GReportException 例外
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	@Override
	public boolean next() throws GReportException {
		try {
			boolean result = _list.next();
			if (!result) {
				_list.close();
			}
			return result;
		} catch (GReportException e) {
			if (_list != null) {
				_list.close();
			}
			throw e;
		}
	}
}
