/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import jp.co.kccs.greenearth.report.GReportException;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.dao.IReportRecord;

/**
 * @create 2006/02/14
 * @author kitamura
 * @since 1.1.0
 */
public class GReportRecordAdapter implements
		jp.co.kccs.greenearth.report.IReportRecord {

	/** 実態となるIReportRecord */
	IReportRecord reportRecord = null;

	/**
	 * 実態となるIReportRecordを指定して、GReportRecordAdapterインスタンスを初期化します。
	 * 
	 * @param record 
	 * @create 2006/03/10
	 * @author kitamura
	 * @since 1.1.0
	 */
	public GReportRecordAdapter(IReportRecord record) {
		reportRecord = record;
	}

	/**
	 * クローンレコードを生成します。<BR>
	 * 内部的に<code>Object#clone()</code>メソッドを呼び出しているだけです。
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getClone()
	 * @return 生成したクローンレコード
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	public jp.co.kccs.greenearth.report.IReportRecord getClone() {
		try {
			return (jp.co.kccs.greenearth.report.IReportRecord) clone();
		} catch (CloneNotSupportedException e) {
			throw new GReportRuntimeException(e);
		}
	}

	/**
	 * 項目名指定で値を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getVariable(java.lang.String)
	 * @param column_name 
	 * @return 指定した項目名の値
	 * @throws GReportException 
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	public Object getVariable(String column_name) throws GReportException {
		return reportRecord.getVariable(column_name);
	}

	/**
	 * 目名指定で値文字列を取得します。
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#getVariableString(java.lang.String)
	 * @param column_name 
	 * @return 指定した目名の値
	 * @throws GReportException 
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String getVariableString(String column_name) throws GReportException {
		return reportRecord.getVariableString(column_name);
	}

	/**
	 * 項目名指定で値を設定します。
	 * 
	 * @see jp.co.kccs.greenearth.report.IReportRecord#setVariable(java.lang.String,
	 *      java.lang.Object)
	 * @param column_name 
	 * @param value 
	 * @create 2006/02/14
	 * @author kitamura
	 * @since 1.1.0
	 */
	public void setVariable(String column_name, Object value) {
		reportRecord.setVariable(column_name, value);
	}

	/**
	 * レコードの各項目値を文字列として取得します.<BR>
	 * フォーマット 項目値|項目値|項目値...<BR>
	 * 各項目値は内部的にgetVariableString(String)メソッドを用いて取得しています。
	 * 
	 * @see java.lang.Object#toString()
	 * @return レコードの項目値
	 * @create 2006/03/21
	 * @author kitamura
	 * @since 1.1.0
	 */
	public String toString() {
		return reportRecord.toString();
	}

}
