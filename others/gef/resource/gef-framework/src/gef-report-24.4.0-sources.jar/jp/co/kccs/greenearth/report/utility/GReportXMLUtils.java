/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

/**
 * レポート帳票の共通メソッドです。<BR>
 * 
 * @create 2014/12/19
 * @author KCCS XieHeping
 * @since 2.0.0
 */
public class GReportXMLUtils {

	/**
	 * XML文字列の処理です。<BR>
	 * 文字列に改行文字がある時、Nullを返す。<BR>
	 * 
	 * @param value 値
	 * @return 処理した値
	 * @create 2014/12/19
	 * @author KCCS XieHeping
	 * @since 2.0.0
	 */
	public static String getXMLValidString(String value) {
		if (value == null) {
			return null;
		}

		String checkValue = value;
		while (checkValue.indexOf(" ") != -1) {
			checkValue = checkValue.replaceFirst(" ", "");
		}

		if (checkValue.equals("\n")) {
			return null;
		} else {
			return value;
		}
	}
}
