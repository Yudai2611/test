/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.report.IReportSection;

/**
 * 【役割】セクションリストを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】複数のセクションを一つのセクションとして扱うことが出来ます。<BR>
 * 
 * @create 2003/12/12
 * @author kusakari
 * @since 1.0.0
 */
public class GSectionList implements ISectionList {

	/** セクションリスト */
	private List<IReportSection> _section_list = new ArrayList<IReportSection>();

	/**
	 * 【機能】セクションをリストに追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#add(jp.co.kccs.greenearth.report.IReportSection)
	 * @param section セクション
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public void add(IReportSection section) {
		_section_list.add(section);
	}

	/**
	 * 【機能】セクションをリストに追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#add(int, jp.co.kccs.greenearth.report.IReportSection)
	 * @param index インデックス
	 * @param section セクション
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public void add(int index, IReportSection section) {
		_section_list.add(index, section);
	}

	/**
	 * 【機能】リストをクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#clear()
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public void clear() {
		_section_list.clear();
	}

	/**
	 * 【機能】リストからインデックス指定でセクションを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#get(int)
	 * @param index インデックス
	 * @return セクション
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public IReportSection get(int index) {
		return _section_list.get(index);
	}

	/**
	 * 【機能】リストからインデックス指定でセクションを削除します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#remove(int)
	 * @param index インデックス
	 * @return セクション
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public IReportSection remove(int index) {
		return _section_list.remove(index);
	}

	/**
	 * 【機能】リストの指定インデックスにセクションを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#set(int, jp.co.kccs.greenearth.report.IReportSection)
	 * @param index インデックス
	 * @param section セクション
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public void set(int index, IReportSection section) {
		_section_list.set(index, section);
	}

	/**
	 * 【機能】リスト内の要素数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#size()
	 * @return 要素数
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public int size() {
		return _section_list.size();
	}

	/**
	 * 【機能】リスト内のすべての要素を適切な順序で格納しているセクション配列を返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#toArray()
	 * @return セクション配列
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public IReportSection[] toArray() {
		IReportSection[] reportSectionArray = new IReportSection[_section_list.size()];
		_section_list.toArray(reportSectionArray);
		return reportSectionArray;
	}

	/**
	 * 【機能】指定セクションがリスト内で最初に検出された位置のインデックスを返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#indexOf(jp.co.kccs.greenearth.report.IReportSection)
	 * @param section セクション
	 * @return インデックス
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public int indexOf(IReportSection section) {
		return _section_list.indexOf(section);
	}

	/**
	 * 【機能】指定セクションがリスト内で最後に検出された位置のインデックスを返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#lastIndexOf(jp.co.kccs.greenearth.report.IReportSection)
	 * @param section セクション
	 * @return インデックス
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public int lastIndexOf(IReportSection section) {
		return _section_list.lastIndexOf(section);
	}

	/**
	 * 【機能】リストに含まれるセクションの高さ総合計を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】保持セクションの総合計を返します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#getHeight()
	 * @return 高さ総合計
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public int getHeight() {
		int height = 0;
		for (int i = 0; i < _section_list.size(); i++) {
			IReportSection workSection = _section_list.get(i);
			if (workSection == null) {
				continue;
			}
			height += workSection.getHeight();
		}
		return height;
	}

	/**
	 * 【機能】リストに含まれるセクションの幅総合計を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】保持セクションの総合計を返します。<BR>
	 * 
	 * @see jp.co.kccs.greenearth.report.utility.ISectionList#getWidth()
	 * @return 幅総合計
	 * @create 
	 * @author 
	 * @since 1.0.0
	 */
	@Override
	public int getWidth() {
		int width = 0;
		for (int i = 0; i < _section_list.size(); i++) {
			IReportSection workSection = _section_list.get(i);
			if (workSection == null) {
				continue;
			}
			width += workSection.getWidth();
		}
		return width;
	}
}
