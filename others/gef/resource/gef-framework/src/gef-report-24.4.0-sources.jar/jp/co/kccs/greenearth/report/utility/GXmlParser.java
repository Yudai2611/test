/*
 * Copyright 2014-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.report.GReportRuntimeException;
import jp.co.kccs.greenearth.report.dao.GDtdEntityResolver;
import jp.co.kccs.greenearth.report.dao.GXmlParseErrorHandler;

/**
 * 【役割】Xml解析を行うクラスです。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】<BR>
 * 
 * @create 2014/11/18
 * @author tou
 * @since 2.0.0
 */
public class GXmlParser {

	/**
	 * 【機能】xmlのドキュメントビルダーを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param publicId 公開識別子
	 * @param entityUrl エンティティURL(DTDのURL)
	 * @param urlMappingKey URLマッピングキー
	 * @throws ParserConfigurationException パース例外
	 * @return ドキュメントビルダーオブジェクト
	 * @create 2014/11/18
	 * @author 
	 * @since 2.0.0
	 */
	public static  DocumentBuilder createDocumentBuilder(String publicId, String entityUrl, String urlMappingKey) throws ParserConfigurationException {
		if (publicId == null) {
			throw new GReportRuntimeException("publicId is null.");
		}
		if (entityUrl == null) {
			throw new GReportRuntimeException("entityUrl is null.");
		}
		if (urlMappingKey == null) {
			throw new GReportRuntimeException("urlMappingKey is null.");
		}
		GDtdEntityResolver entityResolver = new GDtdEntityResolver();
		entityResolver.setPublicId(publicId);
		URL url = GFileUtils.getResource(entityUrl);
		if (url == null) {
			throw new GReportRuntimeException(entityUrl + " is not find.");
		}
		entityResolver.setEntityUrl(GFileUtils.getResource(entityUrl).toString());
		entityResolver.setUrlMappingKey(urlMappingKey);
		return createDocumentBuilder(entityResolver);
	}
	
	/**
	 * 【機能】xmlのドキュメントビルダーを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param entity_resolver DTD定義の設定
	 * @throws ParserConfigurationException パース例外
	 * @return ドキュメントビルダーオブジェクト
	 * @create 2014/11/18
	 * @author 
	 * @since 2.0.0
	 */
	public static  DocumentBuilder createDocumentBuilder(GDtdEntityResolver entity_resolver) throws ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		GXmlParseErrorHandler errHdr = new GXmlParseErrorHandler();
		builder.setErrorHandler(errHdr);
		builder.setEntityResolver(entity_resolver);
		return builder;
	}
}
