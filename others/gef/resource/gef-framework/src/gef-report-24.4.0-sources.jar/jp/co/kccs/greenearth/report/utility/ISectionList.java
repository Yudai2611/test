/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.report.utility;

import jp.co.kccs.greenearth.report.IReportSection;

/**
 * 【役割】セクションリストを表します。<BR>
 * 【生成】<BR>
 * 【解放】<BR>
 * 【備考】複数のセクションを一つのセクションとして扱うことが出来ます。<BR>
 * 
 * @create 2014/09/29
 * @author yamashita
 * @since 2.0.0
 */
public interface ISectionList {

	/**
	 * 【機能】セクションをリストに追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param section セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void add(IReportSection section);

	/**
	 * 【機能】セクションをリストに追加します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param index インデックス
	 * @param section セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void add(int index, IReportSection section);

	/**
	 * 【機能】リストをクリアします。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void clear();

	/**
	 * 【機能】リストからインデックス指定でセクションを取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param index インデックス
	 * @return セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportSection get(int index);

	/**
	 * 【機能】リストからインデックス指定でセクションを削除します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param index インデックス
	 * @return セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportSection remove(int index);

	/**
	 * 【機能】リストの指定インデックスにセクションを設定します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param index インデックス
	 * @param section セクション
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	void set(int index, IReportSection section);

	/**
	 * 【機能】リスト内の要素数を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return 要素数
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int size();

	/**
	 * 【機能】リスト内のすべての要素を適切な順序で格納しているセクション配列を返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @return セクション配列
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	IReportSection[] toArray();

	/**
	 * 【機能】指定セクションがリスト内で最初に検出された位置のインデックスを返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param section セクション
	 * @return int
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int indexOf(IReportSection section);

	/**
	 * 【機能】指定セクションがリスト内で最後に検出された位置のインデックスを返します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】<BR>
	 * 
	 * @param section セクション
	 * @return インデックス
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int lastIndexOf(IReportSection section);

	/**
	 * 【機能】リストに含まれるセクションの高さ総合計を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】保持セクションの総合計を返します。<BR>
	 * 
	 * @return 高さ
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getHeight();

	/**
	 * 【機能】リストに含まれるセクションの幅総合計を取得します。<BR>
	 * 【呼出】API<BR>
	 * 【備考】保持セクションの総合計を返します。<BR>
	 * 
	 * @return 幅
	 * @create 2014/09/29
	 * @author yamashita
	 * @since 2.0.0
	 */
	int getWidth();
}
