/*
 * Copyright 2011-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.json;

import java.io.Serializable;

import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * JavaScript文字列を生成するクラスです.<br>
 * 
 * このオブジェクトを{@link GJSONObject}に登録すると、
 * JavaScriptのfunctionオブジェクトとしてエンコード/デコード出来ます.<br>
 * 
 * @create 2011/06/08
 * @author hamanaka
 * @since 3.9.0
 */
public class GJSFunction extends GJavaScriptBuilder implements Serializable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1741398036669613777L;

	/**
	 * {@link GJSFunction}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/08
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GJSFunction() {
	}

	/**
	 * {@link GJSFunction}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/08
	 * @param javaScriptStr javascript文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GJSFunction(String javaScriptStr) {
		super.append(javaScriptStr);
	}
	
	/**
	 * このオブジェクトを複製します.<br />
	 * 
	 * @create 2017/06/05
	 * @return 複製したGJSFunctionオブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	@Override
	public Object clone() {
		return (GJSFunction) super.clone();
	}
	
	/**
	 * インスタンスを生成します.<br />
	 * 
	 * @create 2017/06/05
	 * @return GJavaScriptBuilder
	 * @author kikuchi
	 * @since 3.20.0
	 */
	@Override
	protected GJSFunction getInstance() {
		return new GJSFunction();
	}
}
