/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.json;

import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import net.arnx.jsonic.JSON;
import net.arnx.jsonic.JSONHint;

/**
 * {@link GJSFunction}を認知するJSONエンコーダー・デコーダー.<br />
 * {@link GJSON}をデシリアライズする際には、{@link JSON}の「mode」「prettyPrint」を再設定する必要があります。
 * @create 2011/06/08
 * @author hamanaka
 * @since 3.9.0
 */
public class GJSON extends JSON implements Serializable{

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 7951905121393917598L;

	/**
	 * {@link GJSFunction}型をJSONに認識させるために{@link JSONHint}アノテーションを拡張します.<br />
	 * 
	 * {@link JSONHint}アノテーションのserializedメソッドが呼ばれたときにtrueを返すようにします。
	 * 
	 * @create 2011/06/08
	 * @author hamanaka
	 * @since 3.9.0
	 */
	private static class JSONHintHandler implements InvocationHandler {

		/** ターゲット */
		private Object _target;

		/**
		 * {@link GJSON}の新しいインスタンスを初期化します.<br />
		 * 
		 * @create 2011/06/08
		 * @param target ターゲット
		 * @author hamanaka
		 * @since 3.9.0
		 */
		public JSONHintHandler(Object target) {
			this._target = target;
		}

		/**
		 * 指定したプロキシのメソッドを実行します.
		 * 
		 * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object,
		 *      java.lang.reflect.Method, java.lang.Object[])
		 * @create 2011/06/08
		 * @param proxy プロキシ
		 * @param method メソッド
		 * @param args 引数
		 * @return メソッドの戻り値
		 * @throws Throwable invokeしたメソッド内で例外が発生した場合
		 * @author hamanaka
		 * @since 3.9.0
		 */
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			if ("serialized".equals(method.getName())) {
				return true;
			}
			return method.invoke(this._target, args);
		}
	}

	/**
	 * {@link GJSON}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/08
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GJSON() {
		super(Mode.SCRIPT);
		this.setPrettyPrint(false);
	}

	/**
	 * {@link GJSON}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/08
	 * @param maxDepth ネストの深さ
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GJSON(int maxDepth) {
		super(maxDepth);
	}

	/**
	 * {@link GJSON}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/08
	 * @param mode モード
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GJSON(Mode mode) {
		super(mode);
	}

	/**
	 * 指定されたフォーマット対象のオブジェクトの、書式化する前処理を実行します.<br />
	 * 
	 * ここでは{@link GJSFunction}型をJSONに認識させるための処理を行っています。
	 * 
	 * @see net.arnx.jsonic.JSON#preformat(net.arnx.jsonic.JSON.Context,
	 *      java.lang.Object)
	 * @create 2011/06/08
	 * @param context 現在のコンテキスト(JSON)
	 * @param value フォーマット対象のオブジェクト
	 * @return フォーマットされたオブジェクト
	 * @throws Exception 変換に失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected Object preformat(Context context, Object value) throws Exception {
		if (value instanceof GJSFunction) {
			Object hint =
				Proxy.newProxyInstance(GJSON.class.getClassLoader(), new Class[] {JSONHint.class}, new JSONHintHandler(
					context.getHint()));
			Method method = Context.class.getDeclaredMethod("enter", Object.class, JSONHint.class);
			method.setAccessible(true);
			method.invoke(context, null, hint);
		}
		return super.preformat(context, value);
	}

}
