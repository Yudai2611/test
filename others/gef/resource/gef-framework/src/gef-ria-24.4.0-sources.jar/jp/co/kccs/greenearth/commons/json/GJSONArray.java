/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.json;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import net.arnx.jsonic.JSON;
import net.arnx.jsonic.JSON.Mode;

/**
 * JSONにおける配列を表すクラスです.<br />
 * 
 * @create 2011/05/06
 * @author yamashita
 * @since 3.9.0
 */
public class GJSONArray extends ArrayList<Object> {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 6696855007368189859L;

	static {
		JSON.prototype = GJSON.class;
	}

	/**
	 * {@link GJSONArray}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/06
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONArray() {
	}

	/**
	 * {@link GJSONArray}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/06
	 * @param array json文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONArray(List<Object> array) {
		if (array != null) {
			this.addAll(array);
		}
	}

	/**
	 * {@link GJSONArray}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/06
	 * @param array json文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	@SuppressWarnings("unchecked")
	public GJSONArray(String array) {
		if (!GStringUtils.isEmpty(array)) {
			GJSON j = new GJSON(Mode.TRADITIONAL);
			Object value = j.parse(array);
			if (value instanceof List) {
				this.addAll((List<Object>) value);
			} else {
				this.add(value);
			}
		}
	}

	/**
	 * JSONデータを取得します.<br />
	 * 
	 * @create 2011/05/06
	 * @return JSONデータ(配列)
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String encode() {
		return GJSON.encode(this);
	}

	/**
	 * JSONデータの文字列を取得します.<br />
	 * 
	 * @create 2011/05/16
	 * @return JSONデータ(配列)
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<String> getStringArray() {
		List<String> array = new ArrayList<String>();
		for (Object o : this) {
			array.add(JSON.encode(o));
		}
		return array;
	}
}
