/*
 * Copyright 2011-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.commons.json;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import net.arnx.jsonic.JSON;
import net.arnx.jsonic.JSON.Mode;

/**
 * JSONにおけるオブジェクトを表すクラスです.<br />
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
public class GJSONObject extends HashMap<String, Object> {

	/** 関数を表すプレースホルダのキー. */
	static final String FUNCTION_PLACEHOLDER_KEY = "geframe.richview.Options.Function.PlaceHolder";

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3546297392296600390L;

	static {
		JSON.prototype = GJSON.class;
	}

	/**
	 * {@link GJSONObject}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/01
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONObject() {
	}

	/**
	 * {@link GJSONObject}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/01
	 * @param json インスタンス化対象Map
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONObject(Map<String, Object> json) {
		if (json != null) {
			putAll(json);
		}
	}

	/**
	 * {@link GJSONObject}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/01
	 * @param json インスタンス化対象文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	@SuppressWarnings("unchecked")
	public GJSONObject(String json) {
		if (!GStringUtils.isEmpty(json)) {
			GJSON j = new GJSON(Mode.TRADITIONAL);
			putAll(convertObject((Map<String, Object>) j.parse(json)));
		}
	}

	/**
	 * 指定した値(Map)に含まれるプレースホルダを復元します.<br/>
	 * 
	 * @param map 値({Map})
	 * @return 復元後の値({Map})
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected Map<String, Object> convertObject(Map<String, Object> map) {
		for (Map.Entry<String, Object> pair : map.entrySet()) {
			pair.setValue(eval(pair.getValue()));
		}
		return map;
	}

	/**
	 * 指定した値({String})に含まれるプレースホルダを復元します.<br/>
	 * 
	 * @param str 値({String})
	 * @return 復元後の値({String})
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected Object convertString(String str) {
		if (str == null) {
			return null;
		}
		final String ph = GFrameworkUtils.getProperty(FUNCTION_PLACEHOLDER_KEY);
		return str.startsWith(ph) ? new GJSFunction(str.replaceFirst(ph, "")) : str;
	}

	/**
	 * 指定した値に含まれるプレースホルダを復元します.<br/>
	 * 
	 * @param array 値({List})
	 * @return 復元後の値({List})
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected List<Object> convertArray(List<Object> array) {
		for (int i = 0; i < array.size(); i++) {
			Object val = array.get(i);
			array.remove(i);
			array.add(i, eval(val));
		}
		return array;
	}

	/**
	 * 指定した値({Object})に含まれるプレースホルダを復元します.<br/>
	 * 
	 * @param val 値({Object})
	 * @return 復元後の値({Object})
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@SuppressWarnings("unchecked")
	protected Object eval(Object val) {
		Object o = val;
		if (val instanceof String) {
			o = convertString((String) val);
		} else if (val instanceof Map<?, ?>) {
			o = convertObject((Map<String, Object>) val);
		} else if (val instanceof List<?>) {
			o = convertArray((List<Object>) val);
		}
		return o;
	}

	/**
	 * 設定されているプロパティ情報を元にJSONデータを作成します.<br>
	 * 値がnullのものはデータから除外されます。
	 * 
	 * @create 2011/04/14
	 * @return JSONデータ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String encode() {
		return GJSON.encode(this);
	}

	/**
	 * プロパティ値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @param name プロパティキー
	 * @return {@link GJSONArray}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@SuppressWarnings("unchecked")
	public GJSONArray getJSONArray(String name) {
		Object value = get(name);
		if (value instanceof GJSONArray) {
			return (GJSONArray) value;
		} else if (value instanceof List) {
			return new GJSONArray((List<Object>) value);
		}
		return null;
	}

	/**
	 * プロパティ値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @param name プロパティキー
	 * @return {@link GJSONObject}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@SuppressWarnings("unchecked")
	public GJSONObject getJSONObject(String name) {
		Object value = get(name);
		if (value instanceof GJSONObject) {
			return (GJSONObject) value;
		} else if (value instanceof Map) {
			return new GJSONObject((Map<String, Object>) value);
		}
		return null;
	}

	/**
	 * プロパティ値を取得します.<br />
	 * 
	 * @create 2011/09/13
	 * @param name プロパティキー
	 * @return {@link List}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getList(String name) {
		Object value = get(name);
		if (value instanceof List) {
			return (List<Object>) value;
		}
		return null;
	}

	/**
	 * プロパティ値を取得します.<br />
	 * 
	 * @create 2011/09/13
	 * @param name プロパティキー
	 * @return {@link Map}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getMap(String name) {
		Object value = get(name);
		if (value instanceof Map) {
			return (Map<String, Object>) value;
		}
		return null;
	}

	/**
	 * プロパティ値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @param name プロパティ名
	 * @return プロパティ値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getString(String name) {
		Object value = get(name);
		if (value instanceof String) {
			return (String) value;
		}
		return null;
	}

	/**
	 * このコンポーネントにキーに対応する値を登録します.<br />
	 * 
	 * valueがnullの場合は格納しません。
	 * 
	 * @create 2011/05/28
	 * @param key 登録する値のキー
	 * @param value 登録する値
	 * @return 登録する値
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public Object put(String key, Object value) {
		if (value == null) {
			return null;
		}
		return super.put(key, value);
	}
	
	/**
	 * このオブジェクトを複製します.<br />
	 * 
	 * @see java.lang.Object#clone()
	 * @return 複製したGJSONObjectオブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	@Override
	public Object clone() {
		Map<String, Object> clone = cloneMap((Map<String, Object>) this);
		return new GJSONObject(clone);
	}

	/**
	 * 指定したオブジェクトを複製します.<br />
	 * 
	 * @return 複製したオブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	@SuppressWarnings("unchecked")
	private Object clone(Object val) {
		Object o = val;
		if (val instanceof GJSFunction) {
			o = cloneGJSFunction((GJSFunction) val);
		} else if (val instanceof Map<?, ?>) {
			o = cloneMap((Map<String, Object>) val);
		} else if (val instanceof List<?>) {
			o = cloneArray((List<Object>) val);
		}
		return o;
	}
	
	/**
	 * Mapオブジェクトを複製します.<br />
	 * 
	 * @return 複製したMapオブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	private Map<String, Object> cloneMap(Map<String, Object> map) {
		Map<String, Object> clone = new LinkedHashMap<String, Object>();
		if (map instanceof GJSONObject) {
			clone = new GJSONObject();
		}
		for (Map.Entry<String, Object> pair : map.entrySet()) {
			clone.put(pair.getKey(), clone(pair.getValue()));
		}
		return clone;
	}

	/**
	 * Listオブジェクトを複製します.<br />
	 * 
	 * @return 複製したListオブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	private List<Object> cloneArray(List<Object> array) {
		List<Object> clone = new ArrayList<Object>();
		if (array instanceof GJSONArray) {
			clone = new GJSONArray();
		}
		for (int i = 0; i < array.size(); i++) {
			Object val = array.get(i);
			clone.add(i, clone(val));
		}
		return clone;
	}
	
	/**
	 * GJSFunctionオブジェクトを複製します.<br />
	 * 
	 * @return 複製したGJSFunctionオブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	private GJSFunction cloneGJSFunction(GJSFunction jsFunction) {
		return (GJSFunction) jsFunction.clone();
	}
}
