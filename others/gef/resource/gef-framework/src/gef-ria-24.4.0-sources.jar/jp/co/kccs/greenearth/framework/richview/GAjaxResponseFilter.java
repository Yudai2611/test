/*
 * Copyright 2011-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.Locale;
import java.util.UUID;

import jakarta.servlet.FilterConfig;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.view.GJspUtils;
import jp.co.kccs.greenearth.framework.view.GViewResponseFilter;

/**
 * ajax通信時のレスポンスを生成するクラスです.<br/>
 * 
 * @create 2011/04/15
 * @author yamashita
 * @since 3.9.0
 */
public class GAjaxResponseFilter extends GViewResponseFilter {

	/** XMLバージョン. */
	private String _version = "1.0";
	/** JSP→XML変換時の文字エンコードを指定します. */
	private String _encoding = null;
	/** XML→response変換時の文字エンコード. */
	private String _transformerEncoding = null;

	/** レスポンス出力用ライタのバッファサイズ . */
	static final String BUFFER_SIZE_KEY = "geframe.richview.Response.BufferingSize";
	/** JSP→XML変換時の文字エンコーディングキー . */
	static final String ENCODING_KEY = "geframe.richview.Response.Encoding";
	/** XML→response変換時の文字エンコーディングキー. */
	static final String TRANSFORMER_ENCODING_KEY = "geframe.richview.Response.Transformer.Encoding";
	/** システムエラーレンダーキー. */
	static final String SYSTEM_ERROR_RENDER_KEY = "geframe.richview.SystemError.Render.Key";
	/** {@link Log}オブジェクト */
	private static final Log LOGGER = LogFactory.getLog(GAjaxResponseFilter.class);

	/**
	 * {@link GAjaxResponseFilter}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/15
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GAjaxResponseFilter() {
	}

	/**
	 * 初期化パラメータより、エンコード情報を読み取ります.<br />
	 * 
	 * @create 2011/04/15
	 * @param filterConfig フィルタ情報
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);
		_encoding = GFrameworkUtils.getProperty(ENCODING_KEY, System.getProperty("file.encoding"));
		_transformerEncoding = GFrameworkUtils.getProperty(TRANSFORMER_ENCODING_KEY, _encoding);
	}

	/**
	 * エラー時のレスポンスの書き出し処理を行います.<br>
	 * 
	 * @create 2011/06/21
	 * @author yamashita
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param e 例外
	 * @param parameter パラメータ
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @since 3.9.0
	 */
	@Override
	public void writeErrorResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter,
		Throwable e) throws IOException, ServletException {
		StringBuilder builder = new StringBuilder();
		String render = parameter.getValue("render");
		if (render != null) {
			builder.append(render);
			builder.append(",");
		}
		builder.append(GFrameworkUtils.getProperty(SYSTEM_ERROR_RENDER_KEY));
		parameter.setValue("render", builder.toString()); // システムエラー追加
		String exceptionKey = UUID.randomUUID().toString();
		HttpSession session = request.getSession();
		session.setAttribute(exceptionKey, e);
		parameter.setValue(GConstants.EXCEPTION_KEY, exceptionKey);
		writeResponse(request, response, parameter, null, e, GResultData.EXIT_CODE_SYSTEM_ERROR);
	}

	/**
	 * JSPのDOMオブジェクトを生成します.<br/>
	 * 
	 * @create 2011/04/15
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @param e 例外
	 * @param exitCode 終了コード
	 * @return DOMオブジェクト
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws SAXException XML解析に失敗した場合
	 * @throws ParserConfigurationException パーサ生成エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected Document createJSPDom(HttpServletRequest request, HttpServletResponse response, GParameter parameter,
		GResultData resultData, Throwable e, String exitCode) throws ServletException, IOException, SAXException,
		ParserConfigurationException {
		GAjaxServletResponseWrapper responseWrapper = createAjaxServletResponseWrapper(response);
		GWebContext context = GWebContext.getInstance();
		context.setResponse(responseWrapper);
		String backward = parameter.getValue("backward"); // 遷移先を同一画面に固定
		parameter.setValue("forward", backward);
		if (GResultData.EXIT_CODE_SUCCESS.equals(exitCode) || GResultData.EXIT_CODE_VALIDATE_ERROR.equals(exitCode)) {
			super.writeNomalResponse(request, responseWrapper, parameter, resultData);
		} else if (GResultData.EXIT_CODE_SYSTEM_ERROR.equals(exitCode)) {
			loadErrorResponse(request, responseWrapper, e);
		} else {
			throw new ServletException("Given exit-code is not supported. exit-code=" + exitCode);
		}
		context.setResponse((HttpServletResponse) response);
		response.setBufferSize(GFrameworkUtils.getIntProperty(BUFFER_SIZE_KEY, 8192));
		response.setContentType("text/xml; charset=" + getEncoding());
		return responseWrapper.getContentAsDom(getEncoding());
	}

	/**
	 * システムエラーレスポンスをロードします.<br/>
	 * 
	 * @create 2011/05/28
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param e 例外
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void loadErrorResponse(HttpServletRequest request, HttpServletResponse response, Throwable e)
		throws IOException, ServletException {
		String path = getErrorPage(e);
		if (path == null) {
			throw new ServletException(e);
		}
		String exceptionKey = UUID.randomUUID().toString();
		HttpSession session = request.getSession();
		session.setAttribute(exceptionKey, e);
		Locale locale = GFrameworkContext.getInstance().getLocale();
		String localizePath = GJspUtils.getLocalizePath(path, locale, session.getServletContext());
		GStopWatch watch = new GStopWatch();
		watch.start();
		RequestDispatcher dispatcher = request.getRequestDispatcher(localizePath);
		dispatcher.forward(request, response);
		LOGGER.info("Forward Error Page (" + watch.stop() + ") : path=" + localizePath);
	}

	/**
	 * 正常時のレスポンスの書き出し処理を行います.<br>
	 * 
	 * @create 2011/04/15
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void writeNomalResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter,
		GResultData resultData) throws IOException, ServletException {
		if (resultData == null) {
			throw new NullPointerException("ResultData is Null.");
		}
		writeResponse(request, response, parameter, resultData, null, resultData.getExitCode());
	}

	/**
	 * レスポンスの書き出し処理を行います.<br>
	 * 
	 * @create 2011/06/21
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @param e 例外
	 * @param exitCode 終了コード
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void writeResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter,
		GResultData resultData, Throwable e, String exitCode) throws IOException, ServletException {
		GStopWatch watch = new GStopWatch();
		watch.start();
		Document resDom = null;
		try {
			Document jspDom = createJSPDom(request, response, parameter, resultData, e, exitCode);
			resDom = createResponseDom(jspDom, parameter, exitCode);
		} catch (ParserConfigurationException ep) {
			throw new ServletException(ep);
		} catch (SAXException es) {
			throw new ServletException(es);
		} catch (TransformerException et) {
			throw new ServletException(et);
		}
		PrintWriter writer = response.getWriter();
		try {
			if (resDom != null) {
				TransformerFactory factory = TransformerFactory.newInstance();
				Transformer transformer = factory.newTransformer();
				String encoding = null;
				if (resDom.getNodeType() == Node.DOCUMENT_NODE) {
					encoding = ((Document) resDom).getInputEncoding();
				} else {
					encoding = resDom.getOwnerDocument().getInputEncoding();
				}
				if (encoding == null) {
					encoding = getTransformerEncoding();
				}
				transformer.setOutputProperty(OutputKeys.ENCODING, encoding);
				transformer.transform(new DOMSource(resDom), new StreamResult(writer)); // response
																						// flush
			}
			LOGGER.trace("Write Ajax Response (" + watch.stop() + ")");
		} catch (TransformerException et) {
			throw new ServletException(et);
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

	/**
	 * レスポンス用のドキュメントを生成します.<br/>
	 * 
	 * @create 2011/05/28
	 * @return DOMオブジェクト
	 * @throws ParserConfigurationException パーサ生成エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	Document createDocument() throws ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		builder.setEntityResolver(new EntityResolver() {
			public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
				InputSource source = new InputSource(new StringReader(""));
				return source;
			}
		});
		return builder.newDocument();
	}

	/**
	 * ajaxのレンダリング対象のHTMLを生成します.<br/>
	 * 
	 * @create 2011/05/28
	 * @param document xmlドキュメント
	 * @param id レンダリング対象のHTMLエレメントのid属性の値
	 * @param jspDom Documentオブジェクト
	 * @return HTMLエレメント
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws TransformerException 変換処理中に例外が発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	Element createRenderElement(Document document, String id, Document jspDom) throws TransformerException, IOException {
		Element renderElem = document.createElement("render");
		renderElem.setAttribute("element", id);
		Element elem = findElement(jspDom, id);
		if (elem == null) {
			return null;
		}
		Node clone = elem.cloneNode(true);
		document.adoptNode(clone);
		renderElem.appendChild(clone);
		return renderElem;
	}

	/**
	 * レスポンス用のドキュメントを生成します.<br/>
	 * 
	 * @create 2011/05/28
	 * @param jspDom JSP DOM
	 * @param parameter パラメータ
	 * @param exitCode 終了コード
	 * @return DOMオブジェクト
	 * @throws ParserConfigurationException パーサ生成エラーが発生した場合
	 * @throws IOException 入出力エラーが発生した場合
	 * @throws ServletException サーブレットで例外が発生した場合
	 * @throws TransformerException 変換処理中に例外が発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	Document createResponseDom(Document jspDom, GParameter parameter, String exitCode)
		throws ParserConfigurationException, TransformerException, IOException, ServletException {
		String render = GStringUtils.nullToBlank(parameter.getValue("render"));
		LOGGER.trace("Ajax Render Key : \"" + render + "\"");
		if (GStringUtils.isEmpty(render)) {
			return null;
		}
		Document document = createDocument();
		Element rootElem = document.createElement("ajax-response");
		document.appendChild(rootElem);
		Element exitCodeElem = document.createElement("exit-code");
		exitCodeElem.setTextContent(exitCode);
		rootElem.appendChild(exitCodeElem);
		Element onetimeTokenElem = document.createElement("onetime-token");
		Element onetimeTokenOrgElem = findOrgElement(jspDom, GConstants.ONE_TIME_TOKEN_PARAM_KEY);
		Element viewidElem = document.createElement("view-id");
		Element viewidOrgElem = findOrgElement(jspDom, GConstants.VIEWID_KEY);
		onetimeTokenElem.setTextContent(onetimeTokenOrgElem.getAttribute("value"));
		rootElem.appendChild(onetimeTokenElem);
		viewidElem.setTextContent(viewidOrgElem.getAttribute("value"));
		rootElem.appendChild(viewidElem);
		for (String id : render.split(",")) {
			id = id.trim();
			Element renderElem = createRenderElement(document, id, jspDom);
			if (renderElem == null) {
				continue;
			}
			rootElem.appendChild(renderElem);
			Element scriptElem = createRenderElement(document, id + ".script.block", jspDom);
			if (scriptElem == null) {
				continue;
			}
			rootElem.appendChild(scriptElem);
		}
		return document;
	}

	/**
	 * id属性で指定したエレメントを取得します.<br />
	 * 
	 * @create 2011/05/28
	 * @param node ノード
	 * @param id ID
	 * @return HTMLエレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	Element findElement(Node node, String id) {
		if (node.getNodeType() == Node.ELEMENT_NODE) {
			Element elem = (Element) node;
			if (elem.hasAttribute("id")) {
				String attr = elem.getAttribute("id");
				if (id.equals(attr)) {
					return elem;
				}
			}
		}
		if (node.hasChildNodes()) {
			NodeList children = node.getChildNodes();
			int size = children.getLength();
			for (int i = 0; i < size; i++) {
				Element elem = findElement(children.item(i), id);
				if (elem != null) {
					return elem;
				}
			}
		}
		return null;
	}

	/**
	 * レスポンスラッパーを生成します.<br/>
	 * 
	 * @param response レスポンス
	 * @return レスポンスラッパー
	 * @create 2013/04/23
	 * @author KCCS yamashita
	 * @since 3.10.0.E
	 */
	GAjaxServletResponseWrapper createAjaxServletResponseWrapper(HttpServletResponse response) {
		return new GAjaxServletResponseWrapper(response);
	}

	/**
	 * JSP→XML変換時の文字エンコードを取得します.
	 * 
	 * @create 2011/05/28
	 * @return 文字エンコーディング
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getEncoding() {
		return _encoding;
	}

	/**
	 * XML→レスポンス変換時の文字エンコードを取得します.
	 * 
	 * @create 2011/05/28
	 * @return 文字エンコーディング
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getTransformerEncoding() {
		return _transformerEncoding;
	}

	/**
	 * XMLのバージョンを取得します.
	 * 
	 * @create 2011/05/28
	 * @return XMLバージョン
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getVersion() {
		return _version;
	}

	/**
	 * JSP→XML変換時の文字エンコードを指定します.
	 * 
	 * @create 2011/05/28
	 * @param encoding 文字エンコーディング
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEncoding(String encoding) {
		_encoding = encoding;
	}

	/**
	 * XML→レスポンス変換時の文字エンコードを指定します.
	 * 
	 * @create 2011/05/28
	 * @param transformerEncoding 文字エンコーディング
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTransformerEncoding(String transformerEncoding) {
		_transformerEncoding = transformerEncoding;
	}

	/**
	 * XMLのバージョンを指定します.
	 * 
	 * @create 2011/05/28
	 * @param version XMLバージョン
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVersion(String version) {
		_version = version;
	}

	/**
	 * id属性で指定したエレメントを取得します.<br />
	 * 
	 * @create 2016/01/14
	 * @param node ノード
	 * @param id ID
	 * @return HTMLエレメント
	 * @throws ServletException
	 * @author okamoto
	 * @since 3.17.0
	 */
	Element findOrgElement(Node node, String id) throws ServletException {
		Element elem = findElement(node,id);
		if(elem == null){
			throw new ServletException(id + " key is not generated.");
		}
		return elem;
	}
}
