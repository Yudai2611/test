/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;

/**
 * ajax通信時にデータがバイト配列に書き込まれる出力ストリームを実装するクラスです.<br/>
 *
 * @create 2011/04/15
 * @author yamashita
 * @since 3.9.0
 */
public class GAjaxServletOutputStream extends ServletOutputStream {

	// 内部変数
	/** {@link ByteArrayOutputStream}オブジェクト. */
	public ByteArrayOutputStream _out = new ByteArrayOutputStream();

	/**
	 * {@link GAjaxServletOutputStream}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2011/04/15
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GAjaxServletOutputStream() {
	}

	/**
	 * {@link ByteArrayOutputStream}オブジェクトを初期化します.<br/>
	 *
	 * @create 2011/04/15
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void reset() {
		_out.reset();
	}

	/**
	 * {@link ByteArrayOutputStream}オブジェクトのバイト配列を取得します.<br/>
	 *
	 * @create 2011/04/15
	 * @return オブジェクトのバイト配列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public byte[] toByteArray() {
		return _out.toByteArray();
	}

	/**
	 * {@link ByteArrayOutputStream}オブジェクトを文字列に変換します.<br/>
	 *
	 * @create 2011/04/15
	 * @author yamashita
	 * @return オブジェクト文字列
	 * @since 3.9.0
	 */
	@Override
	public String toString() {
		return _out.toString();
	}

	/**
	 * {@link ByteArrayOutputStream}オブジェクトを出力ストリームに書き出します.<br/>
	 *
	 * @create 2011/04/15
	 * @param b 書き出されるバイト文字列
	 * @param len 書き出されるバイト数
     * @param off データの開始位置
	 * @throws IOException 入出力エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		if (b == null) {
			return;
		}
		_out.write(b, off, len);
	}

	/**
	 * {@link ByteArrayOutputStream}オブジェクトを出力ストリームに書き出します.<br/>
	 *
	 * @create 2011/04/15
	 * @param b 書き出されるバイト文字列
	 * @throws IOException 入出力エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void write(int b) throws IOException {
		_out.write(b);
	}

	@Override
	public boolean isReady() {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}

	@Override
	public void setWriteListener(WriteListener writeListener) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
