/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * ajax通信時のレスポンスをラップするクラスです.<br/>
 * 
 * @create 2011/04/15
 * @author yamashita
 * @since 3.9.0
 */
public class GAjaxServletResponseWrapper extends HttpServletResponseWrapper {

	// 内部変数
	/** {@link GAjaxServletOutputStream}オブジェクト. */
	GAjaxServletOutputStream _out = new GAjaxServletOutputStream();
	/** {@link PrintWriter}オブジェクト. */
	PrintWriter _writer = null;
	static final String ENCODING_KEY = "geframe.richview.Response.Encoding";

	/**
	 * {@link GAjaxServletResponseWrapper}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/15
	 * @param response レスポンス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GAjaxServletResponseWrapper(HttpServletResponse response) {
		super(response);
	}

	/**
	 * {@link PrintWriter}オブジェクトをフラッシュします.<br/>
	 * 
	 * @create 2011/04/15
	 * @throws IOException 入出力エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void flushBuffer() throws IOException {
		getWriter().flush();
	}

	/**
	 * {@link PrintWriter}オブジェクトをDOMオブジェクトとして取得します.<br/>
	 * 
	 * @create 2011/04/15
	 * @param encoding エンコード
	 * @return DOMオブジェクト
	 * @throws ParserConfigurationException パーサ生成エラーが発生した場合
	 * @throws SAXException XML解析に失敗した場合
	 * @throws IOException 入出力エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public Document getContentAsDom(String encoding) throws ParserConfigurationException, SAXException, IOException {
		getWriter().flush();
		InputStream stream = new ByteArrayInputStream(_out.toByteArray());
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		dbf.setIgnoringElementContentWhitespace(true);
		dbf.setIgnoringComments(true);
		DocumentBuilder db = dbf.newDocumentBuilder();
		db.setEntityResolver(new EntityResolver() {
			public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
				InputSource source = new InputSource(new StringReader(""));
				return source;
			}
		});
		InputSource in = new InputSource(stream);
		in.setEncoding(encoding);
		return db.parse(in);
	}

	/**
	 * {@link GAjaxServletOutputStream}オブジェクトを取得します.<br/>
	 * 
	 * @create 2011/04/15
	 * @return {@link GAjaxServletOutputStream}オブジェクト
	 * @throws IOException 入出力エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public ServletOutputStream getOutputStream() throws IOException {
		return _out;
	}

	/**
	 * 状態をリセット(初期化)します.<br/>
	 * 
	 * @create 2011/04/15
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		getResponse().reset();
		resetBuffer();
	}

	/**
	 * {@link GAjaxServletOutputStream}オブジェクトの状態をリセット(初期化)します.<br/>
	 * 
	 * @create 2011/04/15
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void resetBuffer() {
		_out.reset();
	}

	/**
	 * {@link PrintWriter}オブジェクトを取得します.<br/>
	 * 
	 * @create 2011/04/15
	 * @return {@link PrintWriter}オブジェクト
	 * @throws IOException 入出力エラーが発生した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public PrintWriter getWriter() throws IOException {
		if (_writer == null) {
			_writer = new PrintWriter(new OutputStreamWriter(_out, GFrameworkUtils.getProperty(ENCODING_KEY, System.getProperty("file.encoding"))));
		}
		return _writer;
	}
}