/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPDiv;

/**
 * イメージを表すUIコンポーネントです.<br />
 * 
 * @create 2011/06/16
 * @author yamashita
 * @since 3.9.0
 */
public class GRCustomIndicator extends GPDiv {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3388918153476379087L;

	// 拡張属性
	/** horizontal属性の値. */
	private String _horizontal = null;
	/** vertical属性の値. */
	private String _vertical = null;

	/**
	 * {@link GRCustomIndicator}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/16
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRCustomIndicator() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GRichUIControlBase#reset()
	 * @create 2011/07/12
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRCustomIndicator control = (GRCustomIndicator) getRepository();
		setVertical(control == null ? null : control.getVertical());
		setHorizontal(control == null ? null : control.getHorizontal());
	}

	/**
	 * horizontal属性の値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 横位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getHorizontal() {
		return _horizontal;
	}

	/**
	 * vertical属性の値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 縦位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getVertical() {
		return _vertical;
	}

	/**
	 * horizontal属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return 横位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isHorizontal() {
		return GBooleanUtils.toBoolean(_horizontal, true);
	}

	/**
	 * vertical属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return 縦位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isVertical() {
		return GBooleanUtils.toBoolean(_vertical, true);
	}

	/**
	 * horizontal属性に値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(boolean horizontal) {
		setHorizontal(String.valueOf(horizontal));
	}

	/**
	 * horizontal属性に値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(String horizontal) {
		_horizontal = horizontal;
	}

	/**
	 * vertical属性の値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(boolean vertical) {
		setVertical(String.valueOf(vertical));
	}

	/**
	 * vertical属性の値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(String vertical) {
		_vertical = vertical;
	}
}
