/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control;

import java.util.Date;

import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;

/**
 * DateウィジェットのUIコンポーネントです.<br />
 * 
 * @create 2011/05/13
 * @author hamanaka
 * @since 3.9.0
 */
public class GRDate extends GRSText implements GFormatControl {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4797960546325569219L;
	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;
	/** appendtext属性の値. */
	private String _appendText = null;
	/** buttontext属性の値. */
	private String _buttonText = null;
	/** currenttext属性の値. */
	private String _currentText = null;
	/** closetext属性の値. */
	private String _closeText = null;

	/**
	 * {@link GRDate}の新しいインスタンスを生成します.<br />
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GRDate() {
	}

	/**
	 * このコントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRDate control = (GRDate) getRepository();
		setFormat(control == null ? null : control.getFormat());
		setLocale(control == null ? null : control.getLocale());
		setAppendtext(control == null ? null : control.getAppendtext());
		setButtontext(control == null ? null : control.getButtontext());
		setCurrenttext(control == null ? null : control.getCurrenttext());
		setClosetext(control == null ? null : control.getClosetext());
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return 書式文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2014/05/28
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.16.0
	 */
	@Override
	public String getValue() {
		Object data = super.getObject();
		if (data instanceof Date) {
			return GUIUtils.formatDateToString((Date) data, _format, GCoreUtils.getLocale(_locale));
		} else {
			return super.getValue();
		}
	}

	/**
	 * appendtext属性の値を取得します.<br />
	 * 
	 * @create 2014/06/24
	 * @return appendTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getAppendtext() {
		return _appendText;
	}

	/**
	 * buttontext属性の値を取得します.<br />
	 * 
	 * @create 2014/06/24
	 * @return buttonTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getButtontext() {
		return _buttonText;
	}

	/**
	 * currenttext属性の値を取得します.<br />
	 * 
	 * @create 2015/06/19
	 * @return currentTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public String getCurrenttext() {
		return _currentText;
	}

	/**
	 * closetext属性の値を取得します.<br />
	 * 
	 * @create 2015/06/19
	 * @return closeTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public String getClosetext() {
		return _closeText;
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param format 書式文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param locale ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * appendtext属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param appendText appnedTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setAppendtext(String appendText) {
		_appendText = appendText;
	}

	/**
	 * buttontext属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param buttonText buttonTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setButtontext(String buttonText) {
		_buttonText = buttonText;
	}
	/**
	 * currenttext属性の値を設定します.<br />
	 * 
	 * @create 2015/06/19
	 * @param currentText currentTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public void setCurrenttext(String currentText) {
		_currentText = currentText;
	}

	/**
	 * closetext属性の値を設定します.<br />
	 * 
	 * @create 2015/06/19
	 * @param closeText closeTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public void setClosetext(String closeText) {
		_closeText = closeText;
	}
}
