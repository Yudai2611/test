/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control;

import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase;

/**
 * 入力可能フィールドであることを示すUIコンポーネントです
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GRFieldControlBase extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1549633335192692965L;
	/** テキストボックスのタイプの定数. */
	public static final String TYPE_FIELD = "field";
	/** ラベルのタイプの定数. */
	public static final String TYPE_LABEL = "label";

	// 拡張属性
	/** fieldType属性の値. */
	private String _fieldType = null;

	/**
	 * {@link GRFieldControlBase}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRFieldControlBase() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * 
	 * @create 2011/04/15
	 * @return 可能:<code>true</code>/不可能:<code>false</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public boolean canFocus() {
		return !TYPE_LABEL.equals(getFieldType()) && super.canFocus();
	}

	/**
	 * このコントロール及び子コントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#reset()
	 * @create 2011/04/11
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRFieldControlBase control = (GRFieldControlBase) getRepository();
		setFieldType(control == null ? null : control.getFieldType());
	}

	/**
	 * fieldType属性の値を取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return フィールドタイプ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFieldType() {
		return _fieldType;
	}

	/**
	 * fieldType属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param fieldType フィールドタイプ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFieldType(String fieldType) {
		_fieldType = fieldType;
	}
}
