/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase;

/**
 * イメージを表すUIコンポーネントです.<br />
 * 
 * @create 2011/05/21
 * @author yamashita
 * @since 3.9.0
 */
public class GRImgIndicator extends GUIControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3134992176459089277L;
	// XHTML属性
	/** alt属性の値. */
	private String _alt = null;
	/** ismap属性の値. */
	private String _ismap = null;
	/** longdesc属性の値. */
	private String _longdesc = null;
	/** src属性の値. */
	private String _src = null;
	/** usemap属性の値. */
	private String _usemap = null;

	// 拡張属性
	/** 横センタリング. */
	private String _horizontal = null;
	/** 縦センタリング. */
	private String _vertical = null;

	/**
	 * {@link GRImgIndicator}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/21
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRImgIndicator() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GRichUIControlBase#reset()
	 * @create 2011/07/12
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRImgIndicator control = (GRImgIndicator) getRepository();
		setAlt(control == null ? null : control.getAlt());
		setIsmap(control == null ? null : control.getIsmap());
		setLongdesc(control == null ? null : control.getLongdesc());
		setSrc(control == null ? null : control.getSrc());
		setUsemap(control == null ? null : control.getUsemap());
		setVertical(control == null ? null : control.getVertical());
		setHorizontal(control == null ? null : control.getHorizontal());
	}

	/**
	 * 横位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 横位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getHorizontal() {
		return _horizontal;
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 縦位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getVertical() {
		return _vertical;
	}

	/**
	 * 横位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return 横位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isHorizontal() {
		return GBooleanUtils.toBoolean(_horizontal, true);
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return 縦位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isVertical() {
		return GBooleanUtils.toBoolean(_vertical, true);
	}

	/**
	 * 横位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(boolean horizontal) {
		setHorizontal(String.valueOf(horizontal));
	}

	/**
	 * 横位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(String horizontal) {
		_horizontal = horizontal;
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(boolean vertical) {
		setVertical(String.valueOf(vertical));
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *        <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(String vertical) {
		_vertical = vertical;
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return alt属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getAlt() {
		return _alt;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getIsmap() {
		return _ismap;
	}

	/**
	 * longdesc属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return longdesc属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getLongdesc() {
		return _longdesc;
	}

	/**
	 * src属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return src属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getSrc() {
		return _src;
	}

	/**
	 * usemap属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return usemap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getUsemap() {
		return _usemap;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public boolean isIsmap() {
		return GBooleanUtils.toBoolean(_ismap, false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param alt alt属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setAlt(String alt) {
		_alt = alt;
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param ismap ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setIsmap(boolean ismap) {
		_ismap = String.valueOf(ismap);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param ismap ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setIsmap(String ismap) {
		_ismap = ismap;
	}

	/**
	 * longdesc属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param longdesc longdesc属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setLongdesc(String longdesc) {
		_longdesc = longdesc;
	}

	/**
	 * src属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param src src属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setSrc(String src) {
		_src = src;
	}

	/**
	 * usemap属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param usemap usemap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setUsemap(String usemap) {
		_usemap = usemap;
	}
}
