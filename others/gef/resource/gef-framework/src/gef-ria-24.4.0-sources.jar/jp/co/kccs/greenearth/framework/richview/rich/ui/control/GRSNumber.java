/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control;

import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;

/**
 * NumberウィジェットのUIコンポーネントです.<br />
 * 
 * @create 2011/04/21
 * @author hamanaka
 * @since 3.9.0
 */
public class GRSNumber extends GRSText implements GFormatControl {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1567174405425939458L;

	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;

	/**
	 * {@link GRSNumber}の新しいインスタンスを生成します.<br />
	 * 
	 * @create 2011/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GRSNumber() {
	}

	/**
	 * このコントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRSNumber control = (GRSNumber) getRepository();
		setFormat(control == null ? null : control.getFormat());
		setLocale(control == null ? null : control.getLocale());
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/04/21
	 * @return 書式文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/04/21
	 * @return ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2014/05/28
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.16.0
	 */
	@Override
	public String getValue() {
		Object object = super.getObject();
		if (object instanceof Number) {
			return GUIUtils.formatNumberToString((Number) object, _format, GCoreUtils.getLocale(_locale));
		} else {
			return super.getValue();
		}
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2011/04/21
	 * @param format 書式文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/04/21
	 * @param locale ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}
}
