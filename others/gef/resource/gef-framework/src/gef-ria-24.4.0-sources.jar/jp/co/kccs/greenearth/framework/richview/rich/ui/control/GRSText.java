/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * テキストを表すUIコントロールです.<br />
 * 
 * @create 2011/04/04
 * @author yamashita
 * @since 3.9.0
 */
public class GRSText extends GRFieldControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8980010059037340397L;
	// XHTML属性
	/** autocomplete属性の値. */
	private String _autocomplete = null;
	/** maxlength属性の値. */
	private String _maxlength = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** size属性の値. */
	private String _size = null;
	/** value属性の値. */
	private Object _object = null;
	
	/** noFocusOnReadonly属性の値 */
	private String _noFocusOnReadonly = null;

	/**
	 * {@link GRSText}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRSText() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br />
	 * 
	 * @create 2011/04/04
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public boolean canFocus() {
		return super.canFocus() && !isReadonly();
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param data 表示内容
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		setObject(data);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRSText control = (GRSText) getRepository();
		setAutocomplete(control == null ? null : control.getAutocomplete());
		setMaxlength(control == null ? null : control.getMaxlength());
		setReadonly(control == null ? null : control.getReadonly());
		setSize(control == null ? null : control.getSize());
		setValue(control == null ? null : control.getValue());
		setNoFocusOnReadonly(control == null ? null : control.getNoFocusOnReadonly());
	}

	/**
	 * autocomplete属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * maxlength属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMaxlength() {
		return _maxlength;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * size属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		return _object == null ? null : _object.toString();
	}

	/**
	 * value属性の値をObjectで取得します.<br />
	 * 
	 * @create 2014/05/28
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.16.0
	 */
	public Object getObject() {
		return _object;
	}

	/**
	 * autocomplete属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isAutocomplete() {
		if (_autocomplete == null) {
			return true;
		}
		return !"off".equals(_autocomplete.toLowerCase());
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param autocomplete autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAutocomplete(boolean autocomplete) {
		_autocomplete = autocomplete ? "on" : "off";
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param autocomplete autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * maxlength属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param length maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMaxlength(String length) {
		_maxlength = length;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param readonly readonly属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * size属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param size size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		setObject(value);
	}

	/**
	 * value属性の値をObjectで設定します.<br />
	 * 
	 * @create 2014/05/28
	 * @param value value属性の値
	 * @author hashimoto
	 * @since 3.16.0
	 */
	public void setObject(Object value) {
		_object = value;
	}
	
	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 * 
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}
}
