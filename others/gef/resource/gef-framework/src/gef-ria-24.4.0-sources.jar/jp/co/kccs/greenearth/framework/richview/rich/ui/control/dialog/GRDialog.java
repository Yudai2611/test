/*
 * Copyright 2011-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog;

import jp.co.kccs.greenearth.framework.richview.ui.control.GPDiv;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.GErrorContainer;

/**
 * ダイアログを表すUIコントロールです.<br />
 * 
 * @create 2011/04/30
 * @author yamashita
 * @since 3.9.0
 */
public class GRDialog extends GPDiv implements GErrorContainer {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7002470868265119991L;

	// 拡張属性
	/** focus属性の値. */
	private String _focus = null;

	/**
	 * {@link GRDialog}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRDialog() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2014/07/28
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRDialog control = (GRDialog) getRepository();
		setFocus(control == null ? null : control.getFocus());
	}

	/**
	 * focus属性の値を取得します.<br />
	 * 
	 * @create 2014/07/28
	 * @return focus属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getFocus() {
		return _focus;
	}

	/**
	 * focus属性の値を設定します.<br />
	 * 
	 * @create 2014/07/28
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setFocus(String focus) {
		_focus = focus;
	}
}
