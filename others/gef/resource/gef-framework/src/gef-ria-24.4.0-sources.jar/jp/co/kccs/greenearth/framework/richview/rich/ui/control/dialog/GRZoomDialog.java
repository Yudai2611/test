/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog;


/**
 * ズームダイアログを表すUIコントロールです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
public class GRZoomDialog extends GRDialog {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4577067754067887377L;

	/**
	 * {@link GRZoomDialog}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomDialog() {
	}

}
