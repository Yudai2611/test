/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog;

import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;

/**
 * Zoom画面を表示する際に引き渡すパラメータを定義するUIアイテムです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
public class GRZoomParam extends GUIItemBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4258959722748896877L;

	// 拡張属性
	/** element属性の値. */
	private String _element = null;
	/** name属性の値. */
	private String _name = null;
	/** value属性の値. */
	private String _value = null;

	/**
	 * {@link GRZoomParam}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomParam() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/04/11
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		GRZoomParam zoomParam = (GRZoomParam) getRepository();
		setElement(zoomParam == null ? null : zoomParam.getElement());
		setName(zoomParam == null ? null : zoomParam.getName());
		setValue(zoomParam == null ? null : zoomParam.getValue());
	}

	/**
	 * element属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * name属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getName() {
		return _name;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * element属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param element エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * name属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param name name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
