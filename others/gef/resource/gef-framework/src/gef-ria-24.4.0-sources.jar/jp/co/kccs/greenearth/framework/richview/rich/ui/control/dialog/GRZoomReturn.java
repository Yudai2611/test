/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog;

import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;

/**
 * Zoom画面と呼び出し元の画面の間でデータの取得先と格納先を関連付けるキー名とデータの取得先のタグを定義するUIアイテムです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
public class GRZoomReturn extends GUIItemBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7827043822143462383L;

	// 拡張属性
	/** key属性の値. */
	private String _key = null;
	/** element属性の値. */
	private String _element = null;

	/**
	 * {@link GRZoomReturn}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomReturn() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/04/11
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		GRZoomReturn zoomReturn = (GRZoomReturn) getRepository();
		setKey(zoomReturn == null ? null : zoomReturn.getKey());
		setElement(zoomReturn == null ? null : zoomReturn.getElement());
	}

	/**
	 * element属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * key属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return データの取得先と格納先を関連付けるキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getKey() {
		return _key;
	}

	/**
	 * element属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param element エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * key属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param key データの取得先と格納先を関連付けるキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setKey(String key) {
		_key = key;
	}
}
