/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * ズームクローズイベントを表すUIコントロールです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
public class GZoomCloseEvent extends GZoomEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -1347370337090888196L;

	// 内部変数
	/** {@link GRZoomReturn}オブジェクトのリスト. */
	private List<GRZoomReturn> _zoomreturns = new ArrayList<GRZoomReturn>();

	/**
	 * {@link GZoomCloseEvent}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GZoomCloseEvent() {
	}

	/**
	 * {@link GRZoomReturn}オブジェクトのリストに追加します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomreturn {@link GRZoomReturn}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addZoomreturn(GRZoomReturn zoomreturn) {
		_zoomreturns.add(zoomreturn);
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br />
	 * 
	 * @create 2011/07/07
	 * @return 常用のUIコンポーネント（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GZoomCloseEvent createPracticalInstance() throws GViewException {
		GZoomCloseEvent clone = (GZoomCloseEvent) super.createPracticalInstance();
		if (_zoomreturns != null) {
			List<GRZoomReturn> destZoomreturns = new ArrayList<GRZoomReturn>();
			for (GRZoomReturn zoomreturn : _zoomreturns) {
				GRZoomReturn destZoomreturn = (GRZoomReturn) zoomreturn.createPracticalInstance();
				destZoomreturn.setParent(clone);
				destZoomreturns.add(destZoomreturn);
			}
			clone._zoomreturns = destZoomreturns;
		}
		return clone;
	}

	/**
	 * JSP情報を読み込みます.<br />
	 * 
	 * @create 2011/06/10
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * {@link GRZoomReturn}オブジェクトのリストを設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomreturns {@link GRZoomReturn}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZoomreturns(List<GRZoomReturn> zoomreturns) {
		_zoomreturns = zoomreturns;
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @create 2011/06/10
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		try {
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GRZoomReturn.class.isAssignableFrom(clazz)) {
					GRZoomReturn zoomReturn = (GRZoomReturn) clazz.newInstance();
					zoomReturn.loadJspElement((Element) child);
					addZoomreturn(zoomReturn);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * {@link GRZoomReturn}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return {@link GRZoomReturn}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GRZoomReturn> getZoomreturns() {
		return _zoomreturns;
	}
}