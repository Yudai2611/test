/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog;

import jp.co.kccs.greenearth.framework.richview.ui.event.GEventBase;

/**
 * ズームイベントの基底クラスです.<br />
 * 
 * @create 2011/07/07
 * @author yamashita
 * @since 3.9.0
 */
public class GZoomEventBase extends GEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -1790864893488065965L;

	// 拡張属性
	/** element属性の値. */
	private String _element = null;

	/**
	 * {@link GZoomEventBase}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/13
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GZoomEventBase() {
	}

	/**
	 * エレメントのid属性を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * エレメントのid属性を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @param element element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}
}
