/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * ズームオープンイベントを表すUIコントロールです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
public class GZoomOpenEvent extends GZoomEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7377869649406854532L;

	// 内部変数
	/** {@link GRZoomParam}オブジェクトのリスト. */
	private List<GRZoomParam> _zoomparams = new ArrayList<GRZoomParam>();
	/** {@link GRZoomReceive}オブジェクトのリスト. */
	private List<GRZoomReceive> _zoomreceives = new ArrayList<GRZoomReceive>();

	/**
	 * {@link GZoomOpenEvent}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GZoomOpenEvent() {
	}

	/**
	 * {@link GRZoomParam}オブジェクトのリストに追加します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomparam Zoomダイアログを表示する際に引き渡すパラメータ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addZoomparam(GRZoomParam zoomparam) {
		_zoomparams.add(zoomparam);
	}

	/**
	 * {@link GRZoomReceive}オブジェクトのリストに追加します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomparam Zoomウィンドウからデータを受け取るためのKEYと格納先
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addZoomreceive(GRZoomReceive zoomparam) {
		_zoomreceives.add(zoomparam);
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br />
	 * 
	 * @create 2011/07/07
	 * @return 常用のUIコンポーネント（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GZoomOpenEvent createPracticalInstance() throws GViewException {
		GZoomOpenEvent clone = (GZoomOpenEvent) super.createPracticalInstance();
		if (_zoomparams != null) {
			List<GRZoomParam> destZoomparams = new ArrayList<GRZoomParam>();
			for (GRZoomParam zoomparam : _zoomparams) {
				GRZoomParam destZoomparam = (GRZoomParam) zoomparam.createPracticalInstance();
				destZoomparam.setParent(clone);
				destZoomparams.add(destZoomparam);
			}
			clone._zoomparams = destZoomparams;
		}
		if (_zoomreceives != null) {
			List<GRZoomReceive> destZoomreceives = new ArrayList<GRZoomReceive>();
			for (GRZoomReceive zoomreceive : _zoomreceives) {
				GRZoomReceive destZoomreceive = (GRZoomReceive) zoomreceive.createPracticalInstance();
				destZoomreceive.setParent(clone);
				destZoomreceives.add(destZoomreceive);
			}
			clone._zoomreceives = destZoomreceives;
		}
		return clone;
	}

	/**
	 * JSP情報を読み込みます.<br />
	 * 
	 * @create 2011/06/10
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * {@link GRZoomParam}オブジェクトのリストを設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomparams {@link GRZoomParam}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZoomparams(List<GRZoomParam> zoomparams) {
		_zoomparams = zoomparams;
	}

	/**
	 * {@link GRZoomReceive}オブジェクトのリストを設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomreceives {@link GRZoomReceive}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZoomreceives(List<GRZoomReceive> zoomreceives) {
		_zoomreceives = zoomreceives;
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @create 2011/06/10
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		try {
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GRZoomParam.class.isAssignableFrom(clazz)) {
					GRZoomParam zoomParam = (GRZoomParam) clazz.newInstance();
					zoomParam.loadJspElement((Element) child);
					addZoomparam(zoomParam);
				} else if (clazz != null && GRZoomReceive.class.isAssignableFrom(clazz)) {
					GRZoomReceive zoomReceive = (GRZoomReceive) clazz.newInstance();
					zoomReceive.loadJspElement((Element) child);
					addZoomreceive(zoomReceive);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * {@link GRZoomParam}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return {@link GRZoomParam}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GRZoomParam> getZoomparams() {
		return _zoomparams;
	}

	/**
	 * {@link GRZoomReceive}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return {@link GRZoomReceive}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GRZoomReceive> getZoomreceives() {
		return _zoomreceives;
	}
}