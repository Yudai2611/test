/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRDialog;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GPDivTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * ダイアログウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/04/30
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRDialog.class)
public class GRDialogTag extends GPDivTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 2443584696811450132L;
	/** widgetclassの値. */
	public static final String WIDGET_CLASSNAME = "grdialog";

	// 拡張属性
	/** focus属性の値. */
	private String _focus = null;

	/**
	 * {@link GRDialogTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRDialogTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 * 
	 * @create 2014/07/28
	 * @param component レンダリング対象UIコンポーネント
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRDialog ui = (GRDialog) component;
		GRDialog rep = (GRDialog) component.getRepository();
		setFocus(evaluatePlaceholder(ui.getFocus(), getFocus(),
				rep == null ? null : rep.getFocus(), ui));
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * @create 2011/07/18
	 * @param options オプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		setWidgetOptionValue(options, "title", getTitle());
		setWidgetOptionValue(options, "focus", getFocus());
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/04/30
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @create 2011/04/30
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * focus属性の値を取得します.<br />
	 * 
	 * @create 2014/07/28
	 * @return focus属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getFocus() {
		return _focus;
	}

	/**
	 * focus属性の値を設定します.<br />
	 * 
	 * @create 2014/07/28
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setFocus(String focus) {
		_focus = focus;
	}
}
