/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GWidgetActionParamDecoratorBase;

/**
 * ズームダイアログオプションを装飾するクラスです.<br/>
 * 
 * @create 2011/06/10
 * @author yamashita
 * @since 3.9.0
 */
public class GRZoomDialogActionParamDecorator extends GWidgetActionParamDecoratorBase {

	/** アクションパラメータキー. */
	final static String ACTION_PARAM_KEY = "grzoomdialogevent";

	/**
	 * {@link GRZoomDialogActionParamDecorator}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/10
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomDialogActionParamDecorator() {
	}

	/**
	 * アクションパラメータキーを取得します.<br/>
	 * 
	 * @return アクションパラメータのキー
	 * @create 2013/04/19
	 * @author KCCS yamashita
	 * @since 3.10.0.E
	 */
	protected String getActionParamKey() {
		return ACTION_PARAM_KEY;
	}

	/**
	 * ウィジェットクラス名を取得します.<br/>
	 * 
	 * @return ウィジェットクラス名
	 * @create 2013/04/19
	 * @author KCCS yamashita
	 * @since 3.10.0.E
	 */
	protected String getWidgetClassName() {
		return GRZoomDialogTag.WIDGET_CLASSNAME;
	}
}
