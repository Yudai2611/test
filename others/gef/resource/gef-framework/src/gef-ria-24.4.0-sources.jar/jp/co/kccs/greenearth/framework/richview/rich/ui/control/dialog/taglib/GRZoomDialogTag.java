/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRZoomDialog;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * ズームダイアログウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRZoomDialog.class)
public class GRZoomDialogTag extends GRDialogTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7171208685502702203L;
	public static final String OPTIONS_KEY_IS_TRIGGERED_FROM_DIALOG = "isTriggeredFromDialog";
	public static final String OPTIONS_KEY_OPEN_TRIGGER_ELEMENT = "openTriggerElement";
	public static final String OPTIONS_KEY_OPEN_TRIGGER_EVENT_TYPE = "openTriggerEventType";
	
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grzoomdialog";

	/**
	 * {@link GRZoomDialogTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomDialogTag() {
	}

	/**
	 * XHTML文字列を生成します.
	 * 
	 * @create 2014/02/13
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		loadParameter();
		String xhtml = super.createXhtmlString();
		writeScript();
		
		return xhtml;
	};
	
	private void loadParameter() {
		GWebContext ctx = GWebContext.getInstance();
		GParameter parameter = (GParameter) ctx.getRequest().getAttribute(GConstants.PARAMETER_KEY);
		for (String key : parameter.getValuesMap().keySet()) {
			String[] keys = key.split("\\.");
			if (keys.length <= 1) {
				continue;
			}
			if (keys[0].equals(getFullId())) {
				getDecodeOptions().put(keys[1], parameter.getValue(key));
			}
		}
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#reset()
	 * @create 2014/03/28
	 * @author KCCS kikuchi
	 * @since 3.13.0
	 */
	@Override
	public void reset() {
		resetOptions();
		super.reset();
	}
	
	/**
	 * スクリプトを出力します.<br/>
	 * 
	 * @create 2014/02/13
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	protected void writeScript() throws JspException {
		GJSONObject options = getDecodeOptions();
		if (!options.containsKey(OPTIONS_KEY_IS_TRIGGERED_FROM_DIALOG) || !Boolean.parseBoolean(options.getString(OPTIONS_KEY_IS_TRIGGERED_FROM_DIALOG))) {	// ダイアログ上で発火された通信でない場合、何も出力しない
			return;
		}
		if (options.containsKey(OPTIONS_KEY_OPEN_TRIGGER_ELEMENT) && options.containsKey(OPTIONS_KEY_OPEN_TRIGGER_EVENT_TYPE)) {
			GJavaScriptBuilder sb = new GJavaScriptBuilder();
			sb.append("$(function(){setTimeout(function() {$.ge.idSelector(??).trigger(??);}, 0);});", options.getString(OPTIONS_KEY_OPEN_TRIGGER_ELEMENT), options.getString(OPTIONS_KEY_OPEN_TRIGGER_EVENT_TYPE));
			bindScript(sb.toString());	// ダイアログ上で発火された通信の場合、リクエスト前のダイアログ状態に復元するためのスクリプトを出力する（厳密には、ダイアログオープンをクライアント側で自動実行）
		}
	}

	/**
	 * オプションをリセットします.
	 * 
	 * @create 2014/03/28
	 * @author KCCS kikuchi
	 * @since 3.13.0
	 */
	private void resetOptions() {
		GJSONObject options = getDecodeOptions();
		options.remove(OPTIONS_KEY_IS_TRIGGERED_FROM_DIALOG);
		options.remove(OPTIONS_KEY_OPEN_TRIGGER_ELEMENT);
		options.remove(OPTIONS_KEY_OPEN_TRIGGER_EVENT_TYPE);
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}
}
