/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRZoomParam;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * zoomparamタグを表示するタグクラスです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRZoomParam.class)
public class GRZoomParamTag extends GUIItemBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4588551472319049489L;
	// XHTML属性
	/** name属性の値. */
	private String _name = null;
	/** value属性の値. */
	private String _value = null;
	// 拡張属性
	/** element属性の値. */
	private String _element = null;

	/**
	 * {@link GRZoomParamTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomParamTag() {
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/07/07
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		Tag tag = findAncestorWithClass(this, GZoomOpenEventTag.class);
		if (tag == null) {
			throw new JspException("\"GZoomOpenEventTag\" not found.");
		}
		GZoomOpenEventTag parent = (GZoomOpenEventTag) tag;
		GRZoomParam zoomParam = parent.currentZoomparam();
		if (zoomParam != null) {
			load(zoomParam);
			appendScript(parent.getScriptBuilder(), parent.getElement());
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/07/07
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		GRZoomParam ui = (GRZoomParam) component;
		GRZoomParam rep = (GRZoomParam) component.getRepository();
		setName(ui.getName());
		setElement(evaluatePlaceholder(ui.getElement(), getElement(),
				rep == null ? null : rep.getElement(), ui));
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
	}

	/**
	 * 指定されたスクリプトを追加します.<br />
	 * 
	 * $("#dialog").grdialog('addParam', options);
	 * 
	 * @create 2011/07/07
	 * @param scriptBuilder JavaScript文字列のバッファ
	 * @param target ターゲットID
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendScript(GJavaScriptBuilder scriptBuilder, String target) {
		scriptBuilder.append("$.ge.idSelector(??).", target);
		scriptBuilder.append(GRZoomDialogTag.WIDGET_CLASSNAME);
		scriptBuilder.append("('addParam', event, ");
		GJSONObject options = new GJSONObject();
		options.put("name", getName());
		if (getValue() != null) {
			options.put("value", getValue());
		} else {
			options.put("element", getElement());
		}
		scriptBuilder.append(options.encode());
		scriptBuilder.append(");");
	}

	/**
	 * element属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * name属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getName() {
		return _name;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * element属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param element エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * name属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param name name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
