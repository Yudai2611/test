/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRZoomReturn;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * zoomreturnタグを表示するタグクラスです.<br />
 * 
 * @create 2011/05/12
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRZoomReturn.class)
public class GRZoomReturnTag extends GUIItemBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7796246611573822505L;
	// 拡張属性
	/** key属性の値. */
	private String _key;
	/** element属性の値. */
	private String _element;

	/**
	 * {@link GRZoomReturnTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/12
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomReturnTag() {
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/07/07
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		Tag tag = findAncestorWithClass(this, GZoomCloseEventTag.class);
		if (tag == null) {
			throw new JspException("\"GZoomCloseEventTag\" not found.");
		}
		GZoomCloseEventTag parent = (GZoomCloseEventTag) tag;
		GRZoomReturn zoomReturn = parent.currentZoomreturn();
		if (zoomReturn != null) {
			load(zoomReturn);
			appendScript(parent.getScriptBuilder(), parent.getElement());
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/07/07
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		GRZoomReturn ui = (GRZoomReturn) component;
		GRZoomReturn rep = (GRZoomReturn) component.getRepository();
		setKey(evaluatePlaceholder(ui.getKey(), getKey(),
				rep == null ? null : rep.getKey(), ui));
		setElement(evaluatePlaceholder(ui.getElement(), getElement(),
				rep == null ? null : rep.getElement(), ui));
	}

	/**
	 * 指定されたスクリプトを追加します.<br />
	 * 
	 * $("#dialog").grdialog('addParam', options);
	 * 
	 * @create 2011/07/07
	 * @param scriptBuilder JavaScript文字列のバッファ
	 * @param target ターゲットID
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendScript(GJavaScriptBuilder scriptBuilder, String target) {
		scriptBuilder.append("$.ge.idSelector(??).", target);
		scriptBuilder.append(GRZoomDialogTag.WIDGET_CLASSNAME);
		scriptBuilder.append("('addReturn', event, ");
		GJSONObject options = new GJSONObject();
		options.put("key", getKey());
		options.put("element", getElement());
		scriptBuilder.append(options.encode());
		scriptBuilder.append(");");
	}

	/**
	 * element属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * key属性の値を取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return データの取得先と格納先を関連付けるキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getKey() {
		return _key;
	}

	/**
	 * element属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param element エレメントのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * key属性の値を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param key データの取得先と格納先を関連付けるキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setKey(String key) {
		_key = key;
	}
}
