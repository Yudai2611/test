/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import java.util.Iterator;
import java.util.List;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRZoomReturn;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GZoomCloseEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * zoomcloseeventタグを表示するタグクラスです.<br />
 * 
 * @create 2011/05/13
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GZoomCloseEvent.class)
public class GZoomCloseEventTag extends GZoomEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7130545702192888939L;
	/** {@link GRZoomReturn}オブジェクトのリスト. */
	private List<GRZoomReturn> _zoomreturns;
	/** {@link GRZoomReturn}オブジェクトのイテレータ. */
	private Iterator<GRZoomReturn> _zoomreturnsIterator;

	/**
	 * {@link GZoomCloseEventTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/06
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GZoomCloseEventTag() {
	}

	/**
	 * 現在の{@link GRZoomReturn}オブジェクトを取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return 現在の{@link GRZoomReturn}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomReturn currentZoomreturn() {
		if (_zoomreturnsIterator.hasNext()) {
			return _zoomreturnsIterator.next();
		}
		return null;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/04/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		appendCloseScript();
		printScript();
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/04/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を処理します。 
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetEvent();
		if (isVisible()) {
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/05/13
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GZoomCloseEvent ui = (GZoomCloseEvent) component;
		setZoomreturns(ui.getZoomreturns());
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		_zoomreturnsIterator = null;
	}

	/**
	 * ダイアログを閉じるスクリプトを追加します.<br />
	 * 
	 * $("#dialog").grdialog('close');
	 * 
	 * @create 2011/05/13
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendCloseScript() {
		appendScript("$.ge.idSelector(??).", getElement());
		appendScript(GRZoomDialogTag.WIDGET_CLASSNAME);
		appendScript("('close');");
	}

	/**
	 * {@link GRZoomReturn}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return {@link GRZoomReturn}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GRZoomReturn> getZoomreturns() {
		return _zoomreturns;
	}

	/**
	 * {@link GRZoomReturn}オブジェクトのリストを設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomreturns {@link GRZoomReturn}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZoomreturns(List<GRZoomReturn> zoomreturns) {
		_zoomreturns = zoomreturns;
		_zoomreturnsIterator = zoomreturns.iterator();
	}
}