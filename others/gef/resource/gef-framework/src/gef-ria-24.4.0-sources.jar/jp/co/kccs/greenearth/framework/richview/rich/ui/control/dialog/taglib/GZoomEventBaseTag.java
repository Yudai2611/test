/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GZoomEventBase;
import jp.co.kccs.greenearth.framework.richview.ui.event.taglib.GEventBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * ズームイベントの基底クラスです.<br />
 * 
 * @create 2011/07/07
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GZoomEventBaseTag extends GEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5592184255021012324L;

	// 拡張属性
	/** element属性の値. */
	private String _element;

	// 内部変数
	/** JavaScript文字列. */
	private GJavaScriptBuilder _scriptBuilder = new GJavaScriptBuilder();

	/**
	 * {@link GZoomEventBaseTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GZoomEventBaseTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/07/07
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GZoomEventBase ui = (GZoomEventBase) component;
		GZoomEventBase rep = (GZoomEventBase) component.getRepository();
		setElement(evaluatePlaceholder(ui.getElement(), getElement(),
				rep == null ? null : rep.getElement(), ui));
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		_scriptBuilder = null;
	}

	/**
	 * 指定されたスクリプトを追加します.<br />
	 * 
	 * @create 2011/07/07
	 * @param script スクリプト文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendScript(String script) {
		getScriptBuilder().append(script);
	}

	/**
	 * 指定されたスクリプトを追加します.<br />
	 * 
	 * @create 2011/07/07
	 * @param script スクリプト文字列
	 * @param params バインドパラメータ配列
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendScript(String script, String... params) {
		getScriptBuilder().append(script, params);
	}

	/**
	 * JavaScript関数を生成します.<br/>
	 * 
	 * @create 2011/07/07
	 * @return JavaScript関数
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected GJavaScriptBuilder createScript() throws JspException {
		return getScriptBuilder();
	}

	/**
	 * エレメントのid属性を取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected GJavaScriptBuilder getScriptBuilder() {
		if (_scriptBuilder == null) {
			_scriptBuilder = new GJavaScriptBuilder();
		}
		return _scriptBuilder;
	}

	/**
	 * エレメントのid属性を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @return element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * エレメントのid属性を設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param element element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		this._element = element;
	}
}