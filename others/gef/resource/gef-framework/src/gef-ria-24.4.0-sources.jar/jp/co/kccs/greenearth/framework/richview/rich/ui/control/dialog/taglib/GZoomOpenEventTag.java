/*
 * Copyright 2011-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.taglib;

import java.util.Iterator;
import java.util.List;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRZoomParam;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRZoomReceive;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GZoomOpenEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * zoomopeneventタグを表示するタグクラスです.<br />
 * 
 * @create 2011/05/13
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GZoomOpenEvent.class)
public class GZoomOpenEventTag extends GZoomEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6941711759857257862L;
	/** {@link GRZoomParam}オブジェクトのリスト. */
	private List<GRZoomParam> _zoomparams;
	/** {@link GRZoomReceive}オブジェクトのリスト. */
	private List<GRZoomReceive> _zoomreceives;
	/** {@link GRZoomParam}オブジェクトのイテレータ. */
	private Iterator<GRZoomParam> _zoomparamsIterator;
	/** {@link GRZoomReceive}オブジェクトのイテレータ. */
	private Iterator<GRZoomReceive> _zoomreceivesIterator;

	/**
	 * {@link GZoomOpenEventTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GZoomOpenEventTag() {
	}

	/**
	 * 現在の{@link GRZoomParam}オブジェクトを取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return 現在の{@link GRZoomParam}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomParam currentZoomparam() {
		if (_zoomparamsIterator.hasNext()) {
			return _zoomparamsIterator.next();
		}
		return null;
	}

	/**
	 * 現在の{@link GRZoomReceive}オブジェクトを取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return 現在の{@link GRZoomReceive}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRZoomReceive currentZoomreceive() {
		if (_zoomreceivesIterator.hasNext()) {
			return _zoomreceivesIterator.next();
		}
		return null;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/04/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		appendOpenScript();
		printScript();
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/04/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を処理します。 
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetEvent();
		if (isVisible()) {
			appendCloseScript();
			appendClearScript();
			appendCurrentEventScript();
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/05/13
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GZoomOpenEvent ui = (GZoomOpenEvent) component;
		setZoomparams(ui.getZoomparams());
		setZoomreceives(ui.getZoomreceives());
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		_zoomparamsIterator = null;
		_zoomreceivesIterator = null;
	}

	/**
	 * ダイアログを閉じるスクリプトを追加します.<br />
	 * 対象ダイアログが既に開いている場合のみ、クローズ処理を呼び出します。
	 * 
	 * $("#dialog").grzoomdialog('close');
	 * 
	 * @create 2016/01/27
	 * @author kikuchi
	 * @since 3.17.0
	 */
	protected void appendCloseScript() {
		appendScript("if ($.ge.idSelector(??).", getElement());
		appendScript(GRZoomDialogTag.WIDGET_CLASSNAME);
		appendScript("('isOpen')) {$.ge.idSelector(??).", getElement());
		appendScript(GRZoomDialogTag.WIDGET_CLASSNAME);
		appendScript("('close');}");
	}

	/**
	 * ダイアログを初期化するスクリプトを追加します.<br />
	 * 
	 * $("#dialog").grdialog('clear');
	 * 
	 * @create 2011/05/13
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendClearScript() {
		appendScript("$.ge.idSelector(??).", getElement());
		appendScript(GRZoomDialogTag.WIDGET_CLASSNAME);
		appendScript("('clear');");
	}

	/**
	 * 現在のイベントのスクリプトを追加します.<br />
	 * 
	 * $("#dialog").grdialog('currentEvent', event);
	 * 
	 * @create 2011/07/09
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendCurrentEventScript() {
		appendScript("$.ge.idSelector(??).", getElement());
		appendScript(GRZoomDialogTag.WIDGET_CLASSNAME);
		appendScript("('currentEvent', event);");
	}

	/**
	 * ダイアログを表示するスクリプトを追加します.<br />
	 * 
	 * $("#dialog").grdialog('open');
	 * 
	 * @create 2011/05/13
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void appendOpenScript() {
		appendScript("$.ge.idSelector(??).", getElement());
		appendScript(GRZoomDialogTag.WIDGET_CLASSNAME);
		appendScript("('open');");
	}

	/**
	 * {@link GRZoomParam}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return {@link GRZoomParam}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GRZoomParam> getZoomparams() {
		return _zoomparams;
	}

	/**
	 * {@link GRZoomReceive}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/05/12
	 * @return {@link GRZoomReceive}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GRZoomReceive> getZoomreceives() {
		return _zoomreceives;
	}

	/**
	 * {@link GRZoomParam}オブジェクトのリストを設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomparams {@link GRZoomParam}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZoomparams(List<GRZoomParam> zoomparams) {
		_zoomparams = zoomparams;
		_zoomparamsIterator = zoomparams.iterator();
	}

	/**
	 * {@link GRZoomReceive}オブジェクトのリストを設定します.<br />
	 * 
	 * @create 2011/05/12
	 * @param zoomreceives {@link GRZoomReceive}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZoomreceives(List<GRZoomReceive> zoomreceives) {
		_zoomreceives = zoomreceives;
		_zoomreceivesIterator = zoomreceives.iterator();
	}
}
