/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.error;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.GErrorProviderBase;

/**
 * エラーダイアログを表すUIコントロールです.<br />
 * 
 * @create 2011/05/30
 * @author yamashita
 * @since 3.9.0
 */
public class GRErrorDialog extends GErrorProviderBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3178196858602842527L;

	// 拡張属性
	/** errorlabel属性. */
	private String _errorlabel = null;
	/** anchor属性. */
	private String _anchor = null;

	/**
	 * {@link GRErrorDialog}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRErrorDialog() {
		getDecodeStyle().put("display", "none");
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/06/06
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRErrorDialog control = (GRErrorDialog) getRepository();
		setErrorlabel(control == null ? null : control.getErrorlabel());
		setAnchor(control == null ? null : control.getAnchor());
	}

	/**
	 * エラーダイアログへのリンクを取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return errorlabel属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getErrorlabel() {
		return _errorlabel;
	}

	/**
	 * エラーダイアログへのリンクを設定します.<br />
	 * 
	 * @create 2011/06/16
	 * @param errorlabel errorlabel属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setErrorlabel(String errorlabel) {
		_errorlabel = errorlabel;
	}

	/**
	 * Anchor属性の値を取得します.<br/>
	 * 
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public boolean isAnchor() {
		return GBooleanUtils.toBoolean(getAnchor(), true);
	}

	/**
	 * Anchor属性の値を取得します.<br/>
	 * 
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public String getAnchor() {
		return _anchor;
	}
	
	/**
	 * Anchor属性の値を設定します.<br/>s
	 * 
	 * @param anchor <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public void setAnchor(boolean anchor) {
		_anchor = String.valueOf(anchor);
	}

	/**
	 * Anchor属性の値を設定します.<br/>
	 * 
	 * @param anchor <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public void setAnchor(String anchor) {
		_anchor = anchor;
	}
}
