/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.error;

import jp.co.kccs.greenearth.framework.richview.ui.control.error.GErrorProviderBase;

/**
 * エラーラベルを表すUIコントロールです.<br />
 * 
 * @create 2011/06/16
 * @author yamashita
 * @since 3.9.0
 */
public class GRErrorLabel extends GErrorProviderBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 6887438843067840914L;

	// XHTML属性
	/** for属性の値. */
	private String _for = null;

	// 拡張属性
	/** errormsg属性の値. */
	private String _errormsg = null;

	/**
	 * {@link GRErrorLabel}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/16
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRErrorLabel() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/06/16
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRErrorLabel control = (GRErrorLabel) getRepository();
		setFor(control == null ? null : control.getFor());
		setErrormsg(control == null ? null : control.getErrormsg());
	}

	/**
	 * エラーメッセージを取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return errormsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getErrormsg() {
		return _errormsg;
	}

	/**
	 * for属性の値を取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return for属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFor() {
		return _for;
	}

	/**
	 * エラーメッセージを設定します.<br />
	 * 
	 * @create 2011/06/16
	 * @param errormsg errormsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setErrormsg(String errormsg) {
		_errormsg = errormsg;
	}

	/**
	 * for属性の値を設定します.<br />
	 * 
	 * @create 2011/06/16
	 * @param forr for属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFor(String forr) {
		_for = forr;
	}
}
