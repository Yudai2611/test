/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.error;

import jp.co.kccs.greenearth.framework.richview.ui.control.error.GErrorProviderBase;

/**
 * エラーパネルを表すUIコントロールです.<br />
 * 
 * @create 2011/06/06
 * @author yamashita
 * @since 3.9.0
 */
public class GRErrorPanel extends GErrorProviderBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8621578360335715936L;

	/**
	 * {@link GRErrorPanel}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/06
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRErrorPanel() {
	}
}
