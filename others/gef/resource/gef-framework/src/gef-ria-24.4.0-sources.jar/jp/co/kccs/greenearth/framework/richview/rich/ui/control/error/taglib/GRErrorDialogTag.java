/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.error.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.error.GRErrorDialog;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.taglib.GErrorProviderBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * エラーダイアログウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/05/30
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRErrorDialog.class)
public class GRErrorDialogTag extends GErrorProviderBaseTag {

	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grerrordialog";
	/** エラーダイアログブロックのID */
	protected static final String VALIDATE_BLOCK_ID = ".validate-error-block";
	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 2010736148657944877L;

	// 拡張属性
	/** errorlabel属性の値. */
	private String _errorlabel;
	/** anchor属性. */
	private String _anchor = null;

	/**
	 * {@link GRErrorDialogTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRErrorDialogTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/06/06
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		StringBuilder builder = new StringBuilder();
		GTagBuilder divTag = new GTagBuilder("div");
		decorateAttribute(divTag);
		builder.append(divTag.createStartTagString());
		GTagBuilder divBlockTag = new GTagBuilder("div");
		divBlockTag.setAttribute("id", getFullId() + VALIDATE_BLOCK_ID);
		builder.append(divBlockTag.createStartTagString());
		return builder.toString();
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/06/06
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder divBlockTag = new GTagBuilder("div");
			GTagUtils.printOut(pageContext, divBlockTag.createEndTagString());
			GTagBuilder divTag = new GTagBuilder("div");
			GTagUtils.printOut(pageContext, divTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/06/16
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRErrorDialog ui = (GRErrorDialog) component;
		GRErrorDialog rep = (GRErrorDialog) component.getRepository();
		setErrorlabel(evaluatePlaceholder(ui.getErrorlabel(), getErrorlabel(),
				rep == null ? null : rep.getErrorlabel(), component));
		setAnchor(evaluatePlaceholder(ui.getAnchor(), getAnchor(),
				rep == null ? null : rep.getAnchor(), component));
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * @create 2011/06/06
	 * @param options options属性
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		setWidgetOptionValue(options, "title", getTitle());
		setWidgetOptionValue(options, "errorlabel", getErrorlabel());
		setWidgetOptionValue(options, "anchor", isAnchor());
	}

	/**
	 * エラーダイアログへのリンクを取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return errorlabel属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getErrorlabel() {
		return _errorlabel;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/05/30
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @create 2011/05/30
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * エラーダイアログへのリンクを設定します.<br />
	 * 
	 * @create 2011/06/16
	 * @param errorlabel errorlabel属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setErrorlabel(String errorlabel) {
		_errorlabel = errorlabel;
	}

	/**
	 * Anchor属性の値を取得します.<br/>
	 * 
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public boolean isAnchor() {
		return GBooleanUtils.toBoolean(getAnchor(), true);
	}

	/**
	 * Anchor属性の値を取得します.<br/>
	 * 
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public String getAnchor() {
		return _anchor;
	}
	
	/**
	 * Anchor属性の値を設定します.<br/>s
	 * 
	 * @param anchor <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public void setAnchor(boolean anchor) {
		_anchor = String.valueOf(anchor);
	}

	/**
	 * Anchor属性の値を設定します.<br/>
	 * 
	 * @param anchor <code>true:表示</code>/<code>false:非表示</code>
	 * @create 2014/02/26
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public void setAnchor(String anchor) {
		_anchor = anchor;
	}
}
