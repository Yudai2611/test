/*
 * Copyright 2011-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.error.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.error.GRErrorLabel;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.taglib.GErrorProviderBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * エラーラベルウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/06/16
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRErrorLabel.class)
public class GRErrorLabelTag extends GErrorProviderBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3121520071271946993L;
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grerrorlabel";

	// XHTML属性
	/** for属性の値. */
	private String _for = null;

	// 拡張属性
	/** errormsg属性の値. */
	private String _errormsg = null;

	/**
	 * {@link GRErrorLabelTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/16
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRErrorLabelTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/06/16
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("label");
		decorateAttribute(builder);
		return builder.createStartTagString();
	}
	
	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2016/06/01
	 * @author kobayashi
	 * @since 3.18.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
			return SKIP_BODY;
		}
		return SKIP_BODY;
	}



	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/06/16
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder divTag = new GTagBuilder("label");
			GTagUtils.printOut(pageContext, divTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/06/16
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRErrorLabel ui = (GRErrorLabel) component;
		GRErrorLabel rep = (GRErrorLabel) component.getRepository();
		setFor(evaluatePlaceholder(ui.getFor(), getFor(),
				rep == null ? null : rep.getFor(), ui));
		setErrormsg(evaluatePlaceholder(ui.getErrormsg(), getErrormsg(),
				rep == null ? null : rep.getErrormsg(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @create 2011/06/16
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("for", getFor());
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * 
	 * @create 2011/06/16
	 * @param options options属性
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		setWidgetOptionValue(options, "errormsg", getErrormsg());
	}

	/**
	 * エラーメッセージを取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return errormsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getErrormsg() {
		return _errormsg;
	}

	/**
	 * for属性の値を取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return for属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFor() {
		return _for;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * エラーメッセージを設定します.<br />
	 * 
	 * @create 2011/06/16
	 * @param errormsg errormsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setErrormsg(String errormsg) {
		_errormsg = errormsg;
	}

	/**
	 * for属性の値を設定します.<br />
	 * 
	 * @create 2011/06/16
	 * @param forr for属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFor(String forr) {
		_for = forr;
	}
}
