/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.error.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.rich.ui.control.error.GRErrorPanel;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.taglib.GErrorProviderBaseTag;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * エラーパネルウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/05/30
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRErrorPanel.class)
public class GRErrorPanelTag extends GErrorProviderBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1251500154258511715L;
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grerrorpanel";

	/**
	 * {@link GRErrorPanelTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRErrorPanelTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/06/06
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("span");
		super.decorateAttribute(builder);
		return builder.createStartTagString();
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/06/06
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder divTag = new GTagBuilder("span");
			GTagUtils.printOut(pageContext, divTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/05/30
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @create 2011/05/30
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}
}
