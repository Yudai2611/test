/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.systemerror;

import jp.co.kccs.greenearth.framework.richview.ui.control.GPDiv;

/**
 * システムエラーダイアログを表すUIコントロールです.<br />
 * 
 * @create 2011/06/21
 * @author yamashita
 * @since 3.9.0
 */
public class GRSystemErrorDialog extends GPDiv {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3765873410047564483L;

	/**
	 * {@link GRSystemErrorDialog}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/21
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRSystemErrorDialog() {
	}
}
