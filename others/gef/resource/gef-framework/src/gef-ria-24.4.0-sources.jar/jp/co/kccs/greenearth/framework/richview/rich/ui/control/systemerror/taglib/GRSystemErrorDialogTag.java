/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.systemerror.taglib;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.systemerror.GRSystemErrorDialog;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GPDivTag;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * システムエラーダイアログタグを表示するタグクラスです.<br />
 * 
 * @create 2011/06/21
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRSystemErrorDialog.class)
public class GRSystemErrorDialogTag extends GPDivTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1007121954310247169L;
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grsystemerrordialog";

	/**
	 * {@link GRSystemErrorDialogTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/21
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRSystemErrorDialogTag() {
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * @create 2011/06/06
	 * @param options options属性
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		setWidgetOptionValue(options, "title", getTitle());
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}
}
