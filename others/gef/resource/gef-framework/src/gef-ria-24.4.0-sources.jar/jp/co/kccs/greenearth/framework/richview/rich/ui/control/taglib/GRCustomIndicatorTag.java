/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRCustomIndicator;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GPDivTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * カスタムインジケータウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/06/16
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRCustomIndicator.class)
public class GRCustomIndicatorTag extends GPDivTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -8462068750597174654L;
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grcustomindicator";

	// 拡張属性
	/** 横センタリング. */
	private String _horizontal = null;
	/** 縦センタリング. */
	private String _vertical = null;

	/**
	 * {@link GRCustomIndicatorTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/16
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRCustomIndicatorTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/06/30
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRCustomIndicator ui = (GRCustomIndicator) component;
		GRCustomIndicator rep = (GRCustomIndicator) component.getRepository();
		setHorizontal(evaluatePlaceholder(ui.getHorizontal(), getHorizontal(),
				rep == null ? null : rep.getHorizontal(), ui));
		setVertical(evaluatePlaceholder(ui.getVertical(), getVertical(),
				rep == null ? null : rep.getVertical(), ui));
	}

	/**
	 * options属性に値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param options オプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		setWidgetOptionValue(options, "horizontal", isHorizontal());
		setWidgetOptionValue(options, "vertical", isVertial());
	}

	/**
	 * horizontal属性の値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 横位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getHorizontal() {
		return _horizontal;
	}

	/**
	 * vertical属性の値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 縦位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getVertical() {
		return _vertical;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @create 2011/06/16
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * horizontal属性の値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 横位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isHorizontal() {
		return GBooleanUtils.toBoolean(getHorizontal(), true);
	}

	/**
	 * vertical属性の値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 縦位置のセンタリングを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isVertial() {
		return GBooleanUtils.toBoolean(getVertical(), true);
	}

	/**
	 * horizontal属性に値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(boolean horizontal) {
		setHorizontal(String.valueOf(horizontal));
	}

	/**
	 * horizontal属性に値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(String horizontal) {
		_horizontal = horizontal;
	}

	/**
	 * vertical属性の値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(boolean vertical) {
		setVertical(String.valueOf(vertical));
	}

	/**
	 * vertical属性の値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(String vertical) {
		_vertical = vertical;
	}
}
