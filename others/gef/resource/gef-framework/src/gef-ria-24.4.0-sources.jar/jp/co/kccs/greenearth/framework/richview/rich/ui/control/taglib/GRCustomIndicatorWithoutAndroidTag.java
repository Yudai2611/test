/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import jakarta.servlet.http.HttpServletRequest;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRCustomIndicator;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * カスタムインジケータウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/08/23
 * @author kitamura
 * @since 3.9.0
 */
@TargetUIComponent(GRCustomIndicator.class)
public class GRCustomIndicatorWithoutAndroidTag extends GRCustomIndicatorTag {

	/** シリアルバージョンUID */
	private static final long serialVersionUID = 6213274659391844899L;

	/**
	 * {@link GRCustomIndicatorWithoutAndroidTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/08/23
	 * @author kitamura
	 * @since 3.9.0
	 */
	public GRCustomIndicatorWithoutAndroidTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/08/23
	 * @param component レンダリング対象UIコンポーネント
	 * @author kitamura
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);

		// Androidの場合はインジケーターを表示しないように対応
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		String userAgent = GStringUtils.nullToBlank(request.getHeader("User-Agent"));
		if (userAgent.indexOf("Android") != -1 || userAgent.indexOf("Mobile") != -1) {
			setVisible(false);
		}
	}

}
