/*
 * Copyright 2011-2019 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRDate;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * Dateウィジェットを表示するタグクラスです.<br>
 * 
 * @create 2011/05/13
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GRDate.class)
public class GRDateTag extends GRSTextTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6465644048489782992L;
	/** Widgetオプションのformat名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_FORMAT_NAME = "dateFormat";
	/** Widgetオプションのlocale名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_LOCALE_NAME = "locale";
	/** WidgetオプションのappendText名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_APPENDTEXT_NAME = "appendText";
	/** WidgetオプションのbuttonText名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_BUTTONTEXT_NAME = "buttonText";
	/** WidgetオプションのcurrentText名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_CURRENTTEXT_NAME = "currentText";
	/** WidgetオプションのcloseText名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_CLOSETEXT_NAME = "closeText";
	
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grdate";

	/** 変換キーマップ */
	private static Map<String, String> _map = new HashMap<String, String>();
	/** DateFormatプロパティの年記号変換キー */
	private static final String DATE_FORMAT_YEAR_SIGN_CONVERSION_KEY = "yy";

	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;
	/** appendtext属性の値. */
	private String _appendText = null;
	/** buttontext属性の値. */
	private String _buttonText = null;
	/** currenttext属性の値. */
	private String _currentText = null;
	/** closetext属性の値. */
	private String _closeText = null;

	static {
		_map.put(DATE_FORMAT_YEAR_SIGN_CONVERSION_KEY, "y");
	}

	/**
	 * {@link GRDateTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GRDateTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GRSTextTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/05/13
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRDate ui = (GRDate) component;
		GRDate rep = (GRDate) component.getRepository();
		setFormat(evaluatePlaceholder(ui.getFormat(), getFormat(),
				rep == null ? null : rep.getFormat(), ui));
		setLocale(evaluatePlaceholder(ui.getLocale(), getLocale(),
				rep == null ? null : rep.getLocale(), ui));
		setAppendtext(evaluatePlaceholder(ui.getAppendtext(), getAppendtext(),
				rep == null ? null : rep.getAppendtext(), ui));
		setButtontext(evaluatePlaceholder(ui.getButtontext(), getButtontext(),
				rep == null ? null : rep.getButtontext(), ui));
		setCurrenttext(evaluatePlaceholder(ui.getCurrenttext(), getCurrenttext(),
				rep == null ? null : rep.getCurrenttext(), ui));
		setClosetext(evaluatePlaceholder(ui.getClosetext(), getClosetext(),
				rep == null ? null : rep.getClosetext(), ui));
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2013/07/22
	 * @return XHTML文字列
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public String createXhtmlString() {
		StringBuilder builder = new StringBuilder();
		GTagBuilder dateBuilder = new GTagBuilder("input");
		decorateAttribute(dateBuilder);
		builder.append(dateBuilder.createTagString());
		builder.append(createHdnString());
		return builder.toString();
	}
	
	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2013/07/22
	 * @return XHTML文字列
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected String createHdnString() {
		GTagBuilder builder = new GTagBuilder("input");
		builder.setAttribute("type", "hidden");
		builder.setAttribute("id", getFullId() + "_hdn");
		builder.setAttribute("name", getParameterKey());
		builder.setAttribute("value", getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), "false");
		return builder.createTagString();
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @create 2013/07/20
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.removeAttribute("name");
	}
	
	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * @create 2011/06/06
	 * @param options オプション
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		if (!GStringUtils.isEmpty(getFormat())) {
			setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_FORMAT_NAME, getDateFormat());
		}
		if (!GStringUtils.isEmpty(getAppendtext())) {
			setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_APPENDTEXT_NAME, getAppendtext());
		}
		if (!GStringUtils.isEmpty(getButtontext())) {
			setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_BUTTONTEXT_NAME, getButtontext());
		}
		if (!GStringUtils.isEmpty(getCurrenttext())) {
			setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_CURRENTTEXT_NAME, getCurrenttext());
		}
		if (!GStringUtils.isEmpty(getClosetext())) {
			setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_CLOSETEXT_NAME, getClosetext());
		}
		setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_LOCALE_NAME,
			GLocaleUtils.toString(GCoreUtils.getLocale(getLocale()), "-"));
	}

	/**
	 * ウィジェット－タグ間の仕様差異を吸収するための変換機構です.<br/>
	 * 
	 * @param target 対象文字列
	 * @param k 変換キー
	 * @return 変換後文字列
	 * @create 2013/06/10
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected String convert(String target, String k) {
		String v = _map.get(k);
		return GStringUtils.isEmpty(v) ? target : target.replace(k, v);
	}

	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget ui-widget-content ui-corner-all geui-grdate";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-grdate-readonly";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "ui-state-disabled geui-grdate-disabled";

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getDefaultStyleClass() {
		return DEFAULT_STYLECLASS;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getReadonlyStyleClass() {
		return READONLY_STYLECLASS;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getDisabledStyleClass() {
		return DISABLED_STYLECLASS;
	}

	/**
	 * DateFormatプロパティを取得します.<br/>
	 * 
	 * @return
	 * @create 2013/06/10
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected String getDateFormat() {
		return convert(getFormat(), DATE_FORMAT_YEAR_SIGN_CONVERSION_KEY);
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return 書式文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GRSTextTag#getWidgetClassName()
	 * @create 2011/04/26
	 * @return widgetクラス名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2014/05/28
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.9.0
	 */
	@Override
	public String getValue() {
		Object data = super.getObject();
		if (data instanceof Date) {
			return GUIUtils.formatDateToString((Date) data, _format, GCoreUtils.getLocale(_locale));
		} else {
			return super.getValue();
		}
	}

	/**
	 * appendtext属性の値を取得します.<br />
	 * 
	 * @create 2014/06/24
	 * @return appendTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getAppendtext() {
		return _appendText;
	}

	/**
	 * buttontext属性の値を取得します.<br />
	 * 
	 * @create 2014/06/24
	 * @return buttonTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getButtontext() {
		return _buttonText;
	}

	/**
	 * currenttext属性の値を取得します.<br />
	 * 
	 * @create 2015/06/19
	 * @return currentTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public String getCurrenttext() {
		return _currentText;
	}

	/**
	 * closetext属性の値を取得します.<br />
	 * 
	 * @create 2015/06/19
	 * @return closeTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public String getClosetext() {
		return _closeText;
	}

	/**
	 * フォーマットを設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param format 書式文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param locale ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * appendtext属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param appendText appnedTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setAppendtext(String appendText) {
		_appendText = appendText;
	}

	/**
	 * buttontext属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param buttonText buttonTextオプションの値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setButtontext(String buttonText) {
		_buttonText = buttonText;
	}

	/**
	 * currenttext属性の値を設定します.<br />
	 * 
	 * @create 2015/06/19
	 * @param currentText  currentTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public void setCurrenttext(String currentText) {
		this._currentText = currentText;
	}
	
	/**
	 * closetext属性の値を設定します.<br />
	 * 
	 * @create 2015/06/19
	 * @param closeText closeTextオプションの値
	 * @author KCCS nakamura
	 * @since 3.16.0
	 */
	public void setClosetext(String closeText) {
		this._closeText = closeText;
	}
}
