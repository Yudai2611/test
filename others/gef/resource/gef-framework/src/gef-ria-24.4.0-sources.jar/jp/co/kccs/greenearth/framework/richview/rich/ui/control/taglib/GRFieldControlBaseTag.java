/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRFieldControlBase;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * {@link GRFieldControlBase}のレンダリング用カスタムタグを表します.<br />
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GRFieldControlBaseTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4715035228105109660L;
	/** ウィジェットオプションに出力するフィールドタイプのキー. */
	public final static String WIDGET_OPTIONS_KEY_FIELDTYPE = "fieldType";

	// 拡張属性
	/** fieldType属性の値. */
	private String _fieldType;

	/**
	 * {@link GRFieldControlBaseTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/14
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRFieldControlBaseTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/04/14
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRFieldControlBase ui = (GRFieldControlBase) component;
		GRFieldControlBase rep = (GRFieldControlBase) component.getRepository();
		setFieldType(evaluatePlaceholder(ui.getFieldType(), getFieldType(),
				rep == null ? null : rep.getFieldType(), ui));
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * カスタムタグ属性値をXHTMLのghx:options属性に出力する場合、 このメソッドをオーバーライドして処理を追加してください。<br>
	 * 引数optionsにカスタムタグ属性値を追加するとXHTMLに出力されます。<br>
	 * 
	 * @create 2011/06/25
	 * @param options オプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		if (!GStringUtils.isEmpty(getFieldType())) {
			setWidgetOptionValue(options, WIDGET_OPTIONS_KEY_FIELDTYPE, getFieldType());
		}
	}

	/**
	 * fieldType属性の値を取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return フィールドタイプ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFieldType() {
		return _fieldType;
	}

	/**
	 * fieldType属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param fieldType フィールドタイプ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFieldType(String fieldType) {
		_fieldType = fieldType;
	}
}
