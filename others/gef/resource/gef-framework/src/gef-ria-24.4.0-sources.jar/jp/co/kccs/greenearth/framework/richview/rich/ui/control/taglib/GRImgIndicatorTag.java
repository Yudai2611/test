/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRImgIndicator;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * イメージインジケータウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/05/21
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRImgIndicator.class)
public class GRImgIndicatorTag extends GUIControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 389170652434760954L;
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grimgindicator";
	/** デフォルトのイメージ名 */
	public static final String DEFAULT_IMAGE = "/geframe/images/ajax-indicator.gif";
	/** img要素のデフォルトのスタイルシートのクラス名. */
	static final String IMG_DEFAULT_STYLECLASS = "ui-widget geui-grimgindicator-img";

	// XHTML属性
	/** alt属性の値. */
	private String _alt = null;
	/** ismap属性の値. */
	private String _ismap = null;
	/** longdesc属性の値. */
	private String _longdesc = null;
	/** src属性の値. */
	private String _src = null;
	/** usemap属性の値. */
	private String _usemap = null;

	// 拡張属性
	/** 横センタリング. */
	private String _horizontal;
	/** 縦センタリング. */
	private String _vertical;

	/**
	 * {@link GRImgIndicatorTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/21
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRImgIndicatorTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/04/06
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder spanTag = new GTagBuilder("span");
			GTagUtils.printOut(pageContext, spanTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/05/17
	 * @throws JspException タグの書き込みに失敗した場合
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします / {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を処理します。 
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			GTagBuilder spanTag = new GTagBuilder("span");
			super.decorateWidgetAttribute(spanTag);
			spanTag.setAttribute("id", getFullId());
			StringBuilder sb = new StringBuilder();
			sb.append(spanTag.createStartTagString());
			sb.append(createXhtmlString());
			GTagUtils.printOut(pageContext, sb.toString());
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/06/30
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRImgIndicator ui = (GRImgIndicator) component;
		GRImgIndicator rep = (GRImgIndicator) component.getRepository();
		setAlt(evaluatePlaceholder(ui.getAlt(), getAlt(),
				rep == null ? null : rep.getAlt(), ui));
		setIsmap(evaluatePlaceholder(ui.getIsmap(), getIsmap(),
				rep == null ? null : rep.getIsmap(), ui));
		setLongdesc(evaluatePlaceholder(ui.getLongdesc(), getLongdesc(),
				rep == null ? null : rep.getLongdesc(), ui));
		setSrc(evaluatePlaceholder(ui.getSrc(), getSrc(),
				rep == null ? null : rep.getSrc(), ui));
		setUsemap(evaluatePlaceholder(ui.getUsemap(), getUsemap(),
				rep == null ? null : rep.getUsemap(), ui));
		setHorizontal(evaluatePlaceholder(ui.getHorizontal(), getHorizontal(),
				rep == null ? null : rep.getHorizontal(), ui));
		setVertical(evaluatePlaceholder(ui.getVertical(), getVertical(),
				rep == null ? null : rep.getVertical(), ui));
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2014/07/24
	 * @return XHTML文字列
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("img");
		decorateAttribute(builder);
		return builder.createTagString();
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @create 2011/05/21
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("id", getFullId() + "_img");
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		if (getSrc() == null) {
			builder.setAttribute("src", request.getContextPath() + DEFAULT_IMAGE);
		}
		builder.setAttribute("alt", getAlt());
		if (isIsmap()) {
			builder.setAttribute("ismap", "ismap");
		}
		builder.setAttribute("longdesc", getLongdesc());
		builder.setAttribute("src", getSrc());
		builder.setAttribute("usemap", getUsemap());
	}

	/**
	 * 指定されたタグにこのタグのwidget属性を追加します.<br />
	 * 
	 * @create 2011/05/21
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetAttribute(GTagBuilder builder) {
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * @param options オプション
	 * @create 2011/06/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		setWidgetOptionValue(options, "horizontal", isHorizontal());
		setWidgetOptionValue(options, "vertical", isVertial());
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2014/07/24
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(IMG_DEFAULT_STYLECLASS);
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * 横位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 横位置をセンタリング<code>true:する</code>/<code>false:しない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getHorizontal() {
		return _horizontal;
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 縦位置をセンタリング<code>true:する</code>/<code>false:しない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getVertical() {
		return _vertical;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @create 2011/04/26
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#getWidgetNamespace()
	 * @create 2011/04/28
	 * @return widgetネームスペース名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * 横位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 横位置をセンタリング<code>true:する</code>/<code>false:しない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isHorizontal() {
		return GBooleanUtils.toBoolean(getHorizontal(), true);
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を取得します.<br />
	 * 
	 * @create 2011/06/30
	 * @return 縦位置をセンタリング<code>true:する</code>/<code>false:しない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isVertial() {
		return GBooleanUtils.toBoolean(getVertical(), true);
	}

	/**
	 * 横位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(boolean horizontal) {
		setHorizontal(String.valueOf(horizontal));
	}

	/**
	 * 横位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param horizontal 横位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHorizontal(String horizontal) {
		_horizontal = horizontal;
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(boolean vertical) {
		setVertical(String.valueOf(vertical));
	}

	/**
	 * 縦位置をセンタリングするかどうかの値を設定します.<br />
	 * 
	 * @create 2011/06/30
	 * @param vertical 縦位置のセンタリングを<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVertical(String vertical) {
		_vertical = vertical;
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return alt属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getAlt() {
		return _alt;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getIsmap() {
		return _ismap;
	}

	/**
	 * longdesc属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return longdesc属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getLongdesc() {
		return _longdesc;
	}

	/**
	 * src属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return src属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getSrc() {
		return _src;
	}

	/**
	 * usemap属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return usemap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getUsemap() {
		return _usemap;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2014/07/24
	 * @return ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public boolean isIsmap() {
		return GBooleanUtils.toBoolean(_ismap, false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param alt alt属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setAlt(String alt) {
		_alt = alt;
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param ismap ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setIsmap(boolean ismap) {
		_ismap = String.valueOf(ismap);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param ismap ismap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setIsmap(String ismap) {
		_ismap = ismap;
	}

	/**
	 * longdesc属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param longdesc longdesc属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setLongdesc(String longdesc) {
		_longdesc = longdesc;
	}

	/**
	 * src属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param src src属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setSrc(String src) {
		_src = src;
	}

	/**
	 * usemap属性の値を設定します.<br />
	 * 
	 * @create 2014/07/24
	 * @param usemap usemap属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setUsemap(String usemap) {
		_usemap = usemap;
	}
}
