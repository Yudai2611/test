/*
 * Copyright 2011-2019 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRSNumber;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * Numberウィジェットを表示するタグクラスです.<br>
 * 
 * @create 2011/04/21
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GRSNumber.class)
public class GRSNumberTag extends GRSTextTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6017243545493835699L;
	/** Widgetオプションのformat名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_FORMAT_NAME = "format";
	/** Widgetオプションのlocale名 */
	private static final String WIDGET_OPTIONS_ATTRIBUTE_LOCALE_NAME = "locale";
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grsnumber";

	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;

	/**
	 * {@link GRSNumberTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GRSNumberTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GRSTextTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/04/21
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRSNumber ui = (GRSNumber) component;
		GRSNumber rep = (GRSNumber) component.getRepository();
		setFormat(evaluatePlaceholder(ui.getFormat(), getFormat(),
				rep == null ? null : rep.getFormat(), ui));
		setLocale(evaluatePlaceholder(ui.getLocale(), getLocale(),
				rep == null ? null : rep.getLocale(), ui));
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * @create 2011/06/22
	 * @param options オプション
	 * @author kobayashi
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		if (!GStringUtils.isEmpty(this.getFormat())) {
			setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_FORMAT_NAME, getFormat());
		}
		setWidgetOptionValue(options, WIDGET_OPTIONS_ATTRIBUTE_LOCALE_NAME,
			GLocaleUtils.toString(GCoreUtils.getLocale(getLocale()), "-"));
	}

	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget ui-widget-content ui-corner-all geui-grsnumber";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-grsnumber-readonly";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-grsnumber-disabled ui-state-disabled";

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getDefaultStyleClass() {
		return DEFAULT_STYLECLASS;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getReadonlyStyleClass() {
		return READONLY_STYLECLASS;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getDisabledStyleClass() {
		return DISABLED_STYLECLASS;
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/04/21
	 * @return フォーマット
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/04/21
	 * @return ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GRSTextTag#getWidgetClassName()
	 * @create 2011/04/26
	 * @return widgetクラス名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GRSTextTag#getWidgetNamespace()
	 * @create 2011/04/26
	 * @return widgetネームスペース名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2014/05/28
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.9.0
	 */
	@Override
	public String getValue() {
		Object object = super.getObject();
		if (object instanceof Number) {
			return GUIUtils.formatNumberToString((Number) object, _format, GCoreUtils.getLocale(_locale));
		} else {
			return super.getValue();
		}
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2011/04/21
	 * @param format フォーマット
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/04/21
	 * @param locale ロケール
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

}
