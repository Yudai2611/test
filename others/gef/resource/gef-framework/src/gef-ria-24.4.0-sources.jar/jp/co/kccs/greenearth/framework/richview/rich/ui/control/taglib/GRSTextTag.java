/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRSText;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * テキストウィジェットを表示するタグクラスです.<br />
 *
 * @create 2011/04/15
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GRSText.class)
public class GRSTextTag extends GRFieldControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -8023261637135556169L;
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grstext";
	/** Input_typeの値 */
	private static final String INPUT_TYPE = "text";

	// XHTML属性
	/** autocomplete属性の値. */
	private String _autocomplete = null;
	/** maxlength属性の値. */
	private String _maxlength = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** size属性の値. */
	private String _size = null;
	/** value属性の値. */
	private Object _object = null;

	/** noFocusOnReadonly属性の値 */
	private String _noFocusOnReadonly = null;

	/**
	 * {@link GRSTextTag}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2011/04/15
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GRSTextTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 *
	 * @create 2011/04/15
	 * @return XHTML文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		return builder.createTagString();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 *
	 * @create 2011/04/15
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRSText ui = (GRSText) component;
		GRSText rep = (GRSText) component.getRepository();
		setAutocomplete(evaluatePlaceholder(ui.getAutocomplete(), getAutocomplete(),
				rep == null ? null : rep.getAutocomplete(), ui));
		setMaxlength(evaluatePlaceholder(ui.getMaxlength(), getMaxlength(),
				rep == null ? null : rep.getMaxlength(), ui));
		setReadonly(evaluatePlaceholder(ui.getReadonly(), getReadonly(),
				rep == null ? null : rep.getReadonly(), ui));
		setSize(evaluatePlaceholder(ui.getSize(), getSize(),
				rep == null ? null : rep.getSize(), ui));
		setObject(evaluatePlaceholder(ui.getObject(), getObject(),
				rep == null ? null : rep.getValue(), ui));
		setnoFocusOnReadonly(evaluatePlaceholder(ui.getNoFocusOnReadonly(), getNoFocusOnReadonly(),
				rep == null ? null : rep.getNoFocusOnReadonly(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 *
	 * @create 2011/04/15
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("type", INPUT_TYPE);
		builder.setAttribute("autocomplete", getAutocomplete());
		builder.setAttribute("maxlength", getMaxlength());
		builder.setAttribute("size", getSize());
		builder.setAttribute("value", getValue());
		if (isReadonly()) {
			builder.setAttribute("readonly", "readonly");
			if (isNoFocusOnReadonly()) {
				builder.setAttribute("tabindex", "-1");
			}
		}
		if (!isEnabled()) {
			builder.setAttribute("disabled", "disabled");
		}
	}

	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget ui-widget-content ui-corner-all geui-grstext";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-grstext-disabled ui-state-disabled";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-grstext-readonly";

	/**
	 * デフォルトのスタイルクラスを取得します.<br/>
	 *
	 * @return デフォルトのスタイルクラス
	 * @create 2019/03/26
	 * @author yamashita
	 * @since 3.X.X
	 */
	protected String getDefaultStyleClass() {
		return DEFAULT_STYLECLASS;
	}

	/**
	 * 読み取り専用時のスタイルクラスを取得します.<br/>
	 *
	 * @return 読み取り専用時のスタイルクラス
	 * @create 2019/03/26
	 * @author yamashita
	 * @since 3.X.X
	 */
	protected String getReadonlyStyleClass() {
		return READONLY_STYLECLASS;
	}

	/**
	 * 使用不可時のスタイルクラスを取得します.<br/>
	 *
	 * @return 使用不可時のスタイルクラス
	 * @create 2019/03/26
	 * @author yamashita
	 * @since 3.X.X
	 */
	protected String getDisabledStyleClass() {
		return DISABLED_STYLECLASS;
	}

	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(getDefaultStyleClass());
		super.toggleStyleClassAttribute(getReadonlyStyleClass(), isReadonly());
		super.toggleStyleClassAttribute(getDisabledStyleClass(), !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 *
	 * @create 2011/06/25
	 * @param options オプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		if (isReadonly()) {
			setWidgetOptionValue(options, "readonly", true);
		}
	}

	/**
	 * autocomplete属性の値を取得します.<br />
	 *
	 * @create 2011/04/15
	 * @return autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * maxlength属性の値を取得します.<br />
	 *
	 * @create 2011/04/15
	 * @return maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMaxlength() {
		return _maxlength;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 *
	 * @create 2011/04/15
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * size属性の値を取得します.<br />
	 *
	 * @create 2011/04/15
	 * @return size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * value属性の値を取得します.<br />
	 *
	 * @create 2011/04/15
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		return _object == null ? null : _object.toString();
	}

	/**
	 * value属性の値をObjectで取得します.<br />
	 *
	 * @create 2014/05/28
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.9.0
	 */
	public Object getObject() {
		return _object;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 *
	 * @create 2011/04/15
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 *
	 * @create 2011/04/26
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 *
	 * @create 2011/04/15
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 *
	 * @create 2011/05/13
	 * @param autocomplete autocomplete属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setAutocomplete(boolean autocomplete) {
		_autocomplete = autocomplete ? "on" : "off";
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 *
	 * @create 2011/04/15
	 * @param autocomplete autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * maxlength属性の値を設定します.<br />
	 *
	 * @create 2011/04/15
	 * @param length maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMaxlength(String length) {
		_maxlength = length;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 *
	 * @create 2011/04/15
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 *
	 * @create 2011/04/15
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * size属性の値を設定します.<br />
	 *
	 * @create 2011/04/15
	 * @param size size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 *
	 * @create 2011/04/15
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		setObject(value);
	}

	/**
	 * value属性の値をObjectで設定します.<br />
	 *
	 * @create 2014/05/28
	 * @param value value属性の値
	 * @author hashimoto
	 * @since 3.9.0
	 */
	public void setObject(Object value) {
		_object = value;
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 *
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 *
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setnoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 *
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 *
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}
}
