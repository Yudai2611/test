/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib;

import jp.co.kccs.greenearth.commons.json.GJSFunction;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GActionParamDecorator;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GActionParamDecoratorBase;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * ウィジェット専用のアクションパラメータを装飾する規定クラスです.<br/>
 * 
 * @create 2013/04/18
 * @author yamashita
 * @since 3.10.0.E
 */
public abstract class GWidgetActionParamDecoratorBase extends GActionParamDecoratorBase {

	/**
	 * デフォルトコンストラクタ.<br />
	 * 
	 * @create 2013/04/18
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public GWidgetActionParamDecoratorBase() {
	}

	/**
	 * アクションパラメータの装飾を行います.<br/>
	 * 
	 * @create 2013/04/18
	 * @param options アクションパラメータ
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public void decorate(GJSONObject options, GUIComponent component) {
		GJSFunction function = new GJSFunction();
		function.append("function(event, options, $form) {");
		function.append("return $.ge.idSelector(??).", component.getFullId());
		function.append(getWidgetClassName());
		function.append("('");
		function.append(GActionParamDecorator.DEFAULT_CALLBACK_FUNCTION_NAME);
		function.append("', event, options, $form);}");
		options.put(getActionParamKey(), function);
	}
	
	/**
	 * アクションパラメータのキーを取得します.<br/>
	 * 
	 * @return アクションパラメータのキー
	 * @create 2013/04/19
	 * @author KCCS yamashita
	 * @since 3.10.0.E
	 */
	protected abstract String getActionParamKey();

	/**
	 * ウィジェットクラス名を取得します.<br/>
	 * 
	 * @return ウィジェットクラス名
	 * @create 2013/04/19
	 * @author KCCS yamashita
	 * @since 3.10.0.E
	 */
	protected abstract String getWidgetClassName();
}
