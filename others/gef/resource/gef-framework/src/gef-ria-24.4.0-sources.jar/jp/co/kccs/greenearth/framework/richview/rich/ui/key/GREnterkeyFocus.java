/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.key;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;
import jp.co.kccs.greenearth.framework.richview.ui.key.GEnterkeyFocus;

/**
 * EnterkeyFocus制御を表すUIコンポーネントです.<br />
 * 
 * @create 2011/05/07
 * @author hamanaka
 * @since 3.9.0
 */
public class GREnterkeyFocus extends GUIItemBase implements GEnterkeyFocus {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3228384445219777365L;

	// 拡張属性
	/** auto属性の値 */
	private String _auto = null;

	/**
	 * {@link GREnterkeyFocus}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/07
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GREnterkeyFocus() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#reset()
	 * @create 2011/05/07
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GREnterkeyFocus control = (GREnterkeyFocus) getRepository();
		setAuto(control == null ? null : control.getAuto());
	}

	/**
	 * フォーカス移動順を取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return フォーカス移動順を<code>true:自動設定</code>/<code>false:tabindex順で設定</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getAuto() {
		return _auto;
	}

	/**
	 * フォーカス移動順を取得します.<br />
	 * 
	 * @create 2011/05/07
	 * @return フォーカス移動順を<code>true:自動設定</code>/<code>false:tabindex順で設定</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isAuto() {
		return GBooleanUtils.toBoolean(_auto, true);
	}

	/**
	 * フォーカス移動順を設定します.<br />
	 * 
	 * @create 2011/05/07
	 * @param auto フォーカス移動順を<code>true:自動設定</code>/
	 *            <code>false:tabindex順で設定</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setAuto(boolean auto) {
		this._auto = String.valueOf(auto);
	}

	/**
	 * フォーカス移動順を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @param auto フォーカス移動順を<code>true:自動設定</code>/
	 *            <code>false:tabindex順で設定</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setAuto(String auto) {
		this._auto = auto;
	}
}
