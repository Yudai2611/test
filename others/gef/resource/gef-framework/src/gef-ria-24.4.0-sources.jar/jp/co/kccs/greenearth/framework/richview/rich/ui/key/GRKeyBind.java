/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.key;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;
import jp.co.kccs.greenearth.framework.richview.ui.key.GKeyBind;

/**
 * キー制御を表すUIコンポーネントです.<br />
 * 
 * @create 2011/04/08
 * @author hamanaka
 * @since 3.9.0
 */
public class GRKeyBind extends GUIItemBase implements GKeyBind {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3395380966686736087L;

	// 拡張属性
	/** keycode属性の値. */
	private String _keycode = null;
	/** alt属性の値. */
	private String _alt = null;
	/** ctrl属性の値. */
	private String _ctrl = null;
	/** shift属性の値. */
	private String _shift = null;
	/** bubbling属性の値. */
	private String _bubbling = null;
	/** event属性の値. */
	private String _event = null;
	/** func属性の値. */
	private String _func = null;
	/** element属性の値 */
	private String _element = null;

	/**
	 * {@link GRKeyBind}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/08
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GRKeyBind() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#reset()
	 * @create 2011/04/08
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GRKeyBind control = (GRKeyBind) getRepository();
		setKeycode(control == null ? null : control.getKeycode());
		setAlt(control == null ? null : control.getAlt());
		setCtrl(control == null ? null : control.getCtrl());
		setShift(control == null ? null : control.getShift());
		setBubbling(control == null ? null : control.getBubbling());
		setEvent(control == null ? null : control.getEvent());
		setFunc(control == null ? null : control.getFunc());
		setElement(control == null ? null : control.getElement());
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2011/05/25
	 * @return ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getAlt() {
		return _alt;
	}

	/**
	 * bubbling属性の値を取得します.<br />
	 * 
	 * @create 2011/05/07
	 * @return バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *         <code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getBubbling() {
		return this._bubbling;
	}

	/**
	 * ctrl属性の値を取得します.<br />
	 * 
	 * @create 2011/05/25
	 * @return CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getCtrl() {
		return _ctrl;
	}

	/**
	 * イベントを保持する要素のIDを取得します.<br />
	 * 
	 * @create 2011/05/06
	 * @return 要素のid属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * event属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return event属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getEvent() {
		return _event;
	}

	/**
	 * JavaScript関数を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return func属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getFunc() {
		return _func;
	}

	/**
	 * ブラウザのキーコードまたは特殊キーを取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return keycode属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getKeycode() {
		return _keycode;
	}

	/**
	 * shift属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getShift() {
		return _shift;
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isAlt() {
		return GBooleanUtils.toBoolean(_alt, false);
	}

	/**
	 * bubbling属性の値を取得します.<br />
	 * 
	 * @create 2011/05/07
	 * @return バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *         <code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isBubbling() {
		return GBooleanUtils.toBoolean(_bubbling, false);
	}

	/**
	 * ctrl属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isCtrl() {
		return GBooleanUtils.toBoolean(_ctrl, false);
	}

	/**
	 * shift属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isShift() {
		return GBooleanUtils.toBoolean(_shift, false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2011/05/25
	 * @return
	 * @param alt ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setAlt(boolean alt) {
		this._alt = String.valueOf(alt);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param alt ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setAlt(String alt) {
		this._alt = alt;
	}

	/**
	 * bubbling属性の値を設定します.<br />
	 * 
	 * @create 2011/05/07
	 * @param bubbling バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setBubbling(boolean bubbling) {
		this._bubbling = String.valueOf(bubbling);
	}

	/**
	 * bubbling属性の値を設定します.<br />
	 * 
	 * @create 2011/05/25
	 * @param bubbling バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setBubbling(String bubbling) {
		this._bubbling = bubbling;
	}

	/**
	 * ctrl属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param ctrl CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setCtrl(boolean ctrl) {
		this._ctrl = String.valueOf(ctrl);
	}

	/**
	 * ctrl属性の値を設定します.<br />
	 * 
	 * @create 2011/05/25
	 * @param ctrl CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setCtrl(String ctrl) {
		this._ctrl = ctrl;
	}

	/**
	 * イベントを保持する要素のIDを設定します.<br />
	 * 
	 * @create 2011/05/06
	 * @param element 要素のid属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * event属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param event event属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setEvent(String event) {
		this._event = event;
	}

	/**
	 * JavaScript関数を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param func func属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setFunc(String func) {
		this._func = func;
	}

	/**
	 * ブラウザのキーコードまたは特殊キーを設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param keycode keycode属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setKeycode(String keycode) {
		this._keycode = keycode;
	}

	/**
	 * shift属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param shift SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setShift(boolean shift) {
		this._shift = String.valueOf(shift);
	}

	/**
	 * shift属性の値を設定します.<br />
	 * 
	 * @create 2011/05/25
	 * @param shift SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setShift(String shift) {
		this._shift = shift;
	}

}
