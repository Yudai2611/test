/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.key.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.key.GREnterkeyFocus;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag;
import jp.co.kccs.greenearth.framework.richview.ui.key.GEnterkeyFocus;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * エンターキーフォーカスウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/04/08
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GREnterkeyFocus.class)
public class GREnterkeyFocusTag extends GUIItemBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4911591525650844890L;
	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grenterkeyfocus";

	// 拡張属性
	/** フォーカス移動順を自動設定するかどうか。tabindex順で設定する場合false. */
	private String _auto = null;

	/**
	 * {@link GREnterkeyFocusTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/07
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GREnterkeyFocusTag() {
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/04/08
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GRKeyBind}の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetEnterkeyFocus();
		printScript();
		return SKIP_BODY;
	}

	/**
	 * 親タグの情報を取得します.<br />
	 * 
	 * @create 2015/11/17
	 * @return GUIContainerControlBaseTag 親タグの情報
	 * @throws JspException 親要素のコンテナーが見つからないとき
	 * @author nakamura
	 * @since 3.17.0
	 */
	protected GUIContainerControlBaseTag findTargetContainer() throws JspException {
		Tag parent = findAncestorWithClass(this, GUIContainerControlBaseTag.class);
		if (parent == null) {
			throw new JspException("\"GRichUIContainerControlBaseTag\" not found.");
		}
		return (GUIContainerControlBaseTag) parent;
	}
	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * 以下の属性を読み込みます。<br>
	 * ・auto<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/05/07
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GREnterkeyFocus ui = (GREnterkeyFocus) component;
		GREnterkeyFocus rep = (GREnterkeyFocus) component.getRepository();
		setAuto(evaluatePlaceholder(ui.getAuto(), getAuto(),
				rep == null ? null : rep.getAuto(), ui));
	}

	/**
	 * 親タグより、自分がターゲットとするエンターキーフォーカスコントロールを取得し、読み込みます.<br />
	 * 
	 * @throws JspException
	 * @create 2015/11/17
	 * @author nakamura
	 * @since 3.17.0
	 */
	protected void loadTargetEnterkeyFocus() throws JspException{
		GEnterkeyFocus enterkeyFocus = findTargetContainer().getEnterkeyFocus();
		if (enterkeyFocus != null) {
			load(enterkeyFocus);
		}
	}

	/**
	 * キー制御のスクリプトを出力します.<br />
	 * 
	 * @create 2011/05/07
	 * @throws JspException スクリプトの生成に失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void printScript() throws JspException {
		GUIContainerControlBaseTag container = findTargetContainer();
		GJavaScriptBuilder js = new GJavaScriptBuilder();
		js.append("$(function(){$.ge.idSelector(??).", container.getFullId());
		js.append(this.getWidgetClassName());
		js.append("(");
		GJSONObject json = new GJSONObject();
		json.put("auto", this.isAuto());
		js.append(json.encode());
		js.append(");});");
		container.bindScript(js.toString());
	}

	/**
	 * フォーカス移動順を取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return フォーカス移動順を<code>true:自動設定</code>/<code>false:tabindex順で設定</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getAuto() {
		return _auto;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag#getWidgetClassName()
	 * @create 2011/05/06
	 * @return widgetクラス名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#getWidgetNamespace()
	 * @create 2011/05/06
	 * @return widgetネームスペース名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * フォーカス移動順を取得します.<br />
	 * 
	 * @create 2011/05/07
	 * @return フォーカス移動順を<code>true:自動設定</code>/<code>false:tabindex順で設定</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isAuto() {
		return GBooleanUtils.toBoolean(_auto, true);
	}

	/**
	 * フォーカス移動順を設定します.<br />
	 * 
	 * @create 2011/05/07
	 * @param auto フォーカス移動順を<code>true:自動設定</code>/
	 *            <code>false:tabindex順で設定</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setAuto(boolean auto) {
		this._auto = String.valueOf(auto);
	}

	/**
	 * フォーカス移動順を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @param auto フォーカス移動順を<code>true:自動設定</code>/
	 *            <code>false:tabindex順で設定</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setAuto(String auto) {
		this._auto = auto;
	}
}
