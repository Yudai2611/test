/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.rich.ui.key.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.rich.ui.key.GRKeyBind;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag;
import jp.co.kccs.greenearth.framework.richview.ui.key.GKeyBind;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GEventableTag;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * キーバインドウィジェットを表示するタグクラスです.<br />
 * 
 * @create 2011/04/08
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GRKeyBind.class)
public class GRKeyBindTag extends GUIItemBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7799525196830224080L;

	/** widgetclassの値 */
	public static final String WIDGET_CLASSNAME = "grkeybind";

	// 拡張属性
	/** keycode属性の値. */
	private String _keycode = null;
	/** alt属性の値. */
	private String _alt = null;
	/** ctrl属性の値. */
	private String _ctrl = null;
	/** shift属性の値. */
	private String _shift = null;
	/** bubbling属性の値. */
	private String _bubbling = null;
	/** event属性の値. */
	private String _event = null;
	/** func属性の値. */
	private String _func = null;
	/** element属性の値 */
	private String _element = null;

	/**
	 * {@link GRKeyBindTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/08
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GRKeyBindTag() {
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/04/08
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GRKeyBind}の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetKeybind();
		printScript();
		return SKIP_BODY;
	}

	/**
	 * 親タグの情報を取得します.<br />
	 * 
	 * @create 2015/11/17
	 * @return GUIContainerControlBaseTag 親タグの情報
	 * @throws JspException 親要素のコンテナーが見つからないとき
	 * @author nakamura
	 * @since 3.17.0
	 */
	protected GUIContainerControlBaseTag findTargetContainer() throws JspException {
		Tag parent = findAncestorWithClass(this, GUIContainerControlBaseTag.class);
		if (parent == null) {
			throw new JspException("\"GUIContainerControlBaseTag\" not found.");
		}
		return (GUIContainerControlBaseTag) parent;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * 以下の属性を読み込みます。<br>
	 * ・keycode,isAlt,isCtrl,isShift,bubbling,event,element,func<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/04/08
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GRKeyBind ui = (GRKeyBind) component;
		GRKeyBind rep = (GRKeyBind) component.getRepository();
		setKeycode(evaluatePlaceholder(ui.getKeycode(), getKeycode(),
				rep == null ? null : rep.getKeycode(), ui));
		setAlt(evaluatePlaceholder(ui.getAlt(), getAlt(),
				rep == null ? null : rep.getAlt(), ui));
		setCtrl(evaluatePlaceholder(ui.getCtrl(), getCtrl(),
				rep == null ? null : rep.getCtrl(), ui));
		setShift(evaluatePlaceholder(ui.getShift(), getShift(),
				rep == null ? null : rep.getShift(), ui));
		setBubbling(evaluatePlaceholder(ui.getBubbling(), getBubbling(),
				rep == null ? null : rep.getBubbling(), ui));
		setEvent(evaluatePlaceholder(ui.getEvent(), getEvent(),
				rep == null ? null : rep.getEvent(), ui));
		setFunc(evaluatePlaceholder(ui.getFunc(), getFunc(),
				rep == null ? null : rep.getFunc(), ui));
		setElement(evaluatePlaceholder(ui.getElement(), getElement(),
				rep == null ? null : rep.getElement(), ui));
	}

	/**
	 * 親タグより、自分がターゲットとするキーバインドコントロールを取得し、読み込みます.<br />
	 * 
	 * @throws JspException
	 * @create 2015/11/17
	 * @author nakamura
	 * @since 3.17.0
	 */
	protected void loadTargetKeybind() throws JspException{
		GUIContainerControlBaseTag container = findTargetContainer();
		GKeyBind keyBind = container.currentKeyBind();
		if (keyBind != null) {
			load(keyBind);
		}
	}

	/**
	 * キー制御のスクリプトを出力します.<br />
	 * 
	 * @create 2011/04/08
	 * @throws JspException スクリプトの生成に失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void printScript() throws JspException {
		decorateWidgetOptions(getDecodeOptions());
		GEventableTag eventable = getEventableTag();
		eventable.bindScript(createScript());
	}

	/**
	 * ウィジェットオプションを装飾します.
	 * 
	 * @param options オプション
	 * @create 2013/07/05
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		setWidgetOptionValue(options, "keycode", getKeycode());
		setWidgetOptionValue(options, "event", getEvent());
		setWidgetOptionValue(options, "isAlt", isAlt());
		setWidgetOptionValue(options, "isCtrl", isCtrl());
		setWidgetOptionValue(options, "isShift", isShift());
		setWidgetOptionValue(options, "bubbling", isBubbling());
		setWidgetOptionValue(options, "func", getFunc());
		setWidgetOptionValue(options, "element", getElement());
	}

	/**
	 * スクリプトを生成します.
	 * 
	 * @return スクリプト
	 * @throws JspException
	 * @create 2013/07/05
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected String createScript() throws JspException {
		GUIContainerControlBaseTag container = findTargetContainer();
		GJavaScriptBuilder sb = new GJavaScriptBuilder();
		sb.append("$(function(){$.ge.idSelector(??).", container.getFullId());
		sb.append(getWidgetClassName());
		sb.append("(");
		sb.append(getDecodeOptions().encode());
		sb.append(");});");
		return sb.toString();
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getAlt() {
		return _alt;
	}

	/**
	 * bubbling属性の値を取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *         <code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getBubbling() {
		return _bubbling;
	}

	/**
	 * ctrl属性の値を取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getCtrl() {
		return _ctrl;
	}

	/**
	 * イベントを保持する要素のIDを取得します.<br />
	 * 
	 * @create 2011/05/06
	 * @return 要素のid属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * event属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return event属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getEvent() {
		return _event;
	}

	/**
	 * JavaScript関数を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return func属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getFunc() {
		return _func;
	}

	/**
	 * ブラウザのキーコードまたは特殊キーを取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return keycode属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getKeycode() {
		return _keycode;
	}

	/**
	 * shift属性の値を取得します.<br />
	 * 
	 * @create 2011/07/07
	 * @return SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getShift() {
		return _shift;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag#getWidgetClassName()
	 * @create 2011/05/06
	 * @return widgetクラス名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetClassName() {
		return WIDGET_CLASSNAME;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#getWidgetNamespace()
	 * @create 2011/05/06
	 * @return widgetネームスペース名
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getWidgetNamespace() {
		return DEFAULT_WIDGET_NAMESPACE;
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isAlt() {
		return GBooleanUtils.toBoolean(_alt, false);
	}

	/**
	 * bubbling属性の値を取得します.<br />
	 * 
	 * @create 2011/05/07
	 * @return バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *         <code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isBubbling() {
		return GBooleanUtils.toBoolean(_bubbling, false);
	}

	/**
	 * ctrl属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isCtrl() {
		return GBooleanUtils.toBoolean(_ctrl, false);
	}

	/**
	 * shift属性の値を取得します.<br />
	 * 
	 * @create 2011/04/08
	 * @return shift属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isShift() {
		return GBooleanUtils.toBoolean(_shift, false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param alt ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setAlt(boolean alt) {
		this._alt = String.valueOf(alt);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @param alt ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setAlt(String alt) {
		this._alt = alt;
	}

	/**
	 * bubbling属性の値を設定します.<br />
	 * 
	 * @create 2011/05/07
	 * @param bubbling バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setBubbling(boolean bubbling) {
		this._bubbling = String.valueOf(bubbling);
	}

	/**
	 * bubbling属性の値を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @param bubbling バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setBubbling(String bubbling) {
		this._bubbling = bubbling;
	}

	/**
	 * ctrl属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param ctrl CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setCtrl(boolean ctrl) {
		this._ctrl = String.valueOf(ctrl);
	}

	/**
	 * ctrl属性の値を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @param ctrl CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setCtrl(String ctrl) {
		this._ctrl = ctrl;
	}

	/**
	 * イベントを保持する要素のIDを設定します.<br />
	 * 
	 * @create 2011/05/06
	 * @param element 要素のid属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * event属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param event event属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setEvent(String event) {
		this._event = event;
	}

	/**
	 * JavaScript関数を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param func func属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setFunc(String func) {
		this._func = func;
	}

	/**
	 * ブラウザのキーコードまたは特殊キーを設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param keycode keycode属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setKeycode(String keycode) {
		this._keycode = keycode;
	}

	/**
	 * shift属性の値を設定します.<br />
	 * 
	 * @create 2011/04/08
	 * @param shift SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setShift(boolean shift) {
		this._shift = String.valueOf(shift);
	}

	/**
	 * shift属性の値を設定します.<br />
	 * 
	 * @create 2011/07/07
	 * @param shift SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setShift(String shift) {
		this._shift = shift;
	}
}
