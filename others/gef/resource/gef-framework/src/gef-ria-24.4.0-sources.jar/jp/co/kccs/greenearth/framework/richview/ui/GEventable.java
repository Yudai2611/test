/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui;


/**
 * イベントが実行可能かを示すインターフェースです.<br/>
 * 
 * @create 2013/07/24
 * @author yamashita
 * @since 3.12.0
 */
public interface GEventable {
}
