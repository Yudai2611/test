/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * HTMLにおけるStyleを表すクラスです.<br />
 * 
 * @create 2011/04/15
 * @author yamashita
 * @since 3.9.0
 */
public class GStyle implements Cloneable, Serializable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6740603589688606690L;
	/** スタイルマップ. */
	private Map<String, String> _styleMap = new HashMap<String, String>();

	/**
	 * {@link GStyle}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/15
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyle() {
	}

	/**
	 * {@link GStyle}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/01
	 * @param style スタイルのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyle(Map<String, String> style) {
		if (style != null) {
			_styleMap = style;
		}
	}

	/**
	 * {@link GStyle}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/01
	 * @param style スタイルの文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyle(String style) {
		if (style != null) {
			for (String element : style.split(";")) {
				String[] pair = element.split(":");
				if (GStringUtils.isEmpty(pair[0]) || pair.length != 2) { // キーなし／値なし、は出力しない
					continue;
				}
				_styleMap.put(pair[0].trim(), pair[1].trim());
			}
		}
	}

	/**
	 * このStyleオブジェクトを複製します.<br />
	 * 
	 * @see java.lang.Object#clone()
	 * @return 複製したGStyleオブジェクト
	 * @author hamanaka
	 * @since 2011/04/26
	 */
	@Override
	public Object clone() {
		Map<String, String> map = new HashMap<String, String>();
		map.putAll(_styleMap);
		return new GStyle(map);
	}

	/**
	 * GStyleオブジェクトを文字列表現にして返します.<br />
	 * 
	 * @create 2011/04/15
	 * @return GStyleオブジェクトの文字列表現
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String encode() {
		StringBuilder enc = new StringBuilder();
		for (String key : _styleMap.keySet()) {
			String val = _styleMap.get(key);
			if (GStringUtils.isEmpty(val)) {
				continue;
			}
			enc.append(key);
			enc.append(':');
			enc.append(val);
			enc.append(';');
		}
		return enc.toString();
	}

	/**
	 * 引数のオブジェクトのスタイルマップと等しいかを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @param obj オブジェクト
	 * @return <code>true:等しい</code>/<code>false:等しくない</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof GStyle)) {
			return false;
		}
		GStyle style = (GStyle) obj;
		return _styleMap.equals(style._styleMap);
	}

	/**
	 * スタイルを設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param key キー
	 * @param value 値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void put(String key, String value) {
		_styleMap.put(key, value);
	}

	/**
	 * スタイルマップを削除します.<br />
	 * 
	 * @create 2011/04/15
	 * @param key キー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void remove(String key) {
		_styleMap.remove(key);
	}

	/**
	 * スタイルを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @param key キー
	 * @return スタイル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String get(String key) {
		if (_styleMap.containsKey(key)) {
			return _styleMap.get(key);
		}
		return null;
	}

	/**
	 * スタイルマップを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return スタイルマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public Map<String, String> getStyleMap() {
		return _styleMap;
	}

	/**
	 * スタイルマップが空かどうかを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return <code>true:空</code>/<code>false:空でない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isEmpty() {
		return _styleMap.isEmpty();
	}

	/**
	 * スタイルマップを設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param styleMap スタイルマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyleMap(Map<String, String> styleMap) {
		_styleMap = styleMap;
	}
}
