/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * HTMLにおけるStyleClassを表すクラスです.<br />
 * 
 * @create 2011/04/15
 * @author yamashita
 * @since 3.9.0
 */
public class GStyleClass implements Cloneable, Serializable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -1690574930689964197L;
	/** スタイルクラスリスト. */
	private List<String> _styleclass = new ArrayList<String>();
	/** セパレータ */
	private final static String SEPARATE = " ";

	/**
	 * {@link GStyleClass}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/06
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyleClass() {
	}

	/**
	 * {@link GStyleClass}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/01
	 * @param styleclass スタイルのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyleClass(List<String> styleclass) {
		addAll(styleclass);
	}

	/**
	 * {@link GStyleClass}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/01
	 * @param styleclass スタイルの文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyleClass(String styleclass) {
		add(styleclass);
	}

	/**
	 * {@link GStyleClass}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/09/14
	 * @param styleclass スタイルの文字列
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public GStyleClass(String... styleclass) {
		addAll(styleclass);
	}

	/**
	 * スタイルクラスを設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param name キー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void add(String name) {
		if (GStringUtils.isEmpty(name)) {
			return;
		}
		for (String style : GStringUtils.nullToBlank(name).split(SEPARATE)) {
			if (!style.isEmpty() && !contains(style)) {
				_styleclass.add(style);
			}
		}
	}

	/**
	 * 配列で渡されたスタイルクラスを設定します。
	 * 
	 * @create 2015/06/08
	 * @param styleclass スタイルの配列
	 * @author nakamura
	 * @since 3.16.0
	 */
	public void addAll(String... styleclass) {
		if (styleclass == null) {
			return;
		}
		addAll(Arrays.asList(styleclass));
	}

	/**
	 * リストで渡されたスタイルクラスを設定します。
	 * 
	 * @create 2015/06/08
	 * @param styleclass スタイルのリスト
	 * @author nakamura
	 * @since 3.16.0
	 */
	public void addAll(List<String> styleclass) {
		if (styleclass.isEmpty()) {
			return;
		}
		for (String styles : styleclass) {
			add(styles);
		}
	}

	/**
	 * このGStyleClassオブジェクトを複製します.<br />
	 * 
	 * @see java.lang.Object#clone()
	 * @create 2011/04/26
	 * @return 複製したGStyleClassオブジェクト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public Object clone() {
		List<String> list = new ArrayList<String>();
		list.addAll(_styleclass);
		return new GStyleClass(list);
	}

	/**
	 * スタイルクラスが引数のクラスを含むかを取得します.<br />
	 * 
	 * @create 2011/06/24
	 * @param value スタイルクラス
	 * @return スタイルクラスが引数のクラスを<code>true:含む</code>/<code>false:含まない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean contains(String value) {
		return _styleclass.contains(value);
	}

	/**
	 * GStyleClassオブジェクトを文字列表現にして返します.<br />
	 * 
	 * @return GStyleオブジェクトの文字列表現
	 * @create 2011/04/15
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String encode() {
		StringBuilder enc = new StringBuilder();
		for (String val : _styleclass) {
			if (GStringUtils.isEmpty(val)) {
				continue;
			}
			if (enc.length() > 0) {
				enc.append(SEPARATE);
			}
			enc.append(val);
		}
		return enc.toString();
	}

	/**
	 * スタイルクラスを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @param index インデックス
	 * @return スタイルクラス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String get(int index) {
		return _styleclass.get(index);
	}

	/**
	 * スタイルクラスが空かどうかを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return スタイルクラスが空かどうか
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isEmpty() {
		return _styleclass.isEmpty();
	}

	/**
	 * スタイルクラスを削除します.<br />
	 * 
	 * @create 2011/04/15
	 * @param index インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void remove(int index) {
		_styleclass.remove(index);
	}

	/**
	 * スタイルクラスを削除します.<br />
	 * 
	 * @create 2011/06/24
	 * @param value スタイルクラス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void remove(String value) {
		if (GStringUtils.isEmpty(value)) {
			return;
		}
		for (String style : GStringUtils.nullToBlank(value).split(SEPARATE)) {
			if (!style.isEmpty()) {
				_styleclass.remove(style);
			}
		}
	}

	/**
	 * スタイルクラス数を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return スタイルクラス数
	 * @author yamashita
	 * @since 3.9.0
	 */
	public int size() {
		return _styleclass.size();
	}
}
