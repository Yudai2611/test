/*
 * Copyright 2011-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.event.GEvent;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * {@link GUIComponentBase}は{@link GUIComponent}に指定されるデフォルトの振舞いを提供する、
 * UIコンポーネントを実装するための基底クラスです.<br />
 * 
 * {@link GUIComponentBase} クラスは、HTMLコンポーネントとして共通で必要となる属性を兼ね備えています。<br>
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIComponentBase implements GUIComponent, GEventable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -786335947917651347L;
	/** デフォルトロケール. */
	protected static final Locale DEFAULT_LOCALE = new Locale("");
	/** 【UI拡張機能】 noFocusOnReadonlyのデフォルト値. */
	public static final String UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY = "geframe.richview.ui.Default.NoFocusOnReadonly";

	// XHTML属性
	/** id属性の値. */
	private String _id = null;
	/** class属性の値. */
	private GStyleClass _styleclass = null;
	/** style属性の値. */
	private GStyle _style = null;
	/** title属性の値. */
	private String _title = null;
	/** xml:lang属性の値. */
	private String _lang = null;
	/** dir属性の値. */
	private String _dir = null;
	/** xml:space属性の値. */
	private String _space = null;
	/** onclick属性の値. */
	private String _onclick = null;
	/** ondbclick属性の値. */
	private String _ondblclick = null;
	/** onkeydown属性の値. */
	private String _onkeydown = null;
	/** onkeypress属性の値. */
	private String _onkeypress = null;
	/** onkeyup属性の値. */
	private String _onkeyup = null;
	/** onmousedown属性の値. */
	private String _onmousedown = null;
	/** onmousemove属性の値. */
	private String _onmousemove = null;
	/** onmouseout属性の値. */
	private String _onmouseout = null;
	/** onmouseover属性の値. */
	private String _onmouseover = null;
	/** onmouseup属性の値. */
	private String _onmouseup = null;

	// 拡張属性
	/** visible属性の値. */
	private String _visible = null;
	/** options属性の値. */
	private GJSONObject _options = null;

	// 内部変数
	/** 親コンテナコンポーネント. */
	private GUIComponent _parent = null;
	/** リポジトリ(静的情報). */
	private GUIComponent _repository = null;
	/** イベント一覧 */
	private List<GEvent> _events = new ArrayList<GEvent>();
	/** ID接頭語 */
	private String _prefix = null;
	/** リクエストパラメータキーの完全な接頭語 */
	private String _nameprefix = null;
	/** エラー項目の表示名の名前空間 */
	private String _labelspace = null;

	/**
	 * {@link GUIComponentBase}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponentBase() {
	}

	/**
	 * イベントを追加します.<br />
	 * 
	 * @create 2011/06/11
	 * @param event イベント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addEvent(GEvent event) {
		_events.add(event);
		event.setParent(this);
	}

	/**
	 * 画面に表示する項目名の名前空間を組み立てます.<br />
	 * 
	 * @create 2011/05/16
	 * @param components コンポーネントのリスト
	 * @return 項目名の名前空間
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String assembleLabelspace(List<GUIComponent> components) {
		return null;
	}

	/**
	 * コントロールの接頭辞文字列を組み立てます.<br />
	 * 
	 * @create 2011/05/16
	 * @param components コンポーネントのリスト
	 * @return コントロールの接頭辞文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String assemblePrefix(List<GUIComponent> components) {
		return null;
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br />
	 * 
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @create 2011/05/16
	 * @return 常用インスタンス（クローン）
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponent createPracticalInstance() throws GViewException {
		GUIComponentBase component = null;
		try {
			component = (GUIComponentBase) this.clone();
			component.setRepository(this);
		} catch (CloneNotSupportedException e) {
			throw new GViewException(e);
		}
		List<GEvent> destEvents = new ArrayList<GEvent>();
		for (GEvent srcEvent : getEvents()) {
			GEvent destEvent = (GEvent) srcEvent.createPracticalInstance();
			destEvents.add(destEvent);
			destEvent.setParent(component);
		}
		component.setEvents(destEvents);
		component.setStyle((GStyle) this.getDecodeStyle().clone());
		component.setStyleclass((GStyleClass) this.getDecodeStyleclass().clone());
		component.setOptions((GJSONObject) this.getDecodeOptions().clone());
		return component;
	}
	
	/**
	 * JSP情報を読み込みます.<br />
	 * 
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/03/30
	 * @param element 読み込み対象JSPエレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadJspElement(Element element) throws GViewException {
		try {
			GUIUtils.setAttributes(element, this);
			loadNestedNode(element);
		} catch (InvocationTargetException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * このコンポーネントのウィジェットオプションを登録します.<br />
	 * 
	 * @create 2011/05/16
	 * @param key オプションのキー
	 * @param value オプションの値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void putOption(String key, Object value) {
		if (_options == null) {
			_options = new GJSONObject();
		}
		_options.put(key, value);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void reset() {
		GUIComponentBase control = (GUIComponentBase) getRepository();
		setId(control == null ? null : control.getId());
		setDir(control == null ? null : control.getDir());
		setStyle(control == null ? null : control.getStyle());
		setStyleclass(control == null ? null : control.getStyleclass());
		setStyle(control == null ? null : control.getStyle());
		setStyleclass(control == null ? null : control.getStyleclass());
		setLang(control == null ? null : control.getLang());
		setSpace(control == null ? null : control.getSpace());
		setTitle(control == null ? null : control.getTitle());
		setOnclick(control == null ? null : control.getOnclick());
		setOndblclick(control == null ? null : control.getOndblclick());
		setOnkeydown(control == null ? null : control.getOnkeydown());
		setOnkeypress(control == null ? null : control.getOnkeypress());
		setOnkeyup(control == null ? null : control.getOnkeyup());
		setOnmousedown(control == null ? null : control.getOnmousedown());
		setOnmousemove(control == null ? null : control.getOnmousemove());
		setOnmouseout(control == null ? null : control.getOnmouseout());
		setOnmouseover(control == null ? null : control.getOnmouseover());
		setOnmouseup(control == null ? null : control.getOnmouseup());
		setVisible(control == null ? null : control.getVisible());
		setOptions(control == null ? null : control.getDecodeOptions());
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br>
	 * 
	 * @create 2011/05/16
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		try {
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GEvent.class.isAssignableFrom(clazz)) {
					GEvent event = (GEvent) clazz.newInstance();
					event.loadJspElement((Element) child);
					addEvent(event);
				} else if (clazz == null || !GUIComponent.class.isAssignableFrom(clazz)) {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * ウィジェットオプションを取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return ウィジェットオプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONObject getDecodeOptions() {
		if (_options == null) {
			_options = new GJSONObject();
		}
		return _options;
	}

	/**
	 * スタイルを取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return スタイル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyle getDecodeStyle() {
		if (_style == null) {
			_style = new GStyle();
		}
		return _style;
	}

	/**
	 * スタイルクラスを取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return class属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyleClass getDecodeStyleclass() {
		if (_styleclass == null) {
			_styleclass = new GStyleClass();
		}
		return _styleclass;
	}

	/**
	 * dir属性の値を取得します.<br />
	 * 
	 * @create 2011/05/16
	 * @return dir属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getDir() {
		return _dir;
	}

	/**
	 * このコンポーネントに登録されたイベント一覧を返します.<br />
	 * 
	 * @create 2011/03/30
	 * @return イベント一覧
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GEvent> getEvents() {
		if (_events == null) {
			_events = new ArrayList<GEvent>();
		}
		return _events;
	}

	/**
	 * コンポーネントの完全なIDを取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return コンポーネントの完全なID
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFullId() {
		return GStringUtils.nullToBlank(getPrefix()) + GStringUtils.nullToBlank(getId());
	}

	/**
	 * id属性の値を取得します.<br />
	 * 
	 * @create 2011/05/16
	 * @return id属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getId() {
		return _id;
	}

	/**
	 * エラー項目の表示名の名前空間を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @return labelspace 表示名の名前空間
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLabelspace() {
		if (_labelspace == null) {
			String labelspace = null;
			if (getParent() != null) {
				labelspace = getParent().getLabelspace();
			}
			_labelspace = GStringUtils.nullToBlank(labelspace);
		}
		return _labelspace;
	}

	/**
	 * xml:lang属性の値を取得します.<br />
	 * 
	 * @create 2011/05/16
	 * @return xml:lang属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLang() {
		return _lang;
	}

	/**
	 * リクエストパラメータキーの完全な接頭語を返します.<br />
	 * 
	 * @create 2011/03/30
	 * @return リクエストパラメータキーの完全な接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getNamePrefix() {
		if (_nameprefix == null) {
			String namePrefix = null;
			if (getParent() != null) {
				namePrefix = getParent().getNamePrefix();
			}
			_nameprefix = GStringUtils.nullToBlank(namePrefix);
		}
		return _nameprefix;
	}

	/**
	 * onclick属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnclick() {
		return _onclick;
	}

	/**
	 * ondbclick属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return ondbclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOndblclick() {
		return _ondblclick;
	}

	/**
	 * onkeydown属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onkeydown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnkeydown() {
		return _onkeydown;
	}

	/**
	 * onkeypress属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onkeypress属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnkeypress() {
		return _onkeypress;
	}

	/**
	 * onkeyup属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onkeyup属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnkeyup() {
		return _onkeyup;
	}

	/**
	 * onmousedown属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onmousedown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmousedown() {
		return _onmousedown;
	}

	/**
	 * onmousemove属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onmousemove属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmousemove() {
		return _onmousemove;
	}

	/**
	 * onmouseout属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onmouseout属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmouseout() {
		return _onmouseout;
	}

	/**
	 * onmouseover属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onmouseover属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmouseover() {
		return _onmouseover;
	}

	/**
	 * onmouseup属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return onmouseup属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmouseup() {
		return _onmouseup;
	}

	/**
	 * ウィジェットオプションを取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return ウィジェットオプション
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getOptions() {
		if (_options != null) {
			return _options.encode();
		}
		return null;
	}

	/**
	 * このコントロールが格納されているコンテナコントロールを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return コンテナコントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponent getParent() {
		return _parent;
	}

	/**
	 * このコンポーネントの完全なID接頭語を返します.<br />
	 * 
	 * @create 2011/03/30
	 * @return このコンポーネントの完全なID接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getPrefix() {
		if (_prefix == null) {
			String prefix = null;
			if (getParent() != null) {
				prefix = getParent().getPrefix();
			}
			_prefix = GStringUtils.nullToBlank(prefix);
		}
		return _prefix;
	}

	/**
	 * リポジトリ情報(静的情報)を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return リポジトリ情報(静的情報)
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponent getRepository() {
		return _repository;
	}

	/**
	 * xml:space属性の値を取得します.<br />
	 * 
	 * @create 2011/05/16
	 * @return space属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getSpace() {
		return _space;
	}

	/**
	 * スタイルを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return スタイル
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getStyle() {
		if (_style != null) {
			return _style.encode();
		}
		return null;
	}

	/**
	 * スタイルクラスを取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return スタイルクラス
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getStyleclass() {
		if (_styleclass != null) {
			return _styleclass.encode();
		}
		return null;
	}

	/**
	 * title属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return title属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getTitle() {
		return _title;
	}

	/**
	 * visible属性の値を取得します.<br />
	 * 
	 * @create 2011/05/16
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getVisible() {
		return _visible;
	}

	/**
	 * visible属性の値を取得します.<br />
	 * 
	 * @create 2011/05/16
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isVisible() {
		return GBooleanUtils.toBoolean(getVisible(), true);
	}

	/**
	 * dir属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param dir dir属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setDir(String dir) {
		_dir = dir;
	}

	/**
	 * このコンポーネントにイベント一覧を登録します.<br />
	 * 
	 * @create 2011/03/30
	 * @param events イベント一覧
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEvents(List<GEvent> events) {
		_events = events;
	}

	/**
	 * id属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param id id属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setId(String id) {
		_id = id;
	}

	/**
	 * xml:lang属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param lang xml:lang属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLang(String lang) {
		_lang = lang;
	}

	/**
	 * onclick属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnclick(String script) {
		_onclick = script;
	}

	/**
	 * ondbclick属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script ondbclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOndblclick(String script) {
		_ondblclick = script;
	}

	/**
	 * onkeydown属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onkeydown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnkeydown(String script) {
		_onkeydown = script;
	}

	/**
	 * onkeypress属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onkeypress属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnkeypress(String script) {
		_onkeypress = script;
	}

	/**
	 * onkeyup属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onkeyup属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnkeyup(String script) {
		_onkeyup = script;
	}

	/**
	 * onmousedown属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onmousedown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmousedown(String script) {
		_onmousedown = script;
	}

	/**
	 * onmousemove属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script JavaScript文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmousemove(String script) {
		_onmousemove = script;
	}

	/**
	 * onmouseout属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onmouseout属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmouseout(String script) {
		_onmouseout = script;
	}

	/**
	 * onmouseover属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onmouseover属性
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmouseover(String script) {
		_onmouseover = script;
	}

	/**
	 * onmouseup属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param script onmouseup属性
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmouseup(String script) {
		_onmouseup = script;
	}

	/**
	 * options属性の値を設定します.<br />
	 * 
	 * @create 2011/05/16
	 * @param options ウィジェットオプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOptions(GJSONObject options) {
		_options = options;
	}

	/**
	 * options属性の値を設定します. optionsはJSON表現の文字列である必要があります.<br />
	 * 
	 * @create 2011/05/16
	 * @param options ウィジェットオプション(JSON表現の文字列)
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOptions(String options) {
		_options = options == null ? null : new GJSONObject(options);
	}

	/**
	 * このコントロールを格納するコンテナコントロールを設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param parent コンテナコントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setParent(GUIComponent parent) {
		_parent = parent;
	}

	/**
	 * リポジトリ情報(静的情報)を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param repository リポジトリコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRepository(GUIComponent repository) {
		_repository = repository;
	}

	/**
	 * xml:space属性の値を設定します.<br />
	 * 
	 * @create 2011/05/16
	 * @param space space属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSpace(String space) {
		_space = space;
	}

	/**
	 * style属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param style style属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyle(GStyle style) {
		_style = style;
	}

	/**
	 * style属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param style style属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyle(String style) {
		_style = style == null ? null : new GStyle(style);
	}

	/**
	 * class属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param styleclass class属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyleclass(GStyleClass styleclass) {
		_styleclass = styleclass;
	}

	/**
	 * class属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param styleclass class属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyleclass(String styleclass) {
		_styleclass = styleclass == null ? null : new GStyleClass(styleclass);
	}

	/**
	 * title属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param title title属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTitle(String title) {
		_title = title;
	}

	/**
	 * visible属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param visible <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVisible(boolean visible) {
		_visible = String.valueOf(visible);
	}

	/**
	 * visible属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param visible <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVisible(String visible) {
		_visible = visible;
	}
}
