/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui;

import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * 
 * @create 2011/03/05
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIItemBase extends GUIComponentBase implements GUIItem {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7242691660765180844L;
}
