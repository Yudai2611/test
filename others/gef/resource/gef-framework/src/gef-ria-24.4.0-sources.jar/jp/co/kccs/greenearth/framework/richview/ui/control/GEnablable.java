/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

/**
 * タグの有効状態を表すインターフェースです.<br/>
 * 
 * @create 2011/08/02
 * @author yamashita
 * @since 3.9.0
 */
public interface GEnablable {

	/**
	 * タグの有効/無効を取得します.<br />
	 * 
	 * @create 2011/08/02
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	boolean isEnabled();

	/**
	 * タグの有効/無効を設定します.<br />
	 * 
	 * @create 2011/08/02
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setEnabled(boolean enabled);
}
