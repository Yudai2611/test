/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

/**
 * ajaxのスクリプトブロックを表すUIコントロールです.<br/>
 * 
 * @create 2011/05/23
 * @author yamashita
 * @since 3.9.0
 */
public class GPAjaxRender extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7458087839158628548L;

	/**
	 * {@link GPAjaxRender}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/23
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPAjaxRender() {
	}
}
