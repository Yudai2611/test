/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

/**
 * アンカーを表すUIコンポーネントです.<br>
 * 
 * @create 2011/06/21
 * @author hamanaka
 * @since 3.9.0
 */
public class GPAnchor extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5748243812658713934L;

	// XHTML属性
	/** charset属性の値. */
	private String _charset = null;
	/** coords属性の値. */
	private String _coords = null;
	/** href属性の値. */
	private String _href = null;
	/** hreflang属性の値. */
	private String _hreflang = null;
	/** rel属性の値. */
	private String _rel = null;
	/** rev属性の値. */
	private String _rev = null;
	/** shape属性の値. */
	private String _shape = null;
	/** type属性の値. */
	private String _type = null;
	/** target属性の値. */
	private String _target = null;
	/** oncontext属性の値. */
	private String _oncontextmenu = null;

	/**
	 * {@link GPAnchor}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPAnchor() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#canFocus()
	 * @return <code>true</code>/<code>false</code>
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public boolean canFocus() {
		return isVisible();
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase#reset()
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPAnchor control = (GPAnchor) getRepository();
		setCharset(control == null ? null : control.getCharset());
		setCoords(control == null ? null : control.getCoords());
		setHref(control == null ? null : control.getHref());
		setHreflang(control == null ? null : control.getHreflang());
		setOncontextmenu(control == null ? null : control.getOncontextmenu());
		setRel(control == null ? null : control.getRel());
		setRev(control == null ? null : control.getRev());
		setShape(control == null ? null : control.getShape());
		setType(control == null ? null : control.getType());
		setTarget(control == null ? null : control.getTarget());
	}

	/**
	 * charset属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return charset属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getCharset() {
		return _charset;
	}

	/**
	 * coords属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return coords属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getCoords() {
		return _coords;
	}

	/**
	 * href属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return href属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getHref() {
		return _href;
	}

	/**
	 * hreflang属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return hreflang属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getHreflang() {
		return _hreflang;
	}

	/**
	 * oncontextmenu属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return oncontextmenu属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getOncontextmenu() {
		return _oncontextmenu;
	}

	/**
	 * rel属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return rel属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getRel() {
		return _rel;
	}

	/**
	 * rev属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return rev属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getRev() {
		return _rev;
	}

	/**
	 * shape属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return shape属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getShape() {
		return _shape;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.action.GActionControl#getTarget()
	 * @create 2011/06/21
	 * @return target属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * type属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return type属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getType() {
		return _type;
	}

	/**
	 * charset属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param charset charset属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setCharset(String charset) {
		_charset = charset;
	}

	/**
	 * coords属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param coords coords属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setCoords(String coords) {
		_coords = coords;
	}

	/**
	 * href属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param href href属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setHref(String href) {
		_href = href;
	}

	/**
	 * hreflang属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param hreflang hreflang属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setHreflang(String hreflang) {
		_hreflang = hreflang;
	}

	/**
	 * oncontextmenu属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param oncontextmenu oncontextmenu属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setOncontextmenu(String oncontextmenu) {
		_oncontextmenu = oncontextmenu;
	}

	/**
	 * rel属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param rel rel属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setRel(String rel) {
		_rel = rel;
	}

	/**
	 * rev属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param rev rev属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setRev(String rev) {
		_rev = rev;
	}

	/**
	 * shape属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param shape shpape属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setShape(String shape) {
		_shape = shape;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.action.GActionControl#setTarget(String)
	 * @create 2011/06/21
	 * @param target target属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setTarget(String target) {
		_target = target;
	}

	/**
	 * type属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param type type属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setType(String type) {
		_type = type;
	}
}
