/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;


/**
 * ボディを表すUIコンポーネントです.<br />
 * 
 * @create 2013/03/23
 * @author KCCS kikuchi
 * @since 3.10.0.D
 */
public class GPBody extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4658948579835662208L;
	/** デフォルトのID. */
	public static final String DEFAULT_ID = "body";
	
	// XHTML属性
	/** ロードイベント. */
	private String _onload = null;
	/** アンロードイベント. */
	private String _onunload = null;

	/**
	 * {@link GPBody}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/23
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public GPBody() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIContainerControlBase#reset()
	 * @create 2013/03/23
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		GPBody control = (GPBody) getRepository();
		setOnload(control == null ? null : control.getOnload());
		setOnunload(control == null ? null : control.getOnunload());
	}

	/**
	 * ロードイベントを取得します.<br />
	 * 
	 * @create 2013/03/23
	 * @return ロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public String getOnload() {
		return _onload;
	}

	/**
	 * アンロードイベントを取得します.<br />
	 * 
	 * @create 2013/03/23
	 * @return アンロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public String getOnunload() {
		return _onunload;
	}

	/**
	 * idを取得します.<br />
	 * idがnullである場合、デフォルトidを返します。<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#getId()
	 * @return id id属性の値
	 * @create 2013/03/29
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public String getId() {
		return super.getId() == null ? DEFAULT_ID : super.getId();
	}
	
	/**
	 * ロードイベントを設定します.<br />
	 * 
	 * @create 2013/03/23
	 * @param onload ロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public void setOnload(String onload) {
		_onload = onload;
	}

	/**
	 * アンロードイベントを設定します.<br />
	 * 
	 * @create 2013/03/23
	 * @param onunload アンロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public void setOnunload(String onunload) {
		_onunload = onunload;
	}
}
