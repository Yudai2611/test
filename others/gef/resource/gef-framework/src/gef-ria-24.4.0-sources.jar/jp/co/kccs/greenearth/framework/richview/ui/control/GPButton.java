/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * ボタンを表すUIコントロールです.<br />
 *
 * @create 2013/02/28
 * @author kikuchi
 * @since 3.10.0.D
 */
public class GPButton extends GUIControlBase implements GEnablable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7004245699114513476L;

	// XHTML属性
	/** value属性の値. */
	private String _value = null;

	// 拡張属性
	/** showaccesskey属性の値. */
	private String _showaccesskey = null;
	/** enabled属性の値. */
	private String _enabled = null;

	/**
	 * {@link GPButton}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2013/02/28
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public GPButton() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 *
	 * 以下のいずれかの場合、フォーカスは当てられません。<br>
	 * ・visibleフィールドが<code>false</code><br>
	 * ・enableフィールドが<code>false</code><br>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#canFocus()
	 * @return <code>true</code>/<code>false</code>
	 * @create 2013/02/28
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public boolean canFocus() {
		return isVisible() && isEnabled();
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 *
	 * @create 2013/02/28
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		GPButton control = (GPButton) getRepository();
		setValue(control == null ? null : control.getValue());
		setShowaccesskey(control == null ? null : control.getShowaccesskey());
		setEnabled(control == null ? null : control.getEnabled());
	}

	/**
	 * enabled属性の値を取得します.<br />
	 *
	 * @create 2013/02/28
	 * @return タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kikuchia
	 * @since 3.10.0.D
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * showaccesskey属性の値を取得します.<br />
	 *
	 * @create 2013/02/28
	 * @return accesskey属性を<code>true:表示</code>/<code>false:非表示</code>
	 * @author kikuchia
	 * @since 3.10.0.D
	 */
	public String getShowaccesskey() {
		return _showaccesskey;
	}

	/**
	 * value属性の値を取得します.<br />
	 *
	 * @create 2013/02/28
	 * @return value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * 状態の有効 / 無効を判定します.<br />
	 *
	 * @create 2013/02/28
	 * @return <code>true</code>:有効 / <code>false</code>:無効
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}

	/**
	 * アクセスキーの表示 / 非表示を判定します.<br />
	 *
	 * @create 2013/02/28
	 * @return <code>true</code>:表示 / <code>false</code>:非表示
	 * @author kikuchia
	 * @since 3.10.0.D
	 */
	public boolean isShowaccesskey() {
		return GBooleanUtils.toBoolean(_showaccesskey, true);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param enabled タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param enabled タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * showaccesskey属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param showaccesskey accesskey属性を<code>true:表示</code>/
	 *            <code>false:非表示</code>
	 * @author kikuchia
	 * @since 3.10.0.D
	 */
	public void setShowaccesskey(Boolean showaccesskey) {
		_showaccesskey = String.valueOf(showaccesskey);
	}

	/**
	 * showaccesskey属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param showaccesskey accesskey属性を<code>true:表示</code>/
	 *            <code>false:非表示</code>
	 * @author kikuchia
	 * @since 3.10.0.D
	 */
	public void setShowaccesskey(String showaccesskey) {
		_showaccesskey = showaccesskey;
	}
	/**
	 * value属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param value value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setValue(String value) {
		_value = value;
	}
}
