/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.math.BigDecimal;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * チェックボックスを表すUIコントロールです.<br />
 * 
 * @create 2013/03/14
 * @author KCCS H.nishimura
 * @since 3.10.0.D
 */
public class GPCheckBox extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8294281159708780157L;

	// XHTML属性
	/** チェックの状態. */
	private String _checked;

	// 拡張属性
	/** 読み取り専用にするかの指定. */
	private String _readonly;

	/**
	 * {@link GPCheckBox}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public GPCheckBox() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#canFocus()
	 * @return <code>true</code>/<code>false</code>
	 * @create 2013/03/12
	 * @author H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public boolean canFocus() {
		return super.canFocus() && !isReadonly();
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#clear()
	 * @create 2013/03/14
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public void clear() {
		super.clear();
		setChecked(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#loadData(java.lang.Object)
	 * @param data 表示内容
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public void loadData(Object data) {
		if (data == null) {
			_checked = null;
			return;
		}
		Boolean b = false;
		if (data instanceof String) {
			b = !"0".equals(data);
		} else if (data instanceof Number) {
			BigDecimal numData = new BigDecimal(data.toString());
			b = !(numData.compareTo(BigDecimal.ZERO) == 0);
		} else if (data instanceof Boolean) {
			b = ((Boolean) data).booleanValue();
		}
		_checked = b.toString();
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#reset()
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		GPCheckBox control = (GPCheckBox) getRepository();
		setChecked(control == null ? null : control.getChecked());
		setReadonly(control == null ? null : control.getReadonly());
	}

	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @return checked属性の値
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getChecked() {
		return _checked;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @return readonly属性の値
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * チェック済み / 未チェックを判定します.<br/>
	 * 
	 * @return <code>true</code>：チェック済み / <code>false</code>：未チェック
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public boolean isChecked() {
		return GBooleanUtils.toBoolean(_checked, false);
	}

	/**
	 * 状態の読み込み専用 / 書き込み可能を判定します.<br>
	 * 
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @param checked checked属性の値
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setChecked(boolean checked) {
		_checked = String.valueOf(checked);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @param checked checked属性の値
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setChecked(String checked) {
		_checked = checked;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/03/12
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}
}
