/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;


/**
 * div要素を表すUIコントロールです.<br />
 * 
 * @create 2011/04/04
 * @author yamashita
 * @since 3.9.0
 */
public class GPDiv extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 799079300571140825L;

	/**
	 * {@link GDiv}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPDiv() {
	}
}
