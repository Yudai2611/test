/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

/**
 * セレクトを表すUIコンポーネントです.<br />
 * 
 * @create 2011/06/01
 * @author hamanaka
 * @since 3.9.0
 */
public class GPDynamicSelect extends GPSelect {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3688539095231324974L;

	/**
	 * {@link GPDynamicSelect}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPDynamicSelect() {
	}

	/**
	 * セレクトオプション({@link GSelectOption})を全て削除します.
	 * 
	 * @create 2011/09/17
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void clearOptions() {
		getSelectOptions().clear();
	}

	/**
	 * 指定されたインデックスの{@link GSelectOption}をリストから削除します.<br />
	 * 
	 * @param index インデックス
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void removeSelectOption(int index) {
		getSelectOptions().remove(index);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		getSelectOptions().clear();
		super.reset();
	}
}
