/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;


/**
 * フォームを表すUIコントロールです.<br />
 * 
 * @create 2013/03/21
 * @author KCCS H.nishimura
 * @since 3.10.0.D
 */
public class GPForm extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3527962008976761916L;

	// XHTML属性
	/** MIME タイプのリスト. */
	private String _accept = null;

	/** キャラクタセットのリスト. */
	private String _acceptcharset = null;

	/** サブミット（実行）された時の動作. */
	private String _action = null;

	/** オートコンプリート機能の有無. */
	private String _autocomplete = null;

	/** エンコード形式. */
	private String _enctype = null;

	/** サーバーにデータを送る形式. */
	private String _method = null;

	// イベント
	/** リセットイベント. */
	private String _onreset = null;

	/** サブミットイベント. */
	private String _onsubmit = null;

	/** 表示ターゲット. */
	private String _target = null;

	// 拡張属性
	/** フォーカス対象のオブジェクトID. */
	private String _focus = null;

	/**
	 * {@link GPForm}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public GPForm() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase#reset()
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		GPForm control = (GPForm) getRepository();
		setAccept(control == null ? null : control.getAccept());
		setAcceptCharset(control == null ? null : control.getAcceptCharset());
		setAction(control == null ? null : control.getAction());
		setAutocomplete(control == null ? null : control.getAutocomplete());
		setEnctype(control == null ? null : control.getEnctype());
		setFocus(control == null ? null : control.getFocus());
		setMethod(control == null ? null : control.getMethod());
		setOnreset(control == null ? null : control.getOnreset());
		setOnsubmit(control == null ? null : control.getOnsubmit());
		setTarget(control == null ? null : control.getTarget());
	}

	/**
	 * acceptの属性値を取得します.<BR>
	 * 
	 * @create 2013/03/21
	 * @return MIMEタイプのリスト
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAccept() {
		return _accept;
	}

	/**
	 * acceptcharsetの属性値を取得します.<BR>
	 * 
	 * @create 2013/03/21
	 * @return キャラクタセットのリスト
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAcceptCharset() {
		return _acceptcharset;
	}

	/**
	 * actionの属性値の値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return サブミット（実行）された時の動作
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAction() {
		return _action;
	}

	/**
	 * enctypeの属性値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return <code>on</code>/<code>off</code>
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * enctypeの属性値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return エンコード形式
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getEnctype() {
		return _enctype;
	}

	/**
	 * focusの属性値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return フォーカス対象のオブジェクトID
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getFocus() {
		return _focus;
	}

	/**
	 * methodの属性値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return GET/POST
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getMethod() {
		return _method;
	}

	/**
	 * onresetの属性値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return イベント発生時に実行されるスクリプト
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getOnreset() {
		return _onreset;
	}

	/**
	 * onsubmitの属性値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return イベント発生時に実行されるスクリプト
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getOnsubmit() {
		return _onsubmit;
	}

	/**
	 * targetの属性値を取得します.
	 * 
	 * @create 2013/03/21
	 * @return 表示ターゲット
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * オートコンプリート機能の有効 / 無効を判定します.<br>
	 * 
	 * @return <code>true</code>：有効 / <code>false</code>：無効
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public boolean isAutocomplete() {
		if (_autocomplete == null) {
			return true;
		}
		return !"off".equals(_autocomplete.toLowerCase());
	}

	/**
	 * acceptの属性値を指定します.
	 * 
	 * @param accept MIMEタイプのリスト
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAccept(String accept) {
		_accept = accept;
	}

	/**
	 * charsetの属性値を指定します.
	 * 
	 * @param charset キャラクタセットのリスト
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAcceptCharset(String charset) {
		_acceptcharset = charset;
	}

	/**
	 * actionの属性値を指定します.
	 * 
	 * @param action サブミット（実行）された時の動作
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAction(String action) {
		_action = action;
	}

	/**
	 * autocompleteの属性値を設定します.
	 * 
	 * @param autocomplete <code>true</code>/<code>false</code>
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAutocomplete(boolean autocomplete) {
		_autocomplete = autocomplete ? "on" : "off";
	}

	/**
	 * autocompleteの属性値を設定します.
	 * 
	 * @param autocomplete <code>on</code>/<code>off</code>
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * enctypeの属性値を指定します.
	 * 
	 * @param enctype エンコード形式
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setEnctype(String enctype) {
		_enctype = enctype;
	}

	/**
	 * focusの属性値を設定します.
	 * 
	 * @param focus フォーカス対象のオブジェクトID
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setFocus(String focus) {
		_focus = focus;
	}

	/**
	 * methodの属性値を指定します.
	 * 
	 * @param method GET/POST
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setMethod(String method) {
		_method = method;
	}

	/**
	 * onresetの属性値を設定します.
	 * 
	 * @param script イベント発生時に実行されるスクリプト
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setOnreset(String script) {
		_onreset = script;
	}

	/**
	 * onsubmitの属性値を設定します.
	 * 
	 * @param script イベント発生時に実行されるスクリプトv
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setOnsubmit(String script) {
		_onsubmit = script;
	}

	/**
	 * targetの属性値を設定します.
	 * 
	 * @param target  targetの属性値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setTarget(String target) {
		_target = target;
	}
}
