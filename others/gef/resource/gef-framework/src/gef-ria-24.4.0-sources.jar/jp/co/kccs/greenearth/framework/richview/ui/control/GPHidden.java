/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

/**
 * ブラウザ上には表示されない隠し項目を表すUIコンポーネントです.<br />
 * 
 * @create 2011/05/13
 * @author kobayashi
 * @since 3.9.0
 */

public class GPHidden extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3286874151990536190L;

	// XHTML属性
	/** value属性の値. */
	private String _value = null;

	/**
	 * {@link GPHidden}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/13
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public GPHidden() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * id属性を除く必須属性も全てクリアされますので、{@link GPHidden#clear()}実行後は必須属性に値を設定してください。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#clear()
	 * @create 2011/07/04
	 * @author kobayashi
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param data 表示内容
	 * @author kobayashi
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		setValue(data == null ? null : data.toString());
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @create 2011/05/13
	 * @author kobayashi
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPHidden control = (GPHidden) getRepository();
		setValue(control == null ? null : control.getValue());
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return value属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param value value属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}

}
