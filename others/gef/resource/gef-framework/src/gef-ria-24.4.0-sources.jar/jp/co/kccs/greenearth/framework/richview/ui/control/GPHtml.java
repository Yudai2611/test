/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.framework.view.GViewException;

import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * HTMLを表すUIコントロールです.<br />
 * 
 * @create 2013/03/26
 * @author KCCS H.nishimura
 * @since 3.10.0.D
 */
public class GPHtml extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1718008590783158305L;

	/** デフォルトのID. */
	public static final String DEFAULT_ID = "html";

	/** デフォルトXHTML名前空間 */
	public static final String DEFAULT_XHTML_NAMESPACE = "http://www.w3.org/1999/xhtml";

	// XHTML属性
	/** XHTML文書が属するバージョン. */
	private String _version = null;
	/** XHTMLデフォルト名前空間 */
	private String _xmlns = null;

	// 拡張属性
	/** 動的に指定されたHTMLの名前空間を格納. */
	private Map<String, String> _namespaceMap = new HashMap<String, String>();

	/**
	 * {@link GPHtml}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/28
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public GPHtml() {
	}

	/**
	 * JSPのXHTMLタグの属性をフィールドに設定します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase#loadJspElement(org.w3c.dom.Element)
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2013/03/27
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		NamedNodeMap nodeMap = element.getAttributes();
		for (int i = 0; i < nodeMap.getLength(); i++) {
			Node node = nodeMap.item(i);
			String nodeName = node.getNodeName();
			if (!"xmlns".equals(nodeName) && nodeName.startsWith("xmlns")) {
				_namespaceMap.put(nodeName, node.getNodeValue());
			}
		}
		super.loadJspElement(element);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase#reset()
	 * @create 2013/03/26
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		GPHtml control = (GPHtml) getRepository();
		setVersion(control == null ? null : control.getVersion());
		setXmlns(control == null ? null : control.getXmlns());
	}

	/**
	 * namespaceMapの属性値を取得します.<br/>
	 * 
	 * @return namespaceMapの属性値
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public Map<String, String> getNamespaceMap() {
		return _namespaceMap;
	}

	/**
	 * idの属性値を取得します.<br/>
	 * 
	 * @return idの属性値
	 * @create 2013/03/31
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public String getId() {
		return super.getId() == null ? DEFAULT_ID : super.getId();
	}

	/**
	 * versionの属性値を取得します.<br/>
	 * 
	 * @return versionの属性値
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getVersion() {
		return _version;
	}

	/**
	 * xmlnsの属性値を取得します.<br/>
	 * 
	 * @return xmlnsの属性値
	 * @create 2013/03/29
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public String getXmlns() {
		return _xmlns == null ? DEFAULT_XHTML_NAMESPACE : _xmlns;
	}

	/**
	 * namespaceMapの属性値を設定します.<br>
	 * 
	 * @param namespaceMap namespaceMapの属性値
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setNamespaceMap(Map<String, String> namespaceMap) {
		_namespaceMap = namespaceMap;
	}

	/**
	 * versionの属性値を設定します.<br>
	 * 
	 * @param version versionの属性値
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setVersion(String version) {
		_version = version;
	}

	/**
	 * xmlnsの属性値を設定します.<br>
	 * 
	 * @param xmlns xmlnsの属性値
	 * @create 2013/03/29
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public void setXmlns(String xmlns) {
		this._xmlns = xmlns;
	}
}
