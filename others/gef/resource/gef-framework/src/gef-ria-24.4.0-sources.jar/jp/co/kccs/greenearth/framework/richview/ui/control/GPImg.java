/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * イメージを表すUIコンポーネントです.<br />
 * 
 * @create 2011/04/22
 * @author hamanaka
 * @since 3.9.0
 */
public class GPImg extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2553044726117228265L;

	// XHTML属性
	/** alt属性の値. */
	private String _alt = null;
	/** ismap属性の値. */
	private String _ismap = null;
	/** longdesc属性の値. */
	private String _longdesc = null;
	/** src属性の値. */
	private String _src = null;
	/** usemap属性の値. */
	private String _usemap = null;
	
	/**
	 * {@link GPImg}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/22
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPImg() {
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * 値が<code>null</code>の場合は、<code>null</code>を読み込みます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GRichUIControlBase#loadData(java.lang.Object)
	 * @param data 表示内容
	 * @create 2011/04/22
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		setSrc(data == null ? null : data.toString());
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 * 
	 * @create 2014/07/16
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public void clear() {
		super.clear();
		setSrc(null);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GRichUIControlBase#reset()
	 * @create 2011/04/22
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPImg control = (GPImg) getRepository();
		setAlt(control == null ? null : control.getAlt());
		setIsmap(control == null ? null : control.getIsmap());
		setLongdesc(control == null ? null : control.getLongdesc());
		setSrc(control == null ? null : control.getSrc());
		setUsemap(control == null ? null : control.getUsemap());
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * 
	 * {@link GPImg#canFocus()}では常にフォーカスは当てられません。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GRichUIControlBase#canFocus()
	 * @return <code>false</code>
	 * @create 2011/04/22
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public boolean canFocus() {
		return false;
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2014/07/16
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return alt属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getAlt() {
		return _alt;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return ismap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getIsmap() {
		return _ismap;
	}

	/**
	 * longdesc属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return longdesc属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLongdesc() {
		return _longdesc;
	}

	/**
	 * src属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return src属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getSrc() {
		return _src;
	}

	/**
	 * usemap属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return usemap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getUsemap() {
		return _usemap;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return ismap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isIsmap() {
		return GBooleanUtils.toBoolean(_ismap, false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param alt alt属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setAlt(String alt) {
		_alt = alt;
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param ismap ismap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setIsmap(boolean ismap) {
		_ismap = String.valueOf(ismap);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param ismap ismap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setIsmap(String ismap) {
		_ismap = ismap;
	}

	/**
	 * longdesc属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param longdesc longdesc属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLongdesc(String longdesc) {
		_longdesc = longdesc;
	}

	/**
	 * src属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param src src属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSrc(String src) {
		_src = src;
	}

	/**
	 * usemap属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param usemap usemap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setUsemap(String usemap) {
		_usemap = usemap;
	}
}
