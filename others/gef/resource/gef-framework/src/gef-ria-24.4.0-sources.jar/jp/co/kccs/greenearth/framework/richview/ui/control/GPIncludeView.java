/*
 * Copyright 2014-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GViewBase;

/**
 * インクルード用のページを表します.<br/>
 * 
 * @create 2014/02/21
 * @author KCCS yamashita
 * @since 3.13.0
 */
public class GPIncludeView extends GViewBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5735271774596253702L;

	/** 親UIコンポーネント. */
	private GUIComponent _parent;

	/**
	 * デフォルトコンストラクタ
	 * 
	 * @create 2014/02/21
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@SuppressWarnings("deprecation")
	public GPIncludeView() {
		setViewclass(GPIncludeView.class.getName());
//		setType(GViewInterface.TYPE_INCLUDE);
	}

	/**
	 * このコントロールを格納するコンテナコントロールを設定します.
	 *  
	 * @param parent
	 * @create 2014/02/27
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public void setParent(GUIComponent parent) {
		_parent = parent;
	}
	
	/**
	 * このコントロールが格納されているコンテナコンポーネントを取得します.
	 * 
	 * @create 2014/02/27
	 * @return 親コントロール
	 * @author yamashita
	 * @since 3.13.0
	 */
	@Override
	public GUIComponent getParent() {
		return _parent;
	}
}
