/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.GJspUtils;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GRepositoryFactory;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;

/**
 * 指定したページを出力するインクルードのUIコントロールです.<br/>
 * 
 * @create 2014/02/20
 * @author KCCS yamashita
 * @since 3.13.0
 */
public class GPJspInclude extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2527020800455413984L;

	/** ページ出力のバッファのフラッシュ指定. */
	private String _flush = null;
	/** インクルードするファイルパス. */
	private String _page = null;

	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2014/02/27
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public GPJspInclude() {
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * JSPのHTMLタグの属性を、フィールドに設定します。
	 * 
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2014/02/27
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}
	
	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * @create 2014/03/28
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.13.0
	 */
	@Override
	public void loadResultData(GResultData data) {
	}

	/**
	 * コントロール入力値の検証を行います.<br />
	 * 
	 * @create 2011/04/12
	 * @param parameter パラメーター
	 * @return 検証結果のエラー配列
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public List<GValidateError> validate(GParameter parameter) {
		return getView().onValidate(parameter);
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br>
	 * 
	 * @create 2014/02/20
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author yamashita
	 * @since 3.13.0
	 */
	private void loadNestedNode(Node node) {
		GViewInterface view = getView();
		if (view != null) {
			addControl(view);
		}
	}

	GViewInterface getView() {
		if (!getControls().isEmpty()) {
			return (GViewInterface) getControls().get(0);
		}
		HttpServletRequest req = GWebContext.getInstance().getRequest();
		ServletContext context = req.getSession().getServletContext();
		String path = getLocalizePath(_page);
		URL url = null;
		try {
			url = context.getResource(path);
			if (url == null) {
				throw new NullPointerException();
			}
		} catch (MalformedURLException | NullPointerException e) {
			throw new GViewException(new FileNotFoundException("The view repository is not found : " + path));
		}
		return (GViewInterface) GRepositoryFactory.createRepository(url);
	}

	/**
	 * 指定されたパスにロケールの言語・国・バリアント情報を付与して取得します.<br />
	 * 
	 * @create 2014/02/20
	 * @param path パス名
	 * @return ロケールの言語・国・バリアント情報が付与されたパス名
	 * @author yamashita
	 * @since 3.13.0
	 */
	protected String getLocalizePath(String path) {
		GWebContext context = GWebContext.getInstance();
		return GJspUtils.getLocalizePath(path, context.getLocale(), context.getServletContext());
	}

	/**
	 * ページ出力のバッファのフラッシュ指定を取得します.<br />
	 * 
	 * @create 2014/02/20
	 * @return ページ出力のバッファのフラッシュ指定
	 * @author yamashita
	 * @since 3.13.0
	 */
	public String getFlush() {
		return _flush;
	}

	/**
	 * インクルードするファイルパスを取得します.<br />
	 * 
	 * @create 2014/02/20
	 * @return インクルードするファイルパス
	 * @author yamashita
	 * @since 3.13.0
	 */
	public String getPage() {
		return _page;
	}

	/**
	 * ページ出力のバッファのフラッシュ指定を取得します.<br />
	 * 
	 * @create 2014/02/20
	 * @return ページ出力のバッファのフラッシュ指定
	 * @author yamashita
	 * @since 3.13.0
	 */
	public boolean isFlush() {
		return GBooleanUtils.toBoolean(getFlush(), false);
	}

	/**
	 * ページ出力のバッファのフラッシュ指定を設定します.<br />
	 * 
	 * @create 2014/02/20
	 * @param flush ページ出力のバッファのフラッシュ指定 <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.13.0
	 */
	public void setFlush(boolean flush) {
		_flush = String.valueOf(flush);
	}

	/**
	 * ページ出力のバッファのフラッシュ指定を設定します.<br />
	 * 
	 * @create 2014/02/20
	 * @param flush ページ出力のバッファのフラッシュ指定 <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.13.0
	 */
	public void setFlush(String flush) {
		_flush = flush;
	}

	/**
	 * インクルードするファイルパスを設定します.<br />
	 * 
	 * @create 2014/02/20
	 * @param page インクルードするファイルパス
	 * @author yamashita
	 * @since 3.13.0
	 */
	public void setPage(String page) {
		_page = page;
	}
}
