/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.Date;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;

/**
 * ラベルコントロールを表すUIコントロールです.<br />
 * 
 * @create 2011/08/19
 * @author yamashita
 * @since 3.9.0
 */

public class GPLabel extends GVariableControlBase implements GFormatControl {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1983655945289656927L;
	// XHTML属性
	/** value属性の値. */
	private Object _object = null;
	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;
	/** multiline属性の値. */
	private String _multiline = null;
	

	/**
	 * {@link GPLabel}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/08/19
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPLabel() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#clear()
	 * @create 2011/08/19
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param data 表示内容
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		setObject(data);
	}
	
	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @create 2011/08/19
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPLabel control = (GPLabel) getRepository();
		setValue(control == null ? null : control.getValue());
		setFormat(control == null ? null : control.getFormat());
		setLocale(control == null ? null : control.getLocale());
		setMultiline(control == null ? null : control.getMultiline());
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		Object object = getObject();
		String value = object == null ? null : object.toString();
		if (object instanceof Date) {
			value = GUIUtils.formatDateToString((Date) object, _format, GCoreUtils.getLocale(_locale));
		} else if (object instanceof Number) {
			value = GUIUtils.formatNumberToString((Number) object, _format, GCoreUtils.getLocale(_locale));
		}
		return value;
	}

	/**
	 * multiline属性の値を取得します.<br />
	 * 
	 * @create 2013/06/18
	 * @return multiline属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getMultiline() {
		return _multiline;
	}
	
	/**
	 * value属性の値をObject型で取得します.<br />
	 * 
	 * @create 2014/05/30
	 * @return value属性の値
	 * @author yoshida
	 * @since 3.14.0
	 */
	public Object getObject() {
		return _object;
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param format 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param locale ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		setObject(value);
	}

	/**
	 * multiline属性の値を設定します.<br />
	 * 
	 * @create 2013/06/18
	 * @param multiline <code>true:改行を有効にする</code>/<code>false:改行を無効にする</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setMultiline(boolean multiline) {
		_multiline = String.valueOf(multiline);
	}

	/**
	 * multiline属性の値を設定します.<br />
	 * 
	 * @create 2013/06/18
	 * @param multiline <code>true:改行を有効にする</code>/<code>false:改行を無効にする</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setMultiline(String multiline) {
		_multiline = multiline;
	}
	
	/**
	 * value属性の値をObject型で設定します.<br />
	 * 
	 * @create 2014/05/30
	 * @param object
	 * @author yoshida
	 * @since 3.14.0
	 */
	public void setObject(Object object) {
		_object = object;
	}
	
	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2013/06/11
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}
	
	/**
	 * multiline属性の値を取得します.<br />
	 * 
	 * @create 2013/06/18
	 * @return <code>true:改行を有効にする</code>/<code>false:改行を無効にする</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public boolean isMultiline() {
		return GBooleanUtils.toBoolean(getMultiline(), false);
	}
	
	
}
