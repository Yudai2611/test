/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.view.validator.GValidator;

/**
 * ラベルコントロールを表すUIコントロールです.<br />
 * 
 * @create 2011/04/21
 * @author hamanaka
 * @since 3.9.0
 */
public class GPLabelValue extends GUIControlBase implements GVariableControl {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2910803404801141145L;

	// 拡張属性
	/** value属性の値. */
	private String _value = null;

	// 内部変数
	/** {@link GErrorLevel}オブジェクト. */
	private GErrorLevel _errorlevel = GErrorLevel.NONE;
	/** {@link GValidator}オブジェクトのリスト. */
	private List<GValidator> _validators = new LinkedList<GValidator>();

	/**
	 * {@link GPLabelValue}のインスタンスを初期化します.<br />
	 * 
	 * @create 2010/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPLabelValue() {
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#loadData(java.lang.Object)
	 * @param data 表示内容
	 * @create 2010/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		_value = data == null ? null : data.toString();
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * @create 2011/03/30
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadResultData(GResultData data) {
		if (data.containsDataName(getId())) {
			loadData(data.getData(getId()));
		}
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#reset()
	 * @create 2010/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPLabelValue control = (GPLabelValue) getRepository();
		setValue(control == null ? null : control.getValue());
	}

	/**
	 * {@link GErrorLevel}オブジェクトを取得します.<br />
	 * 
	 * @create 2011/09/08
	 * @return {@link GErrorLevel}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GErrorLevel getErrorlevel() {
		return _errorlevel;
	}

	/**
	 * name属性の値を取得します.<br />
	 * 
	 * @create 2011/09/08
	 * @return name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getName() {
		return getId();
	}

	/**
	 * 画面で利用されるパラメータ名を取得します.<br />
	 * 
	 * @create 2011/09/08
	 * @return パラメータ名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getParameterKey() {
		return GStringUtils.nullToBlank(getNamePrefix()) + GStringUtils.nullToBlank(getName());
	}

	/**
	 * {@link GValidator}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/09/08
	 * @return {@link GValidator}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GValidator> getValidators() {
		return _validators;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2010/04/21
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2011/09/08
	 * @return <code>false:非クリア対象</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isClear() {
		return false;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/09/08
	 * @return <code>true:タグの有効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isEnabled() {
		return true;
	}

	/**
	 * required属性の値を取得します.<br />
	 * 
	 * @create 2011/09/08
	 * @return <code>false:任意入力</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isRequired() {
		return false;
	}

	/**
	 * clear属性の値を設定します.<br />
	 * ここでは何もしません。<br/>
	 * 
	 * @create 2011/09/08
	 * @param clear <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setClear(boolean clear) {
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/09/08
	 * @param enabled <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEnabled(boolean enabled) {
	}

	/**
	 * {@link GErrorLevel}オブジェクトを設定します.<br />
	 * ここでは何もしません。<br/>
	 * 
	 * @create 2011/09/08
	 * @param errorlevel エラーレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setErrorlevel(GErrorLevel errorlevel) {
	}

	/**
	 * name属性の値を設定します.<br />
	 * ここでは何もしません。<br/>
	 * 
	 * @create 2011/09/08
	 * @param name name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setName(String name) {
	}

	/**
	 * required属性の値を設定します.<br />
	 * ここでは何もしません。<br/>
	 * 
	 * @create 2011/09/08
	 * @param required required属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRequired(boolean required) {
	}

	/**
	 * {@link GValidator}オブジェクトを設定します.<br />
	 * ここでは何もしません。<br/>
	 * 
	 * @create 2011/09/08
	 * @param validators {@link GValidator}のリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValidators(List<GValidator> validators) {
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2010/04/21
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
