/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyle;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.view.GViewException;

/**
 * リンクイメージを表すUIコントロールです.<br />
 * 
 * @create 2013/06/06
 * @author KCCS H.nishimura
 * @since 3.12.0
 */
public class GPLinkedImg extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3124121513437552035L;

	// XHTML属性
	/** alt属性の値. */
	private String _alt = null;
	/** ismap属性の値. */
	private String _ismap = null;
	/** longdesc属性の値. */
	private String _longdesc = null;
	/** src属性の値. */
	private String _src = null;
	/** usemap属性の値. */
	private String _usemap = null;

	/** charset属性の値. */
	private String _charset = null;
	/** coords属性の値. */
	private String _coords = null;
	/** href属性の値. */
	private String _href = null;
	/** hreflang属性の値. */
	private String _hreflang = null;
	/** rel属性の値. */
	private String _rel = null;
	/** rev属性の値. */
	private String _rev = null;
	/** shape属性の値. */
	private String _shape = null;
	/** type属性の値. */
	private String _type = null;
	/** target属性の値. */
	private String _target = null;
	/** oncontextmenu属性の値 */
	private String _oncontextmenu = null;

	// 拡張属性
	/** 画像のスタイル */
	private GStyle _imgstyle = null;
	/** 画像のスタイルシートのクラス名 */
	private GStyleClass _imgstyleclass = null;

	/**
	 * {@link GPLinkedImg}のインスタンスを初期化します.<br />
	 * 
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public GPLinkedImg() {
	}

	/**
	 * 指定された値をsrc属性値に設定します.<br />
	 * 
	 * 値が<code>null</code>の場合は、<code>null</code>を読み込みます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#loadData(java.lang.Object)
	 * @param data 表示内容
	 * @create 2014/06/05
	 * @author kikuchi
	 * @since 3.16.0
	 */
	@Override
	public void loadData(Object data) {
		setSrc(data == null ? null : data.toString());
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 * 
	 * @create 2014/07/22
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public void clear() {
		super.clear();
		setSrc(null);
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#canFocus()
	 * @return
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	@Override
	public boolean canFocus() {
		return isVisible() && isEnabled();
	}
	
	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br />
	 * 
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @create 2016/04/04
	 * @return 常用インスタンス（クローン）
	 * @author kobayashi
	 * @since 3.17.1
	 */
	@Override
	public GPLinkedImg createPracticalInstance() throws GViewException {
		GPLinkedImg clone = (GPLinkedImg) super.createPracticalInstance();
		clone.setImgstyle((GStyle) this.getDecodeImgstyle().clone());
		clone.setImgstyleclass((GStyleClass) this.getDecodeImgstyleclass().clone());
		return clone;
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#reset()
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPLinkedImg control = (GPLinkedImg) getRepository();
		setAlt(control == null ? null : control.getAlt());
		setIsmap(control == null ? null : control.getIsmap());
		setLongdesc(control == null ? null : control.getLongdesc());
		setSrc(control == null ? null : control.getSrc());
		setUsemap(control == null ? null : control.getUsemap());
		setCharset(control == null ? null : control.getCharset());
		setCoords(control == null ? null : control.getCoords());
		setHref(control == null ? null : control.getHref());
		setHreflang(control == null ? null : control.getHreflang());
		setOncontextmenu(control == null ? null : control.getOncontextmenu());
		setRel(control == null ? null : control.getRel());
		setRev(control == null ? null : control.getRev());
		setShape(control == null ? null : control.getShape());
		setType(control == null ? null : control.getType());
		setTarget(control == null ? null : control.getTarget());
		setEnabled(control == null ? null : control.getEnabled());
		setImgstyle(control == null ? null : control.getImgstyle());
		setImgstyleclass(control == null ? null : control.getImgstyleclass());
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @return alt属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getAlt() {
		return _alt;
	}
	
	/**
	 * charset属性の値を取得します.<br />
	 * 
	 * @return charset属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getCharset() {
		return _charset;
	}

	/**
	 * coords属性の値を取得します.<br />
	 * 
	 * @return coords属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getCoords() {
		return _coords;
	}

	/**
	 * imgstyle属性の値を取得します.<br />
	 * 
	 * @return imgstyle属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public GStyle getDecodeImgstyle() {
		if (_imgstyle == null) {
			_imgstyle = new GStyle();
		}
		return _imgstyle;
	}

	/**
	 * imgstyleclass属性の値を取得します.<br />
	 * 
	 * @return imgstyleclass属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public GStyleClass getDecodeImgstyleclass() {
		if (_imgstyleclass == null) {
			_imgstyleclass = new GStyleClass();
		}
		return _imgstyleclass;
	}

	/**
	 * href属性の値を取得します.<br />
	 * 
	 * @return href属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getHref() {
		return _href;
	}

	/**
	 * hreflang属性の値を取得します.<br />
	 * 
	 * @return hreflang属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getHreflang() {
		return _hreflang;
	}

	/**
	 * imgstyle属性の値を取得します.<br />
	 * 
	 * @return imgstyle属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getImgstyle() {
		if (_imgstyle != null && !_imgstyle.isEmpty()) {
			return _imgstyle.encode();
		}
		return null;
	}

	/**
	 * imgstyleclass属性の値を取得します.<br />
	 * 
	 * @return imgstyleclass属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getImgstyleclass() {
		if (_imgstyleclass != null && !_imgstyleclass.isEmpty()) {
			return _imgstyleclass.encode();
		}
		return null;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @return ismap属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getIsmap() {
		return _ismap;
	}

	/**
	 * longdesc属性の値を取得します.<br />
	 * 
	 * @return longdesc属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getLongdesc() {
		return _longdesc;
	}

	/**
	 * oncontextmenu属性の値を取得します.<br />
	 * 
	 * @return oncontextmenu
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getOncontextmenu() {
		return _oncontextmenu;
	}

	/**
	 * rel属性の値を取得します.<br />
	 * 
	 * @return rel属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getRel() {
		return _rel;
	}

	/**
	 * rev属性の値を取得します.<br />
	 * 
	 * @return rev属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getRev() {
		return _rev;
	}

	/**
	 * shape属性の値を取得します.<br />
	 * 
	 * @return shape属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getShape() {
		return _shape;
	}

	/**
	 * src属性の値を取得します.<br />
	 * 
	 * @return src属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getSrc() {
		return _src;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @return target属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * type属性の値を取得します.<br />
	 * 
	 * @return type属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getType() {
		return _type;
	}

	/**
	 * usemap属性の値を取得します.<br />
	 * 
	 * @return usemap属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getUsemap() {
		return _usemap;
	}

	/**
	 * サーバサイド・クリッカブルマップであるかどうかを取得します.
	 * 
	 * @return <code>true</code>:有効 / <code>false</code>:無効
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public boolean isIsmap() {
		return GBooleanUtils.toBoolean(_ismap, false);
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl#isClear()
	 * @return <code>false:非クリア対象</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 * @since
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @param alt alt属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setAlt(String alt) {
		_alt = alt;
	}
	
	/**
	 * charset属性の値を設定します.<br />
	 * 
	 * @param charset charset属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setCharset(String charset) {
		_charset = charset;
	}

	/**
	 * coords属性の値を設定します.<br />
	 * 
	 * @param coords coords属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setCoords(String coords) {
		_coords = coords;
	}

	/**
	 * href属性の値を設定します.<br />
	 * 
	 * @param href href属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setHref(String href) {
		_href = href;
	}

	/**
	 * hreflang属性の値を設定します.<br />
	 * 
	 * @param hreflang hreflang属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setHreflang(String hreflang) {
		_hreflang = hreflang;
	}

	/**
	 * imgstyle属性の値を設定します.<br />
	 * 
	 * @param imgstyle imgstyle属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyle(GStyle imgstyle) {
		_imgstyle = imgstyle;
	}

	/**
	 * imgstyle属性の値を設定します.<br />
	 * 
	 * @param imgstyle imgstyle属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyle(String imgstyle) {
		_imgstyle = imgstyle == null ? null : new GStyle(imgstyle);
	}

	/**
	 * imgstyleclass属性の値を設定します.<br />
	 * 
	 * @param imgstyleclass imgstyleclass属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyleclass(GStyleClass imgstyleclass) {
		_imgstyleclass = imgstyleclass;
	}

	/**
	 * imgstyleclass属性の値を設定します.<br />
	 * 
	 * @param imgstyleclass imgstyleclass属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyleclass(String imgstyleclass) {
		_imgstyleclass = imgstyleclass == null ? null : new GStyleClass(imgstyleclass);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @param ismap ismap属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setIsmap(boolean ismap) {
		_ismap = String.valueOf(ismap);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @param ismap ismap属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setIsmap(String ismap) {
		_ismap = ismap;
	}

	/**
	 * longdesc属性の値を設定します.<br />
	 * 
	 * @param longdesc longdesc属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setLongdesc(String longdesc) {
		_longdesc = longdesc;
	}

	/**
	 * oncontextmenu属性の値を設定します.<br />
	 * 
	 * @param oncontextmenu oncontextmenu属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setOncontextmenu(String oncontextmenu) {
		_oncontextmenu = oncontextmenu;
	}

	/**
	 * rel属性の値を設定します.<br />
	 * 
	 * @param rel rel属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setRel(String rel) {
		_rel = rel;
	}

	/**
	 * rev属性の値を設定します.<br />
	 * 
	 * @param rev rel属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setRev(String rev) {
		_rev = rev;
	}

	/**
	 * shape属性の値を設定します.<br />
	 * 
	 * @param shape shape属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setShape(String shape) {
		_shape = shape;
	}

	/**
	 * src属性の値を設定します.<br />
	 * 
	 * @param src src属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setSrc(String src) {
		_src = src;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @param target target属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setTarget(String target) {
		_target = target;
	}

	/**
	 * type属性の値を設定します.<br />
	 * 
	 * @param type type属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setType(String type) {
		_type = type;
	}

	/**
	 * usemap属性の値を設定します.<br />
	 * 
	 * @param usemap usemap属性の値
	 * @create 2013/06/06
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setUsemap(String usemap) {
		_usemap = usemap;
	}
}
