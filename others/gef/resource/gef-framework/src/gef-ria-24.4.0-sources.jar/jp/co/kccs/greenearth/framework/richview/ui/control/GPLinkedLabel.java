/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.Date;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;

/**
 * リンクラベルを表すUIコントロールです.<br />
 * 
 * @create 2013/06/04
 * @author yamashita
 * @since 3.12.0
 */
public class GPLinkedLabel extends GVariableControlBase implements GFormatControl {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5286187706604958358L;
	// XHTML属性
	/** charset属性の値. */
	private String _charset = null;
	/** coords属性の値. */
	private String _coords = null;
	/** href属性の値. */
	private String _href = null;
	/** hreflang属性の値. */
	private String _hreflang = null;
	/** rel属性の値. */
	private String _rel = null;
	/** rev属性の値. */
	private String _rev = null;
	/** shape属性の値. */
	private String _shape = null;
	/** type属性の値. */
	private String _type = null;
	/** target属性の値. */
	private String _target = null;
	/** oncontextmenu属性の値. */
	private String _oncontextmenu = null;

	// 拡張属性
	/** value属性の値. */
	private Object _object = null;
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;

	/**
	 * {@link GPLinkedLabel}のインスタンスを初期化します.<br />
	 * 
	 * @create 2013/06/04
	 * @author yamashita
	 * @since 3.12.0
	 */
	public GPLinkedLabel() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br> {@link GHidden}のvalue属性に<code>null</code>
	 * を設定します。<br>
	 * 
	 * id属性を除く必須属性も全てクリアされますので、{@link GPLabel#clear()}実行後は必須属性に値を設定してください。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#clear()
	 * @create 2013/06/11
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);
	}
	
	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @param data 表示内容
	 * @create 2013/06/04
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public void loadData(Object data) {
		setObject(data);
	}

	/**
	 * コントロールの状態をリセットします.<br>
	 * 
	 * @create 2013/06/04
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPLinkedLabel control = (GPLinkedLabel) getRepository();
		setCharset(control == null ? null : control.getCharset());
		setCoords(control == null ? null : control.getCoords());
		setFormat(control == null ? null : control.getFormat());
		setHref(control == null ? null : control.getHref());
		setHreflang(control == null ? null : control.getHreflang());
		setOncontextmenu(control == null ? null : control.getOncontextmenu());
		setLocale(control == null ? null : control.getLocale());
		setRel(control == null ? null : control.getRel());
		setRev(control == null ? null : control == null ? null : control.getRev());
		setShape(control == null ? null : control.getShape());
		setType(control == null ? null : control.getType());
		setTarget(control == null ? null : control.getTarget());
		setValue(control == null ? null : control.getValue());
	}

	/**
	 * charset属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return charset属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getCharset() {
		return _charset;
	}

	/**
	 * coords属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return coords属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getCoords() {
		return _coords;
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return 書式文字列
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * href属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return href属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getHref() {
		return _href;
	}

	/**
	 * hreflang属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return hreflang属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getHreflang() {
		return _hreflang;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/07/06
	 * @return ロケール
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * oncontextmenu属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return oncontextmenu属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getOncontextmenu() {
		return _oncontextmenu;
	}

	/**
	 * rel属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return rel属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getRel() {
		return _rel;
	}

	/**
	 * rev属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return rev属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getRev() {
		return _rev;
	}

	/**
	 * クリッカブルマップの有効範囲となる領域の形状を取得します.<br />
	 * 
	 * @return <code>defalut</code>/<code>rect</code>/<code>circle</code>/
	 *         <code>poly</code>
	 * @create 2013/06/04
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getShape() {
		return _shape;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return target属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * type属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return type属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getType() {
		return _type;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getValue() {
		if (_object instanceof Date) {
			return GUIUtils.formatDateToString((Date) _object, _format, GCoreUtils.getLocale(_locale));
		} else if (_object instanceof Number) {
			return GUIUtils.formatNumberToString((Number) _object, _format, GCoreUtils.getLocale(_locale));
		} else {
			return _object == null ? null : _object.toString();
		}
	}

	/**
	 * value属性の値をObjectで取得します.<br />
	 * 
	 * @create 2014/05/29
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.16.0
	 */
	public Object getObject() {
		return _object;
	}

	/**
	 * charset属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param charset charset属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setCharset(String charset) {
		_charset = charset;
	}

	/**
	 * coords属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param coords coords属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setCoords(String coords) {
		_coords = coords;
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param format 書式文字列
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * href属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param href href属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setHref(String href) {
		_href = href;
	}

	/**
	 * hreflang属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param hreflang hreflang属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setHreflang(String hreflang) {
		_hreflang = hreflang;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/07/06
	 * @param locale ロケール
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * oncontextmenu属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param oncontextmenu oncontextmenu属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setOncontextmenu(String oncontextmenu) {
		_oncontextmenu = oncontextmenu;
	}

	/**
	 * rel属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param rel rel属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setRel(String rel) {
		_rel = rel;
	}

	/**
	 * rev属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param rev rev属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setRev(String rev) {
		_rev = rev;
	}

	/**
	 * shape属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param shape shape属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setShape(String shape) {
		_shape = shape;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param target target属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setTarget(String target) {
		_target = target;
	}

	/**
	 * type属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param type type属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setType(String type) {
		_type = type;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setValue(String value) {
		setObject(value);
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2014/05/29
	 * @param value value属性の値
	 * @author hashimoto
	 * @since 3.16.0
	 */
	public void setObject(Object value) {
		_object = value;
	}
	
	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2013/06/11
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}
}