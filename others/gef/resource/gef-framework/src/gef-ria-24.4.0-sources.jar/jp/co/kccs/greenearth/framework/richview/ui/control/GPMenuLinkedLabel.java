/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.menu.GMenu;

/**
 * リンク先をメニューIDで指定するリンク機能を持ったラベルを表すUIコンポーネントです.<br />
 * 
 * @create 2013/07/17
 * @author kawakami
 * @since 3.12.0
 */
public class GPMenuLinkedLabel extends GPLinkedLabel {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7493425055801729206L;

	// 拡張属性
	/** menu属性の値. */
	private String _menu = null;
	
	/**
	 * {@link GPMenuLinkedLabel}の新しいインスタンスを生成します。<br />
	 * 
	 * @create 2013/07/17
	 * @author kawakami
	 * @since 3.12.0
	 */
	public GPMenuLinkedLabel() {
	}
	
	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.GPLinkedLabel#loadData(java.lang.Object)
	 * @create 2013/07/17
	 * @param {GMenu} メニュー
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	public void loadData(Object data) {
		if (data instanceof GMenu) {
			loadMenu((GMenu) data);
		}
	}
	
	/**
	 * このコントロールの属性値を初期状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.GPLinkedLabel#reset(java.lang.Object)
	 * @create 2011/07/17
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPMenuLinkedLabel control = (GPMenuLinkedLabel) getRepository();
		setMenu(control == null ? null : control.getMenu());
	}
	
	/**
	 * 指定されたメニューを読込みます.<br />
	 * 
	 * @create 2013/07/17
	 * @param menu メニューアイテム
	 * @author kawakami
	 * @since 3.12.0
	 */
	protected void loadMenu(GMenu menu) {
		setMenu(menu.getMenuID());
		Locale locale = GFrameworkContext.getInstance().getLocale();
		super.loadData(GStringUtils.nullToBlank(menu.getDisplayName(locale)));
		if (!(GStatus.Active == menu.getStatus())) {
			setEnabled(false);
		}
	}
	
	/**
	 * href属性の値を設定します.<br/>
	 * ※本メソッドはサポートしません。
	 * 
	 * @create 2013/07/20
	 * @param href href属性の値
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	public void setHref(String href) {
	}

	/**
	 * hreflang属性の値を設定します.<br/>
	 * ※本メソッドはサポートしません。
	 * 
	 * @create 2013/07/20
	 * @param hreflang hreflang属性の値
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	public void setHreflang(String hreflang) {
	}
	
	/**
	 * menu属性の値を取得します.<br />
	 * 
	 * @create 2013/07/17
	 * @return メニューID
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getMenu() {
		return _menu;
	}

	/**
	 * menu属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param menu メニューID
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setMenu(String menu) {
		this._menu = menu;
	}
}
