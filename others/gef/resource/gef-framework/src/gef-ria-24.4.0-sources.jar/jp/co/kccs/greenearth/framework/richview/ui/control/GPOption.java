/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;

/**
 * セレクトコントロールのオプションを表すUIアイテムです.<br />
 * 
 * @create 2011/05/13
 * @author hamanaka
 * @since 3.9.0
 */
public class GPOption extends GUIItemBase implements GSelectOption, GEnablable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2461148141747916957L;
	// XHTML属性
	/** value属性の値. */
	private String _value = null;
	/** enabled属性の値. */
	private String _enabled = null;
	/** label属性の値. */
	private String _label = null;
	//拡張属性
	/** labelid属性の値. */
	private String _labelid = null;
	// 内部変数
	/** {@link GPOption}の選択状態. */
	private String _selected = null;

	/**
	 * {@link GPOption}の新しいインスタンスを初期化します.<br />
	 * 
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPOption() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * *id属性を除く必須属性も全てクリアされますので、{@link GPOption#clear()}実行後は必須属性に値を設定してください。<br>
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		setSelected(false);
	}

	/**
	 * このコントロール及び子コントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIComponentBase#reset()
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPOption control = (GPOption) getRepository();
		setEnabled(control == null ? (String) null : control.getEnabled());
		setLabel(control == null ? (String) null : control.getLabel());
		setLabelid(control == null ? (String) null : control.getLabelid());
		setValue(control == null ? (String) null : control.getValue());
		setSelected(control == null ? (String) null : control.getSelected());
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/05/25
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * labelの値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return labelの値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getLabel() {
		if (getLabelid() != null) {
			return GMessageResources.getMessage(getLabelid());
		} else {
			return _label;
		}
	}
	
	/**
	 * labelid属性の値を取得します．<br />
	 * 
	 * @return labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public String getLabelid() {
		return _labelid;
	}

	/**
	 * オプションの選択状態を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return <code>true:選択</code>/<code>false:未選択</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getSelected() {
		return _selected;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getValue() {
		return _value;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}

	/**
	 * オプションの選択状態を取得します.<br />
	 * 
	 * @create 2011/05/25
	 * @return <code>true:選択</code>/<code>false:未選択</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public boolean isSelected() {
		return GBooleanUtils.toBoolean(_selected, false);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * label属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param label label属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void setLabel(String label) {
		_label = label;
	}
	
	/**
	 * labelid属性の値を設定します.<br />
	 * 
	 * @param labelid labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public void setLabelid(String labelid) {
		_labelid = labelid;
	}

	/**
	 * オプションの選択状態を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param selected <code>true:選択</code>/<code>false:未選択</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void setSelected(boolean selected) {
		_selected = String.valueOf(selected);
	}

	/**
	 * オプションの選択状態を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param selected <code>true:選択</code>/<code>false:未選択</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSelected(String selected) {
		_selected = selected;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}

}
