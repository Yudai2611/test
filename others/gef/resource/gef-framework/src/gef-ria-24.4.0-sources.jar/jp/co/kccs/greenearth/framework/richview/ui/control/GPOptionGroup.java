/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * セレクトコントロールのオプショングループを表すUIアイテムです.<br />
 * 
 * @create 2011/05/17
 * @author hamanaka
 * @since 3.9.0
 */
public class GPOptionGroup extends GUIItemBase implements GSelectOption, GEnablable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3513025855751706164L;
	// XHTML属性
	/** enabled属性の値. */
	private String _enabled = null;
	/** label属性の値. */
	private String _label = null;
	//拡張属性
	/** labelid属性の値. */
	private String _labelid = null;
	// 内部変数
	/** {@link GPOption}オブジェクトのリスト. */
	private List<GPOption> _selectOptions = new LinkedList<GPOption>();

	/**
	 * デフォルトコンストラクタ.<br>
	 * 新しい{@link GPOptionGroup}のインスタンスを初期化します。
	 * 
	 * @create 2011/05/17
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPOptionGroup() {
	}

	/**
	 * オプションのリストにオプションを追加します.<br>
	 * 
	 * @param selectOption オプション
	 * @create 2011/05/17
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void addSelectOption(GPOption selectOption) {
		selectOption.setParent(this);
		_selectOptions.add(selectOption);
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		if (getSelectOptions() != null) {
			for (GPOption selectOption : getSelectOptions()) {
				selectOption.clear();
			}
		}
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIComponent#createPracticalInstance()
	 * @return 常用インスタンス（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @create 2011/05/17
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public GPOptionGroup createPracticalInstance() throws GViewException {
		GPOptionGroup clone = (GPOptionGroup) super.createPracticalInstance();
		if (_selectOptions != null) {
			// オプションのリストのコピー
			List<GPOption> destSelectOptions = new LinkedList<GPOption>();
			for (GPOption selectOption : _selectOptions) {
				GPOption destSelectOption = (GPOption) selectOption.createPracticalInstance();
				destSelectOptions.add(destSelectOption);
				destSelectOption.setParent(clone);
			}
			clone._selectOptions = destSelectOptions;
		}

		return clone;
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。
	 * 
	 * @param element 読み込み対象JSPエレメント
	 * @create 2011/05/13
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * このコントロール及び子コントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIComponentBase#reset()
	 * @create 2011/05/17
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPOptionGroup control = (GPOptionGroup) getRepository();
		setEnabled(control == null ? null : control.getEnabled());
		setLabel(control == null ? (String) null : control.getLabel());
		setLabelid(control == null ? (String) null : control.getLabelid());
		for (GPOption con : getSelectOptions()) {
			con.reset();
		}
	}

	/**
	 * オプションのリストを設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param selectOptions オプションのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSelectOptions(List<GPOption> selectOptions) {
		_selectOptions = selectOptions;

		for (GPOption selectOption : selectOptions) {
			selectOption.setParent(this);
		}
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @create 2011/05/13
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		try {
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GPOption.class.isAssignableFrom(clazz)) {
					// JSPの要素をUIコントロールに読み込みます
					GPOption selectOption = (GPOption) clazz.newInstance();
					selectOption.loadJspElement((Element) child);
					addSelectOption(selectOption);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/05/17
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * labelの値を取得します.<br />
	 * 
	 * @create 2011/05/17
	 * @return labelの値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getLabel() {
		if (getLabelid() != null) {
			return GMessageResources.getMessage(getLabelid());
		} else {
			return _label;
		}
	}
	
	/**
	 * labelid属性の値を取得します.<br />
	 * 
	 * @return labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public String getLabelid() {
		return _labelid;
	}

	/**
	 * 指定されたインデックスの{@link GPOption}を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @param index インデックス
	 * @return {@link GPOption}
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPOption getSelectOption(int index) {
		return _selectOptions.get(index);
	}

	/**
	 * オプションのリストを取得します.<br />
	 * 
	 * @create 2011/05/17
	 * @return オプションのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public List<GPOption> getSelectOptions() {
		return _selectOptions;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/05/17
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * label属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param label label属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void setLabel(String label) {
		_label = label;
	}

	/**
	 * labelid属性の値を設定します.<br />
	 * 
	 * @param labelid labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public void setLabelid(String labelid) {
		_labelid =labelid;
	}
	
	/**
	 * value属性の値を取得します.<br />
	 * ※本メソッドはサポートしていません。
	 * 
	 * @create 2014/01/23
	 * @return value属性の値
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public String getValue() {
		return null;
	}

	/**
	 * オプションの選択状態を取得します.<br />
	 * ※本メソッドはサポートしていません。
	 * 
	 * @create 2011/05/25
	 * @return <code>true:選択</code>/<code>false:未選択</code>
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public boolean isSelected() {
		return false;
	}

	/**
	 * オプションの選択状態を設定します.<br />
	 * ※本メソッドはサポートしていません。
	 * 
	 * @create 2014/01/23
	 * @param selected <code>true:選択</code>/<code>false:未選択</code>
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public void setSelected(boolean selected) {
	}

	/**
	 * value属性の値を設定します.<br />
	 * ※本メソッドはサポートしていません。
	 * 
	 * @create 2014/01/23
	 * @param value value属性の値
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public void setValue(String value) {
	}
}
