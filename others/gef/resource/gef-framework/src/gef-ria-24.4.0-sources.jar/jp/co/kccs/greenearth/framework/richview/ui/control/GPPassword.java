/*
 * Copyright 2013-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * パスワードを表すUIコントロールです.<br />
 * 
 * @create 2013/03/14
 * @author yamashita
 * @since 3.10.0.D
 */
public class GPPassword extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8264697684168290559L;
	// XHTML属性
	/** autocomplete属性の値. */
	private String _autocomplete = null;
	/** maxlength属性の値. */
	private String _maxlength = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** size属性の値. */
	private String _size = null;
	/** value属性の値. */
	private String _value = null;
	/** placeholder属性の値. */
	private String _placeholder = null;
	/** noFocusOnReadonly属性の値 */
	private String _noFocusOnReadonly = null;
	/** redisplay属性の値. */
	private String _redisplay = null;

	/**
	 * {@link GPPassword}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/14
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public GPPassword() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 * 
	 * @create 2013/03/14
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param data 表示内容
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void loadData(Object data) {
		setValue(data == null ? null : data.toString());
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2013/03/14
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		GPPassword control = (GPPassword) getRepository();
		setAutocomplete(control == null ? null : control.getAutocomplete());
		setMaxlength(control == null ? null : control.getMaxlength());
		setReadonly(control == null ? null : control.getReadonly());
		setSize(control == null ? null : control.getSize());
		setValue(control == null ? null : control.getValue());
		setNoFocusOnReadonly(control == null ? null : control.getNoFocusOnReadonly());
		setRedisplay(control == null ? null : control.getRedisplay());
	}

	/**
	 * autocomplete属性の値を取得します.<br />
	 * 
	 * @return autocomplete属性の値
	 * @create 2014/03/12
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * maxlength属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return maxlength属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getMaxlength() {
		return _maxlength;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * redisplay属性を取得します.<br />
	 * 
	 * @return redisplay属性の値
	 * @author kobayashi
	 * @create 2016/09/16
	 * @since 3.19.0
	 */
	public String getRedisplay() {
		return _redisplay;
	}

	/**
	 * size属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return size属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * オートコンプリート機能の有効/無効を取得します.<br>
	 * <code>off</code>の場合のみ、<code>false</code>を返します。
	 * 
	 * @return <code>true</code>：有効/<code>false</code>：無効
	 * @create 2014/03/12
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public boolean isAutocomplete() {
		if (_autocomplete == null) {
			return true;
		} else {
			return !"off".equals(_autocomplete.toLowerCase());
		}
	}

	/**
	 * 状態の読み込み専用 / 書き込み可能を判定します.<br>
	 * 
	 * @create 2013/03/14
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 * 
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}

	/**
	 * 入力したパスワードを再表示するかを判定します.<br>
	 * 
	 * @create 2016/09/17
	 * @return <code>true<code>：再表示する / <code>false<code>：再表示しない
	 * @author kobayashi
	 * @since 3.19.0
	 */
	public boolean isRedisplay() {
		return GBooleanUtils.toBoolean(_redisplay, true);
	}

	/**
	 * 引数のbooleanから、autocomplete属性の値を設定します.<br />
	 * <code>true</code>:on<br>
	 * <code>false</code>:off<br>
	 * 
	 * @param autocomplete autocomplete属性の値
	 * @create 2014/03/12
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public void setAutocomplete(boolean autocomplete) {
		_autocomplete = autocomplete ? "on" : "off";
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @param autocomplete autocomplete属性の値
	 * @create 2014/03/12
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * maxlength属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param length maxlength属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setMaxlength(String length) {
		_maxlength = length;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param readonly readonly属性の値
	 * @author kobayashi
	 * @since 3.10.0.D
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * size属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param size size属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setValue(String value) {
		_value = value;
	}
	/**
	 *　placeholder属性の値を設定します。
	 * 
	 * @param placeholder placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public void setPlaceholder(String placeholder) {
		_placeholder = placeholder;
	}
	/**
	 * placeholder属性の値を取得します。
	 * 
	 * @return placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public String getPlaceholder() {
		return _placeholder;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}
	

	/**
	 * redisplay属性の値を設定します.<br />
	 * 
	 * @param redisplay属性の値
	 * @author kobayashi
	 * @create 2016/09/16
	 * @since 3.19.0
	 */
	public void setRedisplay(String redisplay) {
		_redisplay = redisplay;
	}

	/**
	 * redisplay属性の値を設定します.<br />
	 * 
	 * @param redisplay属性の値
	 * @author kikuchi
	 * @create 2017/03/01
	 * @since 3.19.2
	 */
	public void setRedisplay(boolean redisplay) {
		_redisplay = String.valueOf(redisplay);
	}
}
