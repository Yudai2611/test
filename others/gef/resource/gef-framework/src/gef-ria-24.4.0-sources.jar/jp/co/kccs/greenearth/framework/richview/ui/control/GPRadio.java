/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * ラジオボタンを表すUIコンポーネントです.<br>
 * 
 * @create 2011/06/01
 * @author hamanaka
 * @since 3.9.0
 */
public class GPRadio extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 2474847759748594889L;

	// XHTML属性
	/** checked属性の値. */
	private String _checked = null;
	/** value属性の値. */
	private String _value = null;

	/**
	 * {@link GPRadio}の新しいインスタンスを初期化します.<br>
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPRadio() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#clear()
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();

		setChecked(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * 指定された値が<code>value</code>フィールドの値と同じ場合のみ、チェック状態を有効にします。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#loadData(Object)
	 * @create 2011/06/01
	 * @param data チェック状態の内容
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void loadData(Object data) {
		if (data != null && getValue() != null) {
			if (getValue().equals(data.toString())) {
				setChecked(true);
				return;
			}
		}
		setChecked(false);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#reset()
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPRadio control = (GPRadio) getRepository();
		setName(control == null ? null : control.getName());
		setChecked(control == null ? null : control.getChecked());
		setValue(control == null ? null : control.getValue());
	}

	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return checked属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getChecked() {
		return _checked;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return checked属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isChecked() {
		return GBooleanUtils.toBoolean(_checked, false);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param checked checked属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setChecked(boolean checked) {
		_checked = String.valueOf(checked);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param checked checked属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setChecked(String checked) {
		_checked = checked;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
