/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.UUID;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * ラジオグループを表すUIコンポーネントです.<br>
 * 
 * @create 2013/06/12
 * @author kawakami
 * @since RIA WF
 */
public class GPRadioGroup extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3996800385603883316L;

	// XHTML属性
	/** value属性の値. */
	private String _value = null;

	// 拡張属性
	/** readonly属性の値. */
	private String _readonly = null;
	
	/** radioOptionのname属性の値. */
	private String _radioOptionName = null;

	/**
	 * {@link GPRadioGroup}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public GPRadioGroup() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * 
	 * {@link GPRadioGroup}では常にフォーカスは当てられません。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#canFocus()
	 * @return <code>false</code>
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	@Override
	public boolean canFocus() {
		return false;
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * {@link GPRadioGroup}のvalue属性に<code>null</code> を設定します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#clear()
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	@Override
	public void clear() {
		super.clear();
		// 値の状態
		setValue(null);
	}

	/**
	 * 指定された値を文字列変換し読み込みます.<br>
	 * 
	 * 値が<code>null</code>の場合は、<code>null</code>を読み込みます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#loadData(java.lang.Object)
	 * @param data 表示内容
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	@Override
	public void loadData(Object data) {
		setValue(data == null ? null : data.toString());
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#reset()
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	@Override
	public void reset() {
		super.reset();
		GPRadioGroup control = (GPRadioGroup) getRepository();
		setValue(control == null ? null : control.getValue());
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * value属性の値を取得します.<br />
	 * @return value属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * @return readonly属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}
	
	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setReadOnly(boolean readonly) {
		_readonly = Boolean.toString(readonly);
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @param value value属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setValue(String value) {
		_value = value;
	}
	
	/**
	 * radioOptionName属性の値を取得します.<br />
	 * @return radioOptionName属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public String getRadioOptionName() {
		if (_radioOptionName == null) {
			_radioOptionName = UUID.randomUUID().toString();
		}
		return _radioOptionName;
	}

}
