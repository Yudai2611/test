/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * ラジオグループを表すUIコンポーネントです.<br>
 * 
 * @create 2013/06/12
 * @author kawakami
 * @since RIA WF
 */
public class GPRadioOption extends GUIControlBase implements GEnablable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5492307428453869249L;

	// XHTML属性
	/** value属性の値 */
	private String _value = null;

	// 拡張属性
	/** enabled属性の値. */
	private String _enabled = null;
	/** readonly属性の値 */
	private String _readonly = null;
	/** radiogroup属性の値 */
	private String _radiogroup = null;

	/**
	 * {@link GPRadioOption}の新しいインスタンスを初期化します.<br>
	 * 
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public GPRadioOption() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * 
	 * 以下のいずれかの場合、フォーカスは当てられません。<br>
	 * ・visibleフィールドが<code>false</code><br>
	 * ・enableフィールドが<code>false</code><br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#canFocus()
	 * @return <code>true</code>/<code>false</code>
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	@Override
	public boolean canFocus() {
		return isVisible() && isEnabled();
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#reset()
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	@Override
	public void reset() {
		super.reset();
		GPRadioOption control = (GPRadioOption) getRepository();
		setValue(control == null ? null : control.getValue());
		setEnabled(control == null ? null : control.getEnabled());
		setRadiogroup(control == null ? null : control.getRadiogroup());
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @return タグの<code>true:有効</code>/<code>false:無効</code>
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * リクエストパラメータに含まれるキー
	 * 
	 * @return パラメータキー
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	@Override
	public String getParameterKey() {
		return _radiogroup;
	}

	/**
	 * radiogroup属性の値を取得します.<br />
	 * 
	 * @return ラジオグループのid属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public String getRadiogroup() {
		return this._radiogroup;
	}

	/**
	 * タグの有効/無効を取得します.<br />
	 * 
	 * @return 有効=true、無効=false
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @param enabled タグの<code>true:有効</code>/<code>false:無効</code>
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @param enabled タグの<code>true:有効</code>/<code>false:無効</code>
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * readonlyの状態を取得します.<br />
	 * 
	 * @return readonly=true、readonlyでない=false
	 * @create 2013/06/17
	 * @author kawakami
	 * @since RIA WF
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}
	/**
	 * readonlyの状態を取得します.<br />
	 * 
	 * @return readonly=true、readonlyでない=false
	 * @create 2013/06/17
	 * @author kawakami
	 * @since RIA WF
	 */
	public String getReadonly() {
		return _readonly;
	}
	/**
	 * readonlyd属性の値を設定します.<br />
	 * 
	 * @param readonly タグの<code>true:readonly</code>/<code>false:raedonlyでない</code>
	 * @create 2013/06/17
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readony属性の値を設定します.<br />
	 * 
	 * @param readonly タグの<code>true:readonly</code>/<code>false:readonlyでない</code>
	 * @create 2013/06/17
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}
	
	/**
	 * radiogroup属性の値を設定します.<br />
	 * 
	 * @param radiogroup ラジオグループのid属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setRadiogroup(String radiogroup) {
		this._radiogroup = radiogroup;
	}

	/**
	 * 値を設定します.<br />
	 * 
	 * @param value submitする値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setValue(String value) {
		_value = value;
	}
	
	/**
	 * 値を取得します.<br />
	 * 
	 * @return value 値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public String getValue() {
		return _value;
	}
}
