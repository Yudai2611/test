/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.LinkedList;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * セレクトを表すUIコンポーネントです.<br />
 * 
 * @create 2011/06/01
 * @author hamanaka
 * @since 3.9.0
 */
public class GPSelect extends GVariableControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5560249260039324096L;
	/** span要素を出力する際にid属性に付加される値. */
	public static final String LABEL_ID = "_lbl";

	// XHTML属性
	/** size属性の値. */
	private String _size = null;

	// 拡張属性
	/** value属性の値. */
	private String _value = null;
	/** readonly属性の値. */
	private String _readonly = null;

	// 内部変数
	/** {@link GSelectOption}オブジェクトのリスト. */
	private List<GSelectOption> _selectOptions = new LinkedList<GSelectOption>();

	/**
	 * {@link GPSelect}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPSelect() {
	}

	/**
	 * オプションのリストにオプションを追加します.<br>
	 * 
	 * @create 2011/06/01
	 * @param selectOption オプション
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void addSelectOption(GSelectOption selectOption) {
		selectOption.setParent(this);
		_selectOptions.add(selectOption);
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br />
	 * 
	 * @create 2014/06/24
	 * @return <code>true</code>/<code>false</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public boolean canFocus() {
		return super.canFocus() && !isReadonly();
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @see {@link GVariableControlBase#clear()}
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);

		if (getSelectOptions() != null) {
			for (GSelectOption selectOption : getSelectOptions()) {
				selectOption.clear();
			}
		}
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br>
	 * 
	 * 保持しているUIコントロールもコピーされます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#createPracticalInstance()
	 * @create 2011/06/01
	 * @return 常用インスタンス（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public GPSelect createPracticalInstance() throws GViewException {
		GPSelect clone = (GPSelect) super.createPracticalInstance();
		if (_selectOptions != null) {
			// オプションのリストのコピー
			List<GSelectOption> destSelectOptions = new LinkedList<GSelectOption>();
			for (GSelectOption selectOption : _selectOptions) {
				GSelectOption destSelectOption = (GSelectOption) selectOption.createPracticalInstance();
				destSelectOptions.add(destSelectOption);
				destSelectOption.setParent(clone);
			}
			clone._selectOptions = destSelectOptions;
		}

		return clone;
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#loadData(Object)
	 * @create 2011/06/01
	 * @param data データ
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		setValue(data == null ? null : data.toString());
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。
	 * 
	 * @create 2011/06/01
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#reset()
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPSelect control = (GPSelect) getRepository();
		setSize(control == null ? null : control.getSize());
		setValue(control == null ? null : control.getValue());
		setReadonly(control == null ? null : control.getReadonly());
		for (GSelectOption con : _selectOptions) {
			con.reset();
		}
	}

	/**
	 * オプションのリストを設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param selectOptions {@link GSelectOption}オブジェクトのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSelectOptions(List<GSelectOption> selectOptions) {
		_selectOptions = selectOptions;

		for (GSelectOption selectOption : selectOptions) {
			selectOption.setParent(this);
		}
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @create 2011/06/01
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		try {
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GSelectOption.class.isAssignableFrom(clazz)) {
					// JSPの要素をUIコントロールに読み込みます
					GSelectOption selectOption = (GSelectOption) clazz.newInstance();
					selectOption.loadJspElement((Element) child);
					addSelectOption(selectOption);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * 指定されたインデックスの{@link GSelectOption}を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @param index インデックス
	 * @return {@link GSelectOption}オブジェクト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GSelectOption getSelectOption(int index) {
		return _selectOptions.get(index);
	}

	/**
	 * オプションのリストを取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return {@link GSelectOption}オブジェクトのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public List<GSelectOption> getSelectOptions() {
		return _selectOptions;
	}

	/**
	 * size属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return size属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * size属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param size size属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}

	/**
	 * 状態の読み込み専用/書き込み可能を判定します.<br>
	 * 
	 * @create 2014/06/24
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2014/06/24
	 * @return readonly属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param readonly <code>true</code>/<code>false</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param readonly <code>true</code>/<code>false</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}
}
