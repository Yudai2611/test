/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.Date;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;

/**
 * テキストを表すUIコントロールです.<br />
 * 
 * @create 2011/04/04
 * @author yamashita
 * @since 3.9.0
 */
public class GPText extends GVariableControlBase implements GFormatControl {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5170121295125641874L;
	// XHTML属性
	/** autocomplete属性の値. */
	private String _autocomplete = null;
	/** maxlength属性の値. */
	private String _maxlength = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** size属性の値. */
	private String _size = null;
	/** value属性の値. */
	private Object _object = null;

	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;
	/** placeholder属性の値. */
	private String _placeholder = null;

	/** nofocusonreadonly属性の値 */
	private String _noFocusOnReadonly = null;

	/**
	 * {@link GPText}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPText() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br />
	 * 
	 * @create 2011/04/04
	 * @return <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public boolean canFocus() {
		return super.canFocus() && !isReadonly();
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param data 表示内容
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		setObject(data);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPText control = (GPText) getRepository();
		setAutocomplete(control == null ? null : control.getAutocomplete());
		setMaxlength(control == null ? null : control.getMaxlength());
		setReadonly(control == null ? null : control.getReadonly());
		setSize(control == null ? null : control.getSize());
		setValue(control == null ? null : control.getValue());
		setFormat(control == null ? null : control.getFormat());
		setLocale(control == null ? null : control.getLocale());
		setNoFocusOnReadonly(control == null ? null : control.getNoFocusOnReadonly());
	}

	/**
	 * autocomplete属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/08/26
	 * @return 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/08/26
	 * @return ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * maxlength属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMaxlength() {
		return _maxlength;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * size属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		Object object = getObject();
		String value = object == null ? null : object.toString();
		if (object instanceof Date) {
			value = GUIUtils.formatDateToString((Date) object, _format, GCoreUtils.getLocale(_locale));
		} else if (object instanceof Number) {
			value = GUIUtils.formatNumberToString((Number) object, _format, GCoreUtils.getLocale(_locale));
		}
		return value;
	}
	
	/**
	 * value属性の値をObject型で取得します.<br />
	 * 
	 * @create 2014/06/02
	 * @return value属性の値
	 * @author yoshida
	 * @since 3.16.0
	 */
	public Object getObject() {
		return _object;
	}

	/**
	 * オートコンプリート機能の有効 / 無効を判定します.<br>
	 * 
	 * @create 2011/04/04
	 * @return <code>true</code>：有効 / <code>false</code>：無効
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isAutocomplete() {
		if (_autocomplete == null) {
			return true;
		}
		return !"off".equals(_autocomplete.toLowerCase());
	}

	/**
	 * 状態の読み込み専用/書き込み可能を判定します.<br>
	 * 
	 * @create 2011/04/04
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param autocomplete autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAutocomplete(boolean autocomplete) {
		_autocomplete = autocomplete ? "on" : "off";
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param autocomplete autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2011/08/26
	 * @param format 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/08/26
	 * @param locale ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * maxlength属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param length maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMaxlength(String length) {
		_maxlength = length;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param readonly readonly属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * size属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param size size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		setObject(value);
	}
	
	/**
	 *　placeholder属性の値を設定します。
	 * 
	 * @param placeholder placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public void setPlaceholder(String placeholder) {
		_placeholder = placeholder;
	}
	/**
	 * placeholder属性の値を取得します。
	 * 
	 * @return placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public String getPlaceholder() {
		return _placeholder;
	}
	
	/**
	 * value属性の値をObject型で設定します.<br />
	 * 
	 * @create 2014/06/02
	 * @param object
	 * @author yoshida
	 * @since 3.16.0
	 */
	public void setObject(Object object) {
		_object = object;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 * 
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}
}

