/*
 * Copyright 2013-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * テキストエリアを表すUIコントロールです.<br />
 *
 * @create 2013/03/14
 * @author KCCS kikuchi
 * @since 3.10.0.D
 */
public class GPTextarea extends GVariableControlBase {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 321235157062088727L;

	// XHTML属性
	/** cols属性の値. */
	private String _cols = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** rows属性の値. */
	private String _rows = null;
	/** wrap属性の値. */
	private String _wrap = null;

	// 内部変数
	/** value属性の値. */
	private String _value = null;

	/** placeholder属性の値. */
	private String _placeholder = null;

	/** noFocusOnReadonly属性の値 */
	private String _noFocusOnReadonly = null;

	/**
	 * {@link GPTextarea}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2013/03/13
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public GPTextarea() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 *
	 * {@link GPTextarea}の以下の属性に<code>null</code> を設定します。<br />
	 * ・value<br />
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#clear()
	 * @create 2013/03/13
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void clear() {
		super.clear();
		setValue(null);
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#loadData(java.lang.Object)
	 * @create 2013/03/13
	 * @param data 表示内容
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void loadData(Object data) {
		setValue(data == null ? null : data.toString());
	}

	/**
	 * JSP情報を読み込みます.<br />
	 *
	 * JSPのHTMLタグの属性を、フィールドに設定します。
	 *
	 * @create 2013/03/13
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br />
	 *
	 * 画面で利用されるパラメータ名をキーにして<code>value</code>を読み込んでいます。<br />
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase#loadParameter
	 * (jp.co.kccs.greenearth.framework.GParameter)
	 * @create 2013/03/13
	 * @param parameter パラメータオブジェクト
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		if (parameter.getValuesMap().containsKey(getParameterKey())) {
			setValue(parameter.getValue(getParameterKey()));
		}
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRFieldControlBase#reset()
	 * @create 2013/03/13
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		GPTextarea control = (GPTextarea) getRepository();
		setCols(control == null ? null : control.getCols());
		setReadonly(control == null ? null : control.getReadonly());
		setRows(control == null ? null : control.getRows());
		setWrap(control == null ? null : control.getWrap());
		setValue(control == null ? null : control.getValue());
		setNoFocusOnReadonly(control == null ? null : control.getNoFocusOnReadonly());
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 *
	 * @create 2013/03/13
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			Node child = children.item(i);
			Class< ? > clazz = null;
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				GTLDConfiguration tld = GTLDConfiguration.getInstance();
				clazz = tld.getUIClass(child.getNodeName());
			}
			if (clazz != null && GPTextareaValue.class.isAssignableFrom(clazz)) {
				setValue(child.getTextContent());
			} else {
				loadNestedNode(child);
			}
		}
	}

	/**
	 * cols属性の値を取得します.<br />
	 *
	 * @create 2013/03/13
	 * @return cols属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getCols() {
		return _cols;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 *
	 * @create 2013/03/13
	 * @return readonly属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * rows属性の値を取得します.<br />
	 *
	 * @create 2013/03/13
	 * @return rows属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getRows() {
		return _rows;
	}

	/**
	 * value属性の値を取得します.<br />
	 *
	 * @create 2013/03/13
	 * @return value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * wrap属性の値を取得します.<br />
	 *
	 * @create 2013/03/13
	 * @return wrap属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getWrap() {
		return _wrap;
	}

	/**
	 * 状態の読み込み専用 / 書き込み可能を判定します.<br>
	 *
	 * @create 2013/03/13
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * cols属性の値を設定します.<br />
	 *
	 * @create 2013/03/13
	 * @param cols cols属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setCols(String cols) {
		_cols = cols;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 *
	 * @create 2013/03/13
	 * @param readonly readonly属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 *
	 * @create 2013/03/13
	 * @param readonly readonly属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * rows属性の値を設定します.<br />
	 *
	 * @create 2013/03/13
	 * @param rows rows属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setRows(String rows) {
		_rows = rows;
	}

	/**
	 * value属性の値を設定します.<br />
	 *
	 * @create 2013/03/13
	 * @param value value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setValue(String value) {
		_value = value;
	}

	/**
	 * wrap属性の値を設定します.<br />
	 *
	 * @create 2013/03/13
	 * @param wrap wrap属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setWrap(String wrap) {
		_wrap = wrap;
	}
	/**
	 *　placeholder属性の値を設定します。
	 * 
	 * @param placeholder placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public void setPlaceholder(String placeholder) {
		_placeholder = placeholder;
	}
	/**
	 * placeholder属性の値を取得します。
	 * 
	 * @return placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public String getPlaceholder() {
		return _placeholder;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public void setNoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return nofocusonreadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 * 
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}
}
