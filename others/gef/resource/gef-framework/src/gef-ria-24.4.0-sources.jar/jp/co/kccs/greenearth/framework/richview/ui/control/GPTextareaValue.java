/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;

/**
 * テキストエリアコントロールの内部テキストを表すUIアイテムです.<br />
 * 
 * @create 2013/03/14
 * @author kikuchi
 * @since 3.10.0.D
 */
public class GPTextareaValue extends GUIItemBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -223538617122558618L;

	/**
	 * {@link GPTextareaValue}の新しいインスタンスを初期化します.<br />
	 * 
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2013/03/14
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public GPTextareaValue() {
	}
}
