/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * セレクトコントロールのオプションを表します.<br>
 * 
 * @create 2011/05/26
 * @author hamanaka
 * @since 3.9.0
 */
public interface GSelectOption extends GUIItem {

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @create 2011/05/26
	 * @author hamanaka
	 * @since 3.9.0
	 */
	void clear();

	/**
	 * このコントロール及び子コントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @create 2014/01/23
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	void reset();

	/**
	 * label属性の値を取得します.<br />
	 * 
	 * @create 2014/01/23
	 * @return label属性の値
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	String getLabel();

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2014/01/23
	 * @return value属性の値
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	String getValue();

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2014/01/23
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	boolean isEnabled();

	/**
	 * オプションの選択状態を取得します.<br />
	 * 
	 * @create 2011/05/25
	 * @return <code>true:選択</code>/<code>false:未選択</code>
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	boolean isSelected();

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2014/01/23
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	void setEnabled(boolean enabled);

	/**
	 * label属性の値を設定します.<br />
	 * 
	 * @create 2014/01/23
	 * @param label label属性の値
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	void setLabel(String label);

	/**
	 * オプションの選択状態を設定します.<br />
	 * 
	 * @create 2014/01/23
	 * @param selected <code>true:選択</code>/<code>false:未選択</code>
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	void setSelected(boolean selected);

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2014/01/23
	 * @param value value属性の値
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	void setValue(String value);
}
