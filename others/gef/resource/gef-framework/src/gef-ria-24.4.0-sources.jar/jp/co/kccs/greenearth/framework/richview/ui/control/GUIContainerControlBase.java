/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.key.GEnterkeyFocus;
import jp.co.kccs.greenearth.framework.richview.ui.key.GKeyBind;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * コンテナコントロールの共通機能をまとめたクラスです.<br />
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIContainerControlBase extends GUIControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3048111741974004516L;

	// 内部変数
	/** 子要素のUIコントロールのリスト. */
	private List<GUIControl> _controls = new ArrayList<GUIControl>();
	/** {@link GKeyBind}オブジェクトのリスト */
	private List<GKeyBind> _keyBinds = new ArrayList<GKeyBind>();
	/** {@link GEnterkeyFocus}オブジェクト */
	private GEnterkeyFocus _enterkeyFocus;

	/**
	 * コンテナとして格納している子UIコントロールリストにUIコントロールを追加します.<br>
	 * 
	 * @create 2011/03/30
	 * @param control UIコントロールオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addControl(GUIControl control) {
		_controls.add(control);
		control.setParent(this);
	}

	/**
	 * キー制御を追加します.<br />
	 * 
	 * @create 2011/05/06
	 * @param keyBind キー制御
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void addKeyBind(GKeyBind keyBind) {
		_keyBinds.add(keyBind);
		keyBind.setParent(this);
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br />
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		if (getChildren() == null) {
			return;
		}
		for (GUIControl control : getChildren()) {
			control.clear();
		}
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br>
	 * 
	 * 保持しているUIコントロールもコピーされます。<br>
	 * 
	 * @create 2011/03/30
	 * @return 常用インスタンス（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GUIContainerControlBase createPracticalInstance() throws GViewException {
		GUIContainerControlBase clone = (GUIContainerControlBase) super.createPracticalInstance();

		List<GUIControl> destControls = new ArrayList<GUIControl>();
		for (GUIControl srcControl : getChildren()) {
			GUIControl destControl = (GUIControl) srcControl.createPracticalInstance();
			destControls.add(destControl);
			destControl.setParent(clone);
		}
		clone.setControls(destControls);

		List<GKeyBind> destKeyBinds = new ArrayList<GKeyBind>();
		for (GKeyBind srcKeyBind : getKeyBinds()) {
			GKeyBind destKeyBind = (GKeyBind) srcKeyBind.createPracticalInstance();
			destKeyBinds.add(destKeyBind);
			destKeyBind.setParent(clone);
		}
		clone.setKeyBinds(destKeyBinds);

		if (getEnterkeyFocus() != null) {
			GEnterkeyFocus destEnterkeyFocus = (GEnterkeyFocus) getEnterkeyFocus().createPracticalInstance();
			destEnterkeyFocus.setParent(clone);
			clone.setEnterkeyFocus(destEnterkeyFocus);
		}
		return clone;
	}

	/**
	 * 格納しているUIコントロール内から、指定したidのUIコントロールを検索します.<br>
	 * 
	 * コンテナとして格納している子UIコントロール内も検索します。 該当するUIコントロールが存在しない場合は<code>null</code>
	 * を返します。
	 * 
	 * @create 2011/04/12
	 * @param id UIコントロールid
	 * @return UIコントロールオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GUIControl findControl(String id) {
		if (id == null) {
			return null;
		}
		for (GUIControl child : getChildren()) {
			if (id.equals(child.getId())) {
				return child;
			}
			GUIControl control = child.findControl(id);
			if (control != null) {
				return control;
			}
		}
		return null;
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。
	 * 
	 * @create 2011/05/13
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br>
	 * 
	 * {@link GUIContainerControlBase}が保持しているすべての子UIコントロールに対して、
	 * {@link GUIControl#loadParameter(GParameter)}を呼び出します。<br>
	 * 
	 * @create 2011/03/30
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		super.loadParameter(parameter);
		if (parameter == null) {
			return;
		}
		for (GUIControl control : getChildren()) {
			control.loadParameter(parameter);
		}
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * {@link GUIContainerControlBase}が保持しているすべての子UIコントロールに対して、
	 * {@link GUIControl#loadResultData(GResultData)}を呼び出します。<br>
	 * 
	 * @create 2011/03/30
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		super.loadResultData(data);
		if (data == null) {
			return;
		}
		for (GUIControl control : getChildren()) {
			control.loadResultData(data);
		}
	}

	/**
	 * コントロールの検証エラーを読込みます.<br>
	 * 
	 * @create 2011/03/07
	 * @param errors 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadValidateError(List<GValidateError> errors) {
		if (errors == null) {
			return;
		}
		for (GUIControl control : getChildren()) {
			control.loadValidateError(errors);
		}
	}

	/**
	 * このコントロール及び子コントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		for (GUIControl control : getChildren()) {
			control.reset();
		}
		for (GKeyBind keyBind : getKeyBinds()) {
			keyBind.reset();
		}
		if (getEnterkeyFocus() != null) {
			getEnterkeyFocus().reset();
		}
	}

	/**
	 * コントロール入力値の検証を行います.<br />
	 * 
	 * @create 2011/04/12
	 * @param parameter パラメーター
	 * @return 検証結果のエラー配列
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public List<GValidateError> validate(GParameter parameter) {
		List<GValidateError> allErrorList = new ArrayList<GValidateError>();
		if (parameter == null) {
			return allErrorList;
		}
		for (GUIControl control : getChildren()) {
			List<GValidateError> errors = control.validate(parameter);
			if (errors != null) {
				allErrorList.addAll(errors);
			}
		}
		return allErrorList;
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @create 2011/05/13
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		try {
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GUIControl.class.isAssignableFrom(clazz)) {
					// JSPの要素をUIコントロールに読み込みます
					GUIControl control = (GUIControl) clazz.newInstance();
					control.loadJspElement((Element) child);
					addControl(control);
				} else if (clazz != null && GKeyBind.class.isAssignableFrom(clazz)) {
					GKeyBind keyBind = (GKeyBind) clazz.newInstance();
					keyBind.loadJspElement((Element) child);
					addKeyBind(keyBind);
				} else if (clazz != null && GEnterkeyFocus.class.isAssignableFrom(clazz)) {
					GEnterkeyFocus enterkeyFocus = (GEnterkeyFocus) clazz.newInstance();
					enterkeyFocus.loadJspElement((Element) child);
					setEnterkeyFocus(enterkeyFocus);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * コントロール内に格納されているコントロールのリストを取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return コントロールリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public List<GUIControl> getChildren() {
		return getControls();
	}

	/**
	 * コンテナとして格納している子UIコントロールのリストを取得します.<br>
	 * 
	 * @create 2011/03/30
	 * @return 子UIコントロールのリストオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GUIControl> getControls() {
		return _controls;
	}

	/**
	 * Enterキーフォーカス制御を返します.<br />
	 * 
	 * @create 2011/05/09
	 * @return Enterキーフォーカス制御
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GEnterkeyFocus getEnterkeyFocus() {
		return _enterkeyFocus;
	}

	/**
	 * キー制御一覧を返します.<br />
	 * 
	 * @create 2011/05/06
	 * @return キー制御一覧
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public List<GKeyBind> getKeyBinds() {
		return _keyBinds;
	}

	/**
	 * コンテナとして格納する子UIコントロールのリストを設定します.<br>
	 * 
	 * @create 2011/03/30
	 * @param controls 子UIコントロールのリストオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setControls(List<GUIControl> controls) {
		_controls = controls;
	}

	/**
	 * Enterキーフォーカス制御を設定します.<br />
	 * 
	 * @create 2011/05/09
	 * @param enterkeyFocus Enterキーフォーカス制御
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setEnterkeyFocus(GEnterkeyFocus enterkeyFocus) {
		_enterkeyFocus = enterkeyFocus;
	}

	/**
	 * キー制御一覧を設定します.<br />
	 * 
	 * @create 2011/05/06
	 * @param keyBinds キー制御一覧
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setKeyBinds(List<GKeyBind> keyBinds) {
		_keyBinds = keyBinds;
	}
}
