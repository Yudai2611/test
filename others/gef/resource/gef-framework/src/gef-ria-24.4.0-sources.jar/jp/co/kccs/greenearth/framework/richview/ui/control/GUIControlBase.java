/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase;
import jp.co.kccs.greenearth.framework.richview.ui.event.GEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * コントロールの共通機能をまとめたクラスです.<br />
 * 
 * @create 2011/03/07
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIControlBase extends GUIComponentBase implements GUIControl {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 896530723023104078L;
	// XHTML属性
	/** accesskey属性の値. */
	private String _accesskey = null;
	/** tabindex属性の値. */
	private String _tabindex = null;
	/** onblur属性の値. */
	private String _onblur = null;
	/** onchange属性の値. */
	private String _onchange = null;
	/** onfocus属性の値. */
	private String _onfocus = null;
	/** onselect属性の値. */
	private String _onselect = null;

	// 拡張属性
	/** label属性の値. */
	private String _label = null;
	/** labelid属性の値. */
	private String _labelid = null;

	/**
	 * {@link GUIControlBase}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControlBase() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br />
	 * 
	 * @create 2011/03/30
	 * @return <code>true</code>:フォーカスが当てられる/<code>false</code>:フォーカスが当てられない
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean canFocus() {
		return false;
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * ここでは何もしていません。
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void clear() {
	}

	/**
	 * このコントロールがコンテナとして機能している場合、格納しているコントロール内から、 指定した名前のコントロールを検索します.<br>
	 * 
	 * @create 2011/03/30
	 * @param id コントロール名
	 * @return 該当したコントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControl findControl(String id) {
		return null;
	}

	/**
	 * コントロールに入力フォーカスを設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void focus() {
		GWebContext context = GWebContext.getInstance();
		HttpServletRequest request = context.getRequest();
		request.setAttribute(UICONTROL_FOCUS_ID_KEY, this.getFullId());
	}

	/**
	 * 指定された値を出力内容に設定します. ここでは何もしていません。
	 * 
	 * @create 2011/03/30
	 * @param data 表示内容
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadData(Object data) {
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br>
	 * 
	 * @create 2011/03/30
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadParameter(GParameter parameter) {
		for (GEvent event : getEvents()) {
			event.loadParameter(parameter);
		}
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * @create 2011/03/30
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadResultData(GResultData data) {
		for (GEvent event : getEvents()) {
			event.loadResultData(data);
		}
	}

	/**
	 * コントロールの検証エラーを読込みます.<br>
	 * ここでは何もしていません。
	 * 
	 * @create 2011/03/30
	 * @param errors 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadValidateError(List<GValidateError> errors) {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#reset()
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GUIControlBase control = (GUIControlBase) getRepository();
		setAccesskey(control == null ? null : control.getAccesskey());
		setTabindex(control == null ? null : control.getTabindex());
		setLabel(control == null ? null : control.getLabel());
		setLabelid(control == null ? null : control.getLabelid());
		setOnblur(control == null ? null : control.getOnblur());
		setOnchange(control == null ? null : control.getOnchange());
		setOnfocus(control == null ? null : control.getOnfocus());
		setOnselect(control == null ? null : control.getOnselect());
	}

	/**
	 * コントロール入力値の検証を行います.<br />
	 * 
	 * @create 2011/03/30
	 * @param parameter パラメータオブジェクト
	 * @return 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GValidateError> validate(GParameter parameter) {
		return new ArrayList<GValidateError>();
	}

	/**
	 * コントロール入力値の検証を行います.<br />
	 * 
	 * @create 2011/03/30
	 * @param value 検証値
	 * @param errorlevel エラー実行レベル
	 * @return エラー一覧
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GValidateError> validate(String value, GErrorLevel errorlevel) {
		return new ArrayList<GValidateError>();
	}

	/**
	 * accesskey属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return accesskey属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAccesskey() {
		return _accesskey;
	}

	/**
	 * コントロール内に格納されているコントロールのリストを取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return コントロールリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GUIControl> getChildren() {
		return new ArrayList<GUIControl>();
	}

	/**
	 * labelの値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return labelの値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLabel() {
		if (getLabelid() != null) {
			return GMessageResources.getMessage(getLabelid());
		} else {
			return _label;
		}
	}
	
	/**
	 * labelid属性の値を取得します.<br />
	 * 
	 * @return labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public String getLabelid() {
		return _labelid;
	}

	/**
	 * onblur属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return onblur属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnblur() {
		return _onblur;
	}

	/**
	 * onchange属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return onchange属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnchange() {
		return _onchange;
	}

	/**
	 * onfocus属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return onfocus属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnfocus() {
		return _onfocus;
	}

	/**
	 * onselect属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return onselecｔ属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnselect() {
		return _onselect;
	}

	/**
	 * 画面で利用されるパラメータ名を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return パラメータ名
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getParameterKey() {
		return null;
	}

	/**
	 * tabindex属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return tabindex属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getTabindex() {
		return _tabindex;
	}

	/**
	 * accesskey属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param accesskey accesskey属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAccesskey(String accesskey) {
		_accesskey = accesskey;
	}

	/**
	 * label属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param label label属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLabel(String label) {
		_label = label;
	}
	
	/**
	 * labelid属性の値を設定します．<br />
	 * 
	 * @param labelid  labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public void setLabelid(String labelid) {
		_labelid = labelid;
	}

	/**
	 * onblur属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param onblur onblur属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnblur(String onblur) {
		_onblur = onblur;
	}

	/**
	 * onchange属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param onchange onchange属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnchange(String onchange) {
		_onchange = onchange;
	}

	/**
	 * onfocus属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param onfocus onfocus属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnfocus(String onfocus) {
		_onfocus = onfocus;
	}

	/**
	 * onselect属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param onselect onselect属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnselect(String onselect) {
		_onselect = onselect;
	}

	/**
	 * tabindex属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param tabindex tabindex属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTabindex(String tabindex) {
		_tabindex = tabindex;
	}
}
