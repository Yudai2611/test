/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.List;

import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.validator.GValidator;

/**
 * 値を持つコントロールであることを示すUIコンポーネントです.<br />
 * 
 * @create 2011/03/07
 * @author yamashita
 * @since 3.9.0
 */
public interface GVariableControl extends GUIControl, GEnablable {

	/**
	 * エラーレベルを取得します.<br>
	 * 
	 * @create 2011/03/30
	 * @return エラーレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	GErrorLevel getErrorlevel();

	/**
	 * パラメータのサブミット名を取得します.<br>
	 * 
	 * @create 2011/03/07
	 * @return パラメータのサブミット名
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getName();

	/**
	 * 入力値検証用の{@link GValidator}のリストを取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return {@link GValidator}一覧
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GValidator> getValidators();

	/**
	 * クリア処理の対象にするかを取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return クリア対象=true、クリア対象外=false
	 * @author yamashita
	 * @since 3.9.0
	 */
	boolean isClear();

	/**
	 * タグの有効/無効を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return 有効=true、無効=false
	 * @author yamashita
	 * @since 3.9.0
	 */
	boolean isEnabled();

	/**
	 * 入力必須項目であるかを表す値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return 必須=true、必須でない=false
	 * @author yamashita
	 * @since 3.9.0
	 */
	boolean isRequired();

	/**
	 * クリア処理の対象にするかを設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param clear クリア対象=true、クリア対象外=false
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setClear(boolean clear);

	/**
	 * エラーレベルを設定します.<br>
	 * 
	 * @create 2011/03/30
	 * @param errorlevel エラーレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setErrorlevel(GErrorLevel errorlevel);

	/**
	 * パラメータのサブミット名を設定します.<br>
	 * 
	 * @create 2011/03/30
	 * @param name パラメータのサブミット名
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setName(String name);

	/**
	 * 入力必須項目であるかを表す値を設定します.<br>
	 * true:必須<br>
	 * false:必須でない
	 * 
	 * @create 2011/03/30
	 * @param required 必須=true、必須でない=false
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setRequired(boolean required);

	/**
	 * 入力値検証用の{@link GValidator}のリストを設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param validators {@link GValidator}のリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setValidators(List<GValidator> validators);
}
