/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.validator.GRequiredValidator;
import jp.co.kccs.greenearth.framework.view.validator.GValidator;

/**
 * 値を持つコントロールであることを示すUIコンポーネントです.<br />
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GVariableControlBase extends GUIControlBase implements GVariableControl, GEnablable {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -8086890592640377345L;

	// XHTML属性
	/** name属性の値. */
	private String _name = null;

	// 拡張属性
	/** clear属性の値. */
	private String _clear = null;
	/** enabled属性の値. */
	private String _enabled = null;
	/** required属性の値. */
	private String _required = null;
	/** {@link GValidator}オブジェクトのリスト. */
	private List<GValidator> _validators = new LinkedList<GValidator>();

	// 内部変数
	/** {@link GErrorLevel}オブジェクト. */
	private GErrorLevel _errorlevel = GErrorLevel.NONE;

	/**
	 * {@link GVariableControlBase}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/11
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GVariableControlBase() {
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * 
	 * visibleフィールドが<code>false</code>またはenableフィールドが<code>false</code>
	 * の場合、フォーカスは当てられません。<br>
	 * 
	 * @create 2011/04/11
	 * @return <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public boolean canFocus() {
		return isVisible() && isEnabled();
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @create 2011/04/11
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setErrorlevel(GErrorLevel.NONE);
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br />
	 * 
	 * @create 2011/04/11
	 * @return 常用インスタンス（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GVariableControl createPracticalInstance() throws GViewException {
		GVariableControl clone = (GVariableControl) super.createPracticalInstance();
		List<GValidator> destValidators = new LinkedList<GValidator>();
		for (GValidator validator : getValidators()) {
			GValidator destValidator = validator.createPracticalInstanse();
			destValidators.add(destValidator);
		}
		clone.setValidators(destValidators);
		return clone;
	}

	/**
	 * 指定された値を出力内容に設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param data 表示内容
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public abstract void loadData(Object data);

	/**
	 * JSP情報を読み込みます.<br>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。
	 * 
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br />
	 * 
	 * @create 2011/03/07
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		super.loadParameter(parameter);
		if (parameter.getValuesMap().containsKey(getParameterKey())) {
			loadData(parameter.getValue(getParameterKey()));
		}
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * コントロールを検証する場合、エラーレベルを見分けます。
	 * 
	 * @create 2011/04/11
	 * @param data 結果セット
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		super.loadResultData(data);
		if (data.containsDataName(getId())) {
			loadData(data.getData(getId()));
		}
		loadValidateError(data.getErrors());
	}

	/**
	 * コントロールの検証エラーを読込みます.<br>
	 * 
	 * このコントロールの値で発生したエラーを読込み、このコントロールのエラーレベルを設定します。
	 * 
	 * @create 2011/03/07
	 * @param errors 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadValidateError(List<GValidateError> errors) {
		_errorlevel = GErrorLevel.NONE;
		if (errors == null || errors.size() == 0) {
			return;
		}
		for (GValidateError error : errors) {
			for (String id : error.getFieldIdList()) {
				if (!getFullId().equals(id)) {
					continue;
				}
				if (GErrorType.ERROR == error.getType()) {
					_errorlevel = GErrorLevel.ERROR;
					return;
				}
				if (GErrorType.WARNING == error.getType()) {
					_errorlevel = GErrorLevel.WARNING;
				} else if (GErrorType.INFO == error.getType()) {
					if (GErrorLevel.WARNING != _errorlevel) {
						_errorlevel = GErrorLevel.INFO;
					}
				}
			}
		}
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @create 2011/04/11
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GVariableControlBase control = (GVariableControlBase) getRepository();
		setName(control == null ? null : control.getName());
		setClear(control == null ? null : control.getClear());
		setEnabled(control == null ? null : control.getEnabled());
		setRequired(control == null ? null : control.getRequired());
		setErrorlevel(control == null ? null : control.getErrorlevel());
	}

	/**
	 * コントロール入力値の検証を行います.<br />
	 * 
	 * @create 2011/04/11
	 * @param parameter パラメーター
	 * @return 検証結果のエラー配列
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public List<GValidateError> validate(GParameter parameter) {
		List<GValidateError> allErrorList = new ArrayList<GValidateError>();
		if (parameter.getValuesMap().containsKey(getParameterKey())) {
			String value = parameter.getValue(getParameterKey());
			List<GValidateError> errors = validate(value, parameter.getValidationLevel());
			if (errors != null) {
				allErrorList.addAll(errors);
			}
		}
		return allErrorList;
	}

	/**
	 * コントロールに含まれる検証を実施します.<br>
	 * 
	 * @create 2011/04/11
	 * @param value 検証値
	 * @param errorlevel エラー実行レベル
	 * @return エラー一覧
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public List<GValidateError> validate(String value, GErrorLevel errorlevel) {
		List<GValidateError> errors = new ArrayList<GValidateError>();
		Locale locale = GWebContext.getInstance().getLocale();
		if (isRequired() && GErrorLevel.NONE != errorlevel) {
			GRequiredValidator validator = new GRequiredValidator(); // required属性の既定のエラーレベルはerrorとして扱う
			GValidateError error = validator.validate(this, value, null, locale);
			if (error != null) {
				errors.add(error);
				return errors;
			}
		}
		for (GValidator validator : getValidators()) {
			/*
			 * 下記の場合を除き、検証を実施する。 [1]パラメータで{@link GActionServlet#VALIDATE_KEY}を{@link
			 * GErrorLevel#NONE}を指定された場合 [2]validatorの出力エラーレベルが{@link
			 * GErrorLevel#Warning}の場合で、 　パラメータの{@link
			 * GActionServlet#VALIDATE_KEY}が{@link GErrorLevel#Error}の場合
			 * 　（クライアントから指定された検証レベル（Error）＞Validatorのエラー出力レベル（Warning））
			 * [3]validatorの出力エラーレベルが{@link GErrorLevel#Info}の場合で、 　パラメータの{@link
			 * GActionServlet#VALIDATE_KEY}が{@link GErrorLevel#Warning}、{@link
			 * GErrorLevel#Error}の場合
			 * 　（クライアントから指定された検証レベル（Error、Warning）＞Validatorのエラー出力レベル（Info））
			 * [4]validatorの出力エラーレベルが{@link GErrorLevel#None}の場合
			 */
			if (!(GErrorLevel.NONE == errorlevel
				|| (GErrorLevel.WARNING.toString().equals(validator.getLevel()) && GErrorLevel.ERROR == errorlevel)
				|| (GErrorLevel.INFO.toString().equals(validator.getLevel()) && GErrorLevel.ERROR == errorlevel)
				|| (GErrorLevel.INFO.toString().equals(validator.getLevel()) && GErrorLevel.WARNING == errorlevel) || GErrorLevel.NONE
				.toString().equals(validator.getLevel()))) {
				GValidateError error = validator.validate(this, value, errors, locale);
				if (error != null) {
					errors.add(error);
				}
				if (validator.isStop() && errors != null && errors.size() > 0) {
					return errors;
				}
			}
		}
		return errors;
	}

	/**
	 * 指定されたクラス名のvalidatorオブジェクトを生成します.<br />
	 * 
	 * @create 2011/04/11
	 * @param validatorClassName クラス名
	 * @return validatorオブジェクト
	 * @throws ClassNotFoundException 指定されたクラス名が見つからないとき
	 * @throws InstantiationException インスタンスの生成に失敗したとき
	 * @throws IllegalAccessException インスタンスの生成に失敗したとき
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected GValidator createValidator(String validatorClassName) throws ClassNotFoundException,
		InstantiationException, IllegalAccessException {
		Class< ? > validatorClass = Class.forName(validatorClassName);
		return (GValidator) validatorClass.newInstance();
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		NodeList children = node.getChildNodes();
		try {
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GValidator.class.isAssignableFrom(clazz)) {
					Element validatorElement = (Element) child;
					String validatorClassName = validatorElement.getAttribute("validator");
					GValidator validator = this.createValidator(validatorClassName);
					if (validator == null) {
						continue;
					}
					NamedNodeMap attrs = validatorElement.getAttributes();
					if (attrs.getNamedItem("args") != null) {
						validator.setArgs(validatorElement.getAttribute("args"));
					}
					if (attrs.getNamedItem("errorcode") != null) {
						validator.setErrorcode(validatorElement.getAttribute("errorcode"));
					}
					if (attrs.getNamedItem("level") != null) {
						validator.setLevel(validatorElement.getAttribute("level"));
					}
					if (attrs.getNamedItem("stop") != null) {
						validator.setStop(validatorElement.getAttribute("stop"));
					}
					getValidators().add(validator);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (ClassNotFoundException e) {
			throw new GViewException(e);
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getClear() {
		return _clear;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * {@link GErrorLevel}オブジェクトを取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return {@link GErrorLevel}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GErrorLevel getErrorlevel() {
		return _errorlevel;
	}

	/**
	 * name属性の値を取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getName() {
		if (_name == null) {
			return getId();
		}
		return _name;
	}

	/**
	 * 画面で利用されるパラメータ名を取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return パラメータ名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getParameterKey() {
		return GStringUtils.nullToBlank(getNamePrefix()) + GStringUtils.nullToBlank(getName());
	}

	/**
	 * required属性の値を取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getRequired() {
		return _required;
	}

	/**
	 * {@link GValidator}オブジェクトのリストを取得します.<br />
	 * 
	 * @create 2011/04/11
	 * @return {@link GValidator}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GValidator> getValidators() {
		return _validators;
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), true);
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(getEnabled(), true);
	}

	/**
	 * required属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isRequired() {
		return GBooleanUtils.toBoolean(getRequired(), false);
	}

	/**
	 * clear属性の値を設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param clear <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setClear(boolean clear) {
		_clear = String.valueOf(clear);
	}

	/**
	 * clear属性の値を設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param clear <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setClear(String clear) {
		_clear = clear;
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param enabled <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param enabled <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * {@link GErrorLevel}オブジェクトを設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param errorlevel errorlebelオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setErrorlevel(GErrorLevel errorlevel) {
		_errorlevel = errorlevel;
	}

	/**
	 * name属性の値を設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param name name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * required属性の値を設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param required <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRequired(boolean required) {
		_required = String.valueOf(required);
	}

	/**
	 * required属性の値を設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param required <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRequired(String required) {
		_required = required;
	}

	/**
	 * {@link GValidator}オブジェクトを設定します.<br />
	 * 
	 * @create 2011/04/11
	 * @param validators {@link GValidator}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValidators(List<GValidator> validators) {
		_validators = validators;
	}
}
