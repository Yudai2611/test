/*
 * Copyright 2014-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.error;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * ターゲットUI(actionidが指すUI)が所属するコンテナ({@link GErrorContainer})内のエラー通知UI({@link GErrorProvider})に活性化する旨をマークします.<br/>
 * 
 * @create 2014/02/20
 * @author KCCS yamashita
 * @since 3.13.0
 */
public class GErrorActivateMarker {

	/**
	 * コンストラクタ
	 * 
	 * @create 2014/02/20
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public GErrorActivateMarker() {
	}

	/**
	 * ターゲットUI(actionidが指すUI)が所属するコンテナ({@link GErrorContainer})内のエラー通知UI({@link GErrorProvider})に活性化する旨をマークします.
	 * 
	 * @param container コンテナ
	 * @create 2014/02/27
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	public void markActivated(GErrorContainer container) {
		GWebContext ctx = GWebContext.getInstance();
		GParameter parameter = (GParameter) ctx.getRequest().getAttribute(GConstants.PARAMETER_KEY);
		String actionId = parameter.getValue("actionid");
		GUIControl target = GStringUtils.nullToBlank(container.getFullId()).equals(actionId) ? container : container.findControl(actionId);
		if (target == null) {
			return;
		}
		GErrorContainer closestErrorContainer = closestErrorContainer(target);
		List<GErrorContainer> errorContainers = findErrorContainersFrom(container);
		for (GErrorContainer errorContainer: errorContainers) {
			if (errorContainer == closestErrorContainer) {
				markActivatedClosestErrorProvider((GUIControl) errorContainer);
			}
		}
	}

	private List<GErrorContainer> findErrorContainersFrom(GErrorContainer container) {
		List<GErrorContainer> errorContainers = new ArrayList<GErrorContainer>();
		extractErrorContainersFrom(container, errorContainers);
		return errorContainers;
	}

	private void extractErrorContainersFrom(GUIControl container, List<GErrorContainer> errorContainers) {
		if (container instanceof GErrorContainer) {
			errorContainers.add((GErrorContainer) container);
		}
		List<GUIControl> children = container.getChildren();
		if (children != null) {
			for (GUIControl child : children) {
				extractErrorContainersFrom(child, errorContainers);
			}
		}
	}

	private void markActivatedClosestErrorProvider(GUIControl control) {
		GUIControl errorContainer = control;
		while (!markActivated(errorContainer)) {
			GUIControl parent = getParentControl(errorContainer);
			errorContainer = closestErrorContainer(parent);
			// いずれViewに到達してbreakする前提
			if (errorContainer == null) {
				break;
			}
		}
	}

	private boolean markActivated(GUIControl control) {
		boolean hasErrorProvider = false;
		if (control instanceof GErrorProvider) {
			((GErrorProvider) control).setActive(true);
			hasErrorProvider = true;
		}
		for (GUIControl c: control.getChildren()) {
			if (c instanceof GErrorContainer) {
				continue;
			}
			if (markActivated(c)) {
				hasErrorProvider = true;
			}
		}
		return hasErrorProvider;
	}

	private GErrorContainer closestErrorContainer(GUIControl control) {
		if (control instanceof GErrorContainer) {	// ダイアログなどactionidがエラーコンテナを指すケースがある
			return (GErrorContainer) control;
		}
		GUIControl parent = getParentControl(control);
		if (parent == null) {
			return null;
		}
		if (parent instanceof GErrorContainer) {
			return (GErrorContainer) parent;
		}
		return closestErrorContainer(parent);
	}
	
	private GUIControl getParentControl(GUIComponent component) {
		if (component == null) {
			return null;
		}
		GUIComponent parent = component.getParent();
		if (parent == null) {
			return null;
		}
		if (parent instanceof GUIControl) {
			return (GUIControl) parent;
		}
		return getParentControl(parent);
	}
}
