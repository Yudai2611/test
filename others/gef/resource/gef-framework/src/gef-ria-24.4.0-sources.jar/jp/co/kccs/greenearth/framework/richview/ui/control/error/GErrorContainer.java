/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.error;

import jp.co.kccs.greenearth.framework.view.component.GUIControl;


/**
 * 論理的なエラー通知領域を表現するためのインタフェースです.<br/>
 * 
 * @create 2014/02/20
 * @author KCCS yamashita
 * @since 3.13.0
 */
public interface GErrorContainer extends GUIControl {
}
