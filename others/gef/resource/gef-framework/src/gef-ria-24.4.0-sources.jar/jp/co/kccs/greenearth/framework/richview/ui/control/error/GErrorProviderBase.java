/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.error;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase;

/**
 * エラー通知処理を表すUIコントロールの基底クラスです.<br/>
 * 
 * @create 2011/06/06
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GErrorProviderBase extends GUIContainerControlBase implements GErrorProvider {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2558880768476972327L;
	
	/** 活性化フラグ. */
	private boolean _active;
	// 拡張属性
	/** elements属性. */
	private String _elements = null;

	/**
	 * {@link GErrorProviderBase}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/06
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GErrorProviderBase() {
	}

	@Override
	public void loadParameter(GParameter parameter) {
		super.loadParameter(parameter);
		setActive(false);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br />
	 * 
	 * @create 2011/06/06
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GErrorProviderBase control = (GErrorProviderBase) getRepository();
		setElements(control == null ? null : control.getElements());
		setActive(false);
	}

	/**
	 * 活動するかどうかを判定します.<br/>
	 * 
	 * @return <code>true:活動する</code><code>false:活動しない</code>
	 * @create 2014/02/20
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public boolean isActive() {
		return _active;
	}
	
	/**
	 * 活動状態を設定します.<br/>
	 * 
	 * @param active <code>true:活動する</code><code>false:活動しない</code>
	 * @create 2014/02/20
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public void setActive(boolean active) {
		_active = active;
	}

	/**
	 * elements属性の値を取得します.<br />
	 * 
	 * @create 2011/06/06
	 * @return elements属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElements() {
		return _elements;
	}

	/**
	 * elements属性の値を設定します.<br />
	 * 
	 * @create 2011/06/06
	 * @param elements elements属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElements(String elements) {
		_elements = elements;
	}
}
