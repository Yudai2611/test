/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.ui.control.error.taglib;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.GErrorProviderBase;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * エラー通知処理を表すタグクラスの基底クラスです.<br/>
 * 
 * @create 2011/05/30
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GErrorProviderBaseTag extends GUIContainerControlBaseTag implements GErrorProviderTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7585996205307455525L;

	/** 活性化フラグ. */
	private boolean _active;
	// 拡張属性
	/** elements属性の値. */
	private String _elements;

	/**
	 * {@link GErrorProviderBaseTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GErrorProviderBaseTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/06/06
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GErrorProviderBase ui = (GErrorProviderBase) component;
		GErrorProviderBase rep = (GErrorProviderBase) component.getRepository();
		setElements(evaluatePlaceholder(ui.getElements(), getElements(),
				rep == null ? null : rep.getElements(), ui));
		setActive(ui.isActive());
	}

	/**
	 * 活動するかどうかを判定します.<br/>
	 * 
	 * @return <code>true:活動する</code><code>false:活動しない</code>
	 * @create 2014/02/20
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public boolean isActive() {
		return _active;
	}

	/**
	 * 活動状態を設定します.<br/>
	 * 
	 * @param active <code>true:活動する</code><code>false:活動しない</code>
	 * @create 2014/02/20
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	public void setActive(boolean active) {
		_active = active;
	}

	/**
	 * 結果セットがエラーを含んでいるかを取得します.<br />
	 * 
	 * @create 2011/06/06
	 * @return <code>true:エラーあり</code>/<code>false:エラーなし</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected boolean containsError() {
		if (!isActive()) {
			return false;	// 活性化対象ではない場合、エラーとしない
		}
		GResultData data = getResultData();
		if (data == null || !GResultData.EXIT_CODE_VALIDATE_ERROR.equals(data.getExitCode())) {
			return false;
		}
		GUIControl rootControl = (GUIControl) getRootComponent(this);
		if (rootControl == null) {
			return false;
		}
		List<GValidateError> errors = data.getErrors();
		if (errors == null || errors.isEmpty()) { // errorがセットされていない場合はエラーとしない
			return false;
		}
		String[] elements = GStringUtils.nullToBlank(_elements).trim().split(",");
		if (isEmptyErrorFields(errors)) { // elements指定なし　＆　errorFieldsなし　は汎用エラー通知としてエラーにする
			for (String element : elements) {
				if (GStringUtils.isEmpty(element)) {
					return true;
				}
			}
		}
		for (String element : elements) {
			element = element.trim();
			GUIControl control = rootControl.findControl(element);
			if (control == null) {
				continue;
			}
			String fullId = GStringUtils.nullToBlank(control.getPrefix()) + control.getId(); // TODO:[2011/06/09][yamashita]ThinClinetと仕様を統一する！
			for (GValidateError error : errors) {
				for (String id : error.getFieldIdList()) {
					if (id.equals(fullId) || control.findControl(id) != null) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br />
	 * 
	 * @create 2011/06/06
	 * @param options options属性
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		setWidgetOptionValue(options, "isError", containsError());
	}

	/**
	 * 結果セットを取得します.<br />
	 * 
	 * @create 2011/06/06
	 * @return 結果セット
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected GResultData getResultData() {
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		return (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);
	}

	/**
	 * 各入力フィールドにエラーがないかを取得します.<br/>
	 * 
	 * @create 2011/06/13
	 * @param errors {@link GValidateError}オブジェクトのリスト
	 * @return <code>true:エラー無し</code>/<code>false:エラーあり</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected boolean isEmptyErrorFields(List<GValidateError> errors) {
		for (GValidateError error : errors) {
			if (error.getFieldIdList().isEmpty()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * elements属性の値を取得します.<br />
	 * 
	 * @create 2011/06/06
	 * @return elements属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElements() {
		return _elements;
	}

	/**
	 * elements属性の値を設定します.<br />
	 * 
	 * @create 2011/06/06
	 * @param elements elements属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElements(String elements) {
		_elements = elements;
	}
}
