/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.error.taglib;



/**
 * エラー通知機能を提供するためのインタフェースです.<br/>
 * 
 * @create 2014/02/20
 * @author KCCS yamashita
 * @since 3.13.0
 */
public interface GErrorProviderTag {
	
	/**
	 * 活動するかどうかを判定します.<br/>
	 * 
	 * @return <code>true:活動する</code><code>false:活動しない</code>
	 * @create 2014/02/20
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	boolean isActive();
	/**
	 * 活動状態を設定します.<br/>
	 * 
	 * @param active <code>true:活動する</code><code>false:活動しない</code>
	 * @create 2014/02/20
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	void setActive(boolean active);
}
