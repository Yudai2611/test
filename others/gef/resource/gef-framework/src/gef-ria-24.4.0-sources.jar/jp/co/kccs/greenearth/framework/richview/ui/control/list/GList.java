/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.List;

import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl;

/**
 * リストのインターフェースです.<br/>
 * 
 * @create 2011/07/28
 * @author yamashita
 * @since 3.9.0
 */
public interface GList extends GVariableControl {

	/**
	 * テーブルの列を追加します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param row テーブルの列
	 * @author yamashita
	 * @since 3.9.0
	 */
	void addRow(GListRow row);

	/**
	 * テーブルの列値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	void clearRows();

	/**
	 * テーブルの列を作成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return テーブルの列
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListRow createRow();

	/**
	 * テーブルの列を削除します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param index 列インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	void removeRow(int index);

	/**
	 * テーブルの列のインデックスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	void renumberRowIndex();

	/**
	 * テーブルの列のインデックスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param index 列インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	void renumberRowIndex(int index);

	/**
	 * テーブルの見出しを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListCaption}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListCaption getCaption();

	/**
	 * テーブルのフッタを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListFooter}のオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListFooter getFooter();

	/**
	 * テーブルのヘッダを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListHeader}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListHeader getHeader();

	/**
	 * リストの表示件数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return listsize属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getListsize();

	/**
	 * リスト内の指定された位置にある{@link GListRow}を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @param index 行インデックス
	 * @return {@link GListRow}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListRow getRow(int index);

	/**
	 * {@link GListRow}のリストを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return 行のリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GListRow> getRows();

	/**
	 * テーブルの行数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListRow}オブジェクトのリストの要素数
	 * @author yamashita
	 * @since 3.9.0
	 */
	int getRowSize();

	/**
	 * 表示しているデータの開始件数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return 表示しているデータの開始件数
	 * @author yamashita
	 * @since 3.9.0
	 */
	int getStartIndex();

	/**
	 * リストの表示件数を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param listsize listsize属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setListsize(String listsize);

	/**
	 * テーブルの行を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param rows {@link GListRow}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setRows(List<GListRow> rows);

	/**
	 * 表示しているデータの開始件数を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param startIndex 表示しているデータの開始件数
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setStartIndex(int startIndex);

}
