/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * リストキャプションのインターフェースです.<br/>
 * 
 * @create 2011/07/28
 * @author yamashita
 * @since 3.9.0
 */
public interface GListCaption extends GUIItem {

	/**
	 * コントロールを追加します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param control コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	void addElement(GUIControl control);

	/**
	 * このコントロールの値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	void clear();

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param parent 親リストコントロール
	 * @return エレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListCaption createPracticalInstance(GList parent);

	/**
	 * 指定されたコントロールを検索します.<br>
	 * 
	 * @create 2011/07/27
	 * @param id "hoge" or "hoge.idx.fuga..."
	 * @return コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	GUIControl findElement(String id);

	/**
	 * 格納されているコントロールのリストを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 子コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GUIControl> getChildren();

	/**
	 * コントロールを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @param id コントロールのID
	 * @return {@link GUIControl}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	GUIControl getElement(String id);

	/**
	 * コントロールのマップを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GUIControl}オブジェクトのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	Map<String, GUIControl> getElements();

	/**
	 * エレメントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param caption リストキャプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	void loadElements(GListCaption caption);

	/**
	 * コントロールのマップを設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param controls {@link GUIControl}オブジェクトのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setElements(Map<String, GUIControl> controls);
}
