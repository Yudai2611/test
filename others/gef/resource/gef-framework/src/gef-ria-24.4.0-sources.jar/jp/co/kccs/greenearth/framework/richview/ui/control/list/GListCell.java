/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * リストセルのインターフェースです.<br/>
 * 
 * @create 2011/07/28
 * @author yamashita
 * @since 3.9.0
 */
public interface GListCell extends GUIItem {

	/**
	 * コントロールを追加します.<br/>
	 * 
	 * @create 2011/07/28
	 * @param control コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	void addElement(GUIControl control);

	/**
	 * このコントロールの値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/28
	 * @author yamashita
	 * @since 3.9.0
	 */
	void clear();

	/**
	 * このコントロールの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param parent コントロール
	 * @return コントロール
	 * @throws GViewException 生成に失敗した場合の例外
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListCell createPracticalInstance(GUIComponent parent) throws GViewException;

	/**
	 * セルに所属するVariable系コントロールの一覧を収集します.
	 * 
	 * @create 2011/07/28
	 * @param variableList Variable系コントロール
	 * @param control コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	void fillVariableList(List<GVariableControl> variableList, GUIControl control);

	/**
	 * エレメントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param cell リストセルエレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	void loadElements(GListCell cell);

	/**
	 * 格納されているコントロールのリストを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 子コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GUIControl> getChildren();

	/**
	 * コントロールを取得します.<br />
	 * 
	 * @create 2011/07/28
	 * @param id コントロールのID
	 * @return コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	GUIControl getElement(String id);

	/**
	 * コントロールのマップを取得します.<br />
	 * 
	 * @create 2011/07/28
	 * @return エレメントのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	Map<String, GUIControl> getElements();

	/**
	 * id属性の値を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return id属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getId();

	/**
	 * コントロールのマップを設定します.<br />
	 * 
	 * @create 2011/07/28
	 * @param controls コントロールのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setElements(Map<String, GUIControl> controls);
}
