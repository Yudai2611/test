/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * リストコンテンツのインターフェースです.<br/>
 * 
 * @create 2011/07/28
 * @author yamashita
 * @since 3.9.0
 */
public interface GListContents extends GUIItem {

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param parent リストコントロール
	 * @return エレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GListContents createPracticalInstance(GList parent);

	/**
	 * テーブルのセルを追加します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param cell セル
	 * @author yamashita
	 * @since 3.9.0
	 */
	void addCell(GListCell cell);

	/**
	 * このコントロールの値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	void clear();

	/**
	 * 指定されたコントロールを検索します.<br>
	 * 
	 * @create 2011/07/27
	 * @param id "hoge" or "hoge.idx.fuga..."
	 * @return コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	GUIControl findElement(String id);

	/**
	 * セルの情報を読み込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param row テーブルの列
	 * @author yamashita
	 * @since 3.9.0
	 */
	void loadCells(GListContents row);

	/**
	 * セルを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param id セルのID
	 * @return リストセル
	 * @author yamashita
	 * @since 3.9.0
	 */
	GListCell getCell(String id);

	/**
	 * セルのマップを取得します.<br/>
	 * 
	 * 
	 * @create 2011/07/27
	 * @return セルマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	Map<String, GListCell> getCells();

	/**
	 * 格納されているコントロールのリストを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GUIControl> getChildren();

	/**
	 * セルのマップを設定します.<br/>
	 * 
	 * 
	 * @create 2011/07/27
	 * @param cells セルのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setCells(Map<String, GListCell> cells);
}
