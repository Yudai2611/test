/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

/**
 * リストヘッダーのインターフェースです.<br/>
 * 
 * @create 2011/07/28
 * @author yamashita
 * @since 3.9.0
 */
public interface GListHeader extends GListContents {
}
