/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.List;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl;

/**
 * リストロウのインターフェースです.<br/>
 * 
 * @create 2011/07/28
 * @author yamashita
 * @since 3.9.0
 */
public interface GListRow extends GListContents {

	/**
	 * 指定された値を出力内容に設定します.<br/>
	 * 
	 * caption, headerへのバインディングは行いません。<br/>
	 * 
	 * @create 2011/07/27
	 * @param rowData データ
	 * @author yamashita
	 * @since 3.9.0
	 */
	void loadData(GRowData rowData);

	/**
	 * コントロールの検証エラーを読込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param errors 検証エラーリスト
	 * @return 検証エラーコントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GVariableControl> loadValidateError(List<GValidateError> errors);

	/**
	 * コントロール入力値の検証を行います.<br/>
	 * 
	 * 内包されるリストの検証は行いません。<br/>
	 * 
	 * @create 2011/07/27
	 * @param parameter 画面パラメータ
	 * @return 検証エラー
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GValidateError> validate(GParameter parameter);

	/**
	 * リストの行インデックスを取得します.<br />
	 * 
	 * @create 2011/07/28
	 * @return 行インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	int getRowIndex();

	/**
	 * リストの行インデックスを設定します.<br />
	 * 
	 * @create 2011/07/28
	 * @param rowIndex リストの行インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setRowIndex(int rowIndex);
}
