/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase;
import jp.co.kccs.greenearth.framework.richview.utils.GRIAActionUtils;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;

/**
 * リストを表すUIコントロールです.<br/>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public class GPList extends GVariableControlBase implements GList {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8941555536057850395L;
	// XHTML属性
	/** summary属性の値. */
	private String _summary = null;
	// 拡張属性
	/** listsize属性の値. */
	private String _listsize = "-1";
	// 内部変数
	/** 結果セット内のリストの有無. */
	private String _empty = null;
	/** 表示しているデータの開始件数. */
	private int _startIndex = -1;
	/** {@link GListCaption}オブジェクト. */
	private GListCaption _caption = null;
	/** {@link GListHeader}オブジェクト. */
	private GListHeader _header = null;
	/** {@link GListRow}オブジェクトのリスト. */
	private List<GListRow> _rows = new ArrayList<GListRow>();
	/** {@link GListFooter}オブジェクト. */
	private GListFooter _footer = null;
	/** zebrarow属性の値 */
	private String _zebrarow = null;
	/** emptymsg属性の値 */
	private String _emptymsg = null;
	/** isemptymsg属性の値 */
	private String _isemptymsg = null;
	/** 対象となるリストの総サイズ. */
	private int _totalSize = 0;
	
	/** スクロール領域の幅 */
	private String _scrollWidth = null;
	/** スクロール領域の高さ */
	private String _scrollHeight = null;

	@Deprecated
	public static final String SUFFIX_SEPARATOR = "__@@__";
	@Deprecated
	public static final String INTERNAL_NON_VISIBLE_HTML_ID_SUFFIX = "internal-non-visibled";
	@Deprecated
	public static final String INTERNAL_DISABLED_HTML_ID_SUFFIX = "internal-disabled";
	@Deprecated
	public static final String INTERNAL_NON_VISIBLE_VALUE = "internal.non-visibled";
	@Deprecated
	public static final String INTERNAL_DISABLED_VALUE = "internal.disabled";

	/**
	 * {@link GPList}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPList() {
	}

	/**
	 * テーブルの列を追加します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param row テーブルの列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addRow(GListRow row) {
		row.setRowIndex(getRows().size());
		getRows().add(row);
		row.setParent(this);
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return フォーカスが当てられるかどうか
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public boolean canFocus() {
		return false;
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		if (getCaption() != null) {
			getCaption().clear();
		}
		if (getHeader() != null) {
			getHeader().clear();
		}
		if (getFooter() != null) {
			getFooter().clear();
		}
		clearRows();
		setEmpty(false);
		setStartIndex(-1);
	}

	/**
	 * テーブルの列値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void clearRows() {
		getRows().clear();
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return コンポーネント
	 * @throws GViewException 生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GList createPracticalInstance() throws GViewException {
		GPList clone = (GPList) super.createPracticalInstance();
		if (getCaption() != null) {
			GListCaption listCaption = (GListCaption) getCaption().createPracticalInstance(clone);
			clone.setCaption(listCaption);
		}
		if (getHeader() != null) {
			GListHeader listHeader = (GListHeader) getHeader().createPracticalInstance(clone);
			clone.setHeader(listHeader);
		}
		if (getFooter() != null) {
			GListFooter listFooter = (GListFooter) getFooter().createPracticalInstance(clone);
			clone.setFooter(listFooter);
		}
		clone.setRows(new ArrayList<GListRow>());
		return clone;
	}

	/**
	 * テーブルの行を作成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return テーブルの行
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListRow createRow() {
		GListRow repository = ((GPList) getRepository()).getRows().get(0);
		GListRow newRow = (GListRow) repository.createPracticalInstance(this);
		return (GPListRow) newRow;
	}

	/**
	 * ページの{@link GViewInterface}内から、指定した名前のコントロールを検索します.<br>
	 * 
	 * @create 2011/07/27
	 * @param id "hoge.idx.fuga.idx..."
	 * @return コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GUIControl findControl(String id) {
		if (id == null) {
			return null;
		}
		int period = id.indexOf('.');
		if (period == -1 || !id.startsWith(getId())) {
			return null;
		}
		String elementId = id.substring(period + 1);
		int firstPeriodIndex = elementId.indexOf('.');
		if (firstPeriodIndex == -1) {
			return null;
		}
		String idxStr = elementId.substring(0, firstPeriodIndex);
		// idxStr以下の文字列を取得
		elementId = id.substring(period + 1 + idxStr.length() + 1);
		GListCaption caption = getCaption();
		if ("caption".equals(idxStr)) {
			if (caption == null) {
				return null;
			}
			return caption.findElement(elementId);
		}
		GListHeader header = getHeader();
		if ("header".equals(idxStr)) {
			if (header == null) {
				return null;
			}
			return header.findElement(elementId);
		}
		GListFooter footer = getFooter();
		if ("footer".equals(idxStr)) {
			if (footer == null) {
				return null;
			}
			return footer.findElement(elementId);
		}
		int index = Integer.parseInt(idxStr);
		if (index >= 0 && getRows().size() > index) {
			return getRow(index).findElement(elementId);
		}
		return null;
	}

	/**
	 * 格納されているコントロールのリストを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public List<GUIControl> getChildren() {
		List<GUIControl> children = new ArrayList<GUIControl>();
		if (getCaption() != null) {
			children.addAll(getCaption().getChildren());
		}
		if (getHeader() != null) {
			children.addAll(getHeader().getChildren());
		}
		if (getFooter() != null) {
			children.addAll(getFooter().getChildren());
		}
		for (GListRow row : getRows()) {
			children.addAll(row.getChildren());
		}
		return children;
	}

	/**
	 * 指定された値を出力内容に設定します.<br/>
	 * 
	 * caption, headerへのバインディングは行いません。<br/>
	 * 
	 * @create 2011/07/27
	 * @param data データ
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadData(Object data) {
		if (data == null || !(data instanceof GListData)) {
			return;
		}
		GListData listData = (GListData) data;
		setStartIndex(listData.getStartIndex());
		setListsize(String.valueOf(listData.getMaxListSize()));
		setTotalSize(listData.getTotalSize());
		setEmpty(listData.size() > 0 ? false : true);
		clearRows();
		for (GRowData rowData : listData) {
			GListRow row = createRow();
			addRow(row);
			row.loadData(rowData);
		}
	}

	/**
	 * JSP情報を読み込みます.<br/>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。<br/>
	 * 
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/05/13
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * 画面パラメータとUIを同期化します.<br/>
	 * ※ネストされたリストについては、同期化は実施しません。<br/>s
	 * 
	 * @create 2011/07/27
	 * @param parameter 画面パラメータ
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		GListData listData = GRIAActionUtils.extractListData(parameter, getName());
		loadData(listData);
		
		GListCaption caption = getCaption();
		if (caption != null) {
			loadParameter(caption.getChildren(), parameter);
		}
		GListHeader header = getHeader();
		if (header != null) {
			loadParameter(header.getChildren(), parameter);
		}
		GListFooter footer = getFooter();
		if (footer != null) {
			loadParameter(footer.getChildren(), parameter);
		}
	}

	/**
	 * 画面パラメータとUIを同期化します.<br/>
	 * 
	 * @create 2013/03/06
	 * @param controls コントロール
	 * @param parameter 画面パラメータ
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	protected void loadParameter(List<GUIControl> controls, GParameter parameter) {
		for (GUIControl control : controls) {
			control.loadParameter(parameter);
		}
	}
	
	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param data 結果セット
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		loadData(data.getListData(getId()));
		GListCaption caption = getCaption();
		if (caption != null) {
			loadResultData(caption.getChildren(), data);
		}
		GListHeader header = getHeader();
		if (header != null) {
			loadResultData(header.getChildren(), data);
		}
		GListFooter footer = getFooter();
		if (footer != null) {
			loadResultData(footer.getChildren(), data);
		}
		loadValidateError(data.getErrors());
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br/>
	 * 
	 * @create 2013/03/06
	 * @param data 結果セット
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	protected void loadResultData(List<GUIControl> controls, GResultData data) {
		for (GUIControl control : controls) {
			control.loadResultData(data);
		}
	}
	
	/**
	 * コントロールの検証エラーを読込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param errors 検証エラー情報リスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadValidateError(List<GValidateError> errors) {
		if (errors == null) {
			return;
		}
		for (GListRow row : getRows()) {
			row.loadValidateError(errors);
		}
		GListCaption caption = getCaption();
		if (caption != null) {
			loadValidateError(caption.getChildren(), errors);
		}
		GListHeader header = getHeader();
		if (header != null) {
			loadValidateError(header.getChildren(), errors);
		}
		GListFooter footer = getFooter();
		if (footer != null) {
			loadValidateError(footer.getChildren(), errors);
		}
	}

	/**
	 * コントロールの検証エラーを読込みます.<br/>
	 * 
	 * @create 2013/03/05
	 * @param errors 検証エラー情報リスト
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	protected void loadValidateError(List<GUIControl> controls, List<GValidateError> errors) {
		for (GUIControl control : controls) {
			control.loadValidateError(errors);
		}
	}

	/**
	 * テーブルの行を削除します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param index 行インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void removeRow(int index) {
		getRows().remove(index);
		renumberRowIndex(index);
	}

	/**
	 * テーブルの行のインデックスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void renumberRowIndex() {
		int listIndex = 0;
		for (GListRow row : getRows()) {
			row.setRowIndex(listIndex++);
		}
	}

	/**
	 * テーブルの行のインデックスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param index インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void renumberRowIndex(int index) {
		for (int i = index; i < getRows().size(); i++) {
			GListRow row = getRow(i);
			row.setRowIndex(i);
		}
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPList control = (GPList) getRepository();
		setSummary(control == null ? null : control.getSummary());
		setListsize(control == null ? null : control.getListsize());
		setTotalSize(control == null ? null : control.getTotalSize());
		setEmpty(control == null ? null : control.isEmpty());
		setStartIndex(control == null ? null : control.getStartIndex());
		setZebrarow(control == null ? null : control.getZebrarow());
		setEmptymsg(control == null ? null : control.getEmptymsg());
		setIsemptymsg(control == null ? null : control.getIsemptymsg());
		if (getCaption() != null) {
			getCaption().reset();
		}
		if (getHeader() != null) {
			getHeader().reset();
		}
		if (getFooter() != null) {
			getFooter().reset();
		}
		clearRows();
	}

	/**
	 * コントロール入力値の検証を行います.<br/>
	 * 
	 * @create 2011/07/27
	 * @param parameter 画面パラメータ
	 * @return 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public List<GValidateError> validate(GParameter parameter) {
		List<GValidateError> allErrors = new ArrayList<GValidateError>();
		for (GListRow row : getRows()) {
			List<GValidateError> errors = row.validate(parameter);
			if (errors != null) {
				allErrors.addAll(errors);
			}
		}
		GListCaption caption = getCaption();
		if (caption != null) {
			allErrors.addAll(validate(caption.getChildren(), parameter));
		}
		GListHeader header = getHeader();
		if (header != null) {
			allErrors.addAll(validate(header.getChildren(), parameter));
		}
		GListFooter footer = getFooter();
		if (footer != null) {
			allErrors.addAll(validate(footer.getChildren(), parameter));
		}
		return allErrors;
	}

	/**
	 * {@inheritDoc}
	 *
	 * 非推奨。入力値の検証は行いません。
	 *
	 * @param value
	 * @param errorLevel
	 * @return 0件の検証エラーリスト
	 * @author fujikake
	 * @since 3.19.2
	 */
	@Deprecated
	@Override
	public List<GValidateError> validate(String value, GErrorLevel errorLevel) {
		return new ArrayList<GValidateError>();
	}

	/**
	 * コントロール入力値の検証を行います.<br/>
	 * 
	 * @create 2013/03/05
	 * @param parameter 画面パラメータ
	 * @return 検証エラーリスト
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	protected List<GValidateError> validate(List<GUIControl> controls, GParameter parameter) {
		List<GValidateError> allErrors = new ArrayList<GValidateError>();
		for (GUIControl control : controls) {
			List<GValidateError> errors = control.validate(parameter);
			if (errors != null) {
				allErrors.addAll(errors);
			}
		}
		return allErrors;
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/05/13
	 * @author yamashita
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		try {
			NodeList children = node.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GListCaption.class.isAssignableFrom(clazz)) {
					GListCaption listCaption = (GListCaption) clazz.newInstance();
					listCaption.loadJspElement((Element) child);
					setCaption(listCaption);
				} else if (clazz != null && GListHeader.class.isAssignableFrom(clazz)) {
					GListHeader listheader = (GListHeader) clazz.newInstance();
					listheader.setParent(this);
					listheader.loadJspElement((Element) child);
					setHeader(listheader);
				} else if (clazz != null && GListFooter.class.isAssignableFrom(clazz)) {
					GListFooter listfooter = (GListFooter) clazz.newInstance();
					listfooter.setParent(this);
					listfooter.loadJspElement((Element) child);
					setFooter(listfooter);
				} else if (clazz != null && GListRow.class.isAssignableFrom(clazz)) {
					GListRow listrow = (GListRow) clazz.newInstance();
					listrow.loadJspElement((Element) child);
					addRow(listrow);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * テーブルの見出しを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListCaption}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListCaption getCaption() {
		return (GPListCaption) _caption;
	}

	/**
	 * 結果セット内のリストの有無を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return リストの有無
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getEmpty() {
		return _empty;
	}

	/**
	 * emptymsg属性の値を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return emptymsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getEmptymsg() {
		return _emptymsg;
	}

	/**
	 * テーブルのフッタを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListFooter}のオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListFooter getFooter() {
		return (GPListFooter) _footer;
	}

	/**
	 * このコンポーネントの完全なIDを返します.<br/>
	 * 
	 * @return 完全なID
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getFullId() {
		String prefix = null;
		if (getParent() != null) {
			prefix = getParent().getPrefix();
		}
		return GStringUtils.nullToBlank(prefix) + getId();
	}

	/**
	 * テーブルのヘッダを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListHeader}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListHeader getHeader() {
		return (GPListHeader) _header;
	}

	/**
	 * isemptymsg属性の値を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return isemptymsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getIsemptymsg() {
		return _isemptymsg;
	}

	/**
	 * リストの表示件数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return listsize属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getListsize() {
		return _listsize;
	}

	/**
	 * リクエストパラメータキーの完全な接頭語を返します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 完全な接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getNamePrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getNamePrefix());
		prefixBuilder.append(getName());
		prefixBuilder.append(".");
		return prefixBuilder.toString();
	}

	/**
	 * このコンポーネントの完全なID接頭語を返します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 完全なID接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getPrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getPrefix());
		prefixBuilder.append(getId());
		prefixBuilder.append(".");
		return prefixBuilder.toString();
	}

	/**
	 * リスト内の指定された位置にある{@link GListRow}を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @param index インデックス
	 * @return {@link GListRow}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListRow getRow(int index) {
		return (GPListRow) _rows.get(index);
	}

	/**
	 * {@link GListRow}のリストを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return 行のリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GListRow> getRows() {
		return _rows;
	}

	/**
	 * テーブルの行数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GListRow}オブジェクトのリストの要素数
	 * @author yamashita
	 * @since 3.9.0
	 */
	public int getRowSize() {
		return _rows.size();
	}

	/**
	 * 表示しているデータの開始件数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return 表示しているデータの開始件数
	 * @author yamashita
	 * @since 3.9.0
	 */
	public int getStartIndex() {
		return _startIndex;
	}

	/**
	 * 表の目的や構成の説明を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return summary属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getSummary() {
		return _summary;
	}

	/**
	 * zebrarow属性の値を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return zebrarow属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getZebrarow() {
		return _zebrarow;
	}

	/**
	 * emptyの値を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return 結果セット内に<code>true:リストを含む</code>/<code>false:リストを含まない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isEmpty() {
		return GBooleanUtils.toBoolean(_empty, false);
	}

	/**
	 * isemptymsg属性の値を取得します.
	 * 
	 * @create 2011/07/27
	 * @return isemptymsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isIsemptymsg() {
		return GBooleanUtils.toBoolean(_isemptymsg, true);
	}

	/**
	 * 行の背景色を奇数行・偶数行に分けて設定する機能の使用有無を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return zebrarow属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isZebrarow() {
		return GBooleanUtils.toBoolean(_zebrarow, true);
	}

	/**
	 * テーブルの見出しを設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param caption {@link GListCaption}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setCaption(GListCaption caption) {
		_caption = caption;
		caption.setParent(this);
	}

	/**
	 * emptyの値を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param empty 結果セット内に<code>true:リストを含む</code>/<code>false:リストを含まない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEmpty(boolean empty) {
		_empty = String.valueOf(empty);
	}

	/**
	 * emptymsg属性の値を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param emptymsg emptymsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEmptymsg(boolean emptymsg) {
		_emptymsg = String.valueOf(emptymsg);
	}

	/**
	 * emptymsg属性の値を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param emptymsg emptymsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEmptymsg(String emptymsg) {
		_emptymsg = emptymsg;
	}

	/**
	 * テーブルのフッタを設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param footer {@link GListFooter}のオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFooter(GListFooter footer) {
		_footer = footer;
		footer.setParent(this);
	}

	/**
	 * テーブルのヘッダを設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param header {@link GListHeader}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHeader(GListHeader header) {
		_header = header;
		header.setParent(this);
	}

	/**
	 * isemptymsg属性の値を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param isemptymsg isemptymsg属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setIsemptymsg(String isemptymsg) {
		_isemptymsg = isemptymsg;
	}

	/**
	 * リストの表示件数を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param listsize listsize属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setListsize(String listsize) {
		_listsize = listsize;
	}

	/**
	 * テーブルの行を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param rows {@link GListRow}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRows(List<GListRow> rows) {
		_rows = rows;
		for (GListRow row : rows) {
			row.setParent(this);
		}
	}

	/**
	 * 表示しているデータの開始件数を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param startIndex 表示しているデータの開始件数
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStartIndex(int startIndex) {
		_startIndex = startIndex;
	}

	/**
	 * 目的や構成の説明を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param summary summary属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSummary(String summary) {
		_summary = summary;
	}

	/**
	 * zebrarow属性の値を設定します.<br />
	 * 
	 * 
	 * @create 2011/07/27
	 * @param zebrarow zebrarow属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZebrarow(boolean zebrarow) {
		_zebrarow = String.valueOf(zebrarow);
	}

	/**
	 * zebrarow属性の値を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param zebrarow zebrarow属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setZebrarow(String zebrarow) {
		_zebrarow = zebrarow;
	}

	/**
	 * 対象となるリストの総サイズを取得します.<br />
	 * 
	 * @create 2013/3/05
	 * @return 対象となるリストの総サイズ
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public int getTotalSize() {
		return _totalSize;
	}

	/**
	 * 対象となるリストの総サイズを設定します.<br />
	 * 
	 * @create 2013/03/05
	 * @param totalSize 対象となるリストの総サイズ
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setTotalSize(int _totalSize) {
		this._totalSize = _totalSize;
	}

	
	/**
	 * スクロール領域の幅(px)を取得します。<br>
	 * 
	 * @create 2013/07/23
	 * @return スクロール領域の幅(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getScrollWidth() {
		return _scrollWidth;
	}

	
	/**
	 * スクロール領域の幅(px)を設定します。<br>
	 * 
	 * @create 2013/07/23
	 * @param スクロール領域の幅(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setScrollWidth(String _scrollWidth) {
		this._scrollWidth = _scrollWidth;
	}
	
	/**
	 * スクロール領域の高さ(px)を取得します。<br>
	 * 
	 * @create 2013/07/23
	 * @return スクロール領域の高さ(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getScrollHeight() {
		return _scrollHeight;
	}
	
	/**
	 * スクロール領域の高さ(px)を取得します。<br>
	 * 
	 * @create 2013/07/23
	 * @param スクロール領域の高さ(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setScrollHeight(String _scrollHeight) {
		this._scrollHeight = _scrollHeight;
	}

	/**
	 * {@inheritDoc}
	 *
	 * 非推奨。Requiredの値は変更されません。また、必須チェックは行いません。
	 *
	 * @param required
	 * @author fujikake
	 * @since 3.19.2
	 */
	@Deprecated
	@Override
	public void setRequired(boolean required) {
		//値は変更しません。
	}

	/**
	 * {@inheritDoc}
	 *
	 * 非推奨。Requiredの値は変更されません。また、必須チェックは行いません。
	 *
	 * @param required
	 * @author fujikake
	 * @since 3.19.2
	 */
	@Deprecated
	@Override
	public void setRequired(String required) {
		//値は変更しません。
	}
}
