/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * リストキャプションを表すUIコントロールです.<br/>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public class GPListCaption extends GUIItemBase implements GListCaption {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -8463442633545929984L;

	// 内部変数
	/** エレメントのマップ. */
	private Map<String, GUIControl> _elements = new HashMap<String, GUIControl>();

	/**
	 * {@link GPListCaption}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListCaption() {
	}

	/**
	 * エレメントを追加します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param control コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addElement(GUIControl control) {
		getElements().put(control.getId(), control);
		control.setParent(this);
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void clear() {
		for (GUIControl element : getElements().values()) {
			element.clear();
		}
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 常用のUIコンポーネント（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GListCaption createPracticalInstance() throws GViewException {
		GListCaption clone = (GListCaption) super.createPracticalInstance();
		loadElements(clone);
		return clone;
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param parent リストコントロール
	 * @return 常用のUIコンポーネント（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GListCaption createPracticalInstance(GList parent) throws GViewException {
		GListCaption clone = createPracticalInstance();
		clone.setParent(parent);
		return clone;
	}

	/**
	 * 指定されたエレメントを検索します.<br>
	 * 
	 * @create 2011/07/27
	 * @param id エレメントのID
	 * @return エレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControl findElement(String id) {
		if (id == null) {
			return null;
		}
		int period = id.indexOf('.');
		String elementId = period == -1 ? id : id.substring(0, period);

		for (String key : getElements().keySet()) {
			GUIControl control = getElement(key);

			if (elementId.equals(control.getId())) {
				return control;
			}
			for (GUIControl child : control.getChildren()) {
				if (id.equals(child.getId())) {
					return child;
				}
			}
		}
		return null;
	}

	/**
	 * エレメントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param caption リストキャプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadElements(GListCaption caption) {
		Map<String, GUIControl> elements = new HashMap<String, GUIControl>();
		for (GUIControl element : getElements().values()) {
			GUIControl celement = (GUIControl) element.createPracticalInstance();
			celement.setParent(caption);
			elements.put(celement.getId(), celement);
		}
		caption.setElements(elements);
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。<br/>
	 * 
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		for (GUIControl control : getElements().values()) {
			control.reset();
		}
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		try {
			NodeList children = node.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GUIControl.class.isAssignableFrom(clazz)) {
					GUIControl element = (GUIControl) clazz.newInstance();
					element.loadJspElement((Element) child);
					addElement(element);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * 格納されているコントロールのリストを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GUIControl> getChildren() {
		List<GUIControl> children = new ArrayList<GUIControl>();
		children.addAll(getElements().values());
		return children;
	}

	/**
	 * コントロールを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @param id コントロールのID
	 * @return {@link GUIControl}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControl getElement(String id) {
		return getElements().get(id);
	}

	/**
	 * エレメントのマップを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return {@link GUIControl}オブジェクトのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public Map<String, GUIControl> getElements() {
		return _elements;
	}

	/**
	 * このコンポーネントの完全なID接頭語を返します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 完全なID接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getPrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getPrefix());
		prefixBuilder.append("caption.");
		return prefixBuilder.toString();
	}

	/**
	 * リクエストパラメータキーの完全な接頭語を返します.<br/>
	 * 
	 * @create 2013/08/22
	 * @return 完全なNAME接頭語
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public String getNamePrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getNamePrefix());
		prefixBuilder.append("caption.");
		return prefixBuilder.toString();
	}

	/**
	 * エレメントのマップを設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param controls {@link GUIControl}オブジェクトのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElements(Map<String, GUIControl> controls) {
		_elements = controls;
		for (GUIControl element : controls.values()) {
			element.setParent(this);
		}
	}
}
