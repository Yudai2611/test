/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;
import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * リストセルを表すUIコントロールです.
 * 
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public class GPListCell extends GUIItemBase implements GListCell {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -58598389573275047L;

	// XHTML属性
	/** abbr属性の値. */
	private String _abbr = null;
	/** axis属性の値. */
	private String _axis = null;
	/** colspan属性の値. */
	private String _colspan = null;
	/** headers属性の値. */
	private String _headers = null;
	/** rowspan属性の値. */
	private String _rowspan = null;
	/** scope属性の値. */
	private String _scope = null;

	/** 内部変数 */
	private Map<String, GUIControl> _controls = new HashMap<String, GUIControl>();

	/**
	 * {@link GPListCell}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListCell() {
	}

	/**
	 * コントロールを追加します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param control コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addElement(GUIControl control) {
		getElements().put(control.getId(), control);
		control.setParent(this);
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void clear() {
		for (GUIControl control : getElements().values()) {
			control.clear();
		}
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 常用のUIコンポーネント（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @throws GViewException
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GListCell createPracticalInstance() throws GViewException {
		GListCell clone = (GListCell) super.createPracticalInstance();
		loadElements(clone);
		return clone;
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param parent コンポーネント
	 * @return 常用のUIコンポーネント（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @throws GViewException
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GListCell createPracticalInstance(GUIComponent parent) throws GViewException {
		GListCell clone = createPracticalInstance();
		clone.setParent(parent);
		return clone;
	}

	/**
	 * セルに所属するVariable系コントロールの一覧を収集します.
	 * 
	 * @create 2011/07/27
	 * @param variableList Variable系コントロールのリスト
	 * @param control コントロール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void fillVariableList(List<GVariableControl> variableList, GUIControl control) {
		if (control instanceof GVariableControl) {
			variableList.add((GVariableControl) control);
			return;
		}
		for (GUIControl con : control.getChildren()) {
			fillVariableList(variableList, con);
		}
	}

	/**
	 * エレメントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param cell リストセル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadElements(GListCell cell) {
		Map<String, GUIControl> elements = new HashMap<String, GUIControl>();
		for (GUIControl control : getElements().values()) {
			GUIControl celement = (GUIControl) control.createPracticalInstance();
			control.setParent(cell);
			elements.put(celement.getId(), celement);
		}
		cell.setElements(elements);
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。<br/>
	 * 
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPListCell cell = (GPListCell) getRepository();
		setAbbr(cell == null ? null : cell.getAbbr());
		setAxis(cell == null ? null : cell.getAxis());
		setColspan(cell == null ? null : cell.getColspan());
		setHeaders(cell == null ? null : cell.getHeaders());
		setRowspan(cell == null ? null : cell.getRowspan());
		setScope(cell == null ? null : cell.getScope());
		for (GUIControl control : getElements().values()) {
			control.reset();
		}
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		try {
			NodeList children = node.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GUIControl.class.isAssignableFrom(clazz)) {
					GUIControl element = (GUIControl) clazz.newInstance();
					element.loadJspElement((Element) child);
					addElement(element);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * abbr属性の値を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return abbr属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAbbr() {
		return _abbr;
	}

	/**
	 * axis属性の値を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return axis属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAxis() {
		return _axis;
	}

	/**
	 * 格納されているコントロールのリストを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GUIControl> getChildren() {
		List<GUIControl> children = new ArrayList<GUIControl>();
		children.addAll(getElements().values());
		return children;
	}

	/**
	 * colspan属性の値を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return colspan属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getColspan() {
		return _colspan;
	}

	/**
	 * エレメントを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @param id ID属性の値
	 * @return エレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControl getElement(String id) {
		return getElements().get(id);
	}

	/**
	 * エレメントのマップを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return エレメントのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public Map<String, GUIControl> getElements() {
		return _controls;
	}

	/**
	 * headers属性の値を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return headers属性の値
	 * @author yamashita
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public String getHeaders() {
		return _headers;
	}

	/**
	 * rowspan属性の値を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return rowspan属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getRowspan() {
		return _rowspan;
	}

	/**
	 * scope属性の値を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return scope属性の値
	 * @author yamashita
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public String getScope() {
		return _scope;
	}

	/**
	 * abbr属性の値を設定します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param abbr abbr属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAbbr(String abbr) {
		_abbr = abbr;
	}

	/**
	 * axis属性の値を設定します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param axis axis属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAxis(String axis) {
		_axis = axis;
	}

	/**
	 * colspan属性の値を設定します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param colspan colspan属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setColspan(String colspan) {
		_colspan = colspan;
	}

	/**
	 * エレメントのマップを設定します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param controls コントロールのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElements(Map<String, GUIControl> controls) {
		_controls = controls;
		for (GUIControl control : controls.values()) {
			control.setParent(this);
		}
	}

	/**
	 * headers属性の値を設定します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param headers headers属性の値
	 * @author yamashita
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public void setHeaders(String headers) {
		_headers = headers;
	}

	/**
	 * rowspan属性の値を設定します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param rowspan rowspan属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRowspan(String rowspan) {
		_rowspan = rowspan;
	}

	/**
	 * scope属性の値を設定します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param scope scope属性の値
	 * @author yamashita
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public void setScope(String scope) {
		_scope = scope;
	}
}
