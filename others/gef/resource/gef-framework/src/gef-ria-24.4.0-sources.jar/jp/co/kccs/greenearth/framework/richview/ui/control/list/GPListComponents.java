/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * リストコンポーネントを表すUIコントロールです.<br/>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GPListComponents extends GUIItemBase implements GListContents {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5758481784478786668L;
	// 内部変数
	/** テーブルのセルのマップ. */
	private Map<String, GListCell> _cells = new HashMap<String, GListCell>();

	/**
	 * {@link GPListComponents}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListComponents() {
	}

	/**
	 * テーブルのセルを追加します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param cell リストセル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addCell(GListCell cell) {
		getCells().put(cell.getId(), cell);
		cell.setParent(this);
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void clear() {
		if (getCells().isEmpty()) {
			return;
		}
		for (GListCell cell : getCells().values()) {
			cell.clear();
		}
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 常用のUIコンポーネント（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public GListContents createPracticalInstance() throws GViewException {
		GListContents clone = (GListContents) super.createPracticalInstance();
		loadCells(clone);
		return clone;
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param parent リストコントロール
	 * @return 常用のUIコンポーネント（クローン）
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GListContents createPracticalInstance(GList parent) {
		GListContents clone = createPracticalInstance();
		clone.setParent(parent);
		return clone;
	}

	/**
	 * 指定されたエレメントを検索します.<br>
	 * 
	 * @create 2011/07/27
	 * @param id "hoge" or "hoge.idx.fuga..."
	 * @return エレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControl findElement(String id) {
		if (id == null) {
			return null;
		}
		int period = id.indexOf('.');
		String elementId = period == -1 ? id : id.substring(0, period);

		for (String key : getCells().keySet()) {
			GListCell cell = getCell(key);

			for (String controlKey : cell.getElements().keySet()) {
				GUIControl control = cell.getElement(controlKey);

				if (elementId.equals(control.getId())) {
					return control;
				}

				GUIControl childControl = control.findControl(elementId);
				if (childControl != null) {
					return childControl;
				}
			}
		}
		return null;
	}

	/**
	 * セルの情報を読み込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param row テーブルの列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadCells(GListContents row) {
		Map<String, GListCell> cells = new HashMap<String, GListCell>();
		for (GListCell cell : getCells().values()) {
			GListCell ccell = cell.createPracticalInstance(row);
			ccell.setParent(row);
			cells.put(ccell.getId(), ccell);
		}
		row.setCells(cells);
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * 
	 * JSPのHTMLタグの属性を、フィールドに設定します。<br/>
	 * 
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void loadJspElement(Element element) throws GViewException {
		super.loadJspElement(element);
		loadNestedNode(element);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		for (GListCell cell : getCells().values()) {
			cell.reset();
		}
	}

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br />
	 * 
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	private void loadNestedNode(Node node) throws GViewException {
		try {
			NodeList children = node.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// UIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}
				if (clazz != null && GListCell.class.isAssignableFrom(clazz)) {
					GListCell listcell = (GListCell) clazz.newInstance();
					listcell.setParent(this);
					listcell.loadJspElement((Element) child);
					addCell(listcell);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * セルを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @param id セルのID
	 * @return {@link GListCell}
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GListCell getCell(String id) {
		return _cells.get(id);
	}

	/**
	 * セルのマップを取得します.<br/>
	 * 
	 * @create 2011/04/12
	 * @return セルのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public Map<String, GListCell> getCells() {
		return _cells;
	}

	/**
	 * 格納されているコントロールのリストを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GUIControl> getChildren() {
		List<GUIControl> children = new ArrayList<GUIControl>();
		for (GListCell cell : getCells().values()) {
			children.addAll(cell.getChildren());
		}
		return children;
	}

	/**
	 * セルのマップを設定します.<br/>
	 * 
	 * @create 2011/04/12
	 * @param cells セルのマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setCells(Map<String, GListCell> cells) {
		_cells = cells;
		for (GListCell cell : cells.values()) {
			cell.setParent(this);
		}
	}
}
