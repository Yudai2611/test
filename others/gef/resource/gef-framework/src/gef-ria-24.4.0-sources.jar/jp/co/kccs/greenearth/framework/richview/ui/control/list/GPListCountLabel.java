/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLabelValue;
import jp.co.kccs.greenearth.framework.richview.utils.GRIAActionUtils;

/**
 * リストの総サイズとインデックスを表示するラベルコントロールを表すUIコントロールです.<br />
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
public class GPListCountLabel extends GPLabelValue {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3581260802528688613L;
	// 内部変数
	/** リストエレメントID. */
	private String _listelement = null;
	/** 対象となるリストの開始インデックス. */
	private int _startIndex = -1;
	/** 対象となるリストのサイズ. */
	private int _size = 0;
	/** 対象となるリストの総サイズ. */
	private int _totalSize = 0;

	/**
	 * {@link GRSListCountLabel}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListCountLabel() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @create 2011/08/26
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setStartIndex(-1);
		setSize(0);
		setTotalSize(0);
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br>
	 * 
	 * @create 2013/03/05
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		GListData listData = GRIAActionUtils.extractListData(parameter, getListelement());
		loadData(listData);
	}

	@Override
	public void loadData(Object data) {
		if (data == null || !(data instanceof GListData)) {
			return;
		}
		GListData listData = (GListData) data;
		setStartIndex(listData.getStartIndex());
		setTotalSize(listData.getTotalSize());
		setSize(listData.size());
	}
	
	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * @create 2011/08/26
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		if (data.containsDataName(getListelement())) {
			loadData(data.getListData(getListelement()));
		}
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @create 2010/08/26
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPListCountLabel control = (GPListCountLabel) getRepository();
		setStartIndex(control == null ? -1 : control.getStartIndex());
		setSize(control == null ? 0 : control.getSize());
		setTotalSize(control == null ? 0 : control.getTotalSize());
	}

	/**
	 * リストIDを取得します.<br/>
	 * 
	 * @create 2011/7/27
	 * @return リストID
	 * @author H.Nishida
	 * @since 3.9.0
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.GListElement#getListelement()
	 */
	public String getListelement() {
		return _listelement;
	}

	/**
	 * 対象となるリストのサイズを取得します.<br />
	 * 
	 * @create 2011/08/25
	 * @return 対象となるリストのサイズ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public int getSize() {
		return _size;
	}

	/**
	 * 対象となるリストの開始インデックスを取得します.<br />
	 * 
	 * @create 2011/08/25
	 * @return 対象となるリストの開始インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public int getStartIndex() {
		return _startIndex;
	}

	/**
	 * 対象となるリストの総サイズを取得します.<br />
	 * 
	 * @create 2011/08/25
	 * @return 対象となるリストの総サイズ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public int getTotalSize() {
		return _totalSize;
	}

	/**
	 * リストIDを設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.GListElement#setListelement(java.lang.String)
	 * @create 2011/7/27
	 * @param listelement リストID
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setListelement(String listelement) {
		_listelement = listelement;
	}

	/**
	 * 対象となるリストのサイズを設定します.<br />
	 * 
	 * @create 2011/08/25
	 * @param size 対象となるリストのサイズ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSize(int size) {
		_size = size;
	}

	/**
	 * 対象となるリストの開始インデックスを設定します.<br />
	 * 
	 * @create 2011/08/25
	 * @param startIndex 対象となるリストの開始インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStartIndex(int startIndex) {
		_startIndex = startIndex;
	}

	/**
	 * 対象となるリストの総サイズを設定します.<br />
	 * 
	 * @create 2011/08/25
	 * @param totalSize 対象となるリストの総サイズ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTotalSize(int totalSize) {
		_totalSize = totalSize;
	}
}