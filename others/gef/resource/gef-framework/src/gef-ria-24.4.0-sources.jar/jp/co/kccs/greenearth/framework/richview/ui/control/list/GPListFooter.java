/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

/**
 * リストフッターを表すUIコントロールです.<br/>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public class GPListFooter extends GPListComponents implements GListFooter {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4144471614712321114L;

	/**
	 * {@link GPListFooter}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GPListFooter() {
	}

	/**
	 * リクエストパラメータキーの完全な接頭語を返します.<br/>
	 * 
	 * @create 2011/08/26
	 * @return 完全な接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getNamePrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getNamePrefix());
		prefixBuilder.append("footer.");
		return prefixBuilder.toString();
	}

	/**
	 * このコンポーネントの完全なID接頭語を返します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 完全なID接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getPrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getPrefix());
		prefixBuilder.append("footer.");
		return prefixBuilder.toString();
	}
}
