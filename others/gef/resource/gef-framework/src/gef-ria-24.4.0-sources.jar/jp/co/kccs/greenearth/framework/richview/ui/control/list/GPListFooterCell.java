/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

/**
 * リストヘッダーセルを表すUIコントロールです.
 * 
 * @create 2013/03/06
 * @author yamashita
 * @since 3.10.0.D
 */
public class GPListFooterCell extends GPListCell {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 6624798205621097503L;

	/**
	 * {@link GPListFooterCell}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/06
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public GPListFooterCell() {
	}
}
