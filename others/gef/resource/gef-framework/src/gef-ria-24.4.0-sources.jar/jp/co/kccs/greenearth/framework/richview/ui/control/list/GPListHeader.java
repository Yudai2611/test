/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

/**
 * リストヘッダーを表すUIコントロールです.<br/>
 * 
 * @create 2011/04/12
 * @author yamashita
 * @since 3.9.0
 */
public class GPListHeader extends GPListComponents implements GListHeader {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8982218671068448791L;

	/**
	 * {@link GPListHeader}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/04/12
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GPListHeader() {
	}

	/**
	 * リクエストパラメータキーの完全な接頭語を返します.<br/>
	 * 
	 * @create 2011/08/26
	 * @return 完全なNAME接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getNamePrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getNamePrefix());
		prefixBuilder.append("header.");
		return prefixBuilder.toString();
	}

	/**
	 * このコンポーネントの完全なID接頭語を返します.<br/>
	 * 
	 * @create 2011/04/12
	 * @return 完全なID接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getPrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getPrefix());
		prefixBuilder.append("header.");
		return prefixBuilder.toString();
	}
}
