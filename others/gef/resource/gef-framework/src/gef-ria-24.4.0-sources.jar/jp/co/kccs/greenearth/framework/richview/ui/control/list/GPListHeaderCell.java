/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

/**
 * リストヘッダーセルを表すUIコントロールです.
 * 
 * @create 2011/07/28
 * @author yamashita
 * @since 3.9.0
 */
public class GPListHeaderCell extends GPListCell {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2167452977076192150L;

	/**
	 * {@link GPListHeaderCell}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/28
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListHeaderCell() {
	}
}
