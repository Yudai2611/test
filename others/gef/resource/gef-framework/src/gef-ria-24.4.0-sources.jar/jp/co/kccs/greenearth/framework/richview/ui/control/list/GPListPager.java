/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase;
import jp.co.kccs.greenearth.framework.richview.utils.GRIAActionUtils;

/**
 * リストページャを表すUIコントロールです.<br/>
 * 
 * @create 2011/4/25
 * @author H.Nishida
 * @since 3.9.0
 */
public class GPListPager extends GUIContainerControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8427512462616444059L;
	// 拡張属性
	/** リストエレメントID属性の値. */
	private String _listelement = null;
	/** [次へ]要素のID属性の値. */
	private String _next = null;
	/** [前へ]要素のID属性の値. */
	private String _previous = null;
	/** [最初へ]要素のID属性の値. */
	private String _first = null;
	/** [最後へ]要素のID属性の値. */
	private String _last = null;
	/** [ページネーション]要素のID属性の値. */
	private String _pagination = null;
	/** format属性の値. */
	private String _format = "%PAGE%";
	/** スプリッター. */
	private String _splitter = null;
	/** 画面表示ページ数. */
	private String _displaysize = "-1";

	// 内部変数
	/** 総リスト件数. */
	private int _totalListsize = 0;
	/** リストデータサイズ. */
	private int _listDataSize = 0;
	/** 表示しているデータの開始件数. */
	private int _startIndex = 0;

	/**
	 * {@link GPListPager}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/08/26
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListPager() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @create 2011/08/26
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setStartIndex(-1);
		setListDataSize(0);
		setTotalListSize(0);
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br>
	 * 
	 * @create 2013/03/05
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		GListData listData = GRIAActionUtils.extractListData(parameter, getListelement());
		loadData(listData);
		super.loadParameter(parameter);
	}

	/**
	 * データとコントロールの状態を同期化します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase#loadData(java.lang.Object)
	 * @param data
	 * @create 2013/03/18
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void loadData(Object data) {
		if (data == null || !(data instanceof GListData)) {
			return;
		}
		GListData listData = (GListData) data;
		setStartIndex(listData.getStartIndex());
		setTotalListSize(listData.getTotalSize());
		setListDataSize(listData.size());
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * @create 2011/08/26
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		if (data.containsDataName(getListelement())) {
			GListData listData = data.getListData(getListelement());
			setStartIndex(listData.getStartIndex());
			setTotalListSize(listData.getTotalSize());
			setListDataSize(listData.size());
		}
		super.loadResultData(data);
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GRichUIControlBas#reset()
	 * @create 2011/4/25
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GPListPager control = (GPListPager) getRepository();
		setListelement(control == null ? null : control.getListelement());
		setNext(control == null ? null : control.getNext());
		setPrevious(control == null ? null : control.getPrevious());
		setLast(control == null ? null : control.getLast());
		setFirst(control == null ? null : control.getFirst());
		setFormat(control == null ? null : control.getFormat());
		setSplitter(control == null ? null : control.getSplitter());
		setPagination(control == null ? null : control.getPagination());
		setDisplaysize(control == null ? null : control.getDisplaysize());
		setTotalListSize(0);
		setListDataSize(0);
		setStartIndex(0);
	}

	/**
	 * 画面表示ページ数を取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @return 画面表示ページ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getDisplaysize() {
		return _displaysize;
	}

	/**
	 * 最初のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/4/25
	 * @return [最初へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getFirst() {
		return _first;
	}

	/**
	 * 書式文字列を取得します.<br />
	 * 
	 * @create 2011/4/25
	 * @return format属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * 最後のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/4/25
	 * @return [最後へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getLast() {
		return _last;
	}

	/**
	 * リストデータのサイズを取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @return リストデータ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getListDataSize() {
		return _listDataSize;
	}

	/**
	 * リストエレメントのIDを取得します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.GListElement#getListelement()
	 * @create 2011/4/25
	 * @return リストエレメントID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getListelement() {
		return _listelement;
	}

	/**
	 * 次のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/4/25
	 * @return [次へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getNext() {
		return _next;
	}

	/**
	 * ページネーション要素のIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return [ページネーション]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public String getPagination() {
		return _pagination;
	}

	/**
	 * 前のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/4/25
	 * @return [前へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getPrevious() {
		return _previous;
	}

	/**
	 * スプリッター文字列を取得します.<br />
	 * 
	 * @create 2011/4/25
	 * @return スプリッター文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getSplitter() {
		return _splitter;
	}

	/**
	 * 表示しているデータの開始件数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return 表示しているデータの開始件数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getStartIndex() {
		return _startIndex;
	}

	/**
	 * 総レコード数を取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @return 総レコード数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getTotalListSize() {
		return _totalListsize;
	}

	/**
	 * 画面表示ページ数を設定します.<br />
	 * 
	 * @create 2011/6/13
	 * @param displaySize 画面表示ページ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setDisplaysize(String displaySize) {
		_displaysize = displaySize;
	}

	/**
	 * 最初のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/4/25
	 * @param first [最初へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setFirst(String first) {
		_first = first;
	}

	/**
	 * 書式文字列を設定します.<br />
	 * 
	 * @create 2011/4/25
	 * @param format format属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * 最後のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/4/25
	 * @param last [最後へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setLast(String last) {
		_last = last;
	}

	/**
	 * リストデータのサイズを取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @param listDataSize リストデータ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setListDataSize(int listDataSize) {
		_listDataSize = listDataSize;
	}

	/**
	 * リストエレメントのIDを設定します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.GListElement#setListelement(java.lang.String)
	 * @create 2011/4/25
	 * @param listelement リストエレメントID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setListelement(String listelement) {
		_listelement = listelement;
	}

	/**
	 * 次のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/4/25
	 * @param next [次へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setNext(String next) {
		_next = next;
	}

	/**
	 * ページネーション要素のIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param pagination [ページネーション]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public void setPagination(String pagination) {
		_pagination = pagination;
	}

	/**
	 * 前のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/4/25
	 * @param previous [前へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setPrevious(String previous) {
		_previous = previous;
	}

	/**
	 * スプリッター文字列を設定します.<br />
	 * 
	 * @create 2011/4/25
	 * @param splitter スプリッター
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setSplitter(String splitter) {
		_splitter = splitter;
	}

	/**
	 * 表示しているデータの開始件数を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param startIndex 表示しているデータの開始件数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setStartIndex(int startIndex) {
		_startIndex = startIndex;
	}

	/**
	 * 総レコード数を設定します.<br />
	 * 
	 * @create 2011/6/13
	 * @param totalListSize 総レコード数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setTotalListSize(int totalListSize) {
		_totalListsize = totalListSize;
	}
}
