/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase;
import jp.co.kccs.greenearth.framework.richview.utils.GRIAActionUtils;

/**
 * 対象とするリストに、ページ番号を付加するUIコンポーネントです.<br>
 * 
 * 作成したページ番号を選択することで、選択したページへスクロールします。<br/>
 * 
 * @create 2011/6/14
 * @author H.Nishida
 * @since 3.9.0
 */
public class GPListPagination extends GUIControlBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 9134176591908325125L;

	/** 総ページ数. */
	private int _totalPageSize = 0;
	/** 処理対象ページ数 */
	private int _targetPage = 1;
	/** 開始ページ数 */
	private int _firstPage = 1;
	/** カレントページ. */
	private int _currentPage = 0;

	/**
	 * {@link GPListPagination}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/6/14
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListPagination() {
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 
	 * @create 2011/08/26
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void clear() {
		super.clear();
		setTotalPageSize(0);
		setTargetPage(1);
		setFirstPage(1);
		setCurrentPage(0);
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br>
	 * 
	 * @create 2013/03/05
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void loadParameter(GParameter parameter) {
		GPListPager pager = (GPListPager) getParent();
		GListData listData = GRIAActionUtils.extractListData(parameter, pager.getListelement());
		loadData(listData);
	}

	/**
	 * リストデータとコントロールの状態を同期化します.<br/>
	 * 
	 * @param listData
	 * @create 2013/03/18
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	protected void loadData(GListData listData) {
		if (listData == null || listData.isEmpty()) {
			return;
		}
		int totalRecordSize = listData.getTotalSize();
		int listSize = listData.getMaxListSize();
		int totalPageSize = (totalRecordSize + listSize - 1) / listSize;
		setTotalPageSize(totalPageSize);
		int startIndex = listData.getStartIndex();
		int currentPage = startIndex / listSize + 1;
		setCurrentPage(currentPage);
	}
	
	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * 
	 * @create 2011/08/26
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void loadResultData(GResultData data) {
		GPListPager parent = (GPListPager) getParent();
		if (data.containsDataName(parent.getListelement())) {
			loadData(data.getListData(parent.getListelement()));
		}
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.GRichUIControlBas#reset()
	 * @create 2011/4/25
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		setTotalPageSize(0);
		setTargetPage(1);
		setFirstPage(1);
		setCurrentPage(0);
	}

	/**
	 * カレントページを取得します.<br />
	 * 
	 * @create 2011/4/26
	 * @return カレントページ
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getCurrentPage() {
		return _currentPage;
	}

	/**
	 * 開始ページ数を取得します.<br/>
	 * 
	 * @create 2011/5/6
	 * @return 開始ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getFirstPage() {
		return _firstPage;
	}

	/**
	 * 対象ページ数を取得します.<br/>
	 * 
	 * @create 2011/5/6
	 * @return 対象ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getTargetPage() {
		return _targetPage;
	}

	/**
	 * 総ページ数を取得します.<br />
	 * 
	 * @create 2011/4/26
	 * @return 総ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getTotalPageSize() {
		return _totalPageSize;
	}

	/**
	 * カレントページを設定します.<br />
	 * 
	 * @create 2011/4/26
	 * @param currentPage カレントページ
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setCurrentPage(int currentPage) {
		_currentPage = currentPage;
	}

	/**
	 * 開始ページ数を設定します.<br/>
	 * 
	 * @create 2011/5/6
	 * @param firstPage 開始ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setFirstPage(int firstPage) {
		_firstPage = firstPage;
	}

	/**
	 * 対象ページ数を設定します.<br/>
	 * 
	 * @create 2011/5/6
	 * @param targetPage 対象ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setTargetPage(int targetPage) {
		_targetPage = targetPage;
	}

	/**
	 * 総ページ数を設定します.<br />
	 * 
	 * @create 2011/4/26
	 * @param pageSize 総ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setTotalPageSize(int pageSize) {
		_totalPageSize = pageSize;
	}
}