/*
 * Copyright 2011-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl;
import jp.co.kccs.greenearth.framework.richview.utils.GRIAActionUtils;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * リストロウを表すUIコントロールです.
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public class GPListRow extends GPListComponents implements GListRow {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 872960884682523546L;
	/** リストの行インデックス. */
	private int _rowIndex = -1;
	/**
	 * _displayRowIndex：現在の行のインディクス<br/>
	 *　・NonVisibleの行番号を飛ばして連番となっているため<br/>
	 *　・DisableまたはNonVisibleの状態を示すHTML(※__@_index_@_internal_non-visibled...)のID(indexの部分)は、明細番号順に前詰め連番のため<br/>
	 * @create 2021/03/18
	 * @author KCSS
	 * @since 21.3.0
	 */
	private int _displayRowIndex = -1;

	/**
	 * {@link GPListRow}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListRow() {
	}

	/**
	 * 指定された値を出力内容に設定します.<br/>
	 * 
	 * caption, headerへのバインディングは行いません。<br/>
	 * 
	 * @create 2011/07/27
	 * @param rowData データ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadData(GRowData rowData) {
		for (GListCell cell : getCells().values()) {
			cell.setParent(this);
			List<GVariableControl> variableList = new ArrayList<GVariableControl>();
			for (GUIControl control : cell.getElements().values()) {
				cell.fillVariableList(variableList, control);
			}
			for (GVariableControl variableControl : variableList) {
				if (rowData.containsName(variableControl.getId())) {
					Object value = rowData.getData(variableControl.getId());
					variableControl.setParent(cell);
					variableControl.loadData(value);
				}
			}
		}
	}

	/**
	 * コントロールの検証エラーを読込みます.<br/>
	 * 
	 * @create 2011/07/27
	 * @param errors 検証エラーのリスト
	 * @return コントロールのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GVariableControl> loadValidateError(List<GValidateError> errors) {
		List<GVariableControl> variableList = new ArrayList<GVariableControl>();
		for (GListCell cell : getCells().values()) {
			for (GUIControl control : cell.getElements().values()) {
				cell.fillVariableList(variableList, control);
			}
		}
		for (GVariableControl variableControl : variableList) {
			variableControl.loadValidateError(errors);
		}
		return variableList;
	}

	/**
	 * コントロール入力値の検証を行います.<br/>
	 * 
	 * 内包されるリストの検証は行いません。<br/>
	 * 
	 * @create 2011/07/27
	 * @param parameter パラメータ
	 * @return 検証エラーのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GValidateError> validate(GParameter parameter) {
		List<GValidateError> allErrors = null;
		GErrorLevel errorlevel = parameter.getValidationLevel();
		GPList parent = (GPList) getParent();
		GListData listData = GRIAActionUtils.extractListData(parameter, parent.getName());
		if (listData == null) {
			return allErrors;
		}
		for (GListCell cell : getCells().values()) {
			List<GVariableControl> variableList = new ArrayList<GVariableControl>();
			for (GUIControl control : cell.getElements().values()) {
				cell.fillVariableList(variableList, control);
			}
			for (GVariableControl variableControl : variableList) {
				String[] names = variableControl.getParameterKey().split("\\.");
				if (names.length != 2) {
					continue; // 内包されるリスト以下は検証しない(="."区切りが1つ以上はパス)
				}
				GRowData rowData = listData.get(getRowIndex());
				if (rowData.containsName(names[1])) {
					String value = rowData.getString(names[1]);
					if (value == null) {
						continue;
					}
					List<GValidateError> errors = variableControl.validate(value, errorlevel);
					if (errors != null) {
						if (allErrors == null) {
							allErrors = new ArrayList<GValidateError>();
						}
						allErrors.addAll(errors);
					}
				}
			}
		}
		return allErrors;
	}

	/**
	 * エラー項目の表示名の名前空間を取得します.<br/>
	 * 
	 * @create 2011/08/12
	 * @return 表示名の名前空間
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getLabelspace() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getLabelspace());
		prefixBuilder.append("[");
		prefixBuilder.append(getRowIndex() + 1);
		prefixBuilder.append("]");
		return prefixBuilder.toString();
	}

	/**
	 * このコンポーネントの完全なID接頭語を返します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return 完全なID接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getPrefix() {
		StringBuilder prefixBuilder = new StringBuilder();
		prefixBuilder.append(super.getPrefix());
		prefixBuilder.append(getRowIndex());
		prefixBuilder.append(".");
		return prefixBuilder.toString();
	}

	/**
	 * リストの行インデックスを取得します.<br />
	 * 
	 * @create 2011/04/12
	 * @return リストの行インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public int getRowIndex() {
		return _rowIndex;
	}

	/**
	 * リストの行インデックスを設定します.<br />
	 * 
	 * @create 2011/04/12
	 * @param rowIndex リストの行インデックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRowIndex(int rowIndex) {
		_rowIndex = rowIndex;
	}
	/**
	 * 現在の行のインディクス（DisplayRowIndex）取得<br/>
	 *　・NonVisibleの行番号を飛ばして連番となっているため<br/>
	 *　・DisableまたはNonVisibleの状態を示すHTML(※__@_index_@_internal_non-visibled...)のID(indexの部分)は、明細番号順に前詰め連番のため<br/>
	 * @create 2021/03/18
	 * @author KCSS
	 * @since 21.3.0
	 */
	public int getDisplayRowIndex() {
		return _displayRowIndex;
	}
	/**
	 * 現在の行のインディクス（DisplayRowIndex）設定<br/>
	 *　・NonVisibleの行番号を飛ばして連番となっているため<br/>
	 *　・DisableまたはNonVisibleの状態を示すHTML(※__@_index_@_internal_non-visibled...)のID(indexの部分)は、明細番号順に前詰め連番のため<br/>
	 * @create 2021/03/18
	 * @author KCSS
	 * @since 21.3.0
	 */
	public void setDisplayRowIndex(int _displayRowIndex) {
		this._displayRowIndex = _displayRowIndex;
	}
}
