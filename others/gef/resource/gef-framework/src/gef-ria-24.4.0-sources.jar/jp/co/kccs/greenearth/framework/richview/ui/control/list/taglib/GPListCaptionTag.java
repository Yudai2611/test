/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListCaption;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListCaption;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GContainerTag;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストキャプションを表示するタグクラスです.<br/>
 * 
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListCaption.class)
public class GPListCaptionTag extends GUIItemBaseTag implements GContainerTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7985539346736053461L;
	// 内部制御フィールド
	/** エレメントのマップ. */
	private Map<String, GUIControl> _elements = new HashMap<String, GUIControl>();
	/** タグに関連付けられたコンポーネント. */
	private GUIComponent _component = null;
	/** スタイルシートのクラス名（Captionに適用）. */
	private static final String DEFAULT_STYLECLASS = "ui-widget-header geui-gplist-caption";

	/**
	 * {@link GPListCaptionTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListCaptionTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親となる{@link GPListTag}から、現在の行数を取得し、<code>-1</code>の場合のみ
	 * caption要素の終了タグを出力します。<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		GPListTag parent = (GPListTag) findAncestorWithClass(this, GPListTag.class);
		if (parent != null && parent.isFirstEval()) {
			if (isVisible()) {
				GTagUtils.printOut(pageContext, parent.getScrollStrategy().createCaptionEndTag(this));
			}
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親となる{@link GPListTag}から、現在の行数を取得し、<code>-1</code>の場合のみ
	 * {@link GListCaption}を取得し、そのフィールドから属性の情報を読み込んでいます。<br/>
	 * 読み込んだ属性情報よりcaption要素の開始タグを出力します。<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		GPListTag parent = (GPListTag) findAncestorWithClass(this, GPListTag.class);
		if (parent != null && parent.isFirstEval()) {
			GListCaption listCaption = parent.getCaption();
			if (listCaption != null) {
				load(listCaption);
			}
			if (isVisible()) {
				GTagUtils.printOut(pageContext, parent.getScrollStrategy().createCaptionStartTag(this));
				return EVAL_BODY_INCLUDE;
			}
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPListCaption ui = (GPListCaption) component;
		setElements(ui.getElements());
		setAssociatedComponent(component);
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @return XHTML文字列
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	protected String createXhtmlString() {
		GTagBuilder builder = createCaptionTagBuilder();
		return builder.createStartTagString();
	}
	
	
	/**
	 * CAPTION用のタグビルダーを作成します。
	 * 
	 * @return 必要な要素がすべて設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createCaptionTagBuilder() {
		GTagBuilder builder = new GTagBuilder("caption");
		decorateAttribute(builder);
		return builder;
	}
	
	
	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * タグに関連付けられたコンポーネントを取得します.<br />
	 * 
	 * @return コンポーネント
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GUIComponent getAssociatedComponent() {
		return _component;
	}

	/**
	 * マップから指定されたidのUIコントロールを取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GContainerTag#getControl(java.lang.String)
	 * @param key UIコントロールのid
	 * @return UIコントロール
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GUIControl getControl(String key) {
		return _elements.get(key);
	}

	/**
	 * エレメントのマップを取得します.<br />
	 * 
	 * @return エレメントのマップ
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public Map<String, GUIControl> getElements() {
		return _elements;
	}

	/**
	 * タグに関連付けられたコンポーネントを設定します.<br />
	 * 
	 * @param component コンポーネント
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setAssociatedComponent(GUIComponent component) {
		_component = component;
	}

	/**
	 * エレメントのマップを設定します.<br />
	 * 
	 * @param elements エレメントのマップ
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setElements(Map<String, GUIControl> elements) {
		_elements = elements;
	}
}
