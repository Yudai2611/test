/*
 * Copyright 2011-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.*;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GContainerTag;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストセルを表示するタグクラスです.<br/>
 *
 * @create 2011/04/25
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListCell.class)
public abstract class GPListCellTag extends GUIItemBaseTag implements GContainerTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7793104692632131383L;
	/** スタイルシートのクラス名 */
	private static final String DEFAULT_STYLECLASS = "ui-state-default";

	// XHTML属性
	/** セルを n個、横方向に連結します. */
	private String _colspan;

	/** セルを n個、縦方向に連結します. */
	private String _rowspan;

	/** セルの内容の省略情報を記述します。音声ブラウザがセルの概略を読み上げるのに役立ちます. */
	private String _abbr;

	/** 多次元配列データのための軸情報などを記述します. */
	private String _axis;

	/** このセルに対応する見出しセルのリストを、id 属性で指定します. */
	private String _headers;

	/** セルの幅を指定します. */
	private String _width;

	/**
	 * 見出しセルに対して指定します。row はその見出しが列方向に対する見出しであること、col
	 * はその見出しが行方向に対する見出しであることを示します.<br />
	 */
	private String _scope;

	// 内部変数
	/** エレメントを保持します. */
	private Map<String, GUIControl> _elements;

	/** タグに関連付けられたコンポーネント. */
	private GUIComponent _component;

	/**
	 * {@link GPListCellTag}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2011/4/26
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListCellTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 *
	 * td要素の終了タグを出力します。<br/>
	 *
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @create 2011/4/26
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder tdTag = new GTagBuilder("td");
			printInternalHTML();
			GTagUtils.printOut(pageContext, tdTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 *
	 * 親となる{@link GPListComponentsTag}からid属性の値をキーにして、{@link GListCell}アイテムを取得し、
	 * そのフィールドから属性情報を読み込んでいます。 読み込んだ属性からXHTML文字列を生成し、JSPに出力しています。<br/>
	 *
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/4/26
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GPListCell}の取得・ロード、タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		GPListComponentsTag parent = (GPListComponentsTag) findAncestorWithClass(this, GPListComponentsTag.class);
		if (parent != null) {
			GListCell cell = parent.getCell(getId());
			if (cell != null) {
				load(cell);
			}
		}
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	protected void printInternalHTML() throws JspException {
		GListCell cell = (GListCell) getAssociatedComponent();
		if (cell == null) {
			return;
		}
		for (GUIControl control : cell.getChildren()) {
			GTagUtils.printOut(pageContext, createInternalHTML(control));
		}
	}
	
	protected String createInternalHTML(GUIControl control) {
		if (!(control instanceof GVariableControl)) {
			return "";
		}
		GVariableControl variable = (GVariableControl) control;
		
		StringBuilder internalHtml = new StringBuilder();
		if (!variable.isVisible()) {
			internalHtml.append(createInternalNonVisibleHTMLString(variable));
		}
		if (variable.isVisible() && !variable.isEnabled()) {
			internalHtml.append(createInternalDisabledHTMLString(variable));
		}
		return internalHtml.toString();
	}

	protected String createInternalNonVisibleHTMLString(GVariableControl variable) {
		return createInternalHTMLCommonString(variable, GPList.INTERNAL_NON_VISIBLE_HTML_ID_SUFFIX, GPList.INTERNAL_NON_VISIBLE_VALUE);
	}
	
	protected String createInternalDisabledHTMLString(GVariableControl variable) {
		return createInternalHTMLCommonString(variable, GPList.INTERNAL_DISABLED_HTML_ID_SUFFIX, GPList.INTERNAL_DISABLED_VALUE);
	}
	
	/**
	 * NonVisibleまたはDisabledの状態を示すInternalなHTMLのID体系に要素順を関連付けします。<br/>
	 * ※@@_要素順_@@<br/>
	 * ※要素順は、サーバサイドにリクエストされたパラメータをGListDataへ復元する際に必要となります。<br/>
	 */
	protected String createInternalHTMLCommonString(GVariableControl variable, String nameSuffix, String value) {
		GListCell cell = (GListCell) getAssociatedComponent();
		GPListRow row = (GPListRow) cell.getParent();
		GTagBuilder builder = new GTagBuilder("input");
		final String suffix = new StringBuilder()
				.append(GPList.SUFFIX_SEPARATOR)
				.append(row.getDisplayRowIndex())
				.append(GPList.SUFFIX_SEPARATOR)
				.append(nameSuffix)
				.toString();
		builder.setAttribute("type", "hidden");
		builder.setAttribute("id", variable.getFullId() + suffix);
		builder.setAttribute("name", variable.getParameterKey() + suffix);
		builder.setAttribute("value", value);
		return builder.createTagString();
	}
	
	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.richview.component.GUIComponent)
	 * @create 2011/4/26
	 * @param component レンダリング対象UIコンポーネント
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPListCell ui = (GPListCell) component;
		GPListCell rep = (GPListCell) component.getRepository();
		setColspan(evaluatePlaceholder(ui.getColspan(), getColspan(),
				rep == null ? null : rep.getColspan(), ui));
		setRowspan(evaluatePlaceholder(ui.getRowspan(), getRowspan(),
				rep == null ? null : rep.getRowspan(), ui));
		setAbbr(evaluatePlaceholder(ui.getAbbr(), getAbbr(),
				rep == null ? null : rep.getAbbr(), ui));
		setAxis(evaluatePlaceholder(ui.getAxis(), getAxis(),
				rep == null ? null : rep.getAxis(), ui));
		setScope(evaluatePlaceholder(ui.getScope(), getScope(),
				rep == null ? null : rep.getScope(), ui));
		setHeaders(evaluatePlaceholder(ui.getHeaders(), getHeaders(),
				rep == null ? null : rep.getHeaders(), ui));
		setElements(ui.getElements());
		setAssociatedComponent(component);
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 *
	 * @create 2013/08/20
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public void reset() {
		super.reset();
		_elements = null;
	}

	/**
	 * XHTML文字列を生成します.<br />
	 *
	 * @create 2011/4/26
	 * @return XHTML文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	protected String createXhtmlString() {
		GTagBuilder tdTag = new GTagBuilder("td");
		decorateAttribute(tdTag);
		return tdTag.createStartTagString();
	}

	/**
	 * 指定されたタグビルダーにこのタグの基本属性を追加します.<br/>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.richview.ui.taglib.GTagBuilder)
	 * @create 2011/4/26
	 * @param builder 属性を追記するGTagBuilder
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("colspan", _colspan);
		builder.setAttribute("rowspan", _rowspan);
		builder.setAttribute("abbr", _abbr);
		builder.setAttribute("axis", _axis);
		builder.setAttribute("scope", _scope);
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/06/21
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		styleclass.add(getCellStyleClass());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * セルの内容の省略情報を取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return セルの内容の省略情報
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getAbbr() {
		return _abbr;
	}

	/**
	 * タグに関連付けられたコンポーネントを取得します.<br />
	 *
	 * @create 2011/06/11
	 * @return コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponent getAssociatedComponent() {
		return _component;
	}

	/**
	 * 多次元配列データのための軸情報などを取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return 多次元配列データのための軸情報など
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getAxis() {
		return _axis;
	}

	/**
	 * セルの横方向への連結個数を取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return セルの横方向への連結個数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getColspan() {
		return _colspan;
	}

	/**
	 * マップから指定されたidの{@link GRichUIControl}インスタンスを取得します.<br />
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GContainerTag#getControl(java.lang.String)
	 * @create 2011/4/26
	 * @param id {@link GRichUIControl}インスタンスのid
	 * @return {@link GRichUIControl}インスタンス
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GUIControl getControl(String id) {
		return getElements().get(id);
	}

	/**
	 * エレメントのマップを取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return エレメントのマップ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public Map<String, GUIControl> getElements() {
		if (_elements == null) {
			_elements = new HashMap<String, GUIControl>();
		}
		return _elements;
	}

	/**
	 * このセルに対応する見出しセルのリストのid 属性を取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return このセルに対応する見出しセルのリストのid 属性
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public String getHeaders() {
		return _headers;
	}

	/**
	 * セルの縦方向への連結個数を取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return セルの縦方向への連結個数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getRowspan() {
		return _rowspan;
	}

	/**
	 * 見出し情報を摘要する方向を取得します.<br>
	 *
	 * @create 2011/4/26
	 * @return <code>row</code>/<code>col</code>/<code>rowgroup</code>/
	 *         <code>colgroup</code>
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public String getScope() {
		return _scope;
	}

	/**
	 * セルの幅を取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return セルの幅
	 * @author H.Nishia
	 * @since 3.9.0
	 */
	@Deprecated
	public String getWidth() {
		return _width;
	}

	/**
	 * セルの内容の省略情報を設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param abbr セルの内容の省略情報を
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setAbbr(String abbr) {
		_abbr = abbr;
	}

	/**
	 * タグに関連付けられたコンポーネントを設定します.<br />
	 *
	 * @create 2011/06/11
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAssociatedComponent(GUIComponent component) {
		_component = component;
	}

	/**
	 * 多次元配列データのための軸情報などを設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param axis 多次元配列データのための軸情報など
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setAxis(String axis) {
		_axis = axis;
	}

	/**
	 * セルの横方向への連結個数を設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param colspan セルの横方向への連結個数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setColspan(String colspan) {
		_colspan = colspan;
	}

	/**
	 * エレメントのマップを設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param elements エレメントのマップ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setElements(Map<String, GUIControl> elements) {
		_elements = elements;
	}

	/**
	 * このセルに対応する見出しセルのリストのid 属性を設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param headers このセルに対応する見出しセルのリストのid 属性
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public void setHeaders(String headers) {
		_headers = headers;
	}

	/**
	 * セルの縦方向への連結個数を設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param rowspan セルの縦方向への連結個数
	 * @author H.Nishia
	 * @since 3.9.0
	 */
	public void setRowspan(String rowspan) {
		_rowspan = rowspan;
	}

	/**
	 * 見出し情報を摘要する方向を設定します.<br>
	 * <code>row</code>:そのセルに関する見出し情報を行方向に適用<br>
	 * <code>col</code>:そのセルに関する見出し情報を列方向に適用 <br>
	 * <code>rowgroup</code>:そのセルに関する見出し情報を行グループ全体に適用<br>
	 * <code>colgroup</code>:そのセルに関する見出し情報を列グループ全体に適用<br>
	 *
	 * @create 2011/4/26
	 * @param scope <code>row</code>/<code>col</code>/<code>rowgroup</code>/
	 *            <code>colgroup</code>
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public void setScope(String scope) {
		_scope = scope;
	}

	/**
	 * セルの幅を設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param width セルの幅
	 * @author H.Nishia
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public void setWidth(String width) {
		_width = width;
	}

	/**
	 * セルのスタイルクラスを取得します.<br/>
	 *
	 * @create 2011/4/26
	 * @author H.Nishida<BR>
	 * @since 3.9.0<BR>
	 * @return セルのスタイルクラス文字列
	 */
	protected abstract String getCellStyleClass();
}