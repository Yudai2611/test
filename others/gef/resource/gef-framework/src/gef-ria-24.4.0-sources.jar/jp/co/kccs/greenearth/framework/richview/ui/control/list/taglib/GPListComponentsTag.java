/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import java.util.Map;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListCell;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListContents;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListComponents;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * リストコンポーネントを表示するタグクラスです.<br/>
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
public abstract class GPListComponentsTag extends GUIItemBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4948381621771937227L;
	// 内部変数
	/** テーブルのセルのマップ. */
	private Map<String, GListCell> _cells;
	/** {@link GRSListRowBase}オブジェクト. */
	private GListContents _contents;

	/**
	 * {@link GPListComponentsTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListComponentsTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @create 2011/07/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.richview.component.GUIComponent)
	 * @create 2011/07/27
	 * @param component レンダリング対象UIコンポーネント
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPListComponents ui = (GPListComponents) component;
		setCells(ui.getCells());
		setContents(ui);
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/07/27
	 * @return XHTML文字列
	 * @author H.Nishida
	 * @param lineId
	 * @since 3.9.0
	 */
	protected String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("tr");
		decorateAttribute(builder);
		return builder.createStartTagString();
	}

	/**
	 * マップから指定されたidの{@link GListCell}インスタンスを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @param key {@link GListCell}インスタンスのid
	 * @return {@link GListCell}インスタンス
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GListCell getCell(String key) {
		return _cells.get(key);
	}

	/**
	 * セルのマップを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return セルのマップ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public Map<String, GListCell> getCells() {
		return _cells;
	}

	/**
	 * リストの行を取得します.<br />
	 * 
	 * @create 2011/4/26
	 * @return リストの行
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GListContents getContents() {
		return _contents;
	}

	/**
	 * セルのマップを設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param cells セルのマップ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setCells(Map<String, GListCell> cells) {
		_cells = cells;
	}

	/**
	 * リストの行を設定します.<br />
	 * 
	 * @create 2011/4/26
	 * @param contents リストの行
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setContents(GListContents contents) {
		_contents = contents;
	}
}