/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListCountLabel;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GPLabelValueTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストカウントラベルを表示するタグクラスです.<br/>
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListCountLabel.class)
public class GPListCountLabelTag extends GPLabelValueTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3223284624903791252L;
	// 内部変数
	/** 対象となるリストの開始インデックス. */
	private int _startIndex = -1;
	/** 対象となるリストのサイズ. */
	private int _size = 0;
	/** 対象となるリストの総サイズ. */
	private int _totalSize = 0;
	/** リストエレメントID. */
	private String _listelement = null;

	/**
	 * {@link GPListCountLabelTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListCountLabelTag() {
	}

	/**
	 * XHTML文字列を生成します.<br>
	 * 
	 * value属性にフォーマットが指定されている場合は、指定されたフォーマットに従って件数を表示します。<br>
	 * フォーマットの指定がない場合はデフォルトの表示になります。<br>
	 * （※デフォルト表示の例：　1-10 of 30　）<br>
	 * <br>
	 * フォーマットには、変数を使用することができます。<br>
	 * 【使用できる変数】<br>
	 * %TOTAL%　:　総サイズ　<br>
	 * %START%　:　開始インデックス<br>
	 * %END%　:　終了インデックス<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GPLabelValueTag#createXhtmlString()
	 * @create 2011/7/27
	 * @return XHTML文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() {
		int startNo = 0;
		int endNo = 0;
		if (_totalSize != 0) {
			startNo = _startIndex + 1;
			endNo = _startIndex + _size;
		}
		String formatValue = getDisplay();
		if (!GStringUtils.isEmpty(formatValue)) {
			formatValue = formatValue.replaceAll("%START%", String.valueOf(startNo));
			formatValue = formatValue.replaceAll("%END%", String.valueOf(endNo));
			formatValue = formatValue.replaceAll("%TOTAL%", String.valueOf(_totalSize));
			return formatValue;
		}
		StringBuilder defaultFormattedvalue = new StringBuilder();
		defaultFormattedvalue.append(startNo);
		defaultFormattedvalue.append("-");
		defaultFormattedvalue.append(endNo);
		defaultFormattedvalue.append(" of ");
		defaultFormattedvalue.append(_totalSize);
		return defaultFormattedvalue.toString();
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親タグからidをキーにして、{@link GPListCountLabel}コントロールを取得し、 そのフィールドから属性情報を読み込んでいます。<br>
	 * リストの開始インデックス、サイズ、総サイズが0以上の場合、 XHTML文字列を出力します。<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/7/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			if (_startIndex >= -1 && _size >= 0 && _totalSize >= 0) {
				GTagUtils.printOut(pageContext, GTagUtils.escapeTextContent(createXhtmlString()));
			}
		}
		reset();
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.richview.component.GUIComponent)
	 * @create 2011/7/27
	 * @param component レンダリング対象UIコンポーネント
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPListCountLabel ui = (GPListCountLabel) component;
		GPListCountLabel rep = (GPListCountLabel) component.getRepository();
		setListelement(evaluatePlaceholder(ui.getListelement(), getListelement(),
				rep == null ? null : rep.getListelement(), ui));
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		GResultData resultData = (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);
		if (resultData.containsDataName(getListelement())) {
			GListData listData = resultData.getListData(getListelement());
			int startindex = listData.getStartIndex();
			int totalsize = listData.getTotalSize();
			int size = listData.size();
			ui.setStartIndex(startindex);
			ui.setTotalSize(totalsize);
			ui.setSize(size);
		}
		setStartIndex(ui.getStartIndex());
		setTotalSize(ui.getTotalSize());
		setSize(ui.getSize());
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#reset()
	 * @create 2011/04/04
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		setStartIndex(0);
		setTotalSize(0);
		setSize(0);
	}

	/**
	 * リストエレメントIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return リストエレメントID
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getListelement() {
		return _listelement;
	}

	/**
	 * 対象となるリストのサイズを取得します.<br />
	 * 
	 * @create 2011/7/27
	 * @return 対象となるリストのサイズ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getSize() {
		return _size;
	}

	/**
	 * 対象となるリストの開始インデックスを取得します.<br />
	 * 
	 * @create 2011/7/27
	 * @return 対象となるリストの開始インデックス
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getStartIndex() {
		return _startIndex;
	}

	/**
	 * 対象となるリストの総サイズを取得します.<br />
	 * 
	 * @create 2011/7/27
	 * @return 対象となるリストの総サイズ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getTotalSize() {
		return _totalSize;
	}

	/**
	 * リストエレメントIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param listelement リストエレメントID
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setListelement(String listelement) {
		_listelement = listelement;
	}

	/**
	 * 対象となるリストのサイズを設定します.<br />
	 * 
	 * @create 2011/7/27
	 * @param size 対象となるリストのサイズ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setSize(int size) {
		_size = size;
	}

	/**
	 * 対象となるリストの開始インデックスを設定します.<br />
	 * 
	 * @create 2011/7/27
	 * @param startIndex 対象となるリストの開始インデックス
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setStartIndex(int startIndex) {
		_startIndex = startIndex;
	}

	/**
	 * 対象となるリストの総サイズを設定します.<br />
	 * 
	 * @create 2011/7/27
	 * @param totalSize 対象となるリストの総サイズ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setTotalSize(int totalSize) {
		_totalSize = totalSize;
	}

	/**
	 * リスト件数表示に使用するフォーマット文字列を取得します.<br />
	 * 
	 * @create 2011/7/27
	 * @return フォーマット文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	protected String getDisplay() {
		return getValue();
	}
}
