/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListFooterCell;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * リストのフッター部分のセルを表示するタグクラスです.<br>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GPListFooterCell.class)
public class GPListFooterCellTag extends GPListCellTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 9150153096298762171L;
	/** スタイルシートのクラス名 */
	private static final String DEFAULT_STYLECLASS = "geui-gplist-footer-cell";

	/**
	 * {@link GRSListFooterCellTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListFooterCellTag() {
	}

	/**
	 * セルのスタイルクラスを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0<BR>
	 * @return セルのスタイルクラス文字列
	 */
	@Override
	protected String getCellStyleClass() {
		return DEFAULT_STYLECLASS;
	}
}
