/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

/**
 * リストフッターラインを表示するタグクラスです.
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
public class GPListFooterLineTag extends GPListLineBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2077566563485357786L;

	/**
	 * {@link GPListFooterLineTag}ﾌ新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListFooterLineTag() {
	}

}