/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListFooter;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListFooter;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストフッターを表示するタグクラスです.
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListFooter.class)
public class GPListFooterTag extends GPListComponentsTag {


	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 6144596914287019797L;
	
	/** デフォルトスタイルクラス */
	protected static final String DEFAULT_STYLECLASS = "geui-gplist-footer";

	/**
	 * {@link GPListFooterTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListFooterTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.list.taglib.GListRowTag#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2011/07/27
	 * @author H.Nishida<BR>
	 * @since 3.9.0<BR>
	 * 
	 */
	@Override
	public int doEndTag() throws JspException {
		GPListTag parent = (GPListTag) findAncestorWithClass(this, GPListTag.class);
		if (parent.isLastEval()) { // 行出力完了後
			GTagUtils.printOut(pageContext, parent.getScrollStrategy().createFooterEndTag(this));
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/07/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		GPListTag parent = (GPListTag) findAncestorWithClass(this, GPListTag.class);
		if (parent != null && parent.isLastEval()) {
			GTagUtils.printOut(pageContext, parent.getScrollStrategy().createFooterStartTag(this));
			GListFooter footer = parent.getFooter();
			if (footer != null) {
				load(footer);
			}
			if (isVisible()) {
				return EVAL_BODY_INCLUDE;
			}
		}
		return SKIP_BODY;
	}
	
	/**
	 * TFootタグ用のタグビルダーを作成します。
	 * 
	 * @return 全ての要素が設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createTfootTagBuilder() {
		GTagBuilder tag = new GTagBuilder("tfoot");
		tag.setAttribute("class", GPListFooterTag.DEFAULT_STYLECLASS);
		return tag;
	}
}