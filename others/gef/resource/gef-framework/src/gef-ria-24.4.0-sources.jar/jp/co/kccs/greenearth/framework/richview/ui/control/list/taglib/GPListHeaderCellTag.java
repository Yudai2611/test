/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListHeaderCell;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * リストのヘッダーセルを表示するタグクラスです.<br>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GPListHeaderCell.class)
public class GPListHeaderCellTag extends GPListCellTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6590261376483365805L;
	/** スタイルシートのクラス名 */
	private static final String DEFAULT_STYLECLASS = "geui-gplist-header-cell";

	/**
	 * {@link GPListHeaderCellTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListHeaderCellTag() {
	}

	/**
	 * セルのスタイルクラスを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0<BR>
	 * @return セルのスタイルクラス文字列
	 */
	@Override
	protected String getCellStyleClass() {
		return DEFAULT_STYLECLASS;
	}
}