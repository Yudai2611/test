/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

/**
 * リストヘッダーラインを表示するタグクラスです.
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
public class GPListHeaderLineTag extends GPListLineBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5330032239933411025L;

	/**
	 * {@link GPListHeaderLineTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListHeaderLineTag() {
	}

}