/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストラインを表示する基底タグクラスです.<br/>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GPListLineBaseTag extends GUIItemBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3560601785905158338L;

	/**
	 * {@link GPListLineBaseTag}の新しいインスタンスを生成します.<br />
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListLineBaseTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @create 2011/07/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		GPListComponentsTag parent = (GPListComponentsTag) findAncestorWithClass(this, GPListComponentsTag.class);
		if (parent != null) {
			if (parent.isVisible()) {
				GTagUtils.printOut(pageContext, "</tr>");
			}
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/07/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GPListCell}の取得・ロード、タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		GPListComponentsTag parent = (GPListComponentsTag) findAncestorWithClass(this, GPListComponentsTag.class);
		if (parent != null) {
			if (parent.isVisible()) {
				GTagUtils.printOut(pageContext, parent.createXhtmlString());
				return EVAL_BODY_INCLUDE;
			}
		}
		return SKIP_BODY;
	}
}