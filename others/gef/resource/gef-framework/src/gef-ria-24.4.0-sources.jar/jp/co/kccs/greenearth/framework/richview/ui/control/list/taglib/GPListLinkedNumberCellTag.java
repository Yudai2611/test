/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListCell;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListCell;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GAnchorUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リンクリストナンバーを表示するタグクラスです.<br/>
 * 
 * @create 2016/02/01
 * @author kikuchi
 * @since 3.17.0
 */
@TargetUIComponent(GPListCell.class)
public class GPListLinkedNumberCellTag extends GPListRowCellTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2313162731460574681L;
	/** デフォルトのスタイルクラス **/
	private static final String DEFAULT_STYLECLASS = "geui-gplist-linkednumbercell";
	/** リンクのスタイルシートのクラス名 */
	private static final String LINK_STYLECLASS = "geui-gplist-linkednumbercell-link";
	/** リンクのIDのサフィックス */
	private static final String LINK_ID_SUFFIX = ".link";

	/**
	 * {@link GPListLinkedNumberCellTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2016/02/01
	 * @auther kikuchi
	 * @since 3.17.0
	 */
	public GPListLinkedNumberCellTag() {
	}
	
	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親となる{@link GPListRowTag}からid属性の値をキーにして、{@link GListCell}アイテムを取得し、
	 * そのフィールドから属性情報を読み込んでいます。 読み込んだ属性からXHTML文字列を生成し、JSPに出力しています。<br/>
	 * また、親となる{@link GPListTag}から開始インデックスと現在のインデックスを取得することにより、
	 * リストのナンバーをリンクとして出力しています。<br />
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2016/02/01
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 * @throws JspException {@link GPListLinkedNumberCell}の取得・ロード、タグの書き込みに失敗した場合
	 * @author kikuchi
	 * @since 3.17.0
	 */
	@Override
	public int doStartTag() throws JspException {
		// コンポーネントのロード
		GPListRowTag listRowTag = (GPListRowTag) findAncestorWithClass(this, GPListRowTag.class);
		if (listRowTag != null) {
			GListCell cell = listRowTag.getCell(getId());
			if (cell != null) {
				load(cell);
			}
		}
		if (isVisible()) {
			StringBuilder xhtmlString = new StringBuilder();
			xhtmlString.append(createXhtmlString());
			GPListTag listTag = (GPListTag) findAncestorWithClass(this, GPListTag.class);
			if (listTag != null) {
				int startIndex = listTag.getStartIndex() == -1 ? listTag.getStartIndex() + 1 : listTag.getStartIndex();
				int pageNumber = startIndex + listTag.getCurrentRowIndex() + 1;
				GTagBuilder builder = new GTagBuilder("a");
				builder.setInnerText(String.valueOf(pageNumber));
				decorateATagAttribute(builder);
				xhtmlString.append(builder.createStartEndTagString());
			}
			GTagUtils.printOut(pageContext, xhtmlString.toString());
			return EVAL_BODY_INCLUDE;
		}

		return SKIP_BODY;
	}

	/**
	 * 指定されたタグにa要素の属性を追加します.<br />
	 * 
	 * 1.タグ情報にXHTMLに出力する属性情報を付加します。<br>
	 * 2.本クラスで定義する、以下の属性 を付加します。<br>
	 * ・id,href,class<br>
	 * 
	 * @create 2016/02/01
	 * @param builder 属性を追記するGTagBuilder
	 * @author kikuchi
	 * @since 3.17.0
	 */
	protected void decorateATagAttribute(GTagBuilder builder) throws JspException {
		builder.setAttribute("id", getFullId() + ".link");
		builder.setAttribute("href", "javascript:void(0);");
		builder.setAttribute("class", LINK_STYLECLASS);
		
		bindScript("contextmenu", new GJavaScriptBuilder());
		bindScript("click", new GJavaScriptBuilder());
	}
	
	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br />
	 * 
	 * @param event イベントタイプ
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @param bindScriptBuilder 関連付け先のスクリプトバッファ
	 * @throws JspException 関連付けに失敗したとき
	 * @create 2016/02/01
	 * @author kikuchi
	 * @since 3.17.0
	 */
	@Override
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder) throws JspException {
		if ("click".equals(event)) {
			scriptBuilder.prepend(GAnchorUtils.createPreventClickEventScript(null));
		}
		if ("contextmenu".equals(event)) {
			scriptBuilder.append(GAnchorUtils.createPreventContextMenuEventScript(null));
		}
		super.bindMainScript(event, scriptBuilder, bindScriptBuilder);
	}
	
	/**
	 * スクリプトをバインドするターゲット要素のid属性の値を取得します.<br />
	 * a要素にスクリプトをバインドします。<br />
	 *
	 * @create 2016/02/01
	 * @return バインドターゲット
	 * @author kikuchi
	 * @since 3.17.0
	 */
	@Override
	protected String bindTarget() {
		return getFullId() + LINK_ID_SUFFIX;
	}
	
	/**
	 * セルのスタイルクラスを取得します.<br/>
	 * 
	 * @create 2016/02/05
	 * @return セルのスタイルクラス文字列
	 * @author kikuchi
	 * @since 3.17.0
	 */
	@Override
	protected String getCellStyleClass() {
		return super.getCellStyleClass() + " " + DEFAULT_STYLECLASS;
	}
}
