/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListCell;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListCell;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストナンバーを表示するタグクラスです.<br/>
 * 
 * @create 2011/04/25
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListCell.class)
public class GPListNumberCellTag extends GPListRowCellTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5784200394485388781L;
	
	/** デフォルトのスタイルクラス **/
	private static final String DEFAULT_STYLECLASS = "geui-gplist-numbercell";
	/**
	 * {@link GPListNumberCellTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/4/26
	 * @auther H.Nishida
	 * @since 3.9.0
	 */
	public GPListNumberCellTag() {
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親となる{@link GRSListRowTagg}からid属性の値をキーにして、{@link GRSListNumberCell}
	 * アイテムを取得し、 そのフィールドから属性情報を読み込んでいます。<br>
	 * また、親となる{@link GPListTagTest}から開始インデックスと現在のインデックスを取得することにより、
	 * リストのナンバーを出力しています.<br />
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/4/26
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GRSListNumberCell}の取得・ロード、タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		// コンポーネントのロード
		GPListRowTag listRowTag = (GPListRowTag) findAncestorWithClass(this, GPListRowTag.class);
		if (listRowTag != null) {
			GListCell cell = listRowTag.getCell(getId());
			if (cell != null) {
				load(cell);
			}
		}
		if (isVisible()) {
			StringBuilder xhtmlString = new StringBuilder();
			xhtmlString.append(createXhtmlString());
			GPListTag listTag = (GPListTag) findAncestorWithClass(this, GPListTag.class);
			if (listTag != null) {
				int startIndex = listTag.getStartIndex() == -1 ? listTag.getStartIndex() + 1 : listTag.getStartIndex();
				xhtmlString.append(startIndex + listTag.getCurrentRowIndex() + 1);
			}
			GTagUtils.printOut(pageContext, xhtmlString.toString());
		}

		return SKIP_BODY;
	}
	
	/**
	 * セルのスタイルクラスを取得します.<br/>
	 * 
	 * @create 2013/06/26
	 * @author kawakami
	 * @since 3.12.0<BR>
	 * @return セルのスタイルクラス文字列
	 */
	@Override
	protected String getCellStyleClass() {
		return super.getCellStyleClass() + " " + DEFAULT_STYLECLASS;
	}
}
