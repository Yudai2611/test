/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GEnablable;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListPager;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストページャを表示するタグクラスです.<br/>
 * 
 * @create 2011/04/25
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListPager.class)
public class GPListPagerTag extends GUIContainerControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7943895785128767540L;
	
	/** スタイルクラス */
	private static final String DEFAULT_STYLECLASS = "geui-gplist-pager";
	
	// XHTML属性
	/** リストエレメントID属性の値. */
	private String _listelement = null;
	/** [次へ]要素のID属性の値. */
	private String _next = null;
	/** [前へ]要素のID属性の値. */
	private String _previous = null;
	/** [最初へ]要素のID属性の値. */
	private String _first = null;
	/** [最後へ]要素のID属性の値. */
	private String _last = null;
	/** [ページネーション]要素のID属性の値. */
	private String _pagination = null;
	/** スプリッター. */
	private String _splitter;
	/** format属性の値. */
	private String _format = "%PAGE%";
	/** 画面表示ページ数. */
	private String _displaysize = "-1";

	// 内部変数
	/** 総リスト件数. */
	private int _totalListsize = 0;
	/** リストデータサイズ. */
	private int _listDataSize = 0;
	/** 表示しているデータの開始件数. */
	private int _startIndex = 0;

	/**
	 * {@link GPListPagerTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/04/25
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListPagerTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/04/25
	 * @return XHTML文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String createXhtmlString() {
		GTagBuilder spanTag = new GTagBuilder("span");
		super.decorateAttribute(spanTag);
		if (getId() != null) {
			spanTag.setAttribute("id", getFullId());
		}
		return spanTag.createStartTagString();
	}
	
	

	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		super.decorateStyleClassAttribute(builder);
		GStyleClass sc = super.getDecodeStyleclass();
		sc.add(DEFAULT_STYLECLASS);
		builder.setAttribute("class",sc.encode());
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @create 2011/04/25
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder tagBuilder = new GTagBuilder("span");
			GTagUtils.printOut(pageContext, tagBuilder.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @create 2011/04/25
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());

			// 子コントロールの制御（有効・無効設定
			GPListPager pager = (GPListPager) getAssociatedComponent();

			GEnablable next = (GEnablable) pager.findControl(getNext());
			GEnablable last = (GEnablable) pager.findControl(getLast());
			GEnablable prev = (GEnablable) pager.findControl(getPrevious());
			GEnablable first = (GEnablable) pager.findControl(getFirst());

			if (next != null) {
				next.setEnabled(existNextData());
			}
			if (last != null) {
				last.setEnabled(existNextData());
			}
			if (prev != null) {
				prev.setEnabled(existPreviousData());
			}
			if (first != null) {
				first.setEnabled(existPreviousData());
			}

			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * {@link GListData}に次のデータがある場合に<code>true</code>を返します.<br/>
	 * 
	 * {@link GListData}の開始インデックスと{@link GListData}のサイズに<code>1</code>を加えた値が、
	 * {@link GListData}の合計サイズより小さく、リストのサイズが<code>1</code>以上の場合に
	 * <code>true</code>を返します。<br/>
	 * 
	 * @create 2011/04/25
	 * @return <code>true</code>/<code>false</code>
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public boolean existNextData() {
		return !(getStartIndex() + getListDataSize() + 1 > getTotalListSize() || getListDataSize() < 1);
	}

	/**
	 * {@link GListData}に前のデータがある場合に<code>true</code>を返します.<br/>
	 * 
	 * {@link GListData}の開始インデックスが<code>1</code>以上で、 {@link GListData}のサイズが
	 * <code>1</code>以上の場合に<code>true</code>を返します。<br />
	 * 
	 * @create 2011/04/25
	 * @return <code>true</code>/<code>false</code>
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public boolean existPreviousData() {
		return !(getStartIndex() < 1 || getListDataSize() < 1);
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.richview.component.GUIComponent)
	 * @create 2011/04/25
	 * @param component レンダリング対象UIコンポーネント
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPListPager ui = (GPListPager) component;
		GPListPager rep = (GPListPager) component.getRepository();
		setListelement(evaluatePlaceholder(ui.getListelement(), getListelement(),
				rep == null ? null : rep.getListelement(), ui));
		setNext(evaluatePlaceholder(ui.getNext(), getNext(),
				rep == null ? null : rep.getNext(), ui));
		setPrevious(evaluatePlaceholder(ui.getPrevious(), getPrevious(),
				rep == null ? null : rep.getPrevious(), ui));
		setFirst(evaluatePlaceholder(ui.getFirst(), getFirst(),
				rep == null ? null : rep.getFirst(), ui));
		setLast(evaluatePlaceholder(ui.getLast(), getLast(),
				rep == null ? null : rep.getLast(), ui));
		setPagination(evaluatePlaceholder(ui.getPagination(), getPagination(),
				rep == null ? null : rep.getPagination(), ui));
		setSplitter(evaluatePlaceholder(ui.getSplitter(), getSplitter(),
				rep == null ? null : rep.getSplitter(), ui));
		setFormat(evaluatePlaceholder(ui.getFormat(), getFormat(),
				rep == null ? null : rep.getFormat(), ui));
		setDisplaysize(evaluatePlaceholder(ui.getDisplaysize(), getDisplaysize(),
				rep == null ? null : rep.getDisplaysize(), ui));

		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		GResultData resultData = (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);
		if (resultData.containsDataName(getListelement())) {
			GListData listData = resultData.getListData(getListelement());
			int totalsize = listData.getTotalSize();
			int size = listData.size();
			int startindex = listData.getStartIndex();
			ui.setTotalListSize(totalsize);
			ui.setListDataSize(size);
			ui.setStartIndex(startindex);
		}
		setTotalListSize(ui.getTotalListSize());
		setListDataSize(ui.getListDataSize());
		setStartIndex(ui.getStartIndex());

	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#reset()
	 * @create 2011/04/04
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		setTotalListSize(0);
		setListDataSize(0);
		setStartIndex(0);
	}

	/**
	 * 画面表示ページ数を取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @return 画面表示ページ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getDisplaysize() {
		return _displaysize;
	}

	/**
	 * 最初のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return [最初へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getFirst() {
		return _first;
	}

	/**
	 * 書式文字列を取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return format属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * 最後のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return [最後へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getLast() {
		return _last;
	}

	/**
	 * リストデータのサイズを取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @return リストデータ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getListDataSize() {
		return _listDataSize;
	}

	/**
	 * リストエレメントIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return リストエレメントID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getListelement() {
		return _listelement;
	}

	/**
	 * 次のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return [次へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getNext() {
		return _next;
	}

	/**
	 * ページネーション要素のIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return [ページネーション]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public String getPagination() {
		return _pagination;
	}

	/**
	 * 前のページの要素のIDを取得します.<br/>
	 * 
	 * @create 2011/04/25
	 * @return [前へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getPrevious() {
		return _previous;
	}

	/**
	 * スプリッター文字列を取得します.<br />
	 * 
	 * @create 2011/04/25
	 * @return スプリッター文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getSplitter() {
		return _splitter;
	}

	/**
	 * 表示しているデータの開始件数を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return 表示しているデータの開始件数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getStartIndex() {
		return _startIndex;
	}

	/**
	 * 総レコード数を取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @return 総レコード数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getTotalListSize() {
		return _totalListsize;
	}

	/**
	 * 画面表示ページ数を設定します.<br />
	 * 
	 * @create 2011/6/13
	 * @param displaySize 画面表示ページ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setDisplaysize(String displaySize) {
		_displaysize = displaySize;
	}

	/**
	 * 最初のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param first [最初へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setFirst(String first) {
		_first = first;
	}

	/**
	 * 書式文字列を設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param format format属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * 最後のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param last [最後へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setLast(String last) {
		_last = last;
	}

	/**
	 * リストデータのサイズを取得します.<br />
	 * 
	 * @create 2011/6/13
	 * @param listDataSize リストデータ数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setListDataSize(int listDataSize) {
		_listDataSize = listDataSize;
	}

	/**
	 * リストエレメントIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param listelement リストエレメントID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setListelement(String listelement) {
		_listelement = listelement;
	}

	/**
	 * 次のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param next [次へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setNext(String next) {
		_next = next;
	}

	/**
	 * ページネーション要素のIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param pagination [ページネーション]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 * @deprecated 将来的に削除される可能性があります.
	 */
	@Deprecated
	public void setPagination(String pagination) {
		_pagination = pagination;
	}

	/**
	 * 前のページの要素のIDを設定します.<br/>
	 * 
	 * @create 2011/04/25
	 * @param prev [前へ]要素のID属性の値
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setPrevious(String prev) {
		_previous = prev;
	}

	/**
	 * スプリッター文字列を設定します.<br />
	 * 
	 * @create 2011/04/25
	 * @param splitter スプリッター
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setSplitter(String splitter) {
		_splitter = splitter;
	}

	/**
	 * 表示しているデータの開始件数を設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param startIndex 表示しているデータの開始件数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setStartIndex(int startIndex) {
		_startIndex = startIndex;
	}

	/**
	 * 総レコード数を設定します.<br />
	 * 
	 * @create 2011/6/13
	 * @param totalListSize 総レコード数
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setTotalListSize(int totalListSize) {
		_totalListsize = totalListSize;
	}
}
