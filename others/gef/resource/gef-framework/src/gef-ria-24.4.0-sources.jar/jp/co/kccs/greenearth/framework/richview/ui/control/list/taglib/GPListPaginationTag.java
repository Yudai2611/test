/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import java.io.IOException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.BodyContent;
import jakarta.servlet.jsp.tagext.BodyTag;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListPagination;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストページネーションを表示するタグクラスです.<br/>
 *
 * @create 2011/04/25
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListPagination.class)
public class GPListPaginationTag extends GUIControlBaseTag implements BodyTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 6646450563531934689L;
	/** デフォルトのスタイルシートのクラス名. */
	protected final static String PAGINATION_DEFAULT_STYLECLASS = "geui-gplist-pagination";
	/** カレントページのスタイルシートクラス名. */
	protected static final String CURRENTPAGE_DEFAULT_STYLECLASS = "geui-gplist-currentpage";
	/** 各インデックスページへのリンクのスタイルシートクラス名. */
	protected static final String PAGELINK_DEFAULT_STYLECLASS = "geui-gplist-pagelink";
	/** スプリッターのスタイルシートクラス名. */
	protected static final String SPLITTER_DEFAULT_STYLECLASS = "geui-gplist-splitter";
	/** 表示するページインデックスの置換文字列. */
	protected static final String PAGE_REPLACE_STRING = "%PAGE%";

	/** 総ページ数. */
	private int _totalPageSize = 0;
	/** 処理対象ページ数 */
	private int _targetPage = 1;
	/** 開始ページ数 */
	private int _firstPage = 1;
	/** カレントページ. */
	private int _currentPage = 0;

	private BodyContent _bodyContent = null;

	/**
	 * {@link GPListPaginationTag}の新しいインスタンスを初期化します.<br/>
	 *
	 * @create 2011/4/26
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListPaginationTag() {
	}

	@Override
	public void setBodyContent(BodyContent b) {
		_bodyContent = b;
	}

	@Override
	public void doInitBody() throws JspException {
	}

	/**
	 * イベント系タグのoptions属性に追記します.<br />
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#bindOptions(jp.co.kccs.greenearth.commons.json.GJSONObject)
	 * @param options イベント系タグのoptions属性{@link GJSONObject}
	 * @create 2011/08/03
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void bindOptions(GJSONObject options) {
		options.put("destpage", getTargetPage());
	}

	/**
	 * 指定されたスクリプトを、このタグ又は親タグで実行されるよう対象の要素に関連付けます.<br/>
	 *
	 * デフォルトのイベントバインド ⇒$("#hoge").event(function() { script });<br/>
	 *
	 * @create 2011/04/15
	 * @param event イベント
	 * @param script JavaScript文字列
	 * @author H.Nishida
	 * @throws JspException jsp例外
	 * @since 3.10.0.D
	 */
	@Override
	public void bindScript(String event, GJavaScriptBuilder script) throws JspException {

		if (getCurrentPage() == getTargetPage()) {
			return;
		} else {
			super.bindScript(event, script);

		}
	}

	/**
	 * XHTML文字列を生成します.<br />
	 *
	 * @create 2011/4/26
	 * @return XHTML文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String createXhtmlString() {

		GTagBuilder builder = new GTagBuilder("span");
		decorateAttribute(builder);
		builder.setAttribute("id", getId());
		removeEventAttribute(builder);

		return builder.createStartTagString();
	}

	/**
	 * {@link RichUIListHeaderTag}に保持している、ヘッダー項目保持ListにMapを追加する処理を行います.<BR>
	 *
	 *
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doAfterBody()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida<BR>
	 * @since 3.10.0.D<BR>
	 */
	@Override
	public int doAfterBody() throws JspException {
		printPagination();
		_bodyContent.clearBody();

		int ret = SKIP_BODY;
		if (!(getTargetPage() == getTotalPageSize()) && !(getTargetPage() == getLastPage())) {
			if (getTargetPage() <= getLastPage()){
				ret = EVAL_BODY_AGAIN;
			}
			setTargetPage(getTargetPage() + 1);
		}
		return ret;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 *
	 * @create 2011/04/15
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible() && getTotalPageSize() > 0) {
			// bodyが空の場合doAfterBodyが呼び出されない為、ここでpaginationを出力する
			if(!hasBodyContent()) {
				for (int i = 0; i < getDisplaysize(); i++) {
					printPagination();
					setTargetPage(getTargetPage() + 1);
				}
			}
			GTagBuilder tag = new GTagBuilder("span");
			GTagUtils.printOut(pageContext, tag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 *
	 * 親のタグからid属性の値をキーにして、{@link GPListPagination}
	 * コントロールを取得し、そのフィールドから属性情報を読み込んでいます。<br>
	 * 読み込んだ属性からXHTML文字列を生成し、JSPに出力しています。<br>
	 *
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doStartTag()
	 * @create 2011/4/26
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException
	 *             {@link jp.co.kccs.greenearth.framework.view.component.GView}
	 *             の取得・ロード、タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible() && getTotalPageSize() > 0) {
			initializeTargetPageAndFirstPage();
			GTagUtils.printOut(pageContext, createXhtmlString());

			int displaySize = getDisplaysize();
			if (displaySize == 0 || displaySize < -1) {
				return SKIP_BODY;
			}
			return EVAL_BODY_BUFFERED;
		}
		return SKIP_BODY;
	}

	private void initializeTargetPageAndFirstPage() {
		int start = calculateStartPageNum();
		setTargetPage(start);
		setFirstPage(start);
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.richview.component.GUIComponent)
	 * @create 2011/04/25
	 * @param component レンダリング対象UIコンポーネント
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPListPagerTag parent = (GPListPagerTag) findAncestorWithClass(this, GPListPagerTag.class);
		GPListPagination ui = (GPListPagination) component;

		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		GResultData resultData = (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);
		if (resultData.containsDataName(parent.getListelement())) {
			GListData listData = resultData.getListData(parent.getListelement());

			if (listData.size() > 0) {
				// トータルサイズ
				int totalRecordSize = listData.getTotalSize();
				int listSize = listData.getMaxListSize();
				int totalPageSize = (totalRecordSize + listSize - 1) / listSize;
				ui.setTotalPageSize(totalPageSize);

				// カレントページ
				int startIndex = listData.getStartIndex();
				int currentPage = startIndex / listSize + 1;
				ui.setCurrentPage(currentPage);
			} else {
				setTotalPageSize(0);
				ui.setTotalPageSize(0);
				setCurrentPage(0);
				ui.setCurrentPage(0);
			}
		}
		setTotalPageSize(ui.getTotalPageSize());
		setCurrentPage(ui.getCurrentPage());

	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#reset()
	 * @create 2011/04/04
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		setTotalPageSize(0);
		setTargetPage(1);
		setFirstPage(1);
		setCurrentPage(0);
	}

	/**
	 * スクリプトをバインドするターゲット要素のid属性の値を取得します.<br/>
	 *
	 * {@link GPListPaginationTag}
	 * は、ページネーションを構成するページのテンプレートとして、id属性＋".0"を返却します。<br/>
	 *
	 * @create 2011/08/02
	 * @return バインドターゲット
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected String bindTarget() {
		return getFullId() + "." + getTargetPage();
	}

	/**
	 * 現在表示対象となっているページのインデックスのXHTML文字列を生成します.<br/>
	 *
	 * @create 2011/4/26
	 * @param displayValue 表示文字列
	 * @return span要素のXHTML文字列
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	protected String createCurrentPageXhtmlString(String displayValue) {
		GTagBuilder builder = new GTagBuilder("span");

		builder.setAttribute("id", getId() + "." + displayValue);
		builder.setAttribute("class", CURRENTPAGE_DEFAULT_STYLECLASS);
		StringBuffer sb = new StringBuffer(builder.createStartTagString());
		sb.append(displayValue);
		sb.append(createBodyContentString());
		sb.append(builder.createEndTagString());
		return sb.toString();
	}

	/**
	 * 現在表示対象となっていないページインデックスのXHTML文字列を取得します.<br />
	 *
	 * @create 2011/4/26
	 * @param destPageDiv 対象ページ区分
	 * @param replaceStr リンク表示用の置換文字列
	 * @param styleclass スタイルクラス名
	 * @return a要素のXHTML文字列
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	protected String createOtherPageXhtmlString(String destPageDiv, String replaceStr, String styleclass) {

		// format属性に"%PAGE%"という文字があれば、その文字列をページ数(又はprevvalue,nextvalueの値)に置換
		GPListPagerTag parent = (GPListPagerTag) findAncestorWithClass(this, GPListPagerTag.class);
		String displayValue = parent.getFormat().replace(PAGE_REPLACE_STRING, replaceStr);

		// a要素のXHTML文字列を生成
		GTagBuilder builder = new GTagBuilder("a");

		decorateEventAttribute(builder);
		builder.setAttribute("id", getId() + "." + destPageDiv);
		builder.setAttribute("class", styleclass);
		builder.setAttribute("href", "javascript:void(0);");

		StringBuffer sb = new StringBuffer(builder.createStartTagString());
		sb.append(displayValue);
		sb.append(createBodyContentString());
		sb.append(builder.createEndTagString());
		return sb.toString();
	}

	/**
	 * ページ数の間のスプリッターを生成します.<br/>
	 *
	 * @create 2011/4/26
	 * @return ページ数の間のスプリッター
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	protected String createSplitterString() {
		GPListPagerTag parent = (GPListPagerTag) findAncestorWithClass(this, GPListPagerTag.class);
		String split = parent.getSplitter();
		String tagString = "";
		if (!GStringUtils.isEmpty(split)) {
			GTagBuilder builder = new GTagBuilder("span");
			builder.setInnerText(split);
			builder.setAttribute("class", SPLITTER_DEFAULT_STYLECLASS);
			tagString = builder.createStartEndTagString();
		}
		return tagString;
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(PAGINATION_DEFAULT_STYLECLASS);
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * 設定されているイベント属性を削除します.<br />
	 *
	 * @create 2011/4/26
	 * @param builder タグビルダー
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	protected void removeEventAttribute(GTagBuilder builder) {
		builder.removeAttribute("onblur");
		builder.removeAttribute("onclick");
		builder.removeAttribute("ondblclick");
		builder.removeAttribute("onfocus");
		builder.removeAttribute("onkeydown");
		builder.removeAttribute("onkeypress");
		builder.removeAttribute("onkeyup");
		builder.removeAttribute("onmousedown");
		builder.removeAttribute("onmousemove");
		builder.removeAttribute("onmouseout");
		builder.removeAttribute("onmouseover");
		builder.removeAttribute("onmouseup");
	}

	private void printPagination() throws JspException {
		if (getTargetPage() == getCurrentPage()) {
			printOut(createCurrentPageXhtmlString(String.valueOf(getCurrentPage())));
		} else {
			if (getTargetPage() <= getLastPage()){
				printOut(createOtherPageXhtmlString(String.valueOf(getTargetPage()), String.valueOf(getTargetPage()), PAGELINK_DEFAULT_STYLECLASS));
			}
		}

		if (!(getTargetPage() == getTotalPageSize()) && !(getTargetPage() == getLastPage())) { // スプリッター
			printOut(createSplitterString());
		}
	}

	private String createBodyContentString() {
		if (hasBodyContent()) {
			return _bodyContent.getString();
		}
		return "";
	}

	private void printOut(String html) throws JspException {
		if (_bodyContent == null) {
			GTagUtils.printOut(pageContext, html);
		} else {
			try {
				_bodyContent.getEnclosingWriter().print(html);
			}
			catch (IOException e) {
				throw new JspException("Tag output error.", e);
			}
		}
	}

	private int calculateStartPageNum() {
		int displaySize = getDisplaysize();
		int totalPageSize = getTotalPageSize();
		int current = getCurrentPage();

		int center = displaySize / 2; // 表示ページ数の中央値
		int start = current - center; // 表示開始ページ
		if (current <= center || displaySize == -1 || totalPageSize <= displaySize) {
			// カレントページが表示ページ数の中央値より大きくない場合スタートページは「1」
			start = 1;
		} else if (current + center > totalPageSize) {
			// 最終表示ページが総ページよりも大きい場合、スタートページは「総ページ-表示ページ数+1」
			start = totalPageSize - displaySize + 1;
		}
		return start;
	}

	private boolean hasBodyContent() {
		return _bodyContent != null;
	}

	private int getDisplaysize() {
		GPListPagerTag parent = (GPListPagerTag) findAncestorWithClass(this, GPListPagerTag.class);
		return Integer.parseInt(parent.getDisplaysize());
	}

	private int getLastPage() {
		int displaySize = getDisplaysize();
		int lastPage = 0;
		if (displaySize == -1) {
			lastPage = getTotalPageSize();
		} else {
			lastPage = getFirstPage() + displaySize - 1;
		}
		return lastPage;
	}

	/**
	 * カレントページを取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return カレントページ
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getCurrentPage() {
		return _currentPage;
	}

	/**
	 * 開始ページ数を取得します.<br/>
	 *
	 * @create 2011/5/6
	 * @return 開始ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getFirstPage() {
		return _firstPage;
	}

	/**
	 * IDを取得します.<br>
	 *
	 * IDの先頭に接頭辞文字列が付加されます。<br/>
	 *
	 * @see jakarta.servlet.jsp.tagext.TagSupport#getId()
	 * @create 2011/4/26
	 * @return 接頭辞文字列が付加されたID
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	@Override
	public String getId() {
		if (!GStringUtils.isEmpty(getPrefix())) {
			return getPrefix() + super.getId();
		} else {
			return super.getId();
		}
	}

	/**
	 * 対象ページ数を取得します.<br/>
	 *
	 * @create 2011/5/6
	 * @return 対象ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getTargetPage() {
		return _targetPage;
	}

	/**
	 * 総ページ数を取得します.<br />
	 *
	 * @create 2011/4/26
	 * @return 総ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public int getTotalPageSize() {
		return _totalPageSize;
	}

	/**
	 * カレントページを設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param currentPage カレントページ
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setCurrentPage(int currentPage) {
		_currentPage = currentPage;
	}

	/**
	 * 開始ページ数を設定します.<br/>
	 *
	 * @create 2011/5/6
	 * @param firstPage 開始ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setFirstPage(int firstPage) {
		_firstPage = firstPage;
	}

	/**
	 * 対象ページ数を設定します.<br/>
	 *
	 * @create 2011/5/6
	 * @param targetPage 対象ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setTargetPage(int targetPage) {
		_targetPage = targetPage;
	}

	/**
	 * 総ページ数を設定します.<br />
	 *
	 * @create 2011/4/26
	 * @param pageSize 総ページ数
	 * @author H.Nishida
	 * @since 3.10.0.D
	 */
	public void setTotalPageSize(int pageSize) {
		_totalPageSize = pageSize;
	}
}