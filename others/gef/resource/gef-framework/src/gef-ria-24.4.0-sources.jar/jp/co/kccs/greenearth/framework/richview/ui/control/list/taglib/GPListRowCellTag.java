/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListCell;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * リストのボディ部分のセルを表示するタグクラスです.<br>
 * 
 * @create 2011/4/26
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPListCell.class)
public class GPListRowCellTag extends GPListCellTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -1327653190511990588L;
	/** スタイルシートのクラス名 */
	private static final String DEFAULT_STYLECLASS = "geui-gplist-body-cell";

	/**
	 * {@link GRSListRowCellTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/4/26
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListRowCellTag() {
	}

	/**
	 * セルのスタイルクラスを取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0<BR>
	 * @return セルのスタイルクラス文字列
	 */
	@Override
	protected String getCellStyleClass() {
		return DEFAULT_STYLECLASS;
	}
}
