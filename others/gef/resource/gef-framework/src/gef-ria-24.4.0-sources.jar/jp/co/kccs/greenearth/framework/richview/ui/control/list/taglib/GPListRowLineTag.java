/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

/**
 * リストロウラインを表示するタグクラスです.<br/>
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
public class GPListRowLineTag extends GPListLineBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6085256378957967966L;

	/**
	 * {@link GPListRowLineTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListRowLineTag() {
	}
}