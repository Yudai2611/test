/*
 * Copyright 2011-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import java.util.Map;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListCell;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListRow;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListRow;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * リストロウを表示するタグクラスです.<br/>
 * 
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GPListRow.class)
public class GPListRowTag extends GPListComponentsTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3071182269231906324L;
	
	/** デフォルトのスタイルシートのクラス名(tbody)*/
	protected static final String DEFAULT_STYLECLASS = "geui-gplist-row";
	/** デフォルトのスタイルシートのクラス名（奇数行） */
	protected static final String ODDROW_DEFAULT_STYLECLASS = "geui-gplist-odd-row";
	/** デフォルトのスタイルシートのクラス名（偶数行） */
	protected static final String EVENROW_DEFAULT_STYLECLASS = "geui-gplist-even-row";

	/** リストの行インデックス. */
	private int _rowIndex = -1;



	/**
	 * {@link GPListRowTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPListRowTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 全ての明細が表示されていない場合(trが0個)でも、tbodyを出力します。<br/>
	 *
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @create 2011/07/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		GPListTag parent = (GPListTag) findAncestorWithClass(this, GPListTag.class);
		if (parent != null) {
			if (parent.isLastEval()) {
				GTagUtils.printOut(pageContext, parent.getScrollStrategy().createRowEndTag(this));
				reset();
				return EVAL_PAGE;
			}
			if (parent.isFirstEval()) {
				return EVAL_PAGE;
			}
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親となる{@link GPListTag}からインデックスをキーにして、{@link GPListRow}アイテムを取得し、
	 * そのフィールドから属性情報を読み込んでいます。<br>
	 * <br/>
	 * ※全ての明細が表示されていない場合(trが0個)でも、tbodyを出力します。<br/>
	 * ※非表示明細(visible=false)が含まれる場合、IDのインデックスが欠番となり要素順が理解できない※ため、表示用のIndexを用いて要素順を出力するようにします。<br/>
	 *　・DisableまたはNonVisibleの状態を示すHTML(※__@_index_@_internal_non-visibled...)のID(indexの部分)に、要素順を関連付けします。<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/07/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		GPListTag parent = (GPListTag) findAncestorWithClass(this, GPListTag.class);
		if (parent !=null) {
			if (parent.isFirstEval()) {
				GTagUtils.printOut(pageContext, parent.getScrollStrategy().createRowStartTag(this));
			}
			if (parent.isDuringIteration()) {
				setRowIndex(parent.getCurrentRowIndex());
				GListRow listRow = parent.getRow(getRowIndex());
				if (listRow != null) {
					load(listRow);
				}
				if (isVisible()) {
					for (Map.Entry<String, GListCell> cell : listRow.getCells().entrySet()) {
						if (cell.getValue().isVisible()) {
							parent.increaseDisplayRowIndex();
							((GPListRow)listRow).setDisplayRowIndex(parent.getDisplayRowIndex());
							break;
						}
					}
					return EVAL_BODY_INCLUDE;
				}
			}
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.richview.component.GUIComponent)
	 * @create 2011/07/27
	 * @param component レンダリング対象UIコンポーネント
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPListRow ui = (GPListRow) component;
		setRowIndex(ui.getRowIndex());
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentTag#reset()
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		setRowIndex(-1);
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/07/27
	 * @return XHTML文字列
	 * @author yamashita
	 * @param id GPListRowLineのID
	 * @since 3.9.0
	 */
	protected String createXhtmlString(String id) {
		GTagBuilder builder = new GTagBuilder("tr");
		decorateAttribute(builder);
		if (id != null) {
			builder.setAttribute("id", GStringUtils.nullToBlank(getPrefix()) + id);
		}
		return builder.createStartTagString();
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/07/27
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GPListTag parent = (GPListTag) findAncestorWithClass(this, GPListTag.class);
		if (parent.isZebrarow()) {
			GStyleClass styleclass = getDecodeStyleclass();

			if ((getRowIndex() + 1) % 2 == 0) {
				if (styleclass.contains(ODDROW_DEFAULT_STYLECLASS)) {
					styleclass.remove(ODDROW_DEFAULT_STYLECLASS);
				}
				styleclass.add(EVENROW_DEFAULT_STYLECLASS);
			} else {
				if (styleclass.contains(EVENROW_DEFAULT_STYLECLASS)) {
					styleclass.remove(EVENROW_DEFAULT_STYLECLASS);
				}
				styleclass.add(ODDROW_DEFAULT_STYLECLASS);

			}
			builder.setAttribute("class", getStyleclass());
		}
	}
	
	/**
	 * Tbody用のタグビルダーを作成します。
	 * 
	 * @return 全ての要素が設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createTBodyTagBuilder() {
		GTagBuilder body = new GTagBuilder("tbody");
		body.setAttribute("class", GPListRowTag.DEFAULT_STYLECLASS);
		return body;
	}

	/**
	 * リストの行インデックスを取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return リストの行インデックス
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getRowIndex() {
		return _rowIndex;
	}

	/**
	 * リストの行インデックスを設定します.<br />
	 * 
	 * @create 2011/07/27
	 * @param rowIndex リストの行インデックス
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setRowIndex(int rowIndex) {
		_rowIndex = rowIndex;
	}
}