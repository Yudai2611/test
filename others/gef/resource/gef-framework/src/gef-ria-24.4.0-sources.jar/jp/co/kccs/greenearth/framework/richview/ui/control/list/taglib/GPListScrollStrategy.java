/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.jsp.JspException;


/**
 * GPListTagの関連要素についについててScroll状態毎の振る舞いを定義するためのインターフェース<br>
 * @author kawakami
 * @create 2013/07/24
 * @since 3.12.0
 */
public interface GPListScrollStrategy {
	/** スクロール適用時の幅・高さ指定単位*/
	public static final String SCROLL_SIZE_UNIT = "px";

	/** 水平スクロールブロック用ID SUFFIX */
	public static final String HORIZONTAL_SCROLL_BLOCK_ID_SUFFIX = "-hscrollblock";
	/** 水平スクロールブロック用スタイルクラス名 */
	public static final String HORIZONTAL_SCROLL_BLOCK_STYLE_CLASS = "geui-gplist-hscrollblock";

	/** 水平スクロールバー用DIVのIDサフィックス*/
	public static final String SCROLL_BAR_ID_SUFFIX = "-hscrollbar";
	/** 水平スクロールバー用DIVのスタイルクラス名*/
	public static final String SCROLL_BAR_STYLECLASS = "geui-gplist-hscrollbar";
	/** 水平スクロールバー用DIV内のコンテンツのIDサフィックス*/
	public static final String SCROLL_BAR_CONTENT_ID_SUFFIX = "-hscrollbar-content";
	/** 水平スクロールバー用DIV内のコンテンツのスタイルクラス名*/
	public static final String SCROLL_BAR_CONTENT_STYLECLASS = "geui-gplist-hscrollbar-content";
	
	/** Caption スクロールブロック用スタイルクラス名*/
	public static final String CAPTION_SCROLL_BLOCK_STYLE_CLASS = "geui-gplist-caption-scrollblock";
	/** Caption スクロールブロック用 ID SUFFIX*/
	public static final String CAPTION_SCROLL_BLOCK_ID_SUFFIX = "-caption-scrollblock";
	/** Caption 格納用テーブルのスタイルクラス名*/
	public static final String CAPTION_SCROLL_TABLE_STYLECLASS = "geui-gplist-caption-table";
	/** Caption 格納用テーブルのID SUFFIX*/
	public static final String CAPTION_SCROLL_TABLE_ID_SUFFIX = "-caption-table";

	/** Header スクロール用テーブルのスタイルクラス名*/
	public static final String HEADER_SCROLL_TABLE_STYLE_CLASS = "geui-gplist-header-table";
	/** Header スクロール用テーブルのID SUFFIX*/
	public static final String HEADER_SCROLL_TABLE_ID_SUFFIX = "-header-table";
	/** Header スクロールブロックのスタイルクラス名*/
	public static final String HEADER_SCROLL_BLOCK_STYLE_CLASS = "geui-gplist-header-scrollblock";
	/** Header スクロールブロックのID SUFFIX*/
	public static final String HEADER_SCROLL_BLOCK_ID_SUFFIX = "-header-scrollblock";
	
	/** Row スクロール用テーブルのスタイルクラス名*/
	public static final String ROW_SCROLL_TABLE_STYLE_CLASS = "geui-gplist-row-table";
	/** Row スクロールブロック用のスタイルククラス名*/
	public static final String ROW_SCROLL_BLOCK_STYLE_CLASS = "geui-gplist-row-scrollblock";
	/** Row スクロールブロック用のID SUFFIX*/
	public static final String ROW_SCROLL_BLOCK_ID_SUFFIX = "-row-scrollblock";
	
	/** Footer 　スクロール用テーブルのスタイルクラス名 */
	public static final String FOOTER_SCROLL_TABLE_STYLE_CLASS = "geui-gplist-footer-table";
	/** Footer スクロール用テーブルのID SUFFIX */
	public static final String FOOTER_SCROLL_TABLE_ID_SUFFIX = "-footer-table";
	/** Footer　スクロールブロック用のスタイルクラス名 */
	public static final String FOOTER_SCROLL_BLOCK_STYLE_CLASS = "geui-gplist-footer-scrollblock";
	/** Footer　スクロールブロック用のID SUFFIX*/
	public static final String FOOTER_SCROLL_BLOCK_ID_SUFFIX = "-footer-scrollblock";
	
	
	/**
	 * 既定のスクロール状態において{@link GPListTag#doStartTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createListStartTag() throws JspException;
	
	/**
	 * 既定のスクロール状態において{@link GPListTag#doEndTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createListEndTag() throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListCaptionTag#doStartTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param caption 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createCaptionStartTag(GPListCaptionTag caption) throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListCaptionTag#doEndTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param caption 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createCaptionEndTag(GPListCaptionTag caption) throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListHeaderTag#doStartTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param header 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createHeaderStartTag(GPListHeaderTag header) throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListHeaderTag#doEndTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param header 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createHeaderEndTag(GPListHeaderTag header) throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListRowTag#doStartTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param row 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createRowStartTag(GPListRowTag row) throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListRowTag#doEndTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param row 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createRowEndTag(GPListRowTag row) throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListFooterTag#doStartTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param header 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createFooterStartTag(GPListFooterTag footer) throws JspException;
	/**
	 * 既定のスクロール状態において{@link GPListFooterTag#doEndTag}で出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @param header 出力対象のタグオブジェクト
	 * @return HTMLタグ文字列
	 * @throws JspException
	 * @author kawakmi
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	String createFooterEndTag(GPListFooterTag footer) throws JspException;
}
