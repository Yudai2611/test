/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.GStyle;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;


/**
 * 水平方向のスクロールが有効である状態における振る舞いを定義します。
 * 
 * @author kawakami
 * @create 2013/07/24
 * @since 3.12.0
 */
public class GPListScrollStrategyHorizontal implements GPListScrollStrategy {
	
	private final GPListTag listtag;
	
	/**
	 * {@link GPListTag}オブジェクトを受け取りGPListScrollStateHorizontalオブジェクトを定義します。<br>
	 * GPListTagはGPListTag自身のHTMLタグ文字列の作成に利用されるとともに、
	 * 配下の各要素タグより参照する必要がある状態(スクロール幅等)を保持しており、
	 * それら要素のHTMLタグ出力でも利用されます。
	 * @param listtag
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */	
	public GPListScrollStrategyHorizontal(GPListTag listtag) {
		this.listtag = listtag;
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createListStartTag()
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createListStartTag() {
		StringBuilder sb = new StringBuilder();
		
		sb.append(this.listtag.createListBlockTag().createStartTagString());
		sb.append(createListScrollBlockTagBuilder(this.listtag).createStartTagString());
		sb.append(this.listtag.createXhtmlString());
		
		return sb.toString();
	}


	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createListEndTag()
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createListEndTag() throws JspException {
		StringBuilder sb = new StringBuilder();
		
		sb.append(this.listtag.createListTagBuilder().createEndTagString());
		sb.append(this.listtag.createEmptymsgTagString());
		sb.append(createListScrollBlockTagBuilder(this.listtag).createEndTagString());
		sb.append(this.listtag.createHiddenTagString());
		sb.append(this.listtag.createListBlockTag().createEndTagString());
		
		this.bindHorizontalScrollScript();
		
		return sb.toString();
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListCaptionTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createCaptionStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListCaptionTag)
	 * @param caption
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createCaptionStartTag(GPListCaptionTag caption) {
		return caption.createXhtmlString();
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListCaptionTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createCaptionEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListCaptionTag)
	 * @param caption
	 * @return HTML文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createCaptionEndTag(GPListCaptionTag caption) {
		return caption.createCaptionTagBuilder().createEndTagString();
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListHeaderTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createHeaderStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListHeaderTag)
	 * @param header
	 * @return HTML文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createHeaderStartTag(GPListHeaderTag header) {
		return header.createTheadTagBuilder().createStartTagString();
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListHeaderTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createHeaderEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListHeaderTag)
	 * @param header
	 * @return HTML文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createHeaderEndTag(GPListHeaderTag header) {
		return header.createTheadTagBuilder().createEndTagString();
	}
	
	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListRowrTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createRowStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListRowTag)
	 * @param row
	 * @return HTML文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createRowStartTag(GPListRowTag row) {
		return row.createTBodyTagBuilder().createStartTagString();
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListRowrTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createRowEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListRowTag)
	 * @param row
	 * @return HTML文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createRowEndTag(GPListRowTag row) {
		return row.createTBodyTagBuilder().createEndTagString();
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListFooterTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createFooterStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListFooterTag)
	 * @param footer
	 * @return HTML文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createFooterStartTag(GPListFooterTag footer) {
		return footer.createTfootTagBuilder().createStartTagString(); 
	}

	/**
	 * 水平方向のみのスクロールが有効な場合において
	 * {@link GPListFooterTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createFooterEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListFooterTag)
	 * @param footer
	 * @return HTML文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createFooterEndTag(GPListFooterTag footer) {
		return footer.createTfootTagBuilder().createEndTagString(); 
	}

	/**
	 * Listスクロールブロック用のタグビルダーを生成します。
	 * 
	 * @param listtag
	 * @return 必要な要素がすべて設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createListScrollBlockTagBuilder(GPListTag listtag) {
		GTagBuilder scrollblock = new GTagBuilder("div");
		scrollblock.setAttribute("id", listtag.getFullId() + HORIZONTAL_SCROLL_BLOCK_ID_SUFFIX);
		scrollblock.setAttribute("class", HORIZONTAL_SCROLL_BLOCK_STYLE_CLASS);
		GStyle style = new GStyle();
		style.put("width", listtag.getScrollWidth() + SCROLL_SIZE_UNIT);
		scrollblock.setAttribute("style", style.encode());
		return scrollblock;
	}
	
	/**
	 * 水平スクロール制御用のJavaScriptをバインドします。 
	 * 
	 * @throws JspException
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected void bindHorizontalScrollScript() throws JspException {
		GJavaScriptBuilder js = new GJavaScriptBuilder();
		js.append("$(function(){$.geui.handler.get('gplist').horizontal(??);});", this.listtag.getFullId());
		this.listtag.bindScript(js.toString());	
	}
}
