/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;


/**
 * スクロール指定がない状態における振る舞いを定義する。
 * 
 * @author kawakami
 * @create 2013/07/24
 * @since 3.12.0
 */
public class GPListScrollStrategyNone implements GPListScrollStrategy {
	
	private final GPListTag listtag;
	
	/**
	 * {@link GPListTag}オブジェクトを受け取りGPListScrollStateNoneオブジェクトを定義します。<br>
	 * GPListTagはGPListTag自身のHTMLタグ文字列の作成に利用されるとともに、
	 * 配下の各要素タグより参照する必要がある状態(スクロール幅等)を保持しており、
	 * それら要素のHTMLタグ出力でも利用されます。
	 * @param listtag
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */	
	public GPListScrollStrategyNone(GPListTag listtag) {
		this.listtag = listtag;
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createListStartTag()
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createListStartTag() {
		StringBuilder sb = new StringBuilder();
		
		sb.append(this.listtag.createListBlockTag().createStartTagString());
		sb.append(this.listtag.createXhtmlString());
		
		return sb.toString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListTag#doEndtTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createListEndTag()
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createListEndTag() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.listtag.createListTagBuilder().createEndTagString());
		sb.append(this.listtag.createHiddenTagString());
		sb.append(this.listtag.createEmptymsgTagString());
		sb.append(this.listtag.createListBlockTag().createEndTagString());
		return sb.toString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListCaptionTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createCaptionStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListCaptionTag)
	 * @param caption
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createCaptionStartTag(GPListCaptionTag caption) {
		return caption.createXhtmlString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListCaptionTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createCaptionEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListCaptionTag)
	 * @param caption
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createCaptionEndTag(GPListCaptionTag caption) {
		return caption.createCaptionTagBuilder().createEndTagString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListHeaderTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createHeaderStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListHeaderTag)
	 * @param header
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createHeaderStartTag(GPListHeaderTag header) {
		return header.createTheadTagBuilder().createStartTagString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListHeaderTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createHeaderEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListHeaderTag)
	 * @param header
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createHeaderEndTag(GPListHeaderTag header) {
		return header.createTheadTagBuilder().createEndTagString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListRowTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createRowStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListRowTag)
	 * @param row
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createRowStartTag(GPListRowTag row) {
		return row.createTBodyTagBuilder().createStartTagString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListRowTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createRowEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListRowTag)
	 * @param row
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createRowEndTag(GPListRowTag row) {
		return row.createTBodyTagBuilder().createEndTagString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListFooterTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createFooterStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListFooterTag)
	 * @param footer
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createFooterStartTag(GPListFooterTag footer) {
		return footer.createTfootTagBuilder().createStartTagString();
	}

	/**
	 * スクロール指定がない状態において
	 * {@link GPListFooterTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createFooterEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListFooterTag)
	 * @param footer
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createFooterEndTag(GPListFooterTag footer) {
		return footer.createTfootTagBuilder().createEndTagString();
	}

}
