/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyle;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * 垂直方向のみのスクロールが有効である状態における振る舞いを定義する
 * 
 * @author kawakami
 * @create 2013/07/24
 * @since 3.12.0
 */
public class GPListScrollStrategyVertical implements GPListScrollStrategy {
	
	private final GPListTag listtag;
	
	/**
	 * {@link GPListTag}オブジェクトを受け取りGPListScrollStateVerticalオブジェクトを定義します。<br>
	 * GPListTagはGPListTag自身のHTMLタグ文字列の作成に利用されるとともに、
	 * 配下の各要素タグより参照する必要がある状態(スクロール幅等)を保持しており、
	 * それら要素のHTMLタグ出力でも利用されます。
	 * @param listtag
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	public GPListScrollStrategyVertical(GPListTag listtag) {
		this.listtag = listtag;
	}

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createListStartTag()
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createListStartTag() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.listtag.createListBlockTag().createStartTagString());
		return sb.toString();
	}

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createListEndTag()
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @throws JspException 
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createListEndTag() throws JspException {
		StringBuilder sb = new StringBuilder();
		sb.append(this.listtag.createHiddenTagString());
		sb.append(this.listtag.createListBlockTag().createEndTagString());
		
		this.bindVerticalScrollScript();
		
		return sb.toString();
	}

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListCaptionTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createCaptionStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListCaptionTag)
	 * @param caption
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createCaptionStartTag(GPListCaptionTag caption) {
		StringBuilder sb = new StringBuilder();
		sb.append(createCaptionScrollBlockTagBuilder(this.listtag).createStartTagString());
		sb.append(createCaptionScrollTableTabBuilder(this.listtag).createStartTagString());
		sb.append(caption.createXhtmlString());
		
		return sb.toString();
	}
	

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListCaptionTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createCaptionEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListCaptionTag)
	 * @param caption
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createCaptionEndTag(GPListCaptionTag caption) {
		StringBuilder sb = new StringBuilder();
		sb.append(caption.createCaptionTagBuilder().createEndTagString());
		sb.append(createCaptionScrollTableTabBuilder(this.listtag).createEndTagString());
		sb.append(createCaptionScrollBlockTagBuilder(this.listtag).createEndTagString());
		return sb.toString();
	}

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListHeaderTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createHeaderStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListHeaderTag)
	 * @param header
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createHeaderStartTag(GPListHeaderTag header) {
		StringBuilder sb = new StringBuilder();
		sb.append(createHeaderScrollBlockTagBuilder(this.listtag).createStartTagString());
		sb.append(createHeaderScrollTableTagBuilder(this.listtag).createStartTagString());
		sb.append(header.createTheadTagBuilder().createStartTagString());
		
		return sb.toString();
	}

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListHeaderTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createHeaderEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListHeaderTag)
	 * @param header
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createHeaderEndTag(GPListHeaderTag header) {
		StringBuilder sb = new StringBuilder();
		
		sb.append(header.createTheadTagBuilder().createEndTagString());
		sb.append(createHeaderScrollTableTagBuilder(this.listtag).createEndTagString());
		sb.append(createHeaderScrollBlockTagBuilder(this.listtag).createEndTagString());
		
		return sb.toString();
	}
	
	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListRowTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createRowStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListRowTag)
	 * @param row
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createRowStartTag(GPListRowTag row) {
		StringBuilder sb = new StringBuilder();

		sb.append(createRowScrollBlockTagBuilder(this.listtag).createStartTagString());
		sb.append(createRowScrollTableTagBuilder(this.listtag).createStartTagString());
		sb.append(row.createTBodyTagBuilder().createStartTagString());
		
		return sb.toString();
	}


	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListRowTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createRowEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListRowTag)
	 * @param row
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @throws JspException 
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createRowEndTag(GPListRowTag row) throws JspException {
		StringBuilder sb = new StringBuilder();
		
		sb.append(row.createTBodyTagBuilder().createEndTagString());
		sb.append(createRowScrollTableTagBuilder(this.listtag).createEndTagString());
		sb.append(this.listtag.createEmptymsgTagString());
		sb.append(createRowScrollBlockTagBuilder(this.listtag).createEndTagString());
		
		return sb.toString();
	}

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListFooterTag#doStartTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createFooterStartTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListFooterTag)
	 * @param footer
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createFooterStartTag(GPListFooterTag footer) {
		StringBuilder sb = new StringBuilder();
		
		sb.append(createFooterScrollBlockTagBuilder(this.listtag).createStartTagString());
		sb.append(createFooterScrollTableTagBuilder(this.listtag).createStartTagString());
		sb.append(footer.createTfootTagBuilder().createStartTagString());
		
		return sb.toString();
	}

	/**
	 * 垂直方向のみのスクロールが有効である状態において
	 * {@link GPListFooterTag#doEndTag()}にて出力すべきHTMLタグ文字列を作成します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListScrollStrategy#createFooterEndTag(jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib.GPListFooterTag)
	 * @param footer
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	@Override
	public String createFooterEndTag(GPListFooterTag footer) {
		StringBuilder sb = new StringBuilder();
		
		sb.append(footer.createTfootTagBuilder().createEndTagString());
		sb.append(createFooterScrollTableTagBuilder(this.listtag).createEndTagString());
		sb.append(createFooterScrollBlockTagBuilder(this.listtag).createEndTagString());
		
		return sb.toString();
	}
	
	/**
	 * Caption スクロールブロック用のタグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createCaptionScrollBlockTagBuilder(GPListTag listtag) {
		GTagBuilder div = new GTagBuilder("div");
		div.setAttribute("id", this.listtag.getFullId() + CAPTION_SCROLL_BLOCK_ID_SUFFIX);
		div.setAttribute("class", CAPTION_SCROLL_BLOCK_STYLE_CLASS); 
		return div;
	}
	
	/**
	 * caption のスクロールテーブル用のタグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createCaptionScrollTableTabBuilder(GPListTag listtag) {
		GTagBuilder table = new GTagBuilder("table");
		table.setAttribute("id", listtag.getFullId() + CAPTION_SCROLL_TABLE_ID_SUFFIX);
		GStyleClass styleclass = new GStyleClass(GPListTag.DEFAULT_STYLECLASS, CAPTION_SCROLL_TABLE_STYLECLASS, listtag.getStyleclass());
		table.setAttribute("class", styleclass.encode());
		if (!GStringUtils.isEmpty(listtag.getStyle())) {
			table.setAttribute("style", listtag.getStyle());
		}
		return table;
	}
	
	/**
	 * header スクロールブロック用のタグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createHeaderScrollBlockTagBuilder(GPListTag listtag) {
		GTagBuilder div = new GTagBuilder("div");
		div.setAttribute("id", listtag.getFullId() + HEADER_SCROLL_BLOCK_ID_SUFFIX);
		div.setAttribute("class", HEADER_SCROLL_BLOCK_STYLE_CLASS);
		return div;
	}	
	/**
	 * header のスクロールテーブル用のタグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createHeaderScrollTableTagBuilder(GPListTag listtag) {
		GTagBuilder table = new GTagBuilder("table");
		table.setAttribute("id", listtag.getFullId() + HEADER_SCROLL_TABLE_ID_SUFFIX);
		GStyleClass styleclass = new GStyleClass(GPListTag.DEFAULT_STYLECLASS, HEADER_SCROLL_TABLE_STYLE_CLASS, listtag.getStyleclass());
		table.setAttribute("class", styleclass.encode());
		if (!GStringUtils.isEmpty(listtag.getStyle())) {
			table.setAttribute("style", listtag.getStyle());
		}
		return table;
	}
	
	/**
	 * row のスクロールテーブル用のタグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createRowScrollTableTagBuilder(GPListTag listtag) {
		GTagBuilder table = new GTagBuilder("table");
		listtag.decorateAttribute(table);
		GStyleClass styleclass = new GStyleClass(GPListTag.DEFAULT_STYLECLASS, ROW_SCROLL_TABLE_STYLE_CLASS, listtag.getStyleclass());
		table.setAttribute("class", styleclass.encode());
		return table;
	}
	/**
	 * row のスクロールブロック用タグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createRowScrollBlockTagBuilder(GPListTag listtag) {
		GTagBuilder div = new GTagBuilder("div");
		div.setAttribute("id", listtag.getFullId() + ROW_SCROLL_BLOCK_ID_SUFFIX);
		div.setAttribute("class", ROW_SCROLL_BLOCK_STYLE_CLASS); 
		GStyle divstyle = new GStyle();
		divstyle.put("height", listtag.getScrollHeight() + SCROLL_SIZE_UNIT);
		if (listtag.getRows().size() == 0) {
			if (!(listtag.isEmpty() && listtag.isIsEmptymsg())) {
				divstyle.put("display", "none");
			}
		}
		div.setAttribute("style", divstyle.encode());
		
		return div;
	}
	
	/**
	 * Footer スクロールブロック用のタグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createFooterScrollBlockTagBuilder(GPListTag listtag) {
		GTagBuilder div = new GTagBuilder("div");
		div.setAttribute("id", listtag.getFullId() + FOOTER_SCROLL_BLOCK_ID_SUFFIX);
		div.setAttribute("class", FOOTER_SCROLL_BLOCK_STYLE_CLASS); 
		return div;
	}
	
	/**
	 * footer のスクロールテーブル用タグビルダーを作成します。
	 * 
	 * @param listtag
	 * @return 必要な要素が全て設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createFooterScrollTableTagBuilder(GPListTag listtag) {
		GTagBuilder table = new GTagBuilder("table");
		table.setAttribute("id", listtag.getFullId() + FOOTER_SCROLL_TABLE_ID_SUFFIX);
		GStyleClass styleclass = new GStyleClass(GPListTag.DEFAULT_STYLECLASS, FOOTER_SCROLL_TABLE_STYLE_CLASS, listtag.getStyleclass());
		table.setAttribute("class", styleclass.encode());
		if (!GStringUtils.isEmpty(listtag.getStyle())) {
			table.setAttribute("style", listtag.getStyle());
		}
		return table;
	}
	
	/**
	 * 水平スクロール制御用のJavaScriptをバインドします。 
	 * 
	 * @throws JspException
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected void bindVerticalScrollScript() throws JspException {
		GJavaScriptBuilder js = new GJavaScriptBuilder();
		js.append("$(function(){$.geui.handler.get('gplist').vertical(??);});", this.listtag.getFullId());
		this.listtag.bindScript(js.toString());	
	}
}
