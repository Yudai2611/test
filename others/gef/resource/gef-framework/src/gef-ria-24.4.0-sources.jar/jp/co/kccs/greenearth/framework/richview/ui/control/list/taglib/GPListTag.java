/*
 * Copyright 2011-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.list.taglib;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListCaption;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListFooter;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListHeader;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListRow;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPList;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;
import jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag;

/**
 * リストを表示するタグクラスです.<br/>
 * 
 * @create 2011/07/27
 * @author H.Nishida
 * @since 3.9.0
 */
@TargetUIComponent(GPList.class)
public class GPListTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2073155903992856189L;

	/** スタイルシートのクラス名（DIVに適用）. */
	protected static final String DEFAULT_STYLECLASS = "ui-widget geui-gplist";
	
	/** スタイルシートのクラス名(リスト全体を囲むブロック用 */
	protected static final String BLOCK_STYLECLASS = "geui-gplist-block";
	
	// XHTML属性
	/** summary属性の値. */
	private String _summary = null;

	// 拡張属性
	/** listsize属性の値. */
	private String _listsize = "-1";
	/** ゼブラ機能を使用するかの値. ゼブラ機能が有効の場合リストの奇数列、偶数列に異なる背景色を設定します。 */
	private String _zebrarow = null;
	/** リストの結果が0件の際のメッセージ表示の有無を指定します. */
	private String _isemptymsg = null;
	/** リストの結果が0件の際のメッセージを指定します. */
	private String _emptymsg = null;

	// 内部変数
	/** 結果セット内のリストの有無. */
	private String _empty = null;
	/** 表示しているデータの開始件数. */
	private int _startIndex = -1;
	/** {@link GListCaption}オブジェクト. */
	private GListCaption _caption = null;
	/** {@link GListHeader}オブジェクト. */
	private GListHeader _header = null;
	/** {@link GListRow}オブジェクトのリスト. */
	private List<GListRow> _rows = new ArrayList<GListRow>();
	/** {@link GListFooter}オブジェクト. */
	private GListFooter _footer = null;
	/** 現在の行のインディクス. */
	private int _currentRowIndex;
	/** 対象となるリストの総サイズ. */
	private int _totalSize = 0;
	/** スクロール領域の幅 */
	private String _scrollWidth = null;
	/** スクロール領域の高さ */
	private String _scrollHeight = null;
	/** 画面に表示される明細の要素順を示すIndex */
	private int _displayRowIndex;
	
	// リソースID
	/** 検索結果が0件の際の、メッセージ. */
	public static final String EMPTYMSG_RESOURCEID = "NO-SUCH-DATA";

	/**
	 * {@link GPListTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GPListTag() {
		reset();
	}

	/**
	 * XHTML文字列を生成します.<br>
	 * 
	 * @create 2011/7/27
	 * @return XHTML文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() {
		return createListTagBuilder().createStartTagString();
	}
	
	
	/**
	 * リスト用タグビルダーを作成します。
	 * 
	 * @return 必要な要素がすべて設定されたタグビルダー
	 * @author kawakami
	 * @create 2013/07/25
	 * @since 3.12.0
	 */
	protected GTagBuilder createListTagBuilder() {
		GTagBuilder tag = new GTagBuilder("table");
		decorateAttribute(tag);
		return tag;
	}

	/**
	 * ボディ評価後の処理を行います.<br>
	 * 
	 * 所有している{@link GListRow}の数だけ再評価します。<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.IterationTag#doAfterBody()
	 * @create 2011/7/27
	 * @return {@link jakarta.servlet.jsp.tagext.IterationTag#EVAL_BODY_AGAIN}
	 *         :再びBODYを評価します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doAfterBody() throws JspException {
		_currentRowIndex++;
		if (_rows.size() <= _currentRowIndex) {
			return SKIP_BODY;
		}
		return EVAL_BODY_AGAIN;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 以下のXHTML文字列を出力します。<br>
	 * [1] table要素の終了タグ<br>
	 * [2] 表示されるリストの開始インデックスと表示件数をを値に持つ、type属性が<code>"hidden"</code>であるinput要素<br>
	 * [3] 検索結果が0件の際に表示するメッセージを内包するdiv要素<br>
	 * [4] リストを内包するdiv要素の終了タグ<br>
	 * 
	 * @create 2011/7/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagUtils.printOut(pageContext, getScrollStrategy().createListEndTag());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * リストを内包するdiv要素と、table要素の開始タグを出力します。<br/>
	 * 
	 * @create 2011/7/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, getScrollStrategy().createListStartTag());
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/7/27
	 * @param component レンダリング対象UIコンポーネント
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPList ui = (GPList) component;
		GPList rep = (GPList) component.getRepository();
		setSummary(evaluatePlaceholder(ui.getSummary(), getSummary(),
				rep == null ? null : rep.getSummary(), ui));
		setListsize(evaluatePlaceholder(ui.getListsize(), getListsize(),
				rep == null ? null : rep.getListsize(), ui));
		setIsemptymsg(evaluatePlaceholder(ui.getIsemptymsg(), getIsemptymsg(),
				rep == null ? null : rep.getIsemptymsg(), ui));
		setEmptymsg(evaluatePlaceholder(ui.getEmptymsg(), getEmptymsg(),
				rep == null ? null : rep.getEmptymsg(), ui));
		setZebrarow(evaluatePlaceholder(ui.getZebrarow(), getZebrarow(),
				rep == null ? null : rep.getZebrarow(), ui));
		setScrollWidth(evaluatePlaceholder(ui.getScrollWidth(), getScrollWidth(),
				rep == null ? null : rep.getScrollWidth(), ui));
		setScrollHeight(evaluatePlaceholder(ui.getScrollHeight(), getScrollHeight(),
				rep == null ? null : rep.getScrollHeight(), ui));
		setStartIndex(ui.getStartIndex());
		setTotalSize(ui.getTotalSize());
		setEmpty(ui.getEmpty());
		setCaption(ui.getCaption());
		setHeader(ui.getHeader());
		setRows(ui.getRows());
		setFooter(ui.getFooter());
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see GUIComponentTag#reset()
	 * @create 2011/7/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		setCurrentRowIndex(-1);
		setDisplayRowIndex(-1);
		setListsize("-1");
		setTotalSize(0);
		setRows(new ArrayList<GListRow>());
		setStartIndex(-1);
		setScrollWidth(null);
		setScrollHeight(null);
	}

	/**
	 * 検索結果が0件の際に表示するメッセージの領域のXHTML文字列を生成します.<br />
	 * 
	 * @return 検索結果が0件の際に表示するメッセージの領域のXHTML文字列
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	protected String createEmptymsgTagString() {
		GTagBuilder emptymsgDivTag = new GTagBuilder("div");
		emptymsgDivTag.setAttribute("id", getFullId() + "_emptymsg_block");
		emptymsgDivTag.setAttribute("class", getFullId() + "_emptymsg_block");
		if (isIsEmptymsg() && isEmpty() && getRows().size() == 0) {
			emptymsgDivTag.setInnerText(GStringUtils.isEmpty(getEmptymsg()) ? getMessage(EMPTYMSG_RESOURCEID)
				: getEmptymsg());
		}
		return emptymsgDivTag.createStartEndTagString();
	}

	/**
	 * type属性が<code>"hidden"</code>であるinput要素のXHTML文字列を生成します.<br>
	 * 
	 * type属性が<code>"hidden"</code>であるinput要素は、表示されるリストの開始インデックスと、
	 * 表示件数を値に持つinput要素です。<br/>
	 * 
	 * @return type属性が<code>"hidden"</code>であるinput要素のXHTML文字列
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	protected String createHiddenTagString() {
		GTagBuilder startindexTag = new GTagBuilder("input");
		startindexTag.setAttribute("id", getFullId() + ".startindex");
		startindexTag.setAttribute("name", getFullId() + ".startindex");
		startindexTag.setAttribute("type", "hidden");
		startindexTag.setAttribute("value", String.valueOf(_startIndex));
		startindexTag.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), "false");
		GTagBuilder listsizeTag = new GTagBuilder("input");
		listsizeTag.setAttribute("id", getFullId() + ".listsize");
		listsizeTag.setAttribute("name", getFullId() + ".listsize");
		listsizeTag.setAttribute("type", "hidden");
		listsizeTag.setAttribute("value", _listsize);
		listsizeTag.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), "false");
		GTagBuilder totalsizeTag = new GTagBuilder("input");
		totalsizeTag.setAttribute("id", getFullId() + ".totalsize");
		totalsizeTag.setAttribute("name", getFullId() + ".totalsize");
		totalsizeTag.setAttribute("type", "hidden");
		totalsizeTag.setAttribute("value", String.valueOf(_totalSize));
		totalsizeTag.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), "false");
		GTagBuilder isemptyTag = new GTagBuilder("input");
		isemptyTag.setAttribute("id", getFullId() + ".empty");
		isemptyTag.setAttribute("name", getFullId() + ".empty");
		isemptyTag.setAttribute("type", "hidden");
		isemptyTag.setAttribute("value", String.valueOf(isEmpty()));
		isemptyTag.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), "false");
		return startindexTag.createTagString() + listsizeTag.createTagString() + totalsizeTag.createTagString() + isemptyTag.createTagString();
	}
	


	
	/**
	 * リストを内包する領域のXHTML文字列を生成します.<br />
	 * 
	 * @create 2011/7/27
	 * @return リストを内包する領域のXHTML文字列
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	protected GTagBuilder createListBlockTag() {
		GTagBuilder listBlockTag = new GTagBuilder("div");
		listBlockTag.setAttribute("id", getFullId() + "_list_block");
		listBlockTag.setAttribute("class", BLOCK_STYLECLASS);
		return listBlockTag;
	}

	/**
	 * 指定されたタグビルダーにこのタグの基本属性を追加します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentBaseTag#decorateBaseAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/7/27
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("summary", getSummary());
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイル属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2013/08/08
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	protected void decorateStyleAttribute(GTagBuilder builder) {
		builder.setAttribute("style", getStyle());
	}
	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * テーブルの見出しを取得します.<br>
	 * 
	 * @return {@link GListCaption}インスタンス
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GListCaption getCaption() {
		return _caption;
	}

	/**
	 * 現在の行のインディクスを取得します.<br>
	 * 
	 * @return 行のインディクス
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getCurrentRowIndex() {
		return _currentRowIndex;
	}

	/**
	 * リストの結果が0件の際の表示メッセージを取得します
	 * 
	 * @create 2011/4/18
	 * @return メッセージ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getEmptymsg() {
		return _emptymsg;
	}

	/**
	 * テーブルのフッタを取得します.<br />
	 * 
	 * @create 2011/4/18
	 * @return {@link GListFooter}のオブジェクト
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GListFooter getFooter() {
		return _footer;
	}

	/**
	 * テーブルのヘッダを取得します.<br />
	 * 
	 * @return {@link GListHeader}インスタンス
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GListHeader getHeader() {
		return _header;
	}

	/**
	 * isempty属性の値を取得します.<br/>
	 * 
	 * @create 2011/07/27
	 * @return isempty属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getIsemptymsg() {
		return _isemptymsg;
	}

	/**
	 * リストの表示件数を取得します.<br />
	 * 
	 * @return リストの表示件数
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getListsize() {
		return _listsize;
	}

	/**
	 * リスト内の指定された位置にある{@link GListRow}を取得します.<br />
	 * 
	 * @param index インデックス
	 * @return {@link GListRow}インスタンス
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public GListRow getRow(int index) {
		return _rows.get(index);
	}

	/**
	 * {@link GListRow}のリストを取得します.<br />
	 * 
	 * @return {@link GListRow}のリスト
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public List<GListRow> getRows() {
		return _rows;
	}

	/**
	 * 表示しているデータの開始件数を取得します.<br />
	 * 
	 * @return 表示しているデータの開始件数
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public int getStartIndex() {
		return _startIndex;
	}

	/**
	 * 表の目的や構成の説明を取得します.<br />
	 * 
	 * @return 表の目的や構成の説明を
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public String getSummary() {
		return _summary;
	}

	/**
	 * valueを取得します.<br />
	 * 
	 * @create 2020/07/31
	 * @return value
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Override
	protected String getValue() {
		throw new UnsupportedOperationException();
	}

	/**
	 * zebrarow属性の値を取得します.<br />
	 * 
	 * @create 2011/07/27
	 * @return zebrarow属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getZebrarow() {
		return _zebrarow;
	}

	/**
	 * 結果セット内のリストの有無を取得します.<br />
	 * 
	 * @return 結果セット内のリストの有無
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public boolean isEmpty() {
		return GBooleanUtils.toBoolean(_empty, false);
	}

	/**
	 * リストの結果が0件の際のメッセージ表示の有無を取得します.<br />
	 * 
	 * @return <code>true</code>/<code>false</code>
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public boolean isIsEmptymsg() {
		return GBooleanUtils.toBoolean(_isemptymsg, true);
	}

	/**
	 * zebrarow属性の値を取得します.<br />
	 * 
	 * @return ゼブラ機能の使用有無
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public boolean isZebrarow() {
		return GBooleanUtils.toBoolean(_zebrarow, true);
	}

	/**
	 * テーブルの見出しを設定します.<br />
	 * 
	 * @param caption {@link GListCaption}インスタンス
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setCaption(GListCaption caption) {
		_caption = caption;
	}

	/**
	 * 結果セット内のリストの有無を設定します.<br>
	 * 
	 * @param empty <code>true</code>/<code>false</code>
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setEmpty(boolean empty) {
		_empty = String.valueOf(empty);
	}

	/**
	 * 結果セット内のリストの有無を設定します.<br>
	 * 
	 * @param empty <code>true</code>/<code>false</code>
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setEmpty(String empty) {
		_empty = empty;
	}

	/**
	 * リストの結果が0件の際の表示メッセージを設定します
	 * 
	 * @create 2011/4/18
	 * @param emptymsg メッセージ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setEmptymsg(String emptymsg) {
		_emptymsg = emptymsg;
	}

	/**
	 * テーブルのフッタを設定します.<br />
	 * 
	 * @create 2011/4/18
	 * @param footer {@link GListFooter}のオブジェクト
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setFooter(GListFooter footer) {
		_footer = footer;
	}

	/**
	 * テーブルのヘッダを設定します.<br />
	 * 
	 * @param header {@link GListHeader}インスタンス
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setHeader(GListHeader header) {
		_header = header;
	}

	/**
	 * リストの結果が0件の際のメッセージ表示の有無を設定します.<br>
	 * <code>true</code>:リストの結果が0件の際にメッセージを表示します<br>
	 * <code>false</code>:リストの結果が0件の際にメッセージを表示しません<br>
	 * 
	 * @param isemptymsg リストの結果が0件の際のメッセージ表示の有無
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setIsemptymsg(boolean isemptymsg) {
		_isemptymsg = String.valueOf(isemptymsg);
	}

	/**
	 * isempty属性の値を設定します.<br/>
	 * 
	 * @param isemptymsg リストの結果が0件の際のメッセージ表示の有無
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setIsemptymsg(String isemptymsg) {
		_isemptymsg = isemptymsg;
	}

	/**
	 * リストの表示件数を設定します.<br />
	 * 
	 * @param listsize リストの表示件数
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setListsize(String listsize) {
		_listsize = listsize;
	}

	/**
	 * {@link GListRow}のリストを設定します.<br />
	 * 
	 * @param rows {@link GListRow}のリスト
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setRows(List<GListRow> rows) {
		_rows = rows;
	}

	/**
	 * 表示しているデータの開始件数を設定します.<br />
	 * 
	 * @param startIndex 表示しているデータの開始件数
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setStartIndex(int startIndex) {
		_startIndex = startIndex;
	}

	/**
	 * 音声読み上げブラウザなどのために、この表の目的や構成の説明を設定します.<br />
	 * 
	 * @param summary 表の目的や構成の説明
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setSummary(String summary) {
		_summary = summary;
	}

	/**
	 * zebrarow属性の値を設定します.<br />
	 * 
	 * @param zebrarow <code>true</code>/<code>false</code>
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setZebrarow(boolean zebrarow) {
		_zebrarow = String.valueOf(zebrarow);
	}

	/**
	 * zebrarow属性の値を設定します.<br />
	 * 
	 * @param zebrarow <code>true</code>/<code>false</code>
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	public void setZebrarow(String zebrarow) {
		_zebrarow = zebrarow;
	}

	/**
	 * 対象となるリストの総サイズを取得します.<br />
	 * 
	 * @create 2013/3/05
	 * @return 対象となるリストの総サイズ
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public int getTotalSize() {
		return _totalSize;
	}

	/**
	 * 対象となるリストの総サイズを設定します.<br />
	 * 
	 * @create 2013/03/05
	 * @param totalSize 対象となるリストの総サイズ
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setTotalSize(int _totalSize) {
		this._totalSize = _totalSize;
	}

	/**
	 * 現在の行のインディクスを設定します.<br />
	 * 
	 * @param currentRowIndex インデックス
	 * @create 2011/07/27
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	protected void setCurrentRowIndex(int currentRowIndex) {
		_currentRowIndex = currentRowIndex;
	}

	/**
	 * リソースIDより文字列リソースを取得します.<br>
	 * 
	 * @create 2011/7/27
	 * @param resourceid リソースID
	 * @return メッセージ
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	private String getMessage(String resourceid) {
		return GMessageResources.getMessage(resourceid, GWebContext.getInstance().getLocale());
	}
	
	/**
	 * スクロール領域の幅(px)を取得します。<br>
	 * 
	 * @create 2013/07/23
	 * @return スクロール領域の幅(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getScrollWidth() {
		return _scrollWidth;
	}

	
	/**
	 * スクロール領域の幅(px)を設定します。<br>
	 * 
	 * @create 2013/07/23
	 * @param スクロール領域の幅(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setScrollWidth(String _scrollWidth) {
		this._scrollWidth = _scrollWidth;
	}
	
	/**
	 * スクロール領域の高さ(px)を取得します。<br>
	 * 
	 * @create 2013/07/23
	 * @return スクロール領域の高さ(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getScrollHeight() {
		return _scrollHeight;
	}
	
	/**
	 * スクロール領域の高さ(px)を取得します。<br>
	 * 
	 * @create 2013/07/23
	 * @param スクロール領域の高さ(px)
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setScrollHeight(String _scrollHeight) {
		this._scrollHeight = _scrollHeight;
	}

	/**
	 * スクロールの状態(垂直のみ・水平のみ・両方・なし)ごとに
	 * 定義された振る舞いを持つStrategyオブジェクトを取得します。
	 * @return 
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	public GPListScrollStrategy getScrollStrategy() {
		if(isVertical() && isHorizontal()) {
			return new GPListScrollStrategyBoth(this);
		}
		if (isHorizontal()) {
			return new GPListScrollStrategyHorizontal(this);
		}
		if (isVertical()) {
			return new GPListScrollStrategyVertical(this);
		}
		return new GPListScrollStrategyNone(this);
	}
	/**
	 * 垂直スクロールが設定されているかどうか
	 * 
	 * @return true 垂直スクロールあり false 垂直スクロールなし
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	private boolean isVertical() {
		if (GStringUtils.isEmpty(this.getScrollHeight())) {
			return false;
		}
		return true;
	}
	
	/**
	 * 水平スクロールが設定されているかどうか
	 * 
	 * @return true 水平スクロールあり false 水平スクロールなし
	 * @author kawakami
	 * @create 2013/07/24
	 * @since 3.12.0
	 */
	private boolean isHorizontal() {
		if (GStringUtils.isEmpty(this.getScrollWidth())) {
			return false;
		}
		return true;
	}
	
	/**
	 * 初回のボディ評価中かどうかを返します。
	 * 
	 * @return 初回のボディ評価中かどうか
	 * @author kawakami
	 * @create 2013/07/30
	 * @since 3.12.0
	 */
	public boolean isFirstEval() {
		return getCurrentRowIndex() == -1;
	}
	
	/**
	 * ボディ評価の繰り返し中であるかどうかを返します。
	 * 
	 * @return ボディ評価の繰り返し中であるかどうか
	 * @author kawakami
	 * @create 2013/07/30
	 * @since 3.12.0
	 */
	public boolean isDuringIteration() {
		return getCurrentRowIndex() > -1;
	}
	
	/**
	 * 最後のボディ評価であるかどうかを返します。
	 * 
	 * @return 最後のボディ評価であるかどうか
	 * @author kawakami
	 * @create 2013/07/30
	 * @since 3.12.0
	 */
	public boolean isLastEval() {
		return getCurrentRowIndex() == (getRows().size() - 1) || getRows().size() == 0 ;
	}

	/**
	 * {@inheritDoc}
	 *
	 * 非推奨。Requiredの値は変更されません。また、必須チェックは行いません。
	 *
	 * @param required
	 * @author fujikake
	 * @since 3.19.2
	 */
	@Deprecated
	@Override
	public void setRequired(boolean required) {
		//値は変更しません。
	}

	/**
	 * {@inheritDoc}
	 *
	 * 非推奨。Requiredの値は変更されません。また、必須チェックは行いません。
	 *
	 * @param required
	 * @author fujikake
	 * @since 3.19.2
	 */
	@Deprecated
	@Override
	public void setRequired(String required) {
		//値は変更しません。
	}

	/**
	 * 画面に表示される明細の要素順を示すIndexを取得します。
	 * 
	 * @create 2021/03/18
	 * @author KCSS
	 * @since 21.3.0
	 */
	public int getDisplayRowIndex() {
		return _displayRowIndex;
	}
	/**
	 * 画面に表示される明細の要素順を示すIndexを設定します。
	 * 
	 * @create 2021/03/18
	 * @author KCSS
	 * @since 21.3.0
	 */
	public int setDisplayRowIndex(int displayRowIndex) {
		return _displayRowIndex = displayRowIndex;
	}
	/**
	 * 画面に表示される明細の要素順を示すIndexをインクリメントします。
	 * 
	 * @create 2021/03/18
	 * @author KCSS
	 * @since 21.3.0
	 */
	public int increaseDisplayRowIndex() {
		return _displayRowIndex++;
	}
}