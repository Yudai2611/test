/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * XHTMLのアンカータグをレンダリングするときに使用できるユーティリティ.<br />
 * 
 * @create 2011/07/11
 * @author hamanaka
 * @since 3.9.0
 */
public class GAnchorUtils {

	/**
	 * {@link GAnchorUtils}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/07/11
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GAnchorUtils() {
	}

	/**
	 * 右クリックのコンテキストメニュー表示を抑制するスクリプトを生成します.<br />
	 * 
	 * @param oncontextmenuAttrValue oncontextmenu属性の値
	 * @create 2011/07/11
	 * @return 右クリックのコンテキストメニュー表示を抑制するスクリプト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public static String createPreventContextMenuEventScript(String oncontextmenuAttrValue) {
		GJavaScriptBuilder actionScript = new GJavaScriptBuilder();
		actionScript
			.append("if($(this).attr('href')==='javascript:void(0);'){return false;}");
		if (oncontextmenuAttrValue != null) {
			actionScript.append(oncontextmenuAttrValue);
		}
		return GStringUtils.blankToNull(actionScript.toString());
	}

	/**
	 * Shift/Ctrl押下しながらのマウスクリックを抑制するスクリプトを生成します.<br />
	 * 
	 * @param onclickAttrValue onclick属性の値
	 * @create 2011/07/11
	 * @return Shiftクリック抑制のスクリプト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public static String createPreventClickEventScript(String onclickAttrValue) {
		GJavaScriptBuilder preventScript = new GJavaScriptBuilder();
		preventScript
			.append("if($(this).attr('href')==='javascript:void(0);'){if(event.shiftKey===true || event.ctrlKey===true){return false;}}");
		if (onclickAttrValue != null) {
			preventScript.append(onclickAttrValue);
		}
		return GStringUtils.blankToNull(preventScript.toString());
	}

}
