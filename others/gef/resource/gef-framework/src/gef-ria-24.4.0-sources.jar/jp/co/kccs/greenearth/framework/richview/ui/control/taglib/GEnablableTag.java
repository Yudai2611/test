/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

/**
 * タグの有効状態を表すインターフェースです.<br/>
 * 
 * @create 2013/07/20
 * @author yamashita
 * @since 3.12.0
 */
public interface GEnablableTag {

	/**
	 * タグの有効/無効を取得します.<br />
	 * 
	 * @create 2013/07/20
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	boolean isEnabled();

	/**
	 * タグの有効/無効を設定します.<br />
	 * 
	 * @create 2013/07/20
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	void setEnabled(boolean enabled);
}
