/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPAjaxRender;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTag;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTagUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * ajaxのスクリプトブロックを表すタグクラスです.<br/>
 * 
 * @create 2011/05/23
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GPAjaxRender.class)
public class GPAjaxRenderTag extends GUIContainerControlBaseTag implements GScriptBufferedWriterTag { // ,

	// DynamicAttributes
	// {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5188070453539100495L;
	// 内部変数
	/** エスケープ済みJavaScript文字列. */
	StringBuilder _parts = new StringBuilder();
	/** エスケープ済みHTML文字列. */
	StringBuilder _elements = new StringBuilder();

	// /** 動的に指定されたHTMLの名前空間のマップ. */
	// private Map<String, String> _namespaceMap;

	/**
	 * {@link GPAjaxRenderTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/23
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPAjaxRenderTag() {
	}

	/**
	 * HTML文字列を追加します.<br/>
	 * 
	 * セットされるHTML文字列はエスケープ済み文字列である必要があります。
	 * 
	 * @create 2011/05/23
	 * @param element エスケープ済みHTML文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void appendElement(String element) {
		if (GStringUtils.isEmpty(element)) {
			return;
		}
		_elements.append(element);
	}

	/**
	 * JavaScript文字列を追加します.<br/>
	 * 
	 * セットされるJavaScript文字列はエスケープ済み文字列である必要があります。
	 * 
	 * @create 2011/05/23
	 * @param parts エスケープ済みJavaScript文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void appendParts(String parts) {
		if (GStringUtils.isEmpty(parts)) {
			return;
		}
		_parts.append(parts);
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/05/23
	 * @return XHTML文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("span");
		decorateAttribute(builder);
		return builder.createStartTagString();
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/05/23
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder tagBuilder = new GTagBuilder("span");
			GTagUtils.printOut(pageContext, tagBuilder.createEndTagString());
			writeScript();
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/06/21
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします / {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を処理します。 
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			Tag tag = findAncestorWithClass(this, GScriptBufferedWriterTag.class);
			if (tag != null) {
				GTagBuilder divBuilder = new GTagBuilder("div");
				divBuilder.setAttribute("id", getFullId() + ".script.block");
				GScriptBufferedWriterTag writerTag = (GScriptBufferedWriterTag) tag;
				writerTag.appendElement(divBuilder.createStartTagString());
			}
			GTagUtils.printOut(pageContext, createXhtmlString());
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2011/05/24
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		_parts = new StringBuilder();
		_elements = new StringBuilder();
	}

	/**
	 * 対象となる要素のタグ終了時点で、要素にバインドされたスクリプトを一括して出力します.<br />
	 * 
	 * @create 2011/05/23
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void writeScript() throws JspException {
		Tag tag = findAncestorWithClass(this, GScriptBufferedWriterTag.class);
		String script = GScriptBufferedWriterTagUtils.createScript(_parts, _elements);
		GTagBuilder divBuilder = new GTagBuilder("div");
		if (tag == null) {
			StringBuilder builder = new StringBuilder();
			divBuilder.setAttribute("id", getFullId() + ".script.block");
			builder.append(divBuilder.createStartTagString());
			builder.append(script);
			builder.append(divBuilder.createEndTagString());
			GTagUtils.printOut(pageContext, builder.toString());
			return;
		}
		GScriptBufferedWriterTag writerTag = (GScriptBufferedWriterTag) tag;
		writerTag.appendElement(script);
		writerTag.appendElement(divBuilder.createEndTagString());
	}
}
