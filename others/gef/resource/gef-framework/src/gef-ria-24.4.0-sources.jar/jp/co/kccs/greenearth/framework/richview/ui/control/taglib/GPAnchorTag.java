/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPAnchor;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * アンカーコントロールを表示するタグクラスです.<br>
 * 
 * @create 2011/06/21
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPAnchor.class)
public class GPAnchorTag extends GUIContainerControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4158855395094526002L;

	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gpanchor";

	// XHTML属性
	/** charset属性の値. */
	private String _charset = null;
	/** coords属性の値. */
	private String _coords = null;
	/** href属性の値. */
	private String _href = null;
	/** hreflang属性の値. */
	private String _hreflang = null;
	/** rel属性の値. */
	private String _rel = null;
	/** rev属性の値. */
	private String _rev = null;
	/** shape属性の値. */
	private String _shape = null;
	/** type属性の値. */
	private String _type = null;
	/** target属性の値. */
	private String _target = null;
	/** oncontext属性の値. */
	private String _oncontextmenu = null;

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * {@link GPAnchorTag}の新しいインスタンスを初期化します。<br>
	 * 
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPAnchorTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/06/21
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = null;

		// a要素のXHTML出力文字列を作成します
		builder = new GTagBuilder("a");
		decorateATagAttribute(builder);

		return builder.createStartTagString();
	}

	/**
	 * 終了タグの標準処理です.<br>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder tag = new GTagBuilder("a");
			GTagUtils.printOut(pageContext, tag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPAnchor ui = (GPAnchor) component;
		GPAnchor rep = (GPAnchor) component.getRepository();
		setCharset(evaluatePlaceholder(ui.getCharset(), getCharset(),
				rep == null ? null : rep.getCharset(), ui));
		setCoords(evaluatePlaceholder(ui.getCoords(), getCoords(),
				rep == null ? null : rep.getCoords(), ui));
		setHref(evaluatePlaceholder(ui.getHref(), getHref(),
				rep == null ? null : rep.getHref(), ui));
		setHreflang(evaluatePlaceholder(ui.getHreflang(), getHreflang(),
				rep == null ? null : rep.getHreflang(), ui));
		setRel(evaluatePlaceholder(ui.getRel(), getRel(),
				rep == null ? null : rep.getRel(), ui));
		setRev(evaluatePlaceholder(ui.getRev(), getRev(),
				rep == null ? null : rep.getRev(), ui));
		setShape(evaluatePlaceholder(ui.getShape(), getShape(),
				rep == null ? null : rep.getShape(), ui));
		setType(evaluatePlaceholder(ui.getType(), getType(),
				rep == null ? null : rep.getType(), ui));
		setTarget(evaluatePlaceholder(ui.getTarget(), getTarget(),
				rep == null ? null : rep.getTarget(), ui));
		setOncontextmenu(evaluatePlaceholder(ui.getOncontextmenu(), getOncontextmenu(),
				rep == null ? null : rep.getOncontextmenu(), ui));
		setAssociatedComponent(component);
	}

	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#bindMainScript(java.lang.String,
	 *      jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder,
	 *      jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder)
	 * @param event イベントタイプ
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @param bindScriptBuilder 関連付け先のスクリプトバッファ
	 * @throws JspException 関連付けに失敗したとき
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder)
		throws JspException {
		if ("click".equals(event) && getHref() == null) {
			scriptBuilder.prepend(GAnchorUtils.createPreventClickEventScript(null));
		}
		if ("contextmenu".equals(event) && getHref() == null) {
			scriptBuilder.append(GAnchorUtils.createPreventContextMenuEventScript(null));
		}
		super.bindMainScript(event, scriptBuilder, bindScriptBuilder);
	}

	/**
	 * 指定されたタグビルダーにこのタグの基本属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder タグビルダー
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void decorateATagAttribute(GTagBuilder builder) throws JspException {
		super.decorateAttribute(builder);

		builder.setAttribute("charset", getCharset());
		builder.setAttribute("coords", getCoords());
		builder.setAttribute("hreflang", getHreflang());
		builder.setAttribute("rel", getRel());
		builder.setAttribute("rev", getRev());
		builder.setAttribute("shape", getShape());
		builder.setAttribute("type", getType());
		builder.setAttribute("oncontextmenu", getOncontextmenu());
		if (getHref() == null) {
			builder.setAttribute("href", "javascript:void(0);");
		} else {
			builder.setAttribute("href", getHref());
			builder.setAttribute("target", getTarget());
		}
		bindPreventScript();
	}

	/**
	 * スクリプトを生成します.<br />
	 * clickイベントに対してはShift/Ctrlクリックを抑止するスクリプトを、contextmenuイベントに対しては右ｸﾘｯｸﾒﾆｭｰ表示を抑止するスクリプトを生成します。<br />
	 * 
	 * @create 2014/08/28
	 * @throws JspException 関連付けに失敗したとき
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	private void bindPreventScript() throws JspException {
		if (getHref() == null) {
			if (getOncontextmenu() == null) {
				bindScript("contextmenu", new GJavaScriptBuilder());
			}
			if (getOnclick() == null) {
				bindScript("click", new GJavaScriptBuilder());
			}
		}
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * charset属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return charset属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getCharset() {
		return _charset;
	}

	/**
	 * coords属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return coords属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getCoords() {
		return _coords;
	}

	/**
	 * href属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return href属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getHref() {
		return _href;
	}

	/**
	 * hreflang属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return hreflang属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getHreflang() {
		return _hreflang;
	}

	/**
	 * oncontextmenu属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return oncontextmenu属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getOncontextmenu() {
		return _oncontextmenu;
	}

	/**
	 * rel属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return rel属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getRel() {
		return _rel;
	}

	/**
	 * rev属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return getrev属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getRev() {
		return _rev;
	}

	/**
	 * shape属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return shape属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getShape() {
		return _shape;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.action.GActionControl#getTarget()
	 * @create 2011/06/21
	 * @return target属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * type属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return type属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getType() {
		return _type;
	}

	/**
	 * 属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param charset charset属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setCharset(String charset) {
		_charset = charset;
	}

	/**
	 * coords属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param coords coords属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setCoords(String coords) {
		_coords = coords;
	}

	/**
	 * href属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param href href属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setHref(String href) {
		_href = href;
	}

	/**
	 * hreflang属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param hreflang hreflang属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setHreflang(String hreflang) {
		_hreflang = hreflang;
	}

	/**
	 * oncontextmenu属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param oncontextmenu oncontextmenu属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setOncontextmenu(String oncontextmenu) {
		_oncontextmenu = oncontextmenu;
	}

	/**
	 * rel属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param rel rel属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setRel(String rel) {
		_rel = rel;
	}

	/**
	 * rev属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param rev rev属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setRev(String rev) {
		_rev = rev;
	}

	/**
	 * shape属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param shape shape属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setShape(String shape) {
		_shape = shape;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.action.GActionControl#setTarget(String)
	 * @create 2011/06/21
	 * @param target target属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setTarget(String target) {
		_target = target;
	}

	/**
	 * type属性の値を設定します.<br />
	 * 
	 * @param type type属性の値
	 * @create 2011/06/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setType(String type) {
		_type = type;
	}
}
