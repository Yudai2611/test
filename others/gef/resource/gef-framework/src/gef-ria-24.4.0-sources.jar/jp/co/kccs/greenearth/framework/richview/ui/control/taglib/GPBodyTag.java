/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPBody;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPForm;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GELFunction;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTag;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTagUtils;
import jp.co.kccs.greenearth.framework.view.GViewResponseFilter;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * ボディコントロールを表示するタグクラスです.<br/>
 * 
 * @create 2013/03/19
 * @author KCCS kikuchi
 * @since 3.10.0.D
 */
@TargetUIComponent(GPBody.class)
public class GPBodyTag extends GUIContainerControlBaseTag implements GScriptBufferedWriterTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5348462019789816680L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gpbody";
	/** 画面情報のキー名. */
	private static final String VIEW_CONFIG_KEY = "viewconfig";
	
	/** エスケープ済みJavaScript文字列をバッファ. */
	StringBuilder _parts = new StringBuilder();
	/** エスケープ済みHTML文字列をバッファ.*/
	StringBuilder _elements = new StringBuilder();
	
	// XHTML属性
	/** ロードイベント. */
	private String _onload;
	/** アンロードイベント. */
	private String _onunload;

	// 内部変数
	/** 画面ID. */
	private String _viewid;
	/** ワンタイムトークン文字列. */
	private String _oneTimeToken;
	
	/**
	 * {@link GPBodyTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/19
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public GPBodyTag() {
	}

	/**
	 * エレメントを追加します.<br />
	 * 
	 * @create 2013/03/19
	 * @param element HTML文字列
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public void appendElement(String element) {
		_elements.append(GStringUtils.nullToBlank(element));
	}

	/**
	 * JavaScript文字列を追加します.<br />
	 * 
	 * @create 2013/03/19
	 * @param parts javascript文字列
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public void appendParts(String parts) {
		_parts.append(GStringUtils.nullToBlank(parts));
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#createXhtmlString()
	 * @return XHTML文字列
	 * @create 2013/03/21
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public String createXhtmlString() {
		StringBuilder strBuilder = new StringBuilder(); //script
		GTagBuilder builder = new GTagBuilder("body");
		decorateAttribute(builder);
		strBuilder.append(builder.createStartTagString());
		strBuilder.append(createViewConfigString());
		return strBuilder.toString();
	}
	
	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2013/03/19
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			writeScript();
			GTagBuilder builder = new GTagBuilder("body");
			GTagUtils.printOut(pageContext, builder.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}
	
	/**
	 * 開始タグの標準処理です.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を1回だけ処理します/
	 * {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2013/03/29
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		generateViewid();
		updateManagedTokens();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag#load(
	 * jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2013/03/21
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPBody ui = (GPBody) component;
		GPBody rep = (GPBody) component.getRepository();
		setOnload(evaluatePlaceholder(ui.getOnload(), getOnload(), 
				rep == null ? null : rep.getOnload(), ui));
		setOnunload(evaluatePlaceholder(ui.getOnunload(), getOnunload(),
				rep == null ? null : rep.getOnunload(), ui));
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2013/03/19
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		_parts = new StringBuilder();
		_elements = new StringBuilder();
	}

	/**
	 * 対象となる要素のタグ終了時点で、要素にバインドされたスクリプトを一括して出力します.<br />
	 * 
	 * @create 2013/03/19
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public void writeScript() throws JspException {
		appendParts(createDefaultLocaleScript());
		appendParts(createDefaultContextPathScript());
		appendParts(createInitFocusScript());
		String script = GScriptBufferedWriterTagUtils.createScript(_parts, _elements);
		GTagUtils.printOut(pageContext, script);
	}
	
	/**
	 * デフォルトのコンテキストパス情報を提供するスクリプトを返します.<br />
	 * 
	 * @create 2013/03/19
	 * @return コンテキストパスをクライアント側に提供するスクリプト
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String createDefaultContextPathScript() {
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		scriptBuilder.append("$.ge.contextPath = '");
		scriptBuilder.append(GELFunction.ctxpath());
		scriptBuilder.append("';");
		return scriptBuilder.toString();
	}
	
	/**
	 * デフォルトのロケール情報を提供するスクリプトを生成します.<br />
	 * 
	 * $.ge.locale = "ja-JP"
	 * 
	 * @create 2013/03/19
	 * @return JavaScript文字列
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String createDefaultLocaleScript() {
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		scriptBuilder.append("$.ge.locale = '");
		String locale = GLocaleUtils.toString(GFrameworkContext.getInstance().getLocale(), "-");
		scriptBuilder.append(GStringUtils.nullToBlank(locale));
		scriptBuilder.append("';");
		return scriptBuilder.toString();
	}
	
	/**
	 * 初期フォーカスを設定するXHTML文字列を生成します.<br />
	 * 初期フォーカスを設定するScriptが、script要素の内部テキストとして生成されます。<br />
	 * 
	 * @return XHTML文字列
	 * @create 2013/03/21
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String createInitFocusScript() {
		GPBody body = (GPBody) getAssociatedComponent();
		String id = null;
		if (body != null) {
			id = findFocusControlId(body);
		}
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		if (id != null) {
			scriptBuilder.append("$(function(){$.ge.idSelector(??).focus();});", id);
		}
		return scriptBuilder.toString();
	}
	
	/**
	 * 画面情報を要素として出力するXHTML文字列を生成します.<br />
	 * ワンタイムトークン文字列を値とするinput要素、
	 * 画面のランダムなIDを値とするinput要素、
	 * 表示するJSPのパスを値とするinput要素を生成します。<br />
	 * 
	 * @return XHTML文字列
	 * @create 2013/03/21
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String createViewConfigString() {
		GTagBuilder builder = new GTagBuilder("div");
		builder.setAttribute("id", VIEW_CONFIG_KEY);
		StringBuilder innerText = new StringBuilder();
		innerText.append(createOneTimeTokenString());
		innerText.append(createViewIdString());
		innerText.append(createBackwardIdString());
		builder.setInnerText(innerText.toString());
		return builder.createStartEndTagString(false);
	}
	
	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateAttribute(
	 * jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @create 2013/03/21
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("onload", getOnload());
		builder.setAttribute("onunload", getOnunload());
	}

	/**
	 * タグのスタイルクラスを装飾します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2013/10/24
	 * @author KCCS kikuchi
	 * @since 3.12.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		builder.setAttribute("class", getStyleclass());
	}
	/**
	 * JSPのパスを取得します.<br />
	 * 
	 * @param request HTTPリクエスト
	 * @return JSPパス
	 * @create 2013/03/21
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String getServletPath(HttpServletRequest request) {
		return request.getServletPath();
	}
	
	/**
	 * ハイフン区切り32桁のワンタイムトークン文字列を生成します.<br />
	 * 呼び出しの度にランダムな異なる値を生成します。<br />
	 * また、生成された値は"[viewid]"をキー名としてMapにセットし、
	 * そのMapを{@link GConstants#ONE_TIME_TOKEN_SESSION_KEY}をキー名としてセッションに保持します。<br />
	 * ただし、ワンタイムトークンエラーが発生している場合は{@link HttpSession}にトークンを保持しません。<br />
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected void updateManagedTokens() {
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		Map<String, String> tokenMap = getManagedTokens(request);
		String uuid = UUID.randomUUID().toString();
		if (!existsTokenError(request)) {
			tokenMap.put(getViewid(), uuid);
		}
		setOneTimeToken(uuid);
	}
	
	/**
	 * セッション情報で管理されているワンタイムトークンのMapを取得します。
	 * 
	 * @create 2020/6/23
	 * @param request
	 * @return ワンタイムトークン
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@SuppressWarnings("unchecked")
	protected Map<String, String> getManagedTokens(HttpServletRequest request) {
		HttpSession httpSession = request.getSession();
		Map<String, String> tokens = (Map<String, String>) httpSession.getAttribute(GConstants.ONE_TIME_TOKEN_SESSION_KEY);
		if (tokens == null) {
			tokens = new HashMap<String, String>();
		}
		httpSession.setAttribute(GConstants.ONE_TIME_TOKEN_SESSION_KEY, tokens);
		return tokens;
	}
	
	/**
	 * ワンタイムトークンエラーの発生有無を確認します。<br />
	 * ワンタイムトークンエラーが発生している場合はtrue、それ以外はfalseを返します。
	 * 
	 * @create 2020/6/23
	 * @param request
	 * @return ワンタイムトークンエラー有無
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected boolean existsTokenError(HttpServletRequest request) {
		HttpSession httpSession = request.getSession();
		Throwable e = (Throwable) httpSession.getAttribute(GConstants.ONE_TIME_TOKEN_EXCEPTION_KEY);
		return e != null;
	}

	/**
	 * ハイフン区切り32桁のワンタイムトークン文字列を生成し、保持します.<br />
	 *
	 * @create 2013/03/19
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	void generateViewid() {
		_viewid = UUID.randomUUID().toString();
	}

	/**
	 * Backward ID用のHTMLを作成します.<br />
	 * 
	 * @return HTML文字列
	 * @create 2013/03/26
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String createBackwardIdString() {
		GTagBuilder backwardBuilder = new GTagBuilder("input");
		backwardBuilder.setAttribute("type", "hidden");
		backwardBuilder.setAttribute("name", GViewResponseFilter.BACKWARD_KEY);
		backwardBuilder.setAttribute("id", GViewResponseFilter.BACKWARD_KEY);
		backwardBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), String.valueOf(false));
		backwardBuilder.setAttribute("value", getServletPath((HttpServletRequest) pageContext.getRequest()));
		return backwardBuilder.createTagString();
	}
	
	/**
	 * ワンタイムトークン用のHTMLを作成します.<br />
	 * 
	 * @return XHTML文字列
	 * @create 2013/03/26
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String createOneTimeTokenString() {
		GTagBuilder oneTimeTokenBuilder = new GTagBuilder("input");
		oneTimeTokenBuilder.setAttribute("type", "hidden");
		oneTimeTokenBuilder.setAttribute("id", GConstants.ONE_TIME_TOKEN_PARAM_KEY);
		oneTimeTokenBuilder.setAttribute("name", GConstants.ONE_TIME_TOKEN_PARAM_KEY);
		oneTimeTokenBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), String.valueOf(false));
		oneTimeTokenBuilder.setAttribute("value", getOneTimeToken());
		return oneTimeTokenBuilder.createTagString();
	}
	
	/**
	 * 画面ID（View ID）用のHTMLを作成します.<br />
	 * 
	 * @return HTML文字列
	 * @create 2013/03/26
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String createViewIdString() {
		GTagBuilder viewidBuilder = new GTagBuilder("input");
		viewidBuilder.setAttribute("type", "hidden");
		viewidBuilder.setAttribute("id", GConstants.VIEWID_KEY);
		viewidBuilder.setAttribute("name", GConstants.VIEWID_KEY);
		viewidBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), String.valueOf(false));
		viewidBuilder.setAttribute("value", getViewid());
		return viewidBuilder.createTagString();
	}
	
	/**
	 * ネストされたJSPの要素からフォーカスのあるコントロールのidを取得します.<br />
	 * 
	 * @param container 子要素を内包するUIコントロール
	 * @return フォーカスのあるUIコントロールのid
	 * @create 2013/03/23
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String findFocusControlId(GUIControl container) {
		GWebContext context = GWebContext.getInstance();
		HttpServletRequest request = context.getRequest();
		String tempcontrolid = (String) request.getAttribute(GUIControl.UICONTROL_FOCUS_ID_KEY);
		String controlid = null;
		if (tempcontrolid != null) {
			GUIControl control = container.findControl(tempcontrolid);
			if (control != null && control.canFocus()) {	// TODO: [2013/08/14][yamashita]control==nullはありえないのでは！？例外とするかどうかをあとで検討！
				controlid = tempcontrolid;
			}
		}
		return controlid == null ? getDefaultFocusId(container) : controlid;
	}

	/**
	 * ネストされたJSPの要素からフォームタグを取得し、デフォルトフォーカスIDを取得します.<br />
	 * 指定されたデフォルトフォーカスIDのコントロールが、フォーカスを当てられる状態の場合のみ、
	 * そのIDを取得します。<br />
	 * 
	 * @create 2013/03/19
	 * @param control UIコントロール
	 * @return デフォルトフォーカスオブジェクトID
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected String getDefaultFocusId(GUIControl control) {
		String focusid = null;
		List<GUIControl> forms = GUIUtils.getControls(control, GPForm.class);
		for (int i = 0; i < forms.size(); i++) {
			GPForm form = (GPForm) forms.get(i);
			String id = form.getFocus();
			if (id != null) {
				GUIControl focus = null;
				if (id.equals(form.getId())) {
					focus = form;
				} else {
					focus = form.findControl(id);
				}
				if (focus != null && focus.canFocus()) {
					focusid = GStringUtils.nullToBlank(focus.getPrefix()) + focus.getId();
				}
			}
		}
		return focusid;
	}
	
	/**
	 * ワンタイムトークン文字列を取得します.<br />
	 *
	 * @create 2013/03/23
	 * @return ワンタイムトークン文字列
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public String getOneTimeToken() {
		return _oneTimeToken;
	}
	
	/**
	 * ロードイベントを取得します.<br />
	 *
	 * @create 2013/03/19
	 * @return ロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public String getOnload() {
		return _onload;
	}
	
	/**
	 * アンロードイベントを取得します.<br />
	 *
	 * @create 2013/03/19
	 * @return アンロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public String getOnunload() {
		return _onunload;
	}
	
	/**
	 * 画面IDを取得します.<br />
	 *
	 * @create 2013/03/19
	 * @return 画面ID.
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public String getViewid() {
		return _viewid;
	}

	/**
	 * idを取得します.<br />
	 * idがnullである場合、デフォルトidを返します。<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#getId()
	 * @return id id属性の値
	 * @create 2013/03/29
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public String getId() {
		return super.getId() == null ? GPBody.DEFAULT_ID : super.getId();
	}
	
	/**
	 * ワンタイムトークン文字列を設定します.<br />
	 *
	 * @create 2013/03/19
	 * @param oneTimeToken ワンタイムトークン文字列
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	protected void setOneTimeToken(String oneTimeToken) {
		_oneTimeToken = oneTimeToken;
	}

	/**
	 * ロードイベントを設定します.<br />
	 *
	 * @create 2013/03/19
	 * @param onload ロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public void setOnload(String onload) {
		_onload = onload;
	}
	
	/**
	 * アンロードイベントを設定します.<br />
	 *
	 * @create 2013/03/19
	 * @param onunload アンロードイベント
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	public void setOnunload(String onunload) {
		_onunload = onunload;
	}
	
	/**
	 * 画面IDを設定します.<br />
	 *
	 * @create 2013/03/19
	 * @param viewid 画面ID
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	void setViewid(String viewid) {
		_viewid = viewid;
	}
}
