/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPButton;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * ボタンコントロールを表すUIコントロールです.<br />
 *
 * @create 2013/02/28
 * @author kikuchi
 * @since 3.10.0.D
 */
@TargetUIComponent(GPButton.class)
public class GPButtonTag extends GUIControlBaseTag implements GEnablableTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -8129144240737864449L;
	
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "geui-gpbutton ui-button ui-widget ui-state-default ui-corner-all";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gpbutton-disabled ui-state-disabled";
	/** Input_typeの値 */
	static final String INPUT_TYPE = "button";

	// XHTML属性
	/** value属性の値. */
	private String _value = null;

	// 拡張属性
	/** showaccesskey属性の値. */
	private String _showaccesskey = null;
	/** enabled属性の値. */
	private String _enabled = null;

	/**
	 * {@link GPButtonTag}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2013/02/28
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public GPButtonTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#createXhtmlString()
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2013/02/28
	 * @author KCCS kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		return builder.createTagString();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 *
	 * @create 2013/02/28
	 * @param component レンダリング対象UIコンポーネント
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPButton ui = (GPButton) component;
		GPButton rep = (GPButton) component.getRepository();
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
		setShowaccesskey(evaluatePlaceholder(ui.getShowaccesskey(), getShowaccesskey(),
				rep == null ? null : rep.getShowaccesskey(), ui));
		setEnabled(evaluatePlaceholder(ui.getEnabled(), getEnabled(),
				rep == null ? null : rep.getEnabled(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 *
	 * @create 2013/02/28
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("type", INPUT_TYPE);
		if (getTitle() == null && getValue() != null && isEnabled()) {
			builder.setAttribute("title", getValue());
		}
		StringBuilder valueBuilder = new StringBuilder();
		if (getValue() != null) {
			valueBuilder.append(getValue());
		}
		if (isShowaccesskey() && (getAccesskey() != null)) {
			valueBuilder.append("(");
			valueBuilder.append(getAccesskey().toUpperCase());
			valueBuilder.append(")");
		}
		if (!isEnabled()) {
			builder.setAttribute("disabled", "disabled");
		}
		builder.setAttribute("value", valueBuilder.toString());
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します.<br/>
	 *
	 * @create 2013/03/05
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * enabled属性の値を取得します.<br />
	 *
	 * @create 2013/02/28
	 * @return タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * showaccesskey属性の値を取得します.<br />
	 *
	 * @create 2013/02/28
	 * @return accesskey属性を<code>true:表示</code>/<code>false:非表示</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getShowaccesskey() {
		return _showaccesskey;
	}

	/**
	 * value属性の値を取得します.<br />
	 *
	 * @create 2013/02/28
	 * @return value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * 状態の有効 / 無効を判定します.<br />
	 *
	 * @create 2013/02/28
	 * @return <code>true</code>:有効 / <code>false</code>:無効
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}

	/**
	 * アクセスキーの表示 / 非表示を判定します.<br />
	 *
	 * @create 2013/02/28
	 * @return <code>true</code>:表示 / <code>false</code>:非表示
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public boolean isShowaccesskey() {
		return GBooleanUtils.toBoolean(_showaccesskey, true);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param enabled タグの<code>true:有効</code> / <code>false:無効</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param enabled タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * showaccesskey属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param showaccesskey accesskey属性を<code>true:表示</code>/
	 *            <code>false:非表示</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setShowaccesskey(boolean showaccesskey) {
		_showaccesskey = String.valueOf(showaccesskey);
	}

	/**
	 * showaccesskey属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param showaccesskey accesskey属性を<code>true:表示</code>/
	 *            <code>false:非表示</code>
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setShowaccesskey(String showaccesskey) {
		_showaccesskey = showaccesskey;
	}

	/**
	 * value属性の値を設定します.<br />
	 *
	 * @create 2013/02/28
	 * @param value value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setValue(String value) {
		_value = value;
	}

}
