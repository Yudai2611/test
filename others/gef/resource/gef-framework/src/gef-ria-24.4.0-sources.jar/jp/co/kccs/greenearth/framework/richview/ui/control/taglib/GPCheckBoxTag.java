/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPCheckBox;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * チェックボックスコントロールを表示するタグクラスです.<br />
 * 
 * @create 2013/03/16
 * @author KCCS H.nishimura
 * @since 3.10.0.D
 */
@TargetUIComponent(GPCheckBox.class)
public class GPCheckBoxTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4747880887631455997L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gpcheckbox";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gpcheckbox-disabled ui-state-disabled";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-gpcheckbox-readonly";
	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gpcheckbox";
	/** Input_typeの値 */
	static final String INPUT_TYPE = "checkbox";

	// XHTML属性
	/** チェックの状態. */
	private String _checked;
	// 拡張属性
	/** 読み取り専用にするかの指定. */
	private String _readonly;

	/**
	 * {@link GPCheckBoxTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public GPCheckBoxTag() {
	}

	/**
	 * XHTML文字列を生成します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#createXhtmlString()
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public String createXhtmlString() throws JspException {
		StringBuilder builder = new StringBuilder();
		GTagBuilder chkBuilder = new GTagBuilder("input");
		decorateAttribute(chkBuilder);
		builder.append(chkBuilder.createTagString());
		if (isEnabled()) {
			builder.append(createHiddenTagString());
			if (!isReadonly()) {
				bindScript("click", new GJavaScriptBuilder());
			}
		}
		return builder.toString();
	}

	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br/>
	 * 対象の要素とは{@link GScriptBufferedWriterTag}を実装しているカスタムタグのことを示します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#bindMainScript(java.lang.String, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder)
	 * @param event イベント
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @param bindScriptBuilder 関連付け先のスクリプトバッファ
	 * @throws JspException 関連付けに失敗したとき
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder) throws JspException {
		scriptBuilder.append("$.geui.val('");
		scriptBuilder.append(getFullId());
		scriptBuilder.append("', $.geui.val('");
		scriptBuilder.append(getFullId());
		scriptBuilder.append("'));");
		super.bindMainScript(event, scriptBuilder, bindScriptBuilder);
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPCheckBox ui = (GPCheckBox) component;
		GPCheckBox rep = (GPCheckBox) component.getRepository();
		setChecked(evaluatePlaceholder(ui.getChecked(), getChecked(),
				rep == null ? null : rep.getChecked(), ui));
		setReadonly(evaluatePlaceholder(ui.getReadonly(), getReadonly(),
				rep == null ? null : rep.getReadonly(), ui));
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @return checked属性の値
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getChecked() {
		return _checked;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @return readonly属性の値
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @return checked属性の値
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	protected String getValue() {
		return isChecked() ? "1" : "0";
	}

	/**
	 * チェック済み / 未チェックを判定します.<br/>
	 * 
	 * @return <code>true</code>：チェック状態 / <code>false</code>：未チェック状態
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public boolean isChecked() {
		return GBooleanUtils.toBoolean(_checked, false);
	}

	/**
	 * 状態の読み込み専用 / 書き込み可能を判定します.<br>
	 * 
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @param checked checked属性の値
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setChecked(boolean checked) {
		_checked = String.valueOf(checked);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @param checked checked属性の値
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setChecked(String checked) {
		_checked = checked;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("type", INPUT_TYPE);
		if (isChecked()) {
			builder.setAttribute("checked", "checked");
		}
		if (isReadonly()) {
			builder.setAttribute("disabled", "disabled");
		}
		builder.removeAttribute("name");
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
	}

	/**
	 * タグのスタイルクラスを装飾します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(READONLY_STYLECLASS, isReadonly());
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}
}