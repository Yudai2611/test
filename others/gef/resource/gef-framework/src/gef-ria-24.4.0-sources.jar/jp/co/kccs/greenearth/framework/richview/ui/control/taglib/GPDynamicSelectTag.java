/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.control.GPDynamicSelect;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPOption;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPOptionGroup;
import jp.co.kccs.greenearth.framework.richview.ui.control.GSelectOption;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * セレクトコントロールと複数のオプションアイテムを表示するタグクラスです.<br>
 * 
 * 【概要】<br>
 * XHTMLのselect要素とoption要素に該当し、{@link GDynamicSelect}と、{@link GDynamicSelect}
 * が保持している{@link GPOption}をレンダリングします。 拡張ポイントにて、{@link GPOption}を生成し、
 * {@link GDynamicSelect}に追加することによってセレクトコントロールの選択項目を作成します。 {@link GSelectTag}
 * のように、JSP内で{@link GPOptionTag}を内包させてもXHTMLのoption要素は出力されません。<br>
 * 
 * @create 2011/06/01
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPDynamicSelect.class)
public class GPDynamicSelectTag extends GPSelectTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6104070368552373406L;

	/**
	 * {@link GPDynamicSelectTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPDynamicSelectTag() {
	}

	/**
	 * 開始タグの標準処理です.<br>
	 * 親のタグからid属性の値をキーにして、{@link GDynamicSelectMenu}
	 * コントロールを取得し、そのフィールドから属性情報を読み込んでいます。<br>
	 * 読み込んだ属性からXHTML文字列を生成し、XHTMLに出力しています。<br> {@link GPOptionTag}を生成し、保持している
	 * {@link GSelectOption}の情報を読み込んでいます。
	 * 読み込んだ情報からoption要素のXHTML文字列を生成し、XHTMLに出力しています。
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/06/01
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GDynamicSelectMenu}と{@link GSelectOption}
	 *             の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		initSelectOptionIterator();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
			for (GSelectOption selectOption : getSelectOptions()) {
				if (selectOption instanceof GPOption) {
					GPOptionTag optionTag = new GPOptionTag();
					this.doOptionTag(optionTag, (GPOption) selectOption);
				} else if (selectOption instanceof GPOptionGroup) {
					GPOptionGroupTag groupTag = new GPOptionGroupTag();
					this.doOptionGroupTag(groupTag, (GPOptionGroup) selectOption);
				}
			}
			return EVAL_BODY_INCLUDE;
		} else {
			return SKIP_BODY;
		}
	}

	/**
	 * 指定された{@link GPOptionGroupTag}を実行(XHTMLを生成)し出力します.<br />
	 * 
	 * @create 2011/06/01
	 * @param groupTag {@link GPOptionGroupTag}
	 * @param group {@link GPOptionGroup}
	 * @throws JspException {@link GPDynamicSelect}と{@link GPOption}
	 *             の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void doOptionGroupTag(GPOptionGroupTag groupTag, GPOptionGroup group) throws JspException {
		groupTag.load(group);
		if (groupTag.isVisible()) {
			GTagUtils.printOut(pageContext, groupTag.createXhtmlString());
			for (GPOption option : group.getSelectOptions()) {
				GPOptionTag optionTag = new GPOptionTag();
				this.doOptionTag(optionTag, option);
			}
			GTagBuilder optiongroupTag = new GTagBuilder("optgroup");
			GTagUtils.printOut(pageContext, optiongroupTag.createEndTagString());
		}
	}

	/**
	 * 指定された{@link GPOptionTag}を実行(XHTMLを生成)し出力します.<br />
	 * 
	 * @create 2011/06/01
	 * @param optionTag {@link GPOptionTag}
	 * @param option {@link GPOption}
	 * @throws JspException {@link GDynamicSelectMenu}と{@link GPOption}
	 *             の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void doOptionTag(GPOptionTag optionTag, GPOption option) throws JspException {
		option.setSelected(getValue() != null && getValue().equals(option.getValue()));
		optionTag.load(option);
		if (optionTag.isVisible()) {
			GTagUtils.printOut(pageContext, optionTag.createXhtmlString());
		}
	}
}
