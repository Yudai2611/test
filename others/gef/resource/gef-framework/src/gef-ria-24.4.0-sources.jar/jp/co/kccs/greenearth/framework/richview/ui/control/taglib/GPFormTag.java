/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPForm;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * フォームコントロールを表示するタグクラスです.<br />
 * 
 * @create 2013/03/19
 * @author KCCS H.nishimura
 * @since 3.10.0.D
 */
@TargetUIComponent(GPForm.class)
public class GPFormTag extends GUIContainerControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 9029062998646408291L;

	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gpform";

	// XHTML属性
	/** MIME タイプのリスト. */
	private String _accept;

	/** キャラクタセットのリスト. */
	private String _acceptcharset;

	/** サブミット（実行）された時の動作. */
	private String _action;

	/** エンコード形式. */
	private String _enctype;

	/** サーバーにデータを送る形式. */
	private String _method;

	/** 表示ターゲット. */
	private String _target;

	// イベント
	/** リセットイベント. */
	private String _onreset;

	/** サブミットイベント. */
	private String _onsubmit;

	// 拡張属性
	/** オートコンプリート機能の有無. */
	private String _autocomplete;

	/** フォーカス対象のオブジェクトID. */
	private String _focus;

	/**
	 * {@link GPFormTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/19
	 * @author H.nishimura
	 * @since 3.10.0.D
	 */
	public GPFormTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag#load(
	 * jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPForm ui = (GPForm) component;
		GPForm rep = (GPForm) component.getRepository();
		setAccept(evaluatePlaceholder(ui.getAccept(), getAccept(),
				rep == null ? null : rep.getAccept(), ui));
		setAcceptCharset(evaluatePlaceholder(ui.getAcceptCharset(), getAcceptCharset(),
				rep == null ? null : rep.getAcceptCharset(), ui));
		setAction(evaluatePlaceholder(ui.getAction(), getAction(),
				rep == null ? null : rep.getAction(), ui));
		setAutocomplete(evaluatePlaceholder(ui.getAutocomplete(), getAutocomplete(),
				rep == null ? null : rep.getAutocomplete(), ui));
		setEnctype(evaluatePlaceholder(ui.getEnctype(), getEnctype(),
				rep == null ? null : rep.getEnctype(), ui));
		setMethod(evaluatePlaceholder(ui.getMethod(), getMethod(),
				rep == null ? null : rep.getMethod(), ui));
		setTarget(evaluatePlaceholder(ui.getTarget(), getTarget(),
				rep == null ? null : rep.getTarget(), ui));
		setOnreset(evaluatePlaceholder(ui.getOnreset(), getOnreset(),
				rep == null ? null : rep.getOnreset(), ui));
		setOnsubmit(evaluatePlaceholder(ui.getOnsubmit(), getOnsubmit(),
				rep == null ? null : rep.getOnsubmit(), ui));
		setFocus(evaluatePlaceholder(ui.getFocus(), getFocus(),
				rep == null ? null : rep.getFocus(), ui));
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#createXhtmlString()
	 * @return XHTML文字列
	 * @create 2013/03/25
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public String createXhtmlString() {
		StringBuilder builder = new StringBuilder();
		GTagBuilder formTag = new GTagBuilder("form");
		decorateAttribute(formTag);
		builder.append(formTag.createStartTagString());
		builder.append(GStringUtils.nullToBlank(createMenuString()));
		return builder.toString();
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @create 2013/03/25
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("accept", getAccept());
		builder.setAttribute("accept-charset", getAcceptCharset());
		if (getAction() != null) {
			builder.setAttribute("action", getAction());
		}
		builder.setAttribute("autocomplete", getAutocomplete());
		builder.setAttribute("enctype", getEnctype());
		builder.setAttribute("method", getMethod());
		builder.setAttribute("target", getTarget());
	}
	
	/**
	 * 指定されたタグにこのタグのイベントハンドラ属性を追加します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateEventAttribute(
	 * jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateEventAttribute(GTagBuilder builder) {
		super.decorateEventAttribute(builder);
		builder.setAttribute("onreset", getOnreset());
		builder.setAttribute("onsubmit", getOnsubmit());
	}

	/**
	 * menuIdをvalueに持つtypeがhiddenのXHTML文字列を生成します.<br />
	 * 
	 * @return menuidTagBuilder {@link GTagBuilder}オブジェクト
	 * @create 2013/03/25
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	protected String createMenuString() {
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session =  manager.getSession(pageContext.getSession());
		if (!isSessionValid(session)) {
			return null;
		}
		GTagBuilder menuidTagBuilder = new GTagBuilder("input");
		menuidTagBuilder.setAttribute("type", "hidden");
		menuidTagBuilder.setAttribute("name", "menuid");
		menuidTagBuilder.setAttribute("id", getFullId() + ".menuid");
		GParameter parameter = (GParameter) GWebContext.getInstance().getRequest().getAttribute(GConstants.PARAMETER_KEY);
		String value = GStringUtils.nullToBlank(parameter.getValue("menuid"));
		menuidTagBuilder.setAttribute("value", value);
		menuidTagBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), value);
		menuidTagBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), String.valueOf(false));
		return menuidTagBuilder.createTagString();
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(
	 * jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2013/03/25
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 *  終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2013/03/25
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder formTag = new GTagBuilder("form");
			GTagUtils.printOut(pageContext, formTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * accept属性の値を取得します.<br />
	 * 
	 * @return MIMEタイプのリスト
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAccept() {
		return _accept;
	}

	/**
	 * acceptcharset属性の値を取得します.<br />
	 * 
	 * @return キャラクタセットのリスト
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAcceptCharset() {
		return _acceptcharset;
	}

	/**
	 * action属性の値を取得します.<br />
	 * 
	 * @return サブミット（実行）された時の動作
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAction() {
		return _action;
	}

	/**
	 * 過去に入力した値を候補として表示するオートコンプリート機能の有効/無効を取得します.<br>
	 * 
	 * @return <code>on</code>/<code>off</code>
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * enctype属性の値を取得します.<br />
	 * 
	 * @return エンコード形式
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getEnctype() {
		return _enctype;
	}

	/**
	 * focus属性の値を取得します.<br />
	 * 
	 * @return フォーカス対象のオブジェクトID
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getFocus() {
		return _focus;
	}

	/**
	 * method属性の値を取得します.<br />
	 * 
	 * @return GET/POST
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getMethod() {
		return _method;
	}

	/**
	 * onreset属性の値を取得します.<br />
	 * 
	 * @return イベント発生時に実行されるスクリプト
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getOnreset() {
		return _onreset;
	}

	/**
	 * onsubmit属性の値を取得します.<br />
	 * 
	 * @return イベント発生時に実行されるスクリプト
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getOnsubmit() {
		return _onsubmit;
	}

	
	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @return 表示ターゲット
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * gsessionの有効 / 無効を判定します.<br />
	 * 
	 * @param gsession {@link GSession}
	 * @return <code>true</code>:有効 / <code>false</code>:無効
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public boolean isSessionValid(GSession gsession) {
		return gsession != null && !gsession.isInvalid();
	}

	/**
	 * accept属性の値を取得します.<br />
	 * 
	 * @param accept accept属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAccept(String accept) {
		_accept = accept;
	}

	/**
	 * charset属性の値を設定します.<br />
	 * 
	 * @param charset charset属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAcceptCharset(String charset) {
		_acceptcharset = charset;
	}

	/**
	 * action属性の値を設定します.<br />
	 * 
	 * @param action action属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAction(String action) {
		_action = action;
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @param autocomplete autocomplete属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * enctype属性の値を設定します.<br />
	 * 
	 * @param enctype enctype属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setEnctype(String enctype) {
		_enctype = enctype;
	}

	/**
	 * focus属性の値を設定します.<br />
	 * 
	 * @param focus focus属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setFocus(String focus) {
		_focus = focus;
	}

	/**
	 * method属性の値を設定します.<br />
	 * 
	 * @param  method method属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setMethod(String method) {
		_method = method;
	}

	/**
	 * onreset属性の値を設定します.<br />
	 * 
	 * @param script onreset属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setOnreset(String script) {
		_onreset = script;
	}

	/**
	 * onsubmit属性の値を設定します.<br />
	 * 
	 * @param script onreset属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setOnsubmit(String script) {
		_onsubmit = script;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @param target target属性の値
	 * @create 2013/03/21
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setTarget(String target) {
		_target = target;
	}
}
