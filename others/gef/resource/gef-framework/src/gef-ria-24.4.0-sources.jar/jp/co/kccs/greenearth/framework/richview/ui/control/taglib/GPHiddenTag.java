/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPHidden;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * ブラウザ上には表示されない隠し項目を表すタグクラスです.<br/>
 * 
 * @create 2011/05/13
 * @author kobayashi
 * @since 3.9.0
 */
@TargetUIComponent(GPHidden.class)
public class GPHiddenTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5560893010836558466L;

	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gphidden";
	
	/** 入力タグタイプ */
	static final String INPUT_TYPE = "hidden";

	// XHTML属性
	/** value属性の値. */
	private String _value = null;

	/**
	 * {@link GPHiddenTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/05/13
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public GPHiddenTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/05/13
	 * @return XHTML文字列
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		return builder.createTagString();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 以下の属性を読み込みます。<br>
	 * ・value<br>
	 * 
	 * @create 2011/05/13
	 * @param component レンダリング対象UIコンポーネント
	 * @author kobayashi
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPHidden ui = (GPHidden) component;
		GPHidden rep = (GPHidden) component.getRepository();
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br/>
	 * 
	 * @create 2011/05/13
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author kobayashi
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("type", INPUT_TYPE);
		if (getValue() != null) {
			builder.setAttribute("value", getValue());
		}
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return value属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param value value属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
