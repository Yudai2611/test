/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.DynamicAttributes;

import jp.co.kccs.greenearth.framework.richview.ui.control.GPHtml;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * HTMLコントロールを表示するタグクラスです.<br />
 * 
 * @create 2013/03/26
 * @author KCCS H.nishimura
 * @since 3.10.0.D
 */
@TargetUIComponent(GPHtml.class)
public class GPHtmlTag extends GUIContainerControlBaseTag implements DynamicAttributes {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -682937855292669720L;
	// XHTML属性
	/** XHTML文書が属するバージョン. */
	private String _version;
	/** XHTMLデフォルト名前空間 */
	private String _xmlns = null;

	// 拡張属性
	/** 動的に指定されたHTMLの名前空間を格納. */
	private Map<String, String> _namespaceMap;

	/**
	 * {@link GPHtmlTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/26
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public GPHtmlTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2013/03/26
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPHtml ui = (GPHtml) component;
		GPHtml rep = (GPHtml) component.getRepository();
		setVersion(evaluatePlaceholder(ui.getVersion(), getVersion(),
				rep == null ? null : rep.getVersion(), ui));
		setXmlns(evaluatePlaceholder(ui.getXmlns(), getXmlns(),
				rep == null ? null : rep.getXmlns(), ui));
		_namespaceMap = ui.getNamespaceMap();
	}

	/**
	 * 終了タグの標準処理.<br>
	 * html要素の終了タグを出力します。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2013/03/26
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder htmlTag = new GTagBuilder("html");
			GTagUtils.printOut(pageContext, htmlTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * XHTML文字列を生成します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#createXhtmlString()
	 * @return XHTML文字列
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public String createXhtmlString() {
		GTagBuilder tagBuilder = new GTagBuilder("html");
		decorateAttribute(tagBuilder);
		return tagBuilder.createStartTagString();
	}

	/**
	 * タグの状態をリセット(初期化)します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#reset()
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		_namespaceMap = null;
	}

	/**
	 * 指定された{@link GTagBuilder} にこのタグの基本属性を追加します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder
	 *            属性を追記する{@link GTagBuilder}
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("version", getVersion());
		builder.setAttribute("xmlns", getXmlns());
		for (String key : getNamespaceMap().keySet()) {
			String value = getNamespaceMap().get(key);
			builder.setAttribute(key, value);
		}
	}

	/**
	 * 動的に指定されたXHTMLの属性を設定します.
	 * ※本メソッドは何も行いません。
	 * 
	 * @see jakarta.servlet.jsp.tagext.DynamicAttributes#setDynamicAttribute(java.lang.String, java.lang.String, java.lang.Object)
	 * @param uri 名前空間URI
	 * @param name 属性名
	 * @param value 属性値
	 * @throws JspException 例外
	 * @create 2013/03/26
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public void setDynamicAttribute(String uri, String name, Object value) throws JspException {
	}

	/**
	 * 動的に指定されたXHTMLの名前空間マップを取得します.
	 * 
	 * @return 名前空間マップ
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public Map<String, String> getNamespaceMap() {
		if (_namespaceMap == null) {
			_namespaceMap = new HashMap<String, String>();
		}
		return _namespaceMap;
	}

	/**
	 * id属性の値を取得します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#getId()
	 * @return id属性の値
	 * @create 2013/03/31
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public String getId() {
		return super.getId() == null ? GPHtml.DEFAULT_ID : super.getId();
	}

	/**
	 * version属性の値を取得します.<br>
	 * 
	 * @return version属性の値
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public String getVersion() {
		return _version;
	}

	/**
	 * xmlns属性の値を取得します.<br>
	 * 
	 * @return xmlns属性の値
	 * @create 2013/03/29
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public String getXmlns() {
		return _xmlns == null ? GPHtml.DEFAULT_XHTML_NAMESPACE : _xmlns;
	}

	/**
	 * namespaceMap属性の値を設定します.<br>
	 * 
	 * @param namespaceMap namespaceMap属性の値
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setNamespaceMap(Map<String, String> namespaceMap) {
		_namespaceMap = namespaceMap;
	}

	/**
	 * version属性の値を設定します.<br>
	 * 
	 * @param version version属性の値
	 * @create 2013/03/26
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	public void setVersion(String version) {
		_version = version;
	}
	
	/**
	 * xmlns属性の値を設定します.<br>
	 * 
	 * @param xmlns xmlns属性の値
	 * @create 2013/03/29
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public void setXmlns(String xmlns) {
		this._xmlns = xmlns;
	}
}
