/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPImg;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * イメージコントロールを表示するタグクラスです.<br>
 * 
 * @create 2011/04/22
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPImg.class)
public class GPImgTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7221153285087661479L;

	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gpimg";
	/** disabledのスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "ui-state-disabled geui-gpimg-disabled";

	// XHTML属性
	/** alt属性の値. */
	private String _alt = null;
	/** ismap属性の値. */
	private String _ismap = null;
	/** longdesc属性の値. */
	private String _longdesc = null;
	/** src属性の値. */
	private String _src = null;
	/** usemap属性の値. */
	private String _usemap = null;

	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gpimg";
	
	/**
	 * {@link GPImgTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2011/04/22
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPImgTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/04/22
	 * @return XHTML文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() {
		GTagBuilder imgTag = new GTagBuilder("img");
		decorateAttribute(imgTag);
		StringBuilder builder = new StringBuilder(imgTag.createTagString());
		if (isEnabled()) {
			builder.append(createHiddenTagString());
		}
		return builder.toString();
	}

	/**
	 * valueを取得します.<br />
	 * 
	 * @create 2020/07/31
	 * @return value
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Override
	protected String getValue() {
		return getSrc();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/04/22
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPImg ui = (GPImg) component;
		GPImg rep = (GPImg) component.getRepository();
		setAlt(evaluatePlaceholder(ui.getAlt(), getAlt(),
				rep == null ? null : rep.getAlt(), ui));
		setIsmap(evaluatePlaceholder(ui.getIsmap(), getIsmap(),
				rep == null ? null : rep.getIsmap(), ui));
		setLongdesc(evaluatePlaceholder(ui.getLongdesc(), getLongdesc(),
				rep == null ? null : rep.getLongdesc(), ui));
		setSrc(evaluatePlaceholder(ui.getSrc(), getSrc(),
				rep == null ? null : rep.getSrc(), ui));
		setUsemap(evaluatePlaceholder(ui.getUsemap(), getUsemap(),
				rep == null ? null : rep.getUsemap(), ui));
	}

	/**
	 * 指定されたタグにこのタグの基本属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/04/22
	 * @param builder 属性を追記するGTagBuilder
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.removeAttribute("name");
		builder.setAttribute("alt", getAlt());
		if (isIsmap()) {
			builder.setAttribute("ismap", "ismap");
		}
		builder.setAttribute("longdesc", getLongdesc());
		builder.setAttribute("src", getSrc());
		builder.setAttribute("usemap", getUsemap());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getSrc());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/07/07
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2014/07/16
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}

	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return alt属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getAlt() {
		return _alt;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return ismap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getIsmap() {
		return _ismap;
	}

	/**
	 * longdesc属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return longdesc属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLongdesc() {
		return _longdesc;
	}

	/**
	 * src属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return src属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getSrc() {
		return _src;
	}

	/**
	 * usemap属性の値を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return usemap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getUsemap() {
		return _usemap;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return ismap属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isIsmap() {
		return GBooleanUtils.toBoolean(_ismap, false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param alt alt属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setAlt(String alt) {
		_alt = alt;
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param ismap ismap属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setIsmap(boolean ismap) {
		_ismap = String.valueOf(ismap);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param ismap ismap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setIsmap(String ismap) {
		_ismap = ismap;
	}

	/**
	 * longdesc属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param longdesc longdesc属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLongdesc(String longdesc) {
		_longdesc = longdesc;
	}

	/**
	 * src属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param src src属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSrc(String src) {
		_src = src;
	}

	/**
	 * usemap属性の値を設定します.<br />
	 * 
	 * @create 2011/04/22
	 * @param usemap usemap属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setUsemap(String usemap) {
		_usemap = usemap;
	}
}
