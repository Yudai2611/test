/*
 * Copyright 2014-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPIncludeView;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTagUtils;
import jp.co.kccs.greenearth.framework.view.GJspUtils;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GViewFactory;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * ビューを表現するタグクラスです.<br/>
 * 
 * @create 2014/02/20
 * @author KCCS KCCS yamashita
 * @since 3.13.0
 */
@TargetUIComponent(GPIncludeView.class)
public class GPIncludeViewTag extends GPViewTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3919383118368490256L;

	/**
	 * {@link GPIncludeViewTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2014/02/20
	 * @auther KCCS yamashita
	 * @since 3.13.0
	 */
	public GPIncludeViewTag() {
	}

	/**
	 * タグに関連付けられたビューを取得します.
	 * 
	 * @param request
	 * @return {@link GViewInterface}インスタンス
	 * @throws GViewException
	 * @create 2014/02/21
	 * @author KCCS yamashita
	 * @since 3.13.0
	 */
	@Override
	protected GViewInterface getView(HttpServletRequest request) throws GViewException {
		GViewInterface parent = GViewFactory.getView(request.getServletPath(), request);
		return (GViewInterface) parent.findControl(getId());
	}
	
	/**
	 * このタグが所属するJSPのパスを取得します.<br>
	 * このビューが基底のJSPなら{@link HttpServletRequest#getServletPath()}で取得されるパスを、
	 * このビューが別のJSPにインクルードされたJSPなら<code>request</code>に積まれている
	 * インクルードJSPのパスを取り出し返します。
	 *
	 * @create 2020/09/04
	 * @param request HTTPリクエスト
	 * @return JSPパス
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Deprecated
	protected String getServletPath(HttpServletRequest request) {
		return (String) request.getAttribute(GJspUtils.INCLUDE_PATH_KEY);
	}

	/**
	 * 対象となる要素のタグ終了時点で、要素にバインドされたスクリプトを一括して出力します.<br />
	 * 
	 * @create 2020/09/04
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Override
	public void writeScript() throws JspException {
		String script = GScriptBufferedWriterTagUtils.createScript(_parts, _elements);
		if (GStringUtils.isEmpty(script)) {
			return;
		}
		pageContext.getRequest().setAttribute(INCLUDE_SCRIPT_BUFFER_KEY, script);
	}
}
