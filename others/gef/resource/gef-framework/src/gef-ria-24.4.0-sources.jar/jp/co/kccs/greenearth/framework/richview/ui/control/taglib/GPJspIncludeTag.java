/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.Locale;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPJspInclude;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTag;
import jp.co.kccs.greenearth.framework.view.GJspUtils;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;


/**
 * 指定したページを表示するインクルードのタグクラスです.<br>
 *  * 
 * @create 2014/02/20
 * @author yamashita
 * @since 3.13.0
 */
@TargetUIComponent(GPJspInclude.class)
public class GPJspIncludeTag extends GUIContainerControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -1074036257783368711L;

	/** スクリプトバッファーキー */
	private static final String INCLUDE_SCRIPT_BUFFER_KEY = "geframe.richview.Include.ScriptBuffer.Key";

	// 拡張属性
	/** ページの出力バッファをフラッシュするかどうかを指定します. */
	private String _flush;
	/** インクルードするファイルのパスを指定します. */
	private String _page;

	@Override
	public String createXhtmlString() throws JspException {
		return null;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 出力領域となるXHTMLのdiv要素をを出力し、インクルード対象のファイルのインクルードを行います。
	 * 
	 * @create 2014/02/20
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.13.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			include();
		}
		return SKIP_BODY;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doEndTag()
	 * @create 2014/02/27
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.13.0
	 */
	@Override
	public int doEndTag() throws JspException {
		String script = (String) pageContext.getRequest().getAttribute(INCLUDE_SCRIPT_BUFFER_KEY);
		if (!GStringUtils.isEmpty(script)) {
			Tag tag = findAncestorWithClass(this, GScriptBufferedWriterTag.class);
			if (tag != null) {
				GScriptBufferedWriterTag bufferTag = (GScriptBufferedWriterTag) tag;
				bufferTag.appendElement(script);
			}
		}
		pageContext.getRequest().removeAttribute(INCLUDE_SCRIPT_BUFFER_KEY);
		return super.doEndTag();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2014/02/27
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.13.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPJspInclude ui = (GPJspInclude) component;
		GPJspInclude rep = (GPJspInclude) component.getRepository();
		setPage(evaluatePlaceholder(ui.getPage(), getPage(),
				rep == null ? null : rep.getPage(), ui));
		setFlush(evaluatePlaceholder(ui.getFlush(), getFlush(),
				rep == null ? null : rep.getFlush(), ui));
	}

	/**
	 * インクルード対象のファイルのインクルードを行います.<br />
	 * 
	 * @create 2014/02/27
	 * @author yamashita
	 * @throws JspException インクルードに失敗した場合
	 * @since 3.13.0
	 */
	protected void include() throws JspException {
		Locale locale = GWebContext.getInstance().getLocale();
		GJspUtils.jspInclude(pageContext, getPage(), locale, isFlush());
	}

	/**
	 * ページの出力バッファをフラッシュするかどうかを取得します.<br />
	 * 
	 * @create 2014/02/20
	 * @return <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.13.0
	 */
	public String getFlush() {
		return _flush;
	}

	/**
	 * インクルードするファイルのパスを取得します.<br />
	 * 
	 * @create 2014/02//20
	 * @return インクルードするファイルのパス
	 * @author yamashita
	 * @since 3.13.0
	 */
	public String getPage() {
		return _page;
	}

	/**
	 * ページの出力バッファをフラッシュするかどうかを取得します.<br />
	 * 
	 * @create 2014/02/20
	 * @return <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.13.0
	 */
	public boolean isFlush() {
		return GBooleanUtils.toBoolean(getFlush(), false);
	}

	/**
	 * ページの出力バッファをフラッシュするかどうかを設定します.<br>
	 * 
	 * @create 2014/02/20
	 * @param flush <code>true:ページの出力バッファをフラッシュする</code>/
	 *            <code>false:ページの出力バッファをフラッシュしない</code>
	 * @author yamashita
	 * @since 3.13.0
	 */
	public void setFlush(boolean flush) {
		_flush = String.valueOf(flush);
	}

	/**
	 * ページの出力バッファをフラッシュするかどうかを設定します.<br>
	 * 
	 * @create 2014/02/20
	 * @param flush <code>true:ページ出力バッファをフラッシュする</code>/
	 *            <code>false:ページ出力バッファをフラッシュしない</code>
	 * @author yamashita
	 * @since 3.13.0
	 */
	public void setFlush(String flush) {
		_flush = flush;
	}

	/**
	 * インクルードするファイルのパスを設定します.<br />
	 * 
	 * @create 2014/02/20
	 * @param page インクルードするファイルのパス
	 * @author yamashita
	 * @since 3.13.0
	 */
	public void setPage(String page) {
		_page = page;
	}
}
