/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.Date;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPHidden;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLabel;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * ラベルコントロールを表すタグクラスです.<br/>
 * 
 * @create 2011/08/19
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GPLabel.class)
public class GPLabelTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5205397118213053165L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gplabel";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gplabel-disabled ui-state-disabled";
	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gplabel";
	/** multilineスタイルシートのクラス名.(multiline="true") */
	static final String MULTILINE_STYLECLASS = "geui-gplabel-multiline";

	// XHTML属性
	/** value属性の値. */
	private Object _object = null;
	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;
	/** multiline属性の値. */
	private String _multiline = null;


	/**
	 * {@link GPLabelTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/08/19
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPLabelTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/08/19
	 * @return XHTML文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String createXhtmlString() {
		StringBuilder xhtmlString = new StringBuilder();
		GTagBuilder spanTag = new GTagBuilder("span");
		decorateAttribute(spanTag);
		xhtmlString.append(spanTag.createStartTagString());
		if (getValue() != null) {
			xhtmlString.append(GTagUtils.escapeTextContent(getValue()));
		}
		xhtmlString.append(spanTag.createEndTagString());
		if (isEnabled()) {
			xhtmlString.append(createHiddenTagXhtmlString());
		}
		return xhtmlString.toString();
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br>
	 * 
	 * 親のタグからid属性の値をキーにして、{@link GPHidden}コントロールを取得し、そのフィールドから属性情報を読み込みます。<br>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2011/08/19
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、スキップします
	 * @throws JspException {@link GPHidden}の取得・ロード、タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
			printScript();
		}
		return SKIP_BODY;
	}

	
	protected void printScript() throws JspException {
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		scriptBuilder.append("$(function(){$.geui.handler.get('");
		scriptBuilder.append(XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
		GJSONObject options = new GJSONObject();
		options.put("isMultiline", isMultiline());
		scriptBuilder.append("').init(??, ??);});", getFullId(), options.encode());
		bindScript(scriptBuilder.toString());
	}

	/**
	 * スクリプト出力可能かどうかを判定します.<br/>
	 * 常にスクリプト出力する必要があるため、trueを返します。<br/>
	 * 
	 * @return true: 出力可能
	 * @create 2014/09/23
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	protected boolean isWritable() throws JspException {
		return true;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @create 2011/08/19
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPLabel ui = (GPLabel) component;
		GPLabel rep = (GPLabel) component.getRepository();
		setFormat(evaluatePlaceholder(ui.getFormat(), getFormat(),
				rep == null ? null : rep.getFormat(), ui));
		setLocale(evaluatePlaceholder(ui.getLocale(), getLocale(),
				rep == null ? null : rep.getLocale(), ui));
		setMultiline(evaluatePlaceholder(ui.getMultiline(), getMultiline(),
				rep == null ? null : rep.getMultiline(), ui));
		setObject(evaluatePlaceholder(ui.getObject(), getObject(),
				rep == null ? null : rep.getObject(), ui));
	}
	

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/08/19
	 * @return XHTML文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected String createHiddenTagXhtmlString() {
		GTagBuilder inputTag = createHiddenTagBuilder();
		inputTag.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), "false");
		inputTag.setAttribute("xml:lang", getLang());
		if (getValue() == null) {
			inputTag.removeAttribute("value");
		}
		return inputTag.createTagString();
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br/>
	 * 
	 * @create 2011/08/19
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY),
			XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.removeAttribute("name");
		builder.removeAttribute("onblur");
		builder.removeAttribute("onchange");
		builder.removeAttribute("onfocus");
		builder.removeAttribute("onselect");
		builder.removeAttribute("accesskey");
		builder.removeAttribute("tabindex");
		if (!isEnabled()) {
			builder.removeAttribute("onclick");
			builder.removeAttribute("ondblclick");
			builder.removeAttribute("onkeydown");
			builder.removeAttribute("onkeypress");
			builder.removeAttribute("onkeyup");
			builder.removeAttribute("onmousedown");
			builder.removeAttribute("onmousemove");
			builder.removeAttribute("onmouseout");
			builder.removeAttribute("onmouseover");
			builder.removeAttribute("onmouseup");
		}
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します.<br/>
	 * 
	 * @create 2011/08/19
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(MULTILINE_STYLECLASS, isMultiline());
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		Object object = getObject();
		String value = object == null ? null : object.toString();
		if (object instanceof Date) {
			value = GUIUtils.formatDateToString((Date) object, _format, GCoreUtils.getLocale(_locale));
		} else if (object instanceof Number) {
			value = GUIUtils.formatNumberToString((Number) object, _format, GCoreUtils.getLocale(_locale));
		}
		return value;
	}

	/**
	 * multiline属性の値を取得します.<br />
	 * 
	 * @create 2013/06/18
	 * @return multiline属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getMultiline() {
		return _multiline;
	}
	
	/**
	 * value属性の値をObject型で取得します.<br />
	 * 
	 * @create 2014/05/30
	 * @return value属性の値
	 * @author yoshida
	 * @since 3.14.0
	 */
	public Object getObject() {
		return _object;
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param format 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param locale ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		setObject(value);
	}

	/**
	 * multiline属性の値を設定します.<br />
	 * 
	 * @create 2013/06/18
	 * @param multiline <code>true:改行を有効にする</code>/<code>false:改行を無効にする</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setMultiline(boolean multiline) {
		_multiline = String.valueOf(multiline);
	}

	/**
	 * multiline属性の値を設定します.<br />
	 * 
	 * @create 2013/06/18
	 * @param multiline <code>true:改行を有効にする</code>/<code>false:改行を無効にする</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setMultiline(String multiline) {
		_multiline = multiline;
	}
	
	/**
	 * value属性の値をObject型で設定します.<br />
	 * 
	 * @create 2014/05/30
	 * @param object
	 * @author yoshida
	 * @since 3.14.0
	 */
	public void setObject(Object object) {
		_object = object;
	}
	
	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2013/06/11
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}

	/**
	 * multiline属性の値を取得します.<br />
	 * 
	 * @create 2013/06/18
	 * @return <code>true:改行を有効にする</code>/<code>false:改行を無効にする</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public boolean isMultiline() {
		return GBooleanUtils.toBoolean(getMultiline(), false);
	}
}
