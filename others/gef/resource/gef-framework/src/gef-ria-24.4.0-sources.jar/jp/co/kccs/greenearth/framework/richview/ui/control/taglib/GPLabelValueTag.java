/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.control.GPLabelValue;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * ラベルコントロールを表示するタグクラスです.<br>
 * 
 * @create 2011/04/21
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPLabelValue.class)
public class GPLabelValueTag extends GUIControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3713521457255478932L;

	// 拡張属性
	/** value属性の値. */
	private String _value;

	/**
	 * {@link GPLabelValueTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2010/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPLabelValueTag() {
	}

	/**
	 * XHTML文字列を生成します.<br>
	 * 
	 * @return 表示する値
	 * @create 2010/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String createXhtmlString() {
		return getValue();
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親のタグからid属性の値をキーにして、{@link GPLabelValue}コントロールを取得し、そのフィールドから属性情報を読み込んでいます。<br>
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GViewInterface}の取得・ロード、タグの書き込みに失敗した場合
	 * @create 2010/04/21
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			String htmlString = createXhtmlString();
			if (htmlString != null) {
				GTagUtils.printOut(pageContext, GTagUtils.escapeTextContent(htmlString));
			}
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2010/04/21
	 * @param component UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPLabelValue ui = (GPLabelValue) component;
		GPLabelValue rep = (GPLabelValue) component.getRepository();
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2010/04/21
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * 表示する値を設定します.<br />
	 * 
	 * @create 2010/04/21
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
