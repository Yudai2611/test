/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyle;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLinkedImg;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag;
/**
 * リンクイメージコントロールを表すUIコントロールです.<br />
 * 
 * @create 2013/06/06
 * @author KCCS H.nishimura
 * @since 3.12.0
 */
@TargetUIComponent(GPLinkedImg.class)
public class GPLinkedImgTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5764590706735525326L;
	/** a要素デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gplinkedimg";
	/** span要素disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "ui-state-disabled geui-gplinkedimg-disabled";
	/** img要素のデフォルトのスタイルシートのクラス名.(enable="true") */
	static final String IMG_DEFAULT_STYLECLASS = "geui-gplinkedimg-img";

	// XHTML属性
	/** alt属性の値. */
	private String _alt = null;
	/** ismap属性の値. */
	private String _ismap = null;
	/** longdesc属性の値. */
	private String _longdesc = null;
	/** src属性の値. */
	private String _src = null;
	/** usemap属性の値. */
	private String _usemap = null;
	/** charset属性の値. */
	private String _charset = null;
	/** coords属性の値. */
	private String _coords = null;
	/** href属性の値. */
	private String _href = null;
	/** hreflang属性の値. */
	private String _hreflang = null;
	/** rel属性の値. */
	private String _rel = null;
	/** rev属性の値. */
	private String _rev = null;
	/** shape属性の値. */
	private String _shape = null;
	/** type属性の値. */
	private String _type = null;
	/** target属性の値. */
	private String _target = null;
	/** oncontextmenu属性の値 */
	private String _oncontextmenu = null;
	// 拡張属性
	/** 画像のスタイル. */
	private GStyle _imgstyle;
	/** 画像のスタイルシートのクラス. */
	private GStyleClass _imgstyleclass;

	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gplinkedimg";
	
	/**
	 * {@link GPLinkedImgTag}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public GPLinkedImgTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIContainerControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPLinkedImg ui = (GPLinkedImg) component;
		GPLinkedImg rep = (GPLinkedImg) component.getRepository();
		setAlt(evaluatePlaceholder(ui.getAlt(), getAlt(),
				rep == null ? null : rep.getAlt(), ui));
		setIsmap(evaluatePlaceholder(ui.getIsmap(), getIsmap(), 
				rep == null ? null : rep.getIsmap(), ui));
		setLongdesc(evaluatePlaceholder(ui.getLongdesc(), getLongdesc(),
				rep == null ? null : rep.getLongdesc(), ui));
		setSrc(evaluatePlaceholder(ui.getSrc(), getSrc(), 
				rep == null ? null : rep.getSrc(), ui));
		setUsemap(evaluatePlaceholder(ui.getUsemap(), getUsemap(), 
				rep == null ? null : rep.getUsemap(), ui));
		setCharset(evaluatePlaceholder(ui.getCharset(), getCharset(), 
				rep == null ? null : rep.getCharset(), ui));
		setCoords(evaluatePlaceholder(ui.getCoords(), getCoords(), 
				rep == null ? null : rep.getCoords(), ui));
		setHref(evaluatePlaceholder(ui.getHref(), getHref(), 
				rep == null ? null : rep.getHref(), ui));
		setHreflang(evaluatePlaceholder(ui.getHreflang(), getHreflang(),
				rep == null ? null : rep.getHreflang(), ui));
		setRel(evaluatePlaceholder(ui.getRel(), getRel(), 
				rep == null ? null : rep.getRel(), ui));
		setRev(evaluatePlaceholder(ui.getRev(), getRev(), 
				rep == null ? null : rep.getRev(), ui));
		setShape(evaluatePlaceholder(ui.getShape(), getShape(), 
				rep == null ? null : rep.getShape(), ui));
		setType(evaluatePlaceholder(ui.getType(), getType(), 
				rep == null ? null : rep.getType(), ui));
		setTarget(evaluatePlaceholder(ui.getTarget(), getTarget(), 
				rep == null ? null : rep.getTarget(), ui));
		setEnabled(evaluatePlaceholder(ui.getEnabled(), getEnabled(),
				rep == null ? null : rep.getEnabled(), ui));
		setOncontextmenu(evaluatePlaceholder(ui.getOncontextmenu(), getOncontextmenu(), 
				rep == null ? null : rep.getOncontextmenu(), ui));
		setImgstyle(super.evaluatePlaceholder(super.getFieldValueWithoutEL(ui.getDecodeImgstyle(),
				getDecodeImgstyle(), rep == null ? null : rep.getDecodeImgstyle()), ui));
		setImgstyleclass(super.evaluatePlaceholder(super.getFieldValueWithoutEL(ui.getDecodeImgstyleclass(),
				getDecodeImgstyleclass(), rep == null ? null : rep.getDecodeImgstyleclass()), ui));
	}
	
	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see GUIComponentTag#reset()
	 * @create 2016/3/11
	 * @author Kobayashi
	 * @since 3.18.0
	 */
	@Override
	public void reset() {
		super.reset();
		_imgstyle = null;
		_imgstyleclass = null;
	}

	/**
	 * XHTML文字列を生成します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#createXhtmlString()
	 * @return
	 * @throws JspException
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		StringBuilder builder = new StringBuilder();
		if(isEnabled()) {
			builder.append(createATagXhtmlString());
			builder.append(createHiddenTagString());
		} else {
			builder.append(createSpanTagXhtmlString());
		}
		return builder.toString();
	}
	
	/**
	 * valueを取得します.<br />
	 * 
	 * @create 2020/07/31
	 * @return value
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Override
	protected String getValue() {
		return getSrc();
	}

	/**
	 * img要素のXHTML文字列を生成します.
	 * 
	 * @return
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	protected String createImgTagXhtmlString() {
		GTagBuilder builder = new GTagBuilder("img");
		decorateImgTagAttribute(builder);
		return builder.createTagString();
	}
	
	/**
	 * span要素のXHTML文字列を生成します.
	 * 
	 * @return
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	protected String createSpanTagXhtmlString() {
		GTagBuilder builder = new GTagBuilder("span");
		decorateSpanTagAttribute(builder);
		return builder.createStartTagString() + createImgTagXhtmlString() + builder.createEndTagString();
	}
	
	/**
	 * a要素のXHTML文字列を生成します.
	 * 
	 * @return
	 * @throws JspException
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	protected String createATagXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("a");
		decorateATagAttribute(builder);
		return builder.createStartTagString() + createImgTagXhtmlString() + builder.createEndTagString();
	}

	/**
	 * 指定されたタグビルダー(Anchor)にタグ属性を追加します. <br>
	 * 
	 * @param anchorBuilder
	 * @throws JspException
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	protected void decorateATagAttribute(GTagBuilder anchorBuilder) throws JspException {
		super.decorateAttribute(anchorBuilder);
		anchorBuilder.setAttribute("charset", getCharset());
		anchorBuilder.setAttribute("coords", getCoords());
		anchorBuilder.setAttribute("hreflang", getHreflang());
		anchorBuilder.setAttribute("oncontextmenu", getOncontextmenu());
		anchorBuilder.setAttribute("rel", getRel());
		anchorBuilder.setAttribute("rev", getRev());
		anchorBuilder.setAttribute("shape", getShape());
		anchorBuilder.setAttribute("type", getType());
		if (getHref() == null) {
			anchorBuilder.setAttribute("href", "javascript:void(0);");
		} else {
			anchorBuilder.setAttribute("href", getHref());
			anchorBuilder.setAttribute("target", getTarget());
		}
		anchorBuilder.removeAttribute("name");
		anchorBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getSrc());
		anchorBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);

		bindPreventScript();
	}

	/**
	 * スクリプトを生成します.<br />
	 * clickイベントに対してはShift/Ctrlクリックを抑止するスクリプトを、contextmenuイベントに対しては右ｸﾘｯｸﾒﾆｭｰ表示を抑止するスクリプトを生成します。<br />
	 * 
	 * @create 2014/08/28
	 * @throws JspException 関連付けに失敗したとき
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	private void bindPreventScript() throws JspException {
		if (getHref() == null) {
			if (getOncontextmenu() == null) {
				bindScript("contextmenu", new GJavaScriptBuilder());
			}
			if (getOnclick() == null) {
				bindScript("click", new GJavaScriptBuilder());
			}
		}
	}

	/**
	 * 指定されたタグビルダー(span)にタグ属性を追加します. <br>
	 * 
	 * @param spanBuilder
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	protected void decorateSpanTagAttribute(GTagBuilder spanBuilder) {
		if (getId() != null) {
			spanBuilder.setAttribute("id", getFullId());
		}
		spanBuilder.setAttribute("dir", getDir());
		spanBuilder.setAttribute("title", getTitle());
		spanBuilder.setAttribute("xml:lang", getLang());
		spanBuilder.setAttribute("xml:space", getSpace());
		decorateStyleAttribute(spanBuilder); // style属性
		decorateStyleClassAttribute(spanBuilder); // class属性
		spanBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getSrc());
		spanBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
		spanBuilder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), String.valueOf(isClear()));
	}
	
	/**
	 * 指定されたタグビルダー(img)にタグ属性を追加します. <br>
	 * 
	 * @param imgBuilder
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	protected void decorateImgTagAttribute(GTagBuilder imgBuilder) {
		imgBuilder.setAttribute("alt", getAlt());
		if (isIsmap()) {
			imgBuilder.setAttribute("ismap", "ismap");
		}
		imgBuilder.setAttribute("longdesc", getLongdesc());
		imgBuilder.setAttribute("src", getSrc());
		imgBuilder.setAttribute("usemap", getUsemap());
		imgBuilder.setAttribute("class", getImgStyleclassName());
		imgBuilder.setAttribute("style", getImgstyle());
	}

	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#bindMainScript(java.lang.String, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder)
	 * @param event
	 * @param scriptBuilder
	 * @param bindScriptBuilder
	 * @throws JspException
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	@Override
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder)
		throws JspException {
		if ("click".equals(event) && getHref() == null) {
			scriptBuilder.prepend(GAnchorUtils.createPreventClickEventScript(null));
		}
		if ("contextmenu".equals(event) && getHref() == null) {
			scriptBuilder.append(GAnchorUtils.createPreventContextMenuEventScript(null));
		}
		super.bindMainScript(event, scriptBuilder, bindScriptBuilder);
	}

	/**
	 * 指定されたタグビルダーにaまたはspanタグのスタイルクラス属性を追加します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder
	 * @create 2013/06/13
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2014/07/22
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}

	/**
	 * 指定されたタグビルダーにimgタグのスタイルクラス属性を追加します.<br/>
	 *  
	 * @return img用のスタイルシートのクラス
	 * @create 2013/06/13
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	protected String getImgStyleclassName() {
		GStyleClass styleclass = getDecodeImgstyleclass();
		styleclass.add(IMG_DEFAULT_STYLECLASS);
		return getImgstyleclass();
	}
	
	/**
	 * alt属性の値を取得します.<br />
	 * 
	 * @return alt属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getAlt() {
		return _alt;
	}

	/**
	 * charset属性の値を取得します.<br />
	 * 
	 * @return charset属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getCharset() {
		return _charset;
	}

	/**
	 * coords属性の値を取得します.<br />
	 * 
	 * @return coords属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getCoords() {
		return _coords;
	}

	/**
	 * imgstyle属性の値を取得します.<br />
	 * 
	 * @return imgstyle属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public GStyle getDecodeImgstyle() {
		if (_imgstyle == null) {
			_imgstyle = new GStyle();
		}
		return _imgstyle;
	}

	/**
	 * imgstyleclass属性の値を取得します.<br />
	 * 
	 * @return imgstyleclass属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public GStyleClass getDecodeImgstyleclass() {
		if (_imgstyleclass == null) {
			_imgstyleclass = new GStyleClass();
		}
		return _imgstyleclass;
	}

	/**
	 * href属性の値を取得します.<br />
	 * 
	 * @return href属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getHref() {
		return _href;
	}

	/**
	 * hreflang属性の値を取得します.<br />
	 * 
	 * @return hreflang属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getHreflang() {
		return _hreflang;
	}

	/**
	 * imgstyle属性の値を取得します.<br />
	 * 
	 * @return imgstyle属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getImgstyle() {
		if (_imgstyle != null && !_imgstyle.isEmpty()) {
			return _imgstyle.encode();
		}
		return null;
	}

	/**
	 * imgstyleclass属性の値を取得します.<br />
	 * 
	 * @return imgstyleclass属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getImgstyleclass() {
		if (_imgstyleclass != null && !_imgstyleclass.isEmpty()) {
			return _imgstyleclass.encode();
		}
		return null;
	}

	/**
	 * ismap属性の値を取得します.<br />
	 * 
	 * @return ismap属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getIsmap() {
		return _ismap;
	}

	/**
	 * longdesc属性の値を取得します.<br />
	 * 
	 * @return longdesc属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getLongdesc() {
		return _longdesc;
	}

	/**
	 * oncontextmenu属性の値を取得します.<br />
	 * 
	 * @return oncontextmenu
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getOncontextmenu() {
		return _oncontextmenu;
	}

	/**
	 * rel属性の値を取得します.<br />
	 * 
	 * @return rel属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getRel() {
		return _rel;
	}

	/**
	 * rev属性の値を取得します.<br />
	 * 
	 * @return rev属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getRev() {
		return _rev;
	}

	/**
	 * shape属性の値を取得します.<br />
	 * 
	 * @return shape属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getShape() {
		return _shape;
	}

	/**
	 * src属性の値を取得します.<br />
	 * 
	 * @return src属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getSrc() {
		return _src;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @return target属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * type属性の値を取得します.<br />
	 * 
	 * @return type属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getType() {
		return _type;
	}

	/**
	 * usemap属性の値を取得します.<br />
	 * 
	 * @return usemap属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public String getUsemap() {
		return _usemap;
	}

	/**
	 * サーバサイド・クリッカブルマップであるかどうかを取得します.
	 * 
	 * @return <code>true</code>:有効 / <code>false</code>:無効
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public boolean isIsmap() {
		return GBooleanUtils.toBoolean(_ismap, false);
	}

	/**
	 * alt属性の値を設定します.<br />
	 * 
	 * @param alt alt属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setAlt(String alt) {
		_alt = alt;
	}
	
	/**
	 * charset属性の値を設定します.<br />
	 * 
	 * @param charset charset属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setCharset(String charset) {
		_charset = charset;
	}

	/**
	 * coords属性の値を設定します.<br />
	 * 
	 * @param coords coords属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setCoords(String coords) {
		_coords = coords;
	}

	/**
	 * href属性の値を設定します.<br />
	 * 
	 * @param href href属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setHref(String href) {
		_href = href;
	}

	/**
	 * hreflang属性の値を設定します.<br />
	 * 
	 * @param hreflang hreflang属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setHreflang(String hreflang) {
		_hreflang = hreflang;
	}

	/**
	 * imgstyle属性の値を設定します.<br />
	 * 
	 * @param imgstyle imgstyle属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyle(GStyle imgstyle) {
		_imgstyle = imgstyle;
	}

	/**
	 * imgstyle属性の値を設定します.<br />
	 * 
	 * @param imgstyle imgstyle属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyle(String imgstyle) {
		_imgstyle = imgstyle == null ? null : new GStyle(imgstyle);
	}

	/**
	 * imgstyleclass属性の値を設定します.<br />
	 * 
	 * @param imgstyleclass imgstyleclass属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyleclass(GStyleClass imgstyleclass) {
		_imgstyleclass = imgstyleclass;
	}

	/**
	 * imgstyleclass属性の値を設定します.<br />
	 * 
	 * @param imgstyleclass imgstyleclass属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setImgstyleclass(String imgstyleclass) {
		_imgstyleclass = imgstyleclass == null ? null : new GStyleClass(imgstyleclass);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @param ismap ismap属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setIsmap(boolean ismap) {
		_ismap = String.valueOf(ismap);
	}

	/**
	 * ismap属性の値を設定します.<br />
	 * 
	 * @param ismap ismap属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setIsmap(String ismap) {
		_ismap = ismap;
	}

	/**
	 * longdesc属性の値を設定します.<br />
	 * 
	 * @param longdesc longdesc属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setLongdesc(String longdesc) {
		_longdesc = longdesc;
	}

	/**
	 * oncontextmenu属性の値を設定します.<br />
	 * 
	 * @param oncontextmenu oncontextmenu属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setOncontextmenu(String oncontextmenu) {
		_oncontextmenu = oncontextmenu;
	}

	/**
	 * rel属性の値を設定します.<br />
	 * 
	 * @param rel rel属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setRel(String rel) {
		_rel = rel;
	}

	/**
	 * rev属性の値を設定します.<br />
	 * 
	 * @param rev rel属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setRev(String rev) {
		_rev = rev;
	}

	/**
	 * shape属性の値を設定します.<br />
	 * 
	 * @param shape shape属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setShape(String shape) {
		_shape = shape;
	}

	/**
	 * src属性の値を設定します.<br />
	 * 
	 * @param src src属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setSrc(String src) {
		_src = src;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @param target target属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setTarget(String target) {
		_target = target;
	}

	/**
	 * type属性の値を設定します.<br />
	 * 
	 * @param type type属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setType(String type) {
		_type = type;
	}

	/**
	 * usemap属性の値を設定します.<br />
	 * 
	 * @param usemap usemap属性の値
	 * @create 2013/06/07
	 * @author KCCS H.nishimura
	 * @since 3.12.0
	 */
	public void setUsemap(String usemap) {
		_usemap = usemap;
	}
}
