/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.Date;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLinkedLabel;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * リンクラベルコントロールを表示するタグクラスです.<br>
 * 
 * @create 2013/06/04
 * @author kikuchi
 * @since 3.12.0
 */
@TargetUIComponent(GPLinkedLabel.class)
public class GPLinkedLabelTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4517246249791085545L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS= "ui-widget geui-gplinkedlabel";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gplinkedlabel-disabled ui-state-disabled";
	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gplinkedlabel";

	// XHTML属性
	/** charset属性の値. */
	private String _charset = null;
	/** coords属性の値. */
	private String _coords = null;
	/** href属性の値. */
	private String _href = null;
	/** hreflang属性の値. */
	private String _hreflang = null;
	/** rel属性の値. */
	private String _rel = null;
	/** rev属性の値. */
	private String _rev = null;
	/** shape属性の値. */
	private String _shape = null;
	/** type属性の値. */
	private String _type = null;
	/** target属性の値. */
	private String _target = null;
	/** oncontextmenu属性の値. */
	private String _oncontextmenu = null;

	// 拡張属性
	/** value属性の値. */
	private Object _object = null;
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;
	
	/**
	 * {@link GPLinkedLabelTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/06/04
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public GPLinkedLabelTag() {
	}

	/**
	 * XHTML文字列を生成します.<br>
	 * 
	 * @create 2013/06/04
	 * @return 表示する値
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		StringBuilder xhtmlString = new StringBuilder();
		GTagBuilder builder = new GTagBuilder();
		if (getValue() != null) {
			builder.setInnerText(getValue());
		}
		if (isEnabled()) {
			builder.setName("a");
			decorateATagAttribute(builder);
			xhtmlString.append(builder.createStartEndTagString());
			xhtmlString.append(createHiddenTagXhtmlString());
		} else {
			builder.setName("span");
			decorateSpanTagAttribute(builder);
			xhtmlString.append(builder.createStartEndTagString());
		}
		return xhtmlString.toString();
	}
	
	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2013/06/06
	 * @return XHTML文字列
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected String createHiddenTagXhtmlString() {
		GTagBuilder inputTag = new GTagBuilder("input");
		inputTag.setAttribute("id", getFullId() + "_hdn");
		inputTag.setAttribute("type", "hidden");
		inputTag.setAttribute("name", getParameterKey());
		inputTag.setAttribute("xml:lang", getLang());
		inputTag.setAttribute("value", getValue());

		return inputTag.createTagString();
	}
	
	/**
	 * 指定されたタグにa要素の属性を追加します.<br />
	 * 
	 * 1.タグ情報にXHTMLに出力する属性情報を付加します。<br>
	 * 2.スーパークラスで定義された属性及び、本クラスで定義する、以下の属性 を付加します。<br>
	 * ・charset,coords,hreflang,rel,rev,shape,type,target<br>
	 * 
	 * @create 2013/06/04
	 * @param builder 属性を追記するGTagBuilder
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected void decorateATagAttribute(GTagBuilder builder) throws JspException {
		super.decorateAttribute(builder);
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), getExAttrTagValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute("charset", getCharset());
		builder.setAttribute("coords", getCoords());
		builder.setAttribute("hreflang", getHreflang());
		builder.setAttribute("oncontextmenu", getOncontextmenu());
		builder.setAttribute("rel", getRel());
		builder.setAttribute("rev", getRev());
		builder.setAttribute("shape", getShape());
		builder.setAttribute("type", getType());
		if (getTitle() == null) {
			builder.setAttribute("title", getValue());
		}
		if (getHref() == null) {
			builder.setAttribute("href", "javascript:void(0);");
		} else {
			builder.setAttribute("href", getHref());
			builder.setAttribute("target", getTarget());
		}
		builder.removeAttribute("name");
		builder.removeAttribute("disabled");
		
		bindPreventScript();
	}

	/**
	 * スクリプトを生成します.<br />
	 * clickイベントに対してはShift/Ctrlクリックを抑止するスクリプトを、contextmenuイベントに対しては右ｸﾘｯｸﾒﾆｭｰ表示を抑止するスクリプトを生成します。<br />
	 * 
	 * @create 2014/08/28
	 * @throws JspException 関連付けに失敗したとき
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	private void bindPreventScript() throws JspException {
		if (getHref() == null) {
			if (getOncontextmenu() == null) {
				bindScript("contextmenu", new GJavaScriptBuilder());
			}
			if (getOnclick() == null) {
				bindScript("click", new GJavaScriptBuilder());
			}
		}
	}

	/**
	 * 指定されたタグにspan要素の属性を追加します.<br />
	 * 
	 * 1.タグ情報にXHTMLに出力する属性情報を付加します。<br>
	 * 2.スーパークラスで定義された属性及び、本クラスで定義する、以下の属性 を付加します。<br>
	 * ・charset,coords,hreflang,rel,rev,shape,type,target<br>
	 * 
	 * @create 2013/06/04
	 * @param builder 属性を追記するGTagBuilder
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected void decorateSpanTagAttribute(GTagBuilder builder) {
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), getExAttrTagValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), String.valueOf(isClear()));
		if (getId() != null) {
			builder.setAttribute("id", getFullId());
		}
		builder.setAttribute("dir", getDir());
		builder.setAttribute("title", getTitle());
		builder.setAttribute("xml:lang", getLang());
		builder.setAttribute("xml:space", getSpace());
		builder.setAttribute("disabled", "disabled");
		decorateStyleAttribute(builder);
		decorateStyleClassAttribute(builder);
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します.<br/>
	 * 
	 * @create 2013/06/06
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(getDefaultStyleClass());
		super.toggleStyleClassAttribute(getDisabledStyleClass(), !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * XHTML拡張属性のtag属性に指定する値を取得します.<br/>
	 * ※サブクラス用にテンプレート化
	 * 
	 * @return tag属性の値
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected String getExAttrTagValue() {
		return XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE;
	}

	/**
	 * デフォルトスタイルクラスを取得します.<br/>
	 * ※サブクラス用にテンプレート化
	 * 
	 * @return デフォルトスタイルクラス
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected String getDefaultStyleClass() {
		return DEFAULT_STYLECLASS;
	}

	/**
	 * 無効状態時のスタイルクラスを取得します.<br/>
	 * ※サブクラス用にテンプレート化
	 * 
	 * @return 無効状態時のスタイルクラス
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected String getDisabledStyleClass() {
		return DISABLED_STYLECLASS;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2013/06/04
	 * @param component UIコンポーネント
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPLinkedLabel ui = (GPLinkedLabel) component;
		GPLinkedLabel rep = (GPLinkedLabel) component.getRepository();
		setCharset(evaluatePlaceholder(ui.getCharset(), getCharset(),
				rep == null ? null : rep.getCharset(), ui));
		setCoords(evaluatePlaceholder(ui.getCoords(), getCoords(),
				rep == null ? null : rep.getCoords(), ui));
		setHref(evaluatePlaceholder(ui.getHref(), getHref(),
				rep == null ? null : rep.getHref(), ui));
		setHreflang(evaluatePlaceholder(ui.getHreflang(), getHreflang(),
				rep == null ? null : rep.getHreflang(), ui));
		setLocale(evaluatePlaceholder(ui.getLocale(), getLocale(),
				rep == null ? null : rep.getLocale(), ui));
		setRel(evaluatePlaceholder(ui.getRel(), getRel(),
				rep == null ? null : rep.getRel(), ui));
		setRev(evaluatePlaceholder(ui.getRev(), getRev(),
				rep == null ? null : rep.getRev(), ui));
		setShape(evaluatePlaceholder(ui.getShape(), getShape(),
				rep == null ? null : rep.getShape(), ui));
		setType(evaluatePlaceholder(ui.getType(), getType(),
				rep == null ? null : rep.getType(), ui));
		setTarget(evaluatePlaceholder(ui.getTarget(), getTarget(),
				rep == null ? null : rep.getTarget(), ui));
		setObject(evaluatePlaceholder(ui.getObject(), getObject(),
				rep == null ? null : rep.getObject(), ui));
		setFormat(evaluatePlaceholder(ui.getFormat(), getFormat(),
				rep == null ? null : rep.getFormat(), ui));
		setOncontextmenu(evaluatePlaceholder(ui.getOncontextmenu(), getOncontextmenu(),
				rep == null ? null : rep.getOncontextmenu(), ui));
	}

	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br />
	 * 
	 * @param event イベントタイプ
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @param bindScriptBuilder 関連付け先のスクリプトバッファ
	 * @throws JspException 関連付けに失敗したとき
	 * @create 2013/06/06
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder)
		throws JspException {
		if ("click".equals(event) && getHref() == null) {
			scriptBuilder.prepend(GAnchorUtils.createPreventClickEventScript(null));
		}
		if ("contextmenu".equals(event) && getHref() == null) {
			scriptBuilder.append(GAnchorUtils.createPreventContextMenuEventScript(null));
		}
		super.bindMainScript(event, scriptBuilder, bindScriptBuilder);
	}

	/**
	 * charset属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return charset属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getCharset() {
		return _charset;
	}

	/**
	 * coords属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return coords属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getCoords() {
		return _coords;
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return 書式文字列
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * href属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return href属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getHref() {
		return _href;
	}

	/**
	 * hreflang属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return hreflang属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getHreflang() {
		return _hreflang;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/07/06
	 * @return ロケール
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * oncontextmenu属性の値を取得します.<br />
	 * 
	 * @create 2011/06/21
	 * @return oncontextmenu属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getOncontextmenu() {
		return _oncontextmenu;
	}

	/**
	 * rel属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return rel属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getRel() {
		return _rel;
	}

	/**
	 * rev属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return rev属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getRev() {
		return _rev;
	}

	/**
	 * shape属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return shape属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getShape() {
		return _shape;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return target属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * type属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return type属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getType() {
		return _type;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return value属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public String getValue() {
		if (_object instanceof Date) {
			return GUIUtils.formatDateToString((Date) _object, _format, GCoreUtils.getLocale(_locale));
		} else if (_object instanceof Number) {
			return GUIUtils.formatNumberToString((Number) _object, _format, GCoreUtils.getLocale(_locale));
		} else {
			return _object == null ? null : _object.toString();
		}
	}

	/**
	 * value属性の値をObjectで取得します.<br />
	 * 
	 * @create 2014/05/29
	 * @return value属性の値
	 * @author hashimoto
	 * @since 3.12.0
	 */
	public Object getObject() {
		return _object;
	}
	
	/**
	 * charset属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param charset charset属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setCharset(String charset) {
		_charset = charset;
	}

	/**
	 * coords属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param coords coords属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setCoords(String coords) {
		_coords = coords;
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param format 書式文字列
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * href属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param href href属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setHref(String href) {
		_href = href;
	}

	/**
	 * hreflang属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param hreflang hreflang属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setHreflang(String hreflang) {
		_hreflang = hreflang;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/07/06
	 * @param locale ロケール
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * oncontextmenu属性の値を設定します.<br />
	 * 
	 * @create 2011/06/21
	 * @param oncontextmenu oncontextmenu属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setOncontextmenu(String oncontextmenu) {
		_oncontextmenu = oncontextmenu;
	}

	/**
	 * rel属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param rel rel属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setRel(String rel) {
		_rel = rel;
	}

	/**
	 * rev属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param rev rev属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setRev(String rev) {
		_rev = rev;
	}

	/**
	 * shape属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param shape shape属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setShape(String shape) {
		_shape = shape;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param target target属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setTarget(String target) {
		_target = target;
	}

	/**
	 * type属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param type type属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setType(String type) {
		_type = type;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2013/06/04
	 * @param value value属性の値
	 * @author kikuchi
	 * @since 3.12.0
	 */
	public void setValue(String value) {
		setObject(value);
	}

	/**
	 * value属性の値をObjectで設定します.<br />
	 * 
	 * @create 2014/05/29
	 * @param value value属性の値
	 * @author hashimoto
	 * @since 3.12.0
	 */
	public void setObject(Object value) {
		_object = value;
	}
	
	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2013/06/04
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author kikuchi
	 * @since 3.12.0
	 */
	@Override
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), false);
	}
}
