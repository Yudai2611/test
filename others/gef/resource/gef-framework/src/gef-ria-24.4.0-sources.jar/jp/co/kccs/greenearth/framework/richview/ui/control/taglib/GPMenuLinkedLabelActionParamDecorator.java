/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.commons.json.GJSFunction;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPMenuLinkedLabel;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GActionParamDecorator;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GActionParamDecoratorBase;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;


/**
 * メニューリンクラベルのアクションパラメータを装飾するクラスです.<br/>
 *
 * @create 2013/07/17
 * @author kawakami
 * @since 3.12.0
 */
public class GPMenuLinkedLabelActionParamDecorator extends GActionParamDecoratorBase {

	/** アクションパラメータキー. */
	final static String ACTION_PARAM_KEY = "gpmenulinkedlabelevent";
	/** menuidキー. */
	final static String MENUID_OPTIONS_KEY = "menuid";

	/**
	 * {@link GPMenuLinkedLabelActionParamDecorator}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2013/07/17
	 * @author kawakami
	 * @since 3.12.0
	 */
	public GPMenuLinkedLabelActionParamDecorator() {
	}


	/**
	 * アクションパラメータの装飾を行います.<br/>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GActionParamDecoratorBase#decorate(jp.co.kccs.greenearth.commons.json.GJSONObject, jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param options アクションパラメータ
	 * @param component コンポーネント
	 * @author kawakami
	 * @since 2013/07/17
	 */
	@Override
	public void decorate(GJSONObject options, GUIComponent component) {
		GPMenuLinkedLabel ui = (GPMenuLinkedLabel)component;
		GJSFunction function = new GJSFunction();
		function.append("function(event, options, $form) {");
		function.append("return $.geui.handler.get('gpmenulinkedlabel').");
		function.append(GActionParamDecorator.DEFAULT_CALLBACK_FUNCTION_NAME);
		function.append("(event, options, $form);");
		function.append("}");
		if (ui.getMenu() != null) {
			options.put(MENUID_OPTIONS_KEY, ui.getMenu());
		}
		options.put(ACTION_PARAM_KEY, function);
	}
}
