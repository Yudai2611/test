/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.framework.richview.ui.control.GPMenuLinkedLabel;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * Plain MenuLinkedLabel<br />
 * 
 * @create 2013/07/17
 * @author kawakami
 * @since 3.12.0
 */
@TargetUIComponent(GPMenuLinkedLabel.class)
public class GPMenuLinkedLabelTag extends GPLinkedLabelTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7654590988296203249L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS= "ui-widget geui-gpmenulinkedlabel";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gpmenulinkedlabel-disabled ui-state-disabled";
	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gpmenulinkedlabel";

	// 拡張属性
	/** menu属性の値. */
	private String _menu = null;

	
	/**
	 * {@link GPMenuLinkedLabelTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2013/07/17
	 * @author kawakami
	 * @since 3.12.0
	 */
	public GPMenuLinkedLabelTag() {
	}
	
	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2013/07/17
	 * @param component {GPMenuLinkedLabel}レンダリング対象のUIコンポーネント
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPMenuLinkedLabel ui = (GPMenuLinkedLabel) component;
		GPMenuLinkedLabel rep = (GPMenuLinkedLabel) component.getRepository();
		setMenu(evaluatePlaceholder(ui.getMenu(), this._menu,
				rep == null ? null : rep.getMenu(), component));
	}
	
	/**
	 * XHTML拡張属性のtag属性に指定する値を取得します.<br/>
	 * 
	 * @return tag属性の値
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	protected String getExAttrTagValue() {
		return XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE;
	}

	/**
	 * デフォルトスタイルクラスを取得します.<br/>
	 * 
	 * @return デフォルトスタイルクラス
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	protected String getDefaultStyleClass() {
		return DEFAULT_STYLECLASS;
	}

	/**
	 * 無効状態時のスタイルクラスを取得します.<br/>
	 * 
	 * @return 無効状態時のスタイルクラス
	 * @create 2013/07/19
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	protected String getDisabledStyleClass() {
		return DISABLED_STYLECLASS;
	}

	/**
	 * menu属性の値を取得します.<br />
	 * 
	 * @return メニューID
	 * @create 2013/07/17
	 * @param menu メニューID
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getMenu() {
		return _menu;
	}

	/**
	 * menu属性の値を設定します.<br />
	 * 
	 * @create 2013/07/17
	 * @param menu メニューID
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setMenu(String menu) {
		_menu = menu;
	}
	
	/**
	 * href属性の値を設定します.<br/>
	 * ※本メソッドはサポートしません。
	 * 
	 * @create 2013/07/20
	 * @param href href属性の値
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	public void setHref(String href) {
	}

	/**
	 * hreflang属性の値を設定します.<br/>
	 * ※本メソッドはサポートしません。
	 * 
	 * @create 2013/07/20
	 * @param hreflang hreflang属性の値
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	public void setHreflang(String hreflang) {
	}
}
