/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPOption;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPOptionGroup;
import jp.co.kccs.greenearth.framework.richview.ui.control.GSelectOption;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * セレクトコントロールのオプショングループを表すタグクラスです.<br>
 * 
 * @create 2011/05/13
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPOptionGroup.class)
public class GPOptionGroupTag extends GUIItemBaseTag implements GEnablableTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6277193458103890907L;
	/** デフォルトのスタイルシートのクラス名（fieldType="field"）. */
	static final String DEFAULT_STYLECLASS = "geui-gpoptiongroup";
	/** disableスタイルシートのクラス名（fieldType="field", enabled="false"）. */
	static final String DISABLED_STYLECLASS = "geui-gpoptiongroup-disabled";

	// XHTML属性
	/** オプションの有効/無効. */
	private String _enabled = null;
	/** label属性の値. */
	private String _label = null;
	
	//拡張属性
	/** labelid属性の値. */
	private String _labelid = null;

	// 内部変数
	/** {@link GPOption}オブジェクトのリスト. */
	private List<GPOption> _selectOptions = null;
	/** {@link GPOption}オブジェクトのイテレータ. */
	private transient Iterator<GPOption> _selectOptionsIterator = null;

	/**
	 * {@link GPOptionGroupTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPOptionGroupTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @return XHTML文字列
	 * @create 2011/05/16
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("optgroup");
		decorateAttribute(builder);
		return builder.createStartTagString();
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doEndTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2011/05/16
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			GTagBuilder optiongroupTag = new GTagBuilder("optgroup");
			GTagUtils.printOut(pageContext, optiongroupTag.createEndTagString());
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * 親のタグからid属性の値をキーにして、{@link GPOptionGroup}
	 * コントロールを取得し、そのフィールドから属性情報を読み込んでいます。<br>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @create 2011/05/16
	 * @throws JspException {@link GPOptionGroup}の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@SuppressWarnings("deprecation")
	@Override
	public int doStartTag() throws JspException {
		GSelectTag select = (GSelectTag) findAncestorWithClass(this, GSelectTag.class);
		if (select != null) {
			GSelectOption selectOption = select.getNextSelectOption();
			if (selectOption != null) {
				load(selectOption);
			}
		}
		initSelectOptionIterator();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());

			return EVAL_BODY_INCLUDE;
		} else {
			return SKIP_BODY;
		}
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component UIコンポーネント
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPOptionGroup ui = (GPOptionGroup) component;
		GPOptionGroup rep = (GPOptionGroup) component.getRepository();
		_selectOptions = ui.getSelectOptions();
		setEnabled(evaluatePlaceholder(ui.getEnabled(), getEnabled(),
				rep == null ? null : rep.getEnabled(), ui));
		setLabel(evaluatePlaceholder(ui.getLabel(), getLabel(),
				rep == null ? null : rep.getLabel(), ui));
		setLabelid(evaluatePlaceholder(ui.getLabelid(), getLabelid(),
				rep == null ? null : rep.getLabelid(), ui));
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#reset()
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();

		_selectOptions = null;
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#decorateBaseAttribute(GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/05/17
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);

		if (!isEnabled()) {
			builder.setAttribute("disabled", "disabled");
		}
		if (!GStringUtils.isEmpty(getLabel())) {
			builder.setAttribute("label", getLabel());
		}
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2011/07/07
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * 内部フィールド{@link _selectOptionsIterator}を初期化します.<br/>
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void initSelectOptionIterator() {
		if (_selectOptions == null) {
			_selectOptions = new ArrayList<GPOption>();
		}
		_selectOptionsIterator = _selectOptions.iterator();
	}

	/**
	 * 次のオプションを取得します.<br />
	 * 
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @create 2011/05/17
	 * @return {@link GPOption}オブジェクト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Deprecated
	GPOption getNextSelectOption() {
		return _selectOptionsIterator.next();
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * label属性の値を取得します.<br />
	 * 
	 * @create 2011/05/17
	 * @return label属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLabel() {
		return _label;
	}

	/**
	 * labelid属性の値を取得します.<br />
	 * 
	 * @return labelid属性
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public String getLabelid() {
		return _labelid;
	}
	
	/**
	 * 指定されたインデックスの{@link GPOption}を取得します.<br />
	 * 
	 * @create 2011/05/17
	 * @param index インデックス
	 * @return {@link GPOption}オブジェクト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPOption getSelectOption(int index) {
		return _selectOptions.get(index);
	}

	/**
	 * オプションのリストを取得します.<br />
	 * 
	 * @create 2011/05/17
	 * @return オプションのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public List<GPOption> getSelectOptions() {
		return _selectOptions;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * label属性の値を設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param label label属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLabel(String label) {
		_label = label;
	}

	/**
	 * labelid属性の値を設定します.<br />
	 * 
	 * @param labelid labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public void setLabelid(String labelid) {
		_labelid = labelid;
	}
	
	/**
	 * オプションのリストを設定します.<br />
	 * 
	 * @create 2011/05/17
	 * @param selectOptions オプションのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSelectOptions(List<GPOption> selectOptions) {
		_selectOptions = selectOptions;
	}
}
