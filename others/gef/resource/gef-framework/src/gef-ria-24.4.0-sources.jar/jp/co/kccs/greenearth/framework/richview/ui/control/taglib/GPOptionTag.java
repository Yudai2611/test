/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPOption;
import jp.co.kccs.greenearth.framework.richview.ui.control.GSelectOption;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * セレクトコントロールのオプションを表すタグクラスです.<br>
 * 
 * @create 2011/05/13
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPOption.class)
public class GPOptionTag extends GUIItemBaseTag implements GEnablableTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7541305015503463389L;
	/** デフォルトのスタイルシートのクラス名（fieldType="field"）. */
	static final String DEFAULT_STYLECLASS = "geui-gpoption";
	/** disabledスタイルシートのクラス名（fieldType="field", enabled="false"）. */
	static final String DISABLED_STYLECLASS = "geui-gpoption-disabled";

	// XHTML属性
	/** value属性の値. */
	private String _value = null;
	/** enabled属性の値. */
	private String _enabled = null;
	/** label属性の値. */
	private String _label = null;
	
	//拡張属性
	/** labelid属性の値. */
	private String _labelid = null;

	// 内部変数
	/** {@link GPOption}の選択状態. */
	private boolean _selected = false;

	/**
	 * {@link GPOptionTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPOptionTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @return XHTML文字列
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("option");
		decorateAttribute(builder);

		if (getLabel() != null) {
			builder.setInnerText(getLabel());
		} else {
			builder.setInnerText(getValue());
		}

		return builder.createStartEndTagString();
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doStartTag()
	 * @create 2011/05/13
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GPOption}の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@SuppressWarnings("deprecation")
	@Override
	public int doStartTag() throws JspException {
		GSelectTag selectTag = (GSelectTag) findAncestorWithClass(this, GSelectTag.class);
		if (selectTag == null) {
			throw new JspException("GSelectTag is not found.");
		}
		GPOptionGroupTag optionGroupTag = (GPOptionGroupTag) findAncestorWithClass(this, GPOptionGroupTag.class);
		GSelectOption option =
			optionGroupTag == null ? selectTag.getNextSelectOption() : optionGroupTag.getNextSelectOption();
		if (option != null) {
			load(option);
			selectTag.influenceOption(this, option);
			if (isVisible()) {
				GTagUtils.printOut(pageContext, createXhtmlString());
				return EVAL_BODY_INCLUDE;
			}
		}
		return SKIP_BODY;

	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component UIコンポーネント
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPOption ui = (GPOption) component;
		GPOption rep = (GPOption) component.getRepository();
		setEnabled(evaluatePlaceholder(ui.getEnabled(), getEnabled(),
				rep == null ? null : rep.getEnabled(), ui));
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
		setLabel(evaluatePlaceholder(ui.getLabel(), getLabel(),
				rep == null ? null : rep.getLabel(), ui));
		setLabelid(evaluatePlaceholder(ui.getLabelid(), getLabelid(),
				rep == null ? null : rep.getLabelid(), ui));
		_selected = ui.isSelected();
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#reset()
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();

		_selected = false;
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#decorateBaseAttribute(GTagBuilder)
	 * @create 2011/05/13
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);

		if (!isEnabled()) {
			builder.setAttribute("disabled", "disabled");
		}
		if (isSelected()) {
			builder.setAttribute("selected", "selected");
		}
		if (getValue() != null) {
			builder.setAttribute("value", getValue());
		}
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/07/07
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * label属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return label属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getLabel() {
		return _label;
	}

	/**
	 * labelid属性の値を取得します.<br />
	 * 
	 * @return labelid属性
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public String getLabelid() {
		return _labelid;
	}
	
	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/05/13
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}

	/**
	 * オプションの選択状態を取得します.<br />
	 * 
	 * @return 選択中:<code>true</code>/未選択:<code>false</code>
	 * @create 2011/05/13
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public boolean isSelected() {
		return _selected;
	}

	/**
	 * オプションの選択状態を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @param enabled <code>true:選択</code>/<code>false:未選択</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * label属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param label label属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setLabel(String label) {
		_label = label;
	}

	/**
	 * labelid属性の値を設定します.<br />
	 * 
	 * @param labelid labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public void setLabelid(String labelid) {
		_labelid = labelid;
	}
	
	/**
	 * オプションの選択状態を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param selected <code>true:選択</code>/<code>false:未選択</code>
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSelected(boolean selected) {
		_selected = selected;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/05/13
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
