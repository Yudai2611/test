/*
 * Copyright 2013-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPPassword;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * パスワードコントロールを表示するタグクラスです.<br />
 * 
 * @create 2013/03/14
 * @author yamashita
 * @since 3.10.0.D
 */
@TargetUIComponent(GPPassword.class)
public class GPPasswordTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2293341369875647695L;
	/** Input_typeの値 */
	static final String INPUT_TYPE = "password";
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget ui-widget-content ui-corner-all geui-gppassword";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gppassword-disabled ui-state-disabled";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-gppassword-readonly";
	/** プレースホルダーコンテナのID SUFFIX*/
	static final String PLACEHOLDER_CONTAINER_IDSUFFIX = "-placeholder-container";
	/** プレースホルダーコンテナのスタイルシートのクラス名 */
	static final String PLACEHOLDER_CONTAINER_STYLECLASS = "geui-placeholder-container";
	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gppassword";
	/** プレースホルダーのID SUFFIX*/
	static final String PLACEHOLDER_IDSUFFIX = "-placeholder";
	/** プレースホルダーのスタイルシートのクラス名*/
	static final String PLACEHOLDER_STYLECLASS = "geui-placeholder";
	
	// XHTML属性
	/** autocomplete属性の値. */
	private String _autocomplete;
	/** maxlength属性の値. */
	private String _maxlength = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** size属性の値. */
	private String _size = null;
	/** value属性の値. */
	private String _value = null;
	/** placeholder属性の値. */
	private String _placeholder = null;
	/** noFocusOnReadonly属性の値 */
	private String _noFocusOnReadonly = null;	
	/** redisplay属性の値. */
	private String _redisplay = null;


	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2013/03/14
	 * @return XHTML文字列
	 * @author yamashita
	 * @throws JspException 
	 * @since 3.10.0.D
	 */
	@Override
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		bindScript();
		if (isEnabled() && !isReadonly()) {
			return decorateWithPlaceholder(builder.createTagString());
		}
		return builder.createTagString();
	}

	/**
	 * 値をセットするJavaScriptをバインドします.<br />
	 * IEにおいて、HTMLを取得(innerHTML/outerHTML)した際value属性値がロストする問題に対応しています。<br/>
	 * 
	 * @throws JspException 
	 * @create 2013/09/18
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected void bindScript() throws JspException {
		GJavaScriptBuilder js = new GJavaScriptBuilder();
		if (isRedisplay()) {
			js.append("$.ge.idSelector(??).val(??);", getFullId(), getValue());
		}
		bindScript(js.toString());
	}
	
	/**
	 * スクリプト出力可能かどうかを判定します.<br/>
	 * 常にスクリプト出力する必要があるため、trueを返します。<br/>
	 * 
	 * @return true: 出力可能
	 * @create 2013/09/18
	 * @author KCCS kikuchi
	 * @since 3.12.0
	 */
	@Override
	protected boolean isWritable() throws JspException {
		return true;
	}
	
	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2013/03/14
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPPassword ui = (GPPassword) component;
		GPPassword rep = (GPPassword) component.getRepository();
		setAutocomplete(evaluatePlaceholder(ui.getAutocomplete(), getAutocomplete(),
				rep == null ? null : rep.getAutocomplete(), ui));
		setMaxlength(evaluatePlaceholder(ui.getMaxlength(), getMaxlength(),
				rep == null ? null : rep.getMaxlength(), ui));
		setReadonly(evaluatePlaceholder(ui.getReadonly(), getReadonly(),
				rep == null ? null : rep.getReadonly(), ui));
		setSize(evaluatePlaceholder(ui.getSize(), getSize(),
				rep == null ? null : rep.getSize(), ui));
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
		setPlaceholder(evaluatePlaceholder(ui.getPlaceholder(), getPlaceholder(),
				rep == null ? null : rep.getPlaceholder(), ui));
		setNoFocusOnReadonly(evaluatePlaceholder(ui.getNoFocusOnReadonly(), getNoFocusOnReadonly(),
				rep == null ? null : rep.getNoFocusOnReadonly(), ui));
		setRedisplay(evaluatePlaceholder(ui.getRedisplay(), getRedisplay(),
				rep == null ? null : rep.getRedisplay(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @create 2013/03/14
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		String value = isRedisplay() ? getValue() : "";
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), value);
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
		builder.setAttribute("type", INPUT_TYPE);
		builder.setAttribute("autocomplete", getAutocomplete());
		builder.setAttribute("maxlength", getMaxlength());
		builder.setAttribute("size", getSize());
		builder.setAttribute("value", value);
		if (isReadonly()) {
			builder.setAttribute("readonly", "readonly");
			if (isNoFocusOnReadonly()) {
				builder.setAttribute("tabindex", "-1");
			}
		}
	}

	/**
	 * タグのスタイルクラスを装飾します.<br/>
	 * 
	 * @create 2013/03/15
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(READONLY_STYLECLASS, isReadonly());
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * autocomplete属性の値を取得します.<br />
	 * 
	 * @return autocomplete属性の値
	 * @create 2014/03/12
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * maxlength属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return maxlength属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getMaxlength() {
		return _maxlength;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * size属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return size属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * 状態の読み込み専用 / 書き込み可能を判定します.<br>
	 * 
	 * @create 2013/03/14
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 * 
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}

	/**
	 * 入力したパスワードを再表示するかを判定します.<br>
	 * 
	 * @create 2016/09/17
	 * @return <code>true<code>：再表示する / <code>false<code>：再表示しない
	 * @author kobayashi
	 * @since 3.19.0
	 */
	public boolean isRedisplay() {
		return GBooleanUtils.toBoolean(_redisplay, true);
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * redisplay属性を取得します.<br />
	 * 
	 * @return redisplay属性の値
	 * @author kobayashi
	 * @create 2016/09/16
	 * @since 3.19.0
	 */
	public String getRedisplay() {
		return _redisplay;
	}

	/**
	 * 引数のbooleanから、autocomplete属性の値を設定します.<br />
	 * <code>true</code>:on<br>
	 * <code>false</code>:off<br>
	 * 
	 * @param autocomplete autocomplete属性の値
	 * @create 2014/03/12
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public void setAutocomplete(boolean autocomplete) {
		_autocomplete = autocomplete ? "on" : "off";
	}

	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @param autocomplete autocomplete属性の値
	 * @create 2014/03/12
	 * @author KCCS N.Nishimura
	 * @since RIW FW
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * maxlength属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param length maxlength属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setMaxlength(String length) {
		_maxlength = length;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * size属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param size size属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public void setValue(String value) {
		_value = value;
	}
	/**
	 *　placeholder属性の値を設定します。
	 * 
	 * @param placeholder placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public void setPlaceholder(String placeholder) {
		_placeholder = placeholder;
	}
	/**
	 * placeholder属性の値を取得します。
	 * 
	 * @return placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public String getPlaceholder() {
		return _placeholder;
	}

	
	/**
	 * placeholder用のタグを付加します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GPPlaceholderDecorator#decorate(java.lang.String, jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GPPLaceholderDecoratableTag)
	 * @param tagString デコレートするタグ文字列
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @throws JspException 
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	protected String decorateWithPlaceholder(String tagString) throws JspException {
		StringBuilder sb = new StringBuilder();
		if (!GStringUtils.isEmpty(getPlaceholder())) {
			GTagBuilder container = new GTagBuilder("span");
			container.setAttribute("id", getFullId() + PLACEHOLDER_CONTAINER_IDSUFFIX);
			container.setAttribute("class", PLACEHOLDER_CONTAINER_STYLECLASS);
			sb.append(container.createStartTagString());
		}
		sb.append(tagString);
		
		if (!GStringUtils.isEmpty(getPlaceholder())) {
			GTagBuilder placeholder = new GTagBuilder("span");
			placeholder.setAttribute("id", getFullId() + PLACEHOLDER_IDSUFFIX);
			placeholder.setAttribute("class", PLACEHOLDER_STYLECLASS);
			placeholder.setInnerText(getPlaceholder());
			sb.append(placeholder.createStartEndTagString());
			GTagBuilder containerend = new GTagBuilder("span");
			sb.append(containerend.createEndTagString());
			GJavaScriptBuilder js = new GJavaScriptBuilder();
			js.append("$(function(){$.geui.placeholderdecorator.decorate(??);});",getFullId());
			super.bindScript(js.toString());
		}
		return sb.toString();
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 * 
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0 
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 * 
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0 
	 */
	public void setNoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}

	/**
	 * redisplay属性の値を設定します.<br />
	 * 
	 * @param redisplay属性の値
	 * @author kobayashi
	 * @create 2016/09/16
	 * @since 3.19.0
	 */
	public void setRedisplay(boolean redisplay) {
		_redisplay = String.valueOf(redisplay);
	}

	/**
	 * redisplay属性の値を設定します.<br />
	 * 
	 * @param redisplay属性の値
	 * @author kobayashi
	 * @create 2016/09/16
	 * @since 3.19.0
	 */
	public void setRedisplay(String redisplay) {
		_redisplay = redisplay;
	}

}
