/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPRadioGroup;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * ラジオグループウィジェットを作成するタグクラスです.<br>
 * 
 * @create 2013/06/12
 * @author kawakami
 * @since 3.12.0
 */
@TargetUIComponent(GPRadioGroup.class)
public class GPRadioGroupTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 3746637604274623400L;

	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gpradiogroup";
	
	// XHTML属性
	/** value属性の値 */
	private String _value = null;
	/** readonly属性の値. */
	private String _readonly = null;
	
	/**
	 * {@link GPRadioGroupTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	public GPRadioGroupTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @return XHTML文字列
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	public String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		return builder.createTagString();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * 以下の属性を読み込みます。<br>
	 * ・value<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GRFieldControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPRadioGroup ui = (GPRadioGroup) component;
		GPRadioGroup rep = (GPRadioGroup) component.getRepository();
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * 1.タグ情報にXHTMLに出力する属性情報を付加します。<br>
	 * 2.スーパークラスで定義された属性及び、本クラスで定義する、以下の属性<br>
	 * を付加します。<br>
	 * (属性の一覧はクラスのドキュメントを参照ください。)<br>
	 * 
	 * [1]type属性<br>
	 * [2]value属性<br>
	 * [3]InitValue拡張属性<br>
	 * [4]Tag拡張属性<br>
	 * 3. enabled属性がfalseの場合は、name属性を定義しません。<br>
	 * 
	 * @param builder 属性を追記するGTagBuilder
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		if (!isEnabled()) {
			builder.removeAttribute("name");
		}
		builder.setAttribute("type", "hidden");
		builder.setAttribute("value", getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2013/06/12
	 * @return value属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @param value value属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setValue(String value) {
		_value = value;
	}
	
	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}
	
	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @param readonly readonly属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since RIA WF
	 */
	public void setReadOnly(boolean readonly) {
		_readonly = Boolean.toString(readonly);
	}
}
