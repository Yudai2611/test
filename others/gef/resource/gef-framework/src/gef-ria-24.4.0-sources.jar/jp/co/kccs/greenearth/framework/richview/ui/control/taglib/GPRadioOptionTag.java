/*
 * Copyright 2013-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPRadioGroup;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPRadioOption;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * ラジオオプションウィジェットを表示するタグクラスです.<br>
 * 
 * @create 2013/06/12
 * @author kawakami
 * @since 3.12.0
 */
@TargetUIComponent(GPRadioOption.class)
public class GPRadioOptionTag extends GUIControlBaseTag implements GEnablableTag {
	
	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -8898621343199721434L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gpradiooption";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gpradiooption-disabled ui-state-disabled";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-gpradiooption-readonly";
	/** ERRORスタイルシートのクラス名. */
	static final String ERROR_STYLECLASS = "geui-errorlevel-error";
	/** WARNスタイルシートのクラス名. */
	static final String WARN_STYLECLASS = "geui-errorlevel-warn";
	/** INFOスタイルシートのクラス名. */
	static final String INFO_STYLECLASS = "geui-errorlevel-info";
	
	/** radougroup属性のキー */
	static final String XHTML_EXTENSION_ATTRIBUTE_RADIOGROUP_VALUE = "ghx:radiogroup";
	/** セパレータ */
	private final static String SEPARATE = " ";

	// XHTML属性
	/** checked属性の値 */
	private String _checked = null;
	/** value属性の値 */
	private String _value = null;
	/** name属性の値*/
	private String _name = null;
	// 拡張属性
	/** readonly属性の値*/
	String _readonly = null;
	/** enabled属性の値. */
	private String _enabled = null;
	/** radiogroup属性の値 */
	private String _radiogroup = null;
	/** {@link GErrorLevel}オブジェクト. */
	private GErrorLevel _errorlevel = null;

	/**
	 * {@link GPRadioOptionTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	public GPRadioOptionTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @return XHTML文字列
	 * @create 2013/06/12
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		this.bindScript("change",new GJavaScriptBuilder());
		return builder.createTagString();
	}
	
	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br/>
	 * 対象の要素とは{@link GScriptBufferedWriterTag}を実装しているカスタムタグのことを示します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#bindMainScript(java.lang.String, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder)
	 * @param event イベント
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @param bindScriptBuilder 関連付け先のスクリプトバッファ
	 * @throws JspException 関連付けに失敗したとき
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder) throws JspException {
		scriptBuilder.append("$.ge.idSelector(??).val(??);",this.getRadiogroup(),this.getValue());
		super.bindMainScript(event, scriptBuilder, bindScriptBuilder);
	}

	/**
	 * 指定されたレンダリング対象のGPRadioOptionコンポーネントから以下の属性を読み込みます<br>
	 * <p>value,radiogroup</p>
	 * その属性radiogroupに指定されたidを持つGPRadioGroupコンポーネントをコンポーネントツリーから探し<br>
	 * 以下の属性を読み込みます。<br>
	 * <p>checked</p>
	 * readonly,enabled,visible属性値はradiogroup属性に指定されたidを持つGPRadioGroupコンポーネント<br>
	 * とGPradioOptionコンポーネントの値の組み合わせで決定されます。ルールは以下の通りです。<br>
	 * <pre>
	 *          ui component       | option tag
	 * 	        group    option    | 
	 *          -----------------------------------
	 * enabled  true     true      | true
	 *          true     false     | false
	 *          false    true      | false
	 *          false    false     | false
	 * readonly true     true      | true
	 *          true     false     | true
	 *          false    true      | true
	 *          false    false     | false
	 * visible  true     true      | true
	 *          true     false     | false
	 *          false    true      | false
	 *          false    false     | false
	 * </pre>
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPRadioOption ui = (GPRadioOption) component;
		GPRadioOption rep = (GPRadioOption) component.getRepository();
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
		setRadiogroup(evaluatePlaceholder(ui.getRadiogroup(), getRadiogroup(),
				rep == null ? null : rep.getRadiogroup(), ui));
		
		GViewInterface view = (GViewInterface)super.getRootComponent(this);
		if(this.getRadiogroup() == null) {
			//TODO 例外の種類を再考
			throw new IllegalArgumentException("radiogroup attribute is missing at gp:radiooption");
		}
		GPRadioGroup group = (GPRadioGroup)view.findControl(this.getRadiogroup());
		if(group == null) {
			//TODO 例外の種類を再考
			throw new IllegalArgumentException("gp:radiogroup is missing by radiogroup attribute:" + this.getRadiogroup());
		}
		_name = group.getRadioOptionName();
		_readonly = group.isReadonly() ? group.getReadonly() : ui.getReadonly();
		_errorlevel = group.getErrorlevel();
		setChecked(evaluatePlaceholder(
					Boolean.toString(group.getValue() != null ? group.getValue().equals(getValue()) : false), 
					getChecked(),
					null, ui));
		setEnabled(evaluatePlaceholder(
					!group.isEnabled() ? group.getEnabled() : ui.getEnabled(),
					getEnabled(),
					rep == null ? null : rep.getEnabled(), ui));
		setVisible(evaluatePlaceholder(					
					!group.isVisible() ? group.getVisible() : ui.getVisible(), 
					getVisible(),
					rep == null ? null : rep.getVisible(), ui));
	}
	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * スーパークラスで定義された属性および、本クラスで定義する以下の属性を XHTMLに出力する属性をタグビルダーに付加します。
	 * (属性の一覧はクラスのドキュメントを参照ください。)<br>
	 * [1]type属性<br>
	 * [2]value属性<br>
	 * [3]disabled属性<br>
	 * [4]checked属性<br>
	 * [5]name属性<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder builder 属性を追記するGTagBuilder
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		
		builder.setAttribute("type", "radio");
		builder.setAttribute("value", getValue());
		if (isReadonly()||!isEnabled()) {
			builder.setAttribute("disabled", "disabled");
		}
		if (isChecked()) {
			builder.setAttribute("checked", "checked");
		}
		builder.setAttribute(XHTML_EXTENSION_ATTRIBUTE_RADIOGROUP_VALUE, this.getRadiogroup());
		builder.setAttribute("name", this._name);
	}
	/**
	 * タグのスタイルクラスを装飾します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @create 2013/03/16
	 * @author KCCS H.nishimura
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(READONLY_STYLECLASS, isReadonly());
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());

		if (_errorlevel == GErrorLevel.ERROR) {
			styleclass.add(ERROR_STYLECLASS);
			styleclass.remove(WARN_STYLECLASS + SEPARATE + INFO_STYLECLASS);
		}
		else if (_errorlevel == GErrorLevel.WARNING) {
			styleclass.add(WARN_STYLECLASS);
			styleclass.remove(ERROR_STYLECLASS + SEPARATE + INFO_STYLECLASS);
		}
		else if (_errorlevel == GErrorLevel.INFO) {
			styleclass.add(INFO_STYLECLASS);
			styleclass.remove(ERROR_STYLECLASS + SEPARATE + WARN_STYLECLASS);
		}
		else {
			styleclass.remove(ERROR_STYLECLASS + SEPARATE + WARN_STYLECLASS + SEPARATE + INFO_STYLECLASS);
		}
		
		builder.setAttribute("class", getStyleclass());
	}
	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @create 2013/06/12
	 * @return checked属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getChecked() {
		return _checked;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2013/06/12
	 * @return タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * radiogroup属性の値を取得します.<br />
	 * 
	 * @return ラジオグループのid属性の値
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getRadiogroup() {
		return this._radiogroup;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2013/06/12
	 * @return value属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @create 2013/06/12
	 * @return checked属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public boolean isChecked() {
		return GBooleanUtils.toBoolean(_checked, false);
	}

	/**
	 * タグの有効/無効を取得します.<br />
	 * 
	 * @return 有効=true、無効=false
	 * @create 2013/06/12
	 * @author kawakami
	 * @since 3.12.0
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(_enabled, true);
	}
	/**
	 * readonlyかどうかを取得します.<br />
	 * 
	 * @return readonly=true、readonlyでない=false
	 * @create 2013/06/17
	 * @author kawakami
	 * @since 3.12.0
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}
	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @create 2013/06/12
	 * @param checked checked属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setChecked(boolean checked) {
		_checked = String.valueOf(checked);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @create 2013/06/12
	 * @param checked checked属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setChecked(String checked) {
		_checked = checked;
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2013/06/12
	 * @param enabled タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2013/06/12
	 * @param enabled タグの<code>true:有効</code>/<code>false:無効</code>
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * radiogroup属性の値を設定します.<br />
	 * 
	 * @create 2013/06/12
	 * @param radiogroup ラジオグループのid属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setRadiogroup(String radiogroup) {
		this._radiogroup = radiogroup;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2013/06/12
	 * @param value value属性の値
	 * @author kawakami
	 * @since 3.12.0
	 */
	public void setValue(String value) {
		_value = value;
	}
	
}
