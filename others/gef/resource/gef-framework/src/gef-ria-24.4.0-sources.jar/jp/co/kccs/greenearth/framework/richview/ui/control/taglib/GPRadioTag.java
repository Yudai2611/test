/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPRadio;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * ラジオボタンコントロールを表示するタグクラスです.<br>
 * 
 * @create 2011/06/01
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPRadio.class)
public class GPRadioTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5015909710962577648L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget geui-gpradio";
	/** デフォルトのスタイルシートのクラス名（enable="false"）. */
	static final String DISABLED_STYLECLASS = "geui-gpradio-disabled ui-state-disabled";
	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gpradio";
	
	// XHTML属性
	/** checked属性の値. */
	private String _checked = null;
	/** value属性の値. */
	private String _value = null;

	/**
	 * {@link GPRadioTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPRadioTag() {
	}

	/**
	 * XHTML文字列を生成します.<br/>
	 * 
	 * @create 2011/06/01
	 * @throws JspException タグの書き込みに失敗した場合
	 * @return XHTML文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		return builder.createTagString();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/06/01
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPRadio ui = (GPRadio) component;
		GPRadio rep = (GPRadio) component.getRepository();
		setChecked(evaluatePlaceholder(ui.getChecked(), getChecked(),
				rep == null ? null : rep.getChecked(), ui));
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br/>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/06/01
	 * @param builder builder 属性を追記するGTagBuilder
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("type", "radio");
		builder.setAttribute("name", getParameterKey());
		if (getValue() != null) {
			builder.setAttribute("value", getValue());
		}
		if (isChecked()) {
			builder.setAttribute("checked", "checked");
		}
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/07/07
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @create 2011/06/04
	 * @return checked属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getChecked() {
		return _checked;
	}

	/**
	 * IDを取得します.<br>
	 * 
	 * IDの先頭に接頭辞文字列が付加されます。
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#getId()
	 * @create 2011/06/01
	 * @return 接頭辞文字列が付加されたID
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getId() {
		if (!GStringUtils.isEmpty(getPrefix())) {
			return getPrefix() + super.getId();
		}
		return super.getId();
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * checked属性の値を取得します.<br />
	 * 
	 * @create 2011/06/04
	 * @return checked属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isChecked() {
		return GBooleanUtils.toBoolean(_checked, false);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param checked checked属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setChecked(boolean checked) {
		_checked = String.valueOf(checked);
	}

	/**
	 * checked属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param checked checked属性の値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setChecked(String checked) {
		_checked = checked;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}
}
