/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.TagSupport;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

public class GPScriptTag extends TagSupport {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2958782501898409743L;

	// HTML属性
	/** 文字コード. */
	private String _charset = null;

	/** スクリプト内の表示に関する記述の有無. */
	private String _defer = null;

	/** ID属性. */
	private String _id = null;

	/** 外部スクリプトファイルのURL. */
	private String _src = null;

	/** スクリプト言語. */
	private String _type = null;

	/** 続するスペースや改行、タブなどの空白類文字の扱い方法. */
	private String _xmlspace = null;

	/**
	 * 
	 * 
	 * @create 2013/08/14
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	public GPScriptTag() {
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br>
	 * 
	 * @create 2013/08/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	public int doStartTag() throws JspException {
		GTagUtils.printOut(pageContext, createXhtmlString());
		return EVAL_BODY_INCLUDE;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br>
	 * 
	 * @create 2013/08/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	@Override
	public int doEndTag() throws JspException {
		GTagBuilder builder = new GTagBuilder("script");
		GTagUtils.printOut(pageContext, builder.createEndTagString());
		reset();
		return EVAL_PAGE;
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2013/08/14
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	public void reset() {
		_charset = null;
		_defer = null;
		_id = null;
		_src = null;
		_type = null;
		_xmlspace = null;
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2013/08/14
	 * @return XHTML文字列
	 * @author yamashita
	 * @since 3.12.0
	 */
	protected String createXhtmlString() {
		GTagBuilder builder = new GTagBuilder("script");
		builder.setAttribute("charset", getCharset());
		if (isDefer()) {
			builder.setAttribute("defer", "defer");
		}
		builder.setAttribute("id", getId());
		builder.setAttribute("type", getType());
		builder.setAttribute("xml:space", getXmlspace());
		builder.setAttribute("src", getSrc());
		return builder.createStartTagString();
	}

	/**
	 * 文字コードを取得します.<br>
	 * 
	 * @create 2013/08/14
	 * @return 文字コード
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getCharset() {
		return _charset;
	}
	
	/**
	 * defer属性の値を取得します.<br>
	 * 
	 * @return defer属性
	 * @create 2014/06/10
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public String getDefer() {
		return _defer;
	}

	/**
	 * ID属性の値を取得します.<br>
	 * 
	 * @create 2013/08/14
	 * @return ID属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getId() {
		return _id;
	}

	/**
	 * 外部スクリプトファイルのURLを取得します.<br>
	 * 
	 * @create 2013/08/14
	 * @return 外部スクリプトファイルのURL
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getSrc() {
		return _src;
	}

	/**
	 * スクリプト言語を取得します.<br>
	 * 
	 * @create 2013/08/14
	 * @return スクリプト言語
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getType() {
		return _type;
	}

	/**
	 * 連続するスペースや改行、タブなどの空白類文字をどう扱うかを取得します.<br>
	 * 
	 * @create 2013/08/14
	 * @return <code>preserve</code>/<code>default</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getXmlspace() {
		return _xmlspace;
	}

	/**
	 * スクリプトに文書の内容を生成する要素を含まないかを取得します.<br>
	 * <code>true</code>: スクリプト内に表示に関する記述がない場合<br>
	 * <code>false</code>: スクリプト内に表示に関する記述がある場合<br>
	 * 
	 * @create 2013/08/14
	 * @return <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public boolean isDefer() {
		return GBooleanUtils.toBoolean(_defer, false);
	}

	/**
	 * 文字コードを設定します.<br>
	 * 
	 * @create 2013/08/14
	 * @param charset 文字コード
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setCharset(String charset) {
		_charset = charset;
	}

	/**
	 *スクリプトに文書の内容を生成する要素を含まないかを設定します.<br>
	 * 	<code>true</code>: スクリプト内に表示に関する記述がない場合<br>
	 * 	<code>false</code>: スクリプト内に表示に関する記述がある場合<br>
	 * @create 2013/08/14
	 * @param defer <code>true</code>/<code>false</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setDefer(String defer) {
		_defer = defer;
	}
	
	/**
	 *スクリプトに文書の内容を生成する要素を含まないかを設定します.<br>
	 * 	<code>true</code>: スクリプト内に表示に関する記述がない場合<br>
	 * 	<code>false</code>: スクリプト内に表示に関する記述がある場合<br>
	 * 
	 * @param defer <code>true</code>/<code>false</code>
	 * @create 2014/06/10
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public void setDefer(boolean defer) {
		_defer = String.valueOf(defer);
	}
	

	/**
	 * ID属性の値を設定します.<br>
	 * 
	 * @create 2013/08/14
	 * @param id ID属性の値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setId(String id) {
		_id = id;
	}

	/**
	 * 外部スクリプトファイルのURLを設定します.<br>
	 * 
	 * @create 2013/08/14
	 * @param src 外部スクリプトファイルのURL
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setSrc(String src) {
		_src = src;
	}

	/**
	 *スクリプト言語を設定します.<br>
	 * 
	 * @create 2013/08/14
	 * @param type スクリプト言語
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setType(String type) {
		_type = type;
	}

	/**
	 * 連続するスペースや改行、タブなどの空白類文字をどう扱うかを設定します.<br>
	 * <code>preserve</code>:スペースや改行はそのまま表示します。<br>
	 * <code>default</code>:ユーザーエージェントの初期値に任せます。<br>
	 * 
	 * @create 2013/08/14
	 * @param xmlspace <code>preserve</code>/<code>default</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setXmlspace(String xmlspace) {
		_xmlspace = xmlspace;
	}
}
