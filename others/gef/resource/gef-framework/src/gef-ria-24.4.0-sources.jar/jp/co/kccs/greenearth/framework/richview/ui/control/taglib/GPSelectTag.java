/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPSelect;
import jp.co.kccs.greenearth.framework.richview.ui.control.GSelectOption;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTag;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * セレクトコントロールを表示するタグクラスです.<br>
 * 
 * 【概要】<br>
 * XHTMLのselect要素に該当し、{@link GPSelect}コントロールの内容をレンダリングします。
 * <code>GSelectTag</code>の選択項目は{@link GPOptionTag}のみ有効となります。<br>
 * type属性によって、以下のように機能が変わります。<br>
 * <br>
 * 
 * 
 * @create 2011/06/01
 * @author hamanaka
 * @since 3.9.0
 */
@TargetUIComponent(GPSelect.class)
public class GPSelectTag extends GVariableControlBaseTag implements GSelectTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -6741760498499729941L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget ui-state-default geui-gpselect";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gpselect-disabled ui-state-disabled";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-gpselect-readonly";

	// XHTML属性
	/** size属性の値. */
	private String _size = null;

	// 拡張属性
	/** value属性の値. */
	private String _value = null;
	/** readonly属性の値. */
	private String _readonly = null;

	// 内部変数
	/** {@link GSelectOption}オブジェクトのリスト. */
	private List<GSelectOption> _selectOptions = new LinkedList<GSelectOption>();
	/** {@link GSelectOption}オブジェクトのイテレータ. */
	private transient Iterator<GSelectOption> _selectOptionsIterator = null;
	/** {@link GSelectOption}オブジェクトの選択状態. */
	private GPOptionTag _selectedOptionTag = null;

	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gpselect";

	/**
	 * {@link GPSelectTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GPSelectTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/06/01
	 * @return XHTML文字列
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() {
		GTagBuilder selectTag = new GTagBuilder("select");
		decorateAttribute(selectTag);
		return selectTag.createStartTagString();
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doEndTag()
	 * @create 2011/06/01
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		if (isVisible()) {
			// XHTMLのselect要素の終了タグを生成します
			GTagBuilder selectTag = new GTagBuilder("select");
			GTagUtils.printOut(pageContext, selectTag.createEndTagString());
			if (isEnabled() && getSelectOptions().size() > 0) {
				GTagUtils.printOut(pageContext, createHiddenTagString());
				if (!isReadonly()) {
					bindScript("change", new GJavaScriptBuilder());
				}
			}
			bindInitScript();
		}
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br/>
	 * 対象の要素とは{@link GScriptBufferedWriterTag}を実装しているカスタムタグのことを示します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#bindMainScript(java.lang.String, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder)
	 * @param event イベント
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @param bindScriptBuilder 関連付け先のスクリプトバッファ
	 * @throws JspException 関連付けに失敗したとき
	 * @create 2014/06/24
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder) throws JspException {
		scriptBuilder.append("$.geui.val('");
		scriptBuilder.append(getFullId());
		scriptBuilder.append("', $.geui.val('");
		scriptBuilder.append(getFullId());
		scriptBuilder.append("'));");
		super.bindMainScript(event, scriptBuilder, bindScriptBuilder);
	}

	/**
	 * 初期値を設定するためのスクリプトを、対象の要素がレンダリングするように関連付けます.<br/>
	 * 対象の要素とは{@link GScriptBufferedWriterTag}を実装しているカスタムタグのことを示します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#bindMainScript(java.lang.String, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder, jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder)
	 * @throws JspException
	 * @create 2014/07/01
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	protected void bindInitScript() throws JspException {
		GJavaScriptBuilder js = new GJavaScriptBuilder();
		js.append("$(function(){$.geui.handler.get('gpselect').init(??);});", getFullId());
		super.bindScript(js.toString());
	}

	/**
	 * スクリプト出力可能かどうかを判定します.<br>
	 * GPSelectは、初期値を設定するスクリプトを常に出力する必要があるため常にtrueを返します。
	 * <br>
	 * @return true: 出力可能
	 * @create 2014/07/03
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	@Override
	protected boolean isWritable() throws JspException {
		return true;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br/>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doStartTag()
	 * @create 2011/06/01
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GPSelect}の取得・ロード、タグの書き込みに失敗した場合
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		initSelectOptionIterator();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());

			return EVAL_BODY_INCLUDE;
		} else {
			return SKIP_BODY;
		}
	}

	/**
	 * {@link GPOptionTag}に対して処理を行います.<br>
	 * 
	 * 指定された{@link GPOptionTag}のselectedフィールドを<code>"true"</code>にします。 接頭辞文字列を
	 * {@link GPOptionTag}のidフィールドにも付加します。
	 * 
	 * @param option オプション
	 * @create 2011/06/01
	 * @param optionTag {@link GPOptionTag}オブジェクト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void influenceOption(GPOptionTag optionTag, GSelectOption option) {
		boolean isSelected = optionTag.getValue() != null && optionTag.getValue().equals(getValue());
		optionTag.setSelected(isSelected);
		if (isSelected) {
			_selectedOptionTag = optionTag;
		}

		if (optionTag.getId() != null) {
			optionTag.setFullId(GStringUtils.nullToBlank(getPrefix()) + optionTag.getId());
		}
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @see {@link GVariableControlBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)}
	 * @create 2011/06/01
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPSelect ui = (GPSelect) component;
		GPSelect rep = (GPSelect) component.getRepository();
		setSize(evaluatePlaceholder(ui.getSize(), getSize(),
				rep == null ? null : rep.getSize(), ui));
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
		setReadonly(evaluatePlaceholder(ui.getReadonly(), getReadonly(),
				rep == null ? null : rep.getReadonly(), ui));
		_selectOptions = ui.getSelectOptions();
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#reset()
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();

		_selectOptionsIterator = null;
		_selectedOptionTag = null;
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/06/01
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("size", getSize());
		builder.removeAttribute("name");
		if (isReadonly() && isEnabled()) {
			builder.setAttribute("disabled", "disabled");
		}
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY), XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleClassAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/07/07
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(READONLY_STYLECLASS, isReadonly());
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * 指定されたタグにこのタグのwidget属性を追加します. <br>
	 * 
	 * ここでは何も追加しません。
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GRichUIComponentBaseTag#decorateWidgetAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/06/01
	 * @param builder 属性を追記するGTagBuilder
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetAttribute(GTagBuilder builder) {
	}

	/**
	 * 内部フィールド{@link _selectOptionsIterator}を初期化します.<br/>
	 * 
	 * @create 2011/06/01
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void initSelectOptionIterator() {
		if (_selectOptions == null) {
			_selectOptions = new ArrayList<GSelectOption>();
		}
		_selectOptionsIterator = _selectOptions.iterator();
	}

	/**
	 * 次のオプションを取得します.<br />
	 * 
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @create 2011/06/01
	 * @return セレクトオプション
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Deprecated
	public GSelectOption getNextSelectOption() {
		return _selectOptionsIterator.next();
	}

	/**
	 * 指定されたインデックスの{@link GSelectOption}を取得します.<br />
	 * 
	 * @param index インデックス
	 * @create 2011/06/01
	 * @return {@link GSelectOption}オブジェクト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public GSelectOption getSelectOption(int index) {
		return _selectOptions.get(index);
	}

	/**
	 * オプションのリストを取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return {@link GSelectOption}オブジェクトのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public List<GSelectOption> getSelectOptions() {
		return _selectOptions;
	}

	/**
	 * size属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return size属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * デフォルトのスタイルシートのクラスを取得します.<br>
	 * 
	 * クラスが指定されている場合、そのクラスを取得しますが、 クラスが指定されていない場合、デフォルトのクラスを取得します。
	 * デフォルトのクラスはenable属性によって変化します。
	 * 
	 * @see GUIComponentBaseTag#getStyleclass()
	 * @create 2011/06/01
	 * @return スタイルシートのクラス
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Override
	public String getStyleclass() {
		if (super.getStyleclass() != null) {
			return super.getStyleclass();
		}
		if (!isEnabled()) {
			return DISABLED_STYLECLASS;
		} else {
			return DEFAULT_STYLECLASS;
		}
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * オプションのリストをセットします.<br />
	 * 
	 * @create 2011/06/01
	 * @param selectOptions {@link GSelectOption}オブジェクトのリスト
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSelectOptions(List<GSelectOption> selectOptions) {
		_selectOptions = selectOptions;
	}

	/**
	 * size属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param size size属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/06/01
	 * @param value value属性の値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		_value = value;
	}

	/**
	 * 初期選択状態となるオプションの値を取得します.<br />
	 * 
	 * @create 2011/06/01
	 * @return 初期選択状態となるオプションの値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected String getOptionValue() {
		if (_selectedOptionTag != null) {
			return _selectedOptionTag.getValue();
		}
		return null;
	}

	/**
	 * 状態の読み込み専用/書き込み可能を判定します.<br>
	 * 
	 * @create 2014/06/24
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2014/06/24
	 * @return readonly属性の値
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param readonly <code>true</code>/<code>false</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2014/06/24
	 * @param readonly <code>true</code>/<code>false</code>
	 * @author KCCS kikuchi
	 * @since 3.16.0
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}
}