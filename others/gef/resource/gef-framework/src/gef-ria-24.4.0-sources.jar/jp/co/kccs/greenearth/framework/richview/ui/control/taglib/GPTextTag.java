/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.Date;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPText;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIUtils;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * テキストコントロールを表示するタグクラスです.<br/>
 * 
 * @create 2011/08/19
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GPText.class)
public class GPTextTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 1113615078695699038L;
	/** 入力タグタイプ */
	static final String INPUT_TYPE = "text";
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget ui-widget-content ui-corner-all geui-gptext";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gptext-disabled ui-state-disabled";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-gptext-readonly";
	/** プレースホルダーコンテナのID SUFFIX*/
	static final String PLACEHOLDER_CONTAINER_IDSUFFIX = "-placeholder-container";
	/** プレースホルダーコンテナのスタイルシートのクラス名 */
	static final String PLACEHOLDER_CONTAINER_STYLECLASS = "geui-placeholder-container";
	/** プレースホルダーのID SUFFIX*/
	static final String PLACEHOLDER_IDSUFFIX = "-placeholder";
	/** プレースホルダーのスタイルシートのクラス名*/
	static final String PLACEHOLDER_STYLECLASS = "geui-placeholder";
	/** 【XHTML拡張属性】タグ名. */
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gptext";
	
	// XHTML属性
	/** autocomplete属性の値. */
	private String _autocomplete = null;
	/** maxlength属性の値. */
	private String _maxlength = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** size属性の値. */
	private String _size = null;
	/** value属性の値. */
	private Object _object = null;

	// 拡張属性
	/** format属性の値. */
	private String _format = null;
	/** locale属性の値. */
	private String _locale = null;
	/** placeholder属性の値. */
	private String _placeholder = null;

	/** noFocusOnReadonly属性の値 */
	private String _noFocusOnReadonly = null;

	/**
	 * {@link GPTextTag}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/08/19
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GPTextTag() {
	}

	/**
	 * XHTML文字列を生成します.<br/>
	 * 
	 * @create 2011/08/19
	 * @return XHTML文字列
	 * @author yamashita
	 * @throws JspException 
	 * @since 3.9.0
	 */
	@Override
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("input");
		decorateAttribute(builder);
		
		if (isEnabled() && !isReadonly()) {
			return decorateWithPlaceholder(builder.createTagString());
		}
		return builder.createTagString();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/08/19
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPText ui = (GPText) component;
		GPText rep = (GPText) component.getRepository();
		setAutocomplete(evaluatePlaceholder(ui.getAutocomplete(), getAutocomplete(),
				rep == null ? null : rep.getAutocomplete(), ui));
		setMaxlength(evaluatePlaceholder(ui.getMaxlength(), getMaxlength(),
				rep == null ? null : rep.getMaxlength(), ui));
		setReadonly(evaluatePlaceholder(ui.getReadonly(), getReadonly(),
				rep == null ? null : rep.getReadonly(), ui));
		setSize(evaluatePlaceholder(ui.getSize(), getSize(),
				rep == null ? null : rep.getSize(), ui));
		setFormat(evaluatePlaceholder(ui.getFormat(), getFormat(),
				rep == null ? null : rep.getFormat(), ui));
		setLocale(evaluatePlaceholder(ui.getLocale(), getLocale(),
				rep == null ? null : rep.getLocale(), ui));
		setPlaceholder(evaluatePlaceholder(ui.getPlaceholder(), getPlaceholder(),
				rep == null ? null : rep.getPlaceholder(), ui));
		setObject(evaluatePlaceholder(ui.getObject(), getObject(), 
				rep == null ? null : rep.getObject(), ui));
		setNoFocusOnReadonly(evaluatePlaceholder(ui.getNoFocusOnReadonly(), getNoFocusOnReadonly(),
				rep == null ? null : rep.getNoFocusOnReadonly(), ui));
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します.<br/>
	 * 
	 * @create 2011/08/19
	 * @param builder {@link GTagBuilder}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_FORMAT_KEY), getFormat());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_LOCALE_KEY), getLocale());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY),
				XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
		builder.setAttribute("type", INPUT_TYPE);
		builder.setAttribute("autocomplete", getAutocomplete());
		builder.setAttribute("maxlength", getMaxlength());
		builder.setAttribute("size", getSize());
		builder.setAttribute("value", getValue());
		if (isReadonly()) {
			builder.setAttribute("readonly", "readonly");
			if (isNoFocusOnReadonly()) {
				builder.setAttribute("tabindex", "-1");
			}
		}
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します.<br/>
	 * 
	 * @create 2011/08/19
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(READONLY_STYLECLASS, isReadonly());
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * autocomplete属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAutocomplete() {
		return _autocomplete;
	}

	/**
	 * format属性の値を取得します.<br />
	 * 
	 * @create 2011/08/26
	 * @return 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFormat() {
		return _format;
	}

	/**
	 * locale属性の値を取得します.<br />
	 * 
	 * @create 2011/08/26
	 * @return ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLocale() {
		return _locale;
	}

	/**
	 * maxlength属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMaxlength() {
		return _maxlength;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * size属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getSize() {
		return _size;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2011/08/19
	 * @return value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValue() {
		Object object = getObject();
		String value = object == null ? null : object.toString();
		if (object instanceof Date) {
			value = GUIUtils.formatDateToString((Date) object, _format, GCoreUtils.getLocale(_locale));
		} else if (object instanceof Number) {
			value = GUIUtils.formatNumberToString((Number) object, _format, GCoreUtils.getLocale(_locale));
		}
		return value;
	}
	
	/**
	 * value属性の値をObject型で取得します.<br />
	 * 
	 * @create 2014/06/02
	 * @return value属性の値
	 * @author yoshida
	 * @since 3.16.0
	 */
	public Object getObject() {
		return _object;
	}

	/**
	 * 状態の読み込み専用/書き込み可能を判定します.<br>
	 * 
	 * @create 2011/08/19
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}
	
	/**
	 * autocomplete属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param autocomplete autocomplete属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAutocomplete(String autocomplete) {
		_autocomplete = autocomplete;
	}

	/**
	 * format属性の値を設定します.<br />
	 * 
	 * @create 2011/08/26
	 * @param format 書式文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFormat(String format) {
		_format = format;
	}

	/**
	 * locale属性の値を設定します.<br />
	 * 
	 * @create 2011/08/26
	 * @param locale ロケール
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLocale(String locale) {
		_locale = locale;
	}

	/**
	 * maxlength属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param length maxlength属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMaxlength(String length) {
		_maxlength = length;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param readonly readonly属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * size属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param size size属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSize(String size) {
		_size = size;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2011/08/19
	 * @param value value属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValue(String value) {
		setObject(value);
	}
	
	/**
	 * value属性の値をObject型で設定します.<br />
	 * 
	 * @create 2014/06/02
	 * @param object
	 * @author yoshida
	 * @since 3.16.0
	 */
	public void setObject(Object object) {
		_object = object;
	}

	/**
	 *　placeholder属性の値を設定します。
	 * 
	 * @param placeholder placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public void setPlaceholder(String placeholder) {
		_placeholder = placeholder;
	}
	/**
	 * placeholder属性の値を取得します。
	 * 
	 * @return placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public String getPlaceholder() {
		return _placeholder;
	}

	/**
	 * placeholder用のタグを付加します。
	 * 
	 * @param tagString デコレートするタグ文字列
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @throws JspException 
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	protected String decorateWithPlaceholder(String tagString) throws JspException {
		StringBuilder sb = new StringBuilder();
		if (!GStringUtils.isEmpty(getPlaceholder())) {
			GTagBuilder container = new GTagBuilder("span");
			container.setAttribute("id", getFullId() + PLACEHOLDER_CONTAINER_IDSUFFIX);
			container.setAttribute("class", PLACEHOLDER_CONTAINER_STYLECLASS);
			sb.append(container.createStartTagString());
		}
		sb.append(tagString);
		
		if (!GStringUtils.isEmpty(getPlaceholder())) {
			GTagBuilder placeholder = new GTagBuilder("span");
			placeholder.setAttribute("id", getFullId() + PLACEHOLDER_IDSUFFIX);
			placeholder.setAttribute("class", PLACEHOLDER_STYLECLASS);
			placeholder.setInnerText(getPlaceholder());
			sb.append(placeholder.createStartEndTagString());
			GTagBuilder containerend = new GTagBuilder("span");
			sb.append(containerend.createEndTagString());
			GJavaScriptBuilder js = new GJavaScriptBuilder();
			js.append("$(function(){$.geui.placeholderdecorator.decorate(??);});",getFullId());
			super.bindScript(js.toString());
		}
		return sb.toString();
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 * 
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0 
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 * 
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0 
	 */
	public void setNoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 * 
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}
}
