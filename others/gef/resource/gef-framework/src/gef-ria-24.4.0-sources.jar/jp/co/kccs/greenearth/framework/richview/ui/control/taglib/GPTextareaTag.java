/*
 * Copyright 2013-2018 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPTextarea;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * テキストエリアコントロールを表示するタグクラスです.<br />
 * 
 * @create 2013/03/14
 * @author KCCS kikuchi
 * @since 3.10.0.D
 */
@TargetUIComponent(GPTextarea.class)
public class GPTextareaTag extends GVariableControlBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4348232535059377697L;
	/** デフォルトのスタイルシートのクラス名. */
	static final String DEFAULT_STYLECLASS = "ui-widget ui-widget-content ui-corner-all geui-gptextarea";
	/** disabledスタイルシートのクラス名. */
	static final String DISABLED_STYLECLASS = "geui-gptextarea-disabled ui-state-disabled";
	/** readonlyスタイルシートのクラス名. */
	static final String READONLY_STYLECLASS = "geui-gptextarea-readonly";
	/** プレースホルダーコンテナのID SUFFIX*/
	static final String PLACEHOLDER_CONTAINER_IDSUFFIX = "-placeholder-container";
	/** プレースホルダーコンテナのスタイルシートのクラス名 */
	static final String PLACEHOLDER_CONTAINER_STYLECLASS = "geui-placeholder-container";
	/** プレースホルダーのID SUFFIX*/
	static final String PLACEHOLDER_IDSUFFIX = "-placeholder";
	/** プレースホルダーのスタイルシートのクラス名*/
	static final String PLACEHOLDER_STYLECLASS = "geui-placeholder";
	/** 【XHTML拡張属性】タグ名. */
	// ダイアログ(autoReset=true)上でクライアントリセット機能を利用し、javascriptのform.reset()が実行されると、textareaの値がロストする（IE11でのみ発生）。
	// 本来textarea用ハンドラは不要だが、上記の問題を回避するためにハンドラを作成。
	static final String XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE = "gptextarea";
	
	// XHTML属性
	/** cols属性の値. */
	private String _cols = null;
	/** readonly属性の値. */
	private String _readonly = null;
	/** rows属性の値. */
	private String _rows = null;
	/** wrap属性の値. */
	private String _wrap = null;

	// 内部変数
	/** value属性の値. */
	private String _value = null;
	/** タグに関連付けられたコンポーネント. */ 
	private GUIComponent _component;
	/** placeholder属性の値. */
	private String _placeholder = null;

	/** noFocusOnReadonly属性の値 */
	private String _noFocusOnReadonly = null;

	/**
	 * {@link GPTextareaTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/14
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public GPTextareaTag() {
	}
	
	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2013/03/14
	 * @return XHTML文字列
	 * @author kikuchi
	 * @throws JspException 
	 * @since 3.10.0.D
	 */
	@Override
	public String createXhtmlString() throws JspException {
		GTagBuilder builder = new GTagBuilder("textarea");
		decorateAttribute(builder);
		StringBuilder xml = new StringBuilder();
		xml.append(builder.createStartTagString());
		xml.append(System.getProperty("line.separator"));
		String innerText = GTextareaUtils.escapeSpecialChars(getValue());
		if (innerText != null) {
			xml.append(innerText);
		}
		xml.append(builder.createEndTagString());
		if (isEnabled() && !isReadonly()) {
			return decorateWithPlaceholder(xml.toString());
		}
		return xml.toString();
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2013/03/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public int doEndTag() throws JspException {
		GPTextarea textarea = (GPTextarea) _component;
		GPTextarea repository = (GPTextarea) _component.getRepository();
		setValue(evaluatePlaceholder(textarea.getValue(), getValue(),
			repository == null ? null : repository.getValue(), textarea));
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
		}
		int result = super.doEndTag();
		reset();
		return result;
	}
	
	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2013/03/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を処理します。 
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * 以下の属性を読み込みます。<br />
	 * ・cols,readonly,rows,wrap,value<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.rich.ui.control.taglib.GRFieldControlBaseTag
	 * #load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2013/03/14
	 * @param component レンダリング対象UIコンポーネント
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GPTextarea ui = (GPTextarea) component;
		GPTextarea rep = (GPTextarea) component.getRepository();
		setCols(evaluatePlaceholder(ui.getCols(), getCols(),
				rep == null ? null : rep.getCols(), ui));
		setReadonly(evaluatePlaceholder(ui.getReadonly(), getReadonly(),
				rep == null ? null : rep.getReadonly(), ui));
		setRows(evaluatePlaceholder(ui.getRows(), getRows(),
				rep == null ? null : rep.getRows(), ui));
		setWrap(evaluatePlaceholder(ui.getWrap(), getWrap(),
				rep == null ? null : rep.getWrap(), ui));
		setValue(evaluatePlaceholder(ui.getValue(), getValue(),
				rep == null ? null : rep.getValue(), ui));
		setPlaceholder(evaluatePlaceholder(ui.getPlaceholder(), getPlaceholder(),
				rep == null ? null : rep.getPlaceholder(), ui));
		setNoFocusOnReadonly(evaluatePlaceholder(ui.getNoFocusOnReadonly(), getNoFocusOnReadonly(),
				rep == null ? null : rep.getNoFocusOnReadonly(), ui));
		_component = component;
	}
	
	/**
	 * 指定されたタグにこのタグの属性を追加します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GVariableControlBaseTag
	 * #decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2013/03/14
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY), getValue());
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_TAG_KEY),
				XHTML_EXTENSION_ATTRIBUTE_TAG_VALUE);
		builder.setAttribute("cols", getCols());
		builder.setAttribute("rows", getRows());
		builder.setAttribute("wrap", getWrap());
		if (isReadonly()) {
			builder.setAttribute("readonly", "readonly");
			if (isNoFocusOnReadonly()) {
				builder.setAttribute("tabindex", "-1");
			}
		}
	}
	
	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します.<br/>
	 * 
	 * @create 2013/03/14
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		GStyleClass styleclass = getDecodeStyleclass();
		styleclass.add(DEFAULT_STYLECLASS);
		super.toggleStyleClassAttribute(READONLY_STYLECLASS, isReadonly());
		super.toggleStyleClassAttribute(DISABLED_STYLECLASS, !isEnabled());
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2013/03/14
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		_component = null;
	}

	/**
	 * cols属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return cols属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getCols() {
		return _cols;
	}

	/**
	 * readonly属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return readonly属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getReadonly() {
		return _readonly;
	}

	/**
	 * rows属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return rows属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getRows() {
		return _rows;
	}

	/**
	 * value属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getValue() {
		return _value;
	}
	
	/**
	 * wrap属性の値を取得します.<br />
	 * 
	 * @create 2013/03/14
	 * @return wrap属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public String getWrap() {
		return _wrap;
	}

	/**
	 * 状態の読み込み専用 / 書き込み可能を判定します.<br>
	 * 
	 * @create 2013/03/14
	 * @return <code>true<code>：読み取り専用 / <code>false<code>：書き込み可能
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public boolean isReadonly() {
		return GBooleanUtils.toBoolean(_readonly, false);
	}

	/**
	 * cols属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param cols cols属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setCols(String cols) {
		_cols = cols;
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param readonly readonly属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setReadonly(boolean readonly) {
		_readonly = String.valueOf(readonly);
	}

	/**
	 * readonly属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param readonly readonly属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setReadonly(String readonly) {
		_readonly = readonly;
	}

	/**
	 * rows属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param rows rows属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setRows(String rows) {
		_rows = rows;
	}

	/**
	 * value属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param value value属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setValue(String value) {
		_value = value;
	}

	/**
	 * wrap属性の値を設定します.<br />
	 * 
	 * @create 2013/03/14
	 * @param wrap wrap属性の値
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public void setWrap(String wrap) {
		_wrap = wrap;
	}
	
	/**
	 *　placeholder属性の値を設定します。
	 * 
	 * @param placeholder placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public void setPlaceholder(String placeholder) {
		_placeholder = placeholder;
	}
	/**
	 * placeholder属性の値を取得します。
	 * 
	 * @return placeholder属性の値
	 * @author kawakami
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public String getPlaceholder() {
		return _placeholder;
	}

	/**
	 * placeholder用のタグを付加します。
	 * 
	 * @param tagString デコレートするタグ文字列
	 * @return HTMLタグ文字列
	 * @author kawakami
	 * @throws JspException 
	 * @create 2013/07/29
	 * @since 3.12.0
	 */
	public String decorateWithPlaceholder(String tagString) throws JspException {
		StringBuilder sb = new StringBuilder();
		if (!GStringUtils.isEmpty(getPlaceholder())) {
			GTagBuilder container = new GTagBuilder("span");
			container.setAttribute("id", getFullId() + PLACEHOLDER_CONTAINER_IDSUFFIX);
			container.setAttribute("class", PLACEHOLDER_CONTAINER_STYLECLASS);
			sb.append(container.createStartTagString());
		}
		sb.append(tagString);
		
		if (!GStringUtils.isEmpty(getPlaceholder())) {
			GTagBuilder placeholder = new GTagBuilder("span");
			placeholder.setAttribute("id", getFullId() + PLACEHOLDER_IDSUFFIX);
			placeholder.setAttribute("class", PLACEHOLDER_STYLECLASS);
			placeholder.setInnerText(getPlaceholder());
			sb.append(placeholder.createStartEndTagString());
			GTagBuilder containerend = new GTagBuilder("span");
			sb.append(containerend.createEndTagString());
			GJavaScriptBuilder js = new GJavaScriptBuilder();
			js.append("$(function(){$.geui.placeholderdecorator.decorate(??);});",getFullId());
			super.bindScript(js.toString());
		}
		return sb.toString();
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 * 
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0 
	 */
	public void setNoFocusOnReadonly(boolean noFocusOnReadonly) {
		_noFocusOnReadonly = String.valueOf(noFocusOnReadonly);
	}

	/**
	 * noFocusOnReadonly属性の値を設定します.<br />
	 * 
	 * @param noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0 
	 */
	public void setNoFocusOnReadonly(String noFocusOnReadonly) {
		_noFocusOnReadonly = noFocusOnReadonly;
	}

	/**
	 * noFocusOnReadonly属性を取得します.<br />
	 * 
	 * @return noFocusOnReadonly属性の値
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public String getNoFocusOnReadonly() {
		return _noFocusOnReadonly;
	}

	/**
	 * 読み込み専用の際にフォーカスを当てないかを判定します.<br />
	 * 
	 * @return <code>true</code>：フォーカスを当てない/<code>false</code>：フォーカスを当てる
	 * @author nakamura
	 * @create 2015/12/14
	 * @since 3.17.0
	 */
	public boolean isNoFocusOnReadonly() {
		return GBooleanUtils.toBoolean(_noFocusOnReadonly, GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(
				UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY, "false")));
	}
}
