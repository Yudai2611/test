/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.BodyTagSupport;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.framework.richview.ui.control.GPTextareaValue;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * テキストエリアコントロールの内部テキストを表すタグクラスです.<br />
 * 
 * @create 2013/03/14
 * @author kikuchi
 * @since 3.10.0.D
 */
@TargetUIComponent(GPTextareaValue.class)
public class GPTextareaValueTag extends BodyTagSupport {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5661431847673566245L;

	/**
	 * {@link GPTextareaValueTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * デフォルトコンストラクタ.<br />
	 * 
	 * @create 2013/03/14
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public GPTextareaValueTag() {
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * bodyContentを親クラスのvalueにセットします。<br />
	 * 
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @return <code>0</code>
	 * @throws JspException Error
	 * @create 2013/03/14
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	@Override
	public int doEndTag() throws JspException {
		Tag tag = getParent();
		if (!(tag instanceof GPTextareaTag)) {
			throw new JspException("Not Found textarea tag.");
		}
		GPTextareaTag textareaTag = (GPTextareaTag) tag;
		textareaTag.setValue(bodyContent == null ? null : bodyContent.getString());
		return EVAL_PAGE;
	}
}
