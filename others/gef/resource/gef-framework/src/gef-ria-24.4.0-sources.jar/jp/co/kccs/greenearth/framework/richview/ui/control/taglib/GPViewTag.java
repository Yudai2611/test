/*
 * Copyright 2013-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GScriptBufferedWriterTag;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GView;
import jp.co.kccs.greenearth.framework.view.component.GViewFactory;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GViewBaseTag;

/**
 * ビューを表現するタグクラスです.<br/>
 * 
 * @create 2013/03/26
 * @author KCCS KCCS yamashita
 * @since 3.10.0.D
 */
@TargetUIComponent(GView.class)
public class GPViewTag extends GViewBaseTag implements GScriptBufferedWriterTag {
// TODO [2020/07/13][yamashita]Type(base/include)の概念を削除したため、GScriptBufferedWriterTagの実装を無くせるか検討する。現状writeScriptはダミー実装

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5336170161575778936L;
	
	/** スクリプトバッファーキー */
	static final String INCLUDE_SCRIPT_BUFFER_KEY = "geframe.richview.Include.ScriptBuffer.Key";
	/** エスケープ済みJavaScript文字列をバッファ. */
	StringBuilder _parts = new StringBuilder();
	/** エスケープ済みHTML文字列をバッファ.*/
	StringBuilder _elements = new StringBuilder();

	/**
	 * {@link GPViewTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/26
	 * @auther KCCS yamashita
	 * @since 3.10.0.D
	 */
	public GPViewTag() {
	}

	/**
	 * エレメントを追加します.<br />
	 * 
	 * @create 2013/03/26
	 * @param element HTML文字列
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public void appendElement(String element) {
		_elements.append(GStringUtils.nullToBlank(element));
	}

	/**
	 * JavaScript文字列を追加します.<br />
	 * 
	 * @create 2013/03/26
	 * @param parts javascript文字列
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	public void appendParts(String parts) {
		_parts.append(GStringUtils.nullToBlank(parts));
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2013/03/26
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public int doEndTag() throws JspException {
		writeScript();
		return super.doEndTag();
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2013/03/26
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void reset() {
		super.reset();
		_parts = new StringBuilder();
		_elements = new StringBuilder();
	}

	/**
	 * {@link GViewInterface}オブジェクトを取得します.
	 *
	 * @create 2020/09/04
	 * @param request HTTPリクエスト
	 * @return {@link GViewInterface}オブジェクト
	 * @throws GViewException ビューの取得に失敗した場合
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Deprecated
	protected GViewInterface getView(HttpServletRequest request) throws GViewException {
		String servletPath = getServletPath(request);
		GViewInterface view = GViewFactory.getView(servletPath, request);
		return view;
	}

	/**
	 * このタグが所属するJSPのパスを取得します.<br>
	 * このビューが基底のJSPなら{@link HttpServletRequest#getServletPath()}で取得されるパスを、
	 * このビューが別のJSPにインクルードされたJSPなら<code>request</code>に積まれている
	 * インクルードJSPのパスを取り出し返します。
	 *
	 * @create 2006/12/29
	 * @param request HTTPリクエスト
	 * @return JSPパス
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	protected String getServletPath(HttpServletRequest request) {
		return request.getServletPath();
	}

	/**
	 * 対象となる要素のタグ終了時点で、要素にバインドされたスクリプトを一括して出力します.<br />
	 * ※インクルード先のViewはコンテンツ内のスクリプトを出力しますが、インクルード元となる本クラスは何も出力しません。
	 * 
	 * @create 2013/03/26
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author KCCS yamashita
	 * @since 3.10.0.D
	 */
	@Override
	public void writeScript() throws JspException {
	}
}
