/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.framework.richview.ui.control.GSelectOption;

/**
 * {@link GPSelectTag}と{@link GSelectMenuTag}をシームレスに扱うためのインターフェイスです.<br />
 * 
 * @create 2011/06/01
 * @author hamanaka
 * @since 3.9.0
 */
public interface GSelectTag {

	/**
	 * 次のオプションを取得します.<br />
	 * 
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @create 2011/05/16
	 * @return 次のオプション
	 * @author hamanaka
	 * @since 3.9.0
	 */
	@Deprecated
	public GSelectOption getNextSelectOption();

	/**
	 * {@link GOptionTag}に対して処理を行います.<br>
	 * 
	 * 指定された{@link GOptionTag}のselectedフィールドを<code>"true"</code>にします。 接頭辞文字列を
	 * {@link GOptionTag}のidフィールドにも付加します。
	 * 
	 * @create 2011/05/30
	 * @param optionTag {@link GOptionTag}オブジェクト
	 * @param option オプション
	 * @author hamanaka
	 * @since 3.9.0
	 */
	public void influenceOption(GPOptionTag optionTag, GSelectOption option);

}
