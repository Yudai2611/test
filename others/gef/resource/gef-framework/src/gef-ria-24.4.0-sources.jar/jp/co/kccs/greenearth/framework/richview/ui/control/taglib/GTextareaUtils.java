/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;


/**
 * XHTMLのテキストエリアをレンダリングするときに使用できるユーティリティ.<br />
 * 
 * @create 2013/03/15
 * @author yamashita
 * @since 3.10.0.D
 */
public class GTextareaUtils {

	/**
	 * {@link GTextareaUtils}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/03/15
	 * @author yamashita
	 * @since 3.10.0.D
	 */
	public GTextareaUtils() {
	}

	/**
	 * タグが内包する文字列を取得します。<br>
	 * 
	 * 取得できる文字列に「&amp;gt;」や「&amp;amp;」等の文字が含まれる場合はエスケープして返します。<br>
	 * 以下の文字がエスケープ対象となります。<br>
	 * [1]<code>'&lt;'</code> -> <code>"&amp;lt;"</code><br>
	 * [2]<code>'&gt;'</code> -> <code>"&amp;gt;"</code><br>
	 * [3]<code>'&amp;'</code> -> <code>"&amp;amp;"</code><br>
	 * [4]<code>'\"'</code> -> <code>"&amp;quot;"</code><br>
	 * [5]<code>'\''</code> -> <code>"&amp;#39;"</code><br>
	 * <br>
	 * 通常は半角スペースもエスケープする必要がありますが、<br>
	 * エスケープした半角スペースをブラウザが表示した場合に、再度その値からリクエスト値を生成する際に
	 * 正しく値が変換されないため、半角スペースのみエスケープを行っていません。<br>
	 * 
	 * @create 2013/03/14
	 * @return エスケープ後の内包する文字列
	 * @author kikuchi
	 * @since 3.10.0.D
	 */
	public static String escapeSpecialChars(String value) {
		if (value == null) {
			return null;
		}
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			switch (value.charAt(i)) {
				// エスケープ文字の置換
				case '<' :
					builder.append("&lt;");
					break;
				case '>' :
					builder.append("&gt;");
					break;
				case '&' :
					builder.append("&amp;");
					break;
				case '\"' :
					builder.append("&quot;");
					break;
				case '\'' :
					builder.append("&#39;");
					break;
				// 非エスケープ文字の置換
				default :
					builder.append(value.charAt(i));
					break;
			}
		}
		return builder.toString();
	}
}
