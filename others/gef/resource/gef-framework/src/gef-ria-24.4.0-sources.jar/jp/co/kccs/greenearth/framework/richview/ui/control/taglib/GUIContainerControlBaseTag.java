/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.control.GUIContainerControlBase;
import jp.co.kccs.greenearth.framework.richview.ui.key.GEnterkeyFocus;
import jp.co.kccs.greenearth.framework.richview.ui.key.GKeyBind;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.taglib.GContainerTag;

/**
 * {@link GUIContainerControlBase}のレンダリング用カスタムタグを表します.<br />
 * 
 * @create 2011/04/04
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIContainerControlBaseTag extends GUIControlBaseTag implements GContainerTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5355321940565949988L;

	// 内部変数
	/** タグに関連付けられたコンポーネント. */
	private GUIComponent _component;
	/** エンターキーフォーカス */
	private GEnterkeyFocus _enterkeyFocus;
	/** キーバインド一覧 */
	private List<GKeyBind> _keyBinds = new ArrayList<GKeyBind>();
	/** キーバインド一覧カーソル*/
	private Iterator<GKeyBind> _keyBindIterator;

	/**
	 * {@link GUIContainerControlBaseTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIContainerControlBaseTag() {
		reset();
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/04/04
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GUIContainerControlBase ui = (GUIContainerControlBase) component;
		setControls(ui.getControls());
		setEnterkeyFocus(ui.getEnterkeyFocus());
		setKeyBinds(ui.getKeyBinds());
		setAssociatedComponent(component);
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 *
	 * @create 2015/11/17
	 * @author nakamura
	 * @since 3.17.0
	 */
	@Override
	public void reset() {
		super.reset();
		_enterkeyFocus = null;
		_keyBindIterator = null;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br>
	 *
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doEndTag()
	 * @create 2015/11/17
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author nakamura
	 * @since 3.17.0
	 */
	@Override
	public int doEndTag() throws JspException {
		int result = super.doEndTag();
		reset();
		return result;
	}
	/**
	 * タグに関連付けられたコンポーネントを取得します.<br />
	 * 
	 * @create 2011/06/11
	 * @return コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponent getAssociatedComponent() {
		return _component;
	}

	/**
	 * 子タグのコントロールのリストから指定された名前の{@link GUIControl}を取得します.<br>
	 * 
	 * @create 2011/04/04
	 * @param id コントロールのid
	 * @return {@link GUIControl}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControl getControl(String id) {
		for (GUIControl control : getControls()) {
			if (id.equals(control.getId())) {
				return control;
			}
		}
		return null;
	}

	/**
	 * コンテナとして格納している子UIコントロールのリストを取得します.<br>
	 * 
	 * @create 2011/03/30
	 * @return 子UIコントロールのリストオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GUIControl> getControls() {
		if (_controls == null) {
			_controls = new ArrayList<GUIControl>();
		}
		return _controls;
	}

	/**
	 * Enterキーフォーカス制御を返します.<br />
	 * 
	 * @create 2015/11/17
	 * @param keyBinds キー制御一覧
	 * @author nakamura
	 * @since 3.17.0
	 */
	public GEnterkeyFocus getEnterkeyFocus() {
		return _enterkeyFocus;
	}

	/**
	 * キー制御一覧を返します.<br />
	 * 
	 * @create 2015/11/17
	 * @param keyBinds キー制御一覧
	 * @author nakamura
	 * @since 3.17.0
	 */
	public List<GKeyBind> getKeyBinds() {
		return _keyBinds;
	}

	/**
	 * 現在のｷｰ制御を返します.<br />
	 * 
	 * @create 2015/11/17
	 * @param keyBinds キー制御一覧
	 * @author nakamura
	 * @since 3.17.0
	 */
	public GKeyBind currentKeyBind() {
		if (_keyBindIterator != null && _keyBindIterator.hasNext()) {
			return _keyBindIterator.next();
		}
		return null;
	}

	/**
	 * タグに関連付けられたコンポーネントを設定します.<br />
	 * 
	 * @create 2011/06/11
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAssociatedComponent(GUIComponent component) {
		_component = component;
	}

	/**
	 * コンテナとして格納する子UIコントロールのリストを設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param controls 子UIコントロールのリストオブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setControls(List<GUIControl> controls) {
		_controls = controls;
	}

	/**
	 * Enterキーフォーカス制御を設定します.<br />
	 * 
	 * @create 2015/11/17
	 * @param keyBinds キー制御一覧
	 * @author nakamura
	 * @since 3.17.0
	 */
	public void setEnterkeyFocus(GEnterkeyFocus enterkeyFocus) {
		_enterkeyFocus = enterkeyFocus;
	}

	/**
	 * キー制御一覧を設定します.<br />
	 * 
	 * @create 2015/11/17
	 * @param keyBinds キー制御一覧
	 * @author nakamura
	 * @since 3.17.0
	 */
	public void setKeyBinds(List<GKeyBind> keyBinds) {
		_keyBinds = keyBinds;
		_keyBindIterator = keyBinds.iterator();
	}
}
