/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import java.util.List;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GContainerTag;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagUtils;

/**
 * {@link GUIControlBase}のレンダリング用カスタムタグを表します.<br />
 * 
 * @create 2011/04/04
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIControlBaseTag extends GUIComponentBaseTag {

		/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5110289937287274973L;
	// XHTML属性
	/** accesskey属性の値. */
	private String _accesskey = null;
	/** tabindex属性の値. */
	private String _tabindex = null;
	/** onblur属性の値. */
	private String _onblur = null;
	/** onchange属性の値. */
	private String _onchange = null;
	/** onfocus属性の値. */
	private String _onfocus = null;
	/** onselect属性の値. */
	private String _onselect = null;

	// 拡張属性
	/** label属性の値. */
	private String _label = null;
	/** labelid属性の値. */
	private String _labelid = null;
	/** 送信パラメータのキー. */
	private String _parameterKey;

	// 内部変数
	/** {@link GUIControl}オブジェクトのリスト. */
	protected List<GUIControl> _controls;

	/**
	 * {@link GUIControlBaseTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIControlBaseTag() {
	}

	/**
	 * XHTML文字列を生成します.<br />
	 * 
	 * @create 2011/05/17
	 * @return XHTML文字列
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public abstract String createXhtmlString() throws JspException;

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br>
	 * 
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doStartTag()
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}
	 *         :ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}
	 *         :ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException タグの書き込みに失敗した場合
	 * @create 2011/05/17
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetControl();
		if (isVisible()) {
			GTagUtils.printOut(pageContext, createXhtmlString());
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2011/04/04
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GUIControlBase ui = (GUIControlBase) component;
		GUIControlBase rep = (GUIControlBase) component.getRepository();
		setAccesskey(evaluatePlaceholder(ui.getAccesskey(), getAccesskey(),
				rep == null ? null : rep.getAccesskey(), ui));
		setTabindex(evaluatePlaceholder(ui.getTabindex(), getTabindex(),
				rep == null ? null : rep.getTabindex(), ui));
		setOnblur(evaluatePlaceholder(ui.getOnblur(), getOnblur(),
				rep == null ? null : rep.getOnblur(), ui));
		setOnchange(evaluatePlaceholder(ui.getOnchange(), getOnchange(),
				rep == null ? null : rep.getOnchange(), ui));
		setOnfocus(evaluatePlaceholder(ui.getOnfocus(), getOnfocus(),
				rep == null ? null : rep.getOnfocus(), ui));
		setOnselect(evaluatePlaceholder(ui.getOnselect(), getOnselect(),
				rep == null ? null : rep.getOnselect(), ui));
		setLabel(evaluatePlaceholder(ui.getLabel(), getLabel(),
				rep == null ? null : rep.getLabel(), ui));
		setLabelid(evaluatePlaceholder(ui.getLabelid(), getLabelid(),
				rep == null ? null : rep.getLabelid(), ui));
		setControls(ui.getChildren());
		setParameterKey(ui.getParameterKey());
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#reset()
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		setPrefix(null);
		_controls = null;
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/04/04
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("accesskey", getAccesskey());
		builder.setAttribute("tabindex", getTabindex());
	}

	/**
	 * 指定されたタグにこのタグのイベントハンドラ属性を追加します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateEventAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/04/04
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateEventAttribute(GTagBuilder builder) {
		super.decorateEventAttribute(builder);
		builder.setAttribute("onblur", getOnblur());
		builder.setAttribute("onchange", getOnchange());
		builder.setAttribute("onfocus", getOnfocus());
		builder.setAttribute("onselect", getOnselect());
	}

	/**
	 * 親タグより、自分がターゲットとするUIコントロールを取得し、読み込みます.<br>
	 * 
	 * {@link TargetUIComponent} アノテーションで指定したUIコントロールでない場合は、
	 * {@link ClassCastException}をスローします。
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void loadTargetControl() {
		Tag parent = findAncestorWithClass(this, GContainerTag.class);
		if (parent == null) {
			return;
		}
		GContainerTag container = (GContainerTag) parent;
		GUIControl control = container.getControl(getId());
		if (control == null) {
			return;
		}
		TargetUIComponent annotation = getClass().getAnnotation(TargetUIComponent.class);
		if (annotation == null) {
			throw new ClassCastException("Not found TargetUIComponent annotation. \"" + getClass().getName() + "\"");
		}
		Class< ? > uiClass = annotation.value();
		if (uiClass == null) {
			throw new ClassCastException("Not found uiClass, for TargetUIComponent annotation value. \""
				+ getClass().getName() + "\"");
		}
		if (uiClass.isAssignableFrom(control.getClass())) {
			load(control);
		} else {
			throw new ClassCastException("\"" + getId() + "\" is " + control.getClass().getName() + ".");
		}
	}

	/**
	 * accesskey属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return accesskey属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAccesskey() {
		return _accesskey;
	}

	/**
	 * label属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return label属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLabel() {
		return _label;
	}
	
	/**
	 * labelid属性の値を取得します.<br />
	 * 
	 * @return labelid属性の値
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public String getLabelid() {
		return _labelid;
	}

	/**
	 * onblur属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return onblur属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnblur() {
		return _onblur;
	}

	/**
	 * onchange属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return onchange属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnchange() {
		return _onchange;
	}

	/**
	 * onfocus属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return onfocus属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnfocus() {
		return _onfocus;
	}

	/**
	 * onselect属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return onselect属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnselect() {
		return _onselect;
	}

	/**
	 * 送信パラメータのキーを取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return 送信パラメータのキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getParameterKey() {
		return _parameterKey;
	}

	/**
	 * tabindex属性の値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return tabindex属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getTabindex() {
		return _tabindex;
	}

	/**
	 * accesskey属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param accesskey accesskey属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAccesskey(String accesskey) {
		_accesskey = accesskey;
	}

	/**
	 * {@link GUIControl}オブジェクトのリストを設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param controls {@link GUIControl}オブジェクトのリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setControls(List<GUIControl> controls) {
		_controls = controls;
	}

	/**
	 * label属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param label label属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLabel(String label) {
		_label = label;
	}
	
	/**
	 * labelid属性の値を設定します.<br />
	 * 
	 * @param labelid
	 * @create 2014/06/12
	 * @author KCCS S.Yoshida
	 * @since 3.16.0
	 */
	public void setLabelid( String labelid) {
		_labelid = labelid;
	}

	/**
	 * onblur属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param onblur onblur属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnblur(String onblur) {
		_onblur = onblur;
	}

	/**
	 * onchange属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param onchange onchange属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnchange(String onchange) {
		_onchange = onchange;
	}

	/**
	 * onfocus属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param onfocus onfocus属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnfocus(String onfocus) {
		_onfocus = onfocus;
	}

	/**
	 * onselect属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param onselect onselect属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnselect(String onselect) {
		_onselect = onselect;
	}

	/**
	 * 送信パラメータのキーを設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param parameterKey 送信パラメータのキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setParameterKey(String parameterKey) {
		_parameterKey = parameterKey;
	}

	/**
	 * tabindex属性の値を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param tabindex tabindex属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTabindex(String tabindex) {
		_tabindex = tabindex;
	}
}
