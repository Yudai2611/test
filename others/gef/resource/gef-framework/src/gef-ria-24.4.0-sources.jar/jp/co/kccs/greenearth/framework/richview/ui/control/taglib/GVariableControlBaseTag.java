/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControlBase;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * {@link GVariableControlBase}のレンダリング用カスタムタグを表します.<br />
 * 
 * @create 2011/04/04
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GVariableControlBaseTag extends GUIControlBaseTag implements GVariableControlTag, GEnablableTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 9149586592073562693L;
	/** エラーレベル:INFOのCSSクラス名 */
	public static final String ERROR_LEVEL_INFO_CLASSNAME = "geui-errorlevel-info";
	/** エラーレベル:WARNのCSSクラス名 */
	public static final String ERROR_LEVEL_WARN_CLASSNAME = "geui-errorlevel-warn";
	/** エラーレベル:ERRORのCSSクラス名 */	
	public static final String ERROR_LEVEL_ERROR_CLASSNAME = "geui-errorlevel-error";
	/** ウィジェット属性名:DISABLED */
	public static final String WIDGET_OPTIONS_KEY_DISABLED = "disabled";
	/** ウィジェット属性名:READONOY */
	public static final String WIDGET_OPTIONS_KEY_READONLY = "readonly";
	/** ウィジェット属性名:CLEAR */
	public static final String WIDGET_OPTIONS_KEY_CLEAR = "clear";

	// XHTML属性
	/** name属性の値. */
	private String _name = null;

	// 拡張属性
	/** clear属性の値. */
	private String _clear = null;
	/** enabled属性の値. */
	private String _enabled = null;
	/** required属性の値. */
	private String _required = null;
	/** {@link GErrorLevel}オブジェクト. */
	private GErrorLevel _errorlevel = GErrorLevel.NONE;

	/**
	 * {@link GVariableControlBaseTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/04/04
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GVariableControlBaseTag() {
	}

	/**
	 * hiddenタグのBuilderを生成します.<br />
	 * ※各Valiableコントロールの処理を共通化<br/>
	 * 
	 * @create 2020/07/31
	 * @return hiddenのXHTML文字列
	 * @author yamashita
	 * @since 20.9.0
	 */
	protected GTagBuilder createHiddenTagBuilder() {
		GTagBuilder builder = new GTagBuilder("input");
		builder.setAttribute("type", "hidden");
		builder.setAttribute("id", getFullId() + "_hdn");
		builder.setAttribute("name", getParameterKey());
		builder.setAttribute("value", getValue());
		return builder;
	}

	/**
	 * hiddenタグのXHTML文字列を生成します.<br />
	 * ※各Valiableコントロールの処理を共通化<br/>
	 * 
	 * @create 2020/07/31
	 * @return hiddenのXHTML文字列
	 * @author yamashita
	 * @since 20.9.0
	 */
	protected String createHiddenTagString() {
		return createHiddenTagBuilder().createTagString();
	}

	/**
	 * valueを取得します.<br />
	 * ※Variableコントロールの値取得を抽象化したメソッドです。<br/>
	 * ※valueに相当する属性は、各Variableコントロールによって異なります。<br/>
	 * 
	 * @create 2020/07/31
	 * @return value
	 * @author yamashita
	 * @since 20.9.0
	 */
	protected abstract String getValue();
	
	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br />
	 * 
	 * @create 2011/04/04
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GVariableControlBase ui = (GVariableControlBase) component;
		GVariableControlBase rep = (GVariableControlBase) component.getRepository();
		setName(ui.getName());
		setEnabled(evaluatePlaceholder(ui.getEnabled(), getEnabled(),
				rep == null ? null : rep.getEnabled(), ui));
		setClear(evaluatePlaceholder(ui.getClear(), getClear(),
				rep == null ? null : rep.getClear(), ui));
		setRequired(evaluatePlaceholder(ui.getRequired(), getRequired(),
				rep == null ? null : rep.getRequired(), ui));
		setErrorlevel(ui.getErrorlevel());
	}

	/**
	 * 指定されたタグビルダーにこのタグの基本属性を追加します.<br />
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GUIControlBaseTag#decorateAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/04/04
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateAttribute(GTagBuilder builder) {
		super.decorateAttribute(builder);
		builder.setAttribute("name", getParameterKey());
		if (!isWidget()) { // Plainコントロールのみ属性出力する
			if (!isEnabled()) {
				builder.setAttribute("disabled", "disabled");
			}
			builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY), String.valueOf(isClear()));
		}
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイル属性を追加します. <br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateStyleAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/06/25
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author H.Nishida
	 * @since 3.9.0
	 */
	@Override
	protected void decorateStyleAttribute(GTagBuilder builder) {
		super.decorateStyleAttribute(builder);
		GStyleClass styleclass = getDecodeStyleclass();
		if (getErrorlevel() == GErrorLevel.INFO) {
			if (!styleclass.contains(ERROR_LEVEL_INFO_CLASSNAME)) {
				styleclass.add(ERROR_LEVEL_INFO_CLASSNAME);
			}
			styleclass.remove(ERROR_LEVEL_WARN_CLASSNAME);
			styleclass.remove(ERROR_LEVEL_ERROR_CLASSNAME);
		} else if (getErrorlevel() == GErrorLevel.WARNING) {
			if (!styleclass.contains(ERROR_LEVEL_WARN_CLASSNAME)) {
				styleclass.add(ERROR_LEVEL_WARN_CLASSNAME);
			}
			styleclass.remove(ERROR_LEVEL_INFO_CLASSNAME);
			styleclass.remove(ERROR_LEVEL_ERROR_CLASSNAME);
		} else if (getErrorlevel() == GErrorLevel.ERROR) {
			if (!styleclass.contains(ERROR_LEVEL_ERROR_CLASSNAME)) {
				styleclass.add(ERROR_LEVEL_ERROR_CLASSNAME);
			}
			styleclass.remove(ERROR_LEVEL_INFO_CLASSNAME);
			styleclass.remove(ERROR_LEVEL_WARN_CLASSNAME);
		} else {
			styleclass.remove(ERROR_LEVEL_INFO_CLASSNAME);
			styleclass.remove(ERROR_LEVEL_WARN_CLASSNAME);
			styleclass.remove(ERROR_LEVEL_ERROR_CLASSNAME);
		}
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br/>
	 * 
	 * カスタムタグ属性値をXHTMLのoptions属性に出力する場合、 このメソッドをオーバーライドして処理を追加してください。<br>
	 * 引数optionsにカスタムタグ属性値を追加するとXHTMLに出力されます。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateWidgetOptions(jp.co.kccs.greenearth.commons.json.GJSONObject)
	 * @create 2011/06/25
	 * @param options オプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected void decorateWidgetOptions(GJSONObject options) {
		super.decorateWidgetOptions(options);
		if (isWidget()) {
			if (!isEnabled()) {
				setWidgetOptionValue(options, WIDGET_OPTIONS_KEY_DISABLED, true);
			}
			if (!isClear()) {
				setWidgetOptionValue(options, WIDGET_OPTIONS_KEY_CLEAR, false);
			}
		}
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getClear() {
		return _clear;
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getEnabled() {
		return _enabled;
	}

	/**
	 * {@link GErrorLevel}オブジェクトを設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @return エラーレベル {@link GErrorLevel}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GErrorLevel getErrorlevel() {
		return _errorlevel;
	}

	/**
	 * name属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getName() {
		return _name == null ? getId() : _name;
	}

	/**
	 * required属性の値を取得します.<br />
	 * 
	 * @create 2011/04/15
	 * @return <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getRequired() {
		return _required;
	}

	/**
	 * clear属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isClear() {
		return GBooleanUtils.toBoolean(getClear(), true);
	}

	/**
	 * enabled属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isEnabled() {
		return GBooleanUtils.toBoolean(getEnabled(), true);
	}

	/**
	 * required属性の値を取得します.<br />
	 * 
	 * @create 2011/06/14
	 * @return <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isRequired() {
		return GBooleanUtils.toBoolean(getRequired(), false);
	}

	/**
	 * clear属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param clear <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setClear(boolean clear) {
		_clear = String.valueOf(clear);
	}

	/**
	 * clear属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param clear <code>true:クリア対象</code>/<code>false:非クリア対象</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setClear(String clear) {
		_clear = clear;
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param enabled <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setEnabled(boolean enabled) {
		_enabled = String.valueOf(enabled);
	}

	/**
	 * enabled属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param enabled <code>true:タグの有効</code>/<code>false:タグの無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEnabled(String enabled) {
		_enabled = enabled;
	}

	/**
	 * {@link GErrorLbel}オブジェクトを設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param errorlevel {@link GErrorLbel}オブジェクト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setErrorlevel(GErrorLevel errorlevel) {
		_errorlevel = errorlevel;
	}

	/**
	 * name属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param name name属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * required属性の値を設定します.<br />
	 * 
	 * @create 2011/06/14
	 * @param required <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public void setRequired(boolean required) {
		_required = String.valueOf(required);
	}

	/**
	 * required属性の値を設定します.<br />
	 * 
	 * @create 2011/04/15
	 * @param required <code>true:必須入力</code>/<code>false:任意入力</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRequired(String required) {
		_required = required;
	}
}
