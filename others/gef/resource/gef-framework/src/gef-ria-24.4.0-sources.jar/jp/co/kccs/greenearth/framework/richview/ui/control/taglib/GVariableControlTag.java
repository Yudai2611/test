/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.control.taglib;

import jp.co.kccs.greenearth.framework.data.GErrorLevel;

/**
 * {@link jp.co.kccs.greenearth.framework.richview.ui.control.GVariableControl}
 * のレンダリング用カスタムタグを表します.<br />
 * 
 * @create 2011/04/04
 * @author yamashita
 * @since 3.9.0
 */
public interface GVariableControlTag extends GEnablableTag {

	/**
	 * エラーレベルを取得します.<br>
	 * 
	 * @create 2011/04/04
	 * @return エラーレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	GErrorLevel getErrorlevel();

	/**
	 * パラメータのサブミット名を取得します.<br>
	 * 
	 * @create 2011/04/04
	 * @return パラメータのサブミット名
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getName();

	/**
	 * クリア処理の対象にするかを取得します.<br>
	 * 
	 * @create 2011/04/04
	 * @return <code>true:クリア対象</code>/<code>false:クリア対象外</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	boolean isClear();

	/**
	 * タグの有効/無効を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return <code>true:有効</code>/<code>false:無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	boolean isEnabled();

	/**
	 * 入力必須項目であるかを表す値を取得します.<br />
	 * 
	 * @create 2011/04/04
	 * @return <code>true:必須</code>/<code>false:必須でない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	boolean isRequired();

	/**
	 * クリア処理の対象にするかを設定します.<br>
	 * 
	 * @create 2011/04/04
	 * @param clear <code>true:クリア対象</code>/<code>false:クリア対象外</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setClear(boolean clear);

	/**
	 * タグの有効/無効を設定します.<br />
	 * 
	 * @create 2011/04/04
	 * @param enabled <code>true:有効</code>/<code>false:無効</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setEnabled(boolean enabled);

	/**
	 * エラーレベルを設定します.<br>
	 * 
	 * @create 2011/04/04
	 * @param errorlevel エラーレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setErrorlevel(GErrorLevel errorlevel);

	/**
	 * パラメータのサブミット名を設定します.<br>
	 * 
	 * @create 2011/04/04
	 * @param name パラメータのサブミット名
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setName(String name);

	/**
	 * 入力必須項目であるかを表す値を設定します.<br>
	 * true:必須<br>
	 * false:必須でない
	 * 
	 * @create 2011/04/04
	 * @param required <code>true:必須</code>/<code>false:必須でない</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setRequired(boolean required);
}
