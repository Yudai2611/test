/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

/**
 * アクションイベントを示すインターフェイスです.<br />
 * 
 * @create 2011/07/09
 * @author yamashita
 * @since 3.9.0
 */
public interface GActionEvent extends GEvent {

	/**
	 * アクションパラメータを追加します.<br />
	 * 
	 * @create 2011/08/11
	 * @param key パラメータキー
	 * @param value 値
	 * @author yamashita
	 * @since 3.9.0
	 */
	void addActionParam(String key, Object value);

	/**
	 * アクションパラメータを削除します.<br />
	 * 
	 * @create 2011/08/11
	 * @param key パラメータキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	void removeActionParam(String key);

	/**
	 * actionbean属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return アクションビーン
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getActionbean();

	/**
	 * actionmethod属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return アクションメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getActionmethod();

	/**
	 * customdialog属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return カスタムダイアログのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getCustomdialog();

	/**
	 * dialogmsg属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return 確認メッセージ
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getDialogmsg();

	/**
	 * form属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return submit対象フォームのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getForm();

	/**
	 * httpmethod属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return HTTPメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getHttpmethod();

	/**
	 * indicator属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return インジケータのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getIndicator();

	/**
	 * mode属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return モード
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getMode();

	/**
	 * validate属性の値を取得します.<br />
	 * 
	 * @create 2011/07/09
	 * @return 入力検証を行うレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getValidate();

	/**
	 * actionbean属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param actionbean アクションビーン
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setActionbean(String actionbean);

	/**
	 * actionmethod属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param actionmethod アクションメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setActionmethod(String actionmethod);

	/**
	 * customdialog属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param customdialog カスタムダイアログのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setCustomdialog(String customdialog);

	/**
	 * dialogmsg属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param dialogmsg 確認メッセージ
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setDialogmsg(String dialogmsg);

	/**
	 * form属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param form submit対象フォームのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setForm(String form);

	/**
	 * httpmethod属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param httpmethod HTTPメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setHttpmethod(String httpmethod);

	/**
	 * indicator属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param indicator インジケータのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setIndicator(String indicator);

	/**
	 * mode属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param mode モード
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setMode(String mode);

	/**
	 * validate属性の値を設定します.<br />
	 * 
	 * @create 2011/07/09
	 * @param validate 入力検証を行うレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setValidate(String validate);
}
