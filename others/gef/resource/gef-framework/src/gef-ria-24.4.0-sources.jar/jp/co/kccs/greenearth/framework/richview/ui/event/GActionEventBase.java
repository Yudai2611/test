/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;

/**
 * {@link GActionEventBase}は{@link GActionEvent}に指定されるデフォルトの振舞いを提供する、
 * アクションイベントを実装するための基底クラスです.<br>
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GActionEventBase extends GEventBase implements GActionEvent {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4362493902501436784L;

	// 拡張属性
	/** actionbean属性の値. */
	private String _actionbean = null;
	/** actionmethod属性の値. */
	private String _actionmethod = null;
	/** form属性の値. */
	private String _form = null;
	/** mode属性の値. */
	private String _mode = null;
	/** httpmethod属性の値. */
	private String _httpmethod = null;
	/** indicator属性の値. */
	private String _indicator = null;
	/** validate属性の値. */
	private String _validate = GErrorLevel.INFO.toString();

	/**
	 * アクションパラメータを追加します.<br />
	 * 
	 * @create 2011/08/11
	 * @param key パラメータキー
	 * @param value 値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void addActionParam(String key, Object value) {
		GJSONObject options = getDecodeOptions();
		options.put(key, value);
	}

	/**
	 * アクションパラメータを削除します.<br />
	 * 
	 * @create 2011/08/11
	 * @param key パラメータキー
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void removeActionParam(String key) {
		GJSONObject options = getDecodeOptions();
		if (options.containsKey(key)) {
			options.remove(key);
		}
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.event.GEventBase#reset()
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GActionEventBase event = (GActionEventBase) getRepository();
		setActionbean(event == null ? null : event.getActionbean());
		setActionmethod(event == null ? null : event.getActionmethod());
		setForm(event == null ? null : event.getForm());
		setMode(event == null ? null : event.getMode());
		setHttpmethod(event == null ? null : event.getHttpmethod());
		setIndicator(event == null ? null : event.getIndicator());
		setValidate(event == null ? null : event.getValidate());
	}

	/**
	 * actionbean属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return アクションビーン
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getActionbean() {
		return _actionbean;
	}

	/**
	 * actionmethod属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return アクションメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getActionmethod() {
		return _actionmethod;
	}

	/**
	 * form属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return submit対象フォームのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getForm() {
		return _form;
	}

	/**
	 * httpmethod属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return HTTPメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getHttpmethod() {
		return _httpmethod;
	}

	/**
	 * indicator属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return インジケータのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getIndicator() {
		return _indicator;
	}

	/**
	 * mode属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return モード
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMode() {
		return _mode;
	}

	/**
	 * validate属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return 入力検証を行うレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValidate() {
		return _validate;
	}

	/**
	 * actionbean属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param actionbean アクションビーン
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setActionbean(String actionbean) {
		_actionbean = actionbean;
	}

	/**
	 * actionmethod属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param actionmethod アクションメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setActionmethod(String actionmethod) {
		_actionmethod = actionmethod;
	}

	/**
	 * form属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param form submit対象フォームのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setForm(String form) {
		_form = form;
	}

	/**
	 * httpmethod属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param httpmethod HTTPメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHttpmethod(String httpmethod) {
		_httpmethod = httpmethod;
	}

	/**
	 * indicator属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param indicator インジケータのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setIndicator(String indicator) {
		_indicator = indicator;
	}

	/**
	 * mode属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param mode モード
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMode(String mode) {
		_mode = mode;
	}

	/**
	 * validate属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param validate 入力検証を行うレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValidate(String validate) {
		_validate = validate;
	}
}
