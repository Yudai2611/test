/*
 * Copyright 2011-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * ajaxイベントを表すUIコントロールです.<br/>
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public class GAjaxEvent extends GActionEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4001206677255570929L;

	// 拡張属性
	/** レンダリング対象のid属性の値. */
	private String _render = null;
	/** async属性の値. */
	private String _async = null;
	/** upload属性の値. */
	private String _upload = null;

	/** download属性の値. */
	private String _download = null;
	
	/**
	 * {@link GAjaxEvent}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GAjaxEvent() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GAjaxEvent event = (GAjaxEvent) getRepository();
		setRender(event == null ? null : event.getRender());
		setAsync(event == null ? null : event.getAsync());
		setUpload(event == null ? null : event.getUpload());
		setDownload(event == null ? null : event.getDownload());
	}

	/**
	 * async属性の値を取得します.<br />
	 * 
	 * @create 2011/09/12
	 * @return <code>true:非同期通信</code>/<code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAsync() {
		return _async;
	}


	/**
	 * download属性の値を取得します.<br />
	 *
	 * @create 2024/04/30
	 * @return <code>true:application/octet-streamレスポンス</code>/ <code>false:XMLレスポンス</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public String getDownload() {
		return _download;
	}

	/**
	 * レンダリング対象のid属性の値を取得します.<br/>
	 * 
	 * @create 2011/04/20
	 * @return レンダリング対象のid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getRender() {
		return _render;
	}

	/**
	 * upload属性の値を取得します.<br />
	 * 
	 * @create 2016/02/12
	 * @return <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public String getUpload() {
		return _upload;
	}

	/**
	 * async属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return <code>true:非同期通信</code>/<code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isAsync() {
		return GBooleanUtils.toBoolean(getAsync(), true);
	}


	/**
	 * download属性の値を取得します.<br />
	 *
	 * @create 2024/04/30
	 * @return <code>true:application/octet-streamレスポンス</code>/ <code>false:XMLレスポンス</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public boolean isDownload() {
		return GBooleanUtils.toBoolean(getDownload(), false);
	}

	/**
	 * upload属性の値を取得します.<br />
	 * 
	 * @create 2016/02/12
	 * @return <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public boolean isUpload() {
		return GBooleanUtils.toBoolean(getUpload(), false);
	}

	/**
	 * async属性に値を設定します.<br />
	 * 
	 * @create 2011/09/12
	 * @param async <code>true:非同期通信</code>/<code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAsync(boolean async) {
		setAsync(String.valueOf(async));
	}


	/**
	 * async属性に値を設定します.<br />
	 * 
	 * @create 2011/09/12
	 * @param async <code>true:非同期通信</code>/ <code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAsync(String async) {
		_async = async;
	}

	/**
	 * download属性に値を設定します.<br />
	 *
	 * @create 2024/04/30
	 * @param download <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public void setDownload(boolean download) {
		setDownload(String.valueOf(download));
	}

	/**
	 * download属性に値を設定します.<br />
	 *
	 * @create 2024/04/30
	 * @param download <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public void setDownload(String download) {
		_download = download;
	}
	/**
	 * レンダリング対象のid属性に値を設定します.<br/>
	 * 
	 * @create 2011/04/20
	 * @param render レンダリング対象のid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRender(String render) {
		_render = render;
	}
	
	/**
	 * upload属性に値を設定します.<br />
	 * 
	 * @create 2016/02/12
	 * @param upload <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public void setUpload(String upload) {
		_upload = upload;
	}
	
	/**
	 * upload属性に値を設定します.<br />
	 * 
	 * @create 2016/02/12
	 * @param upload <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public void setUpload(boolean upload) {
		_upload = String.valueOf(upload);;
	}
}
