/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;


/**
 * クリアイベントを表すUIコントロールです.<br/>
 * 
 * @create 2013/08/09
 * @author yamashita
 * @since 3.12.0
 */
public class GClearEvent extends GEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 246546194640849311L;
	/** クリア範囲を示す値. */
	private String _element = null;

	/**
	 * {@link GClearEvent}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/08/09
	 * @author yamashita
	 * @since 3.12.0
	 */
	public GClearEvent() {
	}

	/**
	 * クリア範囲を示す値を取得します.<br />
	 * 
	 * @create 2013/08/09
	 * @return クリア範囲を示す値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getElement() {
		return this._element;
	}

	/**
	 * クリア範囲を示す値を設定します.<br />
	 * 
	 * @create 2013/08/09
	 * @param element クリア範囲を示す値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setElement(String element) {
		this._element = element;
	}
}
