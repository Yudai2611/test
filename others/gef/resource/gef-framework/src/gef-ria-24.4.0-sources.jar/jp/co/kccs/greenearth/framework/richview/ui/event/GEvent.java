/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * イベントを示すインターフェイスです.<br />
 * 
 * @create 2011/03/08
 * @author yamashita
 * @since 3.9.0
 */
public interface GEvent extends GUIItem {

	/**
	 * 画面入力値を表すパラメータを読み込みます.
	 * 
	 * @create 2013/07/24
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.12.0
	 */
	void loadParameter(GParameter parameter);
	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.
	 * 
	 * @create 2013/07/24
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.12.0
	 */
	void loadResultData(GResultData data);
}