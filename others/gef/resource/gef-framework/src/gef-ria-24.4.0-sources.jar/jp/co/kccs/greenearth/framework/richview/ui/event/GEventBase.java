/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.GUIItemBase;

/**
 * {@link GEvent}に指定されるデフォルトの振舞いを提供する、イベントを実装するための基底クラスです.<br>
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GEventBase extends GUIItemBase implements GEvent {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -8532296931206477138L;

	// 拡張属性
	/** event属性の値. */
	private String _event = null;
	/** dialogmsg属性の値. */
	private String _dialogmsg = null;
	/** customdialog属性の値. */
	private String _customdialog = null;

	/**
	 * 画面入力値を表すパラメータを読み込みます.
	 * 
	 * @create 2013/07/24
	 * @param parameter パラメータオブジェクト
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public void loadParameter(GParameter parameter) {
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.
	 * 
	 * @create 2013/07/24
	 * @param data 結果セットオブジェクト
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public void loadResultData(GResultData data) {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase#reset()
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		GEventBase event = (GEventBase) getRepository();
		setEvent(event == null ? null : event.getEvent());
		setDialogmsg(event == null ? null : event.getDialogmsg());
		setCustomdialog(event == null ? null : event.getCustomdialog());
	}

	/**
	 * event属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return イベント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getEvent() {
		return _event;
	}

	/**
	 * event属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param event イベント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEvent(String event) {
		_event = event;
	}

	/**
	 * customdialog属性の値を取得します.<br />
	 * 
	 * @create 2013/04/17
	 * @return カスタムダイアログのid属性の値
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public String getCustomdialog() {
		return _customdialog;
	}

	/**
	 * dialogmsg属性の値を取得します.<br />
	 * 
	 * @create 2013/04/17
	 * @return 確認メッセージ
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public String getDialogmsg() {
		return _dialogmsg;
	}

	/**
	 * customdialog属性の値を設定します.<br />
	 * 
	 * @create 2013/04/17
	 * @param customdialog カスタムダイアログのid属性の値
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public void setCustomdialog(String customdialog) {
		_customdialog = customdialog;
	}

	/**
	 * dialogmsg属性の値を設定します.<br />
	 * 
	 * @create 2013/04/17
	 * @param dialogmsg 確認メッセージ
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public void setDialogmsg(String dialogmsg) {
		_dialogmsg = dialogmsg;
	}
}
