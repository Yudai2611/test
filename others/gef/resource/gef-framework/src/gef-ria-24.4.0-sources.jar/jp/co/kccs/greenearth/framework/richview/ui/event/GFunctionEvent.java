/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

/**
 * ファンクションイベントを表すUIコントロールです.<br/>
 * 
 * @create 2011/05/18
 * @author yamashita
 * @since 3.9.0
 */
public class GFunctionEvent extends GEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4623513512231509777L;

	// 拡張属性
	/** func属性の値. */
	private String _func = null;
	
	/**
	 * コンストラクタ
	 * 
	 * @create 2011/09/18
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GFunctionEvent() {
	}

	
	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GFunctionEvent event = (GFunctionEvent) getRepository();
		setFunc(event == null ? null : event.getFunc());
	}

	/**
	 * JavaScript関数を取得します.<br />
	 * 
	 * @create 2011/05/18
	 * @return func属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFunc() {
		return _func;
	}

	/**
	 * JavaScript関数を設定します.<br />
	 * 
	 * @create 2011/05/18
	 * @param func func属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFunc(String func) {
		_func = func;
	}
}
