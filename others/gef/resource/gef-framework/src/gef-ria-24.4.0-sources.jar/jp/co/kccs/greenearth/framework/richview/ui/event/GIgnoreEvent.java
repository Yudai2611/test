/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.GEventable;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * 強制実行ボタンを表すUIコントロールです.<br />
 *
 * @create 2021/04/13
 * @author KCSS
 * @since 3.21.9
 */
public class GIgnoreEvent extends GActionEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2310120950707760570L;

	// 拡張属性
	/** 強制実行（無視）レベル. **/
	private String _ignore = null;

	/**
	 * {@link GIgnoreEvent}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2021/04/13
	 * @author KCSS
	 * @since 3.21.9
	 */
	public GIgnoreEvent() {
		setValidate(GErrorLevel.INFO.toString());
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.
	 *
	 * @create 2021/04/13
	 * @author KCSS
	 * @since 3.21.9
	 */
	@Override
	public void loadResultData(GResultData data) {
		GUIComponent parent = getParent();
		if (!(parent instanceof GEventable)) {
			return;
		}
		parent.setVisible(GIgnoreUtils.isVisible(data, getIgnore()));
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 *
	 * @create 2021/04/13
	 * @author KCSS
	 * @since 3.21.9
	 */
	@Override
	public void reset() {
		super.reset();
		GIgnoreEvent event = (GIgnoreEvent) getRepository();
		setIgnore(event == null ? null : event.getIgnore());
	}

	/**
	 * 強制実行（無視）レベルを取得します.
	 *
	 * @create 2021/04/13
	 * @author KCSS
	 * @since 3.21.9
	 */
	public String getIgnore() {
		return _ignore;
	}

	/**
	 * 強制実行（無視）レベルを設定します.
	 *
	 * @create 2021/04/13
	 * @author KCSS
	 * @since 3.21.9
	 */
	public void setIgnore(String ignore) {
		_ignore = ignore;
	}
}
