/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.json.GJSONArray;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;

/**
 * 警告実行機能のユーティリティクラスです.<br>
 * 
 * @create 2013/07/25
 * @author yamashita
 * @since 3.12.0
 */
public final class GIgnoreUtils {

	public static final String REQUEST_PARAMETER_RESTORE_KEY = "reqoptions";
	
	/**
	 * コンストラクタ
	 * 
	 * @create 2013/07/25
	 * @author yamashita
	 * @since 3.12.0
	 */
	private GIgnoreUtils() {
	}

	/***
	 * 結果セットの状態およびignore属性の値に基づいて、UIコントロールを不可視にするかどうかを判定します.<br/>
	 * 
	 * @param data 結果セット
	 * @return true: 可視 / false: 不可視
	 * @create 2013/07/25
	 * @author yamashita
	 * @since 3.12.0
	 */
	public static boolean isVisible(GResultData data, String ignore) {
		if (data == null || data.getErrors().isEmpty() || 
				!GResultData.EXIT_CODE_VALIDATE_ERROR.equals(data.getExitCode()) || 
				GErrorLevel.NONE.toString().equals(ignore)) {
			return false;
		}
		if (GErrorLevel.ERROR.toString().equals(ignore)) {	// 可視
			return true;
		}
		if (GErrorLevel.INFO.toString().equals(ignore)) {	// ignore=info、かつerrorType=Error or Warningが含まれない場合、可視
			return !contains(data.getErrors(), GErrorType.ERROR, GErrorType.WARNING);
		}
		return !contains(data.getErrors(), GErrorType.ERROR);	// ignore属性がwarning、または指定なし（規定値＝warning）、かつerrorType=Errorが含まれない場合、可視
	}

	/**
	 * 前回リクエスト時のパラメータ情報を復元します.<br/>
	 * 
	 * @param options オプション
	 * @param parameter リクエストパラメータ
	 * @create 2013/07/25
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	public static void restore(GJSONObject options, GParameter parameter) {
		if (options == null || parameter == null) {
			return;
		}
		GJSONArray params = new GJSONArray(parameter.getValue("reqoptions"));
		for (Object param : params) {
			@SuppressWarnings("unchecked")
			Map<String, String> p = (Map<String, String>) param;
			String key = p.get("name");
			if (!options.containsKey(key)) {
				options.put(key, p.get("value"));
			}
		}
	}

	/**
	 * 指定したエラータイプ（{GErrorType}）が含まれるかどうかを判定します.<br/>
	 * 
	 * @param errors 検証エラーリスト
	 * @param types エラータイプ（{GErrorType}）のリスト
	 * @return true: 含む / false: 含まない
	 * @create 2013/07/25
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected static boolean contains(List<GValidateError> errors, GErrorType... types) {
		if (errors == null) {
			return false;
		}
		for (GValidateError error : errors) {
			for (GErrorType type : types) {
				if (type == error.getType()) {
					return true;
				}
			}
		}
		return false;
	}
}
