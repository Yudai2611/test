/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;


/**
 * リセットイベントを表すUIコントロールです.<br/>
 * 
 * @create 2013/08/09
 * @author yamashita
 * @since 3.12.0
 */
public class GResetEvent extends GEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 2122561682678485203L;
	/** リセット範囲を示す値. */
	private String _form = null;

	/**
	 * {@link GResetEvent}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/08/09
	 * @author yamashita
	 * @since 3.12.0
	 */
	public GResetEvent() {
	}

	/**
	 * リセット範囲を示す値を取得します.<br />
	 * 
	 * @create 2013/08/09
	 * @return リセット範囲を示す値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getForm() {
		return this._form;
	}

	/**
	 * リセット範囲を示す値を設定します.<br />
	 * 
	 * @create 2013/08/09
	 * @param form リセット範囲を示す値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setForm(String form) {
		this._form = form;
	}
}
