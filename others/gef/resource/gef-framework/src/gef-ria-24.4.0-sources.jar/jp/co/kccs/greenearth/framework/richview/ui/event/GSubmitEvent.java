/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

/**
 * サブミットイベントを表すUIコントロールです.<br/>
 * 
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public class GSubmitEvent extends GActionEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2310120950707760570L;

	// XHTML属性
	/** target属性の値. */
	private String _target = null;
	// 拡張属性
	/** forward属性の値. */
	private String _forward = null;
	
	/**
	 * コンストラクタ
	 * 
	 * @create 2011/09/18
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GSubmitEvent() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GSubmitEvent event = (GSubmitEvent) getRepository();
		setForward(event == null ? null : event.getForward());
		setTarget(event == null ? null : event.getTarget());
	}

	/**
	 * フォワード先のパスを取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return forward属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getForward() {
		return _forward;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return target属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * フォワード先のパスを設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param forward forward属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setForward(String forward) {
		_forward = forward;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param target target属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTarget(String target) {
		_target = target;
	}
}
