/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event;

import jp.co.kccs.greenearth.commons.json.GJSONArray;

/**
 * ウィジェットイベントを表すUIコントロールです.<br/>
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
public class GWidgetEvent extends GEventBase {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 743262411181447677L;

	// 拡張属性
	/** method属性の値. */
	private String _method = null;
	/** args属性の値. */
	private GJSONArray _args = null;
	/** element属性の値. */
	private String _element = null;
	/** widgetname属性の値. */
	private String _widgetname = null;

	/**
	 * {@link GWidgetEvent}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/03/30
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GWidgetEvent() {
	}

	/**
	 * このコントロールの属性値をリポジトリ用コンポーネントと同じ状態に戻します.<br/>
	 * 
	 * @create 2011/07/07
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		GWidgetEvent event = (GWidgetEvent) getRepository();
		setMethod(event == null ? null : event.getMethod());
		setArgs(event == null ? null : event.getArgs());
		setElement(event == null ? null : event.getElement());
		setWidgetname(event == null ? null : event.getWidgetname());
	}

	/**
	 * エンコードされたメソッドの引数を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return エンコード済みargs属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getArgs() {
		if (_args != null) {
			return _args.encode();
		}
		return null;
	}

	/**
	 * デコードされたメソッドの引数を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return args属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONArray getDecordArgs() {
		return _args;
	}

	/**
	 * エレメントのid属性の値を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * ウィジェットのメソッド名を取得します.<br />
	 * 
	 * @create 2011/03/30
	 * @return method属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMethod() {
		return _method;
	}

	/**
	 * widgetname属性の値を取得します.<br/>
	 * 
	 * @create 2011/03/30
	 * @return widgetname widgetname属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getWidgetname() {
		return _widgetname;
	}

	/**
	 * メソッドの引数を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param args 配列化したargs属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setArgs(GJSONArray args) {
		_args = args;
	}

	/**
	 * メソッドの引数を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param args args属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setArgs(String args) {
		_args = new GJSONArray(args);
	}

	/**
	 * エレメントのid属性の値を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param element element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * ウィジェットのメソッド名を設定します.<br />
	 * 
	 * @create 2011/03/30
	 * @param method method属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMethod(String method) {
		_method = method;
	}

	/**
	 * widgetname属性の値を設定します.<br/>
	 * 
	 * @create 2011/03/30
	 * @param widgetname widgetname属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setWidgetname(String widgetname) {
		_widgetname = widgetname;
	}
}
