/*
 * Copyright 2011-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.DynamicAttributes;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.richview.ui.event.GActionEventBase;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GActionParamDecorator;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GActionParamDecoratorFactory;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GEventableTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * アクションイベントの基底クラスです.<br/>
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GActionEventBaseTag extends GEventBaseTag implements DynamicAttributes {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -1015787471810447238L;

	/** アクションパラメータ名 */
	public static final String ACTION_PARAM_NAME = "actionparams";

	// 拡張属性
	/** actionbean属性の値. */
	private String _actionbean = null;
	/** actionmethod属性の値. */
	private String _actionmethod = null;
	/** form属性の値. */
	private String _form = null;
	/** mode属性の値. */
	private String _mode = null;
	/** validate属性の値. */
	private String _validate = GErrorLevel.INFO.toString();
	// 拡張属性
	/** httpmethod属性の値. */
	private String _httpmethod = null;
	/** indicator属性の値. */
	private String _indicator = null;

	// 内部変数
	/** デコレータとUIコントロールを関連付けるマップ. */
	Map<String, String> _decoratorMap = new HashMap<String, String>();
	/** デコレータとIDを関連付けるマップ. */
	Map<String, String> _decoratorIdMap = new HashMap<String, String>();

	/**
	 * イベントオプションを装飾します.<br/>
	 * <br/>
	 * action関連付け項目は、全部options.actionparamsに入れる<br/>
	 * 装飾処理後、options構造のイメージ：<br/>
	 *   options : {dialogmsg : xxxx, customdialog : xxxx, actionparams : { ... } }<br/>
	 *   options.actionparams :{ httpmethod : xxxx, indicator : xxxx, actionbean : xxxx,
	 *         actionmethod : xxxx, actionform : xxxx, mode : xxxx, validate : xxxx }<br/>
	 * 
	 * @create 2011/06/23
	 * @param options オプション
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void decorateEventOptions(GJSONObject options) throws JspException {
		GJSONObject newOptions = new GJSONObject();
		setOptions(newOptions);
		super.decorateEventOptions(newOptions);
		options.put("actionbean", getActionbean());
		options.put("actionmethod", getActionmethod());
		options.put("actionform", getForm());
		options.put("mode", getMode());
		options.put("validate", getValidate());
		options.put("httpmethod", getHttpmethod());
		options.put("indicator", getIndicator());

		GEventableTag eventableTag = getEventableTag();
		eventableTag.bindOptions(options);

		newOptions.put(ACTION_PARAM_NAME, options);
		GUIControl rootControl = (GUIControl) getRootComponent(this);
		if (rootControl == null) {
			return;
		}
		for (String key : getDecoratorIdMap().keySet()) {
			String id = getDecoratorIdMap().get(key);
			GUIControl control = rootControl.findControl(id);
			if (control == null) {
				continue;
			}
			GActionParamDecorator decorator = GActionParamDecoratorFactory.getDecorator(key);
			if (decorator == null) {
				continue;
			}
			decorator.decorate(options, control);
		}
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/04/14
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GActionEventBase ui = (GActionEventBase) component;
		GActionEventBase rep = (GActionEventBase) component.getRepository();
		setActionbean(evaluatePlaceholder(ui.getActionbean(), getActionbean(),
				rep == null ? null : rep.getActionbean(), ui));
		setActionmethod(evaluatePlaceholder(ui.getActionmethod(), getActionmethod(),
				rep == null ? null : rep.getActionmethod(), ui));
		setForm(evaluatePlaceholder(ui.getForm(), getForm(),
				rep == null ? null : rep.getForm(), ui));
		setMode(evaluatePlaceholder(ui.getMode(), getMode(),
				rep == null ? null : rep.getMode(), ui));
		setValidate(evaluatePlaceholder(ui.getValidate(), getValidate(),
				rep == null ? null : rep.getValidate(), ui));
		setHttpmethod(evaluatePlaceholder(ui.getHttpmethod(), getHttpmethod(),
				rep == null ? null : rep.getHttpmethod(), ui));
		setIndicator(evaluatePlaceholder(ui.getIndicator(), getIndicator(),
				rep == null ? null : rep.getIndicator(), ui));
		for (String key : getDecoratorMap().keySet()) {
			String id = getDecoratorMap().get(key);
			getDecoratorIdMap().put(key, evaluatePlaceholder(id, ui));
		}
	}
	
	/**
	 * タグの状態をリセット(初期化)します.<br />
	 * 
	 * @create 2011/06/10
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void reset() {
		super.reset();
		_decoratorMap = null;
		_decoratorIdMap = null;
	}

	/**
	 * デコレータとUIコントロールを関連付けるマップを取得します.<br />
	 * 
	 * 関連付けは、デコレータの（DIコンテナに定義）キーとUIコントロールのid属性の（プレースホルダ置換前の）値となります。
	 * 
	 * @create 2011/07/07
	 * @return デコレータとUIコントロールを関連付けるマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public Map<String, String> getDecoratorMap() {
		if (_decoratorMap == null) {
			_decoratorMap = new HashMap<String, String>();
		}
		return _decoratorMap;
	}

	/**
	 * actionbean属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return アクションビーン
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getActionbean() {
		return _actionbean;
	}

	/**
	 * actionmethod属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return アクションメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getActionmethod() {
		return _actionmethod;
	}

	/**
	 * デコレータとUIコントロールを関連付けるマップを取得します.<br />
	 * 
	 * 関連付けは、デコレータの（DIコンテナに定義）キーとUIコントロールのid属性の（プレースホルダ置換後の）値となります。
	 * 
	 * @create 2011/07/07
	 * @return デコレータとUIコントロールを関連付けるマップ
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected Map<String, String> getDecoratorIdMap() {
		if (_decoratorIdMap == null) {
			_decoratorIdMap = new HashMap<String, String>();
		}
		return _decoratorIdMap;
	}

	/**
	 * form属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return submit対象フォームのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getForm() {
		return _form;
	}

	/**
	 * httpmethod属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return HTTPメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getHttpmethod() {
		return _httpmethod;
	}

	/**
	 * indicator属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return インジケータのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getIndicator() {
		return _indicator;
	}

	/**
	 * mode属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return モード
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMode() {
		return _mode;
	}

	/**
	 * validate属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return 入力検証を行うレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getValidate() {
		return _validate;
	}

	/**
	 * actionbean属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param actionbean アクションビーン
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setActionbean(String actionbean) {
		_actionbean = actionbean;
	}

	/**
	 * actionmethod属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param actionmethod アクションメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setActionmethod(String actionmethod) {
		_actionmethod = actionmethod;
	}

	/**
	 * 動的に指定されたXHTMLの属性を設定します.<br>
	 * 
	 * @see DynamicAttributes#setDynamicAttribute(String, String, Object)
	 * @create 2011/06/10
	 * @param uri 名前空間URI
	 * @param name 属性名
	 * @param value 属性値
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setDynamicAttribute(String uri, String name, Object value) throws JspException {
		getDecoratorMap().put(name, (String) value); // value
														// typeがString以外はCast例外
	}

	/**
	 * form属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param form submit対象フォームのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setForm(String form) {
		_form = form;
	}

	/**
	 * httpmethod属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param httpmethod HTTPメソッド
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setHttpmethod(String httpmethod) {
		_httpmethod = httpmethod;
	}

	/**
	 * indicator属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param indicator インジケータのid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setIndicator(String indicator) {
		_indicator = indicator;
	}

	/**
	 * mode属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param mode モード
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMode(String mode) {
		_mode = mode;
	}

	/**
	 * validate属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param validate 入力検証を行うレベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setValidate(String validate) {
		_validate = validate;
	}
}
