/*
 * Copyright 2011-2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.framework.richview.ui.event.GAjaxEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * ajaxイベントを表示するタグクラスです.<br/>
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GAjaxEvent.class)
public class GAjaxEventTag extends GActionEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 8954741318664008673L;
	/** ファンクション名 */
	private static final String FUNCTION_NAME = "$.gectrl.gappcontroller.invokeAjaxAction";
	/** ajax設定名 */
	public static final String ACTION_PARAM_AJAX_SETTINGS_NAME = "ajaxSettings";

	// 拡張属性
	/** レンダリング対象のid属性の値. */
	private String _render = null;
	/** async属性の値. */
	private String _async = null;
	/** upload属性の値. */
	private String _upload = null;

	/** download属性の値. */
	private String _download = null;

	/**
	 * コンストラクタ
	 *
	 * @create 2011/09/18
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GAjaxEventTag() {
	}

	/**
	 * イベントオプションを装飾します.<br/>
	 *
	 *
	 * @create 2011/06/23
	 * @param options オプション
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void decorateEventOptions(GJSONObject options) throws JspException {
		super.decorateEventOptions(options);
		GJSONObject o = getDecodeOptions();
		GJSONObject actionParams = o.getJSONObject(ACTION_PARAM_NAME);
		actionParams.put("render", getRender());
		actionParams.put("upload", isUpload());
		actionParams.put("download", isDownload());
		GJSONObject ajaxSettings = actionParams.getJSONObject(ACTION_PARAM_AJAX_SETTINGS_NAME);
		if (ajaxSettings == null) {
			ajaxSettings = new GJSONObject();
		}
		ajaxSettings.put("async", isAsync());
		actionParams.put(ACTION_PARAM_AJAX_SETTINGS_NAME, ajaxSettings);
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 *
	 * @create 2011/04/14
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GAjaxEvent ui = (GAjaxEvent) component;
		GAjaxEvent rep = (GAjaxEvent) component.getRepository();
		setRender(evaluatePlaceholder(ui.getRender(), getRender(),
				rep == null ? null : rep.getRender(), ui));
		setAsync(evaluatePlaceholder(ui.getAsync(), getAsync(),
				rep == null ? null : rep.getAsync(), ui));
		setUpload(evaluatePlaceholder(ui.getUpload(), getUpload(),
				rep == null ? null : rep.getUpload(), ui));
		setDownload(evaluatePlaceholder(ui.getDownload(), getDownload(),
				rep == null ? null : rep.getDownload(), ui));

	}

	/**
	 * async属性の値を取得します.<br />
	 *
	 * @create 2011/09/12
	 * @return <code>true:非同期通信</code>/<code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getAsync() {
		return _async;
	}

	/**
	 * download属性の値を取得します.<br />
	 *
	 * @create 2024/04/30
	 * @return <code>true:application/octet-streamレスポンス</code>/ <code>false:XMLレスポンス</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public String getDownload() {
		return _download;
	}

	/**
	 * レンダリング対象のid属性の値を取得します.<br/>
	 *
	 * @create 2011/04/14
	 * @return レンダリング対象のid属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getRender() {
		return _render;
	}

	/**
	 * upload属性の値を取得します.<br />
	 *
	 * @create 2016/02/12
	 * @return <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public String getUpload() {
		return _upload;
	}

	/**
	 * async属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return <code>true:非同期通信</code>/<code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isAsync() {
		return GBooleanUtils.toBoolean(_async, true);
	}

	/**
	 * download属性の値を取得します.<br />
	 *
	 * @create 2024/04/30
	 * @return <code>true:application/octet-streamレスポンス</code>/ <code>false:XMLレスポンス</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public boolean isDownload() {
		return GBooleanUtils.toBoolean(_download, false);
	}

	/**
	 * upload属性の値を取得します.<br />
	 *
	 * @create 2016/02/12
	 * @return <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public boolean isUpload() {
		return GBooleanUtils.toBoolean(getUpload(), false);
	}

	/**
	 * async属性に値を設定します.<br />
	 *
	 * @create 2011/09/12
	 * @param async <code>true:非同期通信</code>/<code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAsync(boolean async) {
		setAsync(String.valueOf(async));
	}

	/**
	 * async属性に値を設定します.<br />
	 *
	 * @create 2011/09/12
	 * @param async <code>true:非同期通信</code>/ <code>false:同期通信</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAsync(String async) {
		_async = async;
	}

	/**
	 * download属性に値を設定します.<br />
	 *
	 * @create 2024/04/30
	 * @param download <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public void setDownload(boolean download) {
		setDownload(String.valueOf(download));
	}

	/**
	 * download属性に値を設定します.<br />
	 *
	 * @create 2024/04/30
	 * @param download <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public void setDownload(String download) {
		_download = download;
	}

	/**
	 * レンダリング対象のid属性に値を設定します.<br/>
	 *
	 * @create 2011/04/14
	 * @param render レンダリング対象のid属性
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setRender(String render) {
		_render = render;
	}

	/**
	 * upload属性に値を設定します.<br />
	 *
	 * @create 2016/02/12
	 * @param upload <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public void setUpload(String upload) {
		_upload = upload;
	}

	/**
	 * upload属性に値を設定します.<br />
	 *
	 * @create 2016/02/12
	 * @param upload <code>true:multipart/form-data通信</code>/ <code>false:application/x-www-form-urlencoded通信</code>
	 * @author kikuchi
	 * @since 3.17.0
	 */
	public void setUpload(boolean upload) {
		_upload = String.valueOf(upload);;
	}

	/**
	 * ファンクション名を取得します.<br/>
	 *
	 * @create 2011/04/14
	 * @return ファンクション名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected String getFunctionName() {
		return FUNCTION_NAME;
	}
}
