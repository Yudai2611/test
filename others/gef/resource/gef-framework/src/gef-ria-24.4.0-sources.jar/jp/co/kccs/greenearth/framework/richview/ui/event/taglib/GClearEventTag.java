/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.ui.event.GClearEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * クリアイベントを表示するタグクラスです.<br/>
 * 
 * @create 2013/08/09
 * @author yamashita
 * @since 3.12.0
 */
@TargetUIComponent(GClearEvent.class)
public class GClearEventTag extends GEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2938801449891294357L;
	/** クリア関数 */
	static final String FUNCTION_NAME = "$.geui.clear";
	/** クリア範囲を示す値. */
	private String _element = null;

	/**
	 * {@link GClearEventTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/08/09
	 * @author hamanaka
	 * @since 3.12.0
	 */
	public GClearEventTag() {
	}

	/**
	 * イベントオプションを装飾します.<br/>
	 * 
	 * @create 2013/08/09
	 * @param options オプション
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public void decorateEventOptions(GJSONObject options) throws JspException {
		super.decorateEventOptions(options);
		options.put("element", getElement());
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @create 2013/08/09
	 * @param component レンダリング対象UIコンポーネント
	 * @author hamanaka
	 * @since 3.12.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GClearEvent ui = (GClearEvent) component;
		GClearEvent rep = (GClearEvent) component.getRepository();
		setElement(evaluatePlaceholder(ui.getElement(), getElement(),
				rep == null ? null : rep.getElement(), ui));
	}

	/**
	 * ファンクション名を取得します.<br />
	 * 
	 * @create 2013/08/09
	 * @return ファンクション名
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	protected String getFunctionName() {
		return FUNCTION_NAME;
	}

	/**
	 * クリア範囲を示す値を取得します.<br />
	 * 
	 * @create 2013/08/09
	 * @return クリア範囲を示す値
	 * @author hamanaka
	 * @since 3.12.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * クリア範囲を示す値を設定します.<br />
	 * 
	 * @create 2013/08/09
	 * @param element クリア範囲を示す値
	 * @author hamanaka
	 * @since 3.12.0
	 */
	public void setElement(String element) {
		_element = element;
	}
}
