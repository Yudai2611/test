/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.event.GEvent;
import jp.co.kccs.greenearth.framework.richview.ui.event.GEventBase;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GEventableTag;
import jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIItemBaseTag;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * {@link GEventTag}に指定されるデフォルトの振舞いを提供する、イベントタグを実装するための基底クラスです.<br>
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GEventBaseTag extends GUIItemBaseTag implements GEventTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -4970541894816957154L;

	// 拡張属性
	/** event属性の値. */
	private String _event = null;
	/** dialogmsg属性の値. */
	private String _dialogmsg = null;
	/** customdialog属性の値. */
	private String _customdialog = null;

	/**
	 * {@link GEventBaseTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/10
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GEventBaseTag() {
	}

	/**
	 * イベントオプションを装飾します.<br/>
	 * ※本メソッドは何も実装していません。<br/>
	 * 
	 * @create 2011/04/05
	 * @param options オプション
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void decorateEventOptions(GJSONObject options) throws JspException {
		options.put("dialogmsg", getDialogmsg());
		options.put("customdialog", getCustomdialog());
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/04/14
	 * @return 呼び出し後のステータス
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		int result = super.doEndTag();
		reset();
		return result;
	}

	/**
	 * 開始タグが呼び出されたときに実行されるメソッドです.<br />
	 * 
	 * @create 2011/04/14
	 * @return 呼び出し後のステータス
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doStartTag() throws JspException {
		loadTargetEvent();
		printScript();
		reset();
		return SKIP_BODY;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @create 2011/06/10
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GEventBase ui = (GEventBase) component;
		GEventBase rep = (GEventBase) component.getRepository();
		setEvent(evaluatePlaceholder(ui.getEvent(), getEvent(),
				rep == null ? null : rep.getEvent(), ui));
		setDialogmsg(evaluatePlaceholder(ui.getDialogmsg(), getDialogmsg(),
				rep == null ? null : rep.getDialogmsg(), ui));
		setCustomdialog(evaluatePlaceholder(ui.getCustomdialog(), getCustomdialog(),
				rep == null ? null : rep.getCustomdialog(), ui));
	}

	/**
	 * 親タグより、自分がターゲットとするイベントコントロールを取得し、読み込みます.<br />
	 * 
	 * @create 2011/04/14
	 * @return
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void loadTargetEvent() throws JspException {
		GEventableTag eventable = getEventableTag();
		GEvent event = eventable.currentEvent();
		if (event == null) {
			return;
		}
		Class< ? > uiClass = getClass().getAnnotation(TargetUIComponent.class).value();
		if (uiClass.isAssignableFrom(event.getClass())) {
			load(event);
		} else {
			throw new ClassCastException(
				"type in hoge properly is not associated with GEventableTag. GEventableTag is the id of \""
					+ eventable.getId() + "\".");
		}
	}

	/**
	 * 生成されたイベントスクリプトを出力します.<br />
	 * 
	 * @create 2011/04/14
	 * @return
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void printScript() throws JspException {
		GEventableTag eventable = getEventableTag();
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		bindConfirmActionScript(scriptBuilder, createScript());
		eventable.bindScript(getEvent(), scriptBuilder);
	}

	/**
	 * イベント実行の確認処理を行うスクリプトを構築します.<br/>
	 * 
	 * @param scriptBuilder メイン処理のクリプト
	 * @param contentsBuilder アドオンするスクリプト
	 * @create 2013/04/18
	 * @author KCCS H.nishimura
	 * @since 3.10.0.E
	 */
	protected void bindConfirmActionScript(GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder contentsBuilder) {
		scriptBuilder.append("if ($.geui.confirmAction(");
		GJSONObject options = getDecodeOptions();
		GJSONObject confirmActionOptions = new GJSONObject();
		confirmActionOptions.put("dialogmsg", options.get("dialogmsg"));
		confirmActionOptions.put("customdialog", options.get("customdialog"));
		scriptBuilder.append(confirmActionOptions.encode());
		scriptBuilder.append(")) {");
		scriptBuilder.append(contentsBuilder.toString());
		scriptBuilder.append("}");
	}

	/**
	 * event属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return イベント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getEvent() {
		return _event;
	}

	/**
	 * event属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param event イベント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEvent(String event) {
		_event = event;
	}

	/**
	 * customdialog属性の値を設定します.<br />
	 * 
	 * @create 2013/04/17
	 * @param customdialog カスタムダイアログのid属性の値
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public void setCustomdialog(String customdialog) {
		_customdialog = customdialog;
	}

	/**
	 * dialogmsg属性の値を設定します.<br />
	 * 
	 * @create 2013/04/17
	 * @param dialogmsg 確認メッセージ
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public void setDialogmsg(String dialogmsg) {
		_dialogmsg = dialogmsg;
	}

	/**
	 * customdialog属性の値を取得します.<br />
	 * 
	 * @create 2013/04/17
	 * @return カスタムダイアログのid属性の値
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public String getCustomdialog() {
		return _customdialog;
	}

	/**
	 * dialogmsg属性の値を取得します.<br />
	 * 
	 * @create 2013/04/17
	 * @return 確認メッセージ
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public String getDialogmsg() {
		return _dialogmsg;
	}

	/**
	 * JavaScript関数を生成します.<br/>
	 * 
	 * @create 2011/04/14
	 * @return スクリプトビルダ
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected GJavaScriptBuilder createScript() throws JspException {
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		String funcName = getFunctionName();
		if (GStringUtils.isEmpty(funcName)) {
			return scriptBuilder;
		}
		scriptBuilder.append(funcName);
		scriptBuilder.append("(event, ");
		decorateEventOptions(getDecodeOptions());
		scriptBuilder.append(getDecodeOptions().encode());
		scriptBuilder.append(");");
		return scriptBuilder;
	}

	/**
	 * ファンクション名を取得します.<br />
	 * 
	 * @create 2011/06/23
	 * @return ファンクション名
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected String getFunctionName() {
		return "";
	}
}
