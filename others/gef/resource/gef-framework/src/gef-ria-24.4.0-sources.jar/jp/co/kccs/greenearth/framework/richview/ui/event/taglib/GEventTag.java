/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

/**
 * イベントを示すインターフェイスです.<br />
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
public interface GEventTag {
}