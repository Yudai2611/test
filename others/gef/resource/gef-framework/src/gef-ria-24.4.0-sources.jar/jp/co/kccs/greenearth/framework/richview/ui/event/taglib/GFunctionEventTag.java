/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.framework.richview.ui.event.GFunctionEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * ファンクションイベントを表示するタグクラスです.<br/>
 * 
 * @create 2011/05/18
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GFunctionEvent.class)
public class GFunctionEventTag extends GEventBaseTag {
	
	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 7749424977071045079L;

	// 拡張属性
	/** func属性の値. */
	private String _func = null;
	
	/**
	 * コンストラクタ
	 * 
	 * @create 2011/09/18
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GFunctionEventTag() {
	}


	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/05/18
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GFunctionEvent ui = (GFunctionEvent) component;
		GFunctionEvent rep = (GFunctionEvent) component.getRepository();
		setFunc(evaluatePlaceholder(ui.getFunc(), getFunc(),
				rep == null ? null : rep.getFunc(), ui));
	}

	/**
	 * JavaScript関数を生成します.<br/>
	 * 
	 * @return スクリプトビルダ
	 * @create 2011/04/14
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected GJavaScriptBuilder createScript() throws JspException {
		super.decorateEventOptions(getDecodeOptions());
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		if (getFunc() != null) {
			scriptBuilder.append(getFunc());
		}
		return scriptBuilder;
	}

	/**
	 * JavaScript関数を取得します.<br />
	 * 
	 * @create 2011/05/18
	 * @return func属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFunc() {
		return _func;
	}

	/**
	 * JavaScript関数を設定します.<br />
	 * 
	 * @create 2011/05/18
	 * @param func func属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFunc(String func) {
		_func = func;
	}
}
