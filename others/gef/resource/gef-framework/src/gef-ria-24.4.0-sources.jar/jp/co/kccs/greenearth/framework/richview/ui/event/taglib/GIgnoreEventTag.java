/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.richview.ui.event.GIgnoreEvent;
import jp.co.kccs.greenearth.framework.richview.ui.event.GIgnoreUtils;
import jp.co.kccs.greenearth.framework.view.GCommunicationType;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.jsp.JspException;

/**
 * 警告実行イベントを表すタグクラスです（AJAX・Submitを区別せず）.<br/>
 *
 * @create 2021/09/30
 * @author KCSS
 * @since 21.9.0
 */
@TargetUIComponent(GIgnoreEvent.class)
public class GIgnoreEventTag extends GActionEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7585569417862295046L;

	/** ファンクション名 */
	private static final String FUNCTION_AJAX_NAME = "$.gectrl.gappcontroller.invokeAjaxAction";
	private static final String FUNCTION_SUBMIT_NAME = "$.gectrl.gappcontroller.invokeSubmitAction";

	// 拡張属性
	/** 強制実行（無視）レベル. **/
	private String _ignore = null;

	/**
	 * {@link GIgnoreEventTag}の新しいインスタンスを初期化します.<br/>
	 *
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public GIgnoreEventTag() {
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 *
	 * @param component レンダリング対象UIコンポーネント
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GIgnoreEvent ui = (GIgnoreEvent) component;
		GIgnoreEvent rep = (GIgnoreEvent) component.getRepository();
		setIgnore(evaluatePlaceholder(ui.getIgnore(), getIgnore(),
				rep == null ? null : rep.getIgnore(), ui));
		ServletRequest request = pageContext.getRequest();
		GIgnoreUtils.restore(getDecodeOptions(), (GParameter) request.getAttribute(GConstants.PARAMETER_KEY));
	}

	/**
	 * リクエスト再発行時使うファンクション名を取得します.<br/>
	 * Ajaxの場合、FUNCTION_AJAX_NAME<br/>
	 * Submitの場合、FUNCTION_SUBMIT_NAME<br/>
	 *
	 * @return ファンクション名
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	@Override
	protected String getFunctionName() {
		// "commtype"で、ajaxかsubmitかを判断して、それぞれのファンクション名取得
		switch((String)getDecodeOptions().get(GCommunicationType.KEY)) {
			case GCommunicationType.COMMUNICATION_TYPE_AJAX:
				return FUNCTION_AJAX_NAME;
			case GCommunicationType.COMMUNICATION_TYPE_SUBMIT:
				return FUNCTION_SUBMIT_NAME;
			default:
				throw new IllegalArgumentException("\"GIgnoreEventTag\"  illegal communication type.");
		}
	}

	/**
	 * 強制実行（無視）レベルを取得します.
	 *
	 * @return 強制実行（無視）レベル
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public String getIgnore() {
		return _ignore;
	}

	/**
	 * 強制実行（無視）レベルを設定します.
	 * @param ignore 強制実行（無視）レベル
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public void setIgnore(String ignore) {
		_ignore = ignore;
	}
}
