/*
 * Copyright 2013-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.ui.event.GResetEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * リセットイベントを表示するタグクラスです.<br/>
 * 
 * @create 2013/08/09
 * @author yamashita
 * @since 3.12.0
 */
@TargetUIComponent(GResetEvent.class)
public class GResetEventTag extends GEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -254170111686994903L;
	/** リセット関数 */
	private static final String FUNCTION_NAME = "$.geui.resetAll";
	/** リセット範囲を示す値. */
	private String _form = null;

	/**
	 * {@link GResetEventTag}の新しいインスタンスを初期化します.<br />
	 * 
	 * @create 2013/08/09
	 * @author yamashita
	 * @since 3.12.0
	 */
	public GResetEventTag() {
	}

	/**
	 * イベントオプションを装飾します.<br/>
	 * 
	 * @create 2013/08/09
	 * @param options オプション
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public void decorateEventOptions(GJSONObject options) throws JspException {
		super.decorateEventOptions(options);
		options.put("element", getForm());
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * 
	 * @create 2013/08/09
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GResetEvent ui = (GResetEvent) component;
		GResetEvent rep = (GResetEvent) component.getRepository();
		setForm(evaluatePlaceholder(ui.getForm(), getForm(),
				rep == null ? null : rep.getForm(), ui));
	}

	/**
	 * ファンクション名を取得します.<br />
	 * 
	 * @create 2013/08/09
	 * @return ファンクション名
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	protected String getFunctionName() {
		return FUNCTION_NAME;
	}

	/**
	 * リセット範囲を示す値を取得します.<br />
	 * 
	 * @create 2013/08/09
	 * @return リセット範囲を示す値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public String getForm() {
		return _form;
	}

	/**
	 * リセット範囲を示す値を設定します.<br />
	 * 
	 * @create 2013/08/09
	 * @param form リセット範囲を示す値
	 * @author yamashita
	 * @since 3.12.0
	 */
	public void setForm(String form) {
		_form = form;
	}
}
