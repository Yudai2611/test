/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.ui.event.GSubmitEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;

/**
 * サブミットイベントを表示するタグクラスです.<br/>
 * 
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GSubmitEvent.class)
public class GSubmitEventTag extends GActionEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -7585569417862295046L;

	/** ファンクション名 */
	private static final String FUNCTION_NAME = "$.gectrl.gappcontroller.invokeSubmitAction";

	// XHTML属性
	/** target属性の値. */
	private String _target = null;
	// 拡張属性
	/** forward属性の値. */
	private String _forward = null;
	
	/**
	 * コンストラクタ
	 * 
	 * @create 2011/09/18
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GSubmitEventTag() {
	}

	/**
	 * イベントオプションを装飾します.<br/>
	 * 
	 * @create 2011/06/23
	 * @param options オプション
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void decorateEventOptions(GJSONObject options) throws JspException {
		super.decorateEventOptions(options);
		GJSONObject actionParams = getDecodeOptions().getJSONObject(ACTION_PARAM_NAME);
		actionParams.put("forward", getForward());
		actionParams.put("target", getTarget());
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/04/14
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GSubmitEvent ui = (GSubmitEvent) component;
		GSubmitEvent rep = (GSubmitEvent) component.getRepository();
		setForward(evaluatePlaceholder(ui.getForward(), getForward(),
				rep == null ? null : rep.getForward(), ui));
		setTarget(evaluatePlaceholder(ui.getTarget(), getTarget(),
				rep == null ? null : rep.getTarget(), ui));
	}

	/**
	 * フォワード先のパスを取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return forward属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getForward() {
		return _forward;
	}

	/**
	 * target属性の値を取得します.<br />
	 * 
	 * @create 2011/04/14
	 * @return target属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getTarget() {
		return _target;
	}

	/**
	 * フォワード先のパスを設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param forward forward属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setForward(String forward) {
		_forward = forward;
	}

	/**
	 * target属性の値を設定します.<br />
	 * 
	 * @create 2011/04/14
	 * @param target target属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTarget(String target) {
		_target = target;
	}

	/**
	 * ファンクション名を取得します.<br/>
	 * 
	 * @create 2011/04/14
	 * @return ファンクション名
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected String getFunctionName() {
		return FUNCTION_NAME;
	}
}
