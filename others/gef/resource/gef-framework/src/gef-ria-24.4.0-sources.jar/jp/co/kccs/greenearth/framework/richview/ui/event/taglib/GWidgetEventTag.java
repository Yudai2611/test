/*
 * Copyright 2011-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.event.taglib;

import jakarta.servlet.jsp.JspException;

import jp.co.kccs.greenearth.commons.json.GJSONArray;
import jp.co.kccs.greenearth.framework.richview.ui.event.GWidgetEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * ウィジェットイベントを表示するタグクラスです.<br/>
 * 
 * @create 2011/04/20
 * @author yamashita
 * @since 3.9.0
 */
@TargetUIComponent(GWidgetEvent.class)
public class GWidgetEventTag extends GEventBaseTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4656095472111871230L;

	// 拡張属性
	/** method属性の値. */
	private String _method = null;
	/** args属性の値. */
	private GJSONArray _args = null;
	/** element属性の値. */
	private String _element = null;
	/** widgetname属性の値. */
	private String _widgetname = null;

	/**
	 * コンストラクタ
	 * 
	 * @create 2011/09/18
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GWidgetEventTag() {
	}
	
	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br/>
	 * 
	 * @create 2011/04/20
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void load(GUIComponent component) {
		super.load(component);
		GWidgetEvent ui = (GWidgetEvent) component;
		GWidgetEvent rep = (GWidgetEvent) component.getRepository();
		setMethod(evaluatePlaceholder(ui.getMethod(), getMethod(),
				rep == null ? null : rep.getMethod(), ui));
		setElement(evaluatePlaceholder(ui.getElement(), getElement(),
				rep == null ? null : rep.getElement(), ui));
		setWidgetname(evaluatePlaceholder(ui.getWidgetname(), getWidgetname(),
				rep == null ? null : rep.getWidgetname(), ui));
		setArgs(ui.getDecordArgs());
	}

	/**
	 * JavaScriptを生成します.<br/>
	 * 
	 * @create 2011/04/20
	 * @return スクリプトビルダ
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	protected GJavaScriptBuilder createScript() throws JspException {
		if (getMethod() == null || getElement() == null || getWidgetname() == null) {
			return null;
		}
		super.decorateEventOptions(getDecodeOptions());
		GJavaScriptBuilder scriptBuilder = new GJavaScriptBuilder();
		scriptBuilder.append("$.ge.idSelector(??).", getElement());
		scriptBuilder.append(getWidgetname());
		scriptBuilder.append("('");
		scriptBuilder.append(getMethod());
		scriptBuilder.append("'");
		if (getDecordArgs() != null) {
			for (String arg : getDecordArgs().getStringArray()) {
				scriptBuilder.append(",");
				scriptBuilder.append(arg);
			}
		}
		scriptBuilder.append(");");
		return scriptBuilder;
	}

	/**
	 * args属性の値を取得します.
	 * 
	 * @create 2011/04/20
	 * @return args args属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getArgs() {
		if (_args != null) {
			return _args.encode();
		}
		return null;
	}

	/**
	 * デコードされたメソッドの引数を取得します.<br />
	 * 
	 * @create 2011/04/22
	 * @return args属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONArray getDecordArgs() {
		return _args;
	}

	/**
	 * エレメントのid属性の値を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getElement() {
		return _element;
	}

	/**
	 * ウィジェットのメソッド名を取得します.<br />
	 * 
	 * @create 2011/04/20
	 * @return method属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getMethod() {
		return _method;
	}

	/**
	 * widgetname属性の値を取得します.
	 * 
	 * @create 2011/04/20
	 * @return widgetname widgetname属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getWidgetname() {
		return _widgetname;
	}

	/**
	 * args属性の値を設定します.
	 * 
	 * @create 2011/04/20
	 * @param args args属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setArgs(GJSONArray args) {
		_args = args;
	}

	/**
	 * args属性の値を設定します.
	 * 
	 * @create 2011/04/22
	 * @param args 配列化したargs属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setArgs(String args) {
		_args = new GJSONArray(args);
	}

	/**
	 * エレメントのid属性の値を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param element element属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setElement(String element) {
		_element = element;
	}

	/**
	 * ウィジェットのメソッド名を設定します.<br />
	 * 
	 * @create 2011/04/20
	 * @param method method属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setMethod(String method) {
		_method = method;
	}

	/**
	 * widgetname属性の値を設定します.
	 * 
	 * @create 2011/04/20
	 * @param widgetname widgetname属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setWidgetname(String widgetname) {
		_widgetname = widgetname;
	}
}
