/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.key;

import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * EnterkeyFocus制御を表すUIコンポーネントです.<br />
 *
 * @create 2011/06/11
 * @author yamashita
 * @since 3.9.0
 */
public interface GEnterkeyFocus extends GUIItem {

	/**
	 * フォーカス移動順を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return フォーカス移動順を<code>true:自動設定</code>/<code>false:tabindex順で設定</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	boolean isAuto();

	/**
	 * フォーカス移動順を設定します.<br />
	 *
	 * @create 2020/02/07
	 * @param auto フォーカス移動順を<code>true:自動設定</code>/
	 *            <code>false:tabindex順で設定</code>
	 * @author hamanaka
	 * @since 20.9.0
	 */
	void setAuto(boolean auto);
}