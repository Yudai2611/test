/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.key;

import jp.co.kccs.greenearth.framework.view.component.GUIItem;

/**
 * キー制御を表すUIコンポーネントです.
 *
 * @create 2011/06/11
 * @author yamashita
 * @since 3.9.0
 */
public interface GKeyBind extends GUIItem {

	/**
	 * イベントを保持する要素のIDを取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return 要素のid属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	String getElement();

	/**
	 * event属性の値を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return event属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	String getEvent();

	/**
	 * JavaScript関数を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return func属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	String getFunc();

	/**
	 * ブラウザのキーコードまたは特殊キーを取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return keycode属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	String getKeycode();

	/**
	 * shift属性の値を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	String getShift();

	/**
	 * alt属性の値を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return ALT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	boolean isAlt();

	/**
	 * bubbling属性の値を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *         <code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	boolean isBubbling();

	/**
	 * ctrl属性の値を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	boolean isCtrl();

	/**
	 * shift属性の値を取得します.<br />
	 *
	 * @create 2020/02/07
	 * @return SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	boolean isShift();

	/**
	 * alt属性の値を設定します.<br />
	 *
	 * @create 2020/02/07
	 * @return
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setAlt(boolean alt);

	/**
	 * bubbling属性の値を設定します.<br />
	 *
	 * @create 2020/02/07
	 * @param bubbling バブリング(上位(祖先)コンテナのキー制御を実行)を<code>true:有効にする</code>/
	 *            <code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setBubbling(boolean bubbling);

	/**
	 * ctrl属性の値を設定します.<br />
	 *
	 * @create 2011/04/08
	 * @param ctrl CTRL修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setCtrl(boolean ctrl);

	/**
	 * イベントを保持する要素のIDを設定します.<br />
	 *
	 * @create 2020/02/07
	 * @param element 要素のid属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setElement(String element);

	/**
	 * event属性の値を設定します.<br />
	 *
	 * @create 2020/02/07
	 * @param event event属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setEvent(String event);

	/**
	 * JavaScript関数を設定します.<br />
	 *
	 * @create 2020/02/07
	 * @param func func属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setFunc(String func);

	/**
	 * ブラウザのキーコードまたは特殊キーを設定します.<br />
	 *
	 * @create 2020/02/07
	 * @param keycode keycode属性の値
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setKeycode(String keycode);

	/**
	 * shift属性の値を設定します.<br />
	 *
	 * @create 2020/02/07
	 * @param shift SHIFT修飾キーを<code>true:有効にする</code>/<code>false:無効にする</code>
	 * @author yamashita
	 * @since 20.9.0
	 */
	void setShift(boolean shift);
}