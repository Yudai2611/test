/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * アクションパラメータを装飾するクラスです.<br/>
 * 
 * @create 2011/06/10
 * @author yamashita
 * @since 3.9.0
 */
public interface GActionParamDecorator {

	/** デコレータのデフォルトコールバック関数名. */
	static String DEFAULT_CALLBACK_FUNCTION_NAME = "decorateActionParam";

	/**
	 * アクションパラメータの装飾を行います.<br/>
	 * 
	 * @create 2011/06/10
	 * @param options アクションパラメータ
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	void decorate(GJSONObject options, GUIComponent component);
}
