/*
 * Copyright 2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * アクションパラメータを装飾するための基底クラスです.<br/>
 * 
 * @create 2013/04/18
 * @author yamashita
 * @since 3.10.0.E
 */
public abstract class GActionParamDecoratorBase implements GActionParamDecorator {

	/**
	 * デフォルトコンストラクタ.<br />
	 * 
	 * @create 2013/04/18
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public GActionParamDecoratorBase() {
	}

	/**
	 * アクションパラメータの装飾を行います.<br/>
	 * 
	 * @create 2013/04/18
	 * @param options アクションパラメータ
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public abstract void decorate(GJSONObject options, GUIComponent component);
}
