/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * デコレータのロードおよび管理を行うファクトリクラスです.<br>
 * 
 * @create 2011/06/10
 * @author yamashita
 * @since 3.9.0
 */
public class GActionParamDecoratorFactory {

	/** デコレータマップ */
	private Map<String, GActionParamDecorator> _decorators = null;
	private static GActionParamDecoratorFactory _factory = null;

	/**
	 * {@link GActionParamDecoratorFactory}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/06/10
	 * @param decorators デコレータのマップ
	 * @auther yamashita
	 * @since 3.9.0
	 */
	public GActionParamDecoratorFactory(Map<String, GActionParamDecorator> decorators) {
		_decorators = decorators;
	}

	/**
	 * デコレータを取得します.<br/>
	 * 
	 * @create 2011/06/10
	 * @param decorator デコレータ
	 * @return アクションパラメータを装飾したデコレータ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static GActionParamDecorator getDecorator(String decorator) {
		if (_factory == null) {
			 _factory = GFrameworkUtils.getComponent(GActionParamDecoratorFactory.class.getName());
		}
		if (_factory._decorators.containsKey(decorator)) {
			return _factory._decorators.get(decorator);
		}
		return null;
	}
	
	/**
	 * キャッシュをクリアします.
	 * 
	 * @create 2015/03/31
	 * @author yamashita
	 * @since 3.15.0
	 */
	public static void clear() {
		if (_factory != null) {
			_factory._decorators.clear();
			_factory = null;
		}
	}
}
