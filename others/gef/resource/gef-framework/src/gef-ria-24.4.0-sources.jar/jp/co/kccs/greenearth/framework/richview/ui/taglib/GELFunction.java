/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.utils.GCoreUtils;

/**
 * EL式で使用する機能を提供します.<br/>
 * 
 * @create 2011/06/03
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GELFunction {

	/**
	 * コンテキストパスを取得します.<br/>
	 * 
	 * @create 2011/06/03
	 * @return コンテキストパス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String ctxpath() {
		GWebContext context = GWebContext.getInstance();
		return context.getRequest().getContextPath();
	}

	/**
	 * メッセージリソースからメッセージを取得します.<br/>
	 * 
	 * @create 2011/06/03
	 * @param id リソースID
	 * @return メッセージ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String resource(String id) {
		return GMessageResources.getMessage(id, GFrameworkContext.getInstance().getLocale());
	}

	/**
	 * メッセージリソースからメッセージを取得します.<br/>
	 * 
	 * @create 2011/06/03
	 * @param id リソースID
	 * @param locale ロケール
	 * @return メッセージ
	 * @author yamashita
	 * @since 3.9.0
	 */	
	public static String resourceL(String id, String locale) {
		return GMessageResources.getMessage(id, GCoreUtils.getLocale(locale));
	}
}