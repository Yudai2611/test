/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.framework.richview.ui.event.GEvent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;

/**
 * イベントが実行可能かを示すインターフェースです.<br/>
 * 
 * @create 2011/04/05
 * @author yamashita
 * @since 3.9.0
 */
public interface GEventableTag extends Tag {

	/**
	 * イベント系タグのoptions属性に追記します.<br />
	 * 
	 * @create 2011/08/02
	 * @param options イベント系タグのoptions属性{@link GJSONObject}
	 * @author yamashita
	 * @since 3.9.0
	 */
	void bindOptions(GJSONObject options);

	/**
	 * 指定されたスクリプトを、このタグ又は親タグで実行されるよう対象の要素に関連付けます.<br />
	 * 
	 * @create 2011/04/05
	 * @param script スクリプト
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	void bindScript(String script) throws JspException;

	/**
	 * 指定された主処理を行うスクリプトを、指定されたイベントタイプで実行されるよう対象の要素に関連付けます.<br/>
	 * 
	 * @create 2011/04/05
	 * @param event イベント
	 * @param script スクリプトビルダー
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	void bindScript(String event, GJavaScriptBuilder script) throws JspException;

	/**
	 * 現在のイベントを返します.<br />
	 * 
	 * @create 2011/04/05
	 * @return 現在のイベント
	 * @author yamashita
	 * @since 3.9.0
	 */
	GEvent currentEvent();

	/**
	 * id属性の値を取得します.<br />
	 * 
	 * @create 2011/07/18
	 * @return id属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getId();
}
