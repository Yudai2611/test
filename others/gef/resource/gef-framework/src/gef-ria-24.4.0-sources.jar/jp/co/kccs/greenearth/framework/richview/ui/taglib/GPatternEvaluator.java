/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * パターン評価を示すインターフェイスです.<br />
 * 
 * @create 2011/06/13
 * @author kobayashi
 * @since 3.9.0
 */
public interface GPatternEvaluator {

	/**
	 * パターン文字列を評価し変換します.<br/>
	 * 
	 * @create 2011/06/13
	 * @param component コンポーネント
	 * @return 変換後のパターン文字列
	 * @author kobayashi
	 * @since 3.9.0
	 */
	String convert(GUIComponent component);
}
