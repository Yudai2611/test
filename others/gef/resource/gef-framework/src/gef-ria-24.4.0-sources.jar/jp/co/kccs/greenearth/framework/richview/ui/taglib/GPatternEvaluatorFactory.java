/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * エヴァリュエーターのロードおよび管理を行うファクトリクラスです.<br>
 * 
 * @create 2011/06/13
 * @author kobayashi
 * @since 3.9.0
 */
public class GPatternEvaluatorFactory {

	/** {@link PatternConverter}を格納するコレクション. */
	protected Map<String, GPatternEvaluator> _evaluators = null;
	private static GPatternEvaluatorFactory _factory = null;

	/**
	 * {@link GPatternEvaluator}の一覧を指定して、{@link GPatternEvaluatorFactory}
	 * インスタンスを初期化します.<br />
	 * 
	 * @create 2011/06/13
	 * @param evaluators {@link GPatternEvaluator}の一覧
	 * @auther kobayashi
	 * @since 3.9.0
	 */
	public GPatternEvaluatorFactory(Map<String, GPatternEvaluator> evaluators) {
		_evaluators = evaluators;
	}

	/**
	 * 指定したパターンに該当する{@link GPatternEvaluator}を取得します.<br />
	 * 
	 * @create 2011/06/13
	 * @param pattern パターン
	 * @return パターンに該当する{@link GPatternEvaluator}
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public static GPatternEvaluator getEvaluator(String pattern) {
		if (_factory == null) {
			_factory = GFrameworkUtils.getComponent(GPatternEvaluatorFactory.class.getName());
		}
		if (_factory._evaluators.containsKey(pattern)) {
			return _factory._evaluators.get(pattern);
		}
		return null;
	}
	
	/**
	 * キャッシュをクリアします.
	 * 
	 * @create 2015/03/31
	 * @author yamashita
	 * @since 3.15.0
	 */
	public static void clear() {
		if (_factory != null) {
			_factory._evaluators.clear();
			_factory = null;
		}
	}
}
