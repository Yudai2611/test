/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * コンポーネントに応じた接頭語を取得するクラスです.<br/>
 * 
 * @create 2011/06/13
 * @author kobayashi
 * @since 3.9.0
 */
public class GPrefixPatternEvaluator implements GPatternEvaluator {

	/**
	 * {@link GPrefixPatternEvaluator}の新しいインスタンスを初期化します.<br/>
	 * 
	 * @create 2011/06/13
	 * @auther kobayashi
	 * @since 3.9.0
	 */
	public GPrefixPatternEvaluator() {
	}

	/**
	 * コンポーネントに応じた接頭語を取得します.<br/>
	 * 
	 * @create 2011/06/13
	 * @param component コンポーネント
	 * @return 接頭語
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String convert(GUIComponent component) {
		return component.getPrefix();
	}
}
