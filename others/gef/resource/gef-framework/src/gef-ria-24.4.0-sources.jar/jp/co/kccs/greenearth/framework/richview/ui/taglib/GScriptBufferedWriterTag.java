/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jakarta.servlet.jsp.JspException;

/**
 * JavaScript文字列のバッファ、一括書き出しが可能かを示すインターフェースです.<br/>
 * 
 * @create 2011/05/23
 * @author yamashita
 * @since 3.9.0
 */
public interface GScriptBufferedWriterTag {

	/**
	 * エレメントを追加します.<br />
	 * 
	 * セットされるelementはエスケープ済みHTML文字列である必要があります。
	 * 
	 * @create 2011/05/23
	 * @param element エレメント
	 * @author yamashita
	 * @since 3.9.0
	 */
	void appendElement(String element);

	/**
	 * JavaScript文字列を追加します.<br />
	 * 
	 * セットされるpartsはエスケープ済みJavaScript文字列である必要があります。
	 * 
	 * @create 2011/05/23
	 * @param parts JavaScript文字列
	 * @author yamashita
	 * @since 3.9.0
	 */
	void appendParts(String parts);

	/**
	 * 対象となる要素のタグ終了時点で、要素にバインドされたスクリプトを一括して出力します.<br />
	 * 
	 * @create 2011/05/23
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	void writeScript() throws JspException;
}