/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;

/**
 * {@link GScriptBufferedWriterTag}クラス専用のユーティリティクラスです.<br>
 * 
 * @create 2011/06/15
 * @author yamashita
 * @since 3.9.0
 */
public final class GScriptBufferedWriterTagUtils {

	/**
	 * コンストラクタ
	 * 
	 * @create 2011/09/18
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GScriptBufferedWriterTagUtils() {
	}

	/**
	 * JavaScriptを生成します.<br/>
	 * 
	 * @create 2011/06/15
	 * @param partsBuilder エスケープ済みJavaScript
	 * @param elementsBuilder エスケープ済みXHTMLエレメント
	 * @return スクリプト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String createScript(StringBuilder partsBuilder, StringBuilder elementsBuilder) {
		StringBuilder out = new StringBuilder();
		if (partsBuilder != null) {
			String parts = partsBuilder.toString();
			if (!GStringUtils.isEmpty(parts)) {
				GTagBuilder scriptBuilder = new GTagBuilder("script");
				scriptBuilder.setAttribute("type", "text/javascript");
				scriptBuilder.setInnerText(" " + parts);
				out.append(scriptBuilder.createTagString(false));
			}
		}
		if (elementsBuilder != null) {
			String elements = elementsBuilder.toString();
			if (!GStringUtils.isEmpty(elements)) {
				out.append(elements);
			}
		}
		return out.toString();
	}
}
