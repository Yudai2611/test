/*
 * Copyright 2011-2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.Tag;
import jakarta.servlet.jsp.tagext.TagSupport;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.json.GJSONObject;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.richview.ui.GStyle;
import jp.co.kccs.greenearth.framework.richview.ui.GStyleClass;
import jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPIncludeView;
import jp.co.kccs.greenearth.framework.richview.ui.control.taglib.GEnablableTag;
import jp.co.kccs.greenearth.framework.richview.ui.event.GEvent;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GView;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;
import jp.co.kccs.greenearth.framework.view.component.taglib.GJavaScriptBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder;
import jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag;
import jp.co.kccs.greenearth.framework.view.component.taglib.GViewInterfaceTag;

/**
 * {@link GUIComponentBase}のレンダリング用カスタムタグを表します.<br />
 *
 * @create 2011/04/14
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIComponentBaseTag extends TagSupport implements GUIComponentTag, GEventableTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 5699281223894744261L;
	/** ウィジェットのデフォルト名前空間. */
	public final static String DEFAULT_WIDGET_NAMESPACE = "geui";
	/** 【XHTML拡張属性】名前空間. */
	public final static String XHTML_EXTENSION_ATTRIBUTE_NAMESPACE_KEY = "geframe.richview.XHtml.Ex.Attr.Namespace";
	/** 【XHTML拡張属性】ウィジェットのクラス名. */
	public final static String XHTML_EXTENSION_ATTRIBUTE_WIDGETCLASS_KEY = "geframe.richview.XHtml.Ex.Attr.Widgetclass";
	/** 【XHTML拡張属性】ウィジェットのオプション. */
	public final static String XHTML_EXTENSION_ATTRIBUTE_OPTIONS_KEY = "geframe.richview.XHtml.Ex.Attr.Options";
	/** 【XHTML拡張属性】プレーンタグ用のタグ名. */
	public final static String XHTML_EXTENSION_ATTRIBUTE_TAG_KEY = "geframe.richview.XHtml.Ex.Attr.Tag";
	/** 【XHTML拡張属性】プレーンタグ用の書式文字列. */
	public final static String XHTML_EXTENSION_ATTRIBUTE_FORMAT_KEY = "geframe.richview.XHtml.Ex.Attr.Format";
	/** 【XHTML拡張属性】プレーンタグ用のロケール文字列. */
	public final static String XHTML_EXTENSION_ATTRIBUTE_LOCALE_KEY = "geframe.richview.XHtml.Ex.Attr.Locale";
	/** 【XHTML拡張属性】プレーンタグ用の初期値. */
	public final static String XHTML_EXTENSION_ATTRIBUTE_INITVALUE_KEY = "geframe.richview.XHtml.Ex.Attr.Initvalue";
	/** 【XHTML拡張属性】プレーンタグ用の初期値. */
	public static final String XHTML_EXTENSION_ATTRIBUTE_CLEAR_KEY = "geframe.richview.XHtml.Ex.Attr.Clear";

	/** 【UI拡張機能】 noFocusOnReadonlyのデフォルト値. */
	public static final String UI_EXTENTION_FUNCTION_NOFOCUSONREADONLY_KEY = "geframe.richview.ui.Default.NoFocusOnReadonly";

	// XHTML属性
	/** id属性の値. */
	private String _id = null;
	/** class属性の値. */
	private GStyleClass _styleclass = null;
	/** style属性の値. */
	private GStyle _style = null;
	/** title属性の値. */
	private String _title = null;
	/** xml:lang属性の値. */
	private String _lang = null;
	/** dir属性の値. */
	private String _dir = null;
	/** xml:space属性の値. */
	private String _space = null;
	/** onclick属性の値. */
	private String _onclick = null;
	/** ondbclick属性の値. */
	private String _ondblclick = null;
	/** onkeydown属性の値. */
	private String _onkeydown = null;
	/** onkeypress属性の値. */
	private String _onkeypress = null;
	/** onkeyup属性の値. */
	private String _onkeyup = null;
	/** onmousedown属性の値. */
	private String _onmousedown = null;
	/** onmousemove属性の値. */
	private String _onmousemove = null;
	/** onmouseout. */
	private String _onmouseout = null;
	/** onmouseover属性の値. */
	private String _onmouseover = null;
	/** onmouseup属性の値. */
	private String _onmouseup = null;

	// 拡張属性
	/** visible属性の値. */
	private String _visible = null;
	/** options属性の値. */
	private GJSONObject _options = null;
	
	// 内部変数
	/** イベント一覧 */
	private List<GEvent> _events = new ArrayList<GEvent>();
	/** イベント一覧カーソル */
	private Iterator<GEvent> _eventIterator;
	/** ID接頭語 */
	private String _prefix;
	/** リクエストパラメータキーの完全な接頭語 */
	private String _namePrefix;
	/** 完全なID */
	private String _fullId;
	/** エラー項目の表示名の名前空間 */
	private String _labelspace;

	/** HTMLイベントリスト. */
	private static List<String> htmlEvents = new ArrayList<String>();
	static {
		htmlEvents.add("blur");
		htmlEvents.add("change");
		htmlEvents.add("focus");
		htmlEvents.add("select");
		htmlEvents.add("reset");
		htmlEvents.add("submit");
		htmlEvents.add("load");
		htmlEvents.add("unload");
		htmlEvents.add("click");
		htmlEvents.add("dblclick");
		htmlEvents.add("keydown");
		htmlEvents.add("keypress");
		htmlEvents.add("keyup");
		htmlEvents.add("mousedown");
		htmlEvents.add("mousemove");
		htmlEvents.add("mouseout");
		htmlEvents.add("mouseover");
		htmlEvents.add("mouseup");
		htmlEvents.add("contextmenu");
	}

	/**
	 * {@link GUIComponentBaseTag}の新しいインスタンスを初期化します.<br />
	 *
	 * @create 2011/04/14
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponentBaseTag() {
		reset();
	}

	/**
	 * イベント系タグのoptions属性に追記します.<br />
	 *
	 * @create 2011/08/02
	 * @param options イベント系タグのoptions属性{@link GJSONObject}
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void bindOptions(GJSONObject options) {
	}

	/**
	 * 指定されたスクリプトを、このタグ又は親タグで実行されるよう対象の要素に関連付けます.<br />
	 * セットされるscriptはエスケープ済みJavaScript文字列であること！
	 *
	 * @create 2011/05/21
	 * @param script スクリプト
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void bindScript(String script) throws JspException {
		if (!isWritable()) {
			return;
		}
		if (GStringUtils.isEmpty(script)) {
			return;
		}
		GScriptBufferedWriterTag bufferTag = null;
		if (this instanceof GScriptBufferedWriterTag) {
			bufferTag = (GScriptBufferedWriterTag) this;
		} else {
			Tag tag = findAncestorWithClass(this, GScriptBufferedWriterTag.class);
			if (tag == null) {
				return;
			}
			bufferTag = (GScriptBufferedWriterTag) tag;
		}
		bufferTag.appendParts(script);
	}

	/**
	 * スクリプト出力可能かどうかを判定します.<br/>
	 *
	 * @return true: 出力可能／false: 出力不可能
	 * @create 2013/07/20
	 * @author KCCS yamashita
	 * @since 3.12.0
	 */
	protected boolean isWritable() throws JspException {
		if (!isWidget() && (this instanceof GEnablableTag)) {
			GEnablableTag self = (GEnablableTag) this;
			if (!self.isEnabled()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 指定された主処理を行うスクリプトを、指定されたイベントタイプで実行されるよう対象の要素に関連付けます.<br />
	 *
	 * 対象の要素とは{@link GScriptBufferedWriterTag}を実装しているカスタムタグのことを示します.<br />
	 *
	 * HTMLイベント ⇒
	 * 	$(document).on('event', '#' + $.ge.escSelectorString('hoge'), function(event){mainscript;});
	 * Widgetイベント（上記以外） ⇒
	 * 	$(document).on('widgetname' + '.event', '#' + $.ge.escSelectorString('hoge'), function(event){mainscript;});
	 *
	 * @create 2011/04/15
	 * @param event イベントタイプ
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void bindScript(String event, GJavaScriptBuilder scriptBuilder) throws JspException {
		if (!isWritable()) {
			return;
		}
		if (event == null) {
			throw new IllegalArgumentException("\"event\" is not specified.");
		}

		GJavaScriptBuilder bindScriptBuilder = new GJavaScriptBuilder();
		bindScriptBuilder.append("$(function(){$.ge.idSelector(??).", bindTarget());
		bindScriptBuilder.append("on('");
		if (!isHTMLEvent(event)) {
			bindScriptBuilder.append(getWidgetClassName());
		}
		bindScriptBuilder.append(event);
		bindScriptBuilder.append("',function(event){");
		bindMainScript(event, scriptBuilder, bindScriptBuilder);
		bindScriptBuilder.append("});});");

		bindScript(bindScriptBuilder.toString());
	}

	/**
	 * 現在のイベントを返します.<br />
	 *
	 * @create 2011/04/14
	 * @return 現在のイベント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GEvent currentEvent() {
		if (_eventIterator != null && _eventIterator.hasNext()) {
			return _eventIterator.next();
		}
		return null;
	}

	/**
	 * 終了タグが呼び出されたときに実行されるメソッドです.<br>
	 *
	 * @see jakarta.servlet.jsp.tagext.TagSupport#doEndTag()
	 * @create 2011/04/14
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}
	 *         :JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public int doEndTag() throws JspException {
		int result = super.doEndTag();
		reset();
		return result;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 *
	 * @create 2011/04/14
	 * @param component レンダリング対象UIコンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void load(GUIComponent component) {
		GUIComponentBase ui = (GUIComponentBase) component;
		GUIComponentBase rep = (GUIComponentBase) component.getRepository();
		setId(ui.getId());
		setStyle(evaluatePlaceholder(getFieldValueWithoutEL(ui.getDecodeStyle(),
				getDecodeStyle(), rep == null ? null : rep.getDecodeStyle()), ui));
		setStyleclass(evaluatePlaceholder(getFieldValueWithoutEL(ui.getDecodeStyleclass(),
				getDecodeStyleclass(), rep == null ? null : rep.getDecodeStyleclass()), ui));
		setTitle(evaluatePlaceholder(ui.getTitle(), getTitle(),
				rep == null ? null : rep.getTitle(), ui));
		setLang(evaluatePlaceholder(ui.getLang(), getLang(),
				rep == null ? null : rep.getLang(), ui));
		setDir(evaluatePlaceholder(ui.getDir(), getDir(),
				rep == null ? null : rep.getDir(), ui));
		setSpace(evaluatePlaceholder(ui.getSpace(), getSpace(),
				rep == null ? null : rep.getSpace(), ui));
		setOnclick(evaluatePlaceholder(ui.getOnclick(), getOnclick(),
				rep == null ? null : rep.getOnclick(), ui));
		setOndblclick(evaluatePlaceholder(ui.getOndblclick(), getOndblclick(),
				rep == null ? null : rep.getOndblclick(), ui));
		setOnkeydown(evaluatePlaceholder(ui.getOnkeydown(), getOnkeydown(),
				rep == null ? null : rep.getOnkeydown(), ui));
		setOnkeypress(evaluatePlaceholder(ui.getOnkeypress(), getOnkeypress(),
				rep == null ? null : rep.getOnkeypress(), ui));
		setOnkeyup(evaluatePlaceholder(ui.getOnkeyup(), getOnkeyup(),
				rep == null ? null : rep.getOnkeyup(), ui));
		setOnmousedown(evaluatePlaceholder(ui.getOnmousedown(), getOnmousedown(),
				rep == null ? null : rep.getOnmousedown(), ui));
		setOnmousemove(evaluatePlaceholder(ui.getOnmousemove(), getOnmousemove(),
				rep == null ? null : rep.getOnmousemove(), ui));
		setOnmouseout(evaluatePlaceholder(ui.getOnmouseout(), getOnmouseout(),
				rep == null ? null : rep.getOnmouseout(), ui));
		setOnmouseover(evaluatePlaceholder(ui.getOnmouseover(), getOnmouseover(),
				rep == null ? null : rep.getOnmouseover(), ui));
		setOnmouseup(evaluatePlaceholder(ui.getOnmouseup(), getOnmouseup(),
				rep == null ? null : rep.getOnmouseup(), ui));
		setVisible(evaluatePlaceholder(ui.getVisible(), getVisible(),
				rep == null ? null : rep.getVisible(), ui));
		setOptions(ui.getDecodeOptions());
		setPrefix(ui.getPrefix());
		setNamePrefix(ui.getNamePrefix());
		setFullId(ui.getFullId());
		setEvents(ui.getEvents());
		setLabelspace(ui.getLabelspace());
	}

	/**
	 * このコンポーネントのウィジェットオプションを登録します.<br />
	 *
	 * @create 2011/05/16
	 * @param key オプションのキー
	 * @param value オプションの値
	 * @return 登録する値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public Object putOption(String key, Object value) {
		if (_options == null) {
			_options = new GJSONObject();
		}
		return _options.put(key, value);
	}

	/**
	 * タグの状態をリセット(初期化)します.<br />
	 *
	 * @create 2011/04/14
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void reset() {
		_eventIterator = null;
		_options = null;
		_style = null;
		_styleclass = null;
	}

	/**
	 * 主処理を行うスクリプトを、対象の要素がレンダリングするように関連付けます.<br/>
	 * 対象の要素とは{@link GScriptBufferedWriterTag}を実装しているカスタムタグのことを示します.<br />
	 *
	 * @param event イベントタイプ
	 * @param scriptBuilder 主処理を行うスクリプト
	 * @param bindScriptBuilder 関連付け先のスクリプトバッファ
	 * @throws JspException 関連付けに失敗したとき
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void bindMainScript(String event, GJavaScriptBuilder scriptBuilder, GJavaScriptBuilder bindScriptBuilder)
		throws JspException {
		bindScriptBuilder.append(scriptBuilder.toString());
	}

	/**
	 * スクリプトをバインドするターゲット要素のid属性の値を取得します.<br />
	 *
	 * @create 2011/08/02
	 * @return バインドターゲット
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected String bindTarget() {
		return getFullId();
	}

	/**
	 * 指定されたタグにこのタグの属性を追加します. <br>
	 *
	 * @create 2011/04/14
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void decorateAttribute(GTagBuilder builder) {
		if (getId() != null) {
			builder.setAttribute("id", getFullId());
		}
		builder.setAttribute("dir", getDir());
		builder.setAttribute("title", getTitle());
		builder.setAttribute("xml:lang", getLang());
		builder.setAttribute("xml:space", getSpace());
		decorateStyleAttribute(builder); // style属性
		decorateStyleClassAttribute(builder); // class属性
		if (isWidget()) {
			decorateWidgetAttribute(builder); // widget属性
		}
		decorateEventAttribute(builder); // イベント属性
	}

	/**
	 * 指定されたタグにこのタグのイベントハンドラ属性を追加します.<br>
	 *
	 * @create 2011/04/14
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected void decorateEventAttribute(GTagBuilder builder) {
		builder.setAttribute("onclick", getOnclick());
		builder.setAttribute("ondblclick", getOndblclick());
		builder.setAttribute("onkeydown", getOnkeydown());
		builder.setAttribute("onkeypress", getOnkeypress());
		builder.setAttribute("onkeyup", getOnkeyup());
		builder.setAttribute("onmousedown", getOnmousedown());
		builder.setAttribute("onmousemove", getOnmousemove());
		builder.setAttribute("onmouseout", getOnmouseout());
		builder.setAttribute("onmouseover", getOnmouseover());
		builder.setAttribute("onmouseup", getOnmouseup());
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイル属性を追加します. <br>
	 *
	 * @create 2011/04/26
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void decorateStyleAttribute(GTagBuilder builder) {
		builder.setAttribute("style", getStyle());
	}

	/**
	 * 指定されたタグビルダーにこのタグのスタイルクラス属性を追加します. <br>
	 *
	 * @create 2011/04/26
	 * @param builder 属性を追記する{@link GTagBuilder}
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void decorateStyleClassAttribute(GTagBuilder builder) {
		builder.setAttribute("class", getStyleclass());
	}

	/**
	 * 指定したスタイルクラスを、フラグに応じて追加あるいは削除します.<br>
	 *
	 * @create 2013/06/17
	 * @param styleClass スタイルクラス
	 * @param shouldAdd スタイルクラスの追加/削除を判定するフラグ
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected void toggleStyleClassAttribute(String styleClass, boolean shouldAdd) {
		toggleStyleClassAttribute(getDecodeStyleclass(), styleClass, shouldAdd);
	}

	/**
	 * 指定したスタイルクラスを、フラグに応じて追加あるいは削除します.<br>
	 *
	 * @create 2013/06/17
	 * @param styleclass スタイルクラス
	 * @param styleClass スタイルクラス
	 * @param shouldAdd スタイルクラスの追加/削除を判定するフラグ
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected void toggleStyleClassAttribute(GStyleClass styleclass, String styleClass, boolean shouldAdd) {
		if (shouldAdd) {
			styleclass.add(styleClass);
		} else {
			styleclass.remove(styleClass);
		}
	}

	/**
	 * 指定されたタグにこのタグのwidget属性を追加します. <br>
	 * 1.スーパークラスで定義された属性及び、本クラスで定義する、以下の属性を付加します。<br>
	 * (属性の一覧はクラスのドキュメントを参照ください。)<br>
	 *
	 * [1]namespace属性<br>
	 * [2]widgetclass属性<br>
	 * [3]options属性<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.richview.ui.taglib.GUIComponentBaseTag#decorateWidgetAttribute(jp.co.kccs.greenearth.framework.view.component.taglib.GTagBuilder)
	 * @create 2011/04/26
	 * @param builder 属性を追記するGTagBuilder
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void decorateWidgetAttribute(GTagBuilder builder) {
		builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_WIDGETCLASS_KEY),
			getWidgetClassName());
		builder
			.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_NAMESPACE_KEY), getWidgetNamespace());
		//GJSONObject options = new GJSONObject(getOptions());
		GJSONObject options = new GJSONObject(getDecodeOptions());
		decorateWidgetOptions(options);
		if (!options.isEmpty()) {
			builder.setAttribute(GFrameworkUtils.getProperty(XHTML_EXTENSION_ATTRIBUTE_OPTIONS_KEY), options.encode());
		}
	}

	/**
	 * options属性に含まれるwidgetに対するオプション属性値を設定します.<br>
	 * カスタムタグ属性値をXHTMLのoptions属性に出力する場合、 このメソッドをオーバーライドして処理を追加してください。<br>
	 * 引数optionsにカスタムタグ属性値を追加するとXHTMLに出力されます。<br>
	 *
	 * @create 2011/06/06
	 * @param options オプション
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void decorateWidgetOptions(GJSONObject options) {
	}

	/**
	 * 指定されたfieldValueの中に含まれる([%XXXX]のような)プレースホルダーを評価した値を返します.<br />
	 *
	 * @create 2011/06/13
	 * @param fieldValue フィールド値
	 * @param component UIコンポーネント
	 * @return プレースフォルダーを展開した値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	@SuppressWarnings("unchecked")
	protected <T> T evaluatePlaceholder(T fieldValue, GUIComponent component) {
		if (fieldValue == null) {
			return null;
		}
		if (fieldValue instanceof String) {
			StringBuffer sb = new StringBuffer();
			Pattern p = Pattern.compile("\\[%(.*?)\\]");
			Matcher m = p.matcher((String) fieldValue);
			while (m.find()) {
				String key = m.group(1);
				GPatternEvaluator evaluator = GPatternEvaluatorFactory.getEvaluator(key);
				if (evaluator != null) {
					m.appendReplacement(sb, evaluator.convert(component));
				}
			}
			m.appendTail(sb);
			return (T) sb.toString();
		}
		return fieldValue;
	}

	/**
	 * 指定されたuiFieldValue,tagFieldValue,repFieldValueの中からEL式を含まない値を選択し、
	 * その中に含まれる([%XXXX]のような)プレースホルダーを展開した文字列を返します.<br />
	 *
	 * @create 2011/06/13
	 * @param uiFieldValue UIコンポーネントのフィールド値
	 * @param tagFieldValue Tagのフィールド値
	 * @param repFieldValue UIコンポーネント(リポジトリ)のフィールド値
	 * @param component UIコンポーネント
	 * @return プレースフォルダーを展開した値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	protected <T> T evaluatePlaceholder(T uiFieldValue, T tagFieldValue, T repFieldValue,
		GUIComponent component) {
		if (component == null) {
			throw new IllegalArgumentException("component is null.");
		}
		return evaluatePlaceholder(getFieldValueWithoutEL(uiFieldValue, tagFieldValue, repFieldValue), component);
	}

	/**
	 * イベント系タグ（{@link GEventableTag}）を取得します.<br />
	 *
	 * @create 2011/08/02
	 * @return イベント系タグ
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected GEventableTag getEventableTag() throws JspException {
		Tag tag = findAncestorWithClass(this, GEventableTag.class);
		if (tag == null) {
			throw new JspException("\"GEventableTag\" not found.");
		}
		return (GEventableTag) tag;
	}

	/**
	 * リポジトリとUIのビュークラス、タグクラスの属性値を比較してEL式を含まない値を返します.<br />
	 *
	 * タグクラスの属性値はEL式展開後の値となることを考慮し、以下の処理を行っています。<br/>
	 * ①UI、リポジトリが同値の場合 ： タグの値（EL式展開後）を返す<br/>
	 * (ビジネスロジックでUIの値に変更がない→UIは展開前のEL式を含むんでいる可能性がある)<br/>
	 * ②UI、リポジトリが異なる値の場合： UIの値を返す<br/>
	 * (ビジネスロジックでUIの値に変更があった→UIは処理された反映されるべき値＆EL式を含まない)<br/>
	 *
	 * @create 2011/06/06
	 * @param uiFieldValue UIコンポーネントのフィールド値
	 * @param tagFieldValue Tagのフィールド値
	 * @param repFieldValue UIコンポーネント(リポジトリ)のフィールド値
	 * @return EL式を含まないフィールド値
	 * @author kobayashi
	 * @since 3.9.0
	 */
	private <T> T getFieldValueWithoutEL(T uiFieldValue, T tagFieldValue, T repFieldValue) {
		if (uiFieldValue == null) {
			return null;
		}
		return !uiFieldValue.equals(repFieldValue) ? uiFieldValue : tagFieldValue;
	}

	/**
	 * styleの各プロパティに{@link GUIComponentBaseTag#evaluatePlaceholder(Object, GUIComponent)}
	 * を適用します
	 * 
	 * @create 2015/03/25
	 * @param fieldValues フィールド値
	 * @param component UIコンポーネント
	 * @return プレースフォルダ―を展開したフィールド値
	 * @author nakamura
	 * @since 3.15.0
	 */
	protected GStyleClass evaluatePlaceholder(GStyleClass fieldValues, GUIComponent component) {
		List<String> evaluatedValues = new ArrayList<String>();

		for (int idx = 0; idx < fieldValues.size(); idx++) {
			evaluatedValues.add(evaluatePlaceholder(fieldValues.get(idx), component));
		}
		return new GStyleClass(evaluatedValues);
	}
	/**
	 * リポジトリとUIのビュークラス、タグクラスの属性値を比較してEL式を含まない値のリストを返します.<br />
	 * 
	 * ①UI、リポジトリ―で要素数が異なる場合：UIを返す
	 * ②UI、リポジトリ―で要素数が同じで要素が異なる場合：UIを返す
	 * ③UI、リポジトリ―で要素数が同じで要素が同値の場合：タグを返す
	 * 
	 * @create 2015/03/25
	 * @param uiFieldValues UIコンポーネントのフィールド値
	 * @param tagFieldValues Tagのフィールド値
	 * @param repFieldValues UIコンポーネント(リポジトリ)のフィールド値
	 * @return EL式を含まないフィールド値
	 * @author nakamura
	 * @since 3.15.0
	 */
	protected GStyleClass getFieldValueWithoutEL(GStyleClass uiFieldValues, GStyleClass tagFieldValues, GStyleClass repFieldValues) {
		if (uiFieldValues == null && repFieldValues == null) {
			return tagFieldValues;
		}
		if (uiFieldValues != null && repFieldValues == null) {
			return uiFieldValues;
		}
		if (uiFieldValues == null && repFieldValues != null) {
			return null;
		}
		if (uiFieldValues.size() == 0 && repFieldValues.size() == 0) {
			return tagFieldValues;
		}
		if (uiFieldValues.size() != repFieldValues.size()) {
			return uiFieldValues;
		}
		for (int idx = 0; idx < uiFieldValues.size(); idx++) {
			if (!uiFieldValues.get(idx).equals(repFieldValues.get(idx))) {
				return uiFieldValues;
			}
		}
		return tagFieldValues;
	}
	/**
	 * styleClassの各プロパティに{@link GUIComponentBaseTag#evaluatePlaceholder(Object, GUIComponent)}
	 * を適用します
	 * 
	 * @create 2015/03/25
	 * @param fieldValues UIコンポーネントのフィールド値
	 * @param component UIコンポーネント
	 * @return プレースフォルダ―を展開したフィールド値のリスト
	 * @author nakamura
	 * @since 3.15.0
	 */
	protected GStyle evaluatePlaceholder(GStyle fieldValues, GUIComponent component) {
		Map<String, String> evaluatedValueMap = new HashMap<String, String>();

		for (Entry<String, String> value : fieldValues.getStyleMap().entrySet()) {
			evaluatedValueMap.put(value.getKey(), evaluatePlaceholder(value.getValue(), component));
		}
		return new GStyle(evaluatedValueMap);
	}
	/**
	 * リポジトリとUIのビュークラス、タグクラスの属性値を比較してEL式を含まない値のリストを返します.<br />
	 * 
	 * ①UI、リポジトリ―で要素数が異なる場合：UIを返す
	 * ②UI、リポジトリ―で要素数が同じで要素が異なる場合：UIを返す
	 * ③UI、リポジトリ―で要素数が同じで要素が同値の場合：タグを返す
	 * 
	 * @create 2015/03/25
	 * @param uiFieldValues UIコンポーネントのフィールド値
	 * @param tagFieldValues Tagのフィールド値
	 * @param repFieldValues  UIコンポーネント(リポジトリ)のフィールド値
	 * @return EL式を含まないフィールド値
	 * @author nakamura
	 * @since 3.15.0
	 */
	protected GStyle getFieldValueWithoutEL(GStyle uiFieldValues, GStyle tagFieldValues, GStyle repFieldValues) {
		
		if (uiFieldValues == null && repFieldValues == null) {
			return tagFieldValues;
		} 
		if (uiFieldValues != null && repFieldValues == null) {
			return uiFieldValues;
		}
		if (uiFieldValues == null && repFieldValues != null) {
			return null;
		}

		Map<String, String> uiFieldValuesMap = uiFieldValues.getStyleMap();
		Map<String, String> repFieldValuesMap = repFieldValues.getStyleMap();

		if (uiFieldValuesMap.size() == 0 && repFieldValuesMap.size() == 0) {
			return tagFieldValues;
		}
		if (uiFieldValuesMap.size() != repFieldValuesMap.size()) {
			return uiFieldValues;
		}
		for (Entry<String, String> value : uiFieldValuesMap.entrySet()) {
			String key = value.getKey();
			String val = value.getValue();

			if (!repFieldValuesMap.containsKey(key)) {
				return uiFieldValues;
			}

			if (!val.equals(repFieldValuesMap.get(key))) {
				return uiFieldValues;
			}
		}
		return tagFieldValues;
	}
	/**
	 * ウィジェットオプションを取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return ウィジェットオプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GJSONObject getDecodeOptions() {
		if (_options == null) {
			_options = new GJSONObject();
		}
		return _options;
	}

	/**
	 * デコードされたstyle属性の値を取得します.<br />
	 *
	 * @create 2011/04/22
	 * @return style属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyle getDecodeStyle() {
		if (_style == null) {
			_style = new GStyle();
		}
		return _style;
	}

	/**
	 * デコードされたclass属性の値を取得します.<br />
	 *
	 * @create 2011/04/22
	 * @return class属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GStyleClass getDecodeStyleclass() {
		if (_styleclass == null) {
			_styleclass = new GStyleClass();
		}
		return _styleclass;
	}

	/**
	 * dir属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return dir属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getDir() {
		return _dir;
	}

	/**
	 * このタグに登録されたイベント一覧を返します.<br />
	 *
	 * @create 2011/04/14
	 * @return イベント一覧
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GEvent> getEvents() {
		return _events;
	}

	/**
	 * このコンポーネントの完全なIDを取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return 完全なID
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getFullId() {
		return _fullId;
	}

	/**
	 * id属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return id属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public String getId() {
		return _id;
	}

	/**
	 * エラー項目の表示名の名前空間を設定します.<br />
	 *
	 * @create 2011/06/07
	 * @return labelspace 表示名の名前空間
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLabelspace() {
		return _labelspace;
	}

	/**
	 * xml:lang属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return xml:lang属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getLang() {
		return _lang;
	}

	/**
	 * リクエストパラメータキーの接頭語を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return リクエストパラメータキーの接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getNamePrefix() {
		return _namePrefix;
	}

	/**
	 * onclick属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnclick() {
		return _onclick;
	}

	/**
	 * ondbclick属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return ondbclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOndblclick() {
		return _ondblclick;
	}

	/**
	 * onkeydown属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onkeydown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnkeydown() {
		return _onkeydown;
	}

	/**
	 * onkeypress属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onkeypress属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnkeypress() {
		return _onkeypress;
	}

	/**
	 * onkeyup属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onkeyup属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnkeyup() {
		return _onkeyup;
	}

	/**
	 * onmousedown属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onmousedown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmousedown() {
		return _onmousedown;
	}

	/**
	 * onmousemove属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onmousemove属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmousemove() {
		return _onmousemove;
	}

	/**
	 * onmouseout属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onmouseout属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmouseout() {
		return _onmouseout;
	}

	/**
	 * onmouseover属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onmouseover属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmouseover() {
		return _onmouseover;
	}

	/**
	 * onmouseup属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return onmouseup属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOnmouseup() {
		return _onmouseup;
	}

	/**
	 * options属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return ウィジェットオプション(JSON表現の文字列)
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getOptions() {
		if (_options != null && !_options.isEmpty()) {
			return _options.encode();
		}
		return null;
	}

	/**
	 * このコンポーネントのID接頭語を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return 接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getPrefix() {
		return _prefix;
	}

	/**
	 * xml:space属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return xml:space属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getSpace() {
		return _space;
	}

	/**
	 * style属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return style属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getStyle() {
		if (_style != null && !_style.isEmpty()) {
			return _style.encode();
		}
		return null;
	}

	/**
	 * class属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return class属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getStyleclass() {
		if (_styleclass != null && !_styleclass.isEmpty()) {
			return _styleclass.encode();
		}
		return null;
	}

	/**
	 * title属性の値を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @return title属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getTitle() {
		return _title;
	}

	/**
	 * visible属性の値を取得します.<br />
	 *
	 * @create 2011/06/14
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public String getVisible() {
		return _visible;
	}

	/**
	 * widgetクラス名を取得します.<br />
	 *
	 * @create 2011/04/30
	 * @return widgetクラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getWidgetClassName() {
		return null;
	}

	/**
	 * widgetネームスペース名を取得します.<br />
	 *
	 * @create 2011/04/30
	 * @return widgetネームスペース名
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getWidgetNamespace() {
		return null;
	}

	/**
	 * visible属性の値を取得します.<br />
	 *
	 * @create 2011/06/14
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @author kobayashi
	 * @since 3.9.0
	 */
	public boolean isVisible() {
		return GBooleanUtils.toBoolean(getVisible(), true);
	}

	/**
	 * このタグがウィジェットかどうかを返します.<br />
	 *
	 * @create 2011/06/25
	 * @return ウィジェットのときtrue
	 * @author yamashita
	 * @since 3.9.0
	 */
	public boolean isWidget() {
		return getWidgetClassName() != null;
	}

	/**
	 * dir属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param dir dir属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setDir(String dir) {
		_dir = dir;
	}

	/**
	 * このコンポーネントにイベント一覧を登録します.<br />
	 *
	 * @create 2011/04/14
	 * @param events イベント一覧
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setEvents(List<GEvent> events) {
		_events = events;
		_eventIterator = events.iterator();
	}

	/**
	 * このコンポーネントの完全なIDを設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param fullId 完全なID
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setFullId(String fullId) {
		_fullId = fullId;
	}

	/**
	 * id属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param id id属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	@Override
	public void setId(String id) {
		_id = id;
	}

	/**
	 * エラー項目の表示名の名前空間を設定します.<br />
	 *
	 * @create 2011/06/07
	 * @param labelspace エラー項目の表示名の名前空間
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLabelspace(String labelspace) {
		_labelspace = labelspace;
	}

	/**
	 * xml:lang属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param lang xml:lang属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLang(String lang) {
		_lang = lang;
	}

	/**
	 * リクエストパラメータキーの接頭語を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param namePrefix リクエストパラメータキーの接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setNamePrefix(String namePrefix) {
		_namePrefix = namePrefix;
	}

	/**
	 * onclick属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnclick(String script) {
		_onclick = script;
	}

	/**
	 * ondbclick属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script ondbclick属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOndblclick(String script) {
		_ondblclick = script;
	}

	/**
	 * onkeydown属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onkeydown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnkeydown(String script) {
		_onkeydown = script;
	}

	/**
	 * onkeypress属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onkeypress属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnkeypress(String script) {
		_onkeypress = script;
	}

	/**
	 * onkeyup属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onkeyup属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnkeyup(String script) {
		_onkeyup = script;
	}

	/**
	 * onmousedown属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onmousedown属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmousedown(String script) {
		_onmousedown = script;
	}

	/**
	 * onmousemove属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onmousemove属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmousemove(String script) {
		_onmousemove = script;
	}

	/**
	 * onmouseout属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onmouseout属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmouseout(String script) {
		_onmouseout = script;
	}

	/**
	 * onmouseover属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onmouseover属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmouseover(String script) {
		_onmouseover = script;
	}

	/**
	 * onmouseup属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param script onmouseup属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOnmouseup(String script) {
		_onmouseup = script;
	}

	/**
	 * options属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param options ウィジェットオプション
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOptions(GJSONObject options) {
		_options = options;
	}

	/**
	 * options属性の値を設定します. optionsはJSON表現の文字列である必要があります.<br />
	 *
	 * @create 2011/04/14
	 * @param options ウィジェットオプション(JSON表現の文字列)
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setOptions(String options) {
		_options = options == null ? null : new GJSONObject(options);
	}

	/**
	 * このコンポーネントのID接頭語を取得します.<br />
	 *
	 * @create 2011/04/14
	 * @param prefix 接頭語
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setPrefix(String prefix) {
		_prefix = prefix;
	}

	/**
	 * xml:space属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param space xml:space属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setSpace(String space) {
		_space = space;
	}

	/**
	 * style属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param style style属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyle(GStyle style) {
		_style = style;
	}

	/**
	 * style属性の値を設定します.<br />
	 *
	 * @create 2011/05/01
	 * @param style style属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyle(String style) {
		_style = style == null ? null : new GStyle(style);
	}

	/**
	 * class属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param styleclass class属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setStyleclass(GStyleClass styleclass) {
		_styleclass = styleclass;
	}

	/**
	 * class属性の値を設定します.<br />
	 *
	 * @create 2011/05/01
	 * @param styleclass class属性の値
	 * @author yamashita
	 */
	public void setStyleclass(String styleclass) {
		_styleclass = styleclass == null ? null : new GStyleClass(styleclass);
	}

	/**
	 * class属性の値を設定します.<br />
	 *
	 * @create 2015/03/24
	 * @param styleclass class属性の値
	 * @author nakamura
	 * @since 3.15.0
	 */
	public void setStyleclass(List<String> styleclass) {
		if (styleclass == null || styleclass.size() == 0) {
			_styleclass = null;
		}
		_styleclass = new GStyleClass(styleclass);
	}

	/**
	 * title属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param title title属性の値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setTitle(String title) {
		_title = title;
	}

	/**
	 * visible属性の値を設定します.<br />
	 *
	 * @create 2011/04/14
	 * @param visible <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVisible(boolean visible) {
		_visible = String.valueOf(visible);
	}

	/**
	 * visible属性の値を設定します.<br />
	 *
	 * @create 2011/06/14
	 * @param visible <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setVisible(String visible) {
		_visible = visible;
	}

	/**
	 * 指定されたタグの上位の親コンポーネント({@link GView})を取得します.<br />
	 * 上位に{@link GPIncludeView}が存在する場合は、さらに上位の親コンポーネント({@link GView})を取得します。<br />
	 *
	 * @create 2011/06/10
	 * @param tag タグ
	 * @return 上位の親コンポーネント(GView)
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected GUIComponent getRootComponent(Tag tag) {
		if (tag instanceof GViewInterfaceTag) {
			GUIComponent component = ((GViewInterfaceTag) tag).getAssociatedComponent();
			if (component == null) {
				return null;
			}
			if (component.getParent() == null) {
				return component;
			}
			GUIComponent rootComponent = component;
			while (true) { // Viewは必ず存在する前提
				GUIComponent parent = rootComponent.getParent();
				if (parent == null) {
					if (rootComponent instanceof GViewInterface) {
						return rootComponent;
					} else {
						throw new IllegalArgumentException("The root component does not exist.");
					}
				}
				rootComponent = parent;
			}
		}
		Tag rootTag = findAncestorWithClass(tag, GViewInterfaceTag.class);
		if (rootTag == null) {
			throw new IllegalArgumentException("The root tag does not exist.");
		}
		return getRootComponent(rootTag);
	}

	/**
	 * 指定されたイベントがHTMLイベント(onclick等)であるかどうかを返します.<br />
	 *
	 * @create 2011/05/16
	 * @param event イベント
	 * @return HTMLイベントのときtrue
	 * @author yamashita
	 * @since 3.9.0
	 */
	protected boolean isHTMLEvent(String event) {
		return htmlEvents.contains(event);
	}

	/**
	 * 指定されたoptionsに指定されたオプションキーで指定されたカスタムタグ属性値を設定します.<br>
	 *
	 * @create 2011/06/06
	 * @param options ウィジェットオプション
	 * @param optionKey オプションキー
	 * @param attributeValue カスタムタグ属性値
	 * @author hamanaka
	 * @since 3.9.0
	 */
	protected void setWidgetOptionValue(GJSONObject options, String optionKey, Object attributeValue) {
		if (attributeValue != null) {
			options.put(optionKey, attributeValue);
			return;
		}
	}
}