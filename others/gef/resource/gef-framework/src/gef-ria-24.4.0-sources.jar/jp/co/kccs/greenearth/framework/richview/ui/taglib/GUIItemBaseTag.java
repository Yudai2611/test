/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.ui.taglib;

import jp.co.kccs.greenearth.framework.view.component.taglib.GUIItemTag;

/**
 * {@link GUIItemBase}のレンダリング用カスタムタグを表します.<br />
 * 
 * @create 2011/04/15
 * @author yamashita
 * @since 3.9.0
 */
public abstract class GUIItemBaseTag extends GUIComponentBaseTag implements GUIItemTag {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -3910280109383863355L;
}
