/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.utils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;

public class GRIAActionUtils {

	/** ActionUtilsのヘルパ. */
	private static final GRIAActionUtilsHelper HELPER = GRIAActionUtilsHelper.Factory.getInstance();

	protected GRIAActionUtils() {
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたセルのIDを返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2011/07/24
	 * @param parameter パラメータ
	 * @return セルのID
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String getCellNameInActionId(GParameter parameter) {
		String[] actionId = parseActionIdInList(parameter);
		return actionId[2];
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたリスト名を返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2007/03/13
	 * @param parameter パラメータ
	 * @return リスト名
	 * @author fujikawa
	 * @since 3.5.0
	 */
	public static String getListNameInActionId(GParameter parameter) {
		String[] actionId = parseActionIdInList(parameter);
		return actionId[0];
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたインデックスを返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2007/03/13
	 * @param parameter パラメータ
	 * @return インデックス
	 * @author fujikawa
	 * @since 3.5.0
	 */
	public static int getRowIndexInActionId(GParameter parameter) {
		int result = 0;
		String[] actionId = parseActionIdInList(parameter);
		result = Integer.parseInt(actionId[1]);
		return result;
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたリスト・インデックスの各値を取得し、 結果セット行データ
	 * {@link jp.co.kccs.greenearth.framework.data.GRowData}で返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2011/08/11
	 * @param parameter パラメータ
	 * @return 結果セット行データ
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static GRowData extractRowData(GParameter parameter) {
		String listName = getListNameInActionId(parameter);
		GListData listData = extractListData(parameter, listName);
		if (listData != null && !listData.isEmpty()) {
			int index = getRowIndexInActionId
					(parameter);
			return listData.get(index);
		}
		return null;
	}

	/**
	 * アクションIDより、該当するセルデータを取得します.<br/>
	 *
	 * @create 2011/07/24
	 * @param parameter パラメータ
	 * @return セルの値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String extractCellData(GParameter parameter) {
		GRowData rowData = extractRowData(parameter);
		if (rowData != null) {
			return rowData.getString(getCellNameInActionId(parameter));
		}
		return null;
	}
	
	/**
	 * {@link jp.co.kccs.greenearth.framework.GParameter}から指定されたリスト名の各値を取得し
	 * 結果セットリストデータ{@link jp.co.kccs.greenearth.framework.data.GListData}で返却します.<br>
	 * パラメータには、以下の形式のキー名で値が設定されている前提です。<br>
	 * 　[リスト名].[項目名]<br>
	 * [リスト名].[項目名].[項目名]のように正しくない形式の場合は該当のデータを無視し、形式がマッチするもののみ
	 * {@link jp.co.kccs.greenearth.framework.data.GListData}に格納して返却します。<br>
	 * ※前列無効な場合、または列データが存在しない場合、空行としてaddします。<br/>
	 *
	 * @create 2011/03/25
	 * @param parameter パラメータ
	 * @param listName リスト名
	 * @return 結果セットリストデータ
	 * @author t.aono
	 * @since 3.9.0
	 */
	public static GListData extractListData(final GParameter parameter, final String listName) {
		if (listName == null) {
			return null;
		}
		final GListData listData = new GListData();
		final Map<String, GRowData> tempMap = new LinkedHashMap<String, GRowData>();
		boolean isEmpty = false;
		Map<String, Map<Integer, String>> nonVisibleAndDisabledMap = new HashMap<String, Map<Integer,String>>();
		Map<String, LinkedList<String>> valuesMap = new HashMap<String, LinkedList<String>>();
		for (String key : parameter.getValuesMap().keySet()) {
			String[] keyStrings = key.split("\\.");
			if (keyStrings.length != 2) {
				continue;
			}
			if (listName.equals(keyStrings[0])) {
				String[] values = parameter.getValues(key);
				if ("listsize".equals(keyStrings[1])) {
					listData.setMaxListSize(parameter.getInteger(key));
				} else if ("startindex".equals(keyStrings[1])) {
					listData.setStartIndex(parameter.getInteger(key));
				} else if ("totalsize".equals(keyStrings[1])) {
					listData.setTotalSize(parameter.getInteger(key));
				} else if ("empty".equals(keyStrings[1])) {
					isEmpty = parameter.getBoolean(key);
				} else if ("maxlistsize".equals(keyStrings[1])) { // TODO [2020/8/4][yamashita]将来削除を検討すること。maxlistsizeはgef-riaでは利用していない（elise if maxlistsizeは不要）。もしかしたらgef-smartで利用している可能性があるので残しておく。
					continue;
				} else {
					String[] split = HELPER.splitNonVisibleOrDisabledID(key);
					final String fullName = split[0];
					if (split.length > 1) {
						if (!nonVisibleAndDisabledMap.containsKey(fullName)) {
							nonVisibleAndDisabledMap.put(fullName, new HashMap<Integer, String>());
						}
						if (!nonVisibleAndDisabledMap.get(fullName).containsKey(Integer.parseInt(split[1]))) {
							nonVisibleAndDisabledMap.get(fullName).put(Integer.parseInt(split[1]), parameter.getValues(key)[0]);
						}
						continue;
					}
					if (!valuesMap.containsKey(key)) {
						LinkedList<String> valuesLinkedList = new LinkedList<String>();
						for (String value : values) {
							valuesLinkedList.add(value);
						}
						valuesMap.put(key, valuesLinkedList);
					}
				}
			}
		}
		for (Entry<String, LinkedList<String>> entry : valuesMap.entrySet()) {
			if (nonVisibleAndDisabledMap.containsKey(entry.getKey())) {
				for (Entry<Integer, String> h : nonVisibleAndDisabledMap.get(entry.getKey()).entrySet()) {
					entry.getValue().add(h.getKey(), h.getValue());
				}
			}
		}
		for (Entry<String, LinkedList<String>> entry : valuesMap.entrySet()) {
			for (int i = 0; i < entry.getValue().size(); i++) {
				GRowData rowData = tempMap.get(Integer.toString(i));
				if (rowData == null) {
					rowData = new GRowData();
				}
				tempMap.put(Integer.toString(i), rowData);
				String value = entry.getValue().get(i);
				if (HELPER.isNonVisibleOrDisabled(value)) {
					continue;
				}
				rowData.setData(entry.getKey().split("\\.")[1], value);
			}
		}
		for (Entry<String, GRowData> entry : tempMap.entrySet()) {
			listData.add(entry.getValue());
		}
		if (listData.size() == 0 && !isEmpty) {
			return null;
		}
		return listData;

	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたパラメータを解析します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 * アクションIDパラメータ解析結果は以下のような形式の配列で返却されます。<br>
	 * 　解析結果[0]　リスト名<br>
	 * 　解析結果[1]　インデックス<br>
	 * 　解析結果[3]　項目名<br>
	 *
	 * @create 2007/03/13
	 * @param parameter パラメータ
	 * @return アクションIDパラメータ解析結果
	 * @author fujikawa
	 * @since 3.5.0
	 */
	protected static String[] parseActionIdInList(GParameter parameter) {
		String actionId = parameter.getValue(GActionServlet.ACTION_ID);
		if (actionId == null) {
			throw new IllegalArgumentException("The actionid is null.");
		}
		String[] ret = actionId.split("\\.");
		if (ret.length <= 1) {
			throw new IllegalArgumentException("The actionid is invalid value.");
		}
		return ret;
	}
}
