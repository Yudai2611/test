/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.utils;

public interface GRIAActionUtilsHelper {

	/**
	 * UIの状態を表す特別な値がnon-visibleまたはdisabledかどうかを判定します.<br/>
	 *
	 * @create 2020/07/31
	 * @param value
	 * @return UIの状態がnon-visibleまたはdisabledかどうか判定
	 * @author yamashita
	 * @since 20.9.0
	 */
	boolean isNonVisibleOrDisabled(String value);
	
	/**
	 * UIの状態を表すID（[リストID].[項目ID][separetor][行番号][separator][non-visible or disabled]）をseparatorで分割します。
	 * 
	 * @create 2020/07/31
	 * @param id 
	 * @return
	 */
	String[] splitNonVisibleOrDisabledID(String id);
	
	/**
	 * {@link GEditableMenuDao}クラスを生成するファクトリクラスです.
	 * 
	 * @create 2020/07/31
	 * @author yamashita
	 * @since 20.9.0
	 */
	public static class Factory {

		/** Factory. */
		protected static Factory instance = new Factory();
		
		/**
		 * デフォルトコンストラクタ.
		 * 
		 * @create 2020/07/31
		 * @author yamashita
		 * @since 20.9.0
		 */
		protected Factory() {
		}

		/**
		 * {@link GRIAActionUtilsHelper}インスタンスを生成します.
		 * 
		 * @return {@link GRIAActionUtilsHelper}インスタンス
		 * @create 2020/07/31
		 * @author yamashita
		 * @since 20.9.0
		 */
		public static GRIAActionUtilsHelper getInstance() {
			return new GRIAActionUtilsHelperImpl();
		}
	}
}
