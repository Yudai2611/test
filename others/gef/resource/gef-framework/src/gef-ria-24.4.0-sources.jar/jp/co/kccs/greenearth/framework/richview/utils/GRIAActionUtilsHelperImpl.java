/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.richview.utils;

import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPList;

class GRIAActionUtilsHelperImpl implements GRIAActionUtilsHelper {

	private static final String SUFFIX_SEPARATOR = GPList.SUFFIX_SEPARATOR;
	private static final String INTERNAL_NON_VISIBLE_VALUE = GPList.INTERNAL_NON_VISIBLE_VALUE;
	private static final String INTERNAL_DISABLED_VALUE = GPList.INTERNAL_DISABLED_VALUE;

	GRIAActionUtilsHelperImpl() {
	}

	/**
	 * UIの状態を表す特別な値がnon-visibleまたはdisabledかどうかを判定します.<br/>
	 *
	 * @create 2020/07/31
	 * @param value
	 * @return UIの状態がnon-visibleまたはdisabledかどうか判定
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Override
	public boolean isNonVisibleOrDisabled(String value) {
		return INTERNAL_NON_VISIBLE_VALUE.equals(value) || INTERNAL_DISABLED_VALUE.equals(value);
	}
	
	/**
	 * UIの状態を表すID（[リストID].[項目ID][separetor][行番号][separator][non-visible or disabled]）をseparatorで分割します。
	 * 
	 * @create 2020/07/31
	 * @param id 
	 * @return separator区切りのString配列
	 * @author yamashita
	 * @since 20.9.0
	 */
	@Override
	public String[] splitNonVisibleOrDisabledID(String id) {
		return id.split(SUFFIX_SEPARATOR);
	}

}
