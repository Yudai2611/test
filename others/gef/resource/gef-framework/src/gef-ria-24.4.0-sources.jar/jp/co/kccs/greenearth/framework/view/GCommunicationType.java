/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view;

/**
 * 通信タイプを表す定数クラスです<br/>
 *
 * @create 2021/09/30
 * @author KCSS
 * @since 21.9.0
 */
public final class GCommunicationType {

	public static final String COMMUNICATION_TYPE_AJAX = "ajax";
	public static final String COMMUNICATION_TYPE_SUBMIT = "submit";
	public static final String KEY = "commtype";

	private GCommunicationType() {
	}

}
