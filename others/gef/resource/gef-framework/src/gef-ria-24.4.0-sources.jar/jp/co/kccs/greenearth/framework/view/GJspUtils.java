/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.PageContext;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * JSPに関連するユーティリティクラスです.<br>
 * 
 * @create 2007/02/26
 * @author kitamura
 * @since 3.0.0
 */
public final class GJspUtils {

	/** インクルード先JSPパスをリクエストに格納する時のキー. */
	public static final String INCLUDE_PATH_KEY = "jp.co.kccs.greenearth.framework.view.INCLUDE_PATH";
	/** ローカライズキー. */
	public static final String LOCALIZABLE_KEY = "geframe.view.Localizable";

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2007/02/26
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GJspUtils() {
	}

	/**
	 * 指定されたパスに指定されたロケールの言語・国・バリアント情報を付与して返却します.<br>
	 * 言語・国情報を付与する順序は以下の通りになります。<br>
	 * 付与したパスに対するファイルが存在するものが返却されます。<br>
	 * 　①指定されたパス＋_(言語)＋_(国)＋_(バリアント)＋拡張子<br>
	 * 　②指定されたパス＋_(言語)＋_(国)＋拡張子<br>
	 * 　③指定されたパス＋_(言語)＋拡張子<br>
	 * 　④指定されたパス＋拡張子<br>
	 * 
	 * @create 2007/02/26
	 * @param path パス
	 * @param locale ロケール
	 * @param context コンテキスト
	 * @return String 言語・国・バリアント情報が付与され、且つファイルが存在するパス
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static String getLocalizePath(String path, Locale locale, ServletContext context) {
		boolean localizable = GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(LOCALIZABLE_KEY, "false"));
		if (localizable) {
			if (path == null) {
				return path;
			}
			int indexq = path.lastIndexOf('?');
			String param = "";
			if (indexq > 0) {
				param = path.substring(indexq);
				path = path.substring(0, indexq);
			}

			int index = path.lastIndexOf('.');
			if (index < 0) {
				return path + param;
			}
			String extension = path.substring(index);
			String fileNameWithoutExtension = path.substring(0, index);
			String localeKey = locale == null ? "" : locale.toString();

			final String basePath = context.getRealPath("");
			while (true) {
				String localizationPath = fileNameWithoutExtension + "_" + localeKey + extension;
				String absolutePath = basePath + new File(localizationPath).getPath();
				if (null != absolutePath) {
					File file = new File(absolutePath);
					if (file.exists() && file.isFile()) {
						//存在すればそのパスを返却
						return localizationPath + param;
					}
				}
				int underscore = localeKey.lastIndexOf("_");
				if (underscore < 0) {
					break;
				}
				localeKey = localeKey.substring(0, underscore);
			}

			return path + param;
		}
		else {
			return path;
		}
	}

	/**
	 * 指定されたコンテキストに指定されたパスのJSPをインクルードします.<br>
	 * インクルードするJSPは言語・国・バリアントに対応したものを使用します。<br>
	 * 
	 * @create 2007/02/02
	 * @param pageContext コンテキスト
	 * @param page インクルードするJSPの相対パス
	 * @param locale ロケール
	 * @param isFlush ファイルを実行する際に、バッファ内のデータをフラッシュするかを表す値
	 * @throws JspException インクルードに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void jspInclude(PageContext pageContext, String page, Locale locale, boolean isFlush) throws JspException {
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		try {
			//言語・国・バリアント情報を付与したパス
			String localizePath = getLocalizePath(page, locale, pageContext.getServletContext());
			request.setAttribute(INCLUDE_PATH_KEY, localizePath);
			pageContext.include(localizePath, isFlush);
		}
		catch (IOException e) {
			throw new JspException(e);
		}
		catch (ServletException e) {
			throw new JspException(e);
		}
	}
}
