/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.component.taglib.GViewBaseTag;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 *カスタムタグ定義情報(TLDファイル)を表します.
 * 
 * @create 2006/12/16
 * @author aono
 * @since 3.0.0
 */
public final class GTLDConfiguration {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GViewBaseTag.class);

	/** インスタンス. */
	private static GTLDConfiguration _instance = null;
	/** タグ名:プレフィックス定義. */
	private static final String NODE_NAME_PREFIX = "short-name";
	/** タグ名:カスタムタグ名定義. */
	private static final String NODE_NAME_TAG = "tag";
	/** タグ名:カスタムタグクラス定義. */
	private static final String NODE_NAME_TAG_CLASS = "tag-class";
	/** タグ名:カスタムタグ名. */
	private static final String NODE_NAME_TAG_NAME = "name";
	/** カスタムタグ名-クラスの対応テーブル. */
	protected Map<String, Class< ? >> _uiTagMap = new HashMap<String, Class< ? >>();

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2006/12/16
	 * @author aono
	 * @since 3.0.0
	 */
	private GTLDConfiguration() {
	}

	// ---- パブリックメソッド -------------------------------------------------

	/**
	 * インスタンスの取得.
	 * 
	 * @create 2007/01/05
	 * @return インスタンス
	 * @author aono
	 * @since 3.0.0
	 */
	public static synchronized GTLDConfiguration getInstance() {
		if (_instance == null) {
			_instance = new GTLDConfiguration();
		}
		return _instance;
	}

	/**
	 * インスタンスの破棄。
	 */
	public void destroy() {
		GTLDConfiguration._instance = null;
	}
	
	/**
	 * カスタムタグに対応するuiクラスを取得.
	 * 
	 * @create 2006/12/13
	 * @param tagName カスタムタグ名(プレフィックス付)
	 * @return カスタムタグに対応するクラス
	 * @author aono
	 * @since 3.0.0
	 */
	public Class< ? > getUIClass(String tagName) {
		return _uiTagMap.get(tagName);
	}

	/**
	 * TLDファイルを読込んで情報をキャッシュします.<br>
	 * [1]キャッシュする情報は次の通り。<br>
	 * ・カスタムタグ名<br>
	 * ・カスタムタグ名に対応するuiクラス<br>
	 * ※カスタムタグ名にはプレフィックスを含みます。<br>
	 * 
	 * @create 2006/12/13
	 * @param path TLDファイルのURL
	 * @throws ParserConfigurationException TDL読込用XMLパーサの設定エラー
	 * @throws SAXException TLDファイルが妥当なXMLではない
	 * @throws IOException TLDファイル読込時にIOエラーが発生
	 * @author aono
	 * @since 3.0.0
	 */
	public void load(URL path) throws ParserConfigurationException, SAXException, IOException {
		// ClassLoaderの取得方法の変更
		ClassLoader cl = Thread.currentThread().getContextClassLoader(); 
		load(path, cl);
	}

	/**
	 * TLDファイルを読込んで情報をキャッシュします.<br>
	 * [1]キャッシュする情報は次の通り。<br>
	 * ・カスタムタグ名<br>
	 * ・カスタムタグ名に対応するuiクラス<br>
	 * ※カスタムタグ名にはプレフィックスを含みます。<br>
	 * 指定されたクラスローダーを使用してuiクラスを生成します.<br>
	 * 
	 * @create 2013/07/12
	 * @param url TLDファイルのURL
	 * @param loader 使用するクラスローダー
	 * @throws ParserConfigurationException TDL読込用XMLパーサの設定エラー
	 * @throws SAXException TLDファイルが妥当なXMLではない
	 * @throws IOException TLDファイル読込時にIOエラーが発生
	 * @author KCCS Shigeki Shoji
	 * @since 3.12.0
	 */
	public void load(URL url, ClassLoader loader) throws ParserConfigurationException, SAXException, IOException {
		InputStream tld = null;
		try {
			// TLDを読込んでDOMを作成
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			tld = url.openStream();
			Document dom = db.parse(tld);
			
			Element domElement = dom.getDocumentElement();
	
			// カスタムタグのプレフィックス情報を取得
			Element prefixNode = getFirstChildElementByTagName(domElement, NODE_NAME_PREFIX);
			// プレフィックスノードが取れなければ処理を続行できない
			if (prefixNode == null) {
				throw new IllegalStateException("short-name tag not found in TLD file.");
			}
			String prefix = prefixNode.getTextContent();
			// プレフィックス情報が取れなければ処理を続行できない
			if (prefix == null || "".equals(prefix)) {
				throw new IllegalStateException("short-name tag have no value.");
			}
	
			// 全てのタグ情報を評価
			for (Node tag = domElement.getFirstChild(); tag != null; tag = tag.getNextSibling()) {
				// tagエレメントを検索して処理
				if (tag.getNodeType() == Node.ELEMENT_NODE && NODE_NAME_TAG.equals(tag.getNodeName())) {
					// /taglib/tag/name/text()を取得
					Element nameNode = getFirstChildElementByTagName((Element) tag, NODE_NAME_TAG_NAME);
					if (nameNode == null) {
						continue;
					}
					String name = nameNode.getTextContent();
	
					if (name == null || "".equals(name)) {
						continue;
					}
	
					// /taglib/tag/tag-class/text()を取得
					Element classnameNode = getFirstChildElementByTagName((Element) tag, NODE_NAME_TAG_CLASS);
					if (classnameNode == null) {
						continue;
					}
					String classname = classnameNode.getTextContent();
	
					if (classname == null || "".equals(classname)) {
						continue;
					}
	
					// カスタムタグ名-クラス名の対応情報をキャッシュ
					// Tagクラスを取得
					Class< ? > tagClass = null;
					try {
						tagClass = Class.forName(classname, true, loader);
					} catch (ClassNotFoundException e) {
						LOGGER.warn("Custom tag class is not found.", e);
						continue;
					}
	
					// uiクラスを取得
					if (tagClass != null && tagClass.isAnnotationPresent(TargetUIComponent.class)) {
						// UIクラスを取得
						TargetUIComponent anotaiont = tagClass.getAnnotation(TargetUIComponent.class);
						Class< ? > uiClass = anotaiont.value();
	
						if (uiClass == null) {
							continue;
						}
	
						// uiクラスを保存
						_uiTagMap.put(new StringBuilder(prefix).append(":").append(name).toString(), uiClass);
					} else {
						continue;
					}
	
				}
			}
		} finally {
			if (null != tld) {
				tld.close();
			}
		}
	}

	/**
	 * 指定された名称の子エレメントを検索して最初に見つけたエレメントを返す.
	 * 
	 * @see org.w3c.dom.Element
	 * @create 2006/12/13
	 * @param parent 親エレメント
	 * @param name 検索エレメント名
	 * @return 対象エレメント/<code>null</code>:対象エレメントなし
	 * @author aono
	 * @since 3.0.0
	 */
	private Element getFirstChildElementByTagName(Element parent, String name) {
		for (Node child = parent.getFirstChild(); child != null; child = child.getNextSibling()) {
			if (child.getNodeType() == Node.ELEMENT_NODE && child.getNodeName().equals(name)) {
				return (Element) child;
			}
		}
		return null;
	}
}
