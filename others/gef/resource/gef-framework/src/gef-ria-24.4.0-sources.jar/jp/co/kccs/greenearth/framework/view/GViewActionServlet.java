/*
 * Copyright 2009-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.action.Validatefull;
import jp.co.kccs.greenearth.framework.view.component.GViewFactory;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

/**
 * クライアント（プレゼンテーション）層にThin Client Frameworkを利用した場合に利用する{@link GActionServlet}の拡張実装です。<br>
 * <br>
 * <b>【ビューとアクション】</b><br>
 * {@link GActionServlet}で定義されるアクションでは、任意のJavaBeanにアクションメソッドを記述するルールになっていましたが、
 * {@link GViewActionServlet}では、遷移元ビュー（バックワードビュー）にアクションメソッドを指定することができます。
 * これにより、ビューに、画面オブジェクトとしての機能と、ビジネスロジックコンポーネントとしての機能の
 * 二つを併せて持たすことができます。
 * また、ビューにアクションメソッドを定義した場合、アクションメソッド内でそのビューが格納している
 * UIコンポーネント情報の利用や、UIコンポーネントへの値の設定ができるようになります。<br>
 * ※ビューにアクションメソッドを定義する場合のシグニチャ等のルールは{@link GActionServlet}と同様です。<br><br>
 * 
 * 遷移元ビュー（バックワードビュー）にアクションメソッドを指定する場合は、リクエストに積めるパラメータから
 * <code>"actionbean"</code>パラメータを除去する必要があります。{@link GJspServlet}は、リクエストに
 * <code>"actionbean"</code>パラメータが積まれているかどうかで、アクションビーンに{@link GViewInterface}を利用するか否かを判定しています。<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * 	<tr bgcolor="#CCCCFF"><td>パラメータキー名</td><td>パラメータが示す意味</td></tr>
 *  <tr><td>actionbean</td><td>― （指定しないでください）</td></tr>
 *  <tr><td>actionmethod</td><td>アクションメソッド名</td></tr>
 * </table>
 * <br>
 * 
 * <b>【入力値検証】</b><br>
 * Thin Client Frameworkでは、画面からサブミットされたパラメータの検証を画面に対応する{@link GViewInterface}の
 * {@link GViewInterface#onValidate(GParameter)}メソッドにて実施します。<br>
 * {@link GViewActionServlet}では、アクションを実行する前に、遷移元の{@link GViewInterface#onValidate(GParameter)}
 * を呼び出す事で、入力値の検証を行います。<br>
 * ここでの検証にて検証エラーが発覚した場合は、その情報を遷移元画面に返します。
 * しかし、アクションでも検証を行っており、双方の検証を１回のリクエストで実行したい場合、
 * つまりは、{@link GViewInterface#onValidate(GParameter)}の検証結果をアクション側に引き継ぐ場合は、
 * 対象のアクションメソッドに{@link Validatefull}アノテーションをつける事で、
 * アクションの引数に渡される{@link GResultData}に検証エラーである{@link GValidateError}を格納する事で、
 * これを実現しています。<br>
 * <br>
 * 
 * <b>【必要なリクエストパラメータ】</b><br>
 * Thin Client Frameworkを駆動させるためには、少なくとも以下のパラメータをリクエストに詰めてサブミットする必要がります。<br>
 * また、これらのパラメータは、フレームワークが優先的に利用するための予約語として扱われるため、
 * アプリケーションデータとして利用することはできません。
 * <table border="1" cellpadding="3" cellspacing="0">
 * 	<tr bgcolor="#CCCCFF"><td>パラメータキー名</td><td>パラメータが示す意味</td></tr>
 *  <tr><td>actionid</td><td>アクションイベントを発生させたコンポーネントのID</td></tr>
 *  <tr><td>actionbean</td><td>アクションクラスの完全修飾名</td></tr>
 *  <tr><td>actionmethod</td><td>アクションメソッド名</td></tr>
 *  <tr><td>mode</td><td>アクションのモード（任意文字列）</td></tr>
 *  <tr><td>backward</td><td>アクションの実行を指示した遷移元コンテンツパス、またはアクションメソッドが存在するビュー</td></tr>
 *  <tr><td>formid</td><td>サブミットするフォームのID</td></tr>
 *  <tr><td>target</td><td>アクション実行結果の表示ターゲット</td></tr>
 *  <tr><td>validate</td><td>入力値検証を行うレベル（all/error/none）</td></tr>
 * </table>
 * 
 * @create 2009/08/27
 * @author kitamura
 * @since 3.6.0
 */
public class GViewActionServlet extends GActionServlet {

	// ----- 定数 -----------------------------------------------
	/** パラメータにアクションを実行したコンポーネントのフォームIDを格納するときのキー名. */
	public static final String ACTION_FORM_KEY = "actionform";
	/** パラメータにアクションを実行したコンポーネントのウィンドウIDを格納するときのキー名. */
	public static final String ACTION_TARGET_KEY = "actiontarget";

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 2186257162580125447L;

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GActionServlet.class);
	
	/**
	 * {@link GViewActionServlet}インスタンスを初期化します。
	 * 
	 * @create 2009/08/30
	 * @see jp.co.kccs.greenearth.framework.GActionServlet#GActionServlet()
	 * @author kitamura
	 * @since 3.6.0
	 */
	public GViewActionServlet() {
	}

	/**
	 * 初期化処理。<br>
	 * アプリケーションコンテナ起動時に、TLDファイルをキャッシュします。<br>
	 * 
	 * @create 2007/01/04
	 * @throws ServletException Servletの正常な処理が妨げられた場合に発生する例外
	 * @author kitamura
	 * @since 3.0.0
	 */
	@Override
	public void init() throws ServletException {
		super.init();

		// TODO 将来的にはGViewResponseFilterに移す
		GTLDConfiguration tld = GTLDConfiguration.getInstance();
		Enumeration< ? > names = getServletConfig().getInitParameterNames();
		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			if (!name.startsWith("ui-tld/")) {
				continue;
			}

			try {
				tld.load(getServletContext().getResource(getInitParameter(name)));
				LOGGER.debug("Load TLD : name=" + name);
			} catch (IOException e) {
				throw new ServletException(e);
			} catch (ParserConfigurationException e) {
				throw new ServletException(e);
			} catch (SAXException e) {
				throw new ServletException(e);
			}
		}
	}

	/**
	 * アクションクラスを生成します。<br>
	 * アクションクラスは、リクエストパラメータに{@value GActionServlet#ACTION_BEAN_KEY}があれば、
	 * そのキーにて指定されたアクションクラスを、
	 * 無ければ、{@value GViewResponseFilter#BACKWARD_KEY}にて指定された{@link GViewInterface}オブジェクトを
	 * アクションクラスに見立てます。
	 * 
	 * @create 2009/08/27
	 * @param parameter パラメータ
	 * @param request リクエスト
	 * @return アクションクラスインスタンス
	 * @throws GViewException {@link GViewInterface}の取得に失敗した場合
	 * @throws ClassNotFoundException クラスの生成に失敗した場合
	 * @throws InstantiationException クラスの生成に失敗した場合
	 * @throws IllegalAccessException クラスの生成に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	protected Object createActionInstance(GParameter parameter, HttpServletRequest request) throws GViewException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		// クラスの生成
		String className = parameter.getValue(ACTION_BEAN_KEY);
		if (className != null) {
			return super.createActionInstance(parameter, request);
		} else {
			String path = parameter.getValue(GViewResponseFilter.BACKWARD_KEY);
			if (path == null) {
				throw new IllegalArgumentException("'" + ACTION_BEAN_KEY + "' is not found!");
			}
			Object action = GViewFactory.getView(path, request);
			if (action == null) {
				throw new IllegalArgumentException("'" + ACTION_BEAN_KEY + "' is not found!");
			}
			return action;
		}
	}

	/**
	 * リクエストパラメータにて指定されたアクションを実行します。<br>
	 * {@link GViewActionServlet}では、{@link GActionServlet#ACTION_BEAN_KEY}キーが存在しない場合、
	 * 遷移元ビューをアクションとしてアクションメソッドを実行します。<br>
	 * また、アクション実行前に遷移元ビューの{@link GViewInterface#onValidate(GParameter)}を呼び出し、
	 * 入力値検証を行っています。<br>
	 * この入力値検証にて検証エラーが返された場合、アクションは実行されず、検証エラーが通知されます。<br>
	 * 検証エラーが発生した場合でもアクションを呼び出す場合は、アクションメソッドに{@link Validatefull}
	 * アノテーションを指定してください。
	 * 
	 * @create 2009/08/27
	 * @see GActionServlet#doAction(HttpServletRequest, HttpServletResponse, GParameter, GResultData)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @throws Throwable アクションの実行に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	protected GResultData doAction(HttpServletRequest request, HttpServletResponse response, GParameter parameter, GResultData resultData) throws Throwable {
		// メソッド名の取得
		String methodName = parameter.getValue(ACTION_METHOD_KEY);
		if (methodName == null) {
			throw new IllegalArgumentException("'" + ACTION_METHOD_KEY + "' is not found!");
		}

		// アクションクラスの生成
		Object target = createActionInstance(parameter, request);

		// BACKWARDの指定がある場合は入力値検証を行う
		String path = parameter.getValue(GViewResponseFilter.BACKWARD_KEY);
		if (path != null) {
			GViewInterface view = GViewFactory.getView(path, request);
			if (view != null) {

				// 入力値検証
				resultData = doValidate(view, parameter, resultData);
				if (resultData.errorsSize() > 0) {
					// 検証結果をアクションへ引き継ぐかを判定
					Class< ? >[] parameterTypes = new Class[2];
					parameterTypes[0] = GParameter.class;
					parameterTypes[1] = GResultData.class;
					if (!target.getClass().getMethod(methodName, parameterTypes).isAnnotationPresent(Validatefull.class)) {
						return resultData;
					}
				}
			}
		}

		return invokeAction(target, methodName, parameter, resultData);
	}

	/**
	 * 入力値検証処理を実行します。<br>
	 * 指定された{@link GViewInterface}の{@link GViewInterface#onValidate(GParameter)}を呼び出しています。<br>
	 * リクエストパラメータにて{@link GActionServlet#VALIDATE_KEY}に"none"が指定されている場合、
	 * 検証処理は行われません。
	 * 
	 * @create 2009/08/27
	 * @param view 遷移元ビュー
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected GResultData doValidate(GViewInterface view, GParameter parameter, GResultData resultData) {
		GStopWatch watch = new GStopWatch();
		if (GErrorLevel.NONE != parameter.getValidationLevel()) {
			watch.start();
			List<GValidateError> errors = view.onValidate(parameter);
			int size = 0;
			if (errors != null && errors.size() > 0) {
				resultData.setExitCode(GResultData.EXIT_CODE_VALIDATE_ERROR);
				resultData.setErrors(errors);
				size = errors.size();
			}
			LOGGER.debug("View OnValidate (" + watch.stop() + ") : view=" + view.getViewclass() + ", errorsize=" + size);
		}
		return resultData;
	}

}
