/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view;

import jp.co.kccs.greenearth.commons.GFrameworkException;

/**
 * Thin Client Frameworkの処理中に発生した例外を表します.
 * 
 * @create 2007/02/12
 * @author kitamura
 * @since 3.0.0
 */
public class GViewException extends GFrameworkException {

	// ----- 定数 -----------------------------------------------
	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -2453454281688269746L;

	/**
	 * {@link GViewException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GViewException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GViewException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GViewException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GViewException}のインスタンスを初期化します.
	 * 
	 * @create 2007/02/12
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GViewException(Throwable cause) {
		super(cause);
	}
}
