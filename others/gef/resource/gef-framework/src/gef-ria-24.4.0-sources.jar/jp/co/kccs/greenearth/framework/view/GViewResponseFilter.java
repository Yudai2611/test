/*
 * Copyright 2009-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import jakarta.servlet.FilterConfig;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GResponseFilter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.view.component.GViewFactory;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;
import net.arnx.jsonic.JSON;
import net.arnx.jsonic.JSONException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Thin Client Frameworkからのリクエストに対応した、{@link GResponseFilter}実装です。<br>
 * {@link GViewInterface}とJSPを利用したレスポンスの生成を行います。<br>
 * {@link GParameter}に{@value #FORWARD_KEY}キーで格納された遷移先へフォワードする処理を実行します。
 * この時、フォワード先の{@link jp.co.kccs.greenearth.framework.view.component.GView}に対し、
 * 処理結果である{@link GResultData}のデータをロードさせる事により、処理結果を画面に反映させます。<br>
 * {@link GResultData}のロードに関しては、{@link jp.co.kccs.greenearth.framework.view.component.GView}を参照してください。<br>
 * <br>
 * 
 * 
 * <b>【検証エラー時の画面遷移】</b><br>
 * 処理結果である{@link GResultData}の終了コードが{@value GResultData#EXIT_CODE_VALIDATE_ERROR}を返す場合、
 * その処理を検証エラーであると見なし、遷移元のページにフォワードします。<br>
 * 遷移元のページでは、この処理結果を受け、格納されている検証エラー情報を画面に表示させます。
 * 遷移元のページは{@link GParameter}に{@value #BACKWARD_KEY}キーで格納されている値で判断されます。<br>
 * <br>
 * 
 * 
 * <b>【システムエラー時の画面遷移】</b><br>
 * {@link #writeErrorResponse(HttpServletRequest, HttpServletResponse, GParameter, Throwable)}メソッドを呼び出すか、
 * 処理結果である{@link GResultData}の終了コードに{@value GResultData#EXIT_CODE_SYSTEM_ERROR}}を指定した場合、
 * その処理はシステムエラーであると見なし、エラーページへのリダイレクトを行います。<br>
 * エラーページの指定は、発生する例外毎に複数指定可能であり、フィルターの初期化パラメータにてJSON形式にて指定します。<br>
 * "exception"項目に例外のクラス名を、"path"項目に例外に対応するエラーページを指定してください。<br>
 * また、例外クラスは継承関係が考慮されます。
 * <pre>
 * [設定例]
 * &lt;filter>
 *    &lt;filter-name>ViewResponseFilter&lt;/filter-name>
 *    &lt;filter-class>jp.co.kccs.greenearth.framework.view.GViewResponseFilter&lt;/filter-class>
 *    &lt;init-param>
 *       &lt;param-name>error-page&lt;/param-name>
 *       &lt;param-value>
 *          [{exception:"jp.co.kccs.greenearth.framework.auth.GAuthenticationException", path:"/Sample/jsp/common/auth-error.jsp"},
 *           {exception:"java.lang.Throwable", path:"/Sample/jsp/common/system-error.jsp"}]
 *       &lt;/param-value>
 *    &lt;/init-param>
 * &lt;/filter>
 * </pre>
 * 
 * 
 * <b>【ファイルダウンロード時の処理】</b><br>
 * 処理結果である{@link GResultData}の終了コードが{@value GResultData#EXIT_CODE_FILE_DOWNLOAD}を返す場合、
 * その処理をファイルダウンロード処理であると見なし、Content-dispositionヘッダーを利用してクライアントにファイルをダウンロードします。<br>
 * ダウンロードされるファイルは{@link GResultData#getDownloadFile()}で取得されるファイルとなります。
 * ダウンロード時の方法やレスポンス書き出し時のバッファリングサイズなどについては{@link jp.co.kccs.greenearth.framework.data.GDownloadFile}
 * にて設定してください。<br>
 * <br>
 * 
 * @create 2009/08/24
 * @author kitamura
 * @since 3.6.0
 */
public class GViewResponseFilter extends GResponseFilter {
	
	/** パラメータに遷移元パスを格納するときのキー名. */
	public static final String BACKWARD_KEY = "backward";
	
	/** パラメータに遷移先パスを格納するときのキー名. */
	public static final String FORWARD_KEY = "forward";
	/** ロガー */
	private static final Log LOGGER = LogFactory.getLog(GResponseFilter.class);
	
	/** システムエラー時のリダイレクト先リスト */
	protected List<GErrorPageSet> _errorPageList = null;
	
	/**
	 * {@link GViewResponseFilter}インスタンスを初期化します。
	 * 
	 * @create 2009/08/26
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GViewResponseFilter() {
	}

	/**
	 * 初期化パラメータより、エラーページ情報を読み取っています。<br>
	 * error-pageパラメータにJSON形式で設定されている、例外クラスとエラーページのマッピングを内部で保持します。<br>
	 * 
	 * @create 2009/08/24
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#init(jakarta.servlet.FilterConfig)
	 * @param filterConfig フィルターコンフィグ
	 * @throws ServletException 初期化に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);
		
		String errorPageConf = filterConfig.getInitParameter("error-page");
		_errorPageList = new ArrayList<GErrorPageSet>();
		if (errorPageConf != null) {
			try {
				List< ? > list = (List< ? >) JSON.decode(errorPageConf);
				for (int i = 0; i < list.size(); i++) {
					Map< ? , ? > map = (Map< ? , ? >) list.get(i);
					GErrorPageSet set = new GErrorPageSet((String) map.get("exception"), (String) map.get("path"));
					_errorPageList.add(set);
				}
			}
			catch (JSONException e) {
				throw new ServletException("It failed in the initialization of error page setting. ", e);
			}
		}
	}
	
	/**
	 * 指定した例外クラスに対応したエラーページにリダイレクトします。<br>
	 * リダイレクト先に例外情報を引き継ぐため、例外オブジェクトを一時的にセッションに格納します。<br>
	 * 格納時のキー名をランダムに生成し、そのキー名をリダイレクト先にURLパラメータとして引き渡す
	 * 事で、リダイレクト先のJSPにてセッションよりリダイレクト情報を取得します。<br>
	 * 一度取得された例外情報は、セッションから削除されます。<br>
	 * エラーページの指定はDI定義にて行っていください。<br>
	 * 設定の詳細はクラスコメントを参照してください。<br>
	 * 
	 * @create 2009/08/19
	 * @see GResponseFilter#writeErrorResponse(HttpServletRequest, HttpServletResponse, GParameter, Throwable)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param e 例外オブジェクト
	 * @throws IOException リダイレクトに失敗した場合
	 * @throws ServletException リダイレクトに失敗した場合、エラーページの取得に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	public void writeErrorResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter, Throwable e) throws IOException, ServletException {
		// エラーの取得
		String path = getErrorPage(e);
		if (path == null) {
			throw new ServletException(e);
		}
		
		// エラーページへ遷移
		String exceptionKey = UUID.randomUUID().toString();
		HttpSession session = request.getSession();
		session.setAttribute(exceptionKey, e);
		Locale locale = GWebContext.getInstance().getLocale();
		String localizePath = GJspUtils.getLocalizePath(getErrorPage(e), locale, session.getServletContext());

		response.sendRedirect(request.getContextPath() + localizePath + "?" + GConstants.EXCEPTION_KEY + "=" + exceptionKey);
		LOGGER.info("Redirect Error Page : path=" + localizePath);
	}

	/**
	 * 指定した例外クラスに該当するエラーページを取得します。
	 * 
	 * @create 2009/08/19
	 * @param e 例外クラス
	 * @return 対応するエラーページのパス
	 * @throws ServletException エラーページの設定が誤っている場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected String getErrorPage(Throwable e) throws ServletException {
		
		if (e == null) {
			return null;
		}
		
		for (GErrorPageSet page : _errorPageList) {
			try {
				Class< ? > clazz = page.getExceptionClass();
				if (clazz.isAssignableFrom(e.getClass())) {
					return page._path;
				}
			}
			catch (ClassNotFoundException cnfe) {
				throw new ServletException("There is no exception class corresponding to the specified error page. :" + page._path, cnfe);
			}
		}
		return null;
	}
	
	/**
	 * 指定した{@link GParameter}より、遷移先のパスを取得します。<br>
	 * 
	 * 相対パスにも対応しており、そのパスの解決方法は以下になります。<br>
	 * [1]{@link GParameter}内の{@link GJspServlet#FORWARD_KEY}キーで指定された遷移先URLを取得します。<br>
	 * [2]遷移先URLが"/"から始まる場合、遷移先URLを返します。<br>
	 * [3]遷移先URLが"/"から始まらない意場合、相対パスとして判断し、
	 * 　[3-1]{@link GParameter}内の{@link GJspServlet#FORWARD_KEY}キーで指定された遷移元URLの後ろに連結します。<br>
	 * 　[3-2]冗長なURL表記を除去します。<br>
	 * 　　[3-2-1]"//"を"/"に置き換えます。<br>
	 * 　　[4-2-2]"/./"を"/"に置き換えます。<br>
	 * 　　[4-2-3]"xxx/../"を"/"に置き換えます。<br>
	 * 
	 * @create 2009/08/19
	 * @param parameter パラメータ
	 * @return 遷移先のパス
	 * @author aono
	 * @since 3.6.0
	 */
	protected String getForwardPath(GParameter parameter) {
		String forwardPath = parameter.getValue(FORWARD_KEY);
		if (GStringUtils.isEmpty(forwardPath)) {
			throw new IllegalArgumentException("'" + FORWARD_KEY + "' is not found!");
		}

		// Forwardの指定が"/"で始まる場合以外はBackwardからの相対パスをセットする。
		if (!forwardPath.startsWith("/")) {
			// Backwardの取得
			String backwardPath = parameter.getValue(BACKWARD_KEY);
			if (backwardPath != null) {
				// Backwardを使ってForwardのパスを補完
				forwardPath = backwardPath.substring(0, backwardPath.lastIndexOf("/") + 1) + forwardPath;

				// 冗長なパス指定を除去
				// 1."//"を除去
				forwardPath = forwardPath.replaceAll("\\Q//\\E", "/");

				// 2."/./"を除去
				forwardPath = forwardPath.replaceAll("\\Q/./\\E", "/");

				// 3."../"を処理
				forwardPath = forwardPath.replaceAll("[^/]+?\\Q/../\\E", "");
			}
		}

		return forwardPath;
	}

	/**
	 * 遷移元のビューにサブミットパラメータをロードしています。<br>
	 * 詳細な処理に関しては、{@link GView#loadParameter(GParameter)}を参照してください。
	 * 
	 * @create 2009/08/24
	 * @see GResponseFilter#prepareResultData(HttpServletRequest, HttpServletResponse)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	protected void prepareResultData(HttpServletRequest request, HttpServletResponse response) {
		super.prepareResultData(request, response);

		// パラメータのロード
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
		String path = parameter.getValue(BACKWARD_KEY);
		if (path != null) {
			GViewInterface view = GViewFactory.getView(path, request);
			if (view != null) {
				GStopWatch watch = new GStopWatch();
				watch.start();
				view.loadParameter(parameter);
				LOGGER.debug("View Load Parameter (" + watch.stop() + ") : view=" + view.getClass().getName());
			}
		}
	}
	
	/**
	 * {@link GParameter}にて指定された遷移先にフォワードします。<br>
	 * JSPを利用して、アクションの処理結果より、HTMLレスポンスを生成します。<br><br>
	 * 
	 * <b>【正常終了時】</b><br>
	 * {@link GParameter}の{@value #FORWARD_KEY}キーで格納されたコンテンツパスへフォワードします。<br><br>
	 * 
	 * <b>【チェックエラー発生時】</b><br>
	 * チェックエラー発生時とは、{@link GResultData#getExitCode()}が{@value GResultData#EXIT_CODE_VALIDATE_ERROR}を返す場合を指します。<br>
	 * {@link GParameter}の{@value #BACKWARD_KEY}キーで格納されたコンテンツパスへフォワードします。<br><br>
	 * 
	 * <b>【遷移先のローカライズ】</b><br>
	 * {@link GViewResponseWriter}では、遷移先のパスをローカライズする事が可能です。<br>
	 * 具体的には、遷移先のコンテンツパスに、ロケールを表す文字列を指定することで、
	 * {@link jp.co.kccs.greenearth.framework.session.GSession}に指定されているロケールに該当するコンテンツに遷移します。<br>
	 * 例：{@link jp.co.kccs.greenearth.framework.session.GSession}に"ja_JP"のロケールが指定されており、遷移先にXXX.jspが指定されている場合、
	 * XXX.jsp、XXX_ja_JP.jsp、XXX_en_US.jspといった３つのコンテンツを用意しておけば、
	 * XXX_ja_JP.jspに遷移します。<br>
	 * ロケールの詳細な解決方法に関しては、{@link GJspUtils#getLocalizePath(String, Locale, ServletContext)}を参照してください。<br>
	 * 
	 * 
	 * @create 2009/08/19
	 * @see GResponseFilter#writeNomalResponse(HttpServletRequest, HttpServletResponse, GParameter, GResultData)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果オブジェクト
	 * @throws IOException フォワード処理に失敗した場合
	 * @throws ServletException フォワード処理に失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	protected void writeNomalResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter, GResultData resultData) throws IOException, ServletException {
		// 画面表示編集処理
		String path = null;
		HttpSession httpSession = request.getSession();
		ServletContext servletContext = httpSession.getServletContext();

		// ロケールの取得
		Locale locale = GWebContext.getInstance().getLocale();

		if (!GResultData.EXIT_CODE_VALIDATE_ERROR.equals(resultData.getExitCode())) {
			// 正常処理
			path = GJspUtils.getLocalizePath(getForwardPath(parameter), locale, servletContext);
		} else {
			// チェックエラー
			path = GJspUtils.getLocalizePath(parameter.getValue(BACKWARD_KEY), locale, servletContext);
			if (path == null) {
				throw new IllegalArgumentException("'" + BACKWARD_KEY + "' is not found!");
			}
		}

		GStopWatch watch = new GStopWatch();
		watch.start();
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
		LOGGER.info("Forward Page (" + watch.stop() + ") : path=" + path);
	}
	
	/**
	 * Thin Client Frameworkアプリケーションにおけるシステムエラー時に遷移するエラーページの設定を表すクラスです。<br>
	 * エラーページのパスとエラー時に発生する例外クラスのセットで表現されます。<br>
	 * 指定した例外クラスが発生した場合に、設定されているエラーページに遷移するという形になります。<br>
	 * 
	 * @create 2009/08/19
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected class GErrorPageSet {
		/** 例外クラス名 */
		public String _exception = null;
		/** エラーページパス */
		public String _path = null;
		
		/**
		 * {@link GErrorPageSet}インスタンスを初期化します。
		 * 
		 * @create 2009/08/19
		 * @auther kitamura
		 * @since 3.6.0
		 */
		public GErrorPageSet() {
		}

		/**
		 * 例外クラス名とエラーページパスを指定して、{@link GErrorPageSet}インスタンスを初期化します。
		 * 
		 * @create 2009/08/19
		 * @param exception 例外クラス名
		 * @param path エラーページパス
		 * @auther kitamura
		 * @since 3.6.0
		 */
		public GErrorPageSet(String exception, String path) {
			_exception = exception;
			_path = path;
		}

		/**
		 * 設定されている例外クラスを{@link Class}オブジェクトとして取得します。
		 * 
		 * @create 2009/08/19
		 * @return 例外クラスの{@link Class}オブジェクト
		 * @throws ClassNotFoundException 設定されている名称の例外クラスが存在しない場合
		 * @author kitamura
		 * @since 3.6.0
		 */
		public Class< ? > getExceptionClass() throws ClassNotFoundException {
			return Class.forName(_exception);
		}
	}

}
