/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.action;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link jp.co.kccs.greenearth.framework.view.component.GView#onValidate(jp.co.kccs.greenearth.framework.GParameter)}
 * で発生した検証エラーを、アクションに引き継いで処理する事を表すアノテーションです。<br>
 * アクションメソッドに指定してください。
 * 
 * @create 2006/12/19
 * @author kitamura
 * @since 3.0.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Validatefull {
}