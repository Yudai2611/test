/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.authorization;

import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.authorization.GActionAuthorizationFilter;
import jp.co.kccs.greenearth.framework.view.GViewResponseFilter;

/**
 * {@link GActionAuthorizationFilter}を拡張し、
 * {@link jp.co.kccs.greenearth.framework.view.component.GView}に定義したアクションメソッドに対応したアクセス権限を確認するフィルタです。<br>
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GViewActionAthorizationFilter extends GActionAuthorizationFilter {
	
	/**
	 * {@link GViewActionAthorizationFilter}インスタンスを初期化します。
	 * 
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GViewActionAthorizationFilter() {
	}

	protected String getActionClassName(GParameter parameter) {
		String className = parameter.getValue(GActionServlet.ACTION_BEAN_KEY);
		if (className == null) {
			className = parameter.getValue(GViewResponseFilter.BACKWARD_KEY);
		}
		if (className == null) {
			throw new IllegalArgumentException("'" + GActionServlet.ACTION_BEAN_KEY + "' is not found!");
		}
		return className;
	}
}
