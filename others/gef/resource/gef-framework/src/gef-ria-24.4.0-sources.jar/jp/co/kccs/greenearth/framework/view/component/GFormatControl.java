/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

/**
 * GreenEARTH ThinClient Frameworkにおけるフォーマットコントロールの基本動作を提供します.<br>
 * フォーマット書式文字列によって値の出力内容が変化するコントロールは、この{@link GFormatControl}を実装する必要があります。<br>
 * <br>
 * {@link GFormatControl}は、値の出力処理に必要なフォーマット書式文字列属性のsetter/getterを実装する必要があります。<br>
 * 
 * @create 2007/05/01
 * @author okajima
 * @since 3.0.0
 */
public interface GFormatControl extends GUIControl {

	/**
	 * フォーマットパターン文字列を取得します.<br>
	 * 
	 * @create 2007/04/11
	 * @return フォーマットパターン文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	String getFormat();

	/**
	 * フォーマットパターン文字列を設定します.<br>
	 * 
	 * @create 2007/04/11
	 * @param format フォーマットパターン文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	void setFormat(String format);
}
