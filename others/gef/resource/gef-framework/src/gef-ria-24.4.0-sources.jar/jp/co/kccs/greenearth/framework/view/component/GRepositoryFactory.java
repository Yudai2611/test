/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.GCacheMode;
import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * {@link GViewInterface}インスタンスの静的情報（リポジトリ）を生成するためのファクトリです.<br>
 * <br>
 * 【リポジトリと{@link GViewInterface}オブジェクトのライフサイクル】<br>
 * {@link GViewInterface}インスタンスは、JSPファイルに定義されたレイアウト構成情報を基に生成されます。<br>
 * このとき、{@link GViewInterface}インスタンスが必要となる度に、JSP情報を読み込むとレスポンスの悪化が予想されます。<br>
 * そのため、JSPファイルごとに、関連付けられた{@link GViewInterface}の初回生成時にのみJSPの情報をロードし、
 * その情報をメモリ上に保持しておき、二回目以降はこのメモリ上の情報を基にインスタンスを生成するようになっています。<br>
 * この、初回生成時にメモリ上に保持された情報を、ThinClient Frameworkでは「リポジトリ」と呼び、
 * リポジトリは{@link GRepositoryFactory}にて管理されます。<br>
 * <br>
 * 【リポジトリインスタンスと常用インスタンス】<br>
 * {@link GViewInterface}を始めとするUIコンポーネントクラスは、JSPの情報を解析し、メモリ中にキャッシュするための
 * リポジトリとしての役割（静的な設計情報）と、実際の画面に表示されている状態を保持し、画面のレンダリング情報を
 * 提供する２つの役割（動的な実行情報）を持っています。<br>
 * {@link GRepositoryFactory}クラスはリポジトリとして扱われる{@link GViewInterface}インスタンス（リポジトリインスタンス）
 * の生成し・管理を行っており、実際にプレゼンテーションロジック中で利用する{@link GViewInterface}インスタンス（常用インスタンス）は、
 * {@link GRepositoryFactory}で管理されるリポジトリからクローンを生成し取得することになります。<br>
 * 実際に常用インスタンスを生成する場合は、{@link GRepositoryFactory}より取得したリポジトリ用{@link GViewInterface}から
 * {@link GView#createPracticalInstance()}メソッドを利用することにより常用インスタンス（クローン）を生成し
 * 利用してください。<br>
 * <br>
 * 【リポジトリキャッシュの無効化】<br>
 * 一度読み込まれたJSPリポジトリは、メモリ上にキャッシュすることされますが、そのキャッシュを無効化することができます。<br>
 * キャッシュを無効するためには<code>ge-framework.properties</code>の<code>geframe.view.Repository.Cache</code>プロパティ
 * に<code>none</code>を指定してください。<br>
 * キャッシュする場合は<code>used</code>を指定します。<br>
 * 指定なしの場合は<code>used</code>として評価します。
 * <pre>geframe.view.Repository.Cache=none</pre>
 * 
 * 
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @see jp.co.kccs.greenearth.framework.view.component.GViewFactory
 * @create 2007/01/09
 * @author kitamura
 * @since 3.0.0
 */
public final class GRepositoryFactory {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GRepositoryFactory.class);
	/** リポジトリプール. */
	private static final Map<String, GViewInterface> REPOSITORY_POOL = new HashMap<String, GViewInterface>();

	/**
	 * {@link GRepositoryFactory}インスタンスを初期化します.
	 * 
	 * @create 2006/12/19
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GRepositoryFactory() {
	}

	// ---- パブリックメソッド -------------------------------------------------

	/**
	 * 指定したJSPのパスに対応する{@link GViewInterface}オブジェクトを取得します.<br>
	 * Thin Client Frameworkが定義するビューに関連づくJSP以外のコンテンツのパスを指定した場合、は<code>null</code>を返します。<br>
	 * {@link GViewInterface}オブジェクトの作成時、
	 * <code>ge-framework.properties</code>のキー<code>"geframe.view.Repository.Cache"</code>が<code>"used"</code>の場合、
	 * 作成された{@link GViewInterface}オブジェクトをキャッシュします。
	 * 
	 * @create 2006/12/19
	 * @param path JSPファイルパス
	 * @return pathに対応するリポジトリオブジェクト
	 * @throws GViewException リポジトリ生成に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GViewInterface getRepository(URL url) throws GViewException {
		if (null == url) {
			throw new GViewException(new FileNotFoundException("The view repository is not found : null"));
		}
		
		GViewInterface repository = null;
		String path = url.getPath();
		
		if (REPOSITORY_POOL.containsKey(path)) {
			repository = REPOSITORY_POOL.get(path);
		} else {
			synchronized (REPOSITORY_POOL) {
				repository = createRepository(url);
				if (repository != null) {
					GCacheMode cacheMode = GCacheMode.convert(GFrameworkUtils.getProperty("geframe.view.Repository.Cache", "used"));
					if (cacheMode == GCacheMode.USED) {
						// 一度読み込んだらキャッシュする
						REPOSITORY_POOL.put(path, repository);
					}
				}
			}
		}
		return repository;
	}

	/**
	 * UNTEST [2007/02/21][kitamura]未実施
	 * JSPリポジトリのプール（キャッシュ情報）をクリアします.
	 * 
	 * @create 2007/02/21
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void clearCache() {
		synchronized (REPOSITORY_POOL) {
			REPOSITORY_POOL.clear();
		}
	}

	// ---- プライベートメソッド ------------------------------------------------------------

	/**
	 * 指定されたノードよりリポジトリオブジェクトを生成します.<br>
	 * ノードの子供を再帰的に呼び出し、{@link GViewInterface}に対応するタグが見つかれば
	 * そのノードをデシリアライズしリポジトリ情報を生成します。
	 * 
	 * @create 2006/12/19
	 * @param node XMLノード
	 * @return リポジトリオブジェクト
	 * @throws IOException XML解析に失敗した場合
	 * @throws SAXException XML解析に失敗した場合
	 * @throws ParserConfigurationException XML解析に失敗した場合
	 * @throws ClassNotFoundException タグに対応するクラスが見つからない場合
	 * @throws IllegalAccessException タグに対応するクラスにアクセス権限がない場合
	 * @throws InstantiationException タグに対応するクラスの生成に失敗した場合
	 * @throws GViewException {@link GUIComponent#loadJspElement(Element)}に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	private static GViewInterface createRepository(Node node) throws IOException, ParserConfigurationException, SAXException, ClassNotFoundException, InstantiationException, IllegalAccessException, GViewException {
		Class< ? > clazz = null;
		if (node.getNodeType() == Node.ELEMENT_NODE) {
			// UIクラスを取得
			GTLDConfiguration tld = GTLDConfiguration.getInstance();
			clazz = tld.getUIClass(node.getNodeName());
		}

		if (clazz != null && GViewInterface.class.isAssignableFrom(clazz)) {
			GViewInterface view = (GViewInterface) clazz.newInstance();
			view.loadJspElement((Element) node);
			return view;
		} else {
			NodeList children = node.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				GViewInterface view = createRepository(child);
				if (view != null) {
					return view;
				}
			}
		}
		return null;
	}

	/**
	 * 指定されたJSPパスより、対応するリポジトリオブジェクトを生成します.
	 * 
	 * @create 2006/12/19
	 * @param url JSPのURL
	 * @return pathに対応するリポジトリオブジェクト
	 * @throws GViewException リポジトリ生成に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static GViewInterface createRepository(URL url) throws GViewException {
		InputStream stream = null;
		try {
			GStopWatch watch = new GStopWatch();
			watch.start();

			stream = url.openStream();
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document dom = db.parse(stream);
			GViewInterface repository = createRepository(dom.getDocumentElement());
			if (repository == null) {
				return null;
			}
			String path = url.getPath();
			repository.setPath(path);

			LOGGER.debug("Load JSP Repository (" + watch.stop() + ") : path=" + path);

			return repository;
		} catch (ParserConfigurationException e) {
			throw new GViewException(e);
		} catch (SAXException e) {
			throw new GViewException(e);
		} catch (IOException e) {
			throw new GViewException(e);
		} catch (ClassNotFoundException e) {
			throw new GViewException(e);
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		} finally {
			if (null != stream) {
				try {
					stream.close();
				} catch (IOException e) {
					throw new GViewException(e);
				}
			}
		}
	}
}
