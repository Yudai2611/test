/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.io.Serializable;
import java.util.List;

import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.framework.view.GViewException;

import org.w3c.dom.Element;

/**
 * GreenEARTH ThinClient Frameworkにおけるユーザーインターフェースの基本動作を提供します.<br>
 * 全てのユーザーインターフェースは、この{@link GUIComponent}を実装する必要があります。<br>
 * <br>
 * {@link GUIComponet}は常用インスタンス生成のための{@link Cloneable}インターフェースの実装と、
 * {@link HttpSession}へのバインドのための{@link Serializable}インターフェースの実装を行う必要があります。
 *
 * @see java.lang.Cloneable
 * @see java.io.Serializable
 * @create 2007/01/09
 * @author kitamura
 * @since 3.0.0
 */
public interface GUIComponent extends Cloneable, Serializable {

	/**
	 * 画面に表示する項目名の名前空間を組み立てます.
	 *
	 * @create 2007/04/18
	 * @param components コンポーネントのリスト
	 * @return 項目名の名前空間
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	String assembleLabelspace(List<GUIComponent> components);

	/**
	 * コントロールの接頭辞文字列を組み立てます.
	 *
	 * @create 2007/04/19
	 * @param components コンポーネントのリスト
	 * @return コントロールの接頭辞文字列
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	String assemblePrefix(List<GUIComponent> components);

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.
	 * このインスタンスを静的情報（リポジトリ）として扱っている状態で、
	 * このリポジトリから常用インスタンスを生成する場合に利用します。
	 *
	 * @create 2006/12/05
	 * @return 常用インスタンス（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUIComponent createPracticalInstance() throws GViewException;

	/**
	 * visible属性の値を取得します.<br />
	 * 
	 * @create 2013/07/24
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	boolean isVisible();

	/**
	 * コンポーネントの完全なIDを取得します.<br />
	 * 
	 * @create 2013/04/18
	 * @return コンポーネントの完全なID
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	String getFullId();

	/**
	 * ラベルスペースを取得します.
	 *
	 * @create 2011/02/05
	 * @return 名前空間
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getLabelspace();

	/**
	 * Name属性のプレフィックスを取得します.
	 *
	 * @create 2011/02/05
	 * @return 名前プレフィックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getNamePrefix();

	/**
	 * このコントロールが格納している親コンテナコンポーネントを取得します.
	 *
	 * @create 2007/02/16
	 * @return 親コンテナコンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUIComponent getParent();

	/**
	 * ID属性のプレフィックスを取得します.
	 *
	 * @create 2011/02/05
	 * @return IDプレフィックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getPrefix();

	/**
	 * リポジトリ情報(静的情報)を取得します.
	 *
	 * @create 2006/12/05
	 * @return リポジトリ用コンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUIComponent getRepository();

	/**
	 * JSP情報を読み込みます.<br>
	 * GreenEARTH ThinClient Frameworkで利用されるJSPはXML形式に準拠しているため、
	 * その読込みにはDOMパーサーを利用しています。<br>
	 * 各UIコンポーネントは、このDOMが解析した一部の{@link Element}を受け取り、自身のフィールドに展開します。
	 *
	 * @create 2006/12/05
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	void loadJspElement(Element element) throws GViewException;

	/**
	 * このコントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 * 実装クラスにおいて、各クラスで新設された属性値の最初期化を実装する必要があります。<br>
	 *
	 * @create 2007/04/04
	 * @author aono
	 * @since 3.0.0
	 */
	void reset();

	/**
	 * このコントロールを格納する親コンテナコンポーネントを設定します.
	 *
	 * @create 2007/02/16
	 * @param parent 親コンテナコンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setParent(GUIComponent parent);

	/**
	 * リポジトリ情報(静的情報)を設定します.
	 *
	 * @create 2006/12/05
	 * @param repository リポジトリ用コンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setRepository(GUIComponent repository);
	
	/**
	 * visible属性の値を設定します.<br />
	 * 
	 * @create 2013/07/24
	 * @param visible <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	void setVisible(boolean visible);
}
