/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.util.List;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;

/**
 * ThinClient Frameworkのユーザインターフェース（画面）を構成するための独立したコントロール（部品）を表します.<br>
 * {@link GUIControl}は、{@link GUIItem}とは異なり、他のユーザインターフェースとは関連せず、
 * 単独でユーザインターフェースとしての意味を持ち、画面上に配置されます。<br>
 * カスタムコントロールを作成する場合は、必ずこのインターフェースを実装する必要があります。
 * 
 * @see jp.co.kccs.greenearth.framework.view.component.GUIItem
 * @create 2006/12/05
 * @author kitamura
 * @since 3.0.0
 */
public interface GUIControl extends GUIComponent {

	/** フォーカス対象のオブジェクトIDを格納するキー. */
	String UICONTROL_FOCUS_ID_KEY = "jp.co.kccs.greenearth.framework.view.component.GUIControl.FocusId";

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 * このインターフェースを実装するクラスでは必ず処理を定義してください。<br>
	 * 
	 * @create 2007/03/20
	 * @return <code>true</code>=フォーカスが当てられる/<code>false</code>=フォーカスが当てられない
	 * @author fujikawa
	 * @since 3.0.0
	 */
	boolean canFocus();

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 各実装クラスは、以下のルールに従って値の消去を実装する必要がありあす。<br>
	 * [1]値に関する属性に<code>null</code>を設定します。<br>
	 * [2]boolean型の値を<code>false</code>に設定します。<br>
	 * 
	 * @create 2007/04/06
	 * @author aono
	 * @since 3.0.0
	 */
	void clear();

	/**
	 * このコントロールがコンテナとして機能している場合、格納しているコントロール内から、
	 * 指定したIDのコントロールを検索します.<br>
	 * 該当するコントロールが存在しない場合は<code>null</code>を返します。
	 * 
	 * @create 2006/12/26
	 * @param id コントロールのID
	 * @return 該当したコントロール
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUIControl findControl(String id);

	/**
	 * コントロールに入力フォーカスを設定します.
	 * 
	 * @create 2007/03/15
	 * @author kitamura
	 * @since 3.0.0
	 */
	void focus();

	/**
	 * コントロール内に格納されているコントロールのリストを取得します.<br>
	 * このインターフェースを実装するクラスでは必ず処理を定義してください。<br>
	 * 
	 * @create 2007/03/15
	 * @return コントロールリスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	List<GUIControl> getChildren();

	/**
	 * コントロールのIDを取得します.
	 * 
	 * @create 2005/11/28
	 * @return ID
	 * @author kitamura
	 * @since 3.0.0
	 */
	String getId();

	/**
	 * 画面に表示する項目名を取得します.
	 * 
	 * @create 2007/04/18
	 * @return 画面に表示する項目名
	 * @author okajima
	 * @since 3.0.0
	 */
	String getLabel();

	/**
	 * 画面に表示する項目名の名前空間を取得します.<br>
	 * 
	 * @create 2007/04/19
	 * @return 項目名の名前空間
	 * @author okajima
	 * @since 3.0.0
	 */
	String getLabelspace();

	/**
	 * 画面で利用されるパラメータ名を取得します.
	 * 
	 * @create 2007/04/10
	 * @return パラメータ名
	 * @author okajima
	 * @since 3.0.0
	 */
	String getParameterKey();

	/**
	 * 接頭辞文字列を取得します.
	 * 
	 * @create 2007/03/20
	 * @return 接頭辞文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	String getPrefix();

	/**
	 * 値をロードします.
	 * 
	 * @create 2011/02/07
	 * @param data 値
	 * @author yamashita
	 * @since 3.9.0
	 */
	void loadData(Object data);

	/**
	 * 画面入力値を表すパラメータを読み込みます.
	 * 
	 * @create 2006/12/26
	 * @param parameter パラメータオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	void loadParameter(GParameter parameter);

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.
	 * 
	 * @create 2006/12/26
	 * @param data 結果セットオブジェクト
	 * @author kitamura
	 * @since 3.0.0
	 */
	void loadResultData(GResultData data);

	/**
	 * 検証エラーを反映します.
	 * 
	 * @create 2011/02/07
	 * @param errors 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	void loadValidateError(List<GValidateError> errors);


	/**
	 * ラベルを設定します.
	 * 
	 * @create 2011/02/07
	 * @param label ラベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setLabel(String label);

	/**
	 * コントロールのIDを設定します.
	 * 
	 * @create 2005/11/28
	 * @param id ID
	 * @author kitamura
	 * @since 3.0.0
	 */
	void setId(String id);

	/**
	 * コントロール入力値の検証を行います.
	 * 
	 * @create 2007/02/07
	 * @param parameter パラメータオブジェクト
	 * @return 検証エラーリスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	List<GValidateError> validate(GParameter parameter);

	/**
	 * コントロール入力値の検証を行います.
	 * 
	 * @create 2011/02/07
	 * @param value 値
	 * @param errorlevel えらレベル
	 * @return 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GValidateError> validate(String value, GErrorLevel errorlevel);
}
