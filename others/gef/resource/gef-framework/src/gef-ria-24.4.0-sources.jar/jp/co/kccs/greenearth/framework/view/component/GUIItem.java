/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

/**
 * {@link GUIControl}の一部を表現するための構成要素（サブパーツ）を表します.<br>
 * {@link GUIItem}は、それ単体では意味を成さず、{@link GUIControl}の構成要素として利用されて始めて
 * ユーザインターフェースとしての役割を果たすUIコンポーネントです。<br>
 * 例 : ツリービューのノード、リストビューの行、列、etc...<br>
 * <br>
 * カスタムアイテムを作成する場合は、必ずこのインターフェースを実装する必要があります。
 * 
 * @create 2006/12/05
 * @author kitamura
 * @since 3.0.0
 */
public interface GUIItem extends GUIComponent {
}
