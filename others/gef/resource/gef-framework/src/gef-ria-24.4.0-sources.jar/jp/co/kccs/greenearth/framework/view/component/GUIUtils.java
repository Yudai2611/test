/*
 * Copyright 2007-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.formatter.GNumberFormatter;

import org.apache.commons.beanutils.MethodUtils;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * UIクラスの為のユーティリティクラス.<br>
 * 
 * @create 2007/01/19
 * @author wadatani
 * @since 3.0.0
 */
public final class GUIUtils {

	/** 日付フォーマッター. */
	private static GDateFormatter _dateFormatter = null;
	/** 数値フォーマッター. */
	private static GNumberFormatter _numberFormatter = null;
	
	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2007/01/19
	 * @author wadatani
	 * @since 3.0.0
	 */
	private GUIUtils() {
	}

	// ---- パブリック メソッド ----------------------------------------------------------

	/**
	 * 日付を指定された書式の文字列に変換します.<br>
	 * 
	 * 日付が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * フォーマット処理は、DIで定義された{@link GDateFormatter}の実装クラスによって処理されます。
	 * 
	 * @create 2007/04/18
	 * @param value フォーマット対象のオブジェクト
	 * @param format 書式文字列
	 * @return フォーマット付文字列
	 * @author kyo
	 * @since 3.0.0
	 */
	public static String formatDateToString(Date value, String format) {
		return formatDateToString(value, format, Locale.getDefault());
	}

	/**
	 * 日付を指定された書式の文字列に変換します.<br>
	 * 
	 * 日付が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * ロケールが<code>null</code>の場合、<code>{@link NullPointerException}</code>が発生します。<br>
	 * フォーマット処理は、DIで定義された{@link GDateFormatter}の実装クラスによって処理されます。
	 * 
	 * @create 2007/04/20
	 * @param value フォーマット対象のオブジェクト
	 * @param format 書式文字列
	 * @return フォーマット付文字列
	 * @param locale ロケール
	 * @author kyo
	 * @since 3.0.0
	 */
	public static String formatDateToString(Date value, String format, Locale locale) {
		if (value == null) {
			return null;
		} else if (locale == null) {
			throw new NullPointerException("locale is not specified.");
		}
		GDateFormatter formatter = getDateFormatter();
		if (format == null || format.equals("")) {
			return formatter.format(value, locale);
		} else {
			return formatter.format(value, locale, format);
		}
	}

	private static GDateFormatter getDateFormatter() {
		if (_dateFormatter == null) {
			_dateFormatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		}
		return _dateFormatter;
	}
	
	/**
	 * デフォルトのロケールを使用して、数値を指定された書式の文字列に変換します.<br>
	 * 
	 * 数値が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * フォーマット処理は、DIで定義された{@link GNumberFormatter}の実装クラスによって処理されます。
	 * 
	 * フォーマットの書式の指定方法については、{@link java.text.DecimalFormat}クラスを参照してください。<br>
	 * 
	 * @create 2007/03/14
	 * @param value フォーマット対象の数値
	 * @param format 書式文字列
	 * @return 変換後文字列
	 * @author aono
	 * @since 3.0.0
	 */
	public static String formatNumberToString(Number value, String format) {
		return formatNumberToString(value, format, Locale.getDefault());
	}

	/**
	 * 指定されたロケールを使用して、数値を指定された書式の文字列に変換します.<br>
	 * 数値が<code>null</code>の場合、<code>null</code>を返します。<br>
	 * ロケールが<code>null</code>の場合、<code>{@link NullPointerException}</code>が発生します。<br>
	 * フォーマット処理は、DIで定義された{@link GNumberFormatter}の実装クラスによって処理されます。
	 * 
	 * フォーマットの書式の指定方法については、{@link java.text.DecimalFormat}クラスを参照してください。<br>
	 * ロケールの指定方法については、{@link Locale}クラスを参照してください。<br>
	 * 
	 * @create 2007/03/24
	 * @param value フォーマット対象の数値
	 * @param format 書式文字列
	 * @param locale ロケール
	 * @return 変換後文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	public static String formatNumberToString(Number value, String format, Locale locale) {
		if (value == null) {
			return null;
		} else if (locale == null) {
			throw new NullPointerException("locale is not specified.");
		}
		
		GNumberFormatter formatter = getNumberFormatter();
		if (format == null || format.equals("")) {
			return formatter.format(value, locale);
		} else {
			return formatter.format(value, locale, format);
		}
	}

	private static GNumberFormatter getNumberFormatter() {
		if (_numberFormatter == null) {
			_numberFormatter = GFrameworkUtils.getComponent(GNumberFormatter.class.getName());
		}
		return _numberFormatter;
	}
	
	/**
	 * ネストされたJSPの要素から指定された型のUIコントロールを取得します.<br>
	 * 
	 * @create 2007/03/20
	 * @param control UIコントロール
	 * @param type 型
	 * @return UIコントロール配列
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static List<GUIControl> getControls(GUIControl control, Class< ? > type) {
		List<GUIControl> list = new ArrayList<GUIControl>();
		GUIControl child = null;
		List<GUIControl> children = control.getChildren();
		for (int i = 0; i < children.size(); i++) {
			child = children.get(i);
			if (child != null && type.isAssignableFrom(child.getClass())) {
				list.add(child);
			}
			List<GUIControl> grandchild = getControls(child, type);
			if (grandchild != null && grandchild.size() > 0) {
				list.addAll(grandchild);
			}
		}
		return list;
	}

	/**
	 * JSPのノード属性を、UIコンポーネントのプロパティに設定します.<br>
	 * プロパティのsetterは以下の条件を満たす必要があります。<br>
	 * [1]setterは<code>public</code>である必要があります。<br>
	 * [2]setter名のプロパティ部は1文字目が大文字、2文字目以降は小文字である必要があります。<br>
	 * 例：
	 * <pre>
	 * public setMaxlength(String maxlength)
	 * </pre>
	 * 
	 * @create 2006/12/13
	 * @param node JSPのノード
	 * @param component プロパティ設定対象のUIコンポーネント
	 * @author aono
	 * @throws InvocationTargetException セッタ内で例外が発生
	 * @since 3.0.0
	 */
	public static void setAttributes(Node node, GUIComponent component) throws InvocationTargetException {
		// 属性の一覧を取得して作成したクラスに設定
		NamedNodeMap attrlist = node.getAttributes();
		int attrCnt = attrlist.getLength();

		for (int i = 0; i < attrCnt; i++) {
			// 属性情報取得
			Node attrNo = attrlist.item(i);
			String attrName = attrNo.getNodeName();
			String attrValue = attrNo.getNodeValue();

			// セッタメソッド名 生成
			StringBuilder methodName = new StringBuilder("set");
			methodName.append(attrName.substring(0, 1).toUpperCase());

			if (attrName.length() > 1) {
				methodName.append(attrName.substring(1));
			}

			// 属性設定
			try {
				MethodUtils.invokeMethod(component, methodName.toString(), new Object[] {attrValue});
			} catch (NoSuchMethodException e) {
				// セッタメソッドが無い場合は無視して他のプロパティを処理する。
				continue;
			} catch (IllegalAccessException e) {
				// セッタメソッドにアクセスできない場合は無視して他のプロパティを処理する。
				continue;
			}
		}
	}

	// ---- プライベートメソッド -------------------------------------------------

	//	/**
	//	 * 将来用
	//	 * 数値を指定された書式の文字列に変換します.<br>
	//	 * 文字列への変換方法は、次のルールに従います。<br>
	//	 * [1]フォーマットが指定されていない場合<br>
	//	 * 　・オブジェクトが実装するtoString()メソッドを使用して文字列を作成します。<br>
	//	 * [2]出力多少のオブジェクトが配列の場合<br>
	//	 * 　・String#format(java.lang.String, java.lang.Object[])を使用して書式付文字列を生成します。<br>
	//	 * [3]出力対象のオブジェクトが配列ではない場合<br>
	//	 * 　・Formatter#format(java.lang.String, java.lang.Object[])を使用して書式付文字列を生成します。<br>
	//	 * 
	//	 * フォーマットの書式の指定方法については、参照ください。<br>
	//	 * 
	//	 * @create 2007/01/20
	//	 * @param value フォーマット対象のオブジェクト
	//	 * @param format 書式指定
	//	 * @return フォーマット付文字列
	//	 * @throws IllegalFormatException 指定された書式でフォーマットできない場合
	//	 * @author aono
	//	 * @since 3.0.0
	//	 */
	//	public static String formatObjectToString( Object value, String format ) throws IllegalFormatException
	//	{
	//		if ( value == null )
	//		{
	//			throw new NullPointerException();
	//		}
	//		if ( format == null )
	//		{
	//			// format指定が無ければ、出力方法はオブジェクトに依存
	//			return value.toString();
	//		}
	//		else if ( value.getClass().isArray() )
	//		{
	//			// 引数が配列の場合は、複数パラメータに対応したフォーマッタを使用
	//			return String.format( format, (Object[])value );
	//		}
	//		else
	//		{
	//			// 通常の出力ロジックを使用
	//			StringBuilder sb = new StringBuilder();
	//			Formatter formatter = new Formatter( sb );
	//
	//			formatter.format( format, value );
	//
	//			return formatter.out().toString();
	//		}
	//	}
}
