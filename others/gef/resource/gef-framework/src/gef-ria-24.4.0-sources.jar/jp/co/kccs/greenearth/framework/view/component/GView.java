/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.GErrorActivateMarker;
import jp.co.kccs.greenearth.framework.richview.ui.control.error.GErrorContainer;

// TODO [2007/02/22][okajima] 拡張ポイントの記述
/**
 * Thin Clientアプリケーションにおいてアプリケーションのユーザーインターフェイスを
 * 構成する画面やWebページを表すクラスです.<br>
 * {@link GView}クラスは、.jsp拡張子を持つファイル(JSP)と関連付けられています。
 * JSPのファイルは、実行時にGViewオブジェクトにそのレイアウト構成情報として読み込まれます。
 * <br>
 * また、{@link GView}オブジェクトは、画面表示時のイベントをハンドリングするための拡張ポイントを設けています。
 * 利用者は、この拡張ポイントを実装することにより、プレゼンテーションロジックの拡張を行います。
 * <br>
 * {@link GView}オブジェクトは、{@link jp.co.kccs.greenearth.framework.view.component.GUIControl}インターフェイスを実装しているUIコントロール、
 * またはこのインターフェイスを実装しているUIコントロールの子を除く、
 * ページ内のすべてのUIコントロールの名前付けコンテナとして機能します。
 * <code>GView</code>オブジェクトでは、対応するJSP内に定義されているUIコントロールをコンテナとして格納しており、
 * その内容をAPI経由で動的に変更することができます。<br>
 * <br>
 * 
 * 
 * <b>【JSPの読み込み】</b><br>
 * {@link GView}はJSPと１対１で対応付けられており、実行時にJSPに定義された画面レイアウト定義を読み込み、
 * 画面情報を構築します。<br>
 * Thin Client Frameworkで利用するJSPは、XML形式で記述することが定められています。
 * これは、対応するビューが画面レイアウト情報をXMLデータとして読み込むためです。
 * {@link GView}は対応するJSPを解析する中で発見されたカスタムタグを、
 * 自身が構成する画面のUIコンポーネント情報として読み込みます。
 * 読み込まれたUIコンポーネント情報は、JSPで定義されている階層構造そのままに、ツリー形式でビューに格納されます。<br>
 * <br>
 * 
 * 
 * <b>【{@link GResultData}の反映】</b><br>
 * {@link GView}はビジネスロジックの処理結果である{@link GResultData}を読み込み、画面表示に反映させます。<br>
 * 読み込み処理は、自動化されており{@link #loadResultData(GResultData)}を呼び出す事により実行されます。<br>
 * 処理内容としは、{@link GView}内に内包されている各{@link GUIControl}のid属性と、{@link GResultData}に
 * 格納されている各データのキー名で引き当てられ、一致したデータオブジェクトを{@link GUIControl}が自身の表示形態
 * にあわせて読み込むというものになります。<br>
 * 独自の方法で{@link GResultData}の情報を読み込む場合は、{@link GView}の{@link #onLoad(GResultData, GParameter)}をオーバーライド
 * していただき、任意の読み込み処理を記述する事もできます。<br>
 * 通常の{@link #onLoad(GResultData, GParameter)}は内部で{@link #loadResultData(GResultData)}を呼び出しています。
 * 
 * 
 * @create 2006/12/19
 * @author okajima
 * @since 3.0.0
 */
public class GView extends GViewBase implements GErrorContainer {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 6343087231272114961L;

	/**
	 * {@link GView}の新しいインスタンスを初期化します.<br>
	 * 
	 * @create 2007/01/13
	 * @author okajima
	 * @since 3.0.0
	 */
	@SuppressWarnings("deprecation")
	public GView() {
		setViewclass(GView.class.getName());
	}
	
	@Override
	public void loadResultData(GResultData data) {
		super.loadResultData(data);
		GErrorActivateMarker marker = new GErrorActivateMarker();
		marker.markActivated(this);
	}
}
