/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.jsp.PageContext;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import jp.co.kccs.greenearth.commons.utils.GReflectionUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GErrorLevel;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.control.GUIControlBase;
import jp.co.kccs.greenearth.framework.view.GTLDConfiguration;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.validator.GValidator;

// TODO [2007/02/22][okajima] 拡張ポイントの記述
/**
 * {@link GViewInterface}の基底クラスです.<br>
 *
 * @create 2006/12/19
 * @author okajima
 * @since 3.0.0
 */
public abstract class GViewBase implements GViewInterface {

	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -1760289974302661171L;

	// ----- 変数 -----------------------------------------------
	// 拡張属性
	/** 高さ. */
	private String _height = null;

	/** コントロールのID. */
	private String _id = null;

	/** 左座標. */
	private String _left = null;

	/** {@link GViewInterface}と関連付くJSPのパス. */
	private String _path = null;

	/** 座標指定方法. */
	private String _position = null;

	/** リポジトリ. */
	private GViewInterface _repository = null;

	/** 値を保持するスコープ. */
	private String _scope = SCOPE_REQUEST;

	/** 上座標. */
	private String _top = null;

//	/** タイプ. */
//	private String _type = TYPE_BASE;

	/** 画面に関連づく{@link GViewInterface}オブジェクトの完全修飾クラス名. */
	private String _viewclass = null;

	/** 幅. */
	private String _width = null;

	// 内部制御フィールド
	/** コンテナとして格納している子UIコントロールのマップ. */
	private List<GUIControl> _controls = new ArrayList<GUIControl>();

	/** ID接頭語 */
	private String _prefix = null;

	// ---- コンストラクタ -------------------------------------------------

	/**
	 * {@link GViewBase}の新しいインスタンスを初期化します.<br>
	 *
	 * @create 2007/01/13
	 * @author okajima
	 * @since 3.0.0
	 */
	public GViewBase() {
	}

	// ---- 拡張ポイント -------------------------------------------------

	/**
	 * プレゼンテーションロジックの拡張ポイントです.<br>
	 * 画面表示時のイベントをハンドリングします。<br>
	 * 標準では、アクションの結果などを{@link GViewInterface}オブジェクトに読み込みこんでいます。
	 * 画面に表示される結果セットオブジェクトなどを変更したい場合、
	 * このメソッドをオーバーライドして必要な処理を追加してください。<br>
	 *
	 * @deprecated {@link #onLoad(GResultData, GParameter, PageContext)}を利用してください
	 * @create 2007/01/14
	 * @param resultData 結果セットオブジェクト
	 * @param parameter パラメータオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public void onLoad(GResultData resultData, GParameter parameter) {
		loadResultData(resultData);
	}

	/**
	 * プレゼンテーションロジックの拡張ポイントです.<br>
	 * 画面表示時のイベントをハンドリングします。<br>
	 * 標準では、アクションの結果などを{@link GViewInterface}オブジェクトに読み込みこんでいます。
	 * 画面に表示される結果セットオブジェクトなどを変更したい場合、
	 * このメソッドをオーバーライドして必要な処理を追加してください。<br>
	 *
	 * @create 2009/08/26
	 * @param resultData 結果データ
	 * @param parameter パラメータ
	 * @param pageContext ページコンテキスト
	 * @throws Exception 画面のロードに失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		onLoad(resultData, parameter);
	}

	/**
	 * 検証処理の拡張ポイントです.<br>
	 * GView要素に含まれる{@link jp.co.kccs.greenearth.framework.view.validator.GValidator}を検証します。
	 *
	 * @create 2007/02/15
	 * @param parameter パラメーター
	 * @return エラーリスト
	 * @author aono
	 * @since 3.0.0
	 */
	public List<GValidateError> onValidate(GParameter parameter) {
		return validate(parameter);
	}

	/**
	 * アクション処理前拡張ポイントです.<br>
	 * アクション処理実行前の追加処理を記述してください。<br>
	 *
	 * @deprecated この拡張ポイントは無効になりました
	 * @create 2007/01/14
	 * @param parameter パラメータオブジェクト
	 * @param resultData 結果セットオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	public void postAction(GParameter parameter, GResultData resultData) {
		// 拡張ポイント
	}

	/**
	 * アクション処理後拡張ポイントです.<br>
	 * アクション処理実行後の追加処理を記述してください。<br>
	 *
	 * @deprecated この拡張ポイントは無効になりました
	 * @create 2007/01/14
	 * @param parameter パラメータオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	public void preAction(GParameter parameter) {
		// 拡張ポイント
	}

	// ---- パブリックメソッド -------------------------------------------------

	/**
	 * コンテナとして格納している子UIコントロールリストにUIコントロールを追加します.<br>
	 * 追加したUIコントロールについて、
	 * 親コントロールとしてこの{@link GViewInterface}オブジェクトを設定します。
	 *
	 * @create 2007/01/14
	 * @param control UIコントロールオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public void addControl(GUIControl control) {
		_controls.add(control);
		control.setParent(this);
	}

	/**
	 * 接頭辞文字列を組み立てます.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIComponent#assemblePrefix(java.util.List)
	 * @create 2007/04/20
	 * @param components コンポーネントのリスト
	 * @return 接頭辞文字列
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	public String assemblePrefix(List<GUIComponent> components) {
		return null;
	}

	/**
	 * このコントロールにフォーカスが当てられる状態かどうかを表します.<br>
	 *
	 * {@link GViewInterface}では常にフォーカスは当てられません。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#canFocus()
	 * @create 2007/03/20
	 * @return <code>false</code>
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public boolean canFocus() {
		//常にフォーカスは当てられない
		return false;
	}

	/**
	 * このコントロールの値に関する属性情報を消去します.<br>
	 * 各実装クラスは、以下のルールに従って値の消去を実装する必要がありあす。<br>
	 * [1]値に関する属性に<code>null</code>を設定します。<br>
	 * [2]boolean型の値を<code>false</code>に設定します。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#clear()
	 * @create 2007/04/06
	 * @author aono
	 * @since 3.0.0
	 */
	public void clear() {
		// 属性の初期化
		for (GUIControl con : getControls()) {
			con.clear();
		}
	}

	/**
	 * このインスタンスの状態を基に、常用のUIコンポーネント（クローン）を生成します.<br>
	 * 保持しているUIコントロールもコピーされます。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIComponent#createPracticalInstance()
	 * @create 2007/01/13
	 * @return 常用インスタンス（クローン）
	 * @throws GViewException 常用インスタンスの生成に失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	public GViewInterface createPracticalInstance() throws GViewException {
		GViewInterface destView = null;
		try {
			Class< ? > clazz = Class.forName(_viewclass);
			destView = (GViewInterface) clazz.newInstance();
			GReflectionUtils.copyProperties(this, destView);
			// TODO [2007/02/27][okajima] 問題なしだと思うが、一応注意してください。
			destView.setRepository(this);

			// 子UIコントロールのリストのコピー
			List<GUIControl> destControls = new ArrayList<GUIControl>();
			for (GUIControl srcControl : _controls) {
				GUIControl destControl = (GUIControl) srcControl.createPracticalInstance();
				destControls.add(destControl);
				destControl.setParent(destView);
			}

			destView.setChildren( destControls );

			return destView;
		} catch (ClassNotFoundException e) {
			throw new GViewException(e);
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	/**
	 * 格納しているUIコントロール内から、指定した名前のUIコントロールを検索します.<br>
	 * コンテナとして格納している子UIコントロール内も検索します。
	 * 該当するUIコントロールが存在しない場合は<code>null</code>を返します。
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#findControl(java.lang.String)
	 * @create 2007/01/14
	 * @param id UIコントロール名
	 * @return UIコントロールオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public GUIControl findControl(String id) {
		if (id == null) {
			return null;
		}
		for (GUIControl control : _controls) {
			if (control.getId().equals(id)) {
				return control;
			} else {
				GUIControl child = control.findControl(id);
				if (child != null) {
					return child;
				}
			}
		}
		return null;
	}

	/**
	 * 表示名空間を取得します.<br>
	 * ここでは何もしません。
	 *
	 * @see GUIControl#assembleLabelspace(GUIControl)
	 * @create 2007/04/18
	 * @param components コンポーネントのリスト
	 * @return 表示名空間
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	public String assembleLabelspace(List<GUIComponent> components) {
		return null;
	}

	/**
	 * コントロールに入力フォーカスを設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#focus()
	 * @create 2007/03/16
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void focus() {
		//何もしない
	}

	/**
	 * コントロール内に格納されているコントロールのリストを取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#getChildren()
	 * @create 2007/03/16
	 * @return コントロールリスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public List<GUIControl> getChildren() {
		if (_controls != null) {
			return _controls;
		} else {
			return new ArrayList<GUIControl>();
		}
	}

	/**
	 * 子UIコントロールのリストから指定された名前のUIコントロールオブジェクトを取得します.<br>
	 *
	 * @create 2007/01/13
	 * @param id UIコントロール名
	 * @return UIコントロールオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public GUIControl getControl(String id) {
		GUIControl control = null;
		for (int i = 0; i < _controls.size(); i++) {
			GUIControl tempcontrol = _controls.get(i);
			if (tempcontrol != null && tempcontrol.getId() != null && tempcontrol.getId().equals(id)) {
				control = tempcontrol;
				break;
			}
		}
		return control;
	}

	/**
	 * JSP情報を読み込みます.<br>
	 * JSPのHTMLタグの属性を、フィールドに設定します。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIComponent#loadJspElement(org.w3c.dom.Element)
	 * @create 2007/01/13
	 * @param element 読み込み対象JSPエレメント
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	public void loadJspElement(Element element) throws GViewException {
		try {
			GUIUtils.setAttributes(element, this);
		} catch (InvocationTargetException e) {
			throw new GViewException(e);
		}
		loadNestedNode(element);
	}

	/**
	 * 画面入力値を表すパラメータを読み込みます.<br>
	 * {@link GViewInterface}が保持しているすべての子UIコントロールに対して、
	 * {@link GUIControl#loadParameter(GParameter)}を呼び出しています。<br>
	 *
	 * @see GUIControl#loadParameter(GParameter)
	 * @create 2007/01/13
	 * @param parameter パラメータオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public void loadParameter(GParameter parameter) {
		if (parameter == null) {
			return;
		}

		// 子UIコントロールのloadParameter(GParameter)の呼び出し
		for (GUIControl control : _controls) {
			control.loadParameter(parameter);
		}
	}

	/**
	 * ビジネスロジックの処理結果を表す結果セットを読み込みます.<br>
	 * {@link GViewInterface}が保持しているすべての子UIコントロールに対して、
	 * {@link GUIControl#loadResultData(GResultData)}を呼び出しています。<br>
	 *
	 * @see GUIControl#loadResultData(GResultData)
	 * @create 2007/01/13
	 * @param data 結果セットオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public void loadResultData(GResultData data) {
		if (data == null) {
			return;
		}

		// 子UIコントロールのloadResultData(GResultData)の呼び出し
		for (GUIControl control : _controls) {
			control.loadResultData(data);
		}
	}

	/**
	 * このコントロール及び子コントロールの属性値にリポジトリ用コンポーネントと同じ状態に戻します.<br>
	 *
	 * @create 2007/04/06
	 * @author aono
	 * @since 3.0.0
	 */
	public void reset() {
		// 属性の初期化
		//		GUIUtils.copyProperties( getRepository(), this );

		GViewBase control = (GViewBase) getRepository();
		setHeight(control.getHeight());
		setLeft(control.getLeft());
		setPath(control.getPath());
		setPosition(control.getPosition());
		setScope(control.getScope());
		setTop(control.getTop());
//		setType(control.getType());
		setWidth(control.getWidth());
		setViewclass(control.getViewclass());

		// 要素の初期化
		for (GUIControl con : getControls()) {
			con.reset();
		}
	}

	/**
	 * {@link GViewInterface}要素に含まれる{@link GValidator}を検証します.
	 *
	 * @see GUIControl#validate(GParameter)
	 * @create 2007/02/15
	 * @param parameter パラメーター
	 * @return エラーリスト
	 * @author aono
	 * @since 3.0.0
	 */
	public List<GValidateError> validate(GParameter parameter) {
		List<GValidateError> allErrorList = null;
		for (GUIControl control : getControls()) {
			List<GValidateError> errors = control.validate(parameter);
			if (errors != null) {
				if (allErrorList == null) {
					allErrorList = new ArrayList<GValidateError>();
				}
				allErrorList.addAll(errors);
			}
		}
		return allErrorList;
	}

	// ---- プロテクテッドメソッド -------------------------------------------------

	/**
	 * ネストされたJSPの要素をUIコントロールに読み込みます.<br>
	 *
	 * @create 2007/01/13
	 * @param node 読み込み対象となるJSPの要素
	 * @throws GViewException JSPの読み込みに失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	protected void loadNestedNode(Node node) throws GViewException {
		try {
			NodeList children = node.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				Class< ? > clazz = null;
				if (child.getNodeType() == Node.ELEMENT_NODE) {
					// TLDファイルよりUIクラスを取得
					GTLDConfiguration tld = GTLDConfiguration.getInstance();
					clazz = tld.getUIClass(child.getNodeName());
				}

				if (clazz != null && GUIControl.class.isAssignableFrom(clazz)) {
					// JSPの要素をUIコントロールに読み込みます
					GUIControl control = (GUIControl) clazz.newInstance();
					control.loadJspElement((Element) child);
					addControl(control);
				} else {
					loadNestedNode(child);
				}
			}
		} catch (InstantiationException e) {
			throw new GViewException(e);
		} catch (IllegalAccessException e) {
			throw new GViewException(e);
		}
	}

	// ---- パブリックプロパティ -------------------------------------------------

	/**
	 * コンテナとして格納している子UIコントロールのリストを取得します.<br>
	 *
	 * @create 2007/01/14
	 * @return 子UIコントロールのリストオブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public List<GUIControl> getControls() {
		return _controls;
	}

	/**
	 * コンポーネントの完全なIDを取得します.<br />
	 *
	 * @create 2013/04/18
	 * @return コンポーネントの完全なID
	 * @author yamashita
	 * @since 3.10.0.E
	 */
	public String getFullId() {
		return GStringUtils.nullToBlank(getPrefix()) + GStringUtils.nullToBlank(getId());
	}

	/**
	 * コンポーネントの高さを取得します.
	 *
	 * @create 2006/12/05
	 * @return 高さ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getHeight() {
		return _height;
	}

	/**
	 * コントロールのIDを取得します.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#getId()
	 * @create 2007/02/18
	 * @return ID
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getId() {
		return _id;
	}

	/**
	 * 画面に表示する項目名を取得します.<br>
	 *
	 * {@link GUIControlBase#_labelid}が設定されている場合、そのリソースIDに紐づくリソースの値を取得します。<br>
	 * {@link GUIControlBase#_labelid}が設定されていない場合、{@link GUIControlBase#_labelvalue}に設定された値を取得します。<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#getLabel()
	 * @create 2007/04/18
	 * @return 画面に表示する項目名
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getLabel() {
		return null;
	}

	/**
	 * 画面に表示する項目名の名前空間を取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#getLabelspace()
	 * @create 2007/04/19
	 * @return 項目名の名前空間
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getLabelspace() {
		return null;
	}

	/**
	 * コンポーネントの左端の x 座標を取得します.
	 *
	 * @create 2006/12/05
	 * @return コンポーネントの左端の x 座標
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getLeft() {
		return _left;
	}

	/**
	 * 画面で利用されるパラメータ名を取得します.<br>
	 *
	 * {@link GViewInterface}は画面に表示されないため、<code>null</code>を返します。
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#getParameterKey()
	 * @create 2007/04/10
	 * @return パラメータ名
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getParameterKey() {
		return null;
	}

	/**
	 * このコントロールが格納されているコンテナコンポーネントを取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIComponent#getParent()
	 * @create 2007/04/19
	 * @return 親コントロール
	 * @author okajima
	 * @since 3.0.0
	 */
	public GUIComponent getParent() {
		return null;
	}

	/**
	 * {@link GViewInterface}と関連付くJSPのパスを取得します.<br>
	 *
	 * @create 2007/01/14
	 * @return JSPのパス名
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getPath() {
		return _path;
	}

	/**
	 * 座標の指定方法を取得します.
	 *
	 * @create 2007/01/16
	 * @return <code>static</code>/<code>relative</code>/<code>absolute</code>/<code>fixed</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getPosition() {
		return _position;
	}

	/**
	 * 接頭辞文字列を取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#getPrefix()
	 * @create 2007/04/09
	 * @return 接頭辞文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getPrefix() {
		if (_prefix == null) {
			String prefix = null;
			if (getParent() != null) {
				prefix = getParent().getPrefix();
			}
			_prefix = GStringUtils.nullToBlank(prefix);
		}
		return _prefix;
	}

	/**
	 * リポジトリ情報(静的情報)を取得します.
	 *
	 * @create 2007/02/18
	 * @return リポジトリ用コンポーネント
	 * @author okajima
	 * @since 3.0.0
	 */
	public GViewInterface getRepository() {
		return _repository;
	}

	/**
	 * {@link GViewInterface}オブジェクトの値を保持するスコープを取得します.<br>
	 *
	 * @create 2006/12/29
	 * @return <code>application</code>/<code>session</code>/<code>request</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getScope() {
		return _scope;
	}

	/**
	 * コンポーネントの上端の y 座標を取得します.
	 *
	 * @create 2006/12/05
	 * @return コンポーネントの上端の y 座標
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getTop() {
		return _top;
	}

//	/**
//	 * JSPのタイプを取得します.
//	 *
//	 * @create 2007/02/18
//	 * @return <code>include</code>/<code>base</code>
//	 * @author okajima
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	public String getType() {
//		return _type;
//	}

	/**
	 * 画面に関連づく{@link GViewInterface}オブジェクトの完全修飾クラス名を取得します.<br>
	 *
	 * @create 2006/12/29
	 * @return {@link GViewInterface}クラス名
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getViewclass() {
		return _viewclass;
	}

	/**
	 * コンポーネントの幅を取得します.
	 *
	 * @create 2006/12/05
	 * @return 幅
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getWidth() {
		return _width;
	}

	/**
	 * コンポーネントの高さを設定します.
	 *
	 * @create 2006/12/05
	 * @param height 高さ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setHeight(String height) {
		_height = height;
	}

	/**
	 * コントロールのIDを設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#setId(java.lang.String)
	 * @create 2007/02/18
	 * @param id ID
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setId(String id) {
		_id = id;
	}

	/**
	 * コンポーネントの左端の x 座標を設定します.
	 *
	 * @create 2006/12/05
	 * @param left コンポーネントの左端の x 座標
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setLeft(String left) {
		_left = left;
	}

	/**
	 * このコントロールを格納するコンテナコントロールを設定します.
	 *
	 * @create 2007/04/19
	 * @param parent 親コントロール
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setParent(GUIComponent parent) {
	}

	/**
	 * {@link GViewInterface}と関連付くJSPのパス名を設定します.<br>
	 *
	 * @create 2007/01/14
	 * @param path JSPのパス名
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setPath(String path) {
		_path = path;
	}

	/**
	 * 座標の指定方法と設定します.<br>
	 * <code>static</code>:本来の位置<br>
	 * <code>relative</code>:本来の位置からの相対位置指定<br>
	 * <code>absolute</code>:絶対位置指定<br>
	 * <code>fixed</code>:絶対位置に固定<br>
	 *
	 * @create 2007/01/16
	 * @param position <code>static</code>/<code>relative</code>/<code>absolute</code>/<code>fixed</code>
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setPosition(String position) {
		_position = position;
	}

	/**
	 * リポジトリ情報(静的情報)を設定します.
	 *
	 * @create 2007/02/18
	 * @param repository リポジトリ用コンポーネント
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setRepository(GUIComponent repository) {
		_repository = (GViewInterface) repository;
	}

	/**
	 * {@link GViewInterface}オブジェクトの値を保持するスコープを設定します.<br>
	 * <code>application</code>	: アプリケーション単位で値を保持します。<br>
	 * <code>session</code> 	: セッション単位で値を保持します。<br>
	 * <code>request</code>		: リクエスト単位で値を保持します。<br>
	 *
	 * @create 2006/12/29
	 * @param scope <code>application</code>/<code>session</code>/<code>request</code>
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	public void setScope(String scope) {
		_scope = scope;
	}

	/**
	 * コンポーネントの上端の y 座標を設定します.
	 *
	 * @create 2006/12/05
	 * @param top
	 *            コンポーネントの上端の y 座標
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setTop(String top) {
		_top = top;
	}

//	/**
//	 * JSPのタイプを設定します.<br>
//	 * <code>include</code>	: インクルードされたJSP<br>
//	 * <code>base</code>	: 基底となるJSP<br>
//	 *
//	 * @create 2007/02/18
//	 * @param type <code>include</code>/<code>base</code>
//	 * @author okajima
//	 * @since 3.0.0
//	 */
//	@Deprecated
//	public void setType(String type) {
//		_type = type;
//	}
//
	/**
	 * 画面に関連づく{@link GViewInterface}オブジェクトの完全修飾クラス名を設定します.<br>
	 *
	 * @create 2006/12/29
	 * @param viewclass {@link GViewInterface}クラス名
	 * @deprecated 内部処理制御用のため使用しないでください。
	 * @author okajima
	 * @since 3.0.0
	 */
	@Deprecated
	public void setViewclass(String viewclass) {
		_viewclass = viewclass;
	}

	/**
	 * コンポーネントの幅を設定します.
	 *
	 * @create 2006/12/05
	 * @param width 幅
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setWidth(String width) {
		_width = width;
	}

	/**
	 * エラーページ用の例外を取得します。
	 *
	 * @create 2009/08/26
	 * @param pageContext ページコンテキスト
	 * @return 例外
	 * @author kitamura
	 * @since 3.6.0
	 */
	public static Throwable getSystemException(PageContext pageContext) {
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
		String exceptionKey = parameter.getValue(GConstants.EXCEPTION_KEY);
		Throwable e = null;
		if (exceptionKey != null) {
			e = (Throwable) pageContext.getAttribute(exceptionKey);
		}
		if (e == null) {
			e = pageContext.getException();
		}
		return e;
	}

	/**
	 * 値をロードします.
	 * ※本メソッドは何も処理を行いません。
	 *
	 * @create 2011/02/07
	 * @param data 値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadData(Object data) {
	}

	/**
	 * 検証エラーを反映します.
	 * ※本メソッドは何も処理を行いません。
	 *
	 * @create 2011/02/07
	 * @param errors 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void loadValidateError(List<GValidateError> errors) {
	}

	/**
	 * ラベルを設定します.
	 * ※本メソッドは何も処理を行いません。
	 *
	 * @create 2011/02/07
	 * @param label ラベル
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setLabel(String label) {
	}

	/**
	 * コントロール入力値の検証を行います.
	 * ※本メソッドは何も処理を行いません。
	 *
	 * @create 2011/02/07
	 * @param value 値
	 * @param errorlevel エラーレベル
	 * @return 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	public List<GValidateError> validate(String value, GErrorLevel errorlevel) {
		return new ArrayList<GValidateError>();
	}

	/**
	 * Name属性のプレフィックスを取得します.
	 * ※本メソッドは何も処理を行いません。
	 *
	 * @create 2011/02/05
	 * @return 名前プレフィックス
	 * @author yamashita
	 * @since 3.9.0
	 */
	public String getNamePrefix() {
		return null;
	}

	/**
	 * コントロール内に格納されているコントロールのリストを取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.GUIControl#getChildren()
	 * @create 2012/09/30
	 * @return コントロールリスト
	 * @author KCCS ichihara
	 * @since 3.10.0.D
	 */
	public void setChildren(List<GUIControl> controls) {
		_controls = controls;
	}

	/**
	 * visible属性の値を取得します.<br />
	 *
	 * @create 2013/07/24
	 * @return <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public boolean isVisible() {
		return true;
	}

	/**
	 * visible属性の値を設定します.<br />
	 *
	 * @create 2013/07/24
	 * @param visible <code>true:表示</code>/<code>false:非表示</code>
	 * @author yamashita
	 * @since 3.12.0
	 */
	@Override
	public void setVisible(boolean visible) {
	}
}
