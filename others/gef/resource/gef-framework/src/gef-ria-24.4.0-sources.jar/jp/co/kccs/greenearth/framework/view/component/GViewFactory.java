/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.framework.view.GViewException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * {@link GViewInterface}オブジェクトを生成するファクトリです.<br>
 * <br>
 * 【ビューのライフサイクル】<br>
 * {@link GViewInterface}のライフサイクルは、{@link GViewFactory}によって管理されます。<br>
 * ビューはインスタンス毎にスコープ属性を持っており、このスコープ属性で指定された範囲の間インスタンスが保持され続けます。<br>
 * スコープの指定は、ビューと対応するJSPに記述されているHTMLタグのscope属性で行います。<br>
 * <br>
 * 指定できるスコープは以下の通りです。
 * <table border="1" cellpadding="3" cellspacing="0">
 * 		<tr><td>request</td><td>リクエスト間でインスタンスが共有されます。</td></tr>
 * 		<tr><td>session</td><td>HTTPセッション間でインスタンスが共有されます。</td></tr>
 * 		<tr><td>application</td><td>webアプリケーション間でインスタンスが共有されます。</td></tr>
 * </table><br>
 * 
 * 【ビューインスタンスの生成とJSP情報のキャッシュ】<br>
 * ビューはJSPに定義されたレイアウト情報を読み込みインスタンス化されます。<br>
 * ビューは生成要求がある度にJSPを読み込むのではなく、初回アクセス時のみJSP情報の読み込みを行い、
 * その情報をメモリ上に「リポジトリ」としてキャッシュします。<br>
 * 二度目以降は、このリポジトリ情報を基に常用インスタンスを生成し返します。<br>
 * リポジトリ情報の管理は、別途{@link GRepositoryFactory}にて行われます。<br><br>
 * 
 * 【通常コンテンツの取り扱いについて】<br>
 * Thin Client Frameworkが定義するビューに関連づくJSP以外のコンテンツのパスを指定した場合、
 * {@link GViewFactory#getView(String, HttpServletRequest)}は<code>null</code>を返します。<br>
 * また、<code>null</code>が返された常コンテンツパスは、{@link GViewInterface}と関連性のないコンテンツとして管理され、
 * 二度目以降の取得要求では、JSPの読み込みは行われず、即座に<code>null</code>が返されることになります。<br><br>
 * 
 * 【インスタンスキャッシュの解放】<br>
 * スコープ毎にキャッシュされている{@link GViewInterface}インスタンスは、{@link #releaseView(String, HttpServletRequest)}メソッドにて
 * 解放することができます。<br>
 * また、明示的に{@link #releaseView(String, HttpServletRequest)}メソッドをコールしなくても、{@link GViewInterface}に指定しているスコープ
 * が終了すると、自動的に解放されます。
 * 
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @see jp.co.kccs.greenearth.framework.view.component.GRepositoryFactory
 * @create 2007/01/06
 * @author kitamura
 * @since 3.0.0
 */
public final class GViewFactory {

	/** 各スコープに値を格納する時のキー名. */
	public static final String ATTRIBUTE_KEY = "jp.co.kccs.greenearth.framework.view.VIEW_POOL";
	/** ビューと関連するJSP以外のコンテンツを管理するマップ. */
	private static Map<String, String> _anotherContentsMap = Collections.synchronizedMap(new HashMap<String, String>());
	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GViewFactory.class);

	/**
	 * {@link GViewFactory}インスタンスを初期化します.
	 * 
	 * @create 2007/01/06
	 * @author kitamura
	 * @since 3.0.0
	 */
	private GViewFactory() {
	}

	/**
	 * 指定されたJSPパスに対応するビューオブジェクトを取得します.<br>
	 * ビューに指定されているスコープ内でまだビューオブジェクトが生成されていない場合は、新規生成して返します。<br>
	 * ビューに指定されているスコープ内で既に生成済みであれば、そのインスタンスを返します。
	 * 
	 * @create 2007/01/06
	 * @param path ビューに対応するJSPパス
	 * @param request ビューを格納するためのスコープを管理しているコンテナ
	 * @return ビューオブジェクト
	 * @throws GViewException ビューの生成に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static synchronized GViewInterface getView(String path, HttpServletRequest request) throws GViewException {
		if (path == null) {
			throw new NullPointerException("Path is null.");
		}

		int indexq = path.lastIndexOf('?');
		if (indexq > 0) {
			path = path.substring(0, indexq);
		}

		// JSP以外のコンテンツ
		if (_anotherContentsMap.containsKey(path)) {
			return null;
		}

		// リクエストプールの取得
		Map<String, GViewInterface> requestPool = (Map<String, GViewInterface>) request.getAttribute(ATTRIBUTE_KEY);

		// セッションプールの取得
		HttpSession session = request.getSession();
		Map<String, GViewInterface> sessionPool = (Map<String, GViewInterface>) session.getAttribute(ATTRIBUTE_KEY);

		// アプリケーションプールの取得
		ServletContext context = session.getServletContext();
		Map<String, GViewInterface> applicationPool = (Map<String, GViewInterface>) context.getAttribute(ATTRIBUTE_KEY);

		GViewInterface view = null;
		if (requestPool != null && requestPool.containsKey(path)) {
			view = requestPool.get(path);
		}
		else if (sessionPool != null && sessionPool.containsKey(path)) {
			view = sessionPool.get(path);
		}
		else if (applicationPool != null && applicationPool.containsKey(path)) {
			view = applicationPool.get(path);
		}
		else {
			// 新規作成
			view = createView(path, request);
			if (view != null) {
				if (GViewInterface.SCOPE_APPLICATION.equals(view.getScope())) {
					if (applicationPool == null) {
						//applicationPool = Collections.synchronizedMap( new HashMap<String, GView>() );
						applicationPool = new ConcurrentHashMap<String, GViewInterface>();
					}
					applicationPool.put(path, view);
					context.setAttribute(ATTRIBUTE_KEY, applicationPool);
				}
				else if (GViewInterface.SCOPE_SESSION.equals(view.getScope())) {
					if (sessionPool == null) {
						//sessionPool = Collections.synchronizedMap( new HashMap<String, GView>() );
						sessionPool = new ConcurrentHashMap<String, GViewInterface>();
					}
					sessionPool.put(path, view);
					session.setAttribute(ATTRIBUTE_KEY, sessionPool);
				}
				else {
					if (requestPool == null) {
						//requestPool = Collections.synchronizedMap( new HashMap<String, GView>() );
						requestPool = new ConcurrentHashMap<String, GViewInterface>();
					}
					requestPool.put(path, view);
					request.setAttribute(ATTRIBUTE_KEY, requestPool);
				}
			}
			else {
				_anotherContentsMap.put(path, null);
			}
		}

		return view;
	}

	/**
	 * UNTEST [2007/02/16][kitamura]未実施
	 * 指定されたJSPパスに対応するビューオブジェクトを解放します.<br>
	 * スコープ毎にキャッシュされたビューを削除しています。<br>
	 * {@link GRepositoryFactory}に格納されているリポジトリ情報は解放されません。
	 * 
	 * @create 2007/02/16
	 * @param path ビューに対応するJSPのパス
	 * @param request ビューを格納するためのスコープを管理しているコンテナ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static synchronized void releaseView(String path, HttpServletRequest request) {
		if (path == null) {
			throw new NullPointerException("Path is null.");
		}
		GViewInterface view = getView(path, request);
		if (view == null) {
			_anotherContentsMap.remove(path);
			return;
		}

		String scope = view.getScope();
		if (GViewInterface.SCOPE_APPLICATION.equals(scope)) {
			HttpSession session = request.getSession();
			ServletContext context = session.getServletContext();
			Map<String, GViewInterface> applicationPool = (Map<String, GViewInterface>) context.getAttribute(ATTRIBUTE_KEY);
			applicationPool.remove(path);
		}
		else if (GViewInterface.SCOPE_SESSION.equals(scope)) {
			HttpSession session = request.getSession();
			Map<String, GViewInterface> sessionPool = (Map<String, GViewInterface>) session.getAttribute(ATTRIBUTE_KEY);
			sessionPool.remove(path);
		}
		else {
			Map<String, GViewInterface> requestPool = (Map<String, GViewInterface>) request.getAttribute(ATTRIBUTE_KEY);
			requestPool.remove(path);
		}
	}

	/**
	 * 指定されたJSPパスに対応するビューオブジェクトを生成します.<br>
	 * 各ビューの生成には、初回生成時のみJSP情報の読み込みを行い、
	 * 二度目以降は、初回生成時にキャッシュしておいた情報を基にインスタンス生成を行っています。<br>
	 * 指定されたパスに該当するコンテンツが、ThinClient Frameworkで定義されるビューとは異なる（htmlコンテンツや通常のJSPなど）
	 * 場合 、<code>null</code>を返します。
	 * 
	 * @see GRepositoryFactory
	 * @create 2007/01/06
	 * @param path ビューに対応するJSPのパス
	 * @param request リクエスト
	 * @return ビューオブジェクト
	 * @throws GViewException ビューの生成に失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	protected static GViewInterface createView(String path, HttpServletRequest request) throws GViewException {
		if (path == null) {
			throw new NullPointerException("Path is null.");
		}
		
		// NOTE: HttpSession#getServletContext と GWebContext#getServletContext の使い分けの基準が不明確
		ServletContext context = request.getSession().getServletContext();
		try {
			URL url = context.getResource(path);
			GViewInterface repository = GRepositoryFactory.getRepository(url);
			if (repository != null) {
				GViewInterface view = repository.createPracticalInstance();
				LOGGER.debug("Create View : class=" + view.getViewclass() + " scope=" + view.getScope());
				return view;
			}
			else {
				return null;
			}
		} catch (MalformedURLException e) {
			throw new GViewException(new FileNotFoundException("The view repository is not found : " + path));
		}
	}
}
