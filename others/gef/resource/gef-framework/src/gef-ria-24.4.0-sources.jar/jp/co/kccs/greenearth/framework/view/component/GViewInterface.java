/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.util.List;

import jakarta.servlet.jsp.PageContext;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;

/**
 * ビューインタフェースです.
 *
 *
 * @create 2011/03/30
 * @author yamashita
 * @since 3.9.0
 */
public interface GViewInterface extends GUIControl {

	/** <code>application</code>スコープ. */
	String SCOPE_APPLICATION = "application";
	/** <code>request</code>スコープ. */
	String SCOPE_REQUEST = "request";
	/** <code>session</code>スコープ. */
	String SCOPE_SESSION = "session";
//	/** <code>base</code>タイプ. */
//	String TYPE_BASE = "base";
//	/** <code>include</code>タイプ. */
//	String TYPE_INCLUDE = "include";

	/**
	 *
	 * @create 2011/03/07
	 * @param resultData
	 * @param parameter
	 * @param pageContext
	 * @throws Exception
	 * @author yamashita
	 * @since 3.9.0
	 */
	void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception;

	/**
	 * 検証処理の拡張ポイントです.<br>
	 *
	 * @create 2011/03/07
	 * @param parameter パラメータ
	 * @return 検証エラーリスト
	 * @author yamashita
	 * @since 3.9.0
	 */
	List<GValidateError> onValidate(GParameter parameter);

	/**
	 * {@link GViewInterface}と関連付くJSPのパスを取得します.
	 *
	 * @create 2011/03/30
	 * @return JSPのパス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getPath();

	/**
	 * {@link GViewInterface}の値を保持するスコープを取得します.<br>
	 *
	 * @create 2011/03/30
	 * @return <code>application</code>/<code>session</code>/<code>request</code>
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getScope();

//	/**
//	 * JSPのタイプを取得します.
//	 *
//	 * @create 2011/03/30
//	 * @return <code>include</code>/<code>base</code>
//	 * @author yamashita
//	 * @since 3.9.0
//	 */
//	String getType();

	/**
	 * 画面に関連づく{@link GViewInterface}の完全修飾クラス名を取得します.<br>
	 *
	 * @create 2011/03/30
	 * @return ビュークラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getViewclass();

	/**
	 * {@link GViewInterface}と関連付くJSPのパス名を設定します.<br>
	 *
	 * @create 2011/03/30
	 * @param path JSPのパス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setPath(String path);

	/**
	 * {@link GViewInterface}オブジェクトの値を保持するスコープを設定します.<br>
	 * <code>application</code>	: アプリケーション単位で値を保持します。<br>
	 * <code>session</code> 	: セッション単位で値を保持します。<br>
	 * <code>request</code>		: リクエスト単位で値を保持します。<br>
	 *
	 * @create 2011/03/30
	 * @param scope
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setScope(String scope);

//	/**
//	 * JSPのタイプを設定します.
//	 *
//	 * @create 2011/03/30
//	 * @param type
//	 * @author yamashita
//	 * @since 3.9.0
//	 */
//	void setType(String type);

	/**
	 * 画面に関連づく{@link GViewInterface}の完全修飾クラス名を設定します.<br>
	 *
	 * @create 2011/03/30
	 * @param viewclass ビュークラス名
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setViewclass(String viewclass);

	/**
	 * コントロール内に格納されているコントロールのリストを設定します.<br>
	 * このインターフェースを実装するクラスでは必ず処理を定義してください。<br>
	 *
	 * @create 2012/09/30
	 * @return コントロールリスト
	 * @author KCCS ichihara
	 * @since 3.10.0.D
	 */
	void setChildren(List<GUIControl> conrols);

	/**
	 * 常用のUIコンポーネントを生成します.<br>
	 *
	 * @create 2014/01/30
	 * @return 常用インスタンス
	 * @author KCCS N.Nishimura
	 * @since 3.13.0
	 */
	GViewInterface createPracticalInstance();
}
