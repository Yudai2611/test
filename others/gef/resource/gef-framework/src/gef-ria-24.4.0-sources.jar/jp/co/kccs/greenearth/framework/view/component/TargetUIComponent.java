/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link GUIComponent}レンダリング用カスタムタグに対して、
 * どの{@link GUIComponent}をレンダリング対象とするかを指定するためのアノテーションです.<br>
 * {@link GUIComponent}レンダリング用カスタムタグ専用のアノテーションです。
 * 
 * @create 2007/01/09
 * @author kitamura
 * @since 3.0.0
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface TargetUIComponent {

	/** レンダリング対象UIコンポーネントクラス. */
	Class< ? > value();
}
