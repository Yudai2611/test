/*
 * Copyright 2007-2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import jakarta.servlet.jsp.tagext.Tag;

import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 子コントロールのコンテナになる親コンポーネントのHTMLコードをレンダリングするタグを表します.<br>
 * コンテナから各子コントロールを取り出すための{@link #getControl(String)}メソッドが定義されています.
 *
 * @create 2007/01/28
 * @author kitamura
 * @since 3.0.0
 */
public interface GContainerTag extends Tag {

	/**
	 * タグに関連付けられたコンポーネントを取得します.
	 *
	 * @create 2011/06/11
	 * @return コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	GUIComponent getAssociatedComponent();

	/**
	 * コンテナとして格納している子コントロールの中から
	 * 指定したIDに該当するコントロールを取得します.
	 *
	 * @create 2007/01/28
	 * @param id コントロールのID
	 * @return コントロール
	 * @author kitamura
	 * @since 3.0.0
	 */
	GUIControl getControl(String id);

	/**
	 * id属性を取得します.
	 *
	 * @create 2011/06/11
	 * @return コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getId();
}
