/*
 * Copyright 2008-2017 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * JavaScript文字列を生成するクラスです.<br>
 * 
 * バインドパラメータとして指定された値はJavaScriptの定数文字列としてJavaScriptエスケープ処理を行います。
 * そして、指定されたスクリプト文字列に定義されたバインド変数{@value this#ATTRIBUTE_BIND_PARAMETER}を
 * JavaScriptエスケープ後のバインドパラメータの前後にシングルクオート"'"を付加してバインド処理を行います。<br>
 * 
 * XHTMLのイベントハンドラ属性、XHTMLのscript要素の内部テキストともに、JavaScriptの構文生成時は
 * {@link GJavaScriptBuilder}を使用してください。
 * 
 * @create 2008/07/18
 * @author okajima
 * @since 3.5.0
 */
public class GJavaScriptBuilder {

	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2008/08/21
	 * @auther okajima
	 * @since 3.5.0
	 */
	public GJavaScriptBuilder() {
	}

	// ---- プライベートフィールド ---------------------------------------------

	/** 属性値のバインド変数定数値 */
	private static final String ATTRIBUTE_BIND_PARAMETER = "??";

	/** バインド変数を含むスクリプト文字列バッファ. */
	private StringBuilder javaScriptStrBuilder = new StringBuilder();

	/** バインドパラメータバッファ. */
	private List<String> bindParameters = new ArrayList<String>();

	// ---- パブリックメソッド ---------------------------------------------

	/**
	 * 指定されたスクリプト文字列をシーケンスの後尾に追加します.<br>
	 * <br>
	 * バインド変数{@value this#ATTRIBUTE_BIND_PARAMETER}は含めないでください。<br>
	 * バインド変数を含む場合は、{@link this#append(String, String...)}を使用してください。
	 * 
	 * @create 2008/07/18
	 * @param javaScriptStr スクリプト文字列
	 * @return このオブジェクトへの参照
	 * @author okajima
	 * @since 3.5.0
	 */
	public GJavaScriptBuilder append(String javaScriptStr) {

		if (javaScriptStr != null) {
			javaScriptStrBuilder.append(javaScriptStr);
		}

		return this;
	}

	/**
	 * 指定されたスクリプト文字列をシーケンスの後尾に追加します.<br>
	 * <br>
	 * 指定されたスクリプト文字列にバインド変数{@value this#ATTRIBUTE_BIND_PARAMETER}を含む場合、
	 * それに対応するバインドパラメータを指定してください。<br>
	 * バインド変数とバインドパラメータ配列の数は一致させてください。<br>
	 * <br>
	 * 注意：バインドパラメータ配列として引数にnullを1つ指定した場合、
	 * nullを含むサイズが1のバインドパラメータ配列を指定したものとして、
	 * バインドパラメータ配列にnullが追加されますので、注意してください。<br>
	 * 
	 * @create 2008/07/18
	 * @param javaScriptStr スクリプト文字列
	 * @param parameters バインドパラメータ配列
	 * @return このオブジェクトへの参照
	 * @author okajima
	 * @since 3.5.0
	 */
	public GJavaScriptBuilder append(String javaScriptStr, String... parameters) {

		if (javaScriptStr != null) {
			javaScriptStrBuilder.append(javaScriptStr);

			if (parameters != null) {
				this.bindParameters.addAll(Arrays.asList(parameters));
			} else {
				this.bindParameters.add(null);
			}
		}

		return this;
	}

	/**
	 * 指定されたスクリプト文字列をシーケンスの先頭に挿入します.<br>
	 * <br>
	 * バインド変数{@value this#ATTRIBUTE_BIND_PARAMETER}は含めないでください。<br>
	 * バインド変数を含む場合は、{@link this#insert(String, String...)}を使用してください。
	 * 
	 * @create 2008/07/18
	 * @param javaScriptStr スクリプト文字列
	 * @return このオブジェクトへの参照
	 * @author okajima
	 * @since 3.5.0
	 */
	public GJavaScriptBuilder prepend(String javaScriptStr) {

		if (javaScriptStr != null) {
			javaScriptStrBuilder.insert(0, javaScriptStr);
		}

		return this;
	}

	/**
	 * 指定されたスクリプト文字列をシーケンスの先頭に挿入します.<br>
	 * <br>
	 * 指定されたスクリプト文字列にバインド変数{@value this#ATTRIBUTE_BIND_PARAMETER}を含む場合、
	 * それに対応するバインドパラメータを指定してください。<br>
	 * バインド変数とバインドパラメータ配列の数は一致させてください。<br>
	 * <br>
	 * 注意：バインドパラメータ配列として引数にnullを1つ指定した場合、
	 * nullを含むサイズが1のバインドパラメータ配列を指定したものとして、
	 * バインドパラメータ配列にnullが追加されますので、注意してください。<br>
	 * 
	 * @create 2008/07/18
	 * @param javaScriptStr スクリプト文字列
	 * @param parameters バインドパラメータ配列
	 * @return このオブジェクトへの参照
	 * @author okajima
	 * @since 3.5.0
	 */
	public GJavaScriptBuilder prepend(String javaScriptStr, String... parameters) {

		if (javaScriptStr != null) {
			javaScriptStrBuilder.insert(0, javaScriptStr);
			if (parameters != null) {
				this.bindParameters.addAll(0, Arrays.asList(parameters));
			} else {
				this.bindParameters.add(0, null);
			}
		}

		return this;
	}

	/**
	 * 保持しているバインドパラメータバッファを取得します.
	 * 
	 * @create 2008/07/18
	 * @return バインドパラメータバッファ
	 * @author okajima
	 * @since 3.5.0
	 */
	public List<String> getBindParameters() {
		return bindParameters;
	}

	/**
	 * 保持しているスクリプト文字列バッファを取得します.
	 * 
	 * @create 2008/07/18
	 * @return スクリプト文字列バッファ
	 * @author okajima
	 * @since 3.5.0
	 */
	public String getJavaScriptBuffer() {
		return javaScriptStrBuilder.toString();
	}

	/**
	 * バインド変数"??"をバインドパラメータの値にバインドした
	 * スクリプト文字列を返します。<br>
	 * その際、各バインドパラメータの文字列はJavaScriptの文字列定数とみなし、
	 * JavaScriptエスケープ処理を行った上でシングルクオート"'"を前後に付加します。<br>
	 * <br>
	 * バインド変数の順番とパラメータの順番は対応しています。<br>
	 * <br>
	 * バインド変数とバインドパラメータの数は対応させてください。<br>
	 * バインド変数の数＞バインドパラメータの数の場合、
	 * 余ったバインド変数は"??"のまま出力されます。<br>
	 * バインド変数の数＜バインドパラメータの数の場合、
	 * 余ったバインドパラメータは無視されます。<br>
	 * 
	 * @create 2008/07/18
	 * @return バインド処理後のスクリプト文字列
	 * @author okajima
	 * @since 3.5.0
	 */
	public String toString() {

		int fromIndex = 0;

		for (String parameter : bindParameters) {

			int bindStartIndex = javaScriptStrBuilder.indexOf(ATTRIBUTE_BIND_PARAMETER, fromIndex);

			if (bindStartIndex == -1) {
				break;
			} else {

				int bindEndIndex = bindStartIndex + ATTRIBUTE_BIND_PARAMETER.length();
				String escapedParameter = GTagUtils.escapeJavaScriptString(GStringUtils.nullToBlank(parameter));

				javaScriptStrBuilder.replace(bindStartIndex, bindEndIndex, "'" + escapedParameter + "'");

				fromIndex = bindStartIndex + escapedParameter.length();
			}
		}

		return javaScriptStrBuilder.toString();
	}
	
	/**
	 * このオブジェクトを複製します.<br />
	 * 
	 * @create 2017/06/05
	 * @return 複製したGJavaScriptBuilderオブジェクト
	 * @author kikuchi
	 * @since 3.20.0
	 */
	@Override
	public Object clone() {
		GJavaScriptBuilder clone = (GJavaScriptBuilder) getInstance();
		
		StringBuilder cloneBuilder = new StringBuilder(this.javaScriptStrBuilder.toString());
		clone.setJavaScriptStrBuilder(cloneBuilder);
		List<String> cloneBindParam = new ArrayList<String>();
		cloneBindParam.addAll(this.bindParameters);
		clone.setBindParameters(cloneBindParam);
		
		return clone;
	}
	
	/**
	 * インスタンスを生成します.<br />
	 * 
	 * @create 2017/06/05
	 * @return GJavaScriptBuilder
	 * @author kikuchi
	 * @since 3.20.0
	 */
	protected GJavaScriptBuilder getInstance() {
		return new GJavaScriptBuilder();
	}
	
	/**
	 * バインド変数を含むスクリプト文字列バッファを設定します.<br />
	 * 
	 * @create 2017/06/05
	 * @param javaScriptStrBuilder バインド変数を含むスクリプト文字列バッファ
	 * @author kikuchi
	 * @since 3.20.0
	 */
	private void setJavaScriptStrBuilder(StringBuilder javaScriptStrBuilder) {
		this.javaScriptStrBuilder = javaScriptStrBuilder;
	}
	
	/**
	 * バインドパラメータバッファを設定します.<br />
	 * 
	 * @create 2017/06/05
	 * @param List<String> バインドパラメータバッファ
	 * @author kikuchi
	 * @since 3.20.0
	 */
	private void setBindParameters(List<String> bindParameters) {
		this.bindParameters = bindParameters;
	}
}
