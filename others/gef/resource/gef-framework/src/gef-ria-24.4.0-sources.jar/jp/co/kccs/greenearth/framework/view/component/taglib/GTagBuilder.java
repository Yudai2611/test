/*
 * Copyright 2007-2008 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * XHTMLを形成するタグを生成するクラスです.
 * 
 * @create 2006/10/11
 * @author kitamura
 * @since 3.0.0
 */
public class GTagBuilder {

	/** 属性値のバインド変数値 */
	private static final String ATTRIBUTE_BIND_PARAMETER = "??";

	/** タグ名称. **/
	private String _name = null;
	/** 属性. **/
	private Map<String, String> _attributes = null;
	/** 内部テキスト. */
	private String _innerText = null;

	// ----- コンストラクタ ----------------------------------------------------------
	/**
	 * {@link GTagBuilder}の新しいインスタンスを初期化します.
	 * 
	 * @create 2006/10/11
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GTagBuilder() {
	}

	/**
	 * タグ名を指定して、{@link GTagBuilder}の新しいインスタンスを初期化します.
	 * 
	 * @create 2006/10/11
	 * @param name タグ名
	 * @author kitamura
	 * @since 3.0.0
	 */
	public GTagBuilder(String name) {
		setName(name);
	}

	// ----- パブリックメソッド ----------------------------------------------------------

	/**
	 * 要素の終了を表現した文字列表現を取得します.
	 * 
	 * @create 2006/10/11
	 * @return 要素の終了の文字列表現
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String createEndTagString() {
		String xml = "";

		String name = getName();
		if (name != null) {
			xml = "</" + name + ">";
		}

		return xml;
	}

	/**
	 * 開始-終了要素の文字列表現を取得します.<br>
	 * 内部テキストがnullの場合であっても、常に開始-終了要素の文字列を取得します。
	 * 内部テキストはエスケープ文字列に変換して取得します。
	 * 
	 * @create 2007/04/16
	 * @return 要素を表現した文字列
	 * @author wadatani
	 * @since 3.0.0
	 */
	public String createStartEndTagString() {
		return createStartEndTagString(true);
	}

	/**
	 * 開始-終了要素の文字列表現を取得します.<br>
	 * 内部テキストがnullの場合であっても、常に開始-終了要素の文字列を取得します。
	 * フラグによって、内部テキストのエスケープを決定します。
	 * 
	 * @create 2007/03/17
	 * @param escFlg 内部テキストをエスケープするかのフラグ
	 * @return 要素を表現した文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	public String createStartEndTagString(boolean escFlg) {
		StringBuilder xml = new StringBuilder();

		String name = getName();
		if (name != null) {
			xml.append(createStartTagString());

			if (getInnerText() != null) {
				if (escFlg) {
					xml.append(GTagUtils.escapeTextContent(getInnerText()));
				} else {
					xml.append(getInnerText());
				}
			}

			xml.append(createEndTagString());
		}

		return xml.toString();
	}

	/**
	 * 開始要素の開始部分の文字列表現を取得します.<br>
	 * 属性の値が<code>null</code>の場合、属性を作りません。
	 * 
	 * @create 2006/10/11
	 * @return 開始要素の開始部分の文字列表現
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String createStartTagString() {
		StringBuilder xml = new StringBuilder();

		String name = getName();
		if (name != null) {
			xml.append("<");
			xml.append(name);

			if (_attributes != null) {
				Set<String> keySet = _attributes.keySet();
				for (String key : keySet) {
					String value = _attributes.get(key);
					if (value != null) {
						xml.append(" ");
						xml.append(key);
						xml.append("=\"");
						xml.append(GTagUtils.escapeXMLAttribute(value));
						xml.append("\"");
					}
				}
			}

			xml.append(">");
		}

		return xml.toString();
	}

	/**
	 * 開始-終了要素の文字列表現を取得します.<br>
	 * 内部テキストがnullの場合、開始要素の文字列のみを取得します。<br>
	 * ※常に開始-終了要素の文字列を取得する場合、{@link #createStartEndTagString()}を使用してください。
	 * 内部テキストはエスケープ文字列に変換して取得します。
	 * 
	 * @create 2007/04/16
	 * @return 要素を表現した文字列
	 * @author wadatani
	 * @since 3.0.0
	 */
	public String createTagString() {
		return createTagString(true);
	}

	/**
	 * 開始-終了要素の文字列表現を取得します.<br>
	 * 内部テキストがnullの場合、開始要素の文字列のみを取得します。<br>
	 * ※常に開始-終了要素の文字列を取得する場合、{@link #createStartEndTagString()}を使用してください。
	 * フラグによって、内部テキストのエスケープを決定します。
	 * 
	 * @create 2006/10/11
	 * @param escFlg 内部テキストをエスケープするかのフラグ
	 * @return 要素を表現した文字列
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String createTagString(boolean escFlg) {
		StringBuilder xml = new StringBuilder();

		String name = getName();
		if (name != null) {
			xml.append(createStartTagString());

			if (getInnerText() != null) {
				if (escFlg) {
					xml.append(GTagUtils.escapeTextContent(getInnerText()));
				} else {
					xml.append(getInnerText());
				}
				xml.append(createEndTagString());
			} else {
				xml.replace(xml.length() - 1, xml.length(), " />");
			}
		}

		return xml.toString();
	}

	/**
	 * マップから指定キーの属性を削除します.
	 * 
	 * @create 2007/02/08
	 * @param key キー
	 * @author shimano
	 * @since 3.0.0
	 */
	public void removeAttribute(String key) {
		_attributes.remove(key);
	}

	// ----- パブリックプロパティ ------------------------------------------------------

	/**
	 * 属性マップを戻します.<BR>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。
	 * 
	 * @create 2006/10/11
	 * @return 属性マップ
	 * @author kitamura
	 * @since 3.0.0
	 */
	public Map<String, String> getAttributes() {
		return _attributes;
	}

	/**
	 * 内部テキストを取得します.<br>
	 * TextContent用にエスケープされています。<br>
	 * 
	 * @create 2006/10/11
	 * @return 内部テキスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getInnerText() {
		return _innerText;
	}

	/**
	 * タグの名称を戻します.
	 * 
	 * @create 2006/10/11
	 * @return タグの名称
	 * @author kitamura
	 * @since 3.0.0
	 */
	public String getName() {
		return _name;
	}

	/**
	 * タグに属性を追加します.<BR>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。
	 * 
	 * @create 2006/10/11
	 * @param key 属性名
	 * @param value 属性値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setAttribute(String key, boolean value) {
		setAttribute(key, String.valueOf(value));
	}

	/**
	 * タグに属性を追加します.<BR>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。<BR>
	 * valueにnullを指定した場合は、Attributeとして追加されず、無視されます。
	 * 
	 * @create 2006/10/11
	 * @param key 属性名
	 * @param value 属性値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setAttribute(String key, String value) {
		// valueがnullの場合は無視する
		if (value != null) {
			if (_attributes == null) {
				_attributes = new HashMap<String, String>();
			}

			_attributes.put(key, value);
		}
	}

	/**
	 * タグに属性を追加します.<BR>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。<BR>
	 * valueにnullを指定した場合は、defaultValueに指定した値が属性値として指定されます。
	 * 
	 * @create 2006/10/11
	 * @param key 属性名
	 * @param value 属性値
	 * @param defaultValue デフォルト値
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setAttribute(String key, String value, String defaultValue) {
		if (value == null) {
			setAttribute(key, defaultValue);
		} else {
			setAttribute(key, value);
		}
	}

	/**
	 * 内部テキストを設定します.<br>
	 * 設定した時点で、自動的にTextContent用にエスケープします。<br>
	 * 
	 * @create 2006/10/11
	 * @param text 内部テキスト
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setInnerText(String text) {
		_innerText = text;
	}

	/**
	 * タグに属性を追加します.<BR>
	 * バインド属性値にバインド変数"??"が含まれている場合、
	 * バインドパラメータ配列の文字列に置き換えます。<br>
	 * その際、各パラメータの文字列はjavascript文字列とみなし、
	 * javascriptエスケープ処理を行った上でシングルクオート"'"を前後に付加します。<br>
	 * <br>
	 * バインド変数の順番とパラメータの順番は対応しています。<br>
	 * 
	 * バインド変数とバインドパラメータの数は対応させてください。<br>
	 * バインド変数の数＞バインドパラメータの数の場合、
	 * 余ったバインド変数は"??"のまま出力されます。<br>
	 * バインド変数の数＜バインドパラメータの数の場合、
	 * 余ったバインドパラメータは無視されます。<br>
	 * 
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。<BR>
	 * valueにnullを指定した場合は、Attributeとして追加されず、無視されます。<BR>
	 * 
	 * @create 2008/07/08
	 * @param key 属性名
	 * @param bindValue バインド属性値
	 * @param parameters バインドパラメータ配列
	 * @author okajima
	 * @since 3.5.0
	 */
	public void setJSAttribute(String key, String bindValue, String... parameters) {

		if (bindValue != null) {
			String value = bindJSParameter(bindValue, parameters);

			setAttribute(key, value);
		}
	}

	/**
	 * 内部テキストを設定します.<br>
	 * バインド内部テキストにバインド変数"??"が含まれている場合、
	 * バインドパラメータ配列の文字列に置き換えます。<br>
	 * その際、各パラメータの文字列はjavascript文字列とみなし、
	 * javascriptエスケープ処理を行った上でシングルクオート"'"を前後に付加します。<br>
	 * <br>
	 * バインド変数の順番とパラメータの順番は対応しています。<br>
	 * 
	 * バインド変数とバインドパラメータの数は対応させてください。<br>
	 * バインド変数の数＞バインドパラメータの数の場合、
	 * 余ったバインド変数は"??"のまま出力されます。<br>
	 * バインド変数の数＜バインドパラメータの数の場合、
	 * 余ったバインドパラメータは無視されます。<br>
	 * 
	 * @create 2008/07/14
	 * @param bindText バインド内部テキスト
	 * @param parameters バインドパラメータ配列
	 * @author okajima
	 * @since 3.5.0
	 */
	public void setJSInnerText(String bindText, String... parameters) {

		if (bindText == null) {
			_innerText = null;
		} else {
			_innerText = bindJSParameter(bindText, parameters);
		}
	}

	/**
	 * タグに名称を設定します.
	 * 
	 * @create 2006/10/11
	 * @param name タグ名称
	 * @author kitamura
	 * @since 3.0.0
	 */
	public void setName(String name) {
		_name = name;
	}

	// ---- プライベートメソッド ---------------------------------------------

	/**
	 * バインド値にバインド変数"??"が含まれている場合、
	 * バインドパラメータ配列の文字列に置き換えます。<br>
	 * その際、各パラメータの文字列はjavascript文字列とみなし、
	 * javascriptエスケープ処理を行った上でシングルクオート"'"を前後に付加します。<br>
	 * <br>
	 * バインド変数の順番とパラメータの順番は対応しています。<br>
	 * 
	 * バインド変数とバインドパラメータの数は対応させてください。<br>
	 * バインド変数の数＞バインドパラメータの数の場合、
	 * 余ったバインド変数は"??"のまま出力されます。<br>
	 * バインド変数の数＜バインドパラメータの数の場合、
	 * 余ったバインドパラメータは無視されます。<br>
	 * 
	 * @create 2008/07/14
	 * @param bindValue バインド値
	 * @param parameters バインドパラメータ配列
	 * @return バインド処理後の文字列
	 * @author okajima
	 * @since 3.5.0
	 */
	private String bindJSParameter(String bindValue, String... parameters) {

		StringBuilder value = new StringBuilder(bindValue);
		int fromIndex = 0;

		for (String parameter : parameters) {

			int bindStartIndex = value.indexOf(ATTRIBUTE_BIND_PARAMETER, fromIndex);

			if (bindStartIndex == -1) {
				break;
			} else {

				int bindEndIndex = bindStartIndex + ATTRIBUTE_BIND_PARAMETER.length();
				String escapedParameter = GTagUtils.escapeJavaScriptString(GStringUtils.nullToBlank(parameter));

				value.replace(bindStartIndex, bindEndIndex, "'" + escapedParameter + "'");

				fromIndex = bindStartIndex + escapedParameter.length();
			}
		}

		return value.toString();
	}
}
