/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import java.io.IOException;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.PageContext;

/**
 * カスタムタグ用のユーティリティクラスです.<br>
 * TODO [07/03/14][aono]DOM要素の属性値を取得した際、以下の特殊記号が正しく取得できない問題があります。{@link #escapeJavaScriptString(String)}参照
 * 
 * @create 2007/02/02
 * @author kitamura
 * @since 3.0.0
 */
public final class GTagUtils {

	/**
	 * Don't let anyone instantiate this class.
	 * 
	 * @create 2006/07/29
	 * @author kitamura
	 * @since 1.0.0
	 */
	private GTagUtils() {
	}

	/**
	 * <code>JavaScript</code>の文字列変数値として出力する文字列をエスケープします.<br>
	 * [1]次の変換を行います。<br>
	 * [1-1]バックスペース　　<code>'\b'</code> -> <code>"\\b"</code><br>
	 * [1-2]水平タブ　　　　　<code>'\t'</code> -> <code>"\\t"</code><br>
	 * [1-3]改行　　　　　　　<code>'\n'</code> -> <code>"\\n"</code><br>
	 * [1-4]改ページ　　　　　<code>'\f'</code> -> <code>"\\f"</code><br>
	 * [1-5]復帰　　　　　　　<code>'\r'</code> -> <code>"\\r"</code><br>
	 * [1-6]二重引用符　　　　<code>'\"'</code> -> <code>"\\""</code><br>
	 * [1-7]一重引用符　　　　<code>'\''</code> -> <code>"\\'"</code><br>
	 * [1-8]\記号　　　　　　&nbsp;<code>"\\"</code>&nbsp; -> <code>"\\\\"</code><br>
	 * 注意1：<code>null</code>はJavaScript出力時にnullと表示する必要があるので、そのまま<code>null</code>を返します。<br>
	 * 注意2：JSP内の要素の属性に以下のエスケープシーケンスを記述した場合、DOMは空文字に置換してしまいます。<br>
	 * <code>&amp;#xxx;</code>の形式で文字コードを指定する事で回避する事が可能です。<br>
	 * [1]"\b":"&amp;#8;"で代替可能<br>
	 * [2]"\t":"&amp;#9;"で代替可能<br>
	 * [3]"\n":"&amp;#10;"で代替可能<br>
	 * [4]"\v":"&amp;#11;"で代替可能<br>
	 * [5]"\f":"&amp;#12;"で代替可能<br>
	 * [6]"\r":"&amp;#13;"で代替可能<br>
	 * 
	 * @create 2007/03/13
	 * @param str 変換対象文字列
	 * @return エスケープ済み文字列
	 * @author aono
	 * @since 3.0.0
	 */
	public static String escapeJavaScriptString(String str) {
		// nullはJavaScript中に出力する際にnullという文字列で返さないといけないので、そのまま返却
		if (str == null) {
			return null;
		}

		StringBuilder builder = new StringBuilder();

		// 一文字ずつ評価、置換
		for (int i = 0; i < str.length(); i++) {
			switch (str.charAt(i)) {
				// エスケープ文字の置換
				case '\b' :
					builder.append("\\b");
					break;
				case '\t' :
					builder.append("\\t");
					break;
				case '\n' :
					builder.append("\\n");
					break;
				case '\f' :
					builder.append("\\f");
					break;
				case '\r' :
					builder.append("\\r");
					break;
				case '\"' :
					builder.append("\\\"");
					break;
				case '\'' :
					builder.append("\\'");
					break;
				case '\\' :
					builder.append("\\\\");
					break;
				case '<' :
					builder.append("\\x3c");
					break;
				case '>' :
					builder.append("\\x3e");
					break;
				// 非エスケープ文字の置換
				default :
					builder.append(str.charAt(i));
					break;
			}
		}

		return builder.toString();
	}

	/**
	 * <code>XML</code>(<code>XHTML</code>)のテキスト要素として出力する文字列をエスケープします.<br>
	 * [1]次の変換を行います。<br>
	 * [1-1]<code>'&lt;'</code> -> <code>"&amp;lt;"</code><br>
	 * [1-2]<code>'&gt;'</code> -> <code>"&amp;gt;"</code><br>
	 * [1-3]<code>'&amp;'</code> -> <code>"&amp;amp;"</code><br>
	 * [1-4]<code>'\"'</code> -> <code>"&amp;quot;"</code><br>
	 * [1-5]<code>'\''</code> -> <code>"&amp;#39;"</code><br>
	 * [1-6]<code>' '</code> -> <code>"&amp;nbsp;"</code><br>
	 * 注意：<code>null</code>はJavaScript出力時にnullと表示する必要があるので、そのまま<code>null</code>を返します。<br>
	 * 
	 * @create 2007/03/13
	 * @param str 変換対象文字列
	 * @return エスケープ済み文字列
	 * @author aono
	 * @since 3.0.0
	 */
	public static String escapeTextContent(String str) {
		return escapeXMLValue(str);
	}

	/**
	 * <code>XML</code>(<code>XHTML</code>)の属性として出力する文字列をエスケープします.<br>
	 * [1]次の変換を行います。<br>
	 * [1-1]<code>'&lt;'</code> -> <code>"&amp;lt;"</code><br>
	 * [1-2]<code>'&gt;'</code> -> <code>"&amp;gt;"</code><br>
	 * [1-3]<code>'&amp;'</code> -> <code>"&amp;amp;"</code><br>
	 * [1-4]<code>'"'</code> -> <code>"&amp;quot;"</code><br>
	 * [1-5]<code>'''</code> -> <code>"&amp;#39;"</code><br>
	 * 注意：<code>null</code>は属性の出力可否の判断に使用する場合があるので、そのまま<code>null</code>を返します。<br>
	 * 
	 * @create 2007/03/13
	 * @param str 変換対象文字列
	 * @return エスケープ済み文字列
	 * @author aono
	 * @since 3.0.0
	 */
	public static String escapeXMLAttribute(String str) {
		return escapeXMLValue(str);
	}
	
	/**
	 * <code>XML</code>(<code>XHTML</code>)の値として出力する文字列をエスケープします.<br>
	 * [1]次の変換を行います。<br>
	 * [1-1]<code>'&lt;'</code> -> <code>"&amp;lt;"</code><br>
	 * [1-2]<code>'&gt;'</code> -> <code>"&amp;gt;"</code><br>
	 * [1-3]<code>'&amp;'</code> -> <code>"&amp;amp;"</code><br>
	 * [1-4]<code>'"'</code> -> <code>"&amp;quot;"</code><br>
	 * [1-5]<code>'''</code> -> <code>"&amp;#39;"</code><br>
	 * 注意：<code>null</code>は属性の出力可否の判断に使用する場合があるので、そのまま<code>null</code>を返します。<br>
	 * 
	 * @create 2013/08/30
	 * @param str 変換対象文字列
	 * @return エスケープ済み文字列
	 * @author kikuchi
	 * @since 3.12.0
	 */
	protected static String escapeXMLValue(String str) {
		// nullはJavaScript中に出力する際にnullという文字列で返さないといけないので、そのまま返却
		if (str == null) {
			return null;
		}

		StringBuilder builder = new StringBuilder();

		// 一文字ずつ評価、置換
		for (int i = 0; i < str.length(); i++) {
			switch (str.charAt(i)) {
				// エスケープ文字の置換
				case '<' :
					builder.append("&lt;");
					break;
				case '>' :
					builder.append("&gt;");
					break;
				case '&' :
					builder.append("&amp;");
					break;
				case '\"' :
					builder.append("&quot;");
					break;
				case '\'' :
					builder.append("&#39;");
					break;
				// 非エスケープ文字の置換
				default :
					builder.append(str.charAt(i));
					break;
			}
		}

		return builder.toString();
	}

	/**
	 * 指定されたHTML文字列を{@link jakarta.servlet.jsp.PageContext PageContext}に書き込みます.
	 * 
	 * @create 2006/04/04
	 * @param pageContext コンテキスト
	 * @param html HTML文字列
	 * @throws JspException 書き込みに失敗した場合
	 * @author kitamura
	 * @since 3.0.0
	 */
	public static void printOut(PageContext pageContext, String html) throws JspException {
		try {
			pageContext.getOut().print(html);
		}
		catch (IOException e) {
			throw new JspException("Tag output error.", e);
		}
	}
}
