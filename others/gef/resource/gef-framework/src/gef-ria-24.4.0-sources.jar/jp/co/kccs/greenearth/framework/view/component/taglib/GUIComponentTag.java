/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import jakarta.servlet.jsp.tagext.IterationTag;

import jp.co.kccs.greenearth.framework.view.component.GUIComponent;

/**
 * GreenEARTH ThinClient FrameworkのUIコンポーネントのXHTMLコードレンダリング用カスタムタグを表します.<br>
 * {@link GUIComponent}のXHTMLコードレンダリングタグです。
 * 全てのUIコンポーネントのXHTMLレンダリング用カスタムタグは、この{@link GUIComponentTag}を実装する必要があります。<br>
 * <br>
 * 関連づくUIコンポーネントの情報を読み込むための{@link #load(GUIComponent)}メソッドを実装する必要があります。
 * 
 * @create 2006/12/26
 * @author kitamura
 * @since 3.0.0
 */
public interface GUIComponentTag extends IterationTag {

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.
	 * 
	 * @create 2006/12/26
	 * @param component レンダリング対象UIコンポーネント
	 * @author kitamura
	 * @since 3.0.0
	 */
	void load(GUIComponent component);

	/**
	 * タグの状態をリセット(初期化)します.
	 * ※タグのプーリング機能が有効な場合の状態の解放手段です。
	 *   doEndTagで呼び出してください。
	 * 
	 * @create 2006/12/26
	 * @author kitamura
	 * @since 3.0.0
	 */
	void reset();
}
