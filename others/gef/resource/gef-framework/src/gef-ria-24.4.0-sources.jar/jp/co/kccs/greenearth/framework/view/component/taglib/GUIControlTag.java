/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

/**
 * {@link GUIControl}のレンダリング用カスタムタグを表します.
 * 
 * @create 2006/12/26
 * @author kitamura
 * @since 3.0.0
 */
public interface GUIControlTag extends GUIComponentTag {

	/**
	 * コントロールのIDを取得します.
	 * 
	 * @create 2007/01/23
	 * @return ID
	 * @author wadatani
	 * @since 3.0.0
	 */
	String getId();

	/**
	 * 接頭辞文字列を取得します.
	 * 
	 * @create 2007/03/20
	 * @return 接頭辞文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	String getPrefix();

	/**
	 * コントロールのIDを設定します.
	 * 
	 * @create 2007/01/23
	 * @param id ID
	 * @author wadatani
	 * @since 3.0.0
	 */
	void setId(String id);

	/**
	 * 接頭辞文字列を設定します.
	 * 
	 * @create 2007/03/20
	 * @param prefix 接頭辞文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	void setPrefix(String prefix);
}
