/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;


/**
 * {@link jp.co.kccs.greenearth.framework.view.component.GUIItem}のレンダリング用カスタムタグを表します.
 * 
 * @create 2006/12/26
 * @author kitamura
 * @since 3.0.0
 */
public interface GUIItemTag extends GUIComponentTag {
}
