/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import jakarta.servlet.jsp.tagext.TagSupport;

import jp.co.kccs.greenearth.framework.view.component.TargetUIComponent;
import jp.co.kccs.greenearth.framework.view.validator.GValidator;

/**
 * 検証要素のクラスです.<br>
 * <br>
 * 【概要】<br>
 * 入力フィールドの子要素として記述することで、画面遷移時に親要素の入力値検証を行います。<br>
 * {@link GValidateTag}はXHTMLを出力しません。<br>
 * <br>
 * ex)<br>
 * [JSP]<br>
 * <code>
 * &lt;gp:text id="ItemCD_Condition" required="true" &gt;<br>
 * 　&lt;gp:validate validator="jp.co.kccs.greenearth.framework.view.validator.GMaxLengthValidator" args="10"/&gt;<br>
 * &lt;/gp:text&gt;<br>
 * </code>
 * [XHTMLへの出力結果]<br>
 * &lt;input type="text" name="ItemCD_Condition" id="ItemCD_Condition" /&gt;<br>
 * <br>
 * 
 * 【詳細】<br>
 * 1.{@link GValidateTag}では、入力値の検証対象と検証方法を指定する方法を指定します。<br>
 * <br>
 * 2.検証対象は親要素になります。<br>
 * <br>
 * 3.検証方法は<code>validator</code>属性で指定したクラスによって変更します。<br>
 * ・入力フィールドのタグの子要素には、複数の{@link GValidateTag}を設定することができます。<br>
 * 
 * <br><br>
 * 【注意事項】<br>
 * 1.なし。
 * <br>
 * <br>
 * <!-- ValidateTag -->
 * <table border="1" cellpadding="3" cellspacing="0" width="100%">
 * <tr bgcolor="#CCCCFF"><td colspan="4"><B><code>GValidateTag</code>の属性一覧</B></td></tr>
 * <tr bgcolor="#CCCCFF"><td rowspan="2">[属性]		</td><td>[許可値]			</td><td width="10%">[タイプ]	</td><td>[備考]	</td></tr>
 * <tr bgcolor="#CCCCFF"><td>[通常値]				</td><td colspan="2">[意味]	
 * <tr><td rowspan="2">args				</td><td>-			</td><td>拡張	</td><td>-							</td></tr>
 * <tr><td>-		</td><td colspan="2">検証クラスに渡すパラメータです。パラメータの内容は、指定する検証クラスによって異なります。	</td></tr>
 * <tr><td rowspan="2">errorcode		</td><td>-			</td><td>拡張	</td><td>エラー情報に設定されます。	</td></tr>
 * <tr><td>-		</td><td colspan="2">検証において検出したエラーのエラーコードを指定します。			</td></tr>
 * <tr><td rowspan="2">level			</td><td>info/warning/error		</td><td>拡張	</td><td>
 * info:インフォメーションを発生します。<br>
 * warning:ワーニングを発生します。<br>
 * error:エラーを発生します。<br>		</td></tr>
 * <tr><td>-		</td><td colspan="2">検証において検出したエラーのエラー出力区分を指定します。<br>
 * デフォルト値は各validatorクラスで定義されます。		</td></tr>
 * <tr><td rowspan="2">stop				</td><td>true/false			</td><td>拡張	</td><td>-							</td></tr>
 * <tr><td>true		</td><td colspan="2">検証エラー発生時、後の検証の継続を指定します。		</td></tr>
 * <tr><td rowspan="2">validator		</td><td>-			</td><td>拡張	</td><td>-						</td></tr>
 * <tr><td>(必須)	</td><td colspan="2">検証に使用するクラスの完全修飾クラス名を指定します。	</td></tr>
 * </table>
 * 
 * @create 2007/02/05
 * @author kitamura
 * @since 3.0.0
 */
@TargetUIComponent(GValidator.class)
public class GValidateTag extends TagSupport {

	// ----- 定数 -----------------------------------------------
	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = 4586828357848549771L;

	// ----- 変数 -----------------------------------------------
	// 拡張属性
	/** 検証クラス名. */
	private String _validator = null;
	/** 検証用パラメータ. */
	private String _args = null;
	/** エラーコード. */
	private String _errorcode = null;
	/** エラー出力区分. */
	private String _level = null;
	/** 検証処理の継続指定. */
	private boolean _stop;

	/**
	 * {@link GValidateTag}インスタンスを初期化します。
	 * 
	 * @create 2009/08/25
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GValidateTag() {
	}
	
	
	// ---- パブリックプロパティ ---------------------------------------------

	/**
	 * 検証用パラメータを取得する.
	 * 
	 * @create 2007/02/09
	 * @return 検証用パラメータ
	 * @author aono
	 * @since 3.0.0
	 */
	public String getArgs() {
		return _args;
	}

	/**
	 * エラーコードを取得する.
	 * 
	 * @create 2007/02/09
	 * @return エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	public String getErrorcode() {
		return _errorcode;
	}

	/**
	 * 出力エラーレベルを取得する.
	 * 
	 * @create 2007/02/09
	 * @return <code>error</code>/<code>warn</code>
	 * @author aono
	 * @since 3.0.0
	 */
	public String getLevel() {
		return _level;
	}

	/**
	 * 検証クラスの完全修飾クラス名を取得する.
	 * 
	 * @create 2007/02/14
	 * @return 検証クラスの完全修飾クラス名
	 * @author aono
	 * @since 3.0.0
	 */
	public String getValidator() {
		return _validator;
	}

	/**
	 * 検証エラー発生時、後の検証を継続するかを取得します.
	 * 
	 * @create 2007/04/04
	 * @return <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public boolean isStop() {
		return _stop;
	}

	/**
	 * 検証用パラメータを設定する.
	 * 
	 * @create 2007/02/09
	 * @param args 検証用パラメータ
	 * @author aono
	 * @since 3.0.0
	 */
	public void setArgs(String args) {
		this._args = args;
	}

	/**
	 * エラーコードを設定する.
	 * 
	 * @create 2007/02/09
	 * @param errorcode エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	public void setErrorcode(String errorcode) {
		this._errorcode = errorcode;
	}

	/**
	 * 出力エラーレベルを設定する.<br>
	 *  info:<br>
	 *  error:検証で問題がある場合{@link GErrorMessage}を生成<br>
	 *  warn:検証で問題がある場合{@link GValidateWarning}を生成<br>
	 * 
	 * @create 2007/02/09
	 * @param level <code>info</code>/<code>error</code>/<code>warn</code>
	 * @author aono
	 * @since 3.0.0
	 */
	public void setLevel(String level) {
		this._level = level;
	}

	/**
	 * 検証エラー発生時、後の検証を継続するかを指定します.
	 * 
	 * @create 2007/04/04
	 * @param stop <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setStop(boolean stop) {
		this._stop = stop;
	}

	/**
	 * 検証クラスの完全修飾クラス名を設定する.
	 * 
	 * @create 2007/02/14
	 * @param validator 検証クラスの完全修飾クラス名
	 * @author aono
	 * @since 3.0.0
	 */
	public void setValidator(String validator) {
		this._validator = validator;
	}
}
