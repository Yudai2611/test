/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.TagSupport;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.commons.utils.GReflectionUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GUIComponent;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GViewInterface;

/**
 * {@link GViewInterfaceTag}の基底クラスです.<br>
 *
 * @create 2006/02/03
 * @author okajima
 * @since 3.0.0
 */
public abstract class GViewBaseTag extends TagSupport implements GContainerTag, GViewInterfaceTag {

	// ----- 定数 -----------------------------------------------
	/** シリアルバージョン(serialVersionUID). */
	private static final long serialVersionUID = -5798961838693639820L;

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(GViewInterfaceTag.class);

	// ----- 変数 -----------------------------------------------
	// 拡張属性
	/** {@link GViewInterface}オブジェクトを保持するスコープ. */
	private String _scope;

//	/** JSPのタイプ. */
//	private String _type;

	/** 画面に関連づく{@link GViewInterface}オブジェクトの完全修飾クラス名. */
	private String _viewclass;

	// 内部変数
	/** UIコントロール. */
	private List<GUIControl> _controls;

	/** 接頭辞文字列. */
	private String _prefix;

	/** タグに関連付けられたコンポーネント. */
	private GUIComponent _component;

	/**
	 * {@link GViewBaseTag}の新しいインスタンスを初期化します.<br>
	 *
	 * @create 2007/02/03
	 * @author okajima
	 * @since 3.0.0
	 */
	public GViewBaseTag() {
	}

	/**
	 * 終了タグの標準処理.<br>
	 *
	 * @see jakarta.servlet.jsp.tagext.Tag#doEndTag()
	 * @create 2007/02/03
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_PAGE}:JSPページの残りの部分の評価を続けます
	 * @throws JspException タグの書き込みに失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	@Override
	public int doEndTag() throws JspException {
		reset();
		return EVAL_PAGE;
	}

	/**
	 * 開始タグの標準処理.<br>
	 * {@link GViewInterface}を取得し、{@link GResultData}オブジェクトをロードします。<br>
	 *
	 * @see jakarta.servlet.jsp.tagext.Tag#doStartTag()
	 * @create 2007/02/03
	 * @return {@link jakarta.servlet.jsp.tagext.Tag#EVAL_BODY_INCLUDE}:ボディ部を1回だけ処理します/{@link jakarta.servlet.jsp.tagext.Tag#SKIP_BODY}:ボディ部を処理せず、次の処理へスキップします
	 * @throws JspException {@link GViewInterface}の取得・ロード、タグの書き込みに失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	@Override
	public int doStartTag() throws JspException {
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();

		try {
			// GViewを取得します
			GViewInterface view = getView(request);
			// GResultDataの情報をGViewに読み込みます
			loadResultDataToGView(view, request);
			// GViewの情報をタグに読み込みます
			load(view);
		} catch (Exception e) {
			throw new JspException(e);
		}

		return EVAL_BODY_INCLUDE;
	}

	/**
	 * 子タグのUIコントロールのリストから指定されたIDの{@link GUIControl}を取得します.<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GContainerTag#getControl(java.lang.String)
	 * @create 2007/01/14
	 * @param id UIコントロールID
	 * @return {@link GUIControl}オブジェクト
	 * @author okajima
	 * @since 3.0.0
	 */
	public GUIControl getControl(String id) {
		GUIControl control = null;
		for (int i = 0; i < _controls.size(); i++) {
			GUIControl tempcontrol = _controls.get(i);
			if (tempcontrol != null && tempcontrol.getId() != null && tempcontrol.getId().equals(id)) {
				control = tempcontrol;
				break;
			}
		}
		return control;
	}

	/**
	 * 指定されたレンダリング対象UIコンポーネントの情報を読み込みます.<br>
	 * ・scope,type,viewclass,prefix,controls<br>
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#load(jp.co.kccs.greenearth.framework.view.component.GUIComponent)
	 * @create 2007/02/04
	 * @param component レンダリング対象UIコンポーネント
	 * @author okajima
	 * @since 3.0.0
	 */
	public void load(GUIComponent component) {
		GReflectionUtils.copyProperties(component, this);
		
		GViewInterface view = (GViewInterface) component;

		_scope = view.getScope();
//		_type = view.getType();
		_viewclass = view.getViewclass();
		_controls = view.getChildren();
		_prefix = view.getPrefix();
		setAssociatedComponent(component);
	}

	/**
	 * タグの状態をリセット(初期化)します.<br>
	 * ※タグのプーリング機能が有効な場合の状態の解放手段です。
	 *   doEndTag()で呼び出してください。
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIComponentTag#reset()
	 * @create 2007/02/18
	 * @author okajima
	 * @since 3.0.0
	 */
	public void reset() {
	}

	// ---- プロテクテッドメソッド -------------------------------------------------
	/**
	 * {@link GViewInterface}オブジェクトを取得します.
	 *
	 * @create 2007/01/13
	 * @param request HTTPリクエスト
	 * @return {@link GViewInterface}オブジェクト
	 * @throws GViewException ビューの取得に失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	protected abstract GViewInterface getView(HttpServletRequest request) throws GViewException;

	// ---- パッケージメソッド -------------------------------------------------

	/**
	 * このタグが所属するJSPのパスを取得します.<br>
	 * このビューが基底のJSPなら{@link HttpServletRequest#getServletPath()}で取得されるパスを、
	 * このビューが別のJSPにインクルードされたJSPなら<code>request</code>に積まれている
	 * インクルードJSPのパスを取り出し返します。
	 *
	 * @create 2006/12/29
	 * @param request HTTPリクエスト
	 * @return JSPパス
	 * @author okajima
	 * @since 3.0.0
	 */
	protected abstract String getServletPath(HttpServletRequest request);

	/**
	 * {@link GViewInterface}オブジェクトに{@link GResultData}オブジェクトの内容を読み込みます.<br>
	 *
	 * @create 2007/01/13
	 * @param view {@link GViewInterface}オブジェクト
	 * @param request リクエスト
	 * @throws Exception 読み込みに失敗した場合
	 * @author okajima
	 * @since 3.0.0
	 */
	void loadResultDataToGView(GViewInterface view, HttpServletRequest request) throws Exception {
		GResultData resultData = (GResultData) request.getAttribute(GConstants.RESULT_DATA_KEY);
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);

		// セッションの情報を削除し、かつインクルードされているビューにも例外情報を伝えるため
		// セッションからリクエストに例外情報を積みかえる
		String exceptionKey = parameter.getValue(GConstants.EXCEPTION_KEY);
		if (exceptionKey != null) {
			HttpSession session = request.getSession();
			Throwable e = (Throwable) session.getAttribute(exceptionKey);
			if (e != null) {
				pageContext.setAttribute(exceptionKey, e);
				session.removeAttribute(exceptionKey);
			}
		}

		GStopWatch watch = new GStopWatch();
		watch.start();
		view.onLoad(resultData, parameter, pageContext);
		LOGGER.debug("View OnLoad (" + watch.stop() + ") : view=" + view.getViewclass());
	}

	// ---- パブリックプロパティ -------------------------------------------------

	/**
	 * タグに関連付けられたコンポーネントを取得します.
	 *
	 * @create 2011/06/11
	 * @return コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public GUIComponent getAssociatedComponent() {
		return _component;
	}

	/**
	 * 子タグのUIコントロールのリストを取得します.<br>
	 *
	 * @create 2007/01/10
	 * @return 子タグのUIコントロールのマップ
	 * @author okajima
	 * @since 3.0.0
	 */
	public List<GUIControl> getControls() {
		return _controls;
	}

	/**
	 * 画面の項目名として表示するリソースのIDを取得します.
	 *
	 * @create 2007/04/19
	 * @return 表示するリソースのID
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getLabelid() {
		return null;
	}

	/**
	 * 画面の項目名として表示する値を取得します.
	 *
	 * @create 2007/04/19
	 * @return 表示する値
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getLabelvalue() {
		return null;
	}


	/**
	 * 接頭辞文字列を取得します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIControlTag#getPrefix()
	 * @create 2007/03/20
	 * @return 接頭辞文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getPrefix() {
		return _prefix;
	}

	/**
	 * {@link GViewInterface}オブジェクトの値を保持するスコープを取得します.<br>
	 *
	 * @create 2006/12/29
	 * @return <code>application</code>/<code>session</code>/<code>request</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getScope() {
		return _scope;
	}

	/**
	 * 画面に関連づく{@link GViewInterface}オブジェクトの完全修飾クラス名を取得します.<br>
	 *
	 * @create 2006/12/29
	 * @return {@link GViewInterface}クラス名
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getViewclass() {
		return _viewclass;
	}


	/**
	 * タグに関連付けられたコンポーネントを設定します.
	 *
	 * @create 2011/06/11
	 * @param component コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	public void setAssociatedComponent(GUIComponent component) {
		_component = component;
	}

	/**
	 * 子タグのUIコントロールのリストを設定します.<br>
	 *
	 * @create 2007/01/10
	 * @param controls 子タグのUIコントロールのリスト
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setControls(List<GUIControl> controls) {
		_controls = controls;
	}

	/**
	 * 画面の項目名として表示するリソースのIDを設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIControlTag#setLabelid(java.lang.String)
	 * @create 2007/04/19
	 * @param labelid 表示するリソースのID
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setLabelid(String labelid) {
	}

	/**
	 * 画面の項目名として表示する値を設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIControlTag#setLabelvalue(java.lang.String)
	 * @create 2007/04/19
	 * @param labelvalue 表示する値
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setLabelvalue(String labelvalue) {
	}


	/**
	 * 接頭辞文字列を設定します.
	 *
	 * @see jp.co.kccs.greenearth.framework.view.component.taglib.GUIControlTag#setPrefix(java.lang.String)
	 * @create 2007/03/20
	 * @param prefix 接頭辞文字列
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setPrefix(String prefix) {
		_prefix = prefix;
	}

	/**
	 * {@link GViewInterface}オブジェクトの値を保持するスコープを設定します.<br>
	 * <code>application</code>	: アプリケーション単位で値を保持します。<br>
	 * <code>session</code>     : セッション単位で値を保持します。<br>
	 * <code>request</code>	    : リクエスト単位で値を保持します。<br>
	 *
	 * @create 2006/12/29
	 * @param scope <code>application<code>/</code>session</code>/<code>request</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setScope(String scope) {
		_scope = scope;
	}

	/**
	 * 画面に関連づく{@link GViewInterface}オブジェクトの完全修飾クラス名を設定します.<br>
	 *
	 * @create 2006/12/29
	 * @param viewclass {@link GViewInterface}クラス名
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setViewclass(String viewclass) {
		_viewclass = viewclass;
	}
}
