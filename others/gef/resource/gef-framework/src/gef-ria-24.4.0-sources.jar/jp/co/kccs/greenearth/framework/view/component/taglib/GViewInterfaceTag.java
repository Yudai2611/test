/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.component.taglib;

import jp.co.kccs.greenearth.framework.view.component.GUIComponent;


/**
 *  ビューを定義するタグクラスです.<br>
 *
 * @create 2011/07/27
 * @author yamashita
 * @since 3.9.0
 */
public interface GViewInterfaceTag extends GUIControlTag {

	/**
	 * タグに関連付けられたコンポーネントを取得します.
	 *
	 * @create 2011/07/27
	 * @return コンポーネント
	 * @author yamashita
	 * @since 3.9.0
	 */
	GUIComponent getAssociatedComponent();

	/**
	 * 
	 * @create 2011/07/27
	 * @return
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getScope();

	/**
	 * 
	 * @create 2011/07/27
	 * @return
	 * @author yamashita
	 * @since 3.9.0
	 */
	String getViewclass();

	/**
	 * 
	 * 
	 * @create 2011/07/27
	 * @param scope
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setScope(String scope);

	/**
	 * 
	 * 
	 * @create 2011/07/27
	 * @param viewclass
	 * @author yamashita
	 * @since 3.9.0
	 */
	void setViewclass(String viewclass);
}
