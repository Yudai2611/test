/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.menu;

import java.io.IOException;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * ClickOnceを利用して、サーバーサイドに配置された.NETのexeファイルを起動する{@link GMenuStarter}の実装です。
 * {@link GMenu#getStartModule()}にて指定されたexeファイルを起動します。<br>
 * アプリケーションの起動引数に、メニューIDとセッションID(SID)を渡しています。
 * このランチャーを使用するためには、クライアントに.NETがインストールされている必要があります。
 * 
 * @create 2011/07/29
 * @author yamashita
 * @since 3.9.0
 */
public class GClickOnceMenuStarter extends GMenuStarterBase {

	/**
	 * {@link GClickOnceMenuStarter}インスタンスを初期化します。
	 * 
	 * @create 2011/07/29
	 * @auther kyo
	 * @since 3.9.0
	 */
	public GClickOnceMenuStarter() {
	}

	/**
	 * ClickOnceを利用して{@link GMenu#getStartModule()}で指定された.NETのexeファイルを起動します。<br>
	 * {@link GMenu#getStartModule()}にて指定されたファイルにリダイレクトしています。<br>
	 * 戻り値の{@link GResultData}には終了コード{@link GResultData#EXIT_CODE_DIRECT_RESPONSE}が指定されます。<br>
	 * 
	 * @create 2011/07/29
	 * @param menu メニュー
	 * @param resultData 結果データ
	 * @param request リクエスト
	 * @param response レスポンス
	 * @return 結果データ
	 * @throws GLaunchMenuException メニューの起動に失敗した場合
	 * @author kyo
	 * @since 3.9.0
	 */
	public GResultData start(GMenu menu, GResultData resultData, HttpServletRequest request, HttpServletResponse response) throws GLaunchMenuException {
		
		if (menu == null || menu.getStartModule() == null) {
			GErrorMessage message = GErrorMessages.getErrorMessage(ERROR_CODE, GFrameworkContext.getInstance().getLocale());
			throw new NullPointerException(message.getMessage());
		}
		
		if (null == resultData) {
			throw new NullPointerException("ResultData is null.");
		}
		
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session = manager.getSession(request.getSession());
		GUser user = session.getLoginUser();
		checkAuthority(menu, user);

		// 遷移先URL作成
		StringBuilder redirectURL = new StringBuilder();
		redirectURL.append(request.getContextPath());
		redirectURL.append(menu.getStartModule());
		redirectURL.append("?menuid=").append(GStringUtils.nullToBlank(menu.getMenuID()));
		if (!request.isRequestedSessionIdFromCookie()) {
			throw new GLaunchMenuException("Cookie is invalid. Please keep effective.");
		}
		for (Cookie cookie : request.getCookies()) {
			if ("JSESSIONID".equals(cookie.getName())) {
				redirectURL.append("&sid=").append(cookie.getValue());
				break;
			}
		}

		// リダイレクト
		try {
			response.sendRedirect(response.encodeRedirectURL(redirectURL.toString()));
		}
		catch (IOException e) {
			throw new GLaunchMenuException(e);
		}

		resultData.setExitCode(GResultData.EXIT_CODE_DIRECT_RESPONSE);
		return resultData;
	}
}
