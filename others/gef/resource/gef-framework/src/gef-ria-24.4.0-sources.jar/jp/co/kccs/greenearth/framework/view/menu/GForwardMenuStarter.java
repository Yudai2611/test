/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.menu;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;
import jp.co.kccs.greenearth.framework.view.GViewResponseFilter;

/**
 * 任意のリソースにフォワードする事でメニューを起動する{@link GMenuStarter}の実装です。<br>
 * {@link GMenu#getStartModule()}にて指定されたリソースにフォワードします。<br>
 * このランチャー内部ではフォワード処理は行わず、{@link GResultData}に終了コードを{@link GResultData#EXIT_CODE_SUCCESS}
 * を設定して返し、その{@link GResultData}をアクションの戻り値として戻してもらう事で、
 * Thin Client Frameworkのレスポン生成の仕組みを使ってフォワードします。
 * {@link GMenu#getParameter()}に指定されたパラメータは、{@link GParameter}にセットされます。<br>
 * 
 * @create 2011/07/29
 * @author kyo
 * @since 3.9.0
 */
public class GForwardMenuStarter extends GMenuStarterBase {
	
	/**
	 * {@link GForwardMenuStarter}インスタンスを初期化します。
	 * 
	 * @create 2011/07/29
	 * @auther kyo
	 * @since 3.9.0
	 */
	public GForwardMenuStarter() {
	}

	/**
	 * フォワード先に{@link GMenu#getStartModule()}にて指定されたリソースを設定します。<br>
	 * {@link GParameter}の{@link GViewResponseFilter#FORWARD_KEY}キーにメニューのリソースを設定し、
	 * {@link GResultData}の終了コードに{@link GResultData#EXIT_CODE_SUCCESS}を指定します。
	 * 
	 * @create 2009/08/30
	 * @param menu メニュー
	 * @param resultData 結果データ
	 * @param request リクエスト
	 * @param response レスポンス
	 * @return 結果データ
	 * @throws GLaunchMenuException メニューの起動に失敗した場合
	 * @author kyo
	 * @since 3.9.0
	 */
	public GResultData start(GMenu menu, GResultData resultData, HttpServletRequest request, HttpServletResponse response) throws GLaunchMenuException {
		
		// 事前チェック
		if (menu == null || menu.getStartModule() == null) {
			GErrorMessage message = GErrorMessages.getErrorMessage(ERROR_CODE, GFrameworkContext.getInstance().getLocale());
			throw new NullPointerException(message.getMessage());
		}
		
		GParameter parameter = (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);

		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session = manager.getSession(request.getSession());
		GUser user = session.getLoginUser();
		checkAuthority(menu, user);
		

		// パラメータ設定されているキーをパラメーターに積み込み
		parameter = stackParameter(parameter, menu.getParameter());
		// ページ遷移設定
		parameter.setValue(GViewResponseFilter.FORWARD_KEY, menu.getStartModule());
		// 終了コードの指定
		resultData.setExitCode(GResultData.EXIT_CODE_SUCCESS);

		return resultData;
	}
	
	/**
	 * メニューパラメータを分解してパラメータオブジェクトに設定します。
	 * 
	 * @create 2009/08/28
	 * @param parameter パラメータ
	 * @param parameters メニューパラメータ
	 * @return 設定結果パラメータ
	 * @author kyo
	 * @since 3.9.0
	 */
	protected GParameter stackParameter(GParameter parameter, String parameters) {
		// アプリケーションのパラメータを設定
		if (parameters != null) {
			for (String partOfParam : parameters.split("\\&")) {
				String[] splitParam = partOfParam.split("=");

				if (splitParam.length > 0) {
					String key = splitParam[0].trim();
					String value = "";
					if (splitParam.length > 1) {
						value = partOfParam.substring(partOfParam.indexOf('=') + 1);
					}
					parameter.setValue(key, value);
				}
			}
		}
		return parameter;
	}
}
