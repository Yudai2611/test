/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.menu;


/**
 * メニューの起動に失敗した場合の例外を表します。
 * 
 * @create 2009/08/28
 * @author kitamura
 * @since 3.6.0
 */
public class GLaunchMenuException extends Exception {
	
	/** シリアルバージョンID. */
	private static final long serialVersionUID = -4238691122821252726L;

	/**
	 * {@link GLaunchMenuException}のインスタンスを初期化します.
	 * 
	 * @create 2009/08/28
	 * @author kitamura
	 * @since 3.6.0
	 */
	public GLaunchMenuException() {
		super();
	}

	/**
	 * 例外メッセージを指定し、{@link GLaunchMenuException}のインスタンスを初期化します.
	 * 
	 * @create 2009/08/28
	 * @param message メッセージ
	 * @author kitamura
	 * @since 3.6.0
	 */
	public GLaunchMenuException(String message) {
		super(message);
	}

	/**
	 * この例外の発生原因を指定し、{@link GLaunchMenuException}のインスタンスを初期化します.
	 * 
	 * @create 2009/08/28
	 * @param cause 原因となった例外
	 * @author kitamura
	 * @since 3.6.0
	 */
	public GLaunchMenuException(Throwable cause) {
		super(cause);
	}

}
