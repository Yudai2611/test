/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.menu;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.menu.GMenu;

/**	
 * メニューの起動用のランチャーを表すインターフェイスです。<br>
 * 指定された{@link GMenu}が指すアプリケーションを起動します。
 * 
 * @see jp.co.kccs.greenearth.framework.menu.GMenu
 * @create 2011/07/29
 * @author kyo
 * @since 3.9.0
 */
public interface GMenuStarter {

	/**
	 * 指定されたメニューを起動します。<br>
	 * 起動方法は、フォワード、リダイレクト等様々ありますが、各実装に委ねられます。
	 * 
	 * @create 2011/07/29
	 * @param menu 起動対象アプリケーションのメニューアイテム
	 * @param resultData 結果データ
	 * @param request リクエスト
	 * @param response レスポンス
	 * @return 結果データ
	 * @throws GLaunchMenuException アプリケーション画面への遷移に失敗
	 * @author kyo
	 * @since 3.9.0
	 */
	GResultData start(GMenu menu, GResultData resultData, HttpServletRequest request, HttpServletResponse response) throws GLaunchMenuException;

}
	