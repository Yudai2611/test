/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.menu;

import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.authorization.GAuthorizationException;
import jp.co.kccs.greenearth.framework.menu.GMenu;

/**
 * {@link GMenuStarter}を実装する上での基底クラスです。
 * 
 * @create 2011/07/30
 * @author KCCS kyo
 * @since 3.9.0
 */
public abstract class GMenuStarterBase implements GMenuStarter {
	
	/** エラーコード. */
	protected static final String ERROR_CODE = "GEF-001001";
	
	/**権限がない場合のエラーコード*/
	protected static final String AUTHORIZATION_ERROR_CODE = "GEF-001004";
	
	/**
	 * メニューにアクセスする権限があるかチェックします。<br>
	 * 
	 * @param menu メニュー
	 * @param user ユーザー
	 * @create 2010/10/24
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	protected void checkAuthority(GMenu menu, GUser user) {
		boolean hasAuthority;
		if (user == null) {
			hasAuthority = false;
		}
		else {
			hasAuthority = menu.hasAuthority(user);
		}
		
		if (!hasAuthority) {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			GErrorMessage message = GErrorMessages.getErrorMessage(AUTHORIZATION_ERROR_CODE, locale);
			throw new GAuthorizationException(AUTHORIZATION_ERROR_CODE, message.getMessage());
		}		
	}

}
