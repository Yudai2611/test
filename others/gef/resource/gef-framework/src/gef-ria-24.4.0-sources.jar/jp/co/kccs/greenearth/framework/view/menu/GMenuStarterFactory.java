/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.menu;

import java.util.Map;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.menu.GMenu;

/**
 * {@link GMenuStarter}を生成するファクトリです。<br>
 * アプリケーションタイプに応じて{@link GMenuStarter}を用意し、ファクトリに登録しておく事で、
 * 起動対象の{@link て必要な{@link GMenuStarter}を生成します。<br>
 * {@link GMenuStarter}の登録は、DI定義にて行います。<br>
 * <br>
 * <b>[DI定義例]</b><br>
 * <pre>
 * &lt;bean name="jp.co.kccs.greenearth.framework.view.menu.GMenuStarterFactory" class="jp.co.kccs.greenearth.framework.view.menu.GMenuStarterFactory" singleton="true">
 *    &lt;constructor-arg>
 *       &lt;map>
 *          &lt;entry key="6">
 *             &lt;bean class="jp.co.kccs.greenearth.framework.view.menu.GForwardMenuStarter"/>
 *          &lt;/entry>
 *          &lt;entry key="8">
 *             &lt;bean class="jp.co.kccs.greenearth.framework.view.menu.GClickOnceMenuStarter"/>
 *          &lt;/entry>
 *       &lt;/map>
 *    &lt;/constructor-arg>
 * &lt;/bean>
 * </pre>
 * {@link GMenuStarter}の登録は{@link GMenuStarterFactory}に{@link GMenuStarter}のマップをコンストラクタインジェクションする事により行います。<br>
 * マップのキーには、アプリケーションタイプを、値には{@link GMenuStarter}を指定します。<br>
 * 
 * @create 2010/10/20
 * @author kyo
 * @since 3.9.0
 */
public class GMenuStarterFactory {
	/** ランチャーのマップ */
	private Map<String, GMenuStarter> _launchers = null;
	/** ファクトリー. */
	private static GMenuStarterFactory _factory;

	/**
	 * 登録する{@link GMenuStarter}のマップを指定して、{@link GMenuStarterFactory}インスタンスを初期化します。
	 * 
	 * @create 2010/10/20
	 * @param launchers 登録する{@link GMenuStarter}のマップ
	 * @auther kyo
	 * @since 3.9.0
	 */
    public GMenuStarterFactory(Map<String, GMenuStarter> launchers) {
        _launchers = launchers;
    }

    /**
     * 指定した{@link GMenu}が指すアプリケーションタイプに該当する{@link GMenuStarter}を取得します。
     * 
     * @create 2010/10/20
     * @param menu メニュー
     * @return {@link GMenu}を起動するための{@link GMenuStarter}
     * @author kyo
     * @since 3.9.0
     */
    
    public static GMenuStarter getMenuExecuter(GMenu menu) {
    	if (_factory == null) {
    		_factory = GFrameworkUtils.getComponent(GMenuStarterFactory.class.getName());
    	}
        if (_factory._launchers.containsKey(menu.getApplicationType())) {
            return _factory._launchers.get(menu.getApplicationType());
        }
        return null;
    }
    

    
}
