/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.menu;

import java.io.IOException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * 指定されたリソースにリダイレクトする事でメニューを起動する{@link GMenuStarter}の実装です。<br>
 * 主に外部ドメインや外部サーバーのアプリケーションへ遷移する場合に使用します。<br>
 * リダイレクト先はhttpまたはhttpsプロトコルでのアクセスに限定されます。<br>
 * 
 * @create 2011/07/30
 * @author KCCS kyo
 * @since 3.9.0
 */
public class GRedirectMenuStarter extends GMenuStarterBase {

	/**
	 * {@link GRedirectMenuStarter}インスタンスを初期化します.<br>
	 * 
	 * @create 2010/01/09
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	public GRedirectMenuStarter() {
	}

	/**
	 * {@link GMenu#getStartModule()}で指定された任意のURLファイルを起動します。<br>
	 * {@link GMenu#getStartModule()}にて指定されたファイルにリダイレクトしています。<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.menu.GMenuStarter#execute(jp.co.kccs.greenearth.framework.em.menumanager.GMenu,
	 *      jp.co.kccs.greenearth.framework.data.GResultData,
	 *      jakarta.servlet.http.HttpServletRequest,
	 *      jakarta.servlet.http.HttpServletResponse)
	 * @param menu メニュー
	 * @param resultData 結果データ
	 * @param request リクエスト
	 * @param response レスポンス
	 * @return 結果データ
	 * @throws GLaunchMenuException メニューの起動に失敗した場合
	 * @create 2010/11/05
	 * @author KCCS kyo
	 * @since v3.9.0
	 */
	public GResultData start(GMenu menu, GResultData resultData, HttpServletRequest request, HttpServletResponse response) throws GLaunchMenuException {

		if (menu == null) {
			GErrorMessage message = GErrorMessages.getErrorMessage(ERROR_CODE, GFrameworkContext.getInstance().getLocale());
			throw new NullPointerException(message.getMessage());
		}
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session = manager.getSession(request.getSession());
		GUser user = session.getLoginUser();
		checkAuthority(menu, user);
		
		// リダイレクト
		try {
			// 遷移先URL作成
			StringBuilder redirectURL = new StringBuilder();
			// httpで始まるものはそのままリダイレクト、/から始まる同一コンテキスト内のコンテンツはコンテキストパスを保管する
			String startmodule = menu.getStartModule();
			if (startmodule == null) {
				throw new GLaunchMenuException("Menu start failure");
			}
			if (startmodule.startsWith("/")) {
				redirectURL.append(request.getContextPath());
				redirectURL.append(startmodule);
			} else if (startmodule.startsWith("http:")
					|| startmodule.startsWith("https:")) {
				redirectURL.append(startmodule);
			} else {
				throw new GLaunchMenuException("MenuStarter is necessary to start from '/' or 'http:' or 'https:'. ");
			}
			String param = menu.getParameter();
			if (param != null) {
				redirectURL.append("?");
				redirectURL.append(param);
			}
			
			response.sendRedirect(response.encodeRedirectURL(redirectURL.toString()));
			
		} catch (IOException e) {
			throw new GLaunchMenuException(e);
		}

		resultData.setExitCode(GResultData.EXIT_CODE_DIRECT_RESPONSE);
		return resultData;
	}
}
