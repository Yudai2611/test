/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link java.util.Date}型検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値が日付型であるかどうかを検証します。<br>
 * 　検証値はフォーマット書式文字列を使用して{@link Date}型のオブジェクトに変換できるかどうかを検証します。
 * {@link Date}型オブジェクトに変換できた場合は<code>null</code>を、変換できなかった場合は{@link GValidateError}を返します。<br>
 * 　検証値を解析するためのフォーマット書式文字列の取得方法は、args属性の値によって変わります。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　{@link GFormatControl}を実装したUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　日付文字列を解析する為のフォーマット書式文字列の取得先を指定します。
 * パラメータの指定は、大文字、小文字を区別しません。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_CONTROL}</code>：検証対象のUIコントロールにセットされたフォーマット書式文字列を取得します。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code>(規定値)：プロパティにセットされたフォーマット書式文字列を取得します。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000059</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * 　<code>日付の指定が不正です</code><br>
 * <br>
 * 【例外】<br>
 * 　1. 検証対象のUIコントロールが{@link GFormatControl}を実装していない場合、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 【備考】<br>
 * 　1. <code>args</code>属性が無指定又は、識別子を誤った場合、{@value GValidatorBase#ARGS_FORMAT_PROPERTY}を指定したものとして処理されます。<br>
 * 　2. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * 　3. 検証値のフォーマット解析は、<code>args</code>属性の値によって以下の処理を行います。<br>
 * 　　3.1 <cord>args</cord>属性の値が<cord>{@value GValidatorBase#ARGS_FORMAT_CONTROL}</cord>の場合<br>
 * 　　検証対象のUIコントロールに設定されたフォーマット書式文字列と{@link GDateUtils#toDate(String, String, Locale, boolean)}を用いて、
 * 検証値を{@link Date}型オブジェクトに変換します。<br>
 * <br>
 * 　　3.2 <cord>args</cord>属性の値が<cord>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</cord>(規定値)の場合<br>
 * 　　プロパティファイルからフォーマット書式文字列を取得し、
 * {@link GConvertUtils#toDate(String, Locale)}を用いて検証値を{@link Date}型オブジェクトに変換します。<br>
 * 　　フォーマット書式文字列は、<code>ge-framework.properties</code>のキー<code>"geframe.core.Convert.DateFormat[インデックス]"</code>に設定された値を使用します。
 * インデックスは<code>1</code>から始まり、
 * {@link Date}型オブジェクトに変換できるまでインデックスへの<code>1</code>の加算とフォーマット書式文字列の取得、
 * {@link Date}型オブジェクトへの変換を繰り返します。
 * {@link Date}型オブジェクトへの変換が成功した場合はその時点で検証処理を終了し、<code>null</code>を返します。
 * 取得可能なキーがなくなった場合はその時点でフォーマット書式文字列の取得を中止し、{@link GValidateError}を返します。<br>
 * <br>
 * <br>
 * [例1]<br>
 * 　検証値：<br>
 * 　　<code>args</code>属性が<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code><br>
 * 　　<code>"2005/10"</code><br>
 * 　プロパティ：<br>
 * 　　<code>geframe.core.Convert.DateFormat1=yyyyMM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat2=yyyyMMdd</code><br>
 * 　　<code>geframe.core.Convert.DateFormat3=yyyy/MM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat4=yyyy/MM/dd</code><br>
 * 　結果：<br>
 * 　　3つ目のキーまでフォーマット書式文字列の取得と{@link java.util.Date}型オブジェクトへの変換を実行します。
 * 3つ目のフォーマット書式文字列によって変換可能であるため、<code>null</code>を返します。<br>
 * <br>
 * [例2]<br>
 * 　検証値：<br>
 * 　　<code>args</code>属性が<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code><br>
 * 　　<code>"2005/10/25 12:21:45"</code><br>
 * 　プロパティ：<br>
 * 　　<code>geframe.core.Convert.DateFormat1=yyyyMM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat2=yyyyMMdd</code><br>
 * 　　<code>geframe.core.Convert.DateFormat3=yyyy/MM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat4=yyyy/MM/dd</code><br>
 * 　結果：<br>
 * 　　4つ目のキーまでフォーマット書式文字列の取得と{@link java.util.Date}型オブジェクトへの変換を実行します。
 * しかし、変換可能なフォーマット書式文字列が存在しないため{@link GValidateError}を返します。<br>
 * <br>
 * [例3]<br>
 * 　検証値：<br>
 * 　　<code>args</code>属性が<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code><br>
 * 　　<code>"2005/10/25"</code><br>
 * 　プロパティ：<br>
 * 　　<code>geframe.core.Convert.DateFormat1=yyyyMM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat2=yyyyMMdd</code><br>
 * 　　<code>geframe.core.Convert.DateFormat3=yyyy/MM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat5=yyyy/MM/dd</code><br>
 * 　結果：<br>
 * 　　3つ目のキーまでフォーマット書式文字列の取得と{@link java.util.Date}型オブジェクトへの変換を実行します。
 * しかし、4つ目のキーが取得できないため変換可能なフォーマット書式文字列が存在しないと判断して{@link GValidateError}を返します。<br>
 * <br>
 * [例4]<br>
 * 　検証値：<br>
 * 　　<code>args</code>属性が<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code><br>
 * 　　<code>"2005/10/25"</code><br>
 * 　プロパティ：<br>
 * 　　<code>geframe.core.Convert.DateFormat2=yyyyMM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat3=yyyyMMdd</code><br>
 * 　　<code>geframe.core.Convert.DateFormat4=yyyy/MM</code><br>
 * 　　<code>geframe.core.Convert.DateFormat5=yyyy/MM/dd</code><br>
 * 　結果：<br>
 * 　　1つ目のキーが取得できないため変換可能なフォーマット書式文字列が存在しないと判断して{@link GValidateError}を返します。<br>
 * 
 * @create 2007/03/27
 * @author okajima
 * @since 3.0.0
 */
public class GDateTypeValidator extends GDateValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = 1800969023718915308L;
	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000059";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/03/27
	 * @author okajima
	 * @since 3.0.0
	 */
	public GDateTypeValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 日付型を検証します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(GUIControl, String, List, Locale)
	 * @create 2007/03/27
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author okajima
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		GFormatControl formatControl = getGFormatControl(control);

		try {
			Date date = getDate(formatControl, value, locale);

			if (date != null) {
				return null;
			}
			else {
				return createValidateError(control, locale);
			}
		}
		catch (ParseException e) {
			return createValidateError(control, locale);
		}
	}
}
