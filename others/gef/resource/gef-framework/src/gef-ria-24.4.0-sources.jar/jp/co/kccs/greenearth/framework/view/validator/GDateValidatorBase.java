/*
 * Copyright 2007-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * {@link java.util.Date}型の検証クラスの簡易実装クラスです.<br>
 * {@link Date}型の検証クラスを作成する場合、このクラスを継承してください。<br>
 * <br>
 * 【概要】<br>
 * {@link java.util.Date}型の検証クラスの作成に必要な次の機能を提供します。<br>
 * 　1. 指定されたフォーマット書式文字列に基づいた{@link Date}型オブジェクトから{@link Date}型オブジェクトへの変換<br>
 * 　2. 指定されたフォーマット書式文字列に基づいた{@link Date}型文字列から{@link Date}型オブジェクトへの変換<br>
 * 　3. {@link GFormatControl}実装の有無のチェック<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証用パラメータ(<code>args</code>属性)に複数のパラメータを指定する場合、次のようにセパレータ文字列で区切る必要があります。<br>
 * <br>
 * <b>args="param01@@param02"</b><br>
 * <br>
 * 　2. セパレータ文字列は、次の優先順位で決定されます。<br>
 * 　　2.1. プロパティファイルのキー{@value #ARGS_SEPARATOR_PROPERTY}で指定された文字列<br>
 * 　　2.2. 文字列 {@value #DEFAULT_ARGS_SEPARATOR}<br>
 * <br>
 * 
 * @create 2007/03/30
 * @author wadatani
 * @since 3.0.0
 */
public abstract class GDateValidatorBase extends GValidatorBase {

	/** シリアルバージョン. */
	private static final long serialVersionUID = -8832769126853880213L;
	/** 日付フォーマッタ. */
	private GDateFormatter _dateFormatter;

	// ----- コンストラクタ -----------------------------------------------------------------------------------------------------
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2007/03/30
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GDateValidatorBase() {
	}

	// ----- プロテクテッドメソッド -----------------------------------------------------------------------------------------------------

	/**
	 * 指定された{GUIControl}を{@link GFormatControl}に変換して取得します.
	 * 変換に失敗した場合、{@link IllegalArgumentException}を投げます。
	 * 
	 * @create 2007/03/31
	 * @param control UIコントロール
	 * @return {@link GFormatControl}インスタンス
	 * @author wadatani
	 * @since 3.0.0
	 */
	protected GFormatControl getGFormatControl(GUIControl control) {

		if (!(control instanceof GFormatControl)) {
			throw new IllegalArgumentException("\"" + control.getId() + "\" : Illegal control interface in " + this.getClass().getSimpleName() + " of " + control.getId() + ".");
		}

		return (GFormatControl) control;
	}

	/**
	 * 指定された検証値を{@link Date}型オブジェクトに変換して取得します.<br>
	 * 
	 * {@link Date}型オブジェクトへの変換に成功した場合は{@link Date}型オブジェクトを返します。
	 * 変換には、{@link GDateFormatter}を利用します。
	 * Validatorのargs属性に<code>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_CONTROL}</code>を指定した場合は、
	 * Validatorタグが所属するUIControlのformat属性に指定されたパターン文字列が変換に利用されます。
	 * 
	 * @create 2007/03/31
	 * @param formatControl {@link GFormatControl}オブジェクト
	 * @param value 検証値
	 * @param locale ロケール
	 * @return {@link Date}型オブジェクト
	 * @throws ParseException 日付型への変換に失敗した場合
	 * @author wadatani
	 * @since 3.0.0
	 */
	protected Date getDate(GFormatControl formatControl, String value, Locale locale) throws ParseException {
		if (GStringUtils.isEmpty(value)) {
			return null;
		}
		GDateFormatter formatter = getDateFormatter();
		if (useControlFormat(formatControl)) {
			String format = formatControl.getFormat();
			if (format != null) {
				return formatter.parse(value, locale, format);
			}
			else {
				throw new IllegalArgumentException("Not specified control format in " + this.getClass().getSimpleName() + " of " + formatControl.getId() + ".");
			}
		}
		else {
			return formatter.parse(value, locale);
		}
	}
	
	private GDateFormatter getDateFormatter() {
		if (_dateFormatter == null) {
			_dateFormatter = GFrameworkUtils.getComponent(GDateFormatter.class.getName());
		}
		return _dateFormatter;
	}
}
