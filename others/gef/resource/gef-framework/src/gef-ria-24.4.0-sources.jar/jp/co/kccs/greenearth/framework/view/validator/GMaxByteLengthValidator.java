/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link Byte}型最大桁数検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　<code>ge-framework.properties</code>にて指定された文字コードにおける検証値の{@link Byte}型の長さが、最大桁数を超えるかどうかを検証します。<br>
 * 　検証値の{@link Byte}型の長さが最大バイト数以下の場合は<code>null</code>、最大桁数を超える場合は{@link GValidateError}を返します。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　全てのUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　<code>ge-framework.properties</code>のキー<code>"geframe.view.Validator.MaxByteLengthCharset"</code>で指定された文字コードにおける
 * {@link Byte}型の最大桁数を指定します。正の整数で指定してください。<br>
 * 　指定は必須です。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000019</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * 　<code>バイト数が制限を超えています</code><br>
 * <br>
 * 【例外】<br>
 * 　1. 最大桁数が指定されていない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 　2. 最大桁数が整数文字列でない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 　3. 最大桁数が0以上の整数文字列の場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 　2. <code>ge-framework.properties</code>のキー<code>"geframe.view.Validator.MaxByteLengthCharset"</code>が存在しない場合は、
 * <code>"Shift_JIS"</code>を使用します。<br>
 * 
 * @create 2007/03/29
 * @author wadatani
 * @since 3.0.0
 */
public class GMaxByteLengthValidator extends GValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = -9133292493409046607L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000019";

	/** プロパティから文字コードの設定を取得するためのキー. */
	protected static final String CHAR_SET_PROPERTY = "geframe.view.Validator.MaxByteLengthCharset";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/03/29
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GMaxByteLengthValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 入力値の{@link java.lang.Byte}型の最大桁数を検証します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(jp.co.kccs.greenearth.framework.view.component.GUIControl, java.lang.String, java.util.List, java.util.Locale)
	 * @create 2007/03/30
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		// 最大桁数の取得
		int maxLength = getArgsAsOverZeroInteger(control, 0);

		byte[] bytes;
		String charset = GFrameworkUtils.getProperty(CHAR_SET_PROPERTY);

		try {
			bytes = value.getBytes(charset);
		}
		catch (UnsupportedEncodingException uee) {
			throw new IllegalArgumentException("\"" + charset + "\" : Illegal charset in " + this.getClass().getSimpleName() + " of " + control.getId() + ".");
		}

		// 検証
		if (bytes.length > maxLength) {
			return createValidateError(control, locale);
		}

		return null;
	}
}
