/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link java.lang.String}型最大文字数検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値の文字数が最大文字数を超えるかどうかを検証します。<br>
 * 　検証値の文字数が最大文字数以下の場合は<code>null</code>、超える場合は{@link jp.co.kccs.greenearth.framework.data.GValidateError}を返します。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　全てのUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　最大文字数を指定します。正の整数を指定してください。<br>
 * 　指定は必須です。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000003</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * 　<code>桁数が制限を超えています</code><br>
 * <br>
 * 【例外】<br>
 * 　1. 最大文字数が指定されていない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 　2. 最大文字数が整数文字列でない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 　3. 最大文字数が0以上の整数文字列でない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 　2. 検証には{@link String#length()}を使用していますので、サーバ側でUnicodeに正しく変換されている必要があります。
 * サーバ側で文字化けしていると正しい検証が行えません。文字コードの設定には注意してください。<br>
 * 
 * @create 2007/02/05
 * @author okajima
 * @since 3.0.0
 */
public class GMaxStringLengthValidator extends GStringValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = 4793418465964127120L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000003";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/03/24
	 * @author okajima
	 * @since 3.0.0
	 */
	public GMaxStringLengthValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 文字列入力値の最大文字数を検証します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(GUIControl, String, List, Locale)
	 * @create 2007/02/05
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author okajima
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		int maxLength = getArgsAsOverZeroInteger(control, 0);

		if (value.codePointCount(0, value.length()) > maxLength) {
			return createValidateError(control, locale);
		}

		return null;
	}
}
