/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link Date}型過去検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値{@link Date}文字列が現在よりも過去かどうかを検証します。
 * 検証値が過去の{@link Date}文字列の場合は{@link GValidateError}、
 * 現在、もしくは未来の{@link Date}文字列の場合は<code>null</code>を返します。<br>
 * 　検証値はフォーマット書式文字列を使用して{@link java.util.Date}型のオブジェクトに変換して検証します。
 * 検証値を解析するためのフォーマット書式文字列の取得方法は、<code>args</code>属性の値によって変わります。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　{@link GFormatControl}を実装したUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　日付文字列を解析する為のフォーマット書式文字列の取得先を指定します。
 * パラメータの指定は、大文字、小文字を区別しません。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_CONTROL}</code>：検証対象のUIコントロールにセットされたフォーマット書式文字列を取得します。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code>(規定値)：プロパティにセットされたフォーマット書式文字列を取得します。<br>
 * <br>
 * 【エラーコード】<br>
 * <code>GEF-000032</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * <code>過去の日付は入力できません</code><br>
 * <br>
 * 【例外】<br>
 * 　1. 検証対象のUIコントロールが{@link GFormatControl}を実装していない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 　2. 検証値が{@link GDateTypeValidator}の検証に失敗する値の場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 【備考】<br>
 * 　1. <code>args</code>属性が無指定又は、識別子を誤った場合、{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_PROPERTY}を指定したものとして処理されます。<br>
 * <br>
 * 　2. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 　3. 検証値のフォーマット解析は、<code>args</code>属性の値によって以下の処理を行います。<br>
 * 　　3.1 <cord>args</cord>属性の値が<cord>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_CONTROL}</cord>の場合<br>
 * 　　検証対象のUIコントロールに設定されたフォーマット書式文字列と{@link jp.co.kccs.greenearth.commons.utils.GDateUtils#toDate(String, String, Locale, boolean)}を用いて、
 * 検証値を{@link Date}型オブジェクトに変換します。<br>
 * <br>
 * 　　3.2 <cord>args</cord>属性の値が<cord>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_PROPERTY}</cord>(規定値)の場合<br>
 * 　　プロパティファイルからフォーマット書式文字列を取得し、
 * {@link jp.co.kccs.greenearth.framework.utils.GConvertUtils#toDate(String, Locale)}を用いて検証値を{@link Date}型オブジェクトに変換します。<br>
 * 　　　フォーマット書式文字列は、<code>ge-framework.properties</code>のキー<code>"geframe.core.Convert.DateFormat[インデックス]"</code>に設定された値を使用します。
 * インデックスは<code>1</code>から始まり、
 * {@link Date}型オブジェクトに変換できるまでインデックスへの<code>1</code>の加算とフォーマット書式文字列の取得、
 * {@link Date}型オブジェクトへの変換を繰り返します。
 * 取得可能なキーが無くなった場合はその時点でフォーマット書式文字列の取得を中止し、{@link IllegalArgumentException}を発生します。<br>
 * <br>
 * 　4. 日付だけでなく、時刻の検証も可能です。<br>
 * 
 * @create 2007/03/28
 * @author wadatani
 * @since 3.0.0
 */
public class GNotPastValidator extends GDateValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = -9066872109807266062L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000032";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/03/28
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GNotPastValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 検証値が過去でないことを検証します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(GUIControl, String, List, Locale)
	 * @create 2007/03/28
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		GFormatControl formatControl = getGFormatControl(control);

		if (isPast(formatControl, value, locale)) {
			return createValidateError(control, locale);
		}

		return null;
	}

	/**
	 * 指定された文字列が現在よりも過去かどうかを判定します.<br>
	 * 検証値の日付が過去の場合は<code>true</code>、現在及び未来の場合は<code>false</code>を返します。<br>
	 * 文字列が{@link Date}型オブジェクトに変換できなかった場合、{@link IllegalArgumentException}が発生します。
	 * 
	 * @create 2007/03/31
	 * @param formatControl {@link GFormatControl}オブジェクト
	 * @param value 文字列
	 * @param locale ロケール
	 * @return <code>true</code>/<code>false</code>
	 * @author wadatani
	 * @since 3.0.0
	 */
	protected boolean isPast(GFormatControl formatControl, String value, Locale locale) {
		Date date;
		try {
			date = getDate(formatControl, value, locale);
		} catch (ParseException e) {
			throw new IllegalArgumentException("\"" + value + "\" : Illegal value in " + this.getClass().getSimpleName() + " of " + formatControl.getId() + ".");
		}
		if (date == null) {
			throw new IllegalArgumentException("\"" + value + "\" : Illegal value in " + this.getClass().getSimpleName() + " of " + formatControl.getId() + ".");
		}
		
		Calendar target = Calendar.getInstance(locale);
		target.setTime(date);
		Calendar now = Calendar.getInstance(locale);

		int nowYear = now.get(Calendar.YEAR);
		int targetYear = target.get(Calendar.YEAR);
		if (nowYear < targetYear) {
			return false;
		}
		else if (nowYear > targetYear) {
			return true;
		}

		int nowMonth = now.get(Calendar.MONTH);
		int targetMonth = target.get(Calendar.MONTH);
		if (nowMonth < targetMonth) {
			return false;
		}
		else if (nowMonth > targetMonth) {
			return true;
		}

		int nowDay = now.get(Calendar.DAY_OF_MONTH);
		int targetDay = target.get(Calendar.DAY_OF_MONTH);
		return nowDay > targetDay;
	}
}
