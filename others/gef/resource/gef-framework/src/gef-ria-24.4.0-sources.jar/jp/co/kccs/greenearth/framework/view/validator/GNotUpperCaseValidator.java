/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link java.lang.String}型小文字検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値が{@link java.lang.String}型の小文字かどうかを検証します。
 * 検証値に大文字が含まれている場合は{@link GValidateError}、大文字が含まれていない場合は<code>null</code>を返します。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　全てのUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　不要です。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000011</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * 　<code>大文字は入力できません</code><br>
 * <br>
 * 【例外】<br>
 * 　特にありません。<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 　2. 小文字検証の対象文字列は英文字のみであり、日本語や数字、記号などは検証対象となりません。
 * 日本語や数字、記号などの大文字が含まれていたとしても検証エラーは発生しません。<br>
 * 
 * @create 2007/03/31
 * @author wadatani
 * @since 3.0.0
 */
public class GNotUpperCaseValidator extends GStringValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = 7766601144792200209L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000011";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します.
	 * 
	 * @create 2007/03/31
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GNotUpperCaseValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 検証値に大文字が含まれていないことを検証します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(jp.co.kccs.greenearth.framework.view.component.GUIControl, java.lang.String, java.util.List, java.util.Locale)
	 * @create 2007/03/31
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		// 検証
		if (value.equals(value.toLowerCase(locale))) {
			return null;
		}
		else {
			return createValidateError(control, locale);
		}
	}

}
