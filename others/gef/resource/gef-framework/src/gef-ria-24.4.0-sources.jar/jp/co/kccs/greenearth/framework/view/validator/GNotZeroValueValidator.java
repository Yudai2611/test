/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link Number}型<code>0</code>値検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値が{@link Number}型<code>0</code>値かどうかを検証します。
 * 検証値が<code>0</code>の場合は{@link GValidateError}、それ以外の場合は<code>null</code>を返します。<br>
 * 　検証値はフォーマット書式文字列を使用して{@link java.math.BigDecimal}型のオブジェクトに変換します。
 * 検証値を解析するためのフォーマット書式文字列の取得方法は、<code>args</code>属性の値によって変わります。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　{@link GFormatControl}を実装したUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　数値文字列を解析する為のフォーマット書式文字列の取得先を指定します。
 * パラメータの指定は、大文字、小文字を区別しません。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_CONTROL}</code>：検証対象のUIコントロールにセットされたフォーマット書式文字列を取得します。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code>(規定値)：プロパティにセットされたフォーマット書式文字列を取得します。<br>
 * <br>
 * 【エラーコード】<br>
 * <code>GEF-000015</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * <code>0は入力できません</code><br>
 * <br>
 * 【例外】<br>
 * 　1. 検証対象のUIコントロールが{@link GFormatControl}を実装していない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 　2. 検証値が検証対象のUIコントロールで設定されたフォーマットに基づいた数値文字列でない値、
 * {@link GNumberTypeValidator}の検証に失敗する値の場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 　3. 検証対象のUIコントロールにフォーマットが設定されていないにも関わらず、
 * 検証値がフォーマットされた数値文字列の場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 【備考】<br>
 * 　1. <code>args</code>属性が無指定又は、識別子を誤った場合、{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_PROPERTY}を指定したものとして処理されます。<br>
 * <br>
 * 　2. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 　3. フォーマット書式文字列は{@link java.text.NumberFormat}の定義に基づいています。<br>
 * <br>
 * 　4. 検証値のフォーマット解析は、<code>args</code>属性の値によって以下の処理を行います。<br>
 * 　　4.1 <cord>args</cord>属性の値が<cord>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_CONTROL}</cord>の場合<br>
 * 　　検証対象のUIコントロールに設定されたフォーマット書式文字列と{@link jp.co.kccs.greenearth.commons.utils.GNumberUtils#toBigDecimal(String, String, Locale)}を用いて、
 * 検証値を{@link BigDecimal}型オブジェクトに変換します。<br>
 * <br>
 * 　　4.2 <cord>args</cord>属性の値が<cord>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_PROPERTY}</cord>(規定値)の場合<br>
 * 　　プロパティファイルからフォーマット書式文字列を取得し、
 * {@link jp.co.kccs.greenearth.framework.utils.GConvertUtils#toBigDecimal(String, Locale)}を用いて検証値を{@link BigDecimal}型オブジェクトに変換します。<br>
 * 　　フォーマット書式文字列は、<code>ge-framework.properties</code>のキー<code>"geframe.core.Convert.NumberFormat[インデックス]"</code>に設定された値を使用します。
 * インデックスは<code>1</code>から始まり、
 * {@link BigDecimal}型オブジェクトに変換できるまでインデックスへの<code>1</code>の加算とフォーマット書式文字列の取得、
 * {@link BigDecimal}型オブジェクトへの変換を繰り返します。
 * 　取得可能なキーが無くなった場合はその時点でフォーマット書式文字列の取得を中止し、{@link IllegalArgumentException}を発生します。<br>
 * <br>
 * 　5. フォーマットに基づいた検証の際、桁区切り子は厳密に検証されますが、グループ区切り子は厳密に検証されません。<br>
 * 　例えば、グループ区切り子が複数記述された検証値"1,,,,0,0,,,00.0"の場合、
 * "10000.0"と認識するため<code>null</code>を返します。
 * 一方、桁区切り子が複数記述された検証値"1,000.....00"の場合、数値として認識せずに{@link GValidateError}を返します。
 * 仕様に注意してください。<br>
 * 
 * @create 2007/03/29
 * @author wadatani
 * @since 3.0.0
 */
public class GNotZeroValueValidator extends GNumberValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = -7758146696084674173L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000015";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/03/29
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GNotZeroValueValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 検証値が<code>0</code>でないことを検証します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(GUIControl, String, List, Locale)
	 * @create 2007/03/29
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		GFormatControl formatControl = getGFormatControl(control);

		try {
			// 検証値をBigDecimalに変換
			BigDecimal target = getBigDecimal(formatControl, value, locale);

			// 検証
			if (target.compareTo(ZERO_VALUE) == 0) {
				return createValidateError(control, locale);
			}

			return null;
		}
		catch (ParseException e) {
			throw new IllegalArgumentException(e);
		}
	}
}
