/*
 * Copyright 2011-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link String}型数値文字参照検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値に数値文字参照がふくまれるかどうか検証します。<br>
 * 　数値文字参照が含まれる場合は{@link GValidateError}を、含まれない場合は<code>null</code>を返します。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　全てのUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　{@link String}型検証値を指定します。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000017</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * 　<code>禁止文字が含まれています</code><br>
 * <br>
 * 【備考】<br>
 * 　1. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 
 * @create 2011/02/24
 * @author KCCS murashige
 * @since 3.9.0
 */
public class GNumCharReferenceValidator extends GStringValidatorBase{

	/** シリアルバージョン.*/
	private static final long serialVersionUID = -637341731240898741L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000017";
	
	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2011/02/24
	 * @author KCCS murashige
	 * @since 3.9.0
	 */
	public GNumCharReferenceValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 数値文字参照が含まれるかどうか検証します。
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(jp.co.kccs.greenearth.framework.view.component.GUIControl, java.lang.String, java.util.List, java.util.Locale)
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
     * @return 発生したエラー
	 * @create 2011/02/24
	 * @author KCCS murashige
	 * @since 3.9.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
        if (value == null || value.equals("")) {
            return null;
        }
		boolean isNumCharReferenceMacher = GStringUtils.checkNumCharReference(value);
		if (isNumCharReferenceMacher) {
			return createValidateError(control, locale);
		}
		return null;
	}
}
