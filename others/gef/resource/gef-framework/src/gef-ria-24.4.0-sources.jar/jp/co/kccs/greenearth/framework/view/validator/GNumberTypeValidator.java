/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link Number}型検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値が数値型であるかどうかを検証します。<br>
 * 　検証値はフォーマット書式文字列を使用して{@link java.math.BigDecimal}型のオブジェクトに変換できるかどうかを検証します。
 * {@link  java.math.BigDecimal}型オブジェクトに変換できた場合は<code>null</code>を、変換できなかった場合は
 * {@link jp.co.kccs.greenearth.framework.data.GValidateError}を返します。<br>
 * 　検証値を解析するためのフォーマット書式文字列の取得方法は、<code>args</code>属性の値によって変わります。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　{@link GFormatControl}を実装したUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　数値文字列を解析する為のフォーマット書式文字列の取得先を指定します。
 * パラメータの指定は、大文字、小文字を区別しません。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_CONTROL}</code>：検証対象のUIコントロールにセットされたフォーマット書式文字列を取得します。<br>
 * 　　<code>{@value GValidatorBase#ARGS_FORMAT_PROPERTY}</code>(規定値)：プロパティにセットされたフォーマット書式文字列を取得します。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000014</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * 　<code>数値を入力してください</code><br>
 * <br>
 * 【例外】<br>
 * 　1. 検証対象のUIコントロールが{@link GFormatControl}を実装していない場合、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 　2. フォーマット書式文字列は{@link java.text.NumberFormat}の定義に基づいています。<br>
 * <br>
 * 　3. 検証値のフォーマット解析は、<code>args</code>属性の値によって以下の処理を行います。<br>
 * 　　（<code>args</code>属性が無指定又は、識別子を誤った場合、{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_PROPERTY}を指定したものとして処理されます。）<br>
 * 　　3.1 <cord>args</cord>属性の値が<cord>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_CONTROL}</cord>の場合<br>
 * 　　検証対象のUIコントロールに設定されたフォーマット書式文字列と{@link jp.co.kccs.greenearth.commons.utils.GNumberUtils#toBigDecimal(String, String, Locale)}を用いて、
 * 検証値が{@link java.math.BigDecimal}型オブジェクトに変換できるかどうかを検証します。<br>
 * <br>
 * 　　3.2 <cord>args</cord>属性の値が<cord>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_PROPERTY}</cord>(規定値)の場合<br>
 * 　　プロパティファイルからフォーマット書式文字列を取得し、
 * {@link jp.co.kccs.greenearth.framework.utils.GConvertUtils#toBigDecimal(String, Locale)}を用いて検証値が{@link java.math.BigDecimal}型オブジェクトに変換できるかどうかを検証します。<br>
 * 　　　フォーマット書式文字列は、<code>ge-framework.properties</code>のキー<code>"geframe.core.Convert.NumberFormat[インデックス]"</code>に設定された値を使用します。
 * インデックスは<code>1</code>から始まり、
 * {@link java.math.BigDecimal}型オブジェクトに変換できるまでインデックスへの<code>1</code>の加算とフォーマット書式文字列の取得、
 * {@link java.math.BigDecimal}型オブジェクトへの変換を繰り返します。<br>
 * 　　{@link Number}型オブジェクトへの変換が成功した場合はその時点で検証処理を終了し、<code>null</code>を返します。
 * 取得可能なキーが無くなった場合はその時点でフォーマット書式文字列の取得を中止し、{@link jp.co.kccs.greenearth.framework.data.GValidateError}を返します。<br>
 * <br>
 * 　4. フォーマットに基づいた検証の際、桁区切り子は厳密に検証されますが、グループ区切り子は厳密に検証されません。<br>
 * 　例えば、グループ区切り子が複数記述された検証値"1,,,,0,0,,,00.0"の場合、
 * "10000.0"と認識するため<code>null</code>を返します。
 * 一方、桁区切り子が複数記述された検証値"1,000.....00"の場合、数値として認識せずに{@link GValidateError}を返します。
 * 仕様に注意してください。<br>
 * 
 * @create 2007/03/27
 * @author okajima
 * @since 3.0.0
 */
public class GNumberTypeValidator extends GNumberValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = -232140323336265544L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000014";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/03/27
	 * @author okajima
	 * @since 3.0.0
	 */
	public GNumberTypeValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 数値型を検証します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(GUIControl, String, List, Locale)
	 * @create 2007/03/27
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author okajima
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		GFormatControl formatControl = getGFormatControl(control);

		try {
			BigDecimal decimal = getBigDecimal(formatControl, value, locale);

			if (decimal != null) {
				return null;
			}
			else {
				return createValidateError(formatControl, locale);
			}
		}
		catch (ParseException e) {
			return createValidateError(formatControl, locale);
		}
	}
}
