/*
 * Copyright 2007-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.formatter.GBigDecimalFormatter;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * {@link java.util.Number}型の検証クラスの簡易実装クラスです.<br>
 * {@link Date}型の検証クラスを作成する場合、このクラスを継承してください。<br>
 * <br>
 * 【概要】<br>
 * {@link java.util.Number}型の検証クラスの作成に必要な次の機能を提供します。<br>
 * 　1. 指定されたフォーマット書式文字列に基づいた{@link Number}型文字列から{@link Number}型オブジェクトへの変換<br>
 * 　2. {@link GFormatControl}実装の有無のチェック<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証用パラメータ(<code>args</code>属性)に複数のパラメータを指定する場合、次のようにセパレータ文字列で区切る必要があります。<br>
 * <br>
 * <b>args="param01@@param02"</b><br>
 * <br>
 * 　2. セパレータ文字列は、次の優先順位で決定されます。<br>
 * 　　2.1. プロパティファイルのキー{@value #ARGS_SEPARATOR_PROPERTY}で指定された文字列<br>
 * 　　2.2. 文字列 {@value #DEFAULT_ARGS_SEPARATOR}<br>
 * <br>
 * 
 * @create 2007/03/30
 * @author wadatani
 * @since 3.0.0
 */
public abstract class GNumberValidatorBase extends GValidatorBase {

	/** シリアルバージョン. */
	private static final long serialVersionUID = 302173855580771596L;

	/** ゼロ値. */
	protected static final BigDecimal ZERO_VALUE = new BigDecimal("0");

	/** 数値フォーマッタ. */
	private GBigDecimalFormatter _bigDecimalFormatter;
	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2007/03/30
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GNumberValidatorBase() {
	}

	/**
	 * 指定された{@link GUIControl}を{@link GFormatControl}に変換して取得します.<br>
	 * 変換に失敗した場合、{@link IllegalArgumentException}を投げます。
	 * 
	 * @create 2007/03/30
	 * @param control UIコントロール
	 * @return {@link GFormatControl}オブジェクト
	 * @author wadatani
	 * @since 3.0.0
	 */
	protected GFormatControl getGFormatControl(GUIControl control) {
		if (!(control instanceof GFormatControl)) {
			throw new IllegalArgumentException("\"" + control.getId() + "\" : Illegal control interface in " + this.getClass().getSimpleName() + " of " + control.getId() + ".");
		}

		return (GFormatControl) control;
	}

	/**
	 * 指定された{@link String}オブジェクトを、{@link BigDecimal}オブジェクトに変換して取得します.<br>
	 * 
	 * 変換には、{@link GBigDecimalFormatter}を利用します。
	 * Validatorのargs属性に<code>{@value jp.co.kccs.greenearth.framework.view.validator.GValidatorBase#ARGS_FORMAT_CONTROL}</code>を指定した場合は、
	 * Validatorタグが所属するUIControlのformat属性に指定されたパターン文字列が変換に利用されます。
	 * 
	 * @create 2007/03/30
	 * @param formatControl {@link GFormatControl}オブジェクト
	 * @param value 検証値
	 * @param locale ロケール
	 * @return {@link BigDecimal}オブジェクト
	 * @exception ParseException 数値型への変換に失敗した場合
	 * @author wadatani
	 * @since 3.0.0
	 */
	protected BigDecimal getBigDecimal(GFormatControl formatControl, String value, Locale locale) throws ParseException {
		if (GStringUtils.isEmpty(value)) {
			return null;
		}
		
		GBigDecimalFormatter formatter = getBigDecimalFormatter();
		if (useControlFormat(formatControl)) {
			String format = formatControl.getFormat();
			if (format != null) {
				return formatter.parse(value, locale, format);
			}
			else {
				throw new IllegalArgumentException("No specified control format in " + this.getClass().getSimpleName() + " of " + formatControl.getId() + ".");
			}
		}
		else {
			return formatter.parse(value, locale);
		}
	}
	
	private GBigDecimalFormatter getBigDecimalFormatter() {
		if (_bigDecimalFormatter == null) {
			_bigDecimalFormatter = GFrameworkUtils.getComponent(GBigDecimalFormatter.class.getName());
		}
		return _bigDecimalFormatter;
	}
}
