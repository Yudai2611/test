/*
 * Copyright 2007-2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の{@link String}型禁止値検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値が{@link String}型禁止値で定義された値であるかどうかを検証します。
 * 検証値が禁止値で定義された値以外の場合は<code>null</code>、禁止値のいずれかの値である場合は{@link GValidateError}を返します。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　全てのUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　{@link String}型禁止値を指定します。<br>
 * 　禁止値を複数指定する場合は、
 * <code>ge-framework.properties</code>のキー<code>"geframe.view.Validator.Args.Separator"</code>で設定された区切り文字を使用し、
 * 各値を区切ってください。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000017</code><br>
 * <br>
 * 【エラーメッセージ】<br>
 * 　<code>禁止文字が含まれています</code><br>
 * <br>
 * 【例外】<br>
 * 　1. 禁止値が指定されていない場合は、{@link IllegalArgumentException}が発生します。<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証値が<code>null</code>、もしくは空文字の場合、<code>null</code>を返します。<br>
 * <br>
 * 　2. 検証用パラメータのセパレータとして使用する文字列は、
 * ge-framework.propertiesのキー<code>"geframe.view.validator.Args.Separator"</code>に指定された文字列を使用します。
 * この定義がない場合は、文字列{@value GValidatorBase#DEFAULT_ARGS_SEPARATOR}を使用します。<br>
 * 
 * @create 2007/03/28
 * @author wadatani
 * @since 3.0.0
 */
public class GProhibitionValueValidator extends GStringValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = 5017852296370125776L;
	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000017";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/03/28
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GProhibitionValueValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 入力値が禁止値かどうかを検証します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(GUIControl, String, List, Locale)
	 * @create 2007/03/28
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || value.equals("")) {
			return null;
		}

		//		if ( getArgs() == null || getArgs().equals( "" ) )
		//		{
		//			throw new IllegalArgumentException( "\"" + getArgs() + "\" : Illegal args in "
		//					+ this.getClass().getSimpleName() + " of " + control.getId() + "." );
		//		}

		String[] prohibitionValues = getArgsAsStringArray(control);
		
		for (String prohibitionValue : prohibitionValues) {
			if (!GStringUtils.isEmpty(prohibitionValue) && value.contains(prohibitionValue)) {
				return createValidateError(control, locale);
			}
		}

		return null;
	}
	
}
