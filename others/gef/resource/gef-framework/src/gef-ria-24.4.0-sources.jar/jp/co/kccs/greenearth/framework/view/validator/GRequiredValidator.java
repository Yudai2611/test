/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 入力値の必須検証クラスです.<br>
 * <br>
 * 【概要】<br>
 * 　検証値が設定されているかどうかを検証します。<br>
 * 　検証値が設定されていない（null、または空文字）場合は{@link jp.co.kccs.greenearth.framework.data.GValidateError}を、
 * それ以外の場合は<code>null</code>を返します。<br>
 * <br>
 * 【対象コントロール】<br>
 * 　全てのUIコントロールにおいて検証可能です。<br>
 * <br>
 * 【検証用パラメータ】<br>
 * 　不要です。<br>
 * <br>
 * 【エラーコード】<br>
 * 　<code>GEF-000001</code><br>
 * 　<br>
 * 【エラーメッセージ】<br>
 * 　<code>入力してください</code><br>
 * 　<br>
 * 【例外】<br>
 * 　特にありません。<br>
 * <br>
 * 【備考】<br>
 * 　特にありません。<br>
 * 
 * @create 2007/02/05
 * @author okajima
 * @since 3.0.0
 */
public class GRequiredValidator extends GValidatorBase {

	/** シリアルバージョン.*/
	private static final long serialVersionUID = 8473826223599572370L;

	/** デフォルトのエラーコード. */
	public static final String DEFAULT_ERROR_CODE = "GEF-000001";

	/**
	 * デフォルトコンストラクタ.<br>
	 * デフォルトのエラーコードを設定します。
	 * 
	 * @create 2007/02/15
	 * @author aono
	 * @since 3.0.0
	 */
	public GRequiredValidator() {
		setErrorcode(DEFAULT_ERROR_CODE);
	}

	/**
	 * 必須入力を検証します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#validate(GUIControl, String, List, Locale)
	 * @create 2007/02/09
	 * @param control UIコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author aono
	 * @since 3.0.0
	 */
	public GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale) {
		if (value == null || "".equals(value)) {
			return createValidateError(control, locale);
		}
		return null;
	}
}
