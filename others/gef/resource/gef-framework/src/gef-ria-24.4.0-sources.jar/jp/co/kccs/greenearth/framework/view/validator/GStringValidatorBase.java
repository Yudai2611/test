/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

/**
 * {@link java.lang.String}型の検証クラスの基底クラス.
 * 
 * @create 2007/03/31
 * @author wadatani
 * @since 3.0.0
 */
public abstract class GStringValidatorBase extends GValidatorBase {

	/** シリアルバージョン. */
	private static final long serialVersionUID = -1067550301114810294L;

	/**
	 * デフォルトコンストラクタ.
	 * 
	 * @create 2007/03/31
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GStringValidatorBase() {
	}

}
