/*
 * Copyright 2007 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.io.Serializable;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * 検証クラスのインターフェイス定義.
 * 
 * @create 2007/02/09
 * @author aono
 * @since 3.0.0
 */
public interface GValidator extends Cloneable, Serializable {

	// ---- パブリックメソッド   ---------------------------------------------

	/**
	 * TODO [2007/05/07][kitamura]さすがにこれはなくしたいですね！
	 * このインスタンスの状態を基に、常用の{@link GValidator}（クローン）を生成します.
	 * 
	 * @create 2007/04/16
	 * @return 常用クローン
	 * @author wadatani
	 * @since 3.0.0
	 */
	GValidator createPracticalInstanse();

	/**
	 * 検証処理.<br>
	 * [1]発生済み検証エラー一覧に<code>null</code>を指定された場合は、
	 * 検証エラーがまだ発生していないものとして扱います。
	 * 
	 * @create 2007/02/09
	 * @param control uiコントロール
	 * @param value 検証値
	 * @param errors 発生済み検証エラー一覧
	 * @param locale ロケール
	 * @return 発生したエラー
	 * @author aono
	 * @since 3.0.0
	 */
	GValidateError validate(GUIControl control, String value, List<GValidateError> errors, Locale locale);

	// ---- パブリックプロパティ ---------------------------------------------

	/**
	 * 検証エラー発生時、後の検証を継続するかを取得します.
	 * 
	 * @create 2007/04/04
	 * @return <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	boolean isStop();

	/**
	 * 検証用パラメータを取得する.
	 * 
	 * @create 2007/02/09
	 * @return 検証用パラメータ
	 * @author aono
	 * @since 3.0.0
	 */
	String getArgs();

	/**
	 * 	エラーコードを取得する.
	 * 
	 * @create 2007/02/09
	 * @return エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	String getErrorcode();

	/**
	 * 出力エラーレベルを取得する.
	 * 
	 * @create 2007/02/09
	 * @return <code>error</code>/<code>warn</code>
	 * @author aono
	 * @since 3.0.0
	 */
	String getLevel();

	/**
	 * 検証エラー発生時、後の検証を継続するかを取得します.
	 * 
	 * @create 2007/04/04
	 * @return <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	String getStop();

	/**
	 * 検証用パラメータを設定する.
	 * 
	 * @create 2007/02/09
	 * @param args 検証用パラメータ
	 * @author aono
	 * @since 3.0.0
	 */
	void setArgs(String args);

	/**
	 * エラーコードを設定する.
	 * 
	 * @create 2007/02/09
	 * @param errorcode エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	void setErrorcode(String errorcode);

	/**
	 * 出力エラーレベルを設定する.<br>
	 *  error:検証で問題がある場合{@link GValidateError}を生成<br>
	 *  warn:検証で問題がある場合{@link GValidateWarning}を生成<br>
	 * 
	 * @create 2007/02/09
	 * @param level <code>error</code>/<code>warn</code>
	 * @author aono
	 * @since 3.0.0
	 */
	void setLevel(String level);

	/**
	 * 検証エラー発生時、後の検証を継続するかを指定します.
	 * 
	 * @create 2007/04/04
	 * @param stop <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	void setStop(String stop);
}
