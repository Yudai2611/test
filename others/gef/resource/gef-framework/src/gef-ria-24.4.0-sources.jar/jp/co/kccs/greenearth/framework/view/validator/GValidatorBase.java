/*
 * Copyright 2007-2013 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.view.validator;

import java.util.Locale;
import java.util.MissingResourceException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.GViewException;
import jp.co.kccs.greenearth.framework.view.component.GFormatControl;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * {@link GValidator}クラスの簡易実装クラスです.<br>
 * <br>
 * 【概要】<br>
 * 検証クラスの作成に必要な次の機能を提供します。<br>
 * 　1. {@link jp.co.kccs.greenearth.framework.view.component.taglib.GValidateTag}の属性情報を受け渡しするためのアクッセッサーメソッド<br>
 * 　2. {@link jp.co.kccs.greenearth.framework.view.component.taglib.GValidateTag}のlevel属性に合わせて、エラー情報を格納するのに必要なクラスの生成<br>
 * 　3. エラー情報に格納するエラーコードに紐付いたエラーメッセージの取得<br>
 * 　4. 検証用パラメータの配列への分割<br>
 * 　5. 検証用パラメータ配列の各種オブジェクトへの変換<br>
 * <br>
 * 【備考】<br>
 * 　1. 検証用パラメータ(<code>args</code>属性)に複数のパラメータを指定する場合、次のようにセパレータ文字列で区切る必要があります。<br>
 * <br>
 * <b>args="param01@@param02"</b><br>
 * <br>
 * 　2. セパレータ文字列は、次の優先順位で決定されます。<br>
 * 　　2.1. プロパティファイルのキー{@value #ARGS_SEPARATOR_PROPERTY}で指定された文字列<br>
 * 　　2.2. 文字列 {@value #DEFAULT_ARGS_SEPARATOR}<br>
 * <br>
 * 
 * @create 2007/02/09
 * @author aono
 * @since 3.0.0
 */
public abstract class GValidatorBase implements GValidator {

	/** シリアルバージョン. */
	private static final long serialVersionUID = 6714561489883341726L;

	/** プロパティより区切り文字を取得するためのキー. */
	private static final String ARGS_SEPARATOR_PROPERTY = "geframe.view.Validator.Args.Separator";

	/** 区切り文字(デフォルト値). */
	private static final String DEFAULT_ARGS_SEPARATOR = "@@";

	/** 検証値の解析フォーマットをコントロールのformat属性から取得する場合のキー. */
	public static final String ARGS_FORMAT_CONTROL = "control";

	/** 検証値の解析フォーマットをプロパティファイルから取得する場合のキー. */
	public static final String ARGS_FORMAT_PROPERTY = "property";

	/** 区切り文字. */
	public static final String ARGS_SEPARATOR = GFrameworkUtils.getProperty(ARGS_SEPARATOR_PROPERTY, DEFAULT_ARGS_SEPARATOR);

	// 拡張属性
	/** 検証用パラメータ. */
	private String _args = null;
	/** エラーコード. */
	private String _errorcode = null;
	/** エラー出力区分. */
	private String _level = null;
	/** 検証処理の継続指定. */
	private String _stop = "false";

	// ---- パブリックメソッド   ---------------------------------------------

	/**
	 * このインスタンスの状態を基に、常用の{@link GValidator}（クローン）を生成します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#createPracticalInstanse()
	 * @create 2007/04/16
	 * @return 常用クローン
	 * @author wadatani
	 * @since 3.0.0
	 */
	public GValidator createPracticalInstanse() {
		GValidator clone = null;

		try {
			clone = (GValidator) clone();
		}
		catch (CloneNotSupportedException e) {
			throw new GViewException(e);
		}

		return clone;
	}

	// ----- プロテクテッドメソッド -----------------------------------------------------------------------------------------------------
	/**
	 * エラーレベル指定に従ってエラーインスタンスを生成します.<br>
	 * エラーレベルに対応する{@link GErrorType}が設定された{@link GValidateError}のインスタンスを生成します。<br>
	 * エラーコード、エラーが発生したUIコントロールのID、エラーメッセージを設定してインスタンスを生成します。<br>
	 * 
	 * @create 2007/02/09
	 * @param control UIコントロール
	 * @param locale ロケール
	 * @return エラーインスタンス
	 * @author aono
	 * @since 3.0.0
	 */
	protected GValidateError createValidateError(GUIControl control, Locale locale) {
		GValidateError error = new GValidateError();

		if (getLevel() != null) {
			error.setType(GErrorType.convert(getLevel()));
		}
		else {
			error.setType(getErrorLevel(locale));
		}

		error.setCode(getErrorcode());
		error.addFieldId(GStringUtils.nullToBlank(control.getPrefix()) + control.getId());	// TODO: [2011/04/18][yamashita]prefix付きのIDを設定するよう変更。thinはname=idのため影響はなし。
		error.setMessage(getErrorMessage(locale));
		error.setLabel(control.getLabel());
		error.setLabelspace(control.getLabelspace());

		return error;
	}

	/**
	 * 検証用パラメータを文字列の配列として取得します.<br>
	 * 
	 * <code>ge-framework.properties</code>のキー{@value #ARGS_SEPARATOR_PROPERTY}に設定されたセパレート文字列を使用して配列を生成します。
	 * キーが設定されていない場合、デフォルトのセパレート文字列{@value #DEFAULT_ARGS_SEPARATOR}を使用します。<br>
	 * 
	 * 検証用パラメータが<code>null</code>の場合、{@link IllegalAccessException}が発生します。<br>
	 * 
	 * @create 2007/04/21
	 * @param control UIコントロール
	 * @return 文字列の配列
	 * @author okajima
	 * @since 3.0.0
	 */
	protected String[] getArgsAsStringArray(GUIControl control) {
		if (getArgs() != null) {
			String[] stringArray = getArgs().split(ARGS_SEPARATOR, -1);

			return stringArray;
		}

		// 検証用パラメータの取得失敗
		throw new IllegalArgumentException("\"" + getArgs() + "\" : Illegal args in " + this.getClass().getSimpleName() + " of " + control.getId() + ".");
	}

	/**
	 * インデックスで指定した位置の検証用パラメータの値を整数値として取得します.<br>
	 * 
	 * 検証用パラメータをセパレータで分割し、インデックス(<code>0</code>相対)で指定された位置の文字列を整数値として取得します。
	 * 整数値への変換は{@link Integer#parseInt(java.lang.String)}を利用しています。<br>
	 * 
	 * 指定したインデックスがパラメータで分割された数より大きい場合、{@link IndexOutOfBoundsException}が発生します。<br>
	 * 
	 * 指定したインデックスが<code>0</code>未満の場合、{@link IndexOutOfBoundsException}が発生します。<br>
	 * 
	 * 検証用パラメータが<code>null</code>の場合、{@link IllegalArgumentException}が発生します。<br>
	 * 
	 * @create 2007/04/21
	 * @param control UIコントロール
	 * @param index インデックス
	 * @return 整数値
	 * @author okajima
	 * @since 3.0.0
	 */
	protected int getArgsAsInteger(GUIControl control, int index) {
		String argument = getArgs(control, index);

		try {
			return Integer.parseInt(argument);
		}
		catch (NumberFormatException nfe) {
			throw new IllegalArgumentException("\"" + getArgs() + "\" : Illegal args in " + this.getClass().getSimpleName() + " of " + control.getId() + ".");
		}
	}

	/**
	 * 検証用パラメータを0以上の整数値として取得します.<br>
	 * セパレータで区切られた検証用パラメータの内、インデックス(<code>0相対<code>)で指定したパラメータを
	 * {@link Integer#parseInt(java.lang.String)}した値を取得します。<br>
	 * 指定したインデックス番号がパラメータ数より大きい場合、{@link IllegalAccessException}が発生します。<br>
	 * 指定したインデックス番号が0未満の場合、{@link IndexOutOfBoundsException}が発生します。<br>
	 * 検証用パラメータが<code>null</code>、整数値以外の場合、{@link IllegalAccessException}が発生します。<br>
	 * 検証用パラメータの値が0より小さい場合、{@link IllegalAccessException}が発生します。
	 * 
	 * @create 2007/04/21
	 * @param control UIコントロール
	 * @param index インデックス
	 * @return 正の整数値
	 * @author okajima
	 * @since 3.0.0
	 */
	protected int getArgsAsOverZeroInteger(GUIControl control, int index) {
		int integer = getArgsAsInteger(control, index);

		if (integer < 0) {
			throw new IllegalArgumentException("\"" + getArgs() + "\" : Illegal args in " + this.getClass().getSimpleName() + " of " + control.getId() + ".");
		}

		return integer;
	}

	/**
	 * インデックスで指定した位置の検証用パラメータの値を文字列として取得します.<br>
	 * 
	 * 検証用パラメータをセパレータで分割し、インデックス(<code>0</code>相対)で指定された位置の文字列を取得します。<br>
	 * 
	 * 指定したインデックスがパラメータで分割された数より大きい場合、{@link IndexOutOfBoundsException}が発生します。<br>
	 * 
	 * 指定したインデックスが<code>0</code>未満の場合、{@link IndexOutOfBoundsException}が発生します。<br>
	 * 
	 * 検証用パラメータが<code>null</code>の場合、{@link IllegalArgumentException}が発生します。<br>
	 * 
	 * @create 2007/04/25
	 * @param control UIコントロール
	 * @param index インデックス
	 * @return 整数値
	 * @author aono
	 * @since 3.0.0
	 */
	protected String getArgs(GUIControl control, int index) {
		String[] args = this.getArgsAsStringArray(control);
		if (index < 0 || args.length <= index) {
			throw new IllegalArgumentException("\"" + getArgs() + "\" " + index + " : Args index is out of bounds in " + this.getClass().getSimpleName() + " of " + control.getId() + ".");
		}
		return args[index];
	}

	/**
	 * {@link GValidator}のエラーコードに紐付いたエラーレベルを取得します.<br>
	 * 
	 * ロケールが<code>null</code>の場合、デフォルトのロケールを使用してエラーレベルを取得します。
	 * 
	 * @create 2007/04/25
	 * @param locale ロケール
	 * @return エラーレベル
	 * @author wadatani
	 * @since 3.0.0
	 */
	protected GErrorType getErrorLevel(Locale locale) {
		GErrorMessage errorMessage = null;

		if (locale != null) {
			errorMessage = GErrorMessages.getErrorMessage(getErrorcode(), locale);
		}
		else {
			errorMessage = GErrorMessages.getErrorMessage(getErrorcode());
		}

		if (errorMessage != null) {
			return errorMessage.getType();
		}
		else {
			throw new MissingResourceException("Error message resource not found.", getErrorcode(), getClass().getName());
		}
	}

	/**
	 * {@link GValidator}のエラーコードに紐付いたエラーメッセージを取得します.<br>
	 * 
	 * ロケールが<code>null</code>の場合、デフォルトのロケールを使用してエラーメッセージを取得します。
	 * 
	 * @create 2007/03/30
	 * @param locale ロケール
	 * @return エラーメッセージ
	 * @author wadatani
	 * @since 3.0.0
	 */
	protected String getErrorMessage(Locale locale) {
		GErrorMessage errorMessage = null;

		if (locale != null) {
			errorMessage = GErrorMessages.getErrorMessage(getErrorcode(), locale);
		}
		else {
			errorMessage = GErrorMessages.getErrorMessage(getErrorcode());
		}

		if (errorMessage != null) {
			return errorMessage.getMessage();
		}
		else {
			throw new MissingResourceException("Error message resource not found.", getErrorcode(), getClass().getName());
		}
	}

	/**
	 * 検証値解析用フォーマットをプロパティから取得するかどうかを判定します.<br>
	 * 
	 * セパレータで分割された検証用パラメータの第1文字列を取得し、
	 * その文字列が<code>"control"</code>の場合は<code>false</code>を返します。
	 * それ以外の場合の文字列の場合は<code>true</code>を返します。<br>
	 * 
	 * <code>args</code>属性の第一セパレータまでの値が<code>{@value #ARGS_FORMAT_CONTROL}</code>
	 * と等しい場合は<code>false</code>を返します。<br>
	 * ・それ以外の場合(<code>null</code>、空文字も含む)は<code>true</code>を返します。<br>
	 * 
	 * @create 2007/04/25
	 * @param control UIコントロール
	 * @return <code>true</code>/<code>false</code>
	 * @author aono
	 * @since 3.0.0
	 */
	protected boolean useControlFormat(GFormatControl control) {
		if (getArgs() == null) {
			return false;
		}
		
		String argument = getArgs(control, 0);
		return ARGS_FORMAT_CONTROL.equals(argument);
	}

	// ---- パブリックプロパティ ---------------------------------------------

	/**
	 * 検証用パラメータを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#getArgs()
	 * @create 2007/02/09
	 * @return 検証用パラメータ
	 * @author aono
	 * @since 3.0.0
	 */
	public String getArgs() {
		return _args;
	}

	/**
	 * 	エラーコードを取得します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#getErrorcode()
	 * @create 2007/02/09
	 * @return エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	public String getErrorcode() {
		return _errorcode;
	}

	/**
	 * 出力エラーレベルを取得します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#getLevel()
	 * @create 2007/02/09
	 * @return <code>error</code>/<code>warn</code>
	 * @author aono
	 * @since 3.0.0
	 */
	public String getLevel() {
		return _level;
	}

	/**
	 * 検証エラー発生時、後の検証を継続するかを取得します.
	 * 
	 * @create 2007/04/04
	 * @return <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public String getStop() {
		return _stop;
	}

	/**
	 * 検証エラー発生時、後の検証を継続するかを取得します.
	 * 
	 * @create 2007/04/04
	 * @return <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public boolean isStop() {
		return GBooleanUtils.toBoolean(_stop, false);
	}

	/**
	 * 検証用パラメータを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#setArgs(java.lang.String)
	 * @create 2007/02/09
	 * @param args 検証用パラメータ
	 * @author aono
	 * @since 3.0.0
	 */
	public void setArgs(String args) {
		_args = args;

	}

	/**
	 * エラーコードを設定します.
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#setErrorcode(java.lang.String)
	 * @create 2007/02/09
	 * @param errorcode エラーコード
	 * @author aono
	 * @since 3.0.0
	 */
	public void setErrorcode(String errorcode) {
		_errorcode = errorcode;

	}

	/**
	 * 出力エラーレベルを設定します.<br>
	 *  <code>error</code>:検証で問題がある場合{@link GValidateError}を生成<br>
	 *  <code>warn</code>:検証で問題がある場合{@link GValidateWarning}を生成<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.view.validator.GValidator#setLevel(java.lang.String)
	 * @create 2007/02/09
	 * @param level <code>error</code>/<code>warn</code>
	 * @author aono
	 * @since 3.0.0
	 */
	public void setLevel(String level) {
		_level = level;
	}

	/**
	 * 検証エラー発生時、後の検証を継続するかを指定します.
	 * 
	 * @create 2007/04/04
	 * @param stop <code>true</code>/<code>false</code>
	 * @author okajima
	 * @since 3.0.0
	 */
	public void setStop(String stop) {
		_stop = stop;
	}
}
