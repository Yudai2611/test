/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.commons.provider;

import java.lang.reflect.Type;
import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * GProviderServiceのインターフェースを定義します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public interface GProviderService {

	/**
	 * パラメータclazzにより、サービス情報を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param clazz クラス
	 * @return サービス情報
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	<T> T getService(Class<T> clazz);
	
	/**
	 * パラメータtoにより、サービス情報を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param type タイプ
	 * @return サービス情報
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	<T> T getService(Type type);

	/**
	 * パラメータclazzにより、サービス情報リストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param clazz クラス
	 * @return サービス情報リスト
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	<T> List<T> getServices(Class<T> clazz);

	/**
	 * パラメータbindにより、バインダーを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param bind バインダー
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	<T> void register(T bind);
	
	/**
	 * パラメータbind と toにより、バインダーを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param bind バインダー
	 * @param to タイプ
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	<T> void register(T bind, Type to);
	
	/**
	 * パラメータbind、to と singletonにより、バインダーを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param bind バインダー
	 * @param to タイプ
	 * @param singleton シングルトン
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	<T> void register(T bind, Type to, boolean singleton);
	
	/**
	 * パラメータbind、to、priority と singletonにより、バインダーを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param bind バインダー
	 * @param to タイプ
	 * @param priority プライオリティ
	 * @param singleton シングルトン
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	<T> void register(T bind, Type to, Integer priority, boolean singleton);

	/**
	 * GProviderServiceのインスタンスを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return GProviderService
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	static GProviderService getInstance() {
		return GFrameworkUtils.getComponent(GProviderService.class.getName());
	}
}
