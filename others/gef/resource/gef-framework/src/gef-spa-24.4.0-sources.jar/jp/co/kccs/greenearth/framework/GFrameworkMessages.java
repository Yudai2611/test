/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

/**
 * メッセージのキーと値を定義します.<br>
 * 主に、例外やロギングメッセージなどで利用される汎用的なメッセージを取り扱います.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public enum GFrameworkMessages {
	CSRF_TOKEN_VERIFICATION_IS_FAILED("Csrf Token verification is failed. Csrf Token is mismatched."),
	$s_INVOKE_STARTED("%s invoke started."),
	$s_APPLY_STARTED("%s apply started."),
	$s_INIT_STARTED("%s init started."),
	$s_DESTROY_STARTED("%s destroy started."),
	$s_PROCESS_STARTED("%s process started."),
	$s_SERVICE_STARTED("%s service started."),
	$s_RESOLVE_STARTED("%s resolve started."),
	$s_WRITE_STARTED("%s write started."),
	WRITTEN_AN_EMPTY_BODY("Written an empty body."),
	AN_IO_ERROR_HAS_OCCURRED_$s("An I/O error has occurred %s."),
	$s_IS_DUPLICATED("%s is duplicated."),
	DECLARED_METHOD_PARAMETER_AND_CREATED_PARAMETER_LENGTH_DONT_MATCH("The declered method parameter and created method parameter length don't match."),
	FAILED_TO_INSTANTIATE_$s("Failed to instantiate %s."),
	FAILED_TO_PARSE_$s("Failed to parse %s."),
	$s_CAN_NOT_BE_CREATED("%s can not be created."),
	$s_IS_NOT_FOUND("%s is not found."),
	$s_IS_NOT_SUPPORTED("%s is not supported."),
	$s_MUST_BE_REQUIRED("%s must be required."),
	$s_MUST_BE_INITIALIZED("%s must be initialized."),
	AUTHENTICATION_FAILED_DUE_TO_$s("Authentication failed due to %s."),
	VALUE_OF_$s_CANNOT_BE_$s("Value of %s cannot be %s."),
	NOT_CONCRETE_CLASS_OF_REQUEST("The concrete class of request must be %s."),
	PERCENT_ENCODED_IN_CONTEXTPATH_ANDOR_SERVLETPATH("The servlet context path and/or the servlet path contain characters that are percent encoded."),
	$s_SHOULD_ONLY_DEFINED_ONCE("%s should be only defined once in %s.");
	
	private String message;
	
	GFrameworkMessages(String message) {
		this.message = message;
	}
	
	public String message() {
		return message;
	}
	
	public String message(Object... args) {
		return String.format(message(), args);
	}
	
	public static String canNotBeCreated(Object arg) {
		return $s_CAN_NOT_BE_CREATED.message(arg);
	}
	
	public static String mustBeRequired(Object arg) {
		return $s_MUST_BE_REQUIRED.message(arg);
	}

	public static String mustBeInitialized(Object arg) {
		return $s_MUST_BE_INITIALIZED.message(arg);
	}

	public static String failedToInstantiate(Object arg) {
		return FAILED_TO_INSTANTIATE_$s.message(arg);
	}
	
	public static String failedToParse(Object arg) {
		return FAILED_TO_PARSE_$s.message(arg);
	}
	
	public static String isNotFound(Object arg) {
		return $s_IS_NOT_FOUND.message(arg);
	}
	
	public static String isNotSupported(Object arg) {
		return $s_IS_NOT_SUPPORTED.message(arg);
	}
	
	public static String isDuplicated(Object arg) {
		return $s_IS_DUPLICATED.message(arg);
	}
	
	public static String shouldOnlyDefinedOnce(Object arg, Object in) {
		return $s_SHOULD_ONLY_DEFINED_ONCE.message(arg, in);
	}
	
	public static String shouldOnlyDefinedOnceInSecurityRule(Object arg) {
		return $s_SHOULD_ONLY_DEFINED_ONCE.message(arg, "security rule");
	}
	
	public static String shouldOnlyDefinedOnceInCorsConfiguration(Object arg) {
		return $s_SHOULD_ONLY_DEFINED_ONCE.message(arg, "cors configuration");
	}
	
	public static String authenticationFailedDueTo(Object arg) {
		return AUTHENTICATION_FAILED_DUE_TO_$s.message(arg);
	}

	public static String notConcreteClassOfRequest(Object arg) {
		return NOT_CONCRETE_CLASS_OF_REQUEST.message(arg);
	}
	
	public static String anIOErrorHasOccuOccurred(Object arg) {
		return AN_IO_ERROR_HAS_OCCURRED_$s.message(arg);
	}
}
