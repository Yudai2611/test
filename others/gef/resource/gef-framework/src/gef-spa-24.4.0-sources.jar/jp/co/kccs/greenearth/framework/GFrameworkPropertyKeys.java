/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * フレームワークプロパティファイルのキーと値を定義します.
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public enum GFrameworkPropertyKeys {
	GEFRAME_SPA_WEB_RESOURCE_ENDPOINT_HTTP_METHOD_DEFAULT("geframe.spa.web.resource.endpoint.HttpMethod.Default"),
	GEFRAME_SPA_WEB_RESOURCE_ENDPOINT_CONSUMES_DEFAULT("geframe.spa.web.resource.endpoint.Consumes.Default"),
	GEFRAME_SPA_WEB_RESOURCE_ENDPOINT_PRODUCES_DEFAULT("geframe.spa.web.resource.endpoint.Produces.Default"),
	GEFRAME_SPA_WEB_RESOURCE_METHOD_ARGUMENT_ENCODED_DEFAULT("geframe.spa.web.resource.method.parameter.Encoded.Default"),
	GEFRAME_SPA_WEB_SERVER_RESPONSE_CHUNKED_THRESHOLD_SIZE("geframe.spa.web.server.response.Chunked.ThresholdSize"),
	GEFRAME_SPA_WEB_SERVER_RESPONSE_ERROR_CONTENT_ENABLE_DEFAULT("geframe.spa.web.server.response.error.Content.Enable.Default");
	private String key;
	GFrameworkPropertyKeys(String key) {
		this.key = key;
	}
	public String getKey() {
		return key;
	}
	public String getValue() {
		return GFrameworkUtils.getProperty(getKey());
	}
	public String getValue(String defaultValue) {
		return GFrameworkUtils.getProperty(getKey(), defaultValue);
	}
}
