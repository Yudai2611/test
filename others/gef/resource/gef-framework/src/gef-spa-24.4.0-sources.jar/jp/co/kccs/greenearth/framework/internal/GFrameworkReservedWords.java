/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.internal;

/**
 * 予約語を定義します.
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public enum GFrameworkReservedWords {
	HEADER_NAME_ACTION_BEAN("X-Action-Bean"),
	HEADER_NAME_ACTION_METHOD("X-Action-Method"),
	HEADER_NAME_CSRF_TOKEN("X-Csrf-Token"),
	PARAMETER_NAME_ACTION_BEAN("actionbean"),
	PARAMETER_NAME_ACTION_METHOD("actionmethod"),
	PARAMETER_NAME_CSRF_TOKEN("csrf_token");
	
	private String key;
	
	GFrameworkReservedWords(String key) {
		this.key = key;
	}
	public String key() {
		return key;
	}
}
