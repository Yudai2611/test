/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web;

import jakarta.ws.rs.ProcessingException;

/**
 * HTTPリクエストまたはレスポンスをハンドリングする一連のコンテナプロセス（フィルター、サーブレットなど）におけるランタイム例外を表します.
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GContainerException extends ProcessingException {

	public GContainerException(Throwable cause) {
		super(cause);
	}

	public GContainerException(Throwable cause, String message) {
		super(message, cause);
	}
	
	public GContainerException(String message) {
		super(message);
	}

	public GContainerException(Throwable cause, String... messages) {
		this(cause, String.join("", messages));
	}

	public GContainerException(String... messages) {
		this(String.join("", messages));
	}

}
