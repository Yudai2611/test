package jp.co.kccs.greenearth.framework.web;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

import org.springframework.web.util.ContentCachingRequestWrapper;

import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

/**
 * HttpServletRequestをラップして、Inputstreamをキャシューします. <br/>
 * キャシューされたInputstreamは何回も読まれることになります. <br/>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GContentCachingServletRequest extends HttpServletRequestWrapper {
	private ContentCachingRequestWrapper requestDelegate;
	private ServletInputStream inputStream;

	public GContentCachingServletRequest(HttpServletRequest request) {
		super(new ContentCachingRequestWrapper(request));
		requestDelegate = (ContentCachingRequestWrapper) getRequest();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see HttpServletRequestWrapper#getInputStream()
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public ServletInputStream getInputStream() {
		if (Objects.isNull(inputStream)) {
			try {
				inputStream = super.getInputStream();
				return inputStream;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(requestDelegate.getContentAsByteArray());
		byteArrayInputStream.reset();
		inputStream = new GServletInputStream(byteArrayInputStream);
		return inputStream;
	}
	private static class GServletInputStream extends ServletInputStream {
		private InputStream inputStream;
		private boolean finished = false;
		public GServletInputStream(InputStream inputStream) {
			this.inputStream = inputStream;
		}
		@Override
		public boolean isFinished() {
			return this.finished;
		}

		@Override
		public boolean isReady() {
			return true;
		}

		@Override
		public void setReadListener(ReadListener readListener) {
			throw new UnsupportedOperationException();
		}

		@Override
		public int read() throws IOException {
			int data = inputStream.read();
			if (this.finished) {
				inputStream.reset();
			}
			if (data == -1) {
				this.finished = true;
			}
			return data;
		}
	}
}