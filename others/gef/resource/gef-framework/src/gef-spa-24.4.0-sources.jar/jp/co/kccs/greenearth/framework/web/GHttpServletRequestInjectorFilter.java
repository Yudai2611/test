package jp.co.kccs.greenearth.framework.web;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;

/**
 * {@link HttpServletRequest}を{@link GContentCachingServletRequest}にラップして、次のチェインに渡す為のフィルターです. <br/>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GHttpServletRequestInjectorFilter implements Filter {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see GHttpServletRequestInjectorFilter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		chain.doFilter(new GContentCachingServletRequest((HttpServletRequest) request), response);
	}
}
