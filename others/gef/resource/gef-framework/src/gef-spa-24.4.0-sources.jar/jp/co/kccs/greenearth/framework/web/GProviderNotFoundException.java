/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web;

/**
 * {@link jakarta.ws.rs.ext.Provider}の決定おけるランタイム例外クラスです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GProviderNotFoundException extends GContainerException {

	public GProviderNotFoundException(Throwable cause) {
		super(cause);
	}

	public GProviderNotFoundException(Throwable cause, String message) {
		super(cause, message);
	}
	
	public GProviderNotFoundException(String message) {
		super(message);
	}

	public GProviderNotFoundException(Throwable cause, String... messages) {
		super(cause, String.join("", messages));
	}

	public GProviderNotFoundException(String... messages) {
		super(String.join("", messages));
	}
}
