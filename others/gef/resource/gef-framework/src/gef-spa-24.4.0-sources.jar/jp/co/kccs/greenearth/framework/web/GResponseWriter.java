/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web;

import java.io.OutputStream;

/**
 * HTTPレスポンスに出力すうｒためのインタフェースを規定します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GResponseWriter {

	/**
	 * レスポンスヘッダーを書き込みます.<br/>
	 * 
	 * @create 2023/10/25
	 * @param response レスポンス
	 * @param contentLength コンテンツ長
	 * @return レスポンスストリーム
	 * @throws GContainerException ヘッダーまたはステータスの書き込みに失敗した場合
	 * @author yamashita
	 * @since 23.10.0
	 */
	OutputStream writeStatusAndHeaders(GWebResponse response, long contentLength) throws GContainerException;

	/**
	 * レスポンスボディを書き込みます.<br/>
	 * 
	 * @create 2023/10/25
	 * @param response レスポンス
	 * @return レスポンスストリーム
	 * @throws GContainerException レスポンスボディの書き込みに失敗した場合
	 * @author yamashita
	 * @since 23.10.0
	 */
	OutputStream write(GWebResponse response) throws GContainerException;
	
	/**
	 * レスポンスをコミットします.<br>
	 * 
	 * @create 2023/10/25
	 * @throws GContainerException レスポンスストリームへのコミットに失敗した場合
	 * @author yamashita
	 * @since 23.10.0
	 */
	void commit() throws GContainerException;

	/**
	 * エラー情報を書き込みます.<br/>
	 * 
	 * @create 2023/10/25
	 * @param error エラー
	 * @author yamashita
	 * @since 23.10.0
	 */
	void failure(Throwable error);
}
