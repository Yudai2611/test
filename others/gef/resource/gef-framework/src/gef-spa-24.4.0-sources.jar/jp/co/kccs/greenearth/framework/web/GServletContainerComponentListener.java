package jp.co.kccs.greenearth.framework.web;

import java.util.Objects;
import java.util.Set;

import jakarta.annotation.Priority;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.priority.GPriority;

/**
 * {@link GHttpServletRequestInjectorFilter}をフィルターチェインの先頭に追加する為のリステナーです. <br/>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@WebListener
public class GServletContainerComponentListener implements ServletContextListener {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see GServletContainerComponentListener#contextInitialized(ServletContextEvent)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        FilterRegistration.Dynamic filter = sce.getServletContext().addFilter(GHttpServletRequestInjectorFilter.class.getCanonicalName(), GHttpServletRequestInjectorFilter.class);
        if (Objects.nonNull(filter)) {
            filter.addMappingForUrlPatterns(null, false, "/*");
        }
    }
}