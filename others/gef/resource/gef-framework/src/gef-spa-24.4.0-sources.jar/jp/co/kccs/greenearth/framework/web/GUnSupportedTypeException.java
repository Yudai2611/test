/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web;

/**
 * サポートする型変換におけるランタイム例外クラスです。
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GUnSupportedTypeException extends GContainerException {

	public GUnSupportedTypeException(Throwable cause) {
		super(cause);
	}

	public GUnSupportedTypeException(Throwable cause, String message) {
		super(cause, message);
	}
	
	public GUnSupportedTypeException(String message) {
		super(message);
	}

	public GUnSupportedTypeException(Throwable cause, String... messages) {
		super(cause, String.join("", messages));
	}

	public GUnSupportedTypeException(String... messages) {
		super(String.join("", messages));
	}
}
