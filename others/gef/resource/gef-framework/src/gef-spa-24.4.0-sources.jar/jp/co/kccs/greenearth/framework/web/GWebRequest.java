/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Optional;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ResourceInfo;
import jp.co.kccs.greenearth.framework.web.http.GHttpHeaders;

/**
 * JAX-RS規定のHTTPリクエストを表現します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GWebRequest extends ContainerRequestContext, GHttpHeaders {

	/**
	 * HTTPメッセージボディ(エンティティボディ)を読み取ります.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param rawType 読み込む型
	 * @return 値
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> T readEntity(final Class<T> rawType);
	
	/**
	 * HTTPメッセージボディ(エンティティボディ)を読み取ります.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param rawType 読み込む型
	 * @param annotations アノテーション
	 * @return 値
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> T readEntity(final Class<T> rawType, final Annotation[] annotations);
	
	/**
	 * HTTPメッセージボディ(エンティティボディ)を読み取ります.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param rawType 読み込む型
	 * @param type 読み込むタイプ
	 * @return 値
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> T readEntity(final Class<T> rawType, final Type type);
	
	/**
	 * HTTPメッセージボディ(エンティティボディ)を読み取ります.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param rawType 読み込む型
	 * @param type 読み込むタイプ
	 * @param annotations アノテーション
	 * @return 値
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> T readEntity(final Class<T> rawType, final Type type, final Annotation[] annotations);
	
	/**
	 * {@link GResponseWriter}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GResponseWriter}
	 * @author yamashita
	 * @since 23.10.0
	 */
	GResponseWriter getResponseWriter();
	
	/**
	 * ネイティブリクエスト(生成元となるリクエストオブジェクト)を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return ネイティブリクエスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> T getNativeRequest();
	
	/**
	 * ネイティブレスポンス(生成元となるレスポンスオブジェクト)を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return ネイティブレスポンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> T getNativeResponse();
	<T extends ResourceInfo> Optional<T> getResource();
}
