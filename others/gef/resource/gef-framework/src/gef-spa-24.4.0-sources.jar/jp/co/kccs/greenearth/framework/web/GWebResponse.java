/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web;

import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * JAX-RS規定のHTTPレスポンスを表現します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GWebResponse extends ContainerResponseContext {
	/**
	 * リクエストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return リクエスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	GWebRequest getWebRequest();
	/**
	 * レスポンスを取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return レスポンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	Response getResponse();
	
	/**
	 * ネイティブレスポンス(生成元となるレスポンスオブジェクト)を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return ネイティブレスポンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> T getNativeResponse();
	
	/**
	 * レスポンスストリームをコミットします.<br/>
	 * 
	 * @create 2023/10/25
	 * @throws GContainerException レスポンスストリームへのコミットに失敗した場合
	 * @author yamashita
	 * @since 23.10.0
	 */
	void commitStream() throws GContainerException;

	/**
	 * レスポンスストリームがコミットされているかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return true: コミット済 / false: 未コミット
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean isCommitted();
	
	/**
	 * レスポンスストリームを閉じます.<br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void close();
	
	// boolean isChunked();
	
	/**
	 * メディアタイプを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getMediaType()
	 * @return メディアタイプ
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	MediaType getMediaType();
	
	/**
	 * メディアタイプを設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param mediaType メディアタイプ
	 * @author yamashita
	 * @since 23.10.0
	 */
	void setMediaType(MediaType mediaType);

	/**
	 * 転送方式(通常レスポンスまたはチャンクレスポンス)の閾値を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 閾値
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	int getChunkedThresholdSize();
}
