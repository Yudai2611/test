/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

/**
 * {@link GResourceConfigurator}インターフェースを実装する基底クラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public abstract class GAbstractResourceConfigurator implements GResourceConfigurator {
	
	@Override
	public abstract void configure(GFeatureContext context);
	
}
