/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

import java.util.List;
import java.util.Map;

import jakarta.ws.rs.core.FeatureContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * JAX-RSコンポーネントクラス、プロパティなどの構成を管理するインターフェースです.<br>
 * {@link jp.co.kccs.greenearth.framework.web.configuration.GResourceConfigurator}から登録します.<br> 
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public interface GFeatureContext extends FeatureContext {
}
