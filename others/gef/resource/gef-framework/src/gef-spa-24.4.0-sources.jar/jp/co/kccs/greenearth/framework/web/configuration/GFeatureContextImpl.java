/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

import jakarta.ws.rs.core.Configurable;
import jakarta.ws.rs.core.Configuration;
import jakarta.ws.rs.core.FeatureContext;
import jp.co.kccs.greenearth.commons.provider.GProviderService;

import java.util.Map;

/**
 * {@link GFeatureContext}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GFeatureContextImpl implements GFeatureContext {
	/** delegate **/
	private Configurable<?> configurableDelegate;

	/**
	 * コンストラクタ
	 *
	 * @create 2024/04/30
	 * @param configurable
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GFeatureContextImpl(Configurable<?> configurable) {
		this.configurableDelegate = configurable;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#getConfiguration()
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Configuration getConfiguration() {
		return configurableDelegate.getConfiguration();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#property(String, Object)
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext property(String name, Object value) {
		if (!getConfiguration().hasProperty(name)) {
			configurableDelegate.property(name, value);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Class)
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Class<?> componentClass) {
		if (!configurableDelegate.getConfiguration().isRegistered(componentClass)) {
			configurableDelegate.register(componentClass);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Class, int)
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Class<?> componentClass, int priority) {
		if (!configurableDelegate.getConfiguration().isRegistered(componentClass)) {
			configurableDelegate.register(componentClass, priority);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Class, Class[])
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Class<?> componentClass, Class<?>... contracts) {
		if (!configurableDelegate.getConfiguration().isRegistered(componentClass)) {
			configurableDelegate.register(componentClass, contracts);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Class, Map)
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Class<?> componentClass, Map<Class<?>, Integer> contracts) {
		if (!configurableDelegate.getConfiguration().isRegistered(componentClass)) {
			configurableDelegate.register(componentClass, contracts);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Object)
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Object component) {
		if (!configurableDelegate.getConfiguration().isRegistered(component)) {
			configurableDelegate.register(component);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Object, int)
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Object component, int priority) {
		if (!configurableDelegate.getConfiguration().isRegistered(component)) {
			configurableDelegate.register(component, priority);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Object, Class[])
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Object component, Class<?>... contracts) {
		if (!configurableDelegate.getConfiguration().isRegistered(component)) {
			configurableDelegate.register(component, contracts);
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFeatureContext#register(Object, Map)
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public FeatureContext register(Object component, Map<Class<?>, Integer> contracts) {
		if (!configurableDelegate.getConfiguration().isRegistered(component)) {
			configurableDelegate.register(component, contracts);
		}
		return this;
	}
}
