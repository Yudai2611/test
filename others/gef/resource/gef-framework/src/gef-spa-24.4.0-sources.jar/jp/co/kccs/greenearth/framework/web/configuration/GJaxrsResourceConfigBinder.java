/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

import jakarta.ws.rs.core.Configurable;

/**
 * JAX-RS関連リソースを追加するためのインタフェースです.<br>
 * 対象とするリソースタイプ({@link ResourceType#value()})を関連付けし、<br>
 * {@link GJaxrsResourceConfigBinderFactory}を通して利用します。<br/>
 * 
 * @create 2024/04/30
 * @author yamashita
 * @since 24.4.0
 */
public interface GJaxrsResourceConfigBinder {

	/**
	 * 指定したコンフィグレーション({@link Configurable})に各種リソースを追加します.<br>
	 * 
	 * @create 2024/04/30
	 * @param config コンフィグレーション
	 * @author yamashita
	 * @since 24.4.0
	 */
	void bind(Configurable<?> config);
}
