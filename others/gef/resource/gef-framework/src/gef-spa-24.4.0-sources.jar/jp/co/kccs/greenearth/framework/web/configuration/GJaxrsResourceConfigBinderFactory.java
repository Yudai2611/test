/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GJaxrsResourceConfigBinder}のインスタンスを生成します.<br>
 * 
 * 
 * @create 2024/04/30
 * @author yamashita
 * @since 24.4.0
 */
public interface GJaxrsResourceConfigBinderFactory {
	
	/**
	 * 指定したリソースタイプ({@link ResourceType#value()})をターゲットとする{@link GJaxrsResourceConfigBinder}の一覧を取得します.<br>
	 * 
	 * @param bindClass {@link GJaxrsResourceConfigBinder}がターゲットとするリソースタイプ
	 * @return {@link GJaxrsResourceConfigBinder}インスタンスの一覧
	 * @create 2024/04/30
	 * @author yamashita
	 * @since 24.4.0
	 */
	List<GJaxrsResourceConfigBinder> getBinders(Class<?> bindClass);

	/**
	 * {@link GJaxrsResourceConfigBinderFactory}のインスタンスを取得します.<br>
	 * 
	 * @return {@link GJaxrsResourceConfigBinderFactory}インスタンス
	 * @create 2024/04/30
	 * @author yamashita
	 * @since 24.4.0
	 */
	static GJaxrsResourceConfigBinderFactory getInstance() {
		return GFrameworkUtils.getComponent(GJaxrsResourceConfigBinderFactory.class.getName());
	}
}
