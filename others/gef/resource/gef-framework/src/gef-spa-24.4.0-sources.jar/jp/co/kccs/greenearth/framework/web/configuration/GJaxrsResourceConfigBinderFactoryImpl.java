/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;

/**
 * {@link GJaxrsResourceConfigBinder}のインスタンスを生成します.<br>
 *
 * @create 2024/04/30
 * @author yamashita
 * @since 24.4.0
 */
@ScanConfiguration(
		modifiers = {
			@Modifier(
				isPublic = true
			)
		},
		scannedAnnotations = ResourceType.class,
		scannedAssignableTypes = GJaxrsResourceConfigBinder.class)
public class GJaxrsResourceConfigBinderFactoryImpl implements GJaxrsResourceConfigBinderFactory {

	private Map<Class<?>, List<GJaxrsResourceConfigBinder>> cachedInstances = null;
	private final List<GJaxrsResourceConfigBinder> EMPTY_LIST = new ArrayList<>();

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2024/04/30
	 * @see GJaxrsResourceConfigBinderFactory#getBinders(Class)
	 * @param bindType {@link GJaxrsResourceConfigBinder}がターゲットとするリソースタイプ
	 * @return {@link GJaxrsResourceConfigBinder}インスタンスの一覧
	 * @author yamashita
	 * @since 24.4.0
	 */
	@Override
	public List<GJaxrsResourceConfigBinder> getBinders(Class<?> bindType) {
		List<GJaxrsResourceConfigBinder> value = getCachedInstances().get(bindType);
		if (value == null) {
			value = entryIntoCache(bindType);
		}
		return Collections.unmodifiableList(value);
	}
	
	private List<GJaxrsResourceConfigBinder> entryIntoCache(Class<?> bindType) {
		Optional<?> optional = getCachedInstances().keySet().stream()
				.filter(bindTypeKey -> bindTypeKey.isAssignableFrom(bindType))
				.findFirst();
		getCachedInstances().put(bindType,
				optional.isPresent() ? getCachedInstances().get(optional.get()) : EMPTY_LIST);
		return getCachedInstances().get(bindType);
	}

	private Map<Class<?>, List<GJaxrsResourceConfigBinder>> getCachedInstances() {
		synchronized (this) {
			if (cachedInstances == null) {
				initCachedInstances();
			}
		}
		return cachedInstances;
	}

	private void initCachedInstances() {
		cachedInstances = new ConcurrentHashMap<>();
		List<GJaxrsResourceConfigBinder> binders = GScanComponentService.getInstance().getScannedInstances(getClass());
		binders.stream().forEach(binder -> {
			Class<?> bindType = binder.getClass().getAnnotation(ResourceType.class).value();
			if (!cachedInstances.containsKey(bindType)) {
				cachedInstances.put(bindType, new ArrayList<>());
			}
			if (!cachedInstances.get(bindType).contains(binder)){
				cachedInstances.get(bindType).add(binder);
			}
		});
	}
}
