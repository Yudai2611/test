/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

import java.util.Map;
import java.util.Objects;

import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import org.glassfish.jersey.server.ResourceConfig;

import jakarta.ws.rs.core.Configuration;
import jp.co.kccs.greenearth.framework.web.server.internal.GInjectionManagerHolder;

/**
 * {@link ResourceConfig}からプロパティを提供するためのクラスです。<br>
 * 
 * @create 2024/04/30
 * @author KCCS dhiaz chebastian
 * @since 24.4.0
 */
public final class GResourceConfigurationProperties {

    public static final String GEFRAME_SPA_RESOURCE_CONFIG_INVOCATION_HANDLER_ENABLED = "geframe.spa.resource.config.InvocationHandler.Enabled";
    public static final String GEFRAME_SPA_WEB_APPLICATION_EXCEPTION_ENTITY_IS_NULL_HANDLER_ENABLED = "geframew.spa.exception.config.WebApplicationExceptionEntityNullHandler.Enabled";
    public GResourceConfigurationProperties() {
    }


    /**
     * {@link ResourceConfig}からプロパティを取得します。<br>
     * 
     * @create 2024/04/30
     * @param key
     * @return {@link Object}
     * @author KCCS dhiaz chebastian
     * @since 24.4.0
     */
    public static Object getValue(String key) {
        return getJerseyResourceConfig().getProperty(key);
    }

    /**
     * {@link ResourceConfig}からプロパティを取得します。nullの場合、引数から渡される値をデフォルトになります。<br>
     * 
     * @create 2024/04/30
     * @param key
     * @param defaultValue
     * @return {@link Object}
     * @author KCCS dhiaz chebastian
     * @since 24.4.0
     */
    public static Object getValue(String key, Object defaultValue) {
        Object value =  getJerseyResourceConfig().getProperty(key);
        if (Objects.isNull(value)) {
            return defaultValue;
        }
        return value;
    }

    /**
     * {@link ResourceConfig}からプロパティのマップを取得します。<br>
     * 
     * @create 2024/04/30
     * @return {@link Map}
     * @author KCCS dhiaz chebastian
     * @since 24.4.0
     */
    public static Map<String, Object> getProperties() {
        return getJerseyResourceConfig().getProperties();
    }


    
    private static ResourceConfig getJerseyResourceConfig() {
        Configuration configuration = GInjectionManagerHolder.getInjectionManager().getInstance(Configuration.class);
        if (configuration instanceof ResourceConfig) {
            return (ResourceConfig) configuration;
        }
        throw new GContainerException(GFrameworkMessages.isNotFound(ResourceConfig.class.getName()));
    }
}
