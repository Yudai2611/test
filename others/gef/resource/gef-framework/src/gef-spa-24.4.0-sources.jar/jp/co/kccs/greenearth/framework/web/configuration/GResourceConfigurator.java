/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

/**
 * アプリケーションを構成するインターフェースです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public interface GResourceConfigurator {
	
	/**
	 * {@link GFeatureContext}へ設定を実行します。<br>
	 * 
	 * @create 2023/10/25
	 * @param context
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	void configure(GFeatureContext context);
}
