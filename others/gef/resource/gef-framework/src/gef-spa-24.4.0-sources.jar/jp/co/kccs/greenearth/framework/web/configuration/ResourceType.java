/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.configuration;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 抽象的なリソースタイプを表現するアノテーションです.<br>
 * 
 * <pre>
 * {@code
 *  [example]
 *  
 *  @ResourceType(ResourceConfig.class)
 *  public class GResourceConfiguratorAggregator implements GJaxrsResourceConfigBinder {
 *  ...
 *  }
 * }
 * </pre>
 * 
 * @create 2024/04/30
 * @author yamashita
 * @since 24.4.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ResourceType {

	Class<?> value();
}
