/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter;

import java.util.Optional;

import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;

/**
 * 一連のリクエストフィルターを実行します.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GContainerRequestFilterStage {

	/**
	 * リクエストフィルター({@link jakarta.ws.rs.container.ContainerRequestFilter})チェインを実行します. <br/>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return レスポンス結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GWebResponse> apply(GWebRequest webRequest) throws Throwable;

}
