/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter;


import java.util.Objects;
import java.util.Optional;

import jakarta.ws.rs.container.ContainerRequestFilter;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.filter.context.GFilterChainContextHolder;
import jp.co.kccs.greenearth.framework.web.internal.GContainerResponse;

/**
 *
 * @create 2023/10/25
 * @see GContainerRequestFilterStage
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GContainerRequestFilterStageImpl implements GContainerRequestFilterStage {
	/** {@link GFilterMatcher} **/
	private GFilterMatcher filterMatcher;
	/** 有効される{@link GFilterChainConfiguration} **/
	private GFilterChainConfiguration filterChainConfiguration;

	public GContainerRequestFilterStageImpl(GFilterChainConfiguration configuration) {
		this.filterChainConfiguration = configuration;
		this.filterMatcher = new GFilterMatcherImpl(configuration);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GContainerRequestFilterStage#apply(GWebRequest)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GWebResponse> apply(GWebRequest webRequest) throws Throwable {
		for (ContainerRequestFilter filter : filterChainConfiguration.getRequestFilters()) {
			if (Objects.nonNull(filter) && !isExcluded(filter.getClass(), webRequest)) {
				filter.filter(webRequest);
			}
			if (GFilterChainContextHolder.getContext().hasAbortResponse()) {
				return Optional.of(new GContainerResponse(webRequest, GFilterChainContextHolder.getContext().getAbortResponse().get()));
			}
		}
		return Optional.empty();
	}
	private boolean isExcluded(Class<?> excludedClass, GWebRequest request) {
		return filterMatcher.isMatch(excludedClass, request);
	}
}
