/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter;


import java.util.Optional;

import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;

/**
 * 一連のレスポンスフィルターを実行します.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GContainerResponseFilterStage {

	/**
	 * レスポンスフィルター({@link jakarta.ws.rs.container.ContainerResponseFilter})チェインを実行します. <br/>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @param webResponse　レスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void apply(GWebRequest webRequest, GWebResponse webResponse) throws Throwable;
}
