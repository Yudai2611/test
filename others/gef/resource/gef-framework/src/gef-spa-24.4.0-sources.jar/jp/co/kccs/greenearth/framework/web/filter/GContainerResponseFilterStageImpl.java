/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter;

import java.io.IOException;
import java.util.Objects;

import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.core.Response;

import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.internal.GContainerResponse;

/**
 *
 * @create 2023/10/25
 * @see GContainerResponseFilterStage
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GContainerResponseFilterStageImpl implements GContainerResponseFilterStage {
	/** {@link GFilterMatcher} **/
	private GFilterMatcher filterMatcher;
	/** 有効される{@link GFilterChainConfiguration} **/
	private GFilterChainConfiguration filterChainConfiguration;

	public GContainerResponseFilterStageImpl(GFilterChainConfiguration filterChainConfiguration) {
		this.filterChainConfiguration = filterChainConfiguration;
		this.filterMatcher = new GFilterMatcherImpl(filterChainConfiguration);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GContainerResponseFilterStage#apply(GWebRequest, GWebResponse)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void apply(GWebRequest webRequest, GWebResponse webResponse) throws Throwable {
		for (ContainerResponseFilter filter : filterChainConfiguration.getResponseFilters()) {
			try {
				if (Objects.nonNull(filter) && !isExcluded(filter.getClass(), webRequest)) {
					filter.filter(webRequest, webResponse);
				}
			} catch (IOException e) {
				throw new GContainerException(e);
			}
		}
	}

	private boolean isExcluded(Class<?> excludedClass, GWebRequest request) {
		return filterMatcher.isMatch(excludedClass, request);
	}
}
