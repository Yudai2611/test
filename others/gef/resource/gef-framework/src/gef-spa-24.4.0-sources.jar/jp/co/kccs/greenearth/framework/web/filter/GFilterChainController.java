/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;

/**
 * リクエスト・レスポンスフィルター全体のﾗｲﾌｻｲｸﾙをコントロールします.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GFilterChainController {

	/**
	 * FilterChainにある{@link jakarta.ws.rs.container.ContainerRequestFilter}は、Priority順でを実行されます.Endpoint.apply()実行前に呼出します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return {@link GFilterChainController}
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<GWebResponse>  applyRequest(GWebRequest webRequest) throws Throwable;
	/**
	 * FilterChainにある{@link jakarta.ws.rs.container.ContainerResponseFilter}は、Priority順でを実行されます.Endpoint.apply()実行後に呼出します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @param webResponse レスポンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	void applyResponse(GWebRequest webRequest, GWebResponse webResponse) throws Throwable;
	/**
	 * {@link GFilterChainController}のインスタンスを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GFilterChainController}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GFilterChainController getInstance() {
		return GFrameworkUtils.getComponent(GFilterChainController.class);
	}
}
