/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter;

import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.filter.context.GFilterChainContextHolder;

/**
 *
 * @create 2023/10/25
 * @see GFilterChainController
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GFilterChainControllerImpl implements GFilterChainController {
	private GContainerRequestFilterStage containerRequestFilterStage;
	private GContainerResponseFilterStage containerResponseFilterStage;

	public GFilterChainControllerImpl(GFilterChainConfiguration filterChainConfiguration) {
		Objects.requireNonNull(filterChainConfiguration, GFrameworkMessages.mustBeRequired(GFilterChainConfiguration.class.getName()));
		containerRequestFilterStage = new GContainerRequestFilterStageImpl(filterChainConfiguration);
		containerResponseFilterStage = new GContainerResponseFilterStageImpl(filterChainConfiguration);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainController#applyRequest(GWebRequest)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GWebResponse> applyRequest(GWebRequest webRequest) throws Throwable {
		init();
		return containerRequestFilterStage.apply(webRequest);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainController#applyResponse(GWebRequest, GWebResponse)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void applyResponse(GWebRequest webRequest, GWebResponse webResponse) throws Throwable {
		try {
			containerResponseFilterStage.apply(webRequest, webResponse);
		} finally {
			GFilterChainContextHolder.release();
		}
	}
	private void init() {
		GFilterChainContextHolder.init();
	}


}
