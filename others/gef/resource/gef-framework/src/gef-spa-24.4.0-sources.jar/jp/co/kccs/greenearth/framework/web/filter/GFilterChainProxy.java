/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter;

import java.io.IOException;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;

/**
 * 仮想フィルターチェーンを表現します.<br/>
 * 連結された具体的なフィルター構成を仮想フィルターチェーンとして一つに集約し、JAX-RSサーブレットコンテナのフィルターチェーンに挿入します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GFilterChainProxy extends ContainerRequestFilter, ContainerResponseFilter {

	/**
	 * 仮想フィルターチェーンのリクエストフィルターを実行します.<br/>
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestFilter#filter(jakarta.ws.rs.container.ContainerRequestContext)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	void filter(ContainerRequestContext requestContext) throws IOException;
	
	/**
	 * 仮想フィルターチェーンのレスポンスフィルターを実行します.<br/>
	 * {@inheritDoc}}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseFilter#filter(jakarta.ws.rs.container.ContainerRequestContext, jakarta.ws.rs.container.ContainerResponseContext)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException;
}
