/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainProxyConfigurator;

/**
 * {@link GFilterChainProxyConfigurator}を提供します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GFilterChainProxyConfiguratorProvider {

	/**
	 * 指定したサーブレット名に関連付けられた{@link GFilterChainProxyConfigurator}を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param servletName サーブレット名
	 * @return {@link GFilterChainProxyConfigurator}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<GFilterChainProxyConfigurator> getProvider(String servletName);

	/**
	 * {@link GFilterChainProxyConfiguratorProvider}のインスタンスを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GFilterChainProxyConfiguratorProvider}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GFilterChainProxyConfiguratorProvider getInstance() {
		return GFrameworkUtils.getComponent(GFilterChainProxyConfiguratorProvider.class.getName());
	}
}
