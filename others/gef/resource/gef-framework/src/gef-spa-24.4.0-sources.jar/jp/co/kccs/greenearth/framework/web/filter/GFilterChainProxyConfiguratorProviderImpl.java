/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainProxyConfigurator;
import jp.co.kccs.greenearth.framework.web.filter.configuration.annotation.FilterChainProxyConfigurator;

/**
 *
 * @create 2023/10/25
 * @see GFilterChainProxyConfiguratorProvider
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
			@Modifier(isPublic = true)
	},
	scannedAnnotations = FilterChainProxyConfigurator.class,
	scannedAssignableTypes = GFilterChainProxyConfigurator.class)
public class GFilterChainProxyConfiguratorProviderImpl implements GFilterChainProxyConfiguratorProvider {
	/** サーバレット名と{@link GFilterChainProxyConfigurator}のペアーマップ **/
	private Map<String, GFilterChainProxyConfigurator> configurators = null;

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainProxyConfiguratorProvider#getProvider(String)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GFilterChainProxyConfigurator> getProvider(String servletName) {
		GFilterChainProxyConfigurator chainProxyConfigurator = getConfigurators().get(servletName);
		if (Objects.isNull(chainProxyConfigurator)) {
			return Optional.of(getConfigurators().get(GFilterChainProxyConfigurator.Default.class.getName()));
		}
		return Optional.ofNullable(chainProxyConfigurator);
	}
	
	protected synchronized Map<String, GFilterChainProxyConfigurator> getConfigurators() {
		if (Objects.isNull(configurators)) {
			configurators = new ConcurrentHashMap<>();
			loadConfigurators();
		}
		Objects.requireNonNull(configurators, GFrameworkMessages.mustBeRequired(GFilterChainProxyConfigurator.class.getSimpleName()));
		return configurators;
	}
	
	protected void loadConfigurators() {
		List<GFilterChainProxyConfigurator> instances = GScanComponentService.getInstance().getScannedInstances(getClass());
		for (GFilterChainProxyConfigurator configurator : instances) {
			for (String servletName : configurator.getAssociatedServletNames()) {
				if (getConfigurators().containsKey(servletName)) {
					continue;
				}
				configurators.put(servletName, configurator);
			}
		}
	}
}
