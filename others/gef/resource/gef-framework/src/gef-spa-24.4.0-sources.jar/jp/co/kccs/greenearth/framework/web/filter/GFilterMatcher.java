/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter;

import jp.co.kccs.greenearth.framework.web.GWebRequest;

/**
 * リクエストのパータンとフィルターは一致するかどうかを検証する為のクラスです. <br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterMatcher {

	/**
	 * 渡された{@link GWebRequest}とフィルタークラスは一致するかどうかを検証します. <br/>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	boolean isMatch(Class<?> filterClazz, GWebRequest webRequest);
}
