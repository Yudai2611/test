/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.http.protocol.UriPatternMatcher;

import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairProvider;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainPattern;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainPatternAction;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainPatternUri;

/**
 *
 * @create 2023/10/25
 * @see GFilterMatcher
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GFilterMatcherImpl implements GFilterMatcher {
	/** フィルタークラスとパータンとペアーマップ **/
	private Map<Class<?>, List<GFilterChainPattern>> excludePatternCaches = new HashMap<>();

	public GFilterMatcherImpl(GFilterChainConfiguration filterChainConfiguration) {
		register(filterChainConfiguration);
	}
	private void register(GFilterChainConfiguration filterChainConfig) {
		if (Objects.nonNull(filterChainConfig)) {
			filterChainConfig.getExcludePatterns().forEach((key, value) -> {
				excludePatternCaches.put(key, new ArrayList<>());
				for (GFilterChainPattern filterPattern : value) {
					excludePatternCaches.get(key).add(filterPattern);
				}
			});
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterMatcher#isMatch(Class, GWebRequest)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public boolean isMatch(Class<?> filterClazz, GWebRequest webRequest) {
		List<GFilterChainPattern> filterPatterns = excludePatternCaches.get(filterClazz);
		if (Objects.nonNull(filterPatterns)) {
			for (GFilterChainPattern filterPattern : filterPatterns) {
				if (filterPattern instanceof GFilterChainPatternUri) {
					if (isMatchUri((GFilterChainPatternUri) filterPattern, webRequest)) {
						return true;
					}
				} else {
					if (isMatchAction((GFilterChainPatternAction) filterPattern, webRequest)) {
						return true;
					}
				}
			}
		}
		return false;
	}
	private boolean isMatchAction(GFilterChainPatternAction filterPattern, GWebRequest webRequest) {
		GResourceKeyPairExtractor.GResourceKeyPair resourceKeyPair = GResourceKeyPairProvider.getInstance().extract(webRequest.getNativeRequest());
		if (isMatchActionBean(resourceKeyPair.getFirst(), filterPattern)) {
			List<String> methods = filterPattern.getActionMethods();
			return isMatchActionMethod(methods, resourceKeyPair.getSecond());
		}
		return false;
	}
	private boolean isMatchActionMethod(List<String> methods, String actionMethod) {
		if (Objects.nonNull(methods)) {
			if (methods.isEmpty()) {
				return true;
			}
			for (String method : methods) {
				Pattern pattern = Pattern.compile(method);
				Matcher matcher = pattern.matcher(actionMethod);
				if (matcher.matches()) {
					return true;
				}
			}
		}
		return false;
	}
	private boolean isMatchActionBean(String actionBean, GFilterChainPatternAction filterPattern) {
		return (
			filterPattern.getActionClass().equals(actionBean)
				||
				filterPattern.getActionClass().equals("*"));
	}
	private boolean isMatchUri(GFilterChainPatternUri filterPattern, GWebRequest webRequest) {
		UriPatternMatcher<String> patternMatcher = new UriPatternMatcher<>();
		patternMatcher.register(filterPattern.getUri(), filterPattern.getUri());
		HttpServletRequest request = webRequest.getNativeRequest();
		String uri = request.getRequestURI().substring(request.getContextPath().length());
		return Objects.nonNull(patternMatcher.lookup(uri));
	}
}
