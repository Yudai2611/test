/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter;

import java.io.IOException;
import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.core.Context;

import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfigurationBuilder;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainProxyConfigurator;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.internal.GContainerRequest;
import jp.co.kccs.greenearth.framework.web.internal.GContainerResponse;
import lombok.SneakyThrows;

/**
 *
 * @create 2023/10/25
 * @see GFilterChainProxy
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
public class GGenericFilterChainProxy implements GFilterChainProxy {

	/** リクエスト **/
	@Context
	private HttpServletRequest httpServletRequest;
	/** レスポンス **/
	@Context
	private HttpServletResponse httpServletResponse;
	/** 有効された{@link GFilterChainConfiguration} **/
	private GFilterChainConfiguration filterConfiguration;
	/** {@link GFilterChainController} **/
	private GFilterChainController filterChainController;

	public GGenericFilterChainProxy() {

	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainProxy#filter(ContainerRequestContext)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@SneakyThrows
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		initHttpContextHolder(requestContext);
		initializeFilterStage();
		filterChainController.applyRequest(GHttpContextHolder.getContext().getWebRequest());
	}

	private void initHttpContextHolder(ContainerRequestContext containerRequestContext) {
		if (containerRequestContext instanceof GWebRequest) {
			GWebRequest webRequest = GWebRequest.class.cast(containerRequestContext);
			GHttpContextHolder.init(webRequest);
		} else {
			GHttpContextHolder.init(new GContainerRequest(httpServletRequest, httpServletResponse, containerRequestContext));
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainProxy#filter(ContainerRequestContext, ContainerResponseContext)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@SneakyThrows
	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
		if (Objects.isNull(GHttpContextHolder.getContext())) {
			initHttpContextHolder(requestContext);
		}
		initializeFilterStage();
		GWebResponse webResponse =  new GContainerResponse(GHttpContextHolder.getContext().getWebRequest(), responseContext);
		filterChainController.applyResponse(GHttpContextHolder.getContext().getWebRequest(), webResponse);
		if (Objects.nonNull(GHttpContextHolder.getContext())) {
			GHttpContextHolder.release();
		}

	}

	protected void initializeFilterStage() {
		if (Objects.isNull(filterConfiguration)) {
			GWebRequest webRequest = GHttpContextHolder.getContext().getWebRequest();
			this.filterConfiguration = buildConfiguration(webRequest);
			Objects.requireNonNull(filterConfiguration, GFrameworkMessages.mustBeRequired(GFilterChainConfiguration.class.getSimpleName()));
			this.filterChainController = new GFilterChainControllerImpl(filterConfiguration);
		}
	}

	protected GFilterChainConfiguration buildConfiguration(GWebRequest webRequest) {
		final String servletName = getCurrentServletName(webRequest);
		GFilterChainProxyConfigurator configurator = GFilterChainProxyConfiguratorProvider.getInstance()
													.getProvider(servletName)
													.orElseThrow(GContainerException::new);
		GFilterChainConfigurationBuilder builder = GFilterChainConfiguration.builder(servletName);
		configurator
			.getDefaultFilterChain()
			.forEach(builder.filters()::chain);
		builder.priorityOrder(configurator.isDefaultPriorityOrder());
		return configurator.configure(builder);
	}
	
	private String getCurrentServletName(GWebRequest webRequest) {
		Objects.requireNonNull(webRequest.getNativeRequest(), GFrameworkMessages.mustBeRequired(HttpServletRequest.class.getSimpleName()));
		return ((HttpServletRequest) webRequest.getNativeRequest()).getHttpServletMapping().getServletName();
	}
}
