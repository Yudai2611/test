/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter.configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.filter.configuration.annotation.FilterChainProxyConfigurator;
import lombok.NoArgsConstructor;

/**
 *  フレームワーク標準の仮想フィルターチェーン({@link GFilterChainProxyConfigurator})を構成します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@FilterChainProxyConfigurator
@Priority(GPriority.NORMAL)
@NoArgsConstructor
public class GDefaultFilterChainProxyConfigurator implements GFilterChainProxyConfigurator {

	/**
	 * {@inheritDoc}
	 * 当該メソッドは、デフォルトのサーブレット名を返却します.<br/>
	 * ﾌﾚｰﾑﾜｰｸ内で定めるデフォルト値を({@link GFilterChainProxyConfigurator.Default})で表現し、<br/>
	 * 実行時のカレントサーブレットのフィルターチェーン構成として適用します.
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<String> getAssociatedServletNames() {
		return Arrays.asList(GFilterChainProxyConfigurator.Default.class.getName());
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<Class<?>> getDefaultFilterChain() {
		List<Class<?>> filterChain = new ArrayList<>(
			Arrays.asList(
			)
		);
		return filterChain;
	}
}
