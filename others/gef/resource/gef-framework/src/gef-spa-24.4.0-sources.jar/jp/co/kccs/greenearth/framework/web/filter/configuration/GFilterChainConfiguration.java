/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

import java.util.List;
import java.util.Map;

import jakarta.annotation.Priority;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseFilter;

/**
 * 仮想フィルターチェーンの構成情報を表現します.<br/>
 * {@link GFilterChainConfigurator}が仮想フィルターチェーンを構成する際に利用されます.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GFilterChainConfiguration {
	/**
	 * サーブレット名を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return String
	 * @author yamashita
	 * @since 23.10.0
	 */
	String getServletName();
	
	/**
	 * フィルターの実行順序をプライオリティ({@link Priority}とするかどうかを判定します.<br/>
	 *
	 * @create 2023/10/25
	 * @return boolean true: {@ink Priority}順で実行/false: 定義順で実行 
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean isPriorityOrder();
	
	/**
	 * フィルターチェーンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return List フィルターチェーン
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<Class<?>> getFilterChain();
	
	/**
	 * リクエストフィルターチェーンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return List リクエストフィルターチェーン
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<? extends ContainerRequestFilter> getRequestFilters();
	
	/**
	 * レスポンスフィルターチェーンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return List レスポンスフィルターチェーン
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<? extends ContainerResponseFilter> getResponseFilters();
	
	/**
	 * フィルター適用除外の構成を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return Map フィルター適用除外の構成
	 * @author yamashita
	 * @since 23.10.0
	 */
	Map<Class<?>, List<GFilterChainPattern>> getExcludePatterns();
	
	/**
	 * プライオリティオーダーを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param priorityOrder true: {@ink Priority}順で実行/false: 定義順で実行 
	 * @author yamashita
	 * @since 23.10.0
	 */
	void setPriorityOrder(boolean priorityOrder);
	
	/**
	 * フィルターチェーンを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param filterChain フィルターチェーン
	 * @author yamashita
	 * @since 23.10.0
	 */
	void setFilterChain(List<Class<?>> filterChain);
	
	/**
	 * フィルター適用除外の構成を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param excludePatterns
	 * @author yamashita
	 * @since 23.10.0
	 */
	void setExcludePatterns(Map<Class<?>, List<GFilterChainPattern>> excludePatterns);

	/**
	 * ビルダー({@link GFilterChainConfigurationBuilder})を生成します.<br/>
	 *
	 * @create 2023/10/25
	 * @param servletName サーブレット名
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GFilterChainConfigurationBuilder builder(String servletName) {
		return new GFilterChainConfigurationBuilderImpl(servletName);
	}
}
