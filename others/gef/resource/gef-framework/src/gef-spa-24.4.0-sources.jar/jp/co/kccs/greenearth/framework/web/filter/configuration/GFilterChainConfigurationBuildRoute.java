/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * {@link GFilterChainConfiguration}をビルドする為のAPIを提供します.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterChainConfigurationBuildRoute {

	/**
	 * ビルダーに指定される値で{@link GFilterChainConfiguration}を作る為のクラスです.<br/>
	 *
	 * @create 2023/10/25
	 * @return {@link GFilterChainConfiguration} ビルド結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfiguration build();
}
