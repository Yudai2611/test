/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * {@link GFilterChainConfiguration}をビルドする為のAPIを提供します.<br/>
 * 提供されるAPIは「priorityOrder」、フィルターチェイン、除外されたいフィルターがあります.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterChainConfigurationBuilder extends
	GFilterChainConfigurationEntryPoint,
	GFilterChainConfigurationExcludeEntryPoint {

	/**
	 * {@link GFilterChainConfiguration}の「priorityOrder」を指定するためのAPIです.<br/>
	 *
	 *
	 * @create 2023/10/25
	 * @param priorityOrder 優先モード.「true」の場合{@link jakarta.annotation.Priority}で判断します.「false」の場合、定義される順番で実行されます. <br/>
	 * @return {@link GFilterChainConfigurationEntryPoint}フィルターチェインを定義されるする為のAPIです.
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfigurationEntryPoint priorityOrder(boolean priorityOrder);
}
