/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;


/**
 *
 * @create 2023/10/25
 * @see GFilterChainConfigurationBuilder
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GFilterChainConfigurationBuilderImpl implements
	GFilterChainConfigurationExcludeEntryPoint,
	GFilterChainConfigurationExcludeFilterPatternRoute,
	GFilterChainConfigurationExcludeFilterRoute,
	GFilterChainConfigurationEntryPoint,
	GFilterChainConfigurationRoute,
	GFilterChainConfigurationExcludeEntryPointRoute,
	GFilterChainConfigurationChainEntryPointRoute,
	GFilterChainConfigurationBuilder {
	/** サーバレット名 **/
	private final String servletName;

	/** 実行順 **/
	private boolean priorityOrder = true;
	/** 除外されるフィルター **/
	private final Map<Class<?>, List<GFilterChainPattern>> excludePatterns = new ConcurrentHashMap<>();

	/** フィルターチェイン **/
	private final List<Class<?>> filterChain = new ArrayList<>();

	/** 除外されるフィルターをビルド為の一時変数 **/
	private Class<?> currentExcludeFilterPointer;

	public GFilterChainConfigurationBuilderImpl(String servletName) {
		this.servletName = servletName;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationExcludeFilterRoute##excludes()
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationExcludeFilterRoute excludes() {
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationExcludeFilterPatternRoute#uri(String)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationExcludeFilterPatternRoute uri(String uri) {
		excludePatterns.get(currentExcludeFilterPointer).add(new GFilterChainPatternUri(uri));
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GFilterChainConfigurationExcludeFilterPatternRoute#action(Class, String...)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationExcludeFilterPatternRoute action(Class<?> actionClass, String... actionMethods) {
		GFilterChainPattern pattern = new GFilterChainPatternAction(actionClass.getCanonicalName(), Arrays.stream(actionMethods).collect(
			Collectors.toList()));
		removeSimilarActionBean(pattern, this.excludePatterns.get(currentExcludeFilterPointer));
		excludePatterns.get(currentExcludeFilterPointer).add(pattern);
		return this;
	}
	private void removeSimilarActionBean(GFilterChainPattern pattern, List<GFilterChainPattern> patternList) {
		if (pattern instanceof GFilterChainPatternAction) {
			for (int i = 0; i < patternList.size(); i++) {
				GFilterChainPattern p = patternList.get(i);
				if (p instanceof GFilterChainPatternAction) {
					if ((((GFilterChainPatternAction) p).getActionClass().equals(((GFilterChainPatternAction) pattern).getActionClass()))) {
						patternList.remove(i);
						break;
					}
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationExcludeFilterPatternRoute#action(String, String...)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationExcludeFilterPatternRoute action(String actionBean, String... actionMethods) {
		actionBean = Objects.requireNonNullElse(actionBean, "").trim();
		excludePatterns.get(currentExcludeFilterPointer).add(new GFilterChainPatternAction(
			actionBean, Arrays.stream(actionMethods).collect(
			Collectors.toList())));
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationExcludeFilterRoute#filter(Class)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationExcludeEntryPointRoute filter(Class<?> filterClass) {
		if (!filterChain.contains(filterClass)) {
			throw new GFrameworkException(String.format("%s is not defined in chain", filterClass.getCanonicalName()));
		}
		currentExcludeFilterPointer = filterClass;
		List<GFilterChainPattern> filterConfigurationPatterns = excludePatterns.get(currentExcludeFilterPointer);
		if (Objects.isNull(filterConfigurationPatterns)) {
			excludePatterns.put(currentExcludeFilterPointer, new ArrayList<>());
		}
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationRoute#chain(Class)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationRoute chain(Class<?> filterClass) {
		if (filterChain.contains(filterClass)) {
			throw new GFrameworkException(GFrameworkMessages.isDuplicated(filterClass.getCanonicalName()));
		}
		filterChain.add(filterClass);
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationEntryPoint#filters()
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationChainEntryPointRoute filters() {
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationBuilder#priorityOrder(boolean)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfigurationEntryPoint priorityOrder(boolean priorityOrder) {
		this.priorityOrder = priorityOrder;
		return this;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainConfigurationBuilder#build()
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GFilterChainConfiguration build() {
		return new GFilterChainConfigurationImpl(
			servletName,
			priorityOrder,
			filterChain,
			excludePatterns
		);
	}
}
