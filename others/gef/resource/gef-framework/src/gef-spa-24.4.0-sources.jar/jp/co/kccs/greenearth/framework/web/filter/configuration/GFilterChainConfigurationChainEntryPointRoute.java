/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * {@link GFilterChainConfiguration}をビルドする為のAPIを提供します.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterChainConfigurationChainEntryPointRoute {

	/**
	 * {@link GFilterChainConfiguration}にフィルターチェインを指定する為のAPIです.<br/>
	 *
	 * @create 2023/10/25
	 * @param filterClass フィルタークラス
	 * @return {@link GFilterChainConfigurationRoute}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfigurationRoute chain(Class<?> filterClass);
}
