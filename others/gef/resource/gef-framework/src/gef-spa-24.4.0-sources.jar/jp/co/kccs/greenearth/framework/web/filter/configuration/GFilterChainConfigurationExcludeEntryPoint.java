/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * {@link GFilterChainConfiguration}をビルドする為のAPIを提供します.<br/>
 *
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterChainConfigurationExcludeEntryPoint extends
	GFilterChainConfigurationBuildRoute  {

	/**
	 * 除外されたいフィルター
	 *
	 * @create 2023/10/25
	 * @return {@link GFilterChainConfigurationExcludeFilterRoute}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfigurationExcludeFilterRoute excludes();
}
