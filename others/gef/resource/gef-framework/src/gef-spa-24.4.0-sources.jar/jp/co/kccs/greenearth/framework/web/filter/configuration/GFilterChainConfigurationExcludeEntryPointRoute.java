/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * {@link GFilterChainConfigurationBuilder}にパータンのAPIを提供するクラスです. <br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterChainConfigurationExcludeEntryPointRoute {

	/**
	 * URIパータンを指定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param uri URIパータン
	 * @return {@link GFilterChainConfigurationExcludeFilterPatternRoute}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfigurationExcludeFilterPatternRoute uri(String uri);

	/**
	 * 「ActionBean」パータンを指定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param actionClass 「ActionClass」{@link Class}型
	 * @param actionMethods 「ActionMethod」の一覧
	 * @return {@link GFilterChainConfigurationExcludeFilterPatternRoute}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfigurationExcludeFilterPatternRoute action(Class<?> actionClass, String... actionMethods);

	/**
	 * 「ActionBean」パータンを指定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param actionBean 「ActionClass」{@link String}型
	 * @param actionMethods 「ActionMethod」の一覧
	 * @return {@link GFilterChainConfigurationExcludeFilterPatternRoute}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfigurationExcludeFilterPatternRoute action(String actionBean, String... actionMethods);

}
