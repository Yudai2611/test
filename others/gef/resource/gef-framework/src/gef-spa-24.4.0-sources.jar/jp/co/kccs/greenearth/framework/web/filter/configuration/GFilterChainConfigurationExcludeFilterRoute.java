/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * 除外されたいフィルターAPIを提供する為のクラスです. <br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterChainConfigurationExcludeFilterRoute {

	/**
	 * 除外されたいフィルターを指定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param filterClass フィルタークラス
	 * @return {@link GFilterChainConfigurationExcludeEntryPointRoute}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfigurationExcludeEntryPointRoute filter(Class<?> filterClass);
}
