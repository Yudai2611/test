/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseFilter;

import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.priority.GPrioritySorter;


/**
 *
 *
 * @create 2023/10/25
 * @see GFilterChainConfiguration
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GFilterChainConfigurationImpl implements GFilterChainConfiguration {
	/** サーバレット名 **/
	private String servletName;

	/** フィルターの優先モード **/
	private boolean priorityOrder = true;

	/** フィルターチェイン **/
	private List<Class<?>> filterChain = new ArrayList<>();

	/** 分別されたフィルターチェイン({@link ContainerRequestFilter})　**/
	private List<? extends ContainerRequestFilter> requestFilters = new ArrayList<>();

	/** 分別されたフィルターチェイン({@link ContainerResponseFilter})　**/
	private List<? extends ContainerResponseFilter> responseFilters = new ArrayList<>();
	/** 除外されるフィルター **/
	private Map<Class<?>, List<GFilterChainPattern>> excludePatterns = new HashMap<>();
	public GFilterChainConfigurationImpl(String servletName, boolean priorityOrder, List<Class<?>> filterChain,
		Map<Class<?>, List<GFilterChainPattern>> excludePatterns) {
		this.servletName = servletName;
		this.priorityOrder = priorityOrder;
		this.filterChain = filterChain;
		this.excludePatterns = excludePatterns;
		this.requestFilters = reorderRequestFilters(filterChain);
		this.responseFilters = reorderResponseFilters(filterChain);
	}

	/**
	 * サーバレット名を取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return サーバレット名
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public String getServletName() {
		return servletName;
	}

	/**
	 * 「priorityOrder」を取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return 実行順のモード
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public boolean isPriorityOrder() {
		return priorityOrder;
	}

	/**
	 * フィルターチェインを取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return フィルターチェイン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<Class<?>> getFilterChain() {
		return filterChain;
	}

	/**
	 * 分別されたいフィルター({@link ContainerRequestFilter})を取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return 分別されたいフィルター({@link ContainerRequestFilter})
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<? extends ContainerRequestFilter> getRequestFilters() {
		return requestFilters;
	}

	/**
	 * 分別されたいフィルター({@link ContainerResponseFilter})を取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return 分別されたいフィルター({@link ContainerResponseFilter})
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<? extends ContainerResponseFilter> getResponseFilters() {
		return responseFilters;
	}

	/**
	 * 除外されるフィルターを取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return 除外されるフィルター
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Map<Class<?>, List<GFilterChainPattern>> getExcludePatterns() {
		return excludePatterns;
	}

	/**
	 * 実行順を設定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param priorityOrder 優先順モード
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setPriorityOrder(boolean priorityOrder) {
		this.priorityOrder = priorityOrder;
	}

	/**
	 * フィルターチェインを設定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param filterChain フィルターチェイン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setFilterChain(List<Class<?>> filterChain) {
		this.filterChain = filterChain;
	}

	/**
	 * 除外されるフィルターを設定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param excludePatterns 除外されるフィルタークラスとパータンのペアー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setExcludePatterns(Map<Class<?>, List<GFilterChainPattern>> excludePatterns) {
		this.excludePatterns = excludePatterns;
	}

	protected List<? extends ContainerRequestFilter> reorderRequestFilters(List<Class<?>> filterChain) {
		List<ContainerRequestFilter> filters = filterChain.stream()
			.filter(ContainerRequestFilter.class::isAssignableFrom)
			.map(f-> (ContainerRequestFilter) GObjectInstantiator.getInstance().newInstance(f).get()).collect(
				Collectors.toList());
		return reorderRequest(filters);
	}
	protected List<? extends ContainerResponseFilter> reorderResponseFilters(List<Class<?>> filterChain) {
		List<ContainerResponseFilter> filters = filterChain.stream()
			.filter(ContainerResponseFilter.class::isAssignableFrom)
			.map(f-> (ContainerResponseFilter) GObjectInstantiator.getInstance().newInstance(f).get()).collect(
				Collectors.toList());
		return reorderResponse(filters);
	}



	private List<ContainerRequestFilter> reorderRequest(List<ContainerRequestFilter> filters) {
		if (isPriorityOrder()) {
			return GPrioritySorter.sortByInstance(filters);
		}
		return filters;
	}
	private List<ContainerResponseFilter> reorderResponse(List<ContainerResponseFilter> filters) {
		if (isPriorityOrder()) {
			filters = GPrioritySorter.reverseByInstance(filters);
		} else {
			Collections.reverse(filters);
		}
		return filters;
	}
}
