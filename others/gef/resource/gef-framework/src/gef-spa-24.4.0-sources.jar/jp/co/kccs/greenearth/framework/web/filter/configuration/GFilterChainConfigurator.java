/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * {@link GFilterChainConfiguration}のビルドする為のクラスです.<br/>
 * 各サーバレットで、このインタフェースの実装は唯一しか有効されないです.有効する為に、web.xmlのサーバレットの「init-param」で「filter-configurator」のキーで指定します.
 * 指定される値は実装クラスの「パッケージ名」+ 「クラス名」です.<br/>
 * 例物：<br/>
 * <servlet>
 * 		<servlet-name>XXXServlet</servlet-name>
 * 		<servlet-class>jp.co.kccs.greenearth.framework.web.server.GServletContainer</servlet-class>
 * 		<init-param>
 * 			<param-name>filter-configurator</param-name>
 * 			<param-value>
 *                 {@link GFilterChainConfigurator}の実装の「パッケージ名」+ 「クラス名」
 *          </param-value>
 * 		</init-param>
 * 	</servlet>
 *
 * 	「init-param」に「priority-order」と「filters」はある為、下記のルールがあります.
 * 	(1)「init-param」に「priority-order」が既に定義されたら、{@link GFilterChainConfigurator}に定義される「priority-order」が優先されます.<br/>
 * 	(2)「init-param」に「filters」が既に定義されたら、順番的には「init-param」の方が先に入ります.<br/>
 * 	例えば、<br/>
 * <servlet>
 * 		<servlet-name>XXXServlet</servlet-name>
 * 		<servlet-class>jp.co.kccs.greenearth.framework.web.server.GServletContainer</servlet-class>
 * 		<init-param>
 * 			<param-name>filter-configurator</param-name>
 * 			<param-value>
 *                 {@link GFilterChainConfigurator}の実装の「パッケージ名」+ 「クラス名」
 *          </param-value>
 * 		</init-param>
 * 	    <init-param>
 * 	        <param-name>filters</param-name>
 * 	        <param-value>
 * 	            package_name.Filter1,
 * 	            package_name.Filter2
 * 	        </param-value>
 * 	    </init-param>
 * 	</servlet>
 *  フィルターチェインリストの順番はpackage_name.Filter1->package_name.Filter2->{@link GFilterChainConfigurator}に定義されたフィルター.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GFilterChainConfigurator {

	/**
	 * {@link GFilterChainConfigurationBuilder}に値を指定するのためです.<br/>
	 *
	 * @create 2023/10/25
	 * @param builder ビルダー
	 * @return {@link GFilterChainConfiguration}ビルド結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GFilterChainConfiguration configure(GFilterChainConfigurationBuilder builder);
}
