/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

import java.util.List;

/**
 * {@link GFilterChainPattern}の形は「ActionBean」と「ActionMethod」の場合です.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GFilterChainPatternAction implements GFilterChainPattern {
	/** 「ActionClass」パータン **/
	private String actionClass;
	/** 「ActionMethod」の一覧 **/
	private List<String> actionMethods;
	public GFilterChainPatternAction(String actionClass, List<String> actionMethods) {
		this.actionClass = actionClass;
		this.actionMethods = actionMethods;
	}

	/**
	 * 「ActionClass」を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return 「ActionClass」パータン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getActionClass() {
		return actionClass;
	}

	/**
	 * 「ActionMethod」を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return 「ActionMethod」の一覧
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getActionMethods() {
		return actionMethods;
	}
}
