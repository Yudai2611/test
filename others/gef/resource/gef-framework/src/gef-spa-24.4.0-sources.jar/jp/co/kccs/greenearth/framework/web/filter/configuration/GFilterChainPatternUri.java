/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

/**
 * {@link GFilterChainPattern}の形はURIの場合です.<br/>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GFilterChainPatternUri implements GFilterChainPattern {
	/** URIパータン　**/
	private String uri;

	public GFilterChainPatternUri(String uri) {
		this.uri = uri;
	}

	/**
	 * URIパータンを取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return URIパータン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getUri() {
		return uri;
	}
}
