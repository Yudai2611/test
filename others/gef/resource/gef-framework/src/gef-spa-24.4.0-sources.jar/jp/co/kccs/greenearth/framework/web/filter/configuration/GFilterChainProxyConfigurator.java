/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.filter.configuration;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.framework.web.filter.GFilterChainProxy;
import jp.co.kccs.greenearth.framework.web.filter.configuration.annotation.FilterChainProxyConfigurator;

/**
 * 仮想フィルターチェーン({@link GFilterChainProxy})の構成をカスタムするためのインタフェースを提供します.<br/>
 * 代表的には、フィルターチェーンの構成を{@link #getDefaultFilterChain()}により構築します.<br/>
 * 当該インタフェースは、1つ以上のサーブレットと関連付けられます.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GFilterChainProxyConfigurator extends GFilterChainConfigurator {
	
	@Override
	default GFilterChainConfiguration configure(GFilterChainConfigurationBuilder builder) {
		return builder.build();
	}

	/**
	 * 仮想フィルターチェーンを関連付けるサーブレット名を指定します.<br/>
	 * 複数指定の場合、それぞれのサーブレットに同じ仮想フィルターチェーン構成を関連付けます.<br/>
	 * 
	 * @create 2023/10/25
	 * @return 関連付けられたサーブレット名のリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	default List<String> getAssociatedServletNames() {
		FilterChainProxyConfigurator annotation = getClass().getAnnotation(FilterChainProxyConfigurator.class);
		return Objects.nonNull(annotation) ? Arrays.asList(annotation.servletNames()) : Collections.emptyList();
	}

	/**
	 * フィルターの実行順序をプライオリティ({@link Priority}とするかどうかを判定します.<br/>
	 *
	 * @create 2023/10/25
	 * @return boolean true: {@ink Priority}順で実行/false: 定義順で実行 
	 * @author yamashita
	 * @since 23.10.0
	 */
	default boolean isDefaultPriorityOrder() {
		return true;
	}

	/**
	 * フィルターチェーンを指定します.<br/>
	 * 実行順序は{@link #isDefaultPriorityOrder()}に準じます.<br/>
	 *
	 * @create 2023/10/25
	 * @return List フィルターチェーン
	 * @author yamashita
	 * @since 23.10.0
	 */
	default List<Class<?>> getDefaultFilterChain() {
		return Collections.emptyList();
	};

	
	class Default {
	}
}
