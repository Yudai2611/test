/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter.configuration.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainProxyConfigurator;

/**
 * {@link GFilterChainProxyConfigurator}を表現するマーカーアノテーションです.<br>
 * {@link GFilterChainProxyConfigurator}の実装クラスに付与します。<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface FilterChainProxyConfigurator {

	/**
	 * 関連付けられたサーブレット名を指定します.<br>
	 * 
	 * @create 2023/10/25
	 * @return 関連付けられたサーブレット名のリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	String[] servletNames() default "";
}
