/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter.context;

import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;

/**
 * 一連のフィルターチェーンで利用可能なコンテキストを表現します.<br/>
 * 各フィルター処理の実行中に、強制停止する場合、{@link #abortWith(Response)}により返却したいレスポンスを設定します。<br/>
 * 
 * @see GFilterChainContextHolder
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public interface GFilterChainContext {
	/**
	 * {@link HttpServletRequest}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link HttpServletRequest}
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	HttpServletRequest getHttpServletRequest();
	/**
	 * {@link HttpServletResponse}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link HttpServletResponse}
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	HttpServletResponse getHttpServletResponse();
	/**
	 * {@link GWebRequest}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GWebRequest}
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	GWebRequest getWebRequest();
	/**
	 * {@link GWebResponse}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GWebResponse}
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	GWebResponse getWebResponse();
	/**
	 * フィルターチェーン内で処理が停止された場合の{@link Response}を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return {@link GWebResponse}
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	Optional<Response> getAbortResponse();
	
	/**
	 * {@link #getAbortResponse()}が取得できるかどうかを判断します.<br/>
	 *
	 * @create 2023/10/25
	 * @return boolean true: 存在する/ false:存在しない
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	boolean hasAbortResponse();
	
	/**
	 *　フィルターチェーン内で処理が停止された場合のレスポンスを設定します.<br/>
	 *
	 * @create 2023/10/25
	 * @param response レスポンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	void abortWith(Response response);
	/**
	 * {@link GFilterChainContext}をリリースします.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	void release();
	
	/**
	 * {@link GFilterChainContext}インスタンスを生成するビルダーを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link Builder}インスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	static Builder builder() {
		return new Builder();
	}
	
	static class Builder {
		private HttpServletRequest httpServletRequest;
		private HttpServletResponse httpServletResponse;
		private GWebRequest webRequest;
		private GWebResponse webResponse;
		private Optional<Response> abortResponse;
		public Builder httpServletRequest(HttpServletRequest httpServletRequest) {
			this.httpServletRequest = httpServletRequest;
			return this;
		}
		public Builder httpServletResponse(HttpServletResponse httpServletResponse) {
			this.httpServletResponse = httpServletResponse;
			return this;
		}
		public Builder webRequest(GWebRequest webRequest) {
			this.webRequest = webRequest;
			return this;
		}
		public Builder webResponse(GWebResponse webResponse) {
			this.webResponse = webResponse;
			return this;
		}
		public Builder abortResponse(Response abortResponse) {
			this.abortResponse = Optional.of(abortResponse);
			return this;
		}
		public GFilterChainContext build() {
			GFilterChainContextImpl context = new GFilterChainContextImpl();
			context.setHttpServletRequest(httpServletRequest);
			context.setHttpServletResponse(httpServletResponse);
			context.setWebRequest(webRequest);
			context.setWebResponse(webResponse);
			context.setAbortResponse(abortResponse);
			return context;
		}
	}
}
