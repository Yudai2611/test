/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter.context;

import java.util.Objects;

import jp.co.kccs.greenearth.commons.collection.GPair;
import jp.co.kccs.greenearth.commons.tools.GCounter;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContext;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;

/**
 * {@link GFilterChainContext}を保持し、一連のライフサイクルメソッド({@link #init}/{@link #release()})を提供します.<br/>
 * {@link GFilterChainContext}は{@link ThreadLocal}スコープ内で保持されます。<br/>
 * 当該クラスを利用するアクターは、利用前後で必ずライフサイクルメソッドを呼びだし、{@link GFilterChainContext}が適切に保全されるようコントロールする必要があります。<br/>
 * 
 * @see GFilterChainContext
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public final class GFilterChainContextHolder {
	
	private static ThreadLocal<GPair<GFilterChainContext, GCounter>> threadLocal = new ThreadLocal<>();

	/**
	 * {@link GFilterChainContext}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GFilterChainContext}
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GFilterChainContext getContext() {
		if (Objects.nonNull(threadLocal.get())) {
			return threadLocal.get().getFirst();
		}
		throw new GContainerException(GFrameworkMessages.mustBeInitialized(GFilterChainContext.class.getName()));
	}

	/**
	 * {@link GFilterChainContext}を初期化します.<br>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	public synchronized static void init() {
		GPair<GFilterChainContext, GCounter> pair = threadLocal.get();
		if (Objects.isNull(pair)) {
			GCounter counter = new GCounter();
			counter.countUp();
			threadLocal.set(new GPair<>(createContext(), counter));
		} else {
			pair.getSecond().countUp();
		}
	}

	/**
	 * {@link GFilterChainContext}を解放します.<br>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	public synchronized static void release() {
		GPair<GFilterChainContext, GCounter> pair = threadLocal.get();
		if (Objects.nonNull(pair)) {
			pair.getSecond().countDown();
			if (pair.getSecond().getCount() == 0) {
				threadLocal.get().getFirst().release();
				threadLocal.remove();
			}
		}

	}

	private static GFilterChainContext createContext() {
		GHttpContext httpContext = GHttpContextHolder.getContext();
		Objects.requireNonNull(httpContext, GFrameworkMessages.mustBeRequired(GHttpContext.class.getSimpleName()));
		GWebRequest webRequest = httpContext.getWebRequest();
		Objects.requireNonNull(webRequest, GFrameworkMessages.mustBeRequired(GWebRequest.class.getSimpleName()));
		return GFilterChainContext
			.builder()
			.httpServletRequest(webRequest.getNativeRequest())
			.httpServletResponse(webRequest.getNativeResponse())
			.webRequest(webRequest)
			.build();
	}

}
