/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.filter.context;

import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import lombok.Getter;
import lombok.Setter;

/**
 * {@link GFilterChainContext}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Getter
@Setter
public class GFilterChainContextImpl implements GFilterChainContext {
	
	private HttpServletRequest httpServletRequest;
	private HttpServletResponse httpServletResponse;
	private GWebRequest webRequest;
	private GWebResponse webResponse;
	private Optional<Response> abortResponse;

	/**
	 * {@inheritDoc}
	 *
	 * @see GFilterChainContext#hasAbortResponse()
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean hasAbortResponse() {
		return Objects.nonNull(abortResponse) && abortResponse.isPresent();
	}

	public Optional<Response> getAbortResponse() {
		if (Objects.isNull(abortResponse)) {
			return Optional.empty();
		}
		return abortResponse;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainContext#abortWith(Response)
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public void abortWith(Response response) {
		webRequest.abortWith(response);
		this.abortResponse = Optional.of(response);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GFilterChainContext#release()
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public void release() {
		httpServletRequest = null;
		httpServletResponse = null;
		webRequest = null;
		webResponse = null;
		abortResponse = null;
	}
}
