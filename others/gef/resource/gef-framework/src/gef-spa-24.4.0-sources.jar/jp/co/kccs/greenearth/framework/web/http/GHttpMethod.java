/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.framework.GFrameworkPropertyKeys;

/**
 * HTTPリクエストメソッドの定義、および関連ユーティリティを提供します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public enum GHttpMethod {

	GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE;

	/** デフォルト値. */
	private static GHttpMethod defaultValue;

	private static final Map<Class<? extends Annotation>, GHttpMethod> SUPPORTED_ANNOTATION_TYPES =
			new ConcurrentHashMap<>() {
				{
					put(jakarta.ws.rs.GET.class, GHttpMethod.GET);
					put(jakarta.ws.rs.HEAD.class, GHttpMethod.HEAD);
					put(jakarta.ws.rs.POST.class, GHttpMethod.POST);
					put(jakarta.ws.rs.PUT.class, GHttpMethod.PUT);
					put(jakarta.ws.rs.PATCH.class, GHttpMethod.PATCH);
					put(jakarta.ws.rs.DELETE.class, GHttpMethod.DELETE);
					put(jakarta.ws.rs.OPTIONS.class, GHttpMethod.OPTIONS);
				}};

				private static final GHttpMethod[] VALUES = GHttpMethod.values();

	private static final Map<String, GHttpMethod> MAPPINGS =
		Arrays.stream(VALUES).collect(Collectors.toUnmodifiableMap(GHttpMethod::name, Function.identity()));
	static {
		resetDefault();
	}

	/**
	 * 指定した文字列を{@link GHttpMethod}インスタンスに変換します.<br/>
	 * null値を指定した場合、デフォルト値を返却します。<br/>
	 *
	 * @create 2023/10/25
	 * @param method HTTPメソッドの文字列
	 * @return 変換済み{@link GHttpMethod}インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GHttpMethod valueFrom(String method) {
		return Objects.isNull(method) ? defaultValue : MAPPINGS.get(method.toUpperCase());
	}

	/**
	 * サポートするHTTPメソッドアノテーションの一覧を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return サポート対象のアノテーションリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static List<Class<? extends Annotation>> supportedAnnotations() {
		return Collections.unmodifiableList(
						SUPPORTED_ANNOTATION_TYPES
							.keySet()
							.stream()
							.collect(Collectors.toList()
						)
				);
	}

	/**
	 * 指定したアノテーションがサポートするHTTPメソッドかどうか判定します.<br/>
	 *
	 * @create 2023/10/25
	 * @param annotationType
	 * @return not null: サポート対象/ null: サポート対象外
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GHttpMethod matches(Class<? extends Annotation> annotationType) {
		return SUPPORTED_ANNOTATION_TYPES.get(annotationType);
	}
	
	public boolean isMatchIgnoreCase(String method) {
		return name().equalsIgnoreCase(method);
	}

	/**
	 * デフォルト値を取得します.<br/>
	 * デフォルト値は、フレームワークプロパティに指定されます。<br/>
	 *
	 * @create 2023/10/25
	 * @return デフォルト値
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GHttpMethod getDefault() {
		return defaultValue;
	}

	/**
	 * デフォルト値をリセットします.<br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	static void resetDefault() {
		defaultValue =
			valueFrom(GFrameworkPropertyKeys.GEFRAME_SPA_WEB_RESOURCE_ENDPOINT_HTTP_METHOD_DEFAULT.getValue(GHttpMethod.POST.toString()));
	}
}
