/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
. */
package jp.co.kccs.greenearth.framework.web.http;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.Response.Status.Family;
import jakarta.ws.rs.core.Response.StatusType;

/**
 * HTTPステータスコードとメッセージを定義します.<br/>
 * 主に、{@link StatusType}の不足点を補います。<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
. */
public enum GHttpStatus implements StatusType {
	/** 200 OK. */
	OK(Response.Status.OK.getStatusCode(), Response.Status.OK.getReasonPhrase()),
	/** 201 CREATED. */
	CREATED(Response.Status.CREATED.getStatusCode(), Response.Status.CREATED.getReasonPhrase()),
	/** 202 ACCEPTED. */
	ACCEPTED(Response.Status.ACCEPTED.getStatusCode(), Response.Status.ACCEPTED.getReasonPhrase()),
	/** 204 NO_CONTENT. */
	NO_CONTENT(Response.Status.NO_CONTENT.getStatusCode(), Response.Status.NO_CONTENT.getReasonPhrase()),
	/** 205 RESET_CONTENT. */
	RESET_CONTENT(Response.Status.RESET_CONTENT.getStatusCode(), Response.Status.RESET_CONTENT.getReasonPhrase()),
	/** 206 PARTIAL_CONTENT. */
	PARTIAL_CONTENT(Response.Status.PARTIAL_CONTENT.getStatusCode(), Response.Status.PARTIAL_CONTENT.getReasonPhrase()),
	/** 300 MULTIPLE_CHOICE. */
	MULTIPLE_CHOICE(300, "Multiple Choice"),
	/** 301 MOVED_PERMANENTLY. */
	MOVED_PERMANENTLY(Response.Status.MOVED_PERMANENTLY.getStatusCode(), Response.Status.MOVED_PERMANENTLY.getReasonPhrase()),
	/** 302 FOUND. */
	FOUND(Response.Status.FOUND.getStatusCode(), Response.Status.FOUND.getReasonPhrase()),
	/** 303 SEE_OTHER. */
	SEE_OTHER(Response.Status.SEE_OTHER.getStatusCode(), Response.Status.SEE_OTHER.getReasonPhrase()),
	/** 304 NOT_MODIFIED. */
	NOT_MODIFIED(Response.Status.NOT_MODIFIED.getStatusCode(), Response.Status.NOT_MODIFIED.getReasonPhrase()),
	/** 305 USE_PROXY. */
	USE_PROXY(Response.Status.USE_PROXY.getStatusCode(), Response.Status.USE_PROXY.getReasonPhrase()),
	/** 307 TEMPORARY_REDIRECT. */
	TEMPORARY_REDIRECT(Response.Status.TEMPORARY_REDIRECT.getStatusCode(), Response.Status.TEMPORARY_REDIRECT.getReasonPhrase()),
	/** 400 BAD_REQUEST. */
	BAD_REQUEST(Response.Status.BAD_REQUEST.getStatusCode(), Response.Status.BAD_REQUEST.getReasonPhrase()),
	/** 401 UNAUTHORIZED. */
	UNAUTHORIZED(Response.Status.UNAUTHORIZED.getStatusCode(), Response.Status.UNAUTHORIZED.getReasonPhrase()),
	/** 402 PAYMENT_REQUIRED. */
	PAYMENT_REQUIRED(Response.Status.PAYMENT_REQUIRED.getStatusCode(), Response.Status.PAYMENT_REQUIRED.getReasonPhrase()),
	/** 403 FORBIDDEN. */
	FORBIDDEN(Response.Status.FORBIDDEN.getStatusCode(), Response.Status.FORBIDDEN.getReasonPhrase()),
	/** 404 NOT_FOUND. */
	NOT_FOUND(Response.Status.NOT_FOUND.getStatusCode(), Response.Status.NOT_FOUND.getReasonPhrase()),
	/** 405 METHOD_NOT_ALLOWED. */
	METHOD_NOT_ALLOWED(Response.Status.METHOD_NOT_ALLOWED.getStatusCode(), Response.Status.METHOD_NOT_ALLOWED.getReasonPhrase()),
	/** 406 NOT_ACCEPTABLE. */
	NOT_ACCEPTABLE(Response.Status.NOT_ACCEPTABLE.getStatusCode(), Response.Status.NOT_ACCEPTABLE.getReasonPhrase()),
	/** 407 PROXY_AUTHENTICATION_REQUIRED. */
	PROXY_AUTHENTICATION_REQUIRED(Response.Status.PROXY_AUTHENTICATION_REQUIRED.getStatusCode(), Response.Status.PROXY_AUTHENTICATION_REQUIRED.getReasonPhrase()),
	/** 408 REQUEST_TIMEOUT. */
	REQUEST_TIMEOUT(Response.Status.REQUEST_TIMEOUT.getStatusCode(), Response.Status.REQUEST_TIMEOUT.getReasonPhrase()),
	/** 409 CONFLICT. */
	CONFLICT(Response.Status.CONFLICT.getStatusCode(), Response.Status.CONFLICT.getReasonPhrase()),
	/** 410 GONE. */
	GONE(410, "Gone"),
	/** 411 LENGTH_REQUIRED. */
	LENGTH_REQUIRED(Response.Status.LENGTH_REQUIRED.getStatusCode(), Response.Status.LENGTH_REQUIRED.getReasonPhrase()),
	/** 412 PRECONDITION_FAILED. */
	PRECONDITION_FAILED(Response.Status.PRECONDITION_FAILED.getStatusCode(), Response.Status.PRECONDITION_FAILED.getReasonPhrase()),
	/** 413 REQUEST_ENTITY_TOO_LARGE. */
	REQUEST_ENTITY_TOO_LARGE(Response.Status.REQUEST_ENTITY_TOO_LARGE.getStatusCode(), Response.Status.REQUEST_ENTITY_TOO_LARGE.getReasonPhrase()),
	/** 414 REQUEST_URI_TOO_LONG. */
	REQUEST_URI_TOO_LONG(Response.Status.REQUEST_URI_TOO_LONG.getStatusCode(), Response.Status.REQUEST_URI_TOO_LONG.getReasonPhrase()),
	/** 415 UNSUPPORTED_MEDIA_TYPE. */
	UNSUPPORTED_MEDIA_TYPE(Response.Status.UNSUPPORTED_MEDIA_TYPE.getStatusCode(), Response.Status.UNSUPPORTED_MEDIA_TYPE.getReasonPhrase()),
	/** 416 REQUESTED_RANGE_NOT_SATISFIABLE. */
	REQUESTED_RANGE_NOT_SATISFIABLE(Response.Status.REQUESTED_RANGE_NOT_SATISFIABLE.getStatusCode(), Response.Status.REQUESTED_RANGE_NOT_SATISFIABLE.getReasonPhrase()),
	/** 417 EXPECTATION_FAILED. */
	EXPECTATION_FAILED(Response.Status.EXPECTATION_FAILED.getStatusCode(), Response.Status.EXPECTATION_FAILED.getReasonPhrase()),
	/** 422 UNPROCESSABLE_ENTITY. */
	UNPROCESSABLE_ENTITY(422, "Unprocessable Entity"),
	/** 423 LOCKED. */
	LOCKED(423, "Locked"),
	/** 425 TOO_EARLY. */
	TOO_EARLY(425, "Too Early"),
	/** 426 UPGRADE_REQUIRED. */
	UPGRADE_REQUIRED(426, "Upgrade Required"),
	/** 428 PRECONDITION_REQUIRED. */
	PRECONDITION_REQUIRED(Response.Status.PRECONDITION_REQUIRED.getStatusCode(), Response.Status.PRECONDITION_REQUIRED.getReasonPhrase()),
	/** 429 TOO_MANY_REQUESTS. */
	TOO_MANY_REQUESTS(Response.Status.TOO_MANY_REQUESTS.getStatusCode(), Response.Status.TOO_MANY_REQUESTS.getReasonPhrase()),
	/** 431 REQUEST_HEADER_FIELDS_TOO_LARGE. */
	REQUEST_HEADER_FIELDS_TOO_LARGE(Response.Status.REQUEST_HEADER_FIELDS_TOO_LARGE.getStatusCode(), Response.Status.REQUEST_HEADER_FIELDS_TOO_LARGE.getReasonPhrase()),
	/** 500 INTERNAL_SERVER_ERROR. */
	INTERNAL_SERVER_ERROR(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), Response.Status.INTERNAL_SERVER_ERROR.getReasonPhrase()),
	/** 501 NOT_IMPLEMENTED. */
	NOT_IMPLEMENTED(Response.Status.NOT_IMPLEMENTED.getStatusCode(), Response.Status.NOT_IMPLEMENTED.getReasonPhrase()),
	/** 502 BAD_GATEWAY. */
	BAD_GATEWAY(Response.Status.BAD_GATEWAY.getStatusCode(), Response.Status.BAD_GATEWAY.getReasonPhrase()),
	/** 503 SERVICE_UNAVAILABLE. */
	SERVICE_UNAVAILABLE(Response.Status.SERVICE_UNAVAILABLE.getStatusCode(), Response.Status.SERVICE_UNAVAILABLE.getReasonPhrase()),
	/** 504 GATEWAY_TIMEOUT. */
	GATEWAY_TIMEOUT(Response.Status.GATEWAY_TIMEOUT.getStatusCode(), Response.Status.GATEWAY_TIMEOUT.getReasonPhrase()),
	/** 505 HTTP_VERSION_NOT_SUPPORTED. */
	HTTP_VERSION_NOT_SUPPORTED(Response.Status.HTTP_VERSION_NOT_SUPPORTED.getStatusCode(), Response.Status.HTTP_VERSION_NOT_SUPPORTED.getReasonPhrase()),
	/** 506 VARIANT_ALSO_NEGOTIATES. */
	VARIANT_ALSO_NEGOTIATES(506, "Variant Also Negotiates"),
	/** 507 Insufficient Storage. */
	INSUFFICIENT_STORAGE(507, "Insufficient Storage"),
	/** 508 LOOP_DETECTED. */
	LOOP_DETECTED(508, "Loop Detected"),
	/** 510 NOT_EXTENDED. */
	NOT_EXTENDED(510, "Not Extended"),
	/** 511 NETWORK_AUTHENTICATION_REQUIRED. */
	NETWORK_AUTHENTICATION_REQUIRED(Response.Status.NETWORK_AUTHENTICATION_REQUIRED.getStatusCode(), Response.Status.NETWORK_AUTHENTICATION_REQUIRED.getReasonPhrase());

	private final int code;
	private final String message;
	private final Family family;
	

	GHttpStatus(final int statusCode, final String message) {
		this.code = statusCode;
		this.message = message;
		this.family = Family.familyOf(statusCode);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.Response.StatusType#getStatusCode()
	 * @return ステータスコード
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public int getStatusCode() {
		return this.code;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.Response.StatusType#getFamily()
	 * @return {@link Status.Family}
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Family getFamily() {
		return this.family;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.Response.StatusType#getReasonPhrase()
	 * @return ステータスコードの識別子
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public String getReasonPhrase() {
		return this.message;
	}
}
