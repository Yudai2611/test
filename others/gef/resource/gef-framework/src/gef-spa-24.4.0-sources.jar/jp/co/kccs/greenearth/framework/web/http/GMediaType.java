/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http;

import java.lang.annotation.Annotation;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.glassfish.jersey.message.internal.HttpHeaderReader;
import org.glassfish.jersey.message.internal.MediaTypes;

import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;

/**
 * {@link MediaType}を拡張し、メディアタイプの生成、定数を追加します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GMediaType extends MediaType {

	public final static String TEXT_JSON = "text/json";
	public final static MediaType TEXT_JSON_TYPE = new MediaType("text", "json");
	public static final String MEDIA_TYPE_WILDCARD = MediaType.MEDIA_TYPE_WILDCARD;
	public final static MediaType WILDCARD_TYPE = MediaType.WILDCARD_TYPE;
	public static final List<? extends MediaType> WILDCARD_TYPE_SINGLETON_LIST = Collections.singletonList(WILDCARD_TYPE);

	public static List<? extends MediaType> createFrom(Annotation annotation) throws ParseException {
		return createFrom(annotation, null);
	}
	
	public static List<? extends MediaType> createFrom(Annotation annotation, String defaultValue) throws ParseException {
		return createFrom(GReflectionHelper.getAnnotationValues(annotation)
													.map(v -> String.join(",", v))
													.orElse(null), defaultValue
							);
	}
	
	public static List<? extends MediaType> createFrom(String mediaType, String defaultValue) throws ParseException {
		List<? extends MediaType> result = GMediaType.readFrom(mediaType, defaultValue);
		Collections.sort(result, MediaTypes.PARTIAL_ORDER_COMPARATOR);
		return Collections.unmodifiableList(result);
	}

	public static List<? extends MediaType> createFrom(String mediaType) throws ParseException {
		return createFrom(mediaType, null);
	}
	
	public static List<? extends MediaType> readFrom(String mediaType) throws ParseException {
		return readFrom(mediaType, null);
	}
	
	/**
	 * メディアタイプ文字列から{@link MediaType}を生成します.<br/>
	 * メディアタイプ文字列が指定されない（null or empty）場合、指定されたデフォルト値を利用します。<br/>
	 * ともに指定されない場合、解析は行わず、空の配列({@link Collections#emptyList()})を返却します。<br/>
	 * メディアタイプ文字列の解析失敗時は、{@link ParseException}}を送出します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param mediaType メディアタイプ文字列
	 * @return 生成された{@link MediaType}
	 * @throws ParseException 解析失敗の場合
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static List<? extends MediaType> readFrom(String mediaType, String defaultValue) throws ParseException {
		if (GStringUtils.isNullOrEmpty(mediaType)) {
			mediaType = defaultValue;
		}
		if (Objects.isNull(mediaType)) {
			return Collections.emptyList();
		}
		List<MediaType> result = new ArrayList<>();
		return HttpHeaderReader.readMediaTypes(result, mediaType.replace("{", "").replace("}", "").trim());
	}
}
