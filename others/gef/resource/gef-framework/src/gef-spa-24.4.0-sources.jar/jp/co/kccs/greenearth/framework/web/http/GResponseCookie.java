/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http;

import java.io.Serializable;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;

public class GResponseCookie implements Cloneable, Serializable {

	private String domain;
	private String path;
	private Long maxAge;
	private boolean httpOnly;
	private boolean secure;
	private SameSite sameSite;
	private String cookieKey;
	private String cookieValue;

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public long getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(long maxAge) {
		this.maxAge = maxAge;
	}

	public boolean isHttpOnly() {
		return httpOnly;
	}

	public void setHttpOnly(boolean httpOnly) {
		this.httpOnly = httpOnly;
	}

	public boolean isSecure() {
		return secure;
	}

	public void setSecure(boolean secure) {
		this.secure = secure;
	}

	public SameSite getSameSite() {
		return sameSite;
	}

	public void setSameSite(SameSite sameSite) {
		this.sameSite = sameSite;
	}

	public String getCookieKey() {
		return cookieKey;
	}

	public void setCookieKey(String cookieKey) {
		this.cookieKey = cookieKey;
	}

	public String getCookieValue() {
		return cookieValue;
	}

	public void setCookieValue(String cookieValue) {
		this.cookieValue = cookieValue;
	}

	public static Builder builder() {
		return new Builder();
	}

	public String toString() {
		String cookie = String.format("%s=%s", cookieKey, cookieValue);
		if (Objects.nonNull(domain)) {
			cookie += ";Domain=" + domain;
		}
		if (Objects.nonNull(path)) {
			cookie += ";Path=" + path;
		}
		if (Objects.nonNull(maxAge) && maxAge >= 0) {
			cookie += ";Max-Age=" + maxAge;
		}
		if (httpOnly) {
			cookie += ";HttpOnly";
		}
		if (secure) {
			cookie += ";Secure";
		}
		if (Objects.nonNull(sameSite)) {
			cookie += ";SameSite=" + sameSite.value;
		}
		return cookie;
	}

	public static class Builder {
		private String domain;
		private String path;
		private Long maxAge = Long.valueOf(-1);
		private boolean httpOnly = false;
		private boolean secure = false;
		private SameSite sameSite;
		private String cookieKey;
		private String cookieValue;
		public Builder domain(String domain) {
			this.domain = domain;
			return this;
		}
		public Builder path(String path) {
			this.path = path;
			return this;
		}
		public Builder maxAge(long maxAge) {
			this.maxAge = maxAge;
			return this;
		}
		public Builder httpOnly(boolean httpOnly) {
			this.httpOnly = httpOnly;
			return this;
		}
		public Builder secure(boolean secure) {
			this.secure = secure;
			return this;
		}
		public Builder sameSite(SameSite sameSite) {
			this.sameSite = sameSite;
			return this;
		}
		public Builder cookieKey(String cookieKey) {
			this.cookieKey = cookieKey;
			return this;
		}
		public Builder cookieValue(String cookieValue) {
			this.cookieValue = Objects.requireNonNullElse(cookieValue, "");
			return this;
		}
		public GResponseCookie build() {
			GResponseCookie responseCookie = new GResponseCookie();
			if (Objects.isNull(cookieKey)) {
				throw new GFrameworkException(GFrameworkMessages.mustBeRequired("Cookie key"));
			}
			responseCookie.setCookieKey(cookieKey);
			responseCookie.setCookieValue(Objects.requireNonNullElse(cookieValue, ""));
			responseCookie.setDomain(domain);
			responseCookie.setPath(path);
			responseCookie.setSameSite(sameSite);
			responseCookie.setHttpOnly(httpOnly);
			responseCookie.setMaxAge(maxAge);
			responseCookie.setSecure(secure);
			return responseCookie;
		}
	}

	public enum SameSite {
		STRICT("strict"),
		LAX("lax"),
		NONE("none");

		private String value;

		SameSite(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
}
