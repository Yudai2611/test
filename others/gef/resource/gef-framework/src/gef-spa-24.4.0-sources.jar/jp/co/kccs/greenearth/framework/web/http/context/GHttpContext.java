/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.context;

import java.util.Locale;

import jp.co.kccs.greenearth.framework.web.GWebRequest;

/**
 * Webアプリケーションのバックエンド全体で利用可能なコンテキストを表します.<br/>
 * 利用前後には必ずライフサイクルメソッド({@link #init}/{@link #release()})を呼びだす必要があります。<br/>
 * 
 * @see GHttpContextHolder
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GHttpContext {
	
	/**
	 * 初期化を行います.<br/>
	 * 
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	void init(GWebRequest request);

	/**
	 * リリースします.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void release();
	
	/**
	 * ロケールを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return ロケール
	 * @author yamashita
	 * @since 23.10.0
	 */
	Locale getLocale();
	
	/**
	 * ロケールを設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param locale ロケール
	 * @author yamashita
	 * @since 23.10.0
	 */
	void setLocale(Locale locale);

	/**
	 * リクエストを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return リクエスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	GWebRequest getWebRequest();
}
