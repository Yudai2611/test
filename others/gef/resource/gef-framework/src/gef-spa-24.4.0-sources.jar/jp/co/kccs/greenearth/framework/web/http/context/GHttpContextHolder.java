/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.context;

import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.collection.GPair;
import jp.co.kccs.greenearth.commons.tools.GCounter;
import jp.co.kccs.greenearth.framework.web.GWebRequest;

/**
 * {@link GHttpContext}を保持し、一連のライフサイクルメソッド({@link #init(GWebRequest)}/{@link #release()})を提供します.<br/>
 * {@link GHttpContext}は{@link ThreadLocal}スコープ内で保持されます。<br/>
 * 当該クラスを利用するアクターは、利用前後で必ずライフサイクルメソッドを呼びだし、{@link GHttpContext}が適切に保全されるようコントロールする必要があります。<br/>
 * 
 * @see GHttpContext
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public final class GHttpContextHolder {

	private static ThreadLocal<GPair<GHttpContext, GCounter>> threadLocal = new ThreadLocal<>();

	/**
	 * コンテキストを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return コンテキスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GHttpContext getContext() {
		if (Objects.nonNull(threadLocal.get())) {
			return threadLocal.get().getFirst();
		}
		return null;
	}

	/**
	 * コンキストを初期化します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static void init(GWebRequest request) {
		GPair<GHttpContext, GCounter> pair = threadLocal.get();
		if (Objects.isNull(pair)) {
			GCounter counter = new GCounter();
			counter.countUp();
			threadLocal.set(new GPair<>(createContext(request), counter));
		} else {
			pair.getSecond().countUp();
		}
	}

	/**
	 * コンテキストを解放します.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static void release() {
		GPair<GHttpContext, GCounter> pair = threadLocal.get();
		if (Objects.nonNull(pair)) {
			pair.getSecond().countDown();
			if (pair.getSecond().getCount() == 0) {
				threadLocal.get().getFirst().release();
				threadLocal.remove();
			}
		}
	}

	private static GHttpContext createContext(GWebRequest request) {
		GHttpContext context = GFrameworkUtils.getComponent(GHttpContext.class.getName());
		context.init(request);
		return context;
	}
}
