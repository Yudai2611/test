/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.context;

import java.util.Locale;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.GHttpHeaders;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * {@link GHttpContext}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@NoArgsConstructor
public class GHttpContextImpl implements GHttpContext {

	@Getter
	@Setter
	private Locale locale;
	@Getter
	private GWebRequest webRequest;

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.http.context.GHttpContext#init(jp.co.kccs.greenearth.framework.web.GWebRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void init(GWebRequest request) {
		this.webRequest = request;
		checkState();
		applyLocale(request);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.http.context.GHttpContext#release()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void release() {
		checkState();
		setLocale(Locale.getDefault());
		webRequest = null;
	}
	
	/**
	 * 指定したリクエストの{@link GHttpHeaders#ACCEPT_LANGUAGE}をロケールとして設定します.<br/>
	 * {@link GHttpHeaders#ACCEPT_LANGUAGE}が設定されていない場合、デフォルト値({@link GFrameworkUtils#getDefaultLocale()})を適用します。<br/>
	 * 
	 * @create 2023/10/25
	 * @param request　リクエスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	protected void applyLocale(GWebRequest request) {
		Locale locale = GFrameworkUtils.getDefaultLocale();
		String lang = request.getHeaderString(GHttpHeaders.ACCEPT_LANGUAGE);
		if (GStringUtils.isNotEmpty(lang)) {
			locale = request.getAcceptableLanguages().get(0);
		}
		setLocale(locale);
	}
	
	void checkState() {
		Objects.requireNonNull(webRequest, GFrameworkMessages.mustBeRequired(GWebRequest.class.getSimpleName()));
	}
}
