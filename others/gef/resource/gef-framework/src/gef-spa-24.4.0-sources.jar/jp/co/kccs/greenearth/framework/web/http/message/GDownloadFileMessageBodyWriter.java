/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.MessageBodyWriter;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;
import jp.co.kccs.greenearth.framework.web.http.GHttpHeaders;

/**
 * {@link GDownloadFile}をHTTPレスポンスボディに書き込むクラスです。<br>
 * 
 * @create 2023/10/25
 * @author kccs okanishi
 * @since 23.10.0
 */
@Provider
@Produces({MediaType.APPLICATION_OCTET_STREAM})
@Priority(GPriority.NORMAL)
public class GDownloadFileMessageBodyWriter implements MessageBodyWriter<GDownloadFile> {

	/** ダウンロードファイルバッファ　デフォルト値. */
	protected static final String DOWNLOADFILE_BUFFER_DEFAULT = "4096";

	/** ダウンロードファイルバッファ　KEY名. */
	protected static final String DOWNLOADFILE_BUFFER_KEY = "geframe.core.FileDownload.BufferSize";

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#isWriteable(Class, Type, Annotation[], MediaType)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return GDownloadFile.class.isAssignableFrom(type);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#writeTo(Object, Class, Type, Annotation[], MediaType, MultivaluedMap, OutputStream)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public void writeTo(GDownloadFile file, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream) throws IOException, WebApplicationException {
		Objects.requireNonNull(file, GFrameworkMessages.mustBeRequired(GDownloadFile.class.getSimpleName()));
		
		setHeader(file, httpHeaders);
		
		if (file.getBufferSize() == -1) {
			String bufferSizeStr = GFrameworkUtils.getProperty(DOWNLOADFILE_BUFFER_KEY, DOWNLOADFILE_BUFFER_DEFAULT);
			int bufferSize = Integer.parseInt(bufferSizeStr);
			file.setBufferSize(bufferSize);
		}

		try (InputStream stream = file.getInputStream()) {
			int read;
			final byte[] data = new byte[file.getBufferSize()];
			while ((read = stream.read(data)) != -1) {
				entityStream.write(data, 0, read);
			}
		} finally {
			file.delete();
		}
	}
	
	/**
	 * HTTPヘッダにファイル名を設定します。<br>
	 * 
	 * @create 2023/10/25
	 * @param file {@link GDownloadFile}インスタンス
	 * @param httpHeaders HTTPヘッダ
	 * @throws UnsupportedEncodingException
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private void setHeader(GDownloadFile file, MultivaluedMap<String, Object> httpHeaders) throws UnsupportedEncodingException {
		if (file.getContentLength() != -1) {
			httpHeaders.add(GHttpHeaders.CONTENT_LENGTH, String.valueOf(file.getContentLength()));
		}
		
		StringBuilder value = new StringBuilder();
		value.append(file.getDisplayType().toString());
		value.append("; ");
		value.append("filename*=utf-8''");
		value.append(URLEncoder.encode(GStringUtils.nullToBlank(file.getName()), "UTF-8").replaceAll("\\+", "%20"));
		httpHeaders.add(GHttpHeaders.CONTENT_DISPOSITION, value.toString());
	}
}
