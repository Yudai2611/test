/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.nio.charset.Charset;

import org.glassfish.jersey.jsonb.LocalizationMessages;

import jakarta.annotation.Priority;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ContextResolver;
import jakarta.ws.rs.ext.MessageBodyWriter;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GContextResolverFactory;

/**
 * オブジェクトのgenericTypeが{@link GResultData}、{@link GSystemError}、{@link Response}
 * である場合、<br>
 * 該当オブジェクトをJson形式として、
 * HTTPレスポンスボディに書き込むクラスです。<br>
 *
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
@Provider
@Produces({GMediaType.APPLICATION_JSON, GMediaType.TEXT_JSON, GMediaType.WILDCARD})
@Priority(GPriority.NORMAL)
public class GObjectToJsonMessageBodyWriter implements MessageBodyWriter<Object> {
	private static final String JSON = "json";
	private static final String PLUS_JSON = "+json";

	/**
	 * {@inheritDoc}
	 * 
	 * @see MessageBodyWriter#isWriteable(Class, Type, Annotation[], MediaType)
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return (genericType == GResultData.class || genericType == GSystemError.class || genericType == Response.class) && supportsMediaType(mediaType);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see MessageBodyWriter#writeTo(Object, Class, Type, Annotation[], MediaType, MultivaluedMap, OutputStream)
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 */
	@Override
	public void writeTo(Object o, Class<?> type, Type genericType,
						Annotation[] annotations,
						MediaType mediaType,
						MultivaluedMap<String, Object> httpHeaders,
						OutputStream entityStream) throws IOException, WebApplicationException {
		Jsonb jsonb = getJsonb(type);
		try {
			entityStream.write(jsonb.toJson(o).getBytes(getCharset(mediaType)));
			entityStream.flush();
		} catch (IOException e) {
			throw new ProcessingException(LocalizationMessages.ERROR_JSONB_SERIALIZATION(), e);
		}
	}

	private static Charset getCharset(MediaType m) {
		String name = (m == null) ? null : m.getParameters().get(MediaType.CHARSET_PARAMETER);
		return (name == null) ? Charset.forName("UTF-8") : Charset.forName(name);
	}
	private Jsonb getJsonb(Class<?> type) {
		final ContextResolver<Jsonb> contextResolver = GContextResolverFactory.getResolver(Jsonb.class, GMediaType.APPLICATION_JSON_TYPE);
		if (contextResolver != null) {
			return contextResolver.getContext(type);
		} else {
			return JsonbSingleton.INSTANCE.getInstance();
		}
	}
	/**
	 * @return true for all media types of the pattern *&#47;json and
	 * *&#47;*+json.
	 */
	private static boolean supportsMediaType(final MediaType mediaType) {
		return mediaType.getSubtype().equals(JSON) || mediaType.getSubtype().endsWith(PLUS_JSON);
	}
	private enum JsonbSingleton {
		INSTANCE;
		private Jsonb jsonbInstance;
		Jsonb getInstance() {
			return jsonbInstance;
		}
		JsonbSingleton() {
			this.jsonbInstance = JsonbBuilder.create();
		}
	}
}