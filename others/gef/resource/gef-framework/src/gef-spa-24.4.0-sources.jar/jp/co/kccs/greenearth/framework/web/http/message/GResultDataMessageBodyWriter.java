/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.MessageBodyWriter;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.web.GProviderNotFoundException;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GMessageBodyFactory;

/**
 * {@link GResultData}をHTTPレスポンスボディに書き込むクラスです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Provider
@Produces({GMediaType.APPLICATION_JSON, GMediaType.TEXT_JSON, GMediaType.APPLICATION_OCTET_STREAM})
@Priority(GPriority.NORMAL)
public class GResultDataMessageBodyWriter implements MessageBodyWriter<GResultData> {
	
	/** 終了コードキー名 */
	private static final String EXITCODE = "exitCode";
	
	/** データキー名 */
	private static final String DATAS = "datas";

	/** 検証エラーキー名 */
	private static final String ERRORS = "errors";

	/** TimeStampキー名 */
	private static final String TIMESTAMP = "timestamp";

	/** HTTPステータスコードキー名 */
	private static final String STATUS = "status";

	/** メッセージキー名 */
	private static final String MESSAGE = "message";

	/** 詳細キー名 */
	private static final String DESCRIPTION = "description";

	/** スタックトレースキー名 */
	private static final String STACKTRACE = "stacktrace";

	/** システムエラーキー名 */
	private static final String SYSTEMERROR = "systemError";

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#isWriteable(Class, Type, Annotation[], MediaType)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return GResultData.class.isAssignableFrom(type);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#writeTo(Object, Class, Type, Annotation[], MediaType, MultivaluedMap, OutputStream)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public void writeTo(GResultData entity, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream) throws IOException, WebApplicationException {

		Map<String, Object> dataMap = new LinkedHashMap<>();
		Map<String, Object> resultMap = new LinkedHashMap<>();

		switch (entity.getExitCode()) {
			case GResultData.EXIT_CODE_FILE_DOWNLOAD :
				getBodyWriter(GDownloadFile.class, GDownloadFile.class, annotations, mediaType)
					.writeTo(entity.getDownloadFile(), GDownloadFile.class, GDownloadFile.class, annotations, mediaType, httpHeaders, entityStream);
				break;

			case GResultData.EXIT_CODE_VALIDATE_ERROR :
				List<GValidateError> list = createIfEmpty(entity.getErrors());

				resultMap.put(EXITCODE, GResultData.EXIT_CODE_VALIDATE_ERROR);
				resultMap.put(ERRORS, list.toArray(new GValidateError[list.size()]));
				resultMap.put(DATAS, getData(entity));
				getJsonBodyWriter(Object.class, resultMap.getClass(), annotations, mediaType)
					.writeTo(resultMap, Object.class, resultMap.getClass(), annotations, mediaType, httpHeaders, entityStream);
				break;

			case GResultData.EXIT_CODE_SYSTEM_ERROR :
				GSystemError error = createSystemError(entity);
				dataMap.put(TIMESTAMP, error.getTimeStamp());
				dataMap.put(STATUS, error.getStatusCode().orElseGet(() -> null));
				dataMap.put(MESSAGE, error.getMessage().orElseGet(() -> null));
				dataMap.put(DESCRIPTION, error.getDescription());

				if (error.isEnableStackTrace()) {
					dataMap.put(STACKTRACE, error.getStackTrace());
				}

				resultMap.put(EXITCODE, GResultData.EXIT_CODE_SYSTEM_ERROR);
				resultMap.put(SYSTEMERROR, dataMap);
				resultMap.put(DATAS, getData(entity));

				getJsonBodyWriter(Object.class, resultMap.getClass(), annotations, mediaType)
					.writeTo(resultMap, Object.class, resultMap.getClass(), annotations, mediaType, httpHeaders, entityStream);
				break;

			case GResultData.EXIT_CODE_SUCCESS :
				resultMap.put(EXITCODE, GResultData.EXIT_CODE_SUCCESS);
				resultMap.put(DATAS, getData(entity));
				getJsonBodyWriter(Object.class, resultMap.getClass(), annotations, mediaType)
					.writeTo(resultMap, Object.class, resultMap.getClass(), annotations, mediaType, httpHeaders, entityStream);
				break;

			case GResultData.EXIT_CODE_DIRECT_RESPONSE :
				break;

			default:
				break;
		}
	}

	/**
	 * {@link MessageBodyWriter}を取得します<br>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param clazz クラス型
	 * @param type ジェネリクス型
	 * @param annotations アノテーション
	 * @param mediaType メディアタイプ
	 * @return {@link MessageBodyWriter}インスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private <T> MessageBodyWriter<T> getBodyWriter(Class<T> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		MessageBodyWriter<T> writer = GMessageBodyFactory.getWriter(clazz, type, annotations, mediaType);
		if (Objects.isNull(writer)) {
			throw new GProviderNotFoundException(GFrameworkMessages.isNotFound(MessageBodyWriter.class));
		}
		return writer;
	}
	
	/**
	 * JsonBodyWriterを取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @param clazz クラス型
	 * @param type ジェネリクス型
	 * @param annotations アノテーション
	 * @param mediaType メディアタイプ
	 * @return JsonBodyWriterインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private MessageBodyWriter<Object> getJsonBodyWriter(Class<Object> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		MessageBodyWriter<Object> writer = GMessageBodyFactory.getWriter(clazz, type, annotations, mediaType);
		if (Objects.isNull(writer)) {
			throw new GProviderNotFoundException(GFrameworkMessages.isNotFound(MessageBodyWriter.class));
		}
		return writer;
	}

	/**
	 * {@link GResultData}からdataを取得します<br>
	 * 
	 * @create 2023/10/25
	 * @param entity {@GResultData}インスタンス
	 * @return Mapインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private Map<String, Object> getData(GResultData entity) {
		Map<String, Object> data = new HashMap<>();
		for (String key: entity.dataNameSet()) {
			data.put(key, entity.getData(key));
		}
		return data;
	}
	
	/**
	 * {@link GValidateError}リストを生成します。<br>
	 * 
	 * @create 2023/10/25
	 * @param validateErrors {@link GValidateError}リスト
	 * @return  {@link GValidateError}リスト
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private List<GValidateError> createIfEmpty(List<GValidateError> validateErrors) {
		return Optional.ofNullable(validateErrors).orElseGet(() -> new ArrayList<>());
	}
	
	/**
	 * {@link GSystemError}を生成します。<br>
	 * 
	 * @create 2023/10/25
	 * @param resultData {@link GResultData}インスタンス
	 * @return {@link GSystemError}インスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private GSystemError createSystemError(GResultData resultData) {
		GSystemError error = resultData.getException() == null ? GSystemError.create() : GSystemError.create(resultData.getException());
		error.setTimeStamp(OffsetDateTime.now(ZoneId.of("UTC")));
		error.setStatusCode(GHttpStatus.INTERNAL_SERVER_ERROR.getStatusCode());
		error.setMessage(GHttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		
		return error;
	}
}
