/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.MessageBodyWriter;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.web.GProviderNotFoundException;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GMessageBodyFactory;

/**
 * {@link GSystemError}をHTTPレスポンスボディに書き込むクラスです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Provider
@Produces({GMediaType.APPLICATION_JSON, GMediaType.TEXT_JSON})
@Priority(GPriority.NORMAL)
public class GSystemErrorMessageBodyWriter implements MessageBodyWriter<GSystemError> {

	/** TimeStampキー名 */
	private static final String TIMESTAMP = "timestamp";
	
	/** HTTPステータスコードキー名 */
	private static final String STATUS = "status";
	
	/** メッセージキー名 */
	private static final String MESSAGE = "message";
	
	/** 詳細キー名 */
	private static final String DESCRIPTION = "description";
	
	/** スタックトレースキー名 */
	private static final String STACKTRACE = "stacktrace";

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#isWriteable(Class, Type, Annotation[], MediaType)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return GSystemError.class.isAssignableFrom(type);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#writeTo(Object, Class, Type, Annotation[], MediaType, MultivaluedMap, OutputStream)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public void writeTo(GSystemError error, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream) throws IOException, WebApplicationException {
		Map<String, Object> result = new LinkedHashMap<>();
		
		result.put(TIMESTAMP, error.getTimeStamp());
		result.put(STATUS, error.getStatusCode().orElseGet(() -> null));
		result.put(MESSAGE, error.getMessage().orElseGet(() -> null));
		result.put(DESCRIPTION, error.getDescription());

		if (error.isEnableStackTrace()) {
			result.put(STACKTRACE, error.getStackTrace());
		}
		
		MessageBodyWriter<Object> writer = GMessageBodyFactory.getWriter(Object.class, result.getClass(), annotations, mediaType);
		if (Objects.isNull(writer)) {
			throw new GProviderNotFoundException(GFrameworkMessages.isNotFound(MessageBodyWriter.class));
		}
		writer.writeTo(result, Object.class, result.getClass(), annotations, mediaType, httpHeaders, entityStream);
	}
}