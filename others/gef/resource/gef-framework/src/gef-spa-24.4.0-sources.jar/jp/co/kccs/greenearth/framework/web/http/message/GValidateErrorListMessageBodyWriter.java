/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.MessageBodyWriter;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.web.GProviderNotFoundException;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GMessageBodyFactory;

/**
 * {@link GValidateError}配列をHTTPレスポンスボディに書き込むクラスです。<br>
 * 　※戻り値タイプがResponseであるEndpointに、List<GValidateError>のentityを持つResponseを返す場合、<br>
 * 　　本クラスではなく、GJsonBindingProviderにより処理されます。<br>
 * 　　例え、Endpointに：{@code return Response.ok().entity(new ArrayList<GValidateError>()).build();}<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Provider
@Produces({GMediaType.APPLICATION_JSON, GMediaType.TEXT_JSON})
@Priority(GPriority.NORMAL)
public class GValidateErrorListMessageBodyWriter implements MessageBodyWriter<List<GValidateError>> {

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#isWriteable(Class, Type, Annotation[], MediaType)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		if (!List.class.isAssignableFrom(type) || !ParameterizedType.class.isInstance(genericType)) {
			return false;
		}
		
		ParameterizedType parameterizedType = (ParameterizedType) genericType;
		Class<?> actualType = (Class<?>) parameterizedType.getActualTypeArguments()[0];
		return GValidateError.class.isAssignableFrom(actualType);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see MessageBodyWriter#writeTo(Object, Class, Type, Annotation[], MediaType, MultivaluedMap, OutputStream)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public void writeTo(List<GValidateError> errors, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream) throws IOException, WebApplicationException {
		MessageBodyWriter<Object> writer = GMessageBodyFactory.getWriter(Object.class, errors.getClass(), annotations, mediaType);
		if (Objects.isNull(writer)) {
			throw new GProviderNotFoundException(GFrameworkMessages.isNotFound(MessageBodyWriter.class));
		}
		writer.writeTo(errors, Object.class, errors.getClass(), annotations, mediaType, httpHeaders, entityStream);
	}
}
