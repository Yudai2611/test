/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message.internal;

import java.lang.reflect.Type;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.ContextResolver;

import org.glassfish.jersey.internal.ContextResolverFactory;

import jp.co.kccs.greenearth.commons.provider.GProviderService;

/**
 * {@link ContextResolver}を取得するファクトリクラスです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GContextResolverFactory {
	
	/**
	 * {@link ContextResolver}を取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @param <T> ContextResolverのジェネリクス型
	 * @param type タイプ
	 * @param mediaType メディアタイプ
	 * @return ContextResolverインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static <T> ContextResolver<T> getResolver(Type type, MediaType mediaType) {
		return getInstance().resolve(type, mediaType);
	}
	
	/**
	 * {@link ContextResolverFactory}のインスタンスを取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @return ContextResolverFactoryインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private static ContextResolverFactory getInstance() {
		return GProviderService.getInstance().getService(ContextResolverFactory.class);
	}
}
