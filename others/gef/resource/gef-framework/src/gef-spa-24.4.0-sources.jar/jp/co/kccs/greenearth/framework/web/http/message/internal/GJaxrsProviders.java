/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message.internal;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.ContextResolver;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.MessageBodyReader;
import jakarta.ws.rs.ext.MessageBodyWriter;
import jakarta.ws.rs.ext.Providers;

import jp.co.kccs.greenearth.framework.web.server.internal.GExceptionMapperFactory;

/**
 * {@link Providers}の実装クラスです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GJaxrsProviders implements Providers {

	/**
	 * {@inheritDoc}
	 *
	 * @see Providers#getContextResolver(Class, MediaType)
	 */
	@Override
	public <T> ContextResolver<T> getContextResolver(Class<T> type, MediaType mediaType) {
		return GContextResolverFactory.getResolver(type, mediaType);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see Providers#getExceptionMapper(Class)
	 */
	@Override
	public <T extends Throwable> ExceptionMapper<T> getExceptionMapper(Class<T> type) {
		return GExceptionMapperFactory.find(type).orElse(null);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see Providers#getMessageBodyReader(Class, Type, Annotation[], MediaType)
	 */
	@Override
	public <T> MessageBodyReader<T> getMessageBodyReader(Class<T> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return GMessageBodyFactory.getReader(type, genericType, annotations, mediaType);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see Providers#getMessageBodyWriter(Class, Type, Annotation[], MediaType)
	 */
	@Override
	public <T> MessageBodyWriter<T> getMessageBodyWriter(Class<T> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return GMessageBodyFactory.getWriter(type, genericType, annotations, mediaType);
	}

}
