/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message.internal;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.MessageBodyReader;
import jakarta.ws.rs.ext.MessageBodyWriter;

import org.glassfish.jersey.message.internal.MessageBodyFactory;

import jp.co.kccs.greenearth.commons.provider.GProviderService;

/**
 * {@link MessageBodyReader}及び{@link MessageBodyWriter}を取得するファクトリクラスです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GMessageBodyFactory {

	/**
	 * {@link MessageBodyReader}を取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @param <T> MessageBodyReaderのジェネリクス型
	 * @param clazz 読み取るクラス
	 * @param type 読み取るクラスのジェネリクス型
	 * @param annotations アノテーション
	 * @param mediaType メディアタイプ
	 * @return MessageBodyReaderインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static <T> MessageBodyReader<T> getReader(Class<T> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		return getInstance().getMessageBodyReader(clazz, type, annotations, mediaType);
	}
	
	/**
	 * {@link MessageBodyWriter}を取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @param <T> MessageBodyWriterのジェネリクス型
	 * @param clazz 書き込みクラス
	 * @param type 書き込みクラスのジェネリクス型
	 * @param annotations アノテーション
	 * @param mediaType メディアタイプ
	 * @return MessageBodyWriterインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static <T> MessageBodyWriter<T> getWriter(Class<T> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		return getInstance().getMessageBodyWriter(clazz, type, annotations, mediaType);
	}
	
	/**
	 * {@link MessageBodyFactory}のインスタンスを取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @return MessageBodyFactoryインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private static MessageBodyFactory getInstance() {
		return GProviderService.getInstance().getService(MessageBodyFactory.class);
	}
}
