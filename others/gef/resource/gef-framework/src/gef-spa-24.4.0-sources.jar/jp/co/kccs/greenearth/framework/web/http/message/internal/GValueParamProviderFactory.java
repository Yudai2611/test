/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.http.message.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.glassfish.jersey.server.model.Parameter;
import org.glassfish.jersey.server.model.Parameterized;
import org.glassfish.jersey.server.spi.internal.ParamValueFactoryWithSource;
import org.glassfish.jersey.server.spi.internal.ParameterValueHelper;
import org.glassfish.jersey.server.spi.internal.ValueParamProvider;

import jp.co.kccs.greenearth.commons.provider.GProviderService;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.resource.GMethodParameter;
import jp.co.kccs.greenearth.framework.web.server.handle.internal.GValueParamProviderAdapter;

/**
 * エンドポイントの引数型に一致した{@link ValueParamProvider}を取得するファクトリクラスです。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public final class GValueParamProviderFactory {

	/**
	 * 引数の値を解決するプロバイダーを取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @param resourceClass リソースクラス
	 * @param methodParameters エンドポイントメソッド引数
	 * @return プロバイダーリスト
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static List<ParamValueFactoryWithSource<?>> getProvider(Class<?> resourceClass, List<GMethodParameter> methodParameters) {
		List<ValueParamProvider> valueParamProviders = GProviderService.getInstance().getServices(ValueParamProvider.class).stream().collect(Collectors.toUnmodifiableList());
		List<ParamValueFactoryWithSource<?>> providers = new ArrayList<>(methodParameters.size());
		for (GMethodParameter methodParameter : methodParameters) {
			List<ValueParamProvider> customProviders = valueParamProviders.stream().filter(provider -> GValueParamProviderAdapter.class.isInstance(provider)).collect(Collectors.toUnmodifiableList());
			List<ParamValueFactoryWithSource<?>> custom = createParamValueFactory(customProviders, resourceClass, methodParameter, true);
			if (!custom.isEmpty() && Objects.nonNull(custom.get(0))) {
				providers.addAll(custom);
				continue;
			} else {
				List<ValueParamProvider> buildinProviders = valueParamProviders.stream().filter(provider -> !GValueParamProviderAdapter.class.isInstance(provider)).collect(Collectors.toUnmodifiableList());
				providers.addAll(createParamValueFactory(buildinProviders, resourceClass, methodParameter, false));
			}
		}
		return providers;
	}

	/**
	 * 引数の値を解決するプロバイダーを取得します。<br>
	 * 
	 * @create 2023/10/25
	 * @param providers ValueParamProviderリスト
	 * @param resourceClass リソースクラス
	 * @param methodParameter エンドポイントメソッド引数
	 * @param isOverride {@link org.glassfish.jersey.model.Parameter.Source}の上書き有無
	 * @return プロバイダーリスト
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private static List<ParamValueFactoryWithSource<?>> createParamValueFactory(List<ValueParamProvider> providers, Class<?> resourceClass, GMethodParameter methodParameter, boolean isOverride) {
		List<Parameter> parameters = getParameters(resourceClass, methodParameter, isOverride);
		return ParameterValueHelper.createValueProviders(providers, new Parameterized() {
			@Override
			public List<Parameter> getParameters() {
				return parameters;
			}

			@Override
			public boolean requiresEntity() {
				throw new UnsupportedOperationException(GFrameworkMessages.isNotSupported("requiresEntity()"));
			}
		});
	}
	
	/**
	 * {@link org.glassfish.jersey.server.model.Parameter}を取得します。<br>
	 * ※Jerseyの不具合（see JERSEY-2642）により従来アクションメソッドシグネチャ（GParameter, GResultData）が実行できないため、<br>
	 * {@link GValueParamProviderAdapter}は<code>Parameter.Source.UNKNOWN</code>への変換とする。
	 * 
	 * @create 2023/10/25
	 * @param resourceClass リソースクラス
	 * @param methodParameter メソッド引数
	 * @param isOverride {@link org.glassfish.jersey.model.Parameter.Source}の上書き有無
	 * @return {@link org.glassfish.jersey.server.model.Parameter}リスト
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private static List<Parameter> getParameters(Class<?> resourceClass, GMethodParameter methodParameter, boolean isOverride) {
		List<Parameter> parameters = new ArrayList<>();
		Parameter parameter = Parameter.create(resourceClass, resourceClass, methodParameter.isEncoded(), methodParameter.getRawType(), methodParameter.getGenericType(), methodParameter.getDeclaredAnnotations());
		if (isOverride) {
			Parameter overrideParameter = Parameter.overrideSource(parameter, Parameter.Source.UNKNOWN);
			parameters.add(overrideParameter);
		} else {
			parameters.add(parameter);
		}
		return parameters;
	}
}
