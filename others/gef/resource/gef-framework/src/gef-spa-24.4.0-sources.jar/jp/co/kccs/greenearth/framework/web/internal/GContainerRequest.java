/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.internal;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.net.URI;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ScheduledThreadPoolExecutor;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.container.ResourceInfo;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import org.glassfish.hk2.api.MultiException;
import org.glassfish.jersey.internal.PropertiesDelegate;
import org.glassfish.jersey.message.internal.MessageBodyFactory;
import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.internal.ContainerUtils;
import org.glassfish.jersey.servlet.async.AsyncContextDelegateProviderImpl;
import org.glassfish.jersey.servlet.internal.ResponseWriter;
import org.glassfish.jersey.servlet.spi.AsyncContextDelegate;
import org.glassfish.jersey.uri.UriComponent;

import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.Encoded;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Cookie;
import jakarta.ws.rs.core.Form;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Request;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;
import jakarta.ws.rs.core.UriBuilder;
import jakarta.ws.rs.core.UriBuilderException;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.ext.ReaderInterceptor;
import jp.co.kccs.greenearth.commons.provider.GProviderService;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GResponseWriter;
import jp.co.kccs.greenearth.framework.web.GWebRequest;

/**
 * {@link GWebRequest}の実装クラスです.<br>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GContainerRequest implements GWebRequest {

	private final HttpServletRequest nativeRequest;
	private final HttpServletResponse nativeResponse;
	private GResponseWriter responseWriter;
	private URI baseUri;
	private URI requestUri;
	private ContainerRequest requestDelegate;
	private GEndpointResource resource;
	private boolean resourceMatchingIsExecuted;

	public GContainerRequest(HttpServletRequest request, HttpServletResponse response) {
		this(request, response, null);
	}

	public GContainerRequest(HttpServletRequest request, HttpServletResponse response, ContainerRequestContext containerRequestContext) {
		if (Objects.isNull(request)) {
			throw new GContainerException(GFrameworkMessages.mustBeRequired(HttpServletRequest.class.getSimpleName()));
		}
		if (Objects.isNull(response)) {
			throw new GContainerException(GFrameworkMessages.mustBeRequired(HttpServletResponse.class.getSimpleName()));
		}
		initializeUri(request);
		if (Objects.isNull(containerRequestContext)) {
			this.requestDelegate = createRequestDelegate(request, response);
		} else if (containerRequestContext instanceof ContainerRequest) {
			this.requestDelegate = (ContainerRequest) containerRequestContext;
			((ContainerRequest) containerRequestContext).bufferEntity();
		} else if (containerRequestContext instanceof GContainerRequest) {
			this.requestDelegate = ((GContainerRequest) containerRequestContext).getContainerRequest();
		} else {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GContainerRequest.class.getSimpleName()));
		}
		this.nativeRequest = adjustParamDates(request, requestDelegate);
		this.nativeResponse = response;
		this.resourceMatchingIsExecuted = false;
		setResponseWriter(createResponseWriter(requestDelegate));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getProperty(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Object getProperty(String name) {
		return requestDelegate.getProperty(name);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getPropertyNames()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Collection<String> getPropertyNames() {
		return requestDelegate.getPropertyNames();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#setProperty(java.lang.String, java.lang.Object)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setProperty(String name, Object object) {
		requestDelegate.setProperty(name, object);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#removeProperty(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void removeProperty(String name) {
		requestDelegate.removeProperty(name);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getUriInfo()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public UriInfo getUriInfo() {
		return requestDelegate.getUriInfo();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#setRequestUri(java.net.URI)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setRequestUri(URI requestUri) {
		requestDelegate.setRequestUri(requestUri);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#setRequestUri(java.net.URI, java.net.URI)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setRequestUri(URI baseUri, URI requestUri) {
		requestDelegate.setRequestUri(baseUri, requestUri);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getRequest()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Request getRequest() {
		return requestDelegate.getRequest();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getMethod()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public String getMethod() {
		return requestDelegate.getMethod();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#setMethod(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setMethod(String method) {
		requestDelegate.setMethod(method);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getHeaders()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, String> getHeaders() {
		return requestDelegate.getHeaders();
	}

	/**
	 * {@inheritDoc}<br/>
	 * ヘッダー項目値がnullの場合はnull値、emptyの場合は空文字を返却します.<br/>
	 * 複数項目値が存在する場合、","で区切られた連結文字列を返却します。
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getHeaderString(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public String getHeaderString(String name) {
		return requestDelegate.getHeaderString(name);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getDate()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Date getDate() {
		return requestDelegate.getDate();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getLanguage()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Locale getLanguage() {
		return requestDelegate.getLanguage();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getLength()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public int getLength() {
		return requestDelegate.getLength();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getMediaType()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public MediaType getMediaType() {
		return requestDelegate.getMediaType();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getAcceptableMediaTypes()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<MediaType> getAcceptableMediaTypes() {
		return requestDelegate.getAcceptableMediaTypes();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getAcceptableLanguages()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<Locale> getAcceptableLanguages() {
		return requestDelegate.getAcceptableLanguages();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getCookies()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Map<String, Cookie> getCookies() {
		return requestDelegate.getCookies();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#hasEntity()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean hasEntity() {
		return requestDelegate.hasEntity();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getEntityStream()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public InputStream getEntityStream() {
		return requestDelegate.getEntityStream();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#setEntityStream(java.io.InputStream)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setEntityStream(InputStream input) {
		requestDelegate.setEntityStream(input);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#getSecurityContext()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public SecurityContext getSecurityContext() {
		return requestDelegate.getSecurityContext();
	}

	@Override
	public void setSecurityContext(SecurityContext context) {
		requestDelegate.setSecurityContext(context);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerRequestContext#abortWith(jakarta.ws.rs.core.Response)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void abortWith(Response response) {
		requestDelegate.abortWith(response);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.HttpHeaders#getRequestHeader(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<String> getRequestHeader(String name) {
		return getHeaders().get(name);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.HttpHeaders#getRequestHeaders()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, String> getRequestHeaders() {
		return getHeaders();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebRequest#getResponseWriter()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GResponseWriter getResponseWriter() {
		return responseWriter;
	}

	void setResponseWriter(GResponseWriter writer) {
		this.responseWriter = writer;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebRequest#getNativeRequest()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> T getNativeRequest() {
		return (T) nativeRequest;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebRequest#getNativeResponse()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> T getNativeResponse() {
		return (T) nativeResponse;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends ResourceInfo> Optional<T> getResource() {
		if (resourceMatchingIsExecuted) {
			return (Optional<T>) Optional.ofNullable(resource);
		}
		resourceMatchingIsExecuted = true;

		try {
			resource = GProviderService.getInstance().getService(GEndpointResource.class);
		} catch (MultiException exception) {
			if (exception.getCause() instanceof WebApplicationException) {
				throw (WebApplicationException) exception.getCause();
			}
			throw exception;
		}
		return (Optional<T>) Optional.ofNullable(resource);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebRequest#readEntity(java.lang.Class)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> T readEntity(Class<T> rawType) {
		return requestDelegate.readEntity(rawType);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebRequest#readEntity(java.lang.Class, java.lang.annotation.Annotation[])
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> T readEntity(Class<T> rawType, Annotation[] annotations) {
		return requestDelegate.readEntity(rawType, annotations);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebRequest#readEntity(java.lang.Class, java.lang.reflect.Type)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> T readEntity(Class<T> rawType, Type type) {
		return requestDelegate.readEntity(rawType, type);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebRequest#readEntity(java.lang.Class, java.lang.reflect.Type, java.lang.annotation.Annotation[])
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> T readEntity(Class<T> rawType, Type type, Annotation[] annotations) {
		return requestDelegate.readEntity(rawType, type, annotations);
	}

	/**
	 * リクエストデリゲートを取得します.
	 *
	 * @create 2023/10/25
	 * @return {@link ContainerRequest}
	 * @author yamashita
	 * @since 23.10.0
	 */
	public ContainerRequest getContainerRequest() {
		return requestDelegate;
	}

	protected void initializeUri(HttpServletRequest request) {
		UriBuilder uriBuilder = UriBuilder.fromUri(request.getRequestURL().toString());
		String decodedBasePath = new StringBuilder()
			.append(request.getContextPath())
			.append(request.getServletPath())
			.append("/")
			.toString();
		String encodedBasePath = UriComponent.encode(decodedBasePath, UriComponent.Type.PATH);
		if (!decodedBasePath.equals(encodedBasePath)) {
			throw new GContainerException(GFrameworkMessages.PERCENT_ENCODED_IN_CONTEXTPATH_ANDOR_SERVLETPATH.message());
		}
		try {
			this.baseUri = uriBuilder.replacePath(encodedBasePath).build();
			String queryParameters = ContainerUtils.encodeUnsafeCharacters(request.getQueryString());
			this.requestUri = uriBuilder
				.replacePath(request
					.getRequestURI())
				.replaceQuery(GStringUtils.nullToBlank(queryParameters))
				.build();
		} catch (UriBuilderException | IllegalArgumentException e) {
			throw new GContainerException(e);
		}
	}
	
	private ContainerRequest createRequestDelegate(HttpServletRequest request, HttpServletResponse response) {
		ContainerRequest containerRequest = new ContainerRequest (
			this.baseUri,
			this.requestUri,
			request.getMethod(),
			null,
			createPropertiesDelegate(request),
			null) {
			@Override
			protected java.lang.Iterable<ReaderInterceptor> getReaderInterceptors() {
				return Collections.<ReaderInterceptor> emptyList();
			};
		};
		containerRequest.setWriter(createResponseWriterDelegate(response));
		addRequestHeaders(request, containerRequest);
		try {
			containerRequest.setEntityStream(request.getInputStream());
			containerRequest.bufferEntity();
		} catch (IOException e) {
			throw new GContainerException(e);
		}
		containerRequest.setWorkers(GProviderService.getInstance().getService(MessageBodyFactory.class));
		return containerRequest;
	}

	private void addRequestHeaders(final HttpServletRequest request, final ContainerRequest requestContext) {
		for (Enumeration<String> e = request.getHeaderNames(); e.hasMoreElements();) {
			String headerName = e.nextElement();
			if (Objects.nonNull(request.getHeader(headerName))) {
				requestContext.headers(headerName, request.getHeader(headerName));
			}
		}
	}

	private ResponseWriter createResponseWriterDelegate(HttpServletResponse response) {
		new AsyncContextDelegateProviderImpl().createDelegate(nativeRequest, response);
		ResponseWriter responseWriter = new ResponseWriter(false, false, response, createAsyncContextDelegate(response), new ScheduledThreadPoolExecutor(1));
		return responseWriter;
	}

	private AsyncContextDelegate createAsyncContextDelegate(HttpServletResponse response) {
		return new AsyncContextDelegateProviderImpl().createDelegate(nativeRequest, response);
	}

	private GResponseWriter createResponseWriter(ContainerRequest requestDelegate) {
		return new GContainerResponseWriterAdapter(requestDelegate, requestDelegate.getResponseWriter());
	}

	private PropertiesDelegate createPropertiesDelegate(HttpServletRequest request) {
		return new PropertiesDelegate() {

			private HttpServletRequest request = null;
			PropertiesDelegate initialize(HttpServletRequest request) {
				this.request = request;
				return this;
			}

			@Override
			public void setProperty(String name, Object object) {
				request.setAttribute(name, object);
			}

			@Override
			public void removeProperty(String name) {
				request.removeAttribute(name);
			}

			@Override
			public Collection<String> getPropertyNames() {
				return Collections.list(request.getAttributeNames());
			}

			@Override
			public Object getProperty(String name) {
				return request.getAttribute(name);
			}
		}.initialize(request);
	}

	private HttpServletRequest adjustParamDates(final HttpServletRequest req, ContainerRequest requestDelegate) {
		final Map<String, String[]> adjustedParams = new HashMap<>();
		
		getQueryParameter(adjustedParams, requestDelegate);
		
		getRequestBody(adjustedParams, requestDelegate);
		
		return new HttpServletRequestWrapper(req) {
			@Override
			public String getParameter(String name) {
				return Objects.isNull(adjustedParams.get(name)) ? null : adjustedParams.get(name)[0];
			}

			@Override
			public Map<String, String[]> getParameterMap() {
				return adjustedParams;
			}

			@Override
			public Enumeration<String> getParameterNames() {
				return Collections.enumeration(adjustedParams.keySet());
			}

			@Override
			public String[] getParameterValues(String name) {
				return adjustedParams.get(name);
			}

			@Override
			public ServletInputStream getInputStream() {
				try {
					requestDelegate.getEntityStream().reset();
				} catch (IOException e) {
					new GContainerException(GFrameworkMessages.anIOErrorHasOccuOccurred("during InputStream initialization"));
				}
				return new GServletInputStream(requestDelegate.getEntityStream());
			}
		};
	}
	
	private void getQueryParameter(Map<String, String[]> map, ContainerRequest requestDelegate) {
		if (requestDelegate.getUriInfo().getQueryParameters() != null) {
			for (Entry<String, List<String>> entry : requestDelegate.getUriInfo().getQueryParameters().entrySet()) {
				map.put(entry.getKey(), entry.getValue().toArray(new String[entry.getValue().size()]));
			}
		}
	}
	
	private void getRequestBody(Map<String, String[]> map, ContainerRequest requestDelegate) {
		Map<String, List<String>> entityMap = requestDelegate.readEntity(Form.class, new Annotation[] {
			new Annotation() {
				@Override
				public Class<? extends Annotation> annotationType() {
					return Encoded.class;
				}
			}
		}).asMap();
		
		if (entityMap != null) {
			for (Entry<String, List<String>> entry : entityMap.entrySet()) {
				map.put(entry.getKey(), entry.getValue().toArray(new String[entry.getValue().size()]));
			}
		}
	}

	private static class GServletInputStream extends ServletInputStream {
		private InputStream inputStream;
		private boolean finished = false;
		public GServletInputStream(InputStream inputStream) {
			this.inputStream = inputStream;
		}
		@Override
		public boolean isFinished() {
			return this.finished;
		}

		@Override
		public boolean isReady() {
			return true;
		}

		@Override
		public void setReadListener(ReadListener readListener) {
			throw new UnsupportedOperationException();
		}

		@Override
		public int read() throws IOException {
			int data = inputStream.read();
			if (data == -1) {
				this.finished = true;
			}
			return data;
		}
	}
}