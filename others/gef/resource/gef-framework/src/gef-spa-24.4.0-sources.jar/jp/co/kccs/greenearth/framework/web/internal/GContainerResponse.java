/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.internal;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.net.URI;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.glassfish.jersey.message.internal.OutboundMessageContext;
import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.ContainerResponse;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.core.EntityTag;
import jakarta.ws.rs.core.Link;
import jakarta.ws.rs.core.Link.Builder;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.NewCookie;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.StatusType;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.GFrameworkPropertyKeys;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;

/**
 * {@link GWebResponse}を実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GContainerResponse implements GWebResponse {

	private GContainerRequest request;
	private Response response;
	private ContainerResponse responseDelegate;
	private final static int RESPONSE_CHUNKED_THRESHOLD_SIZE_DEFAULT = 8192;
	private int RESPONSE_CHUNKED_THRESHOLD_SIZE = Integer.parseInt(GFrameworkPropertyKeys.GEFRAME_SPA_WEB_SERVER_RESPONSE_CHUNKED_THRESHOLD_SIZE.getValue(String.valueOf(RESPONSE_CHUNKED_THRESHOLD_SIZE_DEFAULT)));

	public GContainerResponse(final GWebRequest request, final Response response) {
		if (Objects.isNull(request)) {
			throw new GContainerException(GFrameworkMessages.mustBeRequired(GWebRequest.class.getSimpleName()));
		}
		if (Objects.isNull(response)) {
			throw new GContainerException(GFrameworkMessages.mustBeRequired(Response.class.getSimpleName()));
		}
		if (!GContainerRequest.class.isInstance(request)) {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GContainerRequest.class.getSimpleName()));
		}
		this.request = (GContainerRequest) request;
		this.response = response;
		this.responseDelegate = createResponseDelegate(this.request.getContainerRequest(), response);
	}
	
	public GContainerResponse(final ContainerRequestContext request, final ContainerResponseContext response) {
		if (Objects.isNull(request)) {
			throw new GContainerException(GFrameworkMessages.mustBeRequired(ContainerRequestContext.class.getSimpleName()));
		}
		if (Objects.isNull(response)) {
			throw new GContainerException(GFrameworkMessages.mustBeRequired(ContainerResponseContext.class.getSimpleName()));
		}
		if (!GContainerRequest.class.isInstance(request)) {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GContainerRequest.class.getSimpleName()));
		}
		this.request = (GContainerRequest) request;

		if (response instanceof ContainerResponse) {
			this.responseDelegate = (ContainerResponse) response;
		} else if (response instanceof GContainerResponse) {
			this.responseDelegate = ((GContainerResponse) response).getContainerResponse();
		} else {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GContainerRequest.class.getSimpleName()));
		}
		this.response = Response.status(response.getStatus()).entity(response.getEntity()).build();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getStatus()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public int getStatus() {
		return responseDelegate.getStatus();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#setStatus(int)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setStatus(int code) {
		responseDelegate.setStatus(code);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getStatusInfo()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public StatusType getStatusInfo() {
		return responseDelegate.getStatusInfo();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#setStatusInfo(jakarta.ws.rs.core.Response.StatusType)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setStatusInfo(StatusType statusInfo) {
		responseDelegate.setStatusInfo(statusInfo);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getHeaders()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, Object> getHeaders() {
		return responseDelegate.getHeaders();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getStringHeaders()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, String> getStringHeaders() {
		return responseDelegate.getStringHeaders();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getHeaderString(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public String getHeaderString(String name) {
		return responseDelegate.getHeaderString(name);
	}

	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getAllowedMethods()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Set<String> getAllowedMethods() {
		return responseDelegate.getAllowedMethods();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getDate()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Date getDate() {
		return responseDelegate.getDate();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getLanguage()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Locale getLanguage() {
		return responseDelegate.getLanguage();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getLength()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public int getLength() {
		return responseDelegate.getLength();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#getMediaType()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public MediaType getMediaType() {
		return responseDelegate.getMediaType();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getCookies()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Map<String, NewCookie> getCookies() {
		return responseDelegate.getCookies();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getEntityTag()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public EntityTag getEntityTag() {
		return responseDelegate.getEntityTag();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getLastModified()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Date getLastModified() {
		return responseDelegate.getLastModified();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getLocation()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public URI getLocation() {
		return responseDelegate.getLocation();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getLinks()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Set<Link> getLinks() {
		return responseDelegate.getLinks();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#hasLink(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean hasLink(String relation) {
		return responseDelegate.hasLink(relation);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getLink(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Link getLink(String relation) {
		return responseDelegate.getLink(relation);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getLinkBuilder(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Builder getLinkBuilder(String relation) {
		return responseDelegate.getLinkBuilder(relation);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#hasEntity()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean hasEntity() {
		return responseDelegate.hasEntity();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getEntity()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Object getEntity() {
		return responseDelegate.getEntity();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getEntityClass()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Class<?> getEntityClass() {
		return responseDelegate.getEntityClass();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getEntityType()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Type getEntityType() {
		return responseDelegate.getEntityType();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#setEntity(java.lang.Object)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setEntity(Object entity) {
		responseDelegate.setEntity(entity);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#setEntity(java.lang.Object, java.lang.annotation.Annotation[], jakarta.ws.rs.core.MediaType)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setEntity(Object entity, Annotation[] annotations, MediaType mediaType) {
		responseDelegate.setEntity(entity, annotations, mediaType);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getEntityAnnotations()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Annotation[] getEntityAnnotations() {
		return responseDelegate.getEntityAnnotations();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#getEntityStream()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public OutputStream getEntityStream() {
		return responseDelegate.getEntityStream();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ContainerResponseContext#setEntityStream(java.io.OutputStream)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setEntityStream(OutputStream outputStream) {
		responseDelegate.setEntity(outputStream);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#getWebRequest()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GWebRequest getWebRequest() {
		return request;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#getNativeResponse()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T> T getNativeResponse() {
		return request.getNativeResponse();
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#commitStream()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void commitStream() {
		try {
			responseDelegate.commitStream();
		} catch (IOException e) {
			throw new GContainerException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#isCommitted()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean isCommitted() {
		return responseDelegate.isCommitted();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#close()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void close() {
		responseDelegate.close();
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#getResponse()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Response getResponse() {
		return response;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#setMediaType(jakarta.ws.rs.core.MediaType)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setMediaType(final MediaType mediaType) {
		responseDelegate.setMediaType(mediaType);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GWebResponse#getChunkedThresholdSize()
	 * @return
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	@Override
	public int getChunkedThresholdSize() {
		return RESPONSE_CHUNKED_THRESHOLD_SIZE;
	}

	/**
	 * レスポンスデリゲートを取得します.
	 * 
	 * @create 2023/10/25
	 * @return {@link ContainerResponse}
	 * @author yamashita
	 * @since 23.10.0
	 */
	public ContainerResponse getContainerResponse() {
		return responseDelegate;
	}

	/**
	 * レスポンスデリゲート({@link ContainerResponse})インスタンスを生成します.
	 * 
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @param response レスポンス
	 * @return {@link ContainerResponse}インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	ContainerResponse createResponseDelegate(final ContainerRequest request, final Response response) {
		ContainerResponse delegate =  new ContainerResponse(request, response);
		final boolean isHead = request.getMethod().equals(GHttpMethod.HEAD.name());
		delegate.setStreamProvider(new OutboundMessageContext.StreamProvider() {
			@Override
			public OutputStream getOutputStream(int contentLength) throws IOException {
				final OutputStream outputStream = request.getResponseWriter().writeResponseStatusAndHeaders(contentLength, delegate);
				return isHead ? null : outputStream;
			}
		});
		return delegate;
	}
}
