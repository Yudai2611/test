/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.internal;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Objects;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.spi.ContainerResponseWriter;

import jakarta.ws.rs.ext.WriterInterceptor;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GResponseWriter;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import lombok.Getter;

/**
 * {@link ContainerResponseWriter}を{@link GResponseWriter}にアダプトします.<br/>
 * インスタンス生成、各メソッド実行に利用される{@link GWebRequest}または{@link GWebResponse}は、
 * それぞれ{@link GContainerRequest}、{@link GContainerResponse}を必要とします。<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GContainerResponseWriterAdapter implements GResponseWriter {
	
	private static final Log LOGGER = LogFactory.getLog(GResponseWriter.class);

	@Getter
	private ContainerRequest requestDelegate;
	private ContainerResponseWriter adaptee;
	
	/**
	 * レスポンスライターのインスタンスを生成します.<br>
	 * コンストラクターでは、{@link GResponseWriter}のアダプターとして、{@link ContainerResponseWriter}を注入します。<br>
	 * 
	 * @create 2023/10/25
	 * @param request　リクエスト
	 * @param writer レスポンスライター
	 * @author yamashita
	 * @since 23.10.0
	 */
	public GContainerResponseWriterAdapter(ContainerRequest request, ContainerResponseWriter writer) {
		requireNonNull(request, GFrameworkMessages.mustBeRequired(ContainerRequest.class.getSimpleName()));
		requireNonNull(writer, GFrameworkMessages.mustBeRequired(ContainerResponseWriter.class.getSimpleName()));
		this.requestDelegate = request;
		this.adaptee = writer;
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GResponseWriter#failure(java.lang.Throwable)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void failure(final Throwable error) {
		adaptee.failure(error);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GResponseWriter#writeStatusAndHeaders(jp.co.kccs.greenearth.framework.web.GWebResponse, long)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public OutputStream writeStatusAndHeaders(GWebResponse response, long contentLength) {
		if (!GContainerResponse.class.isInstance(response)) {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GContainerResponse.class.getSimpleName()));
		}
		GContainerResponse concrete = (GContainerResponse) response;
		return adaptee.writeResponseStatusAndHeaders(contentLength, concrete.getContainerResponse());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GResponseWriter#commit()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void commit() throws GContainerException {
		adaptee.commit();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.GResponseWriter#write(jp.co.kccs.greenearth.framework.web.GWebResponse)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public OutputStream write(GWebResponse response) {
		LOGGER.info(GFrameworkMessages.$s_WRITE_STARTED.message(GResponseWriter.class.getSimpleName()));
		try {
			return requestDelegate.getWorkers()
						.writeTo(
								response.getEntity(),
								response.getEntity().getClass(),
								response.getEntityType(),
								response.getEntityAnnotations(),
								response.getMediaType(),
								response.getHeaders(),
								requestDelegate.getPropertiesDelegate(),
								response.getEntityStream(),
								Collections.<WriterInterceptor>emptyList());
		} catch (IOException e) {
			throw new GContainerException(e);
		}
	}
	
	private <T> T requireNonNull(T obj, String message) {
		return Objects.requireNonNull(obj, message);
	}
}
