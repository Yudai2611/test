/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.internal;

import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.UriInfo;

/**
 * {@link UriInfo}の拡張です.<br/>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
public interface GRequestUriInfo extends ResourceInfo, UriInfo {

}
