/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.internal;

import java.lang.reflect.Method;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.glassfish.jersey.server.internal.routing.UriRoutingContext;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.PathSegment;
import jakarta.ws.rs.core.UriBuilder;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import jp.co.kccs.greenearth.framework.web.resource.registry.GEndpointResourceRegistry;

/**
 * {@link GRequestUriInfo}の実装クラスです.
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
public class GRequestUriInfoImpl implements GRequestUriInfo {
	
	private UriRoutingContext uriInfoDelegate;

	public GRequestUriInfoImpl() {
		this.uriInfoDelegate = (UriRoutingContext) ((GContainerRequest) GHttpContextHolder.getContext().getWebRequest()).getContainerRequest().getUriInfo();
	}

	UriRoutingContext getUriInfoDelegate() {
		return uriInfoDelegate;
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getPath()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public String getPath() {
		return uriInfoDelegate.getPath();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getPath(boolean)
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public String getPath(boolean decode) {
		return uriInfoDelegate.getPath(decode);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getPathSegments()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public List<PathSegment> getPathSegments() {
		return uriInfoDelegate.getPathSegments();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getPathSegments(boolean)
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public List<PathSegment> getPathSegments(boolean decode) {
		return uriInfoDelegate.getPathSegments(decode);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getRequestUri()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public URI getRequestUri() {
		return uriInfoDelegate.getRequestUri();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getRequestUriBuilder()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public UriBuilder getRequestUriBuilder() {
		return uriInfoDelegate.getRequestUriBuilder();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getAbsolutePath()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public URI getAbsolutePath() {
		return uriInfoDelegate.getAbsolutePath();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getAbsolutePathBuilder()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public UriBuilder getAbsolutePathBuilder() {
		return uriInfoDelegate.getAbsolutePathBuilder();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getBaseUri()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public URI getBaseUri() {
		return uriInfoDelegate.getBaseUri();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getBaseUriBuilder()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public UriBuilder getBaseUriBuilder() {
		return uriInfoDelegate.getBaseUriBuilder();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getPathParameters()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, String> getPathParameters() {
		throw new UnsupportedOperationException(GFrameworkMessages.isNotSupported("getPathParameters()"));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getPathParameters(boolean)
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, String> getPathParameters(boolean decode) {
		throw new UnsupportedOperationException(GFrameworkMessages.isNotSupported("getPathParameters(boolean)"));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getQueryParameters()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, String> getQueryParameters() {
		return uriInfoDelegate.getQueryParameters();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getQueryParameters(boolean)
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public MultivaluedMap<String, String> getQueryParameters(boolean decode) {
		return uriInfoDelegate.getQueryParameters(decode);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getMatchedURIs()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public List<String> getMatchedURIs() {
		throw new UnsupportedOperationException(GFrameworkMessages.isNotSupported("getMatchedURIs()"));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getMatchedURIs(boolean)
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public List<String> getMatchedURIs(boolean decode) {
		throw new UnsupportedOperationException(GFrameworkMessages.isNotSupported("getMatchedURIs(boolean)"));
	}

	/**
	 * {@index}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#getMatchedResources()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public List<Object> getMatchedResources() {
		List<Object> resources = new ArrayList<>();
		resources.addAll(GEndpointResourceRegistry.getInstance().lookup(GHttpContextHolder.getContext().getWebRequest()));
		return resources;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#resolve(java.net.URI)
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public URI resolve(URI uri) {
		return uriInfoDelegate.resolve(uri);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.core.UriInfo#relativize(java.net.URI)
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public URI relativize(URI uri) {
		return uriInfoDelegate.relativize(uri);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ResourceInfo#getResourceMethod()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public Method getResourceMethod() {
		GEndpointResource endpointResource = getMatchedEndpoint();
		if (Objects.nonNull(endpointResource)) {
			return endpointResource.getResourceMethod();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ResourceInfo#getResourceClass()
	 * @author okanishi
	 * @since 23.10.0
	 */
	@Override
	public Class<?> getResourceClass() {
		GEndpointResource endpointResource = getMatchedEndpoint();
		if (Objects.nonNull(endpointResource)) {
			return endpointResource.getResourceClass();
		}
		return null;
	}

	private GEndpointResource getMatchedEndpoint() {
		Object obj = getMatchedResources().get(0);
		if (Objects.nonNull(obj) && obj instanceof GEndpointResource) {
			GEndpointResource endpointResource = (GEndpointResource) getMatchedResources().get(0);
			return endpointResource;
		}
		return null;
	}
}
