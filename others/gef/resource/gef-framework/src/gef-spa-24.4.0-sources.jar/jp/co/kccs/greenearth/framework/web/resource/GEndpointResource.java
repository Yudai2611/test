/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.framework.action.MethodInterceptor;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Endpoint;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier;

/**
 * エンドポイントリソースを表現します.<br/>
 * エンドポイントメソッド({@link Endpoint}が付与されたメソッド)単位に生成され、{@link GResourceIdentifier}によりユニークに特定されます。<br/>
 * 主に、アクションリソースやエンドポイントメソッドのメタ情報を格納します。<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GEndpointResource extends ResourceInfo {
	
	/**
	 * エンドポイント識別子を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return エンドポイント識別子
	 * @author yamashita
	 * @since 23.10.0
	 */
	GResourceIdentifier getIdentifier();
	
	/**
	 * 指定したアノテーションがエンドポイントメソッドに定義されているか判定します.<br/>
	 * 定義されている場合、合致するアノテーションを返却します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param annotationClass
	 * @return 定義されたアノテーション
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<? extends Annotation> matchesAnnotation(Class<? extends Annotation> annotationClass);
	
	/**
	 * HTTPメソッドを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return HTTPメソッド
	 * @author yamashita
	 * @since 23.10.0
	 */
	GHttpMethod getHttpMethod();

	/**
	 * メディアタイプ(@Consumes)を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return メディアタイプ(@Consumes)
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<? extends MediaType> getConsumes();
	
	/**
	 * メディアタイプ(@Produces)を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return メディアタイプ(@Produces)
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<? extends MediaType> getProduces();
	
	/**
	 * エンドポイントメソッドに宣言された{@link MethodInterceptor}アノテーション一覧を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return
	 * @author yamashita
	 * @since 23.10.0
	 */
	Annotation[] getAnnotationsHasInterceptor();
	
	/**
	 * エンドポイントメソッドの全ての引数パラメータを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return 全ての引数パラメータ
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<GMethodParameter> getParameters();

	/**
	 * エンドポイントリソースクラスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ResourceInfo#getResourceClass()
	 * @return リソースクラス
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	Class<?> getResourceClass();
	
	/**
	 * エンドポイントリソースメソッドを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @see jakarta.ws.rs.container.ResourceInfo#getResourceMethod()
	 * @return リソースメソッド
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	Method getResourceMethod();
}