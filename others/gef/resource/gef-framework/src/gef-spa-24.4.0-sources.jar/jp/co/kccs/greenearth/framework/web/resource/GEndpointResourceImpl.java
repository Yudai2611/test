/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.Encoded;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.GFrameworkPropertyKeys;
import jp.co.kccs.greenearth.framework.action.MethodInterceptor;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGenerator;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGeneratorProvider;
import lombok.Getter;

/**
 * {@link GEndpointResource}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GEndpointResourceImpl implements GEndpointResource {

	@Getter
	private Class<?> resourceClass;
	@Getter
	private Method resourceMethod;
	@Getter
	private GResourceIdentifier identifier;
	@Getter
	private Optional<String> path;
	@Getter
	private GHttpMethod httpMethod;
	@Getter
	private List<? extends MediaType> consumes;
	@Getter
	private List<? extends MediaType> produces;
	private Annotation[] methodAnnotationsHasMethodInterceptor;
	private List<GMethodParameter> methodParameters;
	@Getter
	private GResourceIdentifierGeneratorProvider<GEndpointResource> resourceIdentifierProvider;
	
	public GEndpointResourceImpl(Class<?> resourceClass, Method resourceMethod) {
		this.resourceClass = Objects.requireNonNull(resourceClass, GFrameworkMessages.mustBeRequired("Resource Class"));
		this.resourceMethod = Objects.requireNonNull(resourceMethod, GFrameworkMessages.mustBeRequired("Resource Method"));
		this.path = createPath();
		this.httpMethod = createHttpMethod();
		this.consumes = createMediaType(Consumes.class, GFrameworkPropertyKeys.GEFRAME_SPA_WEB_RESOURCE_ENDPOINT_CONSUMES_DEFAULT.getValue());
		this.produces = createMediaType(Produces.class, GFrameworkPropertyKeys.GEFRAME_SPA_WEB_RESOURCE_ENDPOINT_PRODUCES_DEFAULT.getValue());
		this.methodAnnotationsHasMethodInterceptor = createAnnotationsHasMethodInterceptor();
		this.methodParameters = createMethodParameters(resourceMethod);
		this.identifier = createIdentifier();
	}

	public GEndpointResourceImpl(ResourceInfo resourceInfo) {
		this(resourceInfo.getResourceClass(), resourceInfo.getResourceMethod());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.GEndpointResource#matchesAnnotation(java.lang.Class)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Optional<? extends Annotation> matchesAnnotation(Class<? extends Annotation> annotationClass) {
		return matchesAnnotationInternal(resourceMethod, annotationClass);
	}

	private Optional<? extends Annotation> matchesAnnotationInternal(AnnotatedElement target, Class<? extends Annotation> annotationClass) {
		if (Objects.isNull(annotationClass)) {
			return Optional.empty();
		}
		return Stream.of(target.getDeclaredAnnotations()).filter(annotation ->
				GReflectionHelper.isMatch(annotation, annotationClass)
		).findFirst();
	}

	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.GEndpointResource#getParameters()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<GMethodParameter> getParameters() {
		return methodParameters;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.GEndpointResource#getAnnotationsHasInterceptor()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Annotation[] getAnnotationsHasInterceptor() {
		return methodAnnotationsHasMethodInterceptor;
	}

	private GResourceIdentifierGeneratorProvider<GEndpointResource> getIdentifierProvider() {
		if (Objects.isNull(resourceIdentifierProvider)) {
			resourceIdentifierProvider = GFrameworkUtils.getComponent(GResourceIdentifierGeneratorProvider.class.getName());
		}
		return resourceIdentifierProvider;
	}

	private GResourceIdentifier createIdentifier() {
		GResourceIdentifierGenerator<GEndpointResource> resourceIdentifierGenerator = getIdentifierProvider().getGenerator(this);
		return resourceIdentifierGenerator.generate(this).orElse(null);
	}
	private GHttpMethod createHttpMethod() {
		return GHttpMethod.supportedAnnotations()
					.stream()
					.filter(method -> !matchesAnnotation(method).isEmpty())
					.findFirst()
					.map(v -> GHttpMethod.matches(v))
					.orElse(GHttpMethod.getDefault());
	}

	private List<? extends MediaType> createMediaType(Class<? extends Annotation> mediaType, String defaultValue) {
		Annotation annotation = getMediaTypeAnnotation(mediaType);
		try {
			return GMediaType.createFrom(annotation, defaultValue);
		} catch (ParseException e) {
			throw new GFrameworkException(GFrameworkMessages.failedToParse(MediaType.class.getSimpleName()) + " mediaType=" + (Objects.isNull(annotation) ? defaultValue : GReflectionHelper.getAnnotationValues(annotation).map(v -> v[0]).orElse(null)), e);
		}
	}
	private Annotation getMediaTypeAnnotation(Class<? extends Annotation> mediaType) {
		Optional<? extends Annotation> annotation = matchesAnnotation(mediaType);
		if (annotation.isEmpty()) {
			annotation = matchesAnnotationInternal(resourceClass, mediaType);
		}
		return annotation.orElse(null);
	}

	public Annotation[] createAnnotationsHasMethodInterceptor() {
		List<Annotation> annotations = Stream.of(resourceMethod.getDeclaredAnnotations())
			.filter(annotation ->
				annotation.annotationType().isAnnotationPresent(MethodInterceptor.class)
			)
			.collect(Collectors.toList());
		return annotations.toArray(new Annotation[annotations.size()]);
	}

	private Optional<String> createPath() {
		return matchesAnnotation(Path.class).map(v -> ((Path) v).value());
	}

	private List<GMethodParameter> createMethodParameters(Method resourceMethod) {
		Objects.requireNonNull(resourceMethod, GFrameworkMessages.mustBeRequired("Resource Method"));
		Class<?>[] parameterTypes = resourceMethod.getParameterTypes();
		Type[] genericParameterTypes = resourceMethod.getGenericParameterTypes();

		if (parameterTypes.length != genericParameterTypes.length) {
			Type[] newGenericParameterTypes = new Type[parameterTypes.length];
			newGenericParameterTypes[0] = parameterTypes[0];
			System.arraycopy(genericParameterTypes, 0, newGenericParameterTypes, 1, genericParameterTypes.length);
			genericParameterTypes = newGenericParameterTypes;
		}
		return createMethodParameterList(parameterTypes, genericParameterTypes, resourceMethod.getParameterAnnotations());
	}

	private List<GMethodParameter> createMethodParameterList(Class<?>[] parameterTypes, Type[] genericParameterTypes,
		Annotation[][] parameterAnnotations) {
		List<GMethodParameter> parameters = new ArrayList<>();
		int length = parameterTypes.length;
		for (int i = 0; i < length; i++) {
			GMethodParameter parameter = createMethodParameter(
											parameterTypes[i],
											genericParameterTypes[i],
											parameterAnnotations[i]);
			parameters.add(parameter);
		}
		if (length != parameters.size()) {
			throw new GFrameworkException(GFrameworkMessages.DECLARED_METHOD_PARAMETER_AND_CREATED_PARAMETER_LENGTH_DONT_MATCH.message());
		}
		return Collections.unmodifiableList(parameters);
	}

	private GMethodParameter createMethodParameter(Class<?> rawType, Type genericType, Annotation[] parameterAnnotations) {
		Annotation priorityAnnotation = null;
		String defaultValue = null;
		boolean isEncoded = Boolean.parseBoolean(
								GFrameworkPropertyKeys.GEFRAME_SPA_WEB_RESOURCE_METHOD_ARGUMENT_ENCODED_DEFAULT.getValue(String.valueOf(false))
							);
		String variableName = null;
		for (Annotation annotation : Arrays.asList(parameterAnnotations)) {
			if (GReflectionHelper.isMatch(annotation, Encoded.class)) {
				isEncoded = true;
			} else if (GReflectionHelper.isMatch(annotation, DefaultValue.class)) {
				defaultValue = ((DefaultValue) annotation).value();
			} else {
				if (Objects.isNull(priorityAnnotation)) {	// 後勝ち
					priorityAnnotation = annotation;
					variableName = GReflectionHelper.getAnnotationValue(annotation).orElse(null);
				}
			}
		}
		return GMethodParameter.builder()
								.rawType(rawType)
								.genericType(genericType)
								.declaredAnnotations(parameterAnnotations)
								.isEncoded(isEncoded)
								.defaultValue(defaultValue)
								.priorityAnnotation(priorityAnnotation)
								.variableName(variableName)
								.build();
	}
}
