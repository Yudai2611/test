/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Optional;

/**
 * メソッド引数のパラメータを表します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GMethodParameter {

	/**
	 * 型(Raw Type)を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return 型(Raw Type)
	 * @author yamashita
	 * @since 23.10.0
	 */
	Class<?> getRawType();
	
	/**
	 * 総称型(Generic Type)を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return 総称型(Generic Type)
	 * @author yamashita
	 * @since 23.10.0
	 */
	Type getGenericType();
	
	/**
	 * メソッドに定義されたアノテーションの一覧を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return アノテーション一覧
	 * @author yamashita
	 * @since 23.10.0
	 */
	Annotation[] getDeclaredAnnotations();

	/**
	 * メソッド引数の値をエンコードするかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return true: エンコードする / false: エンコードしない
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean isEncoded();
	
	/**
	 * メソッド引数のデフォルト値を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return メソッド引数のデフォルト値
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<String> getDefaultValue();
	
	/**
	 * 引数に修飾された1つ以上のアノテーションの中で、最も優先されるアノテーションを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return 優先されるアノテーション
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<Annotation> getPriorityAnnotation();
	
	/**
	 * メソッド引数の変数名を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return メソッド引数の変数名
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<String> getVariableName();
	
	/**
	 * {@link GMethodParameter}を構築するためのビルダーを生成します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GMethodParameter}を構築するためのビルダー
	 * @author yamashita
	 * @since 23.10.0
	 */
	static Builder builder() {
		return new Builder();
	}

	static class Builder {

		private Class<?> rawType;
		private Type genericType;
		private Annotation[] declaredAnnotations;
		private boolean isEncoded;
		private Optional<String> defaultValue;
		private Optional<Annotation> priorityAnnotation;
		private Optional<String> variableName;

		public Builder rawType(Class<?> rawType) {
			this.rawType = rawType;
			return this;
		}

		public Builder genericType(Type genericType) {
			this.genericType = genericType;
			return this;
		}

		public Builder declaredAnnotations(Annotation[] declaredAnnotations) {
			this.declaredAnnotations = declaredAnnotations;
			return this;
		}

		public Builder isEncoded(boolean isEncoded) {
			this.isEncoded = isEncoded;
			return this;
		}

		public Builder defaultValue(String defaultValue) {
			this.defaultValue = Optional.ofNullable(defaultValue);
			return this;
		}

		public Builder priorityAnnotation(Annotation priorityAnnotation) {
			this.priorityAnnotation = Optional.ofNullable(priorityAnnotation);
			return this;
		}
		
		public Builder variableName(String variableName) {
			this.variableName = Optional.ofNullable(variableName);
			return this;
		}

		public GMethodParameter build() {
			return new GMethodParameterImpl(rawType, genericType, declaredAnnotations, isEncoded, getOrElseNull(defaultValue), getOrElseNull(priorityAnnotation), getOrElseNull(variableName));
		}
		
		private <T> T getOrElseNull(Optional<T> t) {
			return t.orElse(null);
		}
	}
}
