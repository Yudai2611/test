/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Optional;

import lombok.Getter;

/**
 * {@link GMethodParameter}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Getter
public class GMethodParameterImpl implements GMethodParameter {

	private Class<?> rawType;
	private Type genericType;
	private Annotation[] declaredAnnotations; // 引数に宣言されたアノテーション
	private boolean isEncoded;	// default: false
	private Optional<String> defaultValue;
	private Optional<Annotation> priorityAnnotation;
	private Optional<String> variableName;

	public GMethodParameterImpl(Class<?> rawType, Type genericType, Annotation[] declaredAnnotations, boolean isEncoded,
								String defaultValue, Annotation priorityAnnotation, String variableName) {
		this.rawType = rawType;
		this.genericType = genericType;
		this.declaredAnnotations = declaredAnnotations;
		this.isEncoded = isEncoded;
		this.defaultValue = Optional.ofNullable(defaultValue);
		this.priorityAnnotation = Optional.ofNullable(priorityAnnotation);
		this.variableName = Optional.ofNullable(variableName);
	}
}
