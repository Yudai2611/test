/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.co.kccs.greenearth.framework.action.MethodInterceptor;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;

/**
 * アクションメソッドに対してコネクションの接続と解放を自動化するアノテーションです.<br>
 * <b>@MethodInterceptor(GConnectionInterceptor.class)</b>を簡略化します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@MethodInterceptor(interceptBy = GConnectionInterceptor.class)
public @interface Connection {
	
	/** パラメータ. */
	String[] params() default {};
}
