/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * エンドポイントリソースを表現します.<br/>
 * エンドポイントメソッドに定義します。<br/>
 * 
 * <pre>
 * {@code
 *      @Endpoint
 *      &#064;DELETE
 *      &#064;Connection
 *      &#064;Consumes(MediaType.APPLICATION_FORM_URLENCODED + ";charset=UTF-16;qs=1.1")
 *      &#064;Produces(MediaType.APPLICATION_JSON + ";charset=SHIFT_JIS;qs=1.2")
 *      &#064;ActionInterceptor(value = GTransactionInterceptor.class)
 *      &#064;Transaction
 *      public Response deleteById(@PathParam("id") Long id) throws URISyntaxException {
 *      ...
 *           return Response.status(Status.OK).build();
 *      }
 * }
 * </pre>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Endpoint {
}
