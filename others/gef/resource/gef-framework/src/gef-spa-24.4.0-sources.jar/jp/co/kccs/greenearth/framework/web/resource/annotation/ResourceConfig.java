/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;

/**
 * アプリケーションを構成するアノテーションです	.<br>
 * {@link GAbstractResourceConfigurator}を継承したクラスに付与することで自動スキャンされます。<br>
 * ※ただし、アノテーションを付与するだけでは自動スキャン対象にはなりません。スキャン対象パッケージ配下に配置する必要があります。<br>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ResourceConfig {
}
