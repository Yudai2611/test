/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.co.kccs.greenearth.framework.action.MethodInterceptor;
import jp.co.kccs.greenearth.framework.db.GTransactionInterceptor;

/**
 * アクションメソッドに対してトランザクション処理を自動化するアノテーションです.<br>
 * <b>@@MethodInterceptorInterceptor(GTransactionInterceptor.class)</b>を簡略化します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@MethodInterceptor(interceptBy = GTransactionInterceptor.class)
public @interface Transaction {

	/** パラメータ. */
	String[] params() default {};
}
