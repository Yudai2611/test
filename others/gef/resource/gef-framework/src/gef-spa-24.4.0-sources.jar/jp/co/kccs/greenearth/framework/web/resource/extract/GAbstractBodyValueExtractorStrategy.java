/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;


import static jp.co.kccs.greenearth.framework.GFrameworkMessages.*;

import java.io.InputStream;
import java.util.Objects;
import java.util.function.Function;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.ext.MessageBodyReader;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GMessageBodyFactory;

/**
 *
 * @see GBodyValuesExtractorStrategy
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public abstract class GAbstractBodyValueExtractorStrategy<T> implements GBodyValuesExtractorStrategy {
	private static final Log LOGGER = LogFactory.getLog(GAbstractBodyValueExtractorStrategy.class);
	protected GResourceKeyPairExtractor.GResourceKeyPair extractInternal(HttpServletRequest request, Class<T> contentTypeClazz, Function<T, GResourceKeyPairExtractor.GResourceKeyPair> wrapResourceFunction) {
		MediaType mediaType = GMediaType.valueOf(request.getContentType());
		MessageBodyReader<T> reader = GMessageBodyFactory.getReader(contentTypeClazz, contentTypeClazz, null, mediaType);
		T body = null;
		try {
			InputStream bodyInputStream =  request.getInputStream();
			if (Objects.nonNull(bodyInputStream)) {
				body = reader.readFrom(contentTypeClazz, contentTypeClazz, null, mediaType, new MultivaluedHashMap<>(), bodyInputStream);
			}
		} catch (Exception e) {
			LOGGER.warn(AN_IO_ERROR_HAS_OCCURRED_$s.message("while extracting action bean and action method from request body"));
		}

		return wrapResourceFunction.apply(body);
	}
}
