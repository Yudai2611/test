/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GBodyValuesExtractorStrategy}を提供します.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GBodyValuesExtractorProvider {
	/**
	 * 指定したリクエスト内容に対応する{@link GBodyValuesExtractorStrategy}を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param httpServletRequest
	 * @return ストラテジー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GBodyValuesExtractorStrategy> getStrategy(HttpServletRequest httpServletRequest);
	
	/**
	 * {@link GBodyValuesExtractorProvider}のインスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GBodyValuesExtractorProvider}インスタンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static GBodyValuesExtractorProvider getInstance() {
		return GFrameworkUtils.getComponent(GBodyValuesExtractorProvider.class);
	}
}
