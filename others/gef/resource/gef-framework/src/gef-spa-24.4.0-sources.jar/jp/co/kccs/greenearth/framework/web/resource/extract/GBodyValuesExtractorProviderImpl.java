/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;

/**
 * {@link GBodyValuesExtractorProvider}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author dhiaz chebastian
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
		@Modifier(isPublic = true)
	},
	scannedAssignableTypes = GBodyValuesExtractorStrategy.class)
public class GBodyValuesExtractorProviderImpl implements GBodyValuesExtractorProvider {
	private List<GBodyValuesExtractorStrategy> strategies;

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GBodyValuesExtractorProvider#getStrategy(jakarta.servlet.http.HttpServletRequest)
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GBodyValuesExtractorStrategy> getStrategy(HttpServletRequest request) {
		for (GBodyValuesExtractorStrategy strategy : getStrategies()) {
			if (isStrategySupported(strategy, request)) {
				return Optional.of(strategy);
			}
		}
		return Optional.empty();
	}

	private boolean isStrategySupported(GBodyValuesExtractorStrategy strategy, HttpServletRequest servletRequest) {
		if (strategy.getClass().isAnnotationPresent(Consumes.class)) {
			String[] mediaTypes = strategy.getClass().getAnnotation(Consumes.class).value();
			String requestContentType = servletRequest.getContentType();
			if (Objects.isNull(requestContentType)) {
				return false;
			}
			for (String mediaType: mediaTypes) {
				MediaType supportedMediaType = GMediaType.valueOf(mediaType);
				MediaType requestMediaType = GMediaType.valueOf(requestContentType);
				if (supportedMediaType.isCompatible(requestMediaType)) {
					return true;
				}
			}
		}
		return false;
	}
	private synchronized List<GBodyValuesExtractorStrategy> filterNoConsumesAnnotation(List<GBodyValuesExtractorStrategy> strategies) {
		return strategies.stream().filter(strategy -> strategy.getClass().isAnnotationPresent(Consumes.class)).collect(Collectors.toList());
	}

	private synchronized List<GBodyValuesExtractorStrategy> getStrategies() {
		if (Objects.isNull(strategies)) {
			strategies = GScanComponentService.getInstance().getScannedInstances(getClass());
			strategies = filterNoConsumesAnnotation(strategies);
		}
		return strategies;
	}
}
