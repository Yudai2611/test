/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor.GResourceKeyPair;

/**
 * リクエストボディの内容（Content-Type）に合わせた抽出方法を変更するためのストラテジーです.<br/>
 * 
 * @create 2023/10/25
 * @author dhiaz chebastian
 * @since 23.10.0
 */
public interface GBodyValuesExtractorStrategy {
	
	/**
	 * リクエストボディからキーペア({@link GResourceKeyPair})を抽出します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param httpServletRequest リクエスト
	 * @return キーペア
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	GResourceKeyPair extract(HttpServletRequest httpServletRequest);
}
