/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.core.MultivaluedMap;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;

/**
 *
 * @see GBodyValuesExtractorStrategy
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
@Priority(GPriority.LOW)
public class GFormBodyValuesExtractorStrategy extends GAbstractBodyValueExtractorStrategy<MultivaluedMap> {
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GBodyValuesExtractorStrategy#extract(jakarta.servlet.http.HttpServletRequest)
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GResourceKeyPairExtractor.GResourceKeyPair extract(HttpServletRequest request) {
		return extractInternal(request, MultivaluedMap.class, (body)-> {
			if (Objects.nonNull(body)) {
				String bean = getParameterCaseInsensitive(body, GFrameworkReservedWords.PARAMETER_NAME_ACTION_BEAN.key());
				String method = getParameterCaseInsensitive(body, GFrameworkReservedWords.PARAMETER_NAME_ACTION_METHOD.key());
				return new GResourceKeyPairExtractor.GResourceKeyPair(bean, method);
			}
			return GResourceKeyPairExtractor.GResourceKeyPair.empty();
		});
	}
	private String getParameterCaseInsensitive(MultivaluedMap<String, Object> requestBody, String parameterName) {
		if (Objects.nonNull(requestBody)) {
			for (String parameterKey : requestBody.keySet()) {
				if (parameterKey.equalsIgnoreCase(parameterName)) {
					return (String) requestBody.get(parameterKey).get(0);
				}
			}
		}
		return null;
	}

}
