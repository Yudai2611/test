/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;


import java.util.Objects;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.priority.GPriority;

/**
 * {@link GResourceKeyPairExtractor}の実装クラスです.<br>
 * リクエストﾎﾞﾃﾞｨからキーペアを抽出します.<br/>
 * リクエストボディからの抽出方法は、ストラテジー({@link GBodyValuesExtractorStrategy})として分離します。<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
public class GFromBodyValuesExtractor implements GResourceKeyPairExtractor {
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor#extract(jakarta.servlet.http.HttpServletRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GResourceKeyPair extract(HttpServletRequest request) {
		if (checkIfContentTypeIsPresent(request)) {
			Optional<GBodyValuesExtractorStrategy> strategyOptional = GBodyValuesExtractorProvider.getInstance().getStrategy(request);
			if (strategyOptional.isPresent()) {
				return strategyOptional.get().extract(request);
			}
		}
		return GResourceKeyPair.empty();
	}
	
	private boolean checkIfContentTypeIsPresent(HttpServletRequest httpServletRequest) {
		String contentType = httpServletRequest.getContentType();
		return Objects.nonNull(contentType);
	}

}
