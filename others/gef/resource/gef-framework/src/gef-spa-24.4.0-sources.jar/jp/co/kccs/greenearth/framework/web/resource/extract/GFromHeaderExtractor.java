/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords;

/**
 * {@link GResourceKeyPairExtractor}の実装クラスです.<br>
 * リクエストヘッダーからキーペアとして、アクションメソッドおよびアクションメソッドパラメータを抽出します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Priority(GPriority.HIGH)
public class GFromHeaderExtractor implements GResourceKeyPairExtractor {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor#extract(jakarta.servlet.http.HttpServletRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GResourceKeyPair extract(HttpServletRequest request) {
		return new GResourceKeyPair(
			request.getHeader(GFrameworkReservedWords.HEADER_NAME_ACTION_BEAN.key()),
			request.getHeader(GFrameworkReservedWords.HEADER_NAME_ACTION_METHOD.key())
		);
	}
}
