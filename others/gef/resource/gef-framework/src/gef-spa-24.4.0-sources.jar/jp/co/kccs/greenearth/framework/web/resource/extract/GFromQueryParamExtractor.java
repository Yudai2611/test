/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.Map;
import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords;

/**
 * {@link GResourceKeyPairExtractor}の実装クラスです.<br>
 * リクエストパラメーターからキーペアとして、アクションメソッドおよびアクションメソッドパラメータを抽出します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Priority(GPriority.LOW)
public class GFromQueryParamExtractor implements GResourceKeyPairExtractor {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor#extract(jakarta.servlet.http.HttpServletRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GResourceKeyPair extract(HttpServletRequest request) {
		String bean = getParameterCaseInsensitive(request, GFrameworkReservedWords.PARAMETER_NAME_ACTION_BEAN.key());
		String method = getParameterCaseInsensitive(request, GFrameworkReservedWords.PARAMETER_NAME_ACTION_METHOD.key());
		return new GResourceKeyPair(bean, method);
	}

	private String getParameterCaseInsensitive(HttpServletRequest servletRequest, String parameterName) {
		Map<String, String[]> parameterMap = servletRequest.getParameterMap();
		if (Objects.nonNull(parameterMap)) {
			for (String parameterKey : parameterMap.keySet()) {
				if (parameterKey.equalsIgnoreCase(parameterName)) {
					String[] values = servletRequest.getParameterValues(parameterKey);
					if (Objects.nonNull(values)) {
						return values[0];
					}
				}
			}
		}
		return null;

	}

}
