/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.Map;
import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;

/**
 *
 * @see GBodyValuesExtractorStrategy
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Consumes({GMediaType.APPLICATION_JSON, GMediaType.TEXT_JSON, GMediaType.APPLICATION_XML, GMediaType.TEXT_XML})
@Priority(GPriority.LOW)
public class GMapBodyValuesExtractorStrategy extends GAbstractBodyValueExtractorStrategy<Map> {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GBodyValuesExtractorStrategy#extract(jakarta.servlet.http.HttpServletRequest)
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GResourceKeyPairExtractor.GResourceKeyPair extract(HttpServletRequest request) {
		return extractInternal(request, Map.class, (body)-> {
			if (Objects.nonNull(body)) {
				String bean = getMapValueByInsensitiveKey(body, GFrameworkReservedWords.PARAMETER_NAME_ACTION_BEAN.key());
				String method = getMapValueByInsensitiveKey(body, GFrameworkReservedWords.PARAMETER_NAME_ACTION_METHOD.key());
				return new GResourceKeyPairExtractor.GResourceKeyPair(
					bean,
					method
				);
			}
			return GResourceKeyPairExtractor.GResourceKeyPair.empty();
		});
	}

	private String getMapValueByInsensitiveKey(Map<String, Object> bodyMap, String targetKey) {
		for (String key : bodyMap.keySet()) {
			if (key.equalsIgnoreCase(targetKey)) {
				Object val = bodyMap.get(key);
				if (Objects.nonNull(val)) {
					return (String) val;
				} else {
					return null;
				}
			}
		}
		return null;
	}
}
