/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.Objects;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;

/**
 * {@link GMediaType#MULTIPART_FORM_DATA}の場合にキーペアを抽出するための{@link GBodyValuesExtractorStrategy}実装です.<br>
 * 
 * @create 2023/10/25
 * @author dhiaz chebastian
 * @since 23.10.0
 */
@Consumes(GMediaType.MULTIPART_FORM_DATA)
@Priority(GPriority.LOW)
public class GMultipartBodyValuesExtractorStrategy extends GAbstractBodyValueExtractorStrategy<FormDataMultiPart> {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GBodyValuesExtractorStrategy#extract(jakarta.servlet.http.HttpServletRequest)
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GResourceKeyPairExtractor.GResourceKeyPair extract(HttpServletRequest request) {
		return extractInternal(request, FormDataMultiPart.class, (body)-> {
			if (Objects.nonNull(body)) {
				String bean = getValueFromInsensitiveKey(body, GFrameworkReservedWords.PARAMETER_NAME_ACTION_BEAN.key());
				String method = getValueFromInsensitiveKey(body, GFrameworkReservedWords.PARAMETER_NAME_ACTION_METHOD.key());
				return new GResourceKeyPairExtractor.GResourceKeyPair(bean, method);
			}
			return GResourceKeyPairExtractor.GResourceKeyPair.empty();
		});
	}
	private String getValueFromInsensitiveKey(FormDataMultiPart multiPart, String targetKey) {
		if (Objects.nonNull(multiPart)) {
			for (String key : multiPart.getFields().keySet()) {
				if (key.equalsIgnoreCase(targetKey)) {
					FormDataBodyPart bodyPart = multiPart.getField(key);
					if (Objects.nonNull(bodyPart)) {
						return bodyPart.getValue();
					}
				}
			}
		}
		return null;
	}
}
