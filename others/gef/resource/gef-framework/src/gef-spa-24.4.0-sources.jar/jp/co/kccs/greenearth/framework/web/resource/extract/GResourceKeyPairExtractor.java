/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.Objects;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.collection.GPair;

/**
 * リクエストから特定のキーペアを抽出します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GResourceKeyPairExtractor {
	/**
	 * 指定したリクエストから{@link GResourceKeyPair}を抽出します.<br/>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return {@link GResourceKeyPair}
	 * @author yamashita
	 * @since 23.10.0
	 */
	GResourceKeyPair extract(HttpServletRequest request);

	/**
	 * キーのペアを表現するクラスです.<br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	class GResourceKeyPair extends GPair<String, String> {
		public GResourceKeyPair(String first, String second) {
			super(first, second);
		}
		public boolean isEmpty() {
			return Objects.isNull(getFirst()) || Objects.isNull(getSecond());
		}
		public static GResourceKeyPair empty() {
			return new GResourceKeyPair(null, null);
		}
	}
}
