/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor.GResourceKeyPair;

/**
 * リクエストからキーペア({@link GResourceKeyPairProvider})を抽出するためのインタフェースを規定します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GResourceKeyPairProvider {
	/**
	 * パラメータrequestにより、{@link GResourceKeyPair}を抽出する.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return {@link GResourceKeyPair}
	 * @author yamashita
	 * @since 23.10.0
	 */
	
	/**
	 * 指定したリクエストから{@link GResourceKeyPair}を抽出します.<br/>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return {@link GResourceKeyPair}
	 * @author yamashita
	 * @since 23.10.0
	 */
	GResourceKeyPair extract(HttpServletRequest request);

	/**
	 * {@link gresourcekeypairprovider}のインスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link gresourcekeypairprovider}インスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GResourceKeyPairProvider getInstance() {
		return GFrameworkUtils.getComponent(GResourceKeyPairProvider.class.getName());
	}
}
