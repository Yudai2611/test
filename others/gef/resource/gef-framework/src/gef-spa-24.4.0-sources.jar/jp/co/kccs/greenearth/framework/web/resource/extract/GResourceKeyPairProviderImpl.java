/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.extract;

import java.util.List;
import java.util.Objects;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor.GResourceKeyPair;
import lombok.NoArgsConstructor;

/**
 * {@link GResourceKeyPairProvider}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
			@Modifier(isPublic = true)
	},
	scannedAssignableTypes = GResourceKeyPairExtractor.class)
@NoArgsConstructor
public class GResourceKeyPairProviderImpl implements GResourceKeyPairProvider {
	
	List<GResourceKeyPairExtractor> extractors;
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairProvider#extract(jakarta.servlet.http.HttpServletRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GResourceKeyPair extract(HttpServletRequest request) {
		for (GResourceKeyPairExtractor extractor : getExtractors()) {
			GResourceKeyPair keyPair = extractor.extract(request);
			if (!keyPair.isEmpty()) {
				return keyPair;
			}
		}
		return new Null();
	}

	private synchronized List<GResourceKeyPairExtractor> getExtractors() {
		if (Objects.isNull(extractors)) {
			extractors = GScanComponentService.getInstance().getScannedInstances(getClass());
		}
		return extractors;
	}
	
	class Null extends GResourceKeyPair {
		public Null() {
			this(null, null);
		}
		public Null(String beanName, String methodName) {
			super(beanName, methodName);
		}
	}
}
