/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.identifier;

import java.util.Optional;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.GAbstractTypeSuppoter;
import jp.co.kccs.greenearth.commons.provider.SupportedType;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;

/**
 * エンドポイントリソース({@link GEndpointResource})からエンドポイント識別子を生成するための{@link GResourceIdentifierGenerator}実装です.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@SupportedType(GEndpointResource.class)
@Priority(GPriority.NORMAL)
public class GFromEndpointResourceGenerator extends GAbstractTypeSuppoter implements GResourceIdentifierGenerator<GEndpointResource> {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGenerator#generate(java.lang.Object)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Optional<GResourceIdentifier> generate(GEndpointResource material) {
		return Optional.ofNullable(
				new GResourceIdentifierImpl(
					material.getResourceClass(),
					material.getResourceMethod(),
					material.getHttpMethod(),
					material.getConsumes(),
					material.getProduces())
				);
	}
}
