/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.identifier;

import java.util.Arrays;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.GAbstractTypeSuppoter;
import jp.co.kccs.greenearth.commons.provider.SupportedType;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor.GResourceKeyPair;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairProvider;

/**
 * リクエスト({@link GWebRequest})からエンドポイント識別子を生成するための{@link GResourceIdentifierGenerator}実装です.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@SupportedType(GWebRequest.class)
@Priority(GPriority.NORMAL)
public class GFromWebRequestGenerator extends GAbstractTypeSuppoter implements GResourceIdentifierGenerator<GWebRequest> {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGenerator#generate(java.lang.Object)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override	
	public Optional<GResourceIdentifier> generate(GWebRequest material) {
		if (!HttpServletRequest.class.isInstance(material.getNativeRequest())) {
			return Optional.empty();
		}
		HttpServletRequest request =  material.getNativeRequest();
		GResourceKeyPair pair = GResourceKeyPairProvider.getInstance().extract(request);
		if (pair.isEmpty()) {
			return Optional.empty();
		}
		return Optional.of(
					new GResourceIdentifierImpl(
						pair.getFirst(),
						pair.getSecond(),
						GHttpMethod.valueFrom(material.getMethod()),
						Arrays.asList(material.getMediaType()),
						material.getAcceptableMediaTypes())
				);
	}
}
