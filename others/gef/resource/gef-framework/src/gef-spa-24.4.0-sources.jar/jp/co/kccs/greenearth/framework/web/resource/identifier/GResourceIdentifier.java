/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.identifier;

import java.util.List;
import java.util.Objects;

import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;

/**
 * エンドポイント識別子を表します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GResourceIdentifier {
	
	/**
	 * 指定した識別子と一致するかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param identifier エンドポイント識別子
	 * @return true: 一致 / false: 不一致
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean matches(GResourceIdentifier identifier);
	
	/**
	 * 指定したクラス名と一致するかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param className クラス名
	 * @return true: 一致 / false: 不一致
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean matchesClass(String className);
	
	/**
	 * 指定したメソッド名と一致するかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param methodName メソッド名
	 * @return true: 一致 / false: 不一致
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean matchesMethod(String methodName);
	
	/**
	 * 指定したHTTPメソッドと一致するかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param httpMethod HTTPメソッド名
	 * @return true: 一致 / false: 不一致
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean matchesHttpMethod(GHttpMethod httpMethod);
	
	/**
	 * 指定したメディアタイプ(@Consumes)と一致するかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param consumes メディアタイプ(@Consumes)
	 * @return true: 一致 / false: 不一致
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean matchesConsumes(List<? extends MediaType> consumes);
	
	/**
	 * 指定したメディアタイプ(@Produces)と一致するかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param produces メディアタイプ(@Produces)
	 * @return true: 一致 / false: 不一致
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean matchesProduces(List<? extends MediaType> produces);

	/**
	 * リソースクラス名を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return リソースクラスの完全修飾名称
	 * @author yamashita
	 * @since 23.10.0
	 */
	String getResourceClassName();
	
	/**
	 * リソースメソッド名を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return リソースメソッド名
	 * @author yamashita
	 * @since 23.10.0
	 */
	String getResourceMethodName();
	
	/**
	 * HTTPメソッドを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return HTTPメソッド
	 * @author yamashita
	 * @since 23.10.0
	 */
	GHttpMethod getHttpMethod();
	
	/**
	 * メディアタイプ(@Consumes)を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return メディアタイプ(@Consumes)
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<? extends MediaType> getConsumes();
	
	/**
	 * メディアタイプ(@Produces)を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return メディアタイプ(@Produces)
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<? extends MediaType> getProduces();
	
	/**
	 * エンドポイント識別子のマッチングユーティリティを提供します.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	static class Matcher {
		public static boolean matches(GResourceIdentifier identifier, GResourceIdentifier pattern) {
			return 
					matchesClass(identifier.getResourceClassName(), pattern.getResourceClassName()) &&
					matchesMethod(identifier.getResourceMethodName(), pattern.getResourceMethodName()) &&
					matchesHttpMethod(identifier.getHttpMethod(), pattern.getHttpMethod()) &&
					matchesConsumes(identifier.getConsumes(), pattern.getConsumes()) &&
					matchesProduces(identifier.getProduces(), pattern.getProduces());
		}
		
		public static boolean matchesClass(String resourceClassName, String pattern) {
			return resourceClassName.equals(pattern);
		}
		
		public static boolean matchesMethod(String resourceMethodName, String pattern) {
			return resourceMethodName.equals(pattern);
		}
		
		public static boolean matchesHttpMethod(GHttpMethod httpMethod,  GHttpMethod pattern) {
			return httpMethod.equals(pattern) || (httpMethod.equals(GHttpMethod.GET) && pattern.equals(GHttpMethod.HEAD));
		}
		
		public static boolean matchesConsumes(List<? extends MediaType> consumes, List<? extends MediaType> patterns) {
			return 	!consumes
					.stream()
					.filter(consume ->
						matchesConsumes(consume, patterns)
					)
					.findFirst()
					.isEmpty();
		}
		
		private static boolean matchesConsumes(MediaType consume, List<? extends MediaType> patterns) {
			return	(patterns
				.stream().anyMatch(pattern ->
					Objects.isNull(pattern) || consume.isCompatible(pattern)));
		}
		
		public static boolean matchesProduces(List<? extends MediaType> produces, List<? extends MediaType> patterns) {
			return 	!produces
					.stream()
					.filter(produce -> 
						!patterns
							.stream()
							.filter(pattern ->
								produce.isCompatible(pattern)
							)
							.findFirst()
							.isEmpty()
					)
					.findFirst()
					.isEmpty();
		}
	}
}
