/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.identifier;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.provider.GTypeSupporter;

/**
 * エンドポイント識別子({@link GResourceIdentifier})を生成します.<br/>
 * 
 * @create 2023/10/25
 * @param <T>
 * @author yamashita
 * @since 23.10.0
 */
public interface GResourceIdentifierGenerator<T> extends GTypeSupporter {
	/**
	 * 指定した値で{@link GResourceIdentifier}を生成します.<br/>
	 *
	 * @create 2023/10/25
	 * @param material 生成する素材
	 * @return {@link GResourceIdentifier}
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<GResourceIdentifier> generate(T material);
}
