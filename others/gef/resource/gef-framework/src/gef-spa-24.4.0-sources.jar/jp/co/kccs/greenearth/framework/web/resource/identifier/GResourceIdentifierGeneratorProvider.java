/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.identifier;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GResourceIdentifierGenerator}を提供します.<br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @param <T>
 * @since 23.10.0
 */
public interface GResourceIdentifierGeneratorProvider<T> {

	/**
	 * 指定した値に対応する{@link GResourceIdentifierGenerator}を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param material 生成する素材
	 * @return {@link GResourceIdentifierGenerator}
	 * @author yamashita
	 * @since 23.10.0
	 */
	GResourceIdentifierGenerator<T> getGenerator(T material);

	 static <T> GResourceIdentifierGeneratorProvider<T> getInstance() {
		return GFrameworkUtils.getComponent(GResourceIdentifierGeneratorProvider.class.getName());
	}
}
