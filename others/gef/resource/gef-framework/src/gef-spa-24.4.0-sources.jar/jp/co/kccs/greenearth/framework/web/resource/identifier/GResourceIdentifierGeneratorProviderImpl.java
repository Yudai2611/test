/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.identifier;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.provider.GAbstractTypeSupporterProvider;
import jp.co.kccs.greenearth.commons.provider.SupportedType;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import lombok.NoArgsConstructor;

/**
 * {@link GResourceIdentifierGeneratorProvider}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @param <T>
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
		@Modifier(isPublic = true)
	},
	scannedAnnotations = SupportedType.class,
	scannedAssignableTypes = GResourceIdentifierGenerator.class)
@NoArgsConstructor
public class GResourceIdentifierGeneratorProviderImpl<T> extends GAbstractTypeSupporterProvider<GResourceIdentifierGenerator<T>> implements GResourceIdentifierGeneratorProvider<T> {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGeneratorProvider#getGenerator(java.lang.Object)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GResourceIdentifierGenerator<T> getGenerator(T material) {
		Optional<GResourceIdentifierGenerator<T>> supporter = getTypeSupporter(material);
		return supporter
				.orElseThrow(() -> {
					throw new GContainerException(GFrameworkMessages.isNotFound(GResourceIdentifierGenerator.class.getSimpleName()));
				});
	}
}
