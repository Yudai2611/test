/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.identifier;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import lombok.Getter;

/**
 * {@link GResourceIdentifier}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Getter
public class GResourceIdentifierImpl implements GResourceIdentifier {

	private String resourceClassName;
	private String resourceMethodName;
	private GHttpMethod httpMethod;
	private List<? extends MediaType> consumes;
	private List<? extends MediaType> produces;

	public GResourceIdentifierImpl(Class<?> resourceClass, Method resourceMethod, GHttpMethod httpMethod, List<? extends MediaType> consumes, List<? extends MediaType> produces) {
		this(Optional.ofNullable(resourceClass).map(v -> v.getName()).orElse(null),
			Optional.ofNullable(resourceMethod).map(v -> v.getName()).orElse(null),
			httpMethod,
			consumes,
			produces);
	}
	
	public GResourceIdentifierImpl(String resourceClassName, String resourceMethodName, GHttpMethod httpMethod, List<? extends MediaType> consumes, List<? extends MediaType> produces) {
		verify(resourceClassName, resourceMethodName, httpMethod, consumes, produces);
		this.resourceClassName = resourceClassName;
		this.resourceMethodName = resourceMethodName;
		this.httpMethod = httpMethod;
		this.consumes = consumes;
		this.produces = produces;
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier#matches(jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean matches(GResourceIdentifier identifier) {
		return Matcher.matches(this, identifier);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier#matchesClass(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean matchesClass(String className) {
		return Matcher.matchesClass(this.getResourceClassName(), className);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier#matchesMethod(java.lang.String)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean matchesMethod(String methodName) {
		return Matcher.matchesMethod(this.getResourceMethodName(), methodName);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier#matchesHttpMethod(jp.co.kccs.greenearth.framework.web.http.GHttpMethod)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean matchesHttpMethod(GHttpMethod httpMethod) {
		return Matcher.matchesHttpMethod(this.getHttpMethod(), httpMethod);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier#matchesConsumes(java.util.List)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean matchesConsumes(List<? extends MediaType> consumes) {
		return Matcher.matchesConsumes(this.getConsumes(), consumes);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier#matchesProduces(java.util.List)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean matchesProduces(List<? extends MediaType> produces) {
		return Matcher.matchesProduces(this.getProduces(), produces);
	} 

	private void verify(String resourceClassName, String resourceMethodName, GHttpMethod httpMethod, List<? extends MediaType> consumes, List<? extends MediaType> produces) {
		requireNonNull(resourceClassName, "Resource Class Name");
		requireNonNull(resourceMethodName, "Resource Method Name");
		requireNonNull(httpMethod, GHttpMethod.class.getSimpleName());
		requireNonNull(consumes, "Consumes");
		requireNonNull(produces, "Produces");
	}

	private <T> void requireNonNull(T obj, Object args) {
		Objects.requireNonNull(obj, GFrameworkMessages.mustBeRequired(args));
	}
}
