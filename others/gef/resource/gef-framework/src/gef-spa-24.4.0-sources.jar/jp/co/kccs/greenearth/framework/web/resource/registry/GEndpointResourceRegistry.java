/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.registry;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;

/**
 * エンドポイントリソース({@link GEndpointResource})を一元管理します.<br/>
 * 
 * @see GEndpointResource
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GEndpointResourceRegistry extends GBootstrapInitializable {

	/**
	 * 指定したキー({@link GWebRequest})で、エンドポイントリソース({@link GEndpointResource})を探索します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return エンドポイント({@link GEndpointResource})のリスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<GEndpointResource> lookup(GWebRequest request);

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable#initialize()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	void initialize();

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable#destroy()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	void destroy();

	/**
	 * {@link GEndpointResourceRegistry}のインスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GEndpointResourceRegistry}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GEndpointResourceRegistry getInstance() {
		return GFrameworkUtils.getComponent(GEndpointResourceRegistry.class.getName());
	}
}
