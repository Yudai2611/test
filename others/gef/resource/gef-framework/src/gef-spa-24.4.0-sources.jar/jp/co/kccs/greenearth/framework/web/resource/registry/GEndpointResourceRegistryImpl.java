/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.resource.registry;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jakarta.annotation.Priority;
import jakarta.ws.rs.NotAcceptableException;
import jakarta.ws.rs.NotAllowedException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.NotSupportedException;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.listener.BootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GAbstractBootstrapInitializable;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResourceImpl;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Endpoint;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Resource;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGenerator;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGeneratorProvider;
import lombok.NoArgsConstructor;

/**
 * {@link GEndpointResourceRegistry}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
			@jp.co.kccs.greenearth.commons.service.Modifier(isPublic = true)
	},
	scannedAnnotations = Resource.class
)
@BootstrapInitializable
@NoArgsConstructor
@Priority(GPriority.NORMAL)
public class GEndpointResourceRegistryImpl extends GAbstractBootstrapInitializable implements GEndpointResourceRegistry {
	private static final Log LOGGER = LogFactory.getLog(GEndpointResourceRegistryImpl.class);

	private Map<String, List<GEndpointResource>> metadataActionResources = new ConcurrentHashMap<>();
	private GResourceIdentifierGeneratorProvider<GWebRequest> resourceIdentifierProvider;

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void initialize() {
		LOGGER.info(GFrameworkMessages.$s_INIT_STARTED.message(GEndpointResourceRegistryImpl.class.getSimpleName()));
		registerAll();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<GEndpointResource> lookup(GWebRequest request) {
		GResourceIdentifier identifier = createIdentifier(request);
		return Collections.unmodifiableList(
				Objects.isNull(identifier) ?
					Collections.emptyList() :
					getResources(identifier));
	}

	protected void registerAll() {
		GScanComponentService.getInstance()
			.getScannedClasses(this.getClass())
				.forEach(this::register);
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void destroy() {
		LOGGER.info(GFrameworkMessages.$s_DESTROY_STARTED.message(GEndpointResourceRegistryImpl.class.getSimpleName()));
		getMetadataActionResources()
			.forEach((k, v) -> {
				v.clear();
			});
		getMetadataActionResources().clear();
	}
	
	protected synchronized void register(Class<?> resourceClass) {
		if (!isSupportedModifiers(resourceClass.getModifiers())) {
			return;
		}
		if (getMetadataActionResources().containsKey(resourceClass.getName())) {
			return;
		}
		getMetadataActionResources().put(resourceClass.getName(), createEndpointResources(resourceClass));
	}

	protected GEndpointResource createEndpointResource(Class<?> resourceClass, Method resourceMethod) {
		return new GEndpointResourceImpl(resourceClass, resourceMethod);
	}
	
	protected List<GEndpointResource> createEndpointResources(Class<?> resourceClass) {
		List<GEndpointResource> endpointResources = new ArrayList<>();
		Stream.of(resourceClass.getDeclaredMethods())
			.filter(method -> GReflectionHelper.isAnnotationPresent(method, Endpoint.class))
			.forEach(method -> {
				if (isSupportedModifiers(method.getModifiers())) {
					GEndpointResource endpointResource = createEndpointResource(resourceClass, method);
					endpointResources.add(endpointResource);
				}
			});
		return GEndpointResourceSorter.sort(endpointResources);
	}
	
	private boolean isSupportedModifiers(int modifiers) {
		return Modifier.isPublic(modifiers) && !Modifier.isStatic(modifiers);
	}
	
	private List<GEndpointResource> getResources(GResourceIdentifier identifier) {
		List<GEndpointResource> result = new ArrayList<>();
		getMetadataActionResources()
			.entrySet()
			.stream()
			.filter(entry -> GResourceIdentifier.Matcher.matchesClass(entry.getKey(), identifier.getResourceClassName()))
			.forEach(entry -> {
				List<? extends GEndpointResource > filterResults =  entry.getValue().stream().filter(resource-> resource.getIdentifier().matchesMethod(identifier.getResourceMethodName())).collect(
					Collectors.toList());
				if (filterResults.isEmpty()) {
					throw new NotFoundException(GFrameworkMessages.isNotFound(String.format("%s#%s", identifier.getResourceClassName(), identifier.getResourceMethodName())), Response.status(GHttpStatus.NOT_FOUND).build());
				}
				filterResults =	filterResults.stream()
					.filter(resource -> resource.getIdentifier().matchesHttpMethod(identifier.getHttpMethod())).collect(Collectors.toList());
				if (filterResults.isEmpty()) {
					throw new NotAllowedException(identifier.getHttpMethod().name() + " is not allowed.", Response.status(GHttpStatus.METHOD_NOT_ALLOWED).build());
				}
				filterResults =	filterResults.stream()
					.filter(resource -> resource.getIdentifier().matchesConsumes(identifier.getConsumes())).collect(Collectors.toList());
				if (filterResults.isEmpty()) {
					throw new NotSupportedException(identifier.getConsumes() + " is not supported.", Response.status(GHttpStatus.UNSUPPORTED_MEDIA_TYPE).build());
				}
				filterResults = filterResults.stream()
					.filter(resource -> resource.getIdentifier().matchesProduces(identifier.getProduces())).collect(Collectors.toList());
				if (filterResults.isEmpty()) {
					throw new NotAcceptableException(identifier.getProduces() + " cannot be accepted.", Response.status(GHttpStatus.NOT_ACCEPTABLE).build());
				}
				result.addAll(filterResults);
			});
		if (result.isEmpty()) {
			throw new NotFoundException(GFrameworkMessages.isNotFound(String.format("%s#%s", identifier.getResourceClassName(), identifier.getResourceMethodName())), Response.status(GHttpStatus.NOT_FOUND).build());
		}
		return GEndpointResourceSorter.sort(result);
	}
	private GResourceIdentifierGeneratorProvider<GWebRequest> getIdentifierProvider() {
		if (Objects.isNull(resourceIdentifierProvider)) {
			resourceIdentifierProvider = GResourceIdentifierGeneratorProvider.getInstance();
		}
		return resourceIdentifierProvider;
	}
	
	private GResourceIdentifier createIdentifier(GWebRequest request) {
		GResourceIdentifierGenerator<GWebRequest> resourceIdentifierGenerator = getIdentifierProvider().getGenerator(request);
		return resourceIdentifierGenerator.generate(request).orElseThrow(() -> {
			throw new GContainerException(GFrameworkMessages.canNotBeCreated(GResourceIdentifier.class.getSimpleName()));
		});
	}
	
	private static class GEndpointResourceSorter {
		/**
		 * クラス名・メソッド名をアスキー昇順、同値の場合、引数数・Consumes数・Produces数・メソッドアノテーション数の順に多いほうを優先
		 * 
		 */
		private static final Comparator<GEndpointResource> ENDPOINT_RESOURCE_COMPARATOR = new Comparator<GEndpointResource>() {
			public int compare(GEndpointResource o1, GEndpointResource o2) {
				// 1がPriority Low、-1がPriority High
				int order = o1.getResourceClass().getName().compareTo(o2.getResourceClass().getName());
				if (order < 0) {
					return -1;
				}
				if (order > 0) {
					return 1;
				}
				order = o1.getResourceMethod().getName().compareTo(o2.getResourceMethod().getName());
				if (order < 0) {
					return -1;
				}
				if (order > 0) {
					return 1;
				}
				order = (o1.getParameters().size() - o2.getParameters().size()) * -1;
				if (order < 0) {
					return -1;
				}
				if (order > 0) {
					return 1;
				}
				order = (o1.getConsumes().size() - o2.getConsumes().size()) * -1;
				if (order < 0) {
					return -1;
				}
				if (order > 0) {
					return 1;
				}
				order = (o1.getProduces().size() - o2.getProduces().size()) * -1;
				if (order < 0) {
					return -1;
				}
				if (order > 0) {
					return 1;
				}
				return (o1.getResourceMethod().getDeclaredAnnotations().length - o2.getResourceMethod().getDeclaredAnnotations().length) * -1;
			};
		};

		private static List<GEndpointResource> sort(List<GEndpointResource> resources) {
			return resources
					.stream()
					.sorted(ENDPOINT_RESOURCE_COMPARATOR)
					.collect(Collectors.toList());
		}
	}

	Map<String, List<GEndpointResource>> getMetadataActionResources() {
		return metadataActionResources;
	}
}
