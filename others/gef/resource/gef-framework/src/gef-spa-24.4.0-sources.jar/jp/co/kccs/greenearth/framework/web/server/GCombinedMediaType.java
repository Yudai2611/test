/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;

import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * サーバーとクライアントのメディアタイプの組合せです.<br/>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Getter
public class GCombinedMediaType extends MediaType {
	private Double serverQuality;
	private Double clientQuality;
	private Double distance;

	private GCombinedMediaType(MediaType client, MediaType server, boolean isServerSuperior) {
		super(isServerSuperior ? server.getType() : client.getType(), isServerSuperior ? server.getSubtype() : client.getSubtype(), createMediaTypeParametersConsiderQuality(client, server, calculateDistance(client, server)));
		this.distance = Double.parseDouble(getParameters().get("d"));
		this.clientQuality = Double.parseDouble(getParameters().get("q"));
		this.serverQuality = Double.parseDouble(getParameters().get("qs"));
	}

	/**
	 * サーバーとクライアントのメディアタイプの組合せです.<br/>
	 *
	 * @create 2024/04/30
	 * @param client クライアントのメディアタイプ
	 * @param server サーバーのメディアタイプ
	 * @return クライアントとサーバーの組合せオブジェクト
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public static GCombinedMediaType create(MediaType client, MediaType server) {
		if (client.isWildcardType() && !server.isWildcardType()) {
			return new GCombinedMediaType(client, server, true);
		} else if (!client.isWildcardType() && server.isWildcardType()) {
			return new GCombinedMediaType(client, server, false);
		} else {
			if (client.isWildcardSubtype() && !server.isWildcardSubtype()) {
				return new GCombinedMediaType(client, server, true);
			} else if (!client.isWildcardSubtype() && server.isWildcardSubtype()) {
				return new GCombinedMediaType(client, server, false);
			}
			return new GCombinedMediaType(client, server, true);
		}
	}
	private static Map<String, String> createMediaTypeParametersConsiderQuality(MediaType client, MediaType server, int distance) {
		String clientQuality = client.getParameters().get("q");
		String serverQuality = server.getParameters().get("qs");
		return new HashMap<>() {
			{
				put("d", String.format("%d", distance));
				put("q", Objects.isNull(clientQuality) ? "1.0" : clientQuality);
				put("qs", Objects.isNull(serverQuality) ? "1.0" : serverQuality);
			}
		};
	}

	private static int calculateDistance(MediaType client, MediaType server) {
		int distance = 0;
		if ((client.isWildcardType() && !server.isWildcardType())
				|| (!client.isWildcardType() && server.isWildcardType())) {
			distance += 1;
		}
		if ((client.isWildcardSubtype() && !server.isWildcardSubtype())
				|| (!client.isWildcardSubtype() && server.isWildcardSubtype())) {
			distance += 1;
		}
		return distance;
	}
}
