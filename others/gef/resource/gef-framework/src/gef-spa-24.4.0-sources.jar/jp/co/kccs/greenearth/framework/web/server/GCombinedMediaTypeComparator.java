/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;


import java.util.Comparator;

/**
 * {@link GCombinedMediaType}をソートするためのクラスです。<br/>
 * ソート条件の優先は下記の通りです。<br/>
 * 「１」具体性を比較します。<br/>
 * 「２」「q」の値を比較します。<br/>
 * 「３」「qs」の値を比較します。<br/>
 * 「４」「d」の値を比較します.
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GCombinedMediaTypeComparator implements Comparator<GCombinedMediaType> {

	/**
	 * {@link GCombinedMediaType}をソートします。<br/>
	 *
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public int compare(GCombinedMediaType o1, GCombinedMediaType o2) {
		// 1がPriority Low、-1がHigh
		if (o1.isWildcardType() && !o2.isWildcardType()) {
			return 1;
		}
		if (!o1.isWildcardType() && o2.isWildcardType()) {
			return -1;
		}
		if (o1.isWildcardSubtype() && !o2.isWildcardSubtype()) {
			return 1;
		}
		if (!o1.isWildcardSubtype() && o2.isWildcardSubtype()) {
			return -1;
		}
		double o1qp = o1.getClientQuality();;
		double o2qp = o2.getClientQuality();
		if (o1qp > o2qp) {
			return -1;
		}
		if (o1qp < o2qp) {
			return 1;
		}
		double o1qsp = o1.getServerQuality();
		double o2qsp = o2.getServerQuality();
		if (o1qsp > o2qsp) {
			return -1;
		}
		if (o1qsp < o2qsp) {
			return 1;
		}
		double o1dp = o1.getDistance();
		double o2dp = o2.getDistance();
		if (o1dp > o2dp) {
			return 1;
		}
		if (o1dp < o2dp) {
			return -1;
		}
		return 0;
	}
}
