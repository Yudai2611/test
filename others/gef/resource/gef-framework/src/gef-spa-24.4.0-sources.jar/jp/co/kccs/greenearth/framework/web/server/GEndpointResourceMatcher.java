/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import jp.co.kccs.greenearth.framework.web.resource.registry.GEndpointResourceRegistry;

import java.util.Optional;


/**
 * {@link GEndpointResource}をマッチングします。<br>
 * マッチングのアルゴリズムはJAX-RSのアルゴリズムに基づいて作られます.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface GEndpointResourceMatcher {

	/**
	 * {@link GWebRequest}の情報次第で一番最適な{@link GEndpointResource}を探します。<br>
	 * マッチングのアルゴリズムはJAX-RSのアルゴリズムに基づいて作られます.<br>
	 *
	 * @create 2024/04/30
	 * @param webRequest リクエスト
	 * @return 一致する {@link GEndpointResource}
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	Optional<GEndpointResource> match(GWebRequest webRequest);

	/**
	 * {@link GEndpointResourceMatcher}のDIを取得します. <br>
	 *
	 * @create 2024/04/30
	 * @return 一致する {@link GEndpointResource}
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	static GEndpointResourceMatcher getInstance() {
		return GFrameworkUtils.getComponent(GEndpointResourceMatcher.class);
	}
}
