/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;

import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import jp.co.kccs.greenearth.framework.web.resource.registry.GEndpointResourceRegistry;
import jp.co.kccs.greenearth.framework.web.server.handle.GEndpointHandle;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;
import java.util.stream.Collectors;

/**
 * {@link GEndpointResourceMatcher}の実装です.<br>
 *
 * @create 2024/04/30
 * @see GEndpointResourceMatcher
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GEndpointResourceMatcherImpl implements GEndpointResourceMatcher {

	private static final Log LOGGER = LogFactory.getLog(GEndpointResourceMatcherImpl.class);

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see GEndpointResourceMatcher#match(GWebRequest)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Optional<GEndpointResource> match(GWebRequest request) {
		List<GResourceCandidate> resourceCandidates = matchesCandidate(request);
		if (compareTop2(resourceCandidates)) {
			LOGGER.warn(GFrameworkMessages.isDuplicated(GEndpointHandle.class.getSimpleName()));
		}
		return Optional.ofNullable(resourceCandidates.get(0).getResource());
	}

	boolean compareTop2(List<GResourceCandidate> resourceCandidates) {
		if (resourceCandidates.size() < 2) {
			return false;
		}
		GResourceCandidate o1 = resourceCandidates.get(0);
		GResourceCandidate o2 = resourceCandidates.get(1);
		return o1.getConsume().equals(o2.getConsume())
				&& o1.getProduce().equals(o2.getProduce());
	}

	private List<GResourceCandidate> matchesCandidate(GWebRequest request) {
		List<GResourceCandidate> resourceCandidates = new ArrayList<>();
		GEndpointResourceRegistry.getInstance().lookup(request)
				.stream()
				.forEach(endpoint -> {
					resourceCandidates.addAll(createResourceCandidates(request, endpoint));
				});
		return GResourceCandidateSorter.sort(resourceCandidates);
	}

	private List<GResourceCandidate> createResourceCandidates(GWebRequest request, GEndpointResource endpoint) {
		List<GResourceCandidate> resourceCandidates = new ArrayList<>();
		MediaType requestMediaType = Objects.isNull(request.getMediaType()) ? MediaType.WILDCARD_TYPE : request.getMediaType();
		endpoint.getConsumes()
				.stream()
				.filter(consume ->
						consume.isCompatible(requestMediaType)
				)
				.forEach(consume -> {
					request.getAcceptableMediaTypes()
							.forEach(acceptableMediaType -> {
								endpoint.getProduces()
										.stream()
										.filter(produce ->
												produce.isCompatible(acceptableMediaType)
										)
										.forEach(produce -> {
											resourceCandidates.add(createCandidate(endpoint, requestMediaType, consume, acceptableMediaType, produce));
										}); }); });
		return resourceCandidates;
	}

	GResourceCandidate createCandidate(GEndpointResource endpointResource, MediaType clientContentType, MediaType serverConsume, MediaType clientAcceptableMediaType, MediaType serverProduce) {
		return new GResourceCandidate(
				endpointResource,
				GCombinedMediaType.create(clientContentType, serverConsume),
				GCombinedMediaType.create(clientAcceptableMediaType, serverProduce));
	}


	@Getter
	@AllArgsConstructor
	class GResourceCandidate {
		private GEndpointResource resource;
		private GCombinedMediaType consume;
		private GCombinedMediaType produce;
	}

	private static class GResourceCandidateSorter {
		private static final GCombinedMediaTypeComparator COMPARATOR = new GCombinedMediaTypeComparator();
		private static List<GResourceCandidate> sort(List<GResourceCandidate> resourceCandidates) {
			return resourceCandidates
					.stream()
					.sorted(
							Comparator
									.comparing(GResourceCandidate::getConsume, COMPARATOR)
									.thenComparing(GResourceCandidate::getProduce, COMPARATOR)
					)
					.collect(Collectors.toList());
		}
	}
}
