/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;


/**
 * リソース注入の準備を管理する為のコンテナーです.
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface GResourceConfigurationContainer {
	/**
	 * リソースを使えるようにこのメソッドを呼び出す必要があります.
	 *
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	void init();

	/**
	 * リソースを使えないようにこのメソッドを呼び出す必要があります.
	 *
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	void destroy();
}
