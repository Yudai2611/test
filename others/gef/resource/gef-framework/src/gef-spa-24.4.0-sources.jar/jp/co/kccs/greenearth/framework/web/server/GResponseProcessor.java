/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;

/**
 * HTTPレスポンスを処理します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GResponseProcessor {
	/**
	 * HTTPレスポンスを処理します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param response レスポンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	void process(GWebResponse response);
	
	/**
	 * HTTPレスポンスを解放します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param response HTTPレスポンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	void release(GWebResponse response);
	
	/**
	 * エラー情報({@link Throwable})からHTTPレスポンスへ変換します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param throwable エラー情報({@link Throwable})
	 * @param request HTTPリクエスト
	 * @return HTTPレスポンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	GWebResponse toResponse(Throwable throwable, GWebRequest request);
	
	/**
	 * {@link GResponseProcessor}のインスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GResponseProcessor}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GResponseProcessor getInstance() {
		return GFrameworkUtils.getComponent(GResponseProcessor.class.getName());
	}
}
