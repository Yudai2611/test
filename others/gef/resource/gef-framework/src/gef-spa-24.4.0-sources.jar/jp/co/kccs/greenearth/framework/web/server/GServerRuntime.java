/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;

/**
 * サーバーランタイムの一連のプロセスを実行＆管理します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GServerRuntime {
	
	/**
	 * サーバーランタイムを初期化を行います.<br/>
	 * 
	 * @create 2023/10/25
	 * @param filterChainConfiguration フィルターチェーンの構成情報
	 * @author yamashita
	 * @since 23.10.0
	 */
	void init(GFilterChainConfiguration filterChainConfiguration);
	
	/**
	 * サーバーランタイムの一連のプロセスを実行します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	void process(GWebRequest request);

	/**
	 * サーバーランタイムを破棄します.<br/>
	 * 
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void destroy();

	/**
	 * {@link GServerRuntime}のインスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@link GServerRuntime}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GServerRuntime getInstance() {
		return GFrameworkUtils.getComponent(GServerRuntime.class.getName());
	}
}
