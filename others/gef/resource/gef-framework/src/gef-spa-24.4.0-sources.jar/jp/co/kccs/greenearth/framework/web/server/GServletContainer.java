/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.framework.web.server.internal.GResourceConfigurationContainerImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.provider.GProviderService;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfigurationBuilder;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfigurationImpl;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfigurator;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContext;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.internal.GContainerRequest;
import jp.co.kccs.greenearth.framework.web.server.internal.GWebComponentBinder;
import jp.co.kccs.greenearth.framework.web.server.internal.GWebServletConfig;

/**
 * SPAフレームワーク標準のサーブレットコンテナです.<br/>
 * 主に、{@link GServerRuntime}の実行管理、各種リソース({@link GHttpContext}、{@link GFilterChainConfiguration})ライフサイクルの管理など、行います。<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GServletContainer extends HttpServlet {

	private static final Log LOGGER = LogFactory.getLog(GServletContainer.class);
	private static final long serialVersionUID = 720266217145802426L;
	private GServerRuntime runtime;
	private GResourceConfigurationContainer resourceConfigurationContainer;
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.servlet.http.HttpServlet#init(jakarta.servlet.ServletConfig)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void init(ServletConfig servletConfig) throws ServletException {
		LOGGER.trace(GFrameworkMessages.$s_INIT_STARTED.message(GServletContainer.class.getSimpleName()));
		super.init(servletConfig);
		Objects.requireNonNull(getServerRuntime(), GFrameworkMessages.mustBeRequired(GServerRuntime.class.getSimpleName()));
		this.resourceConfigurationContainer = new GResourceConfigurationContainerImpl();
		initializeFilters(servletConfig);
		GProviderService.getInstance().register(new GWebComponentBinder(new GWebServletConfig(this)));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.servlet.http.HttpServlet#service(jakarta.servlet.http.HttpServletRequest,
	 *      jakarta.servlet.http.HttpServletResponse)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		LOGGER.trace(GFrameworkMessages.$s_SERVICE_STARTED.message(GServletContainer.class.getSimpleName()));
		try {
			this.resourceConfigurationContainer.init();
			processRuntime(req, res);
		} finally {
			GHttpContextHolder.release();
			this.resourceConfigurationContainer.destroy();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jakarta.servlet.GenericServlet#destroy()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void destroy() {
		LOGGER.trace(GFrameworkMessages.$s_DESTROY_STARTED.message(GServletContainer.class.getSimpleName()));
		destroyRuntime();
		super.destroy();
	}

	protected void processRuntime(HttpServletRequest req, HttpServletResponse res) {
		GWebRequest request = createRequest(req, res);
		GHttpContextHolder.init(request);
		getServerRuntime().process(request);
	}

	protected void initializeRuntime(GFilterChainConfiguration filterChainConfiguration) {
		getServerRuntime().init(filterChainConfiguration);
	}

	protected void initializeFilters(ServletConfig servletConfig) {
		String filterChain = servletConfig.getInitParameter("filters");
		String filterConfigurator = servletConfig.getInitParameter("filter-configurator");
		String priorityOrder = servletConfig.getInitParameter("priority-order");
		GFilterChainConfiguration filterConfiguration =
			buildConfiguration(servletConfig.getServletName(), priorityOrder, filterChain, filterConfigurator);

		initializeRuntime(filterConfiguration);
	}

	protected GWebRequest createRequest(HttpServletRequest req, HttpServletResponse rep) {
		return new GContainerRequest(req, rep);
	}

	private GFilterChainConfiguration buildConfiguration(String servletName, String priorityOrder, String filterChains,
		String filterConfigurator) {
		boolean priorityOrderValue = true;
		List<Class<?>> filterChainList = new ArrayList<>();

		if (Objects.nonNull(priorityOrder)) {
			priorityOrderValue = Boolean.parseBoolean(priorityOrder);
		}
		if (Objects.nonNull(filterChains)) {
			filterChainList = Arrays.stream(filterChains.split(","))
				.map(config -> GReflectionHelper.classForName(config))
				.filter(optional -> optional.isPresent())
				.map(optional -> optional.get())
				.collect(Collectors.toList());
		}
		GFilterChainConfigurationBuilder filterConfigurationBuilder = createBuilder(servletName, priorityOrderValue, filterChainList);
		if (Objects.nonNull(filterConfigurator)) {
			Optional<GFilterChainConfigurator> filterConfiguratorObj = GObjectInstantiator.getInstance().newInstance(filterConfigurator);
			if (filterConfiguratorObj.isPresent()) {
				return filterConfiguratorObj.get().configure(filterConfigurationBuilder);
			}
		}
		return new GFilterChainConfigurationImpl(servletName, priorityOrderValue, filterChainList, new HashMap<>());
	}

	private GFilterChainConfigurationBuilder createBuilder(String servletName, boolean priorityOrder, List<Class<?>> filterChain) {
		GFilterChainConfigurationBuilder builder = GFilterChainConfiguration.builder(servletName);
		builder.priorityOrder(priorityOrder);
		for (Class<?> filter : filterChain) {
			builder.filters().chain(filter);
		}
		return builder;
	}

	private void destroyRuntime() {
		getServerRuntime().destroy();
	}

	GServerRuntime getServerRuntime() {
		if (Objects.isNull(runtime)) {
			runtime = GServerRuntime.getInstance();
		}
		return runtime;
	}

}
