/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;

/**
 * {@link GValidateException}が発生する場合、このクラスで処理されます.　<br/>
 * 
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Provider
@Priority(GPriority.LOW)
public class GValidateExceptionMapper implements ExceptionMapper<GValidateException> {

	/**
	 * {@link Response}に422ステータスコードを設定して、エンティティに{@link GValidateException#getValidateErrors()}を設定する.　<br/>
	 * 
	 * @create 2024/04/30
	 * @param throwable
	 * @return {@link Response}
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Response toResponse(GValidateException throwable) {
		return Response.status(GHttpStatus.UNPROCESSABLE_ENTITY).type(GMediaType.APPLICATION_JSON).entity((throwable).getValidateErrors()).build();
	}
}
