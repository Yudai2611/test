/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Objects;

import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.provider.GAbstractTypeSuppoter;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GUnSupportedTypeException;

/**
 * {@link GResponseTypeConverter}インターフェースを実装する基底クラスです.<br>
 * 
 * @create 2023/10/25
 * @param <T>
 * @author KCCS okanishi
 * @since 23.10.0
 */
public abstract class GAbstractResponseTypeConverter<T> extends GAbstractTypeSuppoter implements GResponseTypeConverter {

	/**
	 * {@inheritDoc}
	 *
	 * @see GResponseTypeConverter#convert(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public Response convert(Object result) {
		if (Objects.isNull(result)) {
			return Response.noContent().build();
		}

		if (!isSupportedType(result)) {
			throw new GUnSupportedTypeException(GFrameworkMessages.isNotSupported(result.getClass()));
		}

		return createResponse((T) result);
	}
	
	/**
	 * {@link Response}インスタンスを生成します.<br>
	 * 
	 * @create 2023/10/25
	 * @param result
	 * @return {@link Response}のインスタンス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	protected Response createResponse(T result) {
		return Response.ok().entity(result).build();
	}
	
	/**
	 * 引数のオブジェクトをサポート有無を確認します.<br>
	 * 
	 * @create 2023/10/25
	 * @param result
	 * @return サポートする場合は<code>true</code>、存在しない場合は<code>false</code>を返します.
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	protected boolean isSupportedType(Object result) {
		Type type = ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
		
		if (!ParameterizedType.class.isInstance(type)) {
			return ((Class<?>) type).isAssignableFrom(result.getClass());
		}
		return ((Class<?>) ((ParameterizedType) type).getRawType()).isAssignableFrom(result.getClass());
	}

}
