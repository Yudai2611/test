/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import java.util.List;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.SupportedType;

/**
 * エンドポイントの戻り値型{@link List}を{@link Response}オブジェクトに変換します.<br/>
 * ※ジェネリクス型が{@link jp.co.kccs.greenearth.framework.data.GValidateError}の場合は、{@link Response#status(int)}をコントロールするため本クラスでは扱わない<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@SupportedType(List.class)
@Priority(GPriority.NORMAL)
public class GListToResponseTypeConverter extends GAbstractResponseTypeConverter<List<?>> {
	
}
