/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.GTypeSupporter;
import jp.co.kccs.greenearth.commons.provider.GTypeSupporterProvider;
import jp.co.kccs.greenearth.commons.provider.SupportedType;


/**
 * エンドポイントの戻り値型{@link Null}を{@link Response}オブジェクトに変換します.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@SupportedType(GTypeSupporter.Null.class)
@Priority(GPriority.NORMAL)
public class GNullToResponseTypeConverter extends GAbstractResponseTypeConverter<GTypeSupporter.Null> {

    /**
     * {@inheritDoc}
     *
     * @see GAbstractResponseTypeConverter#createResponse(Object)
     * @create 2024/04/30
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Response convert(Object result) {
        return Response.noContent().build();
    }
}
