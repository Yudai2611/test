/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.SupportedType;

/**
 * {@link Object}をJAX-RSレスポンス({@link Response})へ変換します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@SupportedType(Object.class)
@Priority(GPriority.LOW)
public class GObjectToResponseTypeConverter extends GAbstractResponseTypeConverter<Object> {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.converter.GAbstractResponseTypeConverter#isSupportedType(java.lang.Object)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	protected boolean isSupportedType(Object result) {
		return Object.class.isInstance(result);
	}
}
