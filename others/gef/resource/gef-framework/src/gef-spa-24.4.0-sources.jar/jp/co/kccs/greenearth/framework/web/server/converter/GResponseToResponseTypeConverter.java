/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.SupportedType;

/**
 * エンドポイントの戻り値型{@link Response}に変換します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@SupportedType(Response.class)
@Priority(GPriority.NORMAL)
public class GResponseToResponseTypeConverter extends GAbstractResponseTypeConverter<Response> {

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractResponseTypeConverter#createResponse(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	protected Response createResponse(Response result) {
		return Response.class.cast(result);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractResponseTypeConverter#isSupportedType(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	protected boolean isSupportedType(Object result) {
		return Response.class.isInstance(result);
	}
}
