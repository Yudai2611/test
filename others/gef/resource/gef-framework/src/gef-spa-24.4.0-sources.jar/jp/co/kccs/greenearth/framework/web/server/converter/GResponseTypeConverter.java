/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.provider.GTypeSupporter;

/**
 * エンドポイントメソッドの結果をJAX-RSレスポンス({@link Response})に変換するためのインタフェースを提供します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GResponseTypeConverter extends GTypeSupporter {
	
	/**
	 * 指定した値をJAX-RSレスポンス({@link Response})に変換します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param result エンドポイントメソッドの結果の値
	 * @return JAX-RSレスポンス({@link Response})
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T> Response convert(T result);
}
