/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import java.lang.reflect.Type;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GResponseTypeConverter}を提供するプロバイダーです.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GResponseTypeConverterProvider {
	
	/**
	 * 指定したクラス型、総称型で{@link GResponseTypeConverter}を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param returnType クラス型
	 * @param genericType 総称型
	 * @return {@link GResponseTypeConverter}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	GResponseTypeConverter getConverter(Object result, Type genericType);

	/**
	 * {@link GResponseTypeConverterProvider}のインスタンスを取得します.<br/> 
	 * 
	 * @create 2023/10/25
	 * @return {@link GResponseTypeConverterProvider}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GResponseTypeConverterProvider getInstance() {
		return GFrameworkUtils.getComponent(GResponseTypeConverterProvider.class.getName());
	}
}
