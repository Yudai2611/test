/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.provider.GAbstractTypeSupporterProvider;
import jp.co.kccs.greenearth.commons.provider.GTypeSupporter;
import jp.co.kccs.greenearth.commons.provider.SupportedType;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import lombok.NoArgsConstructor;

/**
 * エンドポイントメソッドの戻り値型に関連付けられたコンバーター({@link GResponseTypeConverter})を提供します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
			@Modifier(isPublic = true)
	},
	scannedAnnotations = SupportedType.class,
	scannedAssignableTypes = GResponseTypeConverter.class
)
@NoArgsConstructor
public class GResponseTypeConverterProviderImpl extends GAbstractTypeSupporterProvider<GResponseTypeConverter> implements GResponseTypeConverterProvider {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.converter.GResponseTypeConverterProvider#getConverter(Object, java.lang.reflect.Type)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GResponseTypeConverter getConverter(Object result, Type genericType) {
		Class<?> resultClazz = Objects.isNull(result) ? GTypeSupporter.Null.class : result.getClass();
		Optional<GResponseTypeConverter> supporter = getTypeSupporter(
			resultClazz.isPrimitive() ? ConverterTypes.forType(resultClazz) : resultClazz
			, isParameterizedType(genericType) ? ((ParameterizedType) genericType).getActualTypeArguments()[0] : resultClazz
			);
		return supporter.orElseThrow(() -> {
			throw new GContainerException(GFrameworkMessages.isNotFound(GResponseTypeConverterProviderImpl.class.getSimpleName()));
		});
	}
	
	private boolean isParameterizedType(Type genericType) {
		return ParameterizedType.class.isInstance(genericType);
	}
	
	private static enum ConverterTypes {

		BYTE(Byte.class, byte.class) { },
		SHORT(Short.class, short.class) { },
		INTEGER(Integer.class, int.class) { },
		LONG(Long.class, long.class) { },
		FLOAT(Float.class, float.class) { },
		DOUBLE(Double.class, double.class) { },
		BOOLEAN(Boolean.class, boolean.class) { },
		CHAR(Character.class, char.class) { };

		private final Class<?> wrapper;
		private final Class<?> primitive;

		private ConverterTypes(Class<?> wrapper, Class<?> primitive) {
			this.wrapper = wrapper;
			this.primitive = primitive;
		}

		public static Class<?> forType(Class<?> type) {
			for (ConverterTypes primitive : ConverterTypes.values()) {
				if (primitive.supports(type)) {
					return primitive.wrapper;
				}
			}
			return null;
		}

		private boolean supports(Class<?> type) {
			return type == primitive;
		}
	}
}
