/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.server.converter;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.SupportedType;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;

/**
 * エンドポイントの戻り値型{@link GResultData}を{@link Response}オブジェクトに変換します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@SupportedType(GResultData.class)
@Priority(GPriority.NORMAL)
public class GResultDataToResponseTypeConverter extends GAbstractResponseTypeConverter<GResultData> {

	/** 終了コードキー名 */
	private static final String EXITCODE = "exitCode";

	/** データキー名 */
	private static final String DATAS = "datas";

	/** 検証エラーキー名 */
	private static final String ERRORS = "errors";

	/** TimeStampキー名 */
	private static final String TIMESTAMP = "timestamp";

	/** HTTPステータスコードキー名 */
	private static final String STATUS = "status";

	/** メッセージキー名 */
	private static final String MESSAGE = "message";

	/** 詳細キー名 */
	private static final String DESCRIPTION = "description";

	/** スタックトレースキー名 */
	private static final String STACKTRACE = "stacktrace";

	/** システムエラーキー名 */
	private static final String SYSTEMERROR = "systemError";

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractResponseTypeConverter#createResponse(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	protected Response createResponse(GResultData resultData) {

		Map<String, Object> dataMap = new LinkedHashMap<>();
		Map<String, Object> resultMap = new LinkedHashMap<>();

		switch (resultData.getExitCode()) {
			case GResultData.EXIT_CODE_FILE_DOWNLOAD :
				return createResponse(GHttpStatus.OK, resultData.getDownloadFile());

			case GResultData.EXIT_CODE_VALIDATE_ERROR :
				List<GValidateError> list = createIfEmpty(resultData.getErrors());

				resultMap.put(EXITCODE, GResultData.EXIT_CODE_VALIDATE_ERROR);
				resultMap.put(ERRORS, list.toArray(new GValidateError[list.size()]));
				resultMap.put(DATAS, extractDataFrom(resultData));
				return createResponse(GHttpStatus.UNPROCESSABLE_ENTITY, resultMap);

			case GResultData.EXIT_CODE_SYSTEM_ERROR :
				GSystemError error = createSystemError(resultData);
				dataMap.put(TIMESTAMP, error.getTimeStamp());
				dataMap.put(STATUS, error.getStatusCode().orElseGet(() -> null));
				dataMap.put(MESSAGE, error.getMessage().orElseGet(() -> null));
				dataMap.put(DESCRIPTION, error.getDescription());

				if (error.isEnableStackTrace()) {
					dataMap.put(STACKTRACE, error.getStackTrace());
				}

				resultMap.put(EXITCODE, GResultData.EXIT_CODE_SYSTEM_ERROR);
				resultMap.put(SYSTEMERROR, dataMap);
				resultMap.put(DATAS, extractDataFrom(resultData));

				return createResponse(GHttpStatus.INTERNAL_SERVER_ERROR, resultMap);

			case GResultData.EXIT_CODE_SUCCESS :
				resultMap.put(EXITCODE, GResultData.EXIT_CODE_SUCCESS);
				resultMap.put(DATAS, extractDataFrom(resultData));
				return createResponse(GHttpStatus.OK, resultMap);

			case GResultData.EXIT_CODE_DIRECT_RESPONSE :
				return createResponse(GHttpStatus.OK);

			default :
				throw new IllegalArgumentException(GFrameworkMessages.isNotSupported(resultData.getExitCode()));
		}
	}

	/**
	 * {@link GResultData}からデータを抽出します.<br>
	 * 
	 * @create 2023/10/25
	 * @param resultData 結果セット
	 * @return データ
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private Map<String, Object> extractDataFrom(GResultData resultData) {
		Map<String, Object> data = new HashMap<>();
		for (String key : resultData.dataNameSet()) {
			data.put(key, resultData.getData(key));
		}
		return data;
	}

	private List<GValidateError> createIfEmpty(List<GValidateError> validateErrors) {
		return Optional.ofNullable(validateErrors).orElseGet(() -> new ArrayList<>());
	}

	private GSystemError createSystemError(GResultData resultData) {
		GSystemError error = resultData.getException() == null ? GSystemError.create() : GSystemError.create(resultData.getException());
		error.setTimeStamp(OffsetDateTime.now(ZoneId.of("UTC")));
		error.setStatusCode(GHttpStatus.INTERNAL_SERVER_ERROR.getStatusCode());
		error.setMessage(GHttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		return error;
	}

	private <T> Response createResponse(GHttpStatus status, T t) {
		return Response.status(status).entity(t).build();
	}

	private Response createResponse(GHttpStatus status) {
		return Response.status(status).build();
	}
}
