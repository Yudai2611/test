/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import java.util.Set;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.SupportedType;

/**
 * エンドポイントの戻り値型{@link Set}を{@link Response}オブジェクトに変換します.<br>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
@SupportedType(Set.class)
@Priority(GPriority.NORMAL)
public class GSetToResponseTypeConverter extends GAbstractResponseTypeConverter<Set<?>> {
}
