/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.SupportedType;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;

/**
 * エンドポイントの戻り値型{@link GSystemError}を{@link Response}オブジェクトに変換します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@SupportedType(GSystemError.class)
@Priority(GPriority.NORMAL)
public class GSystemErrorToResponseTypeConverter extends GAbstractResponseTypeConverter<GSystemError> {
	
	/** TimeStampキー名 */
	private static final String TIMESTAMP = "timestamp";

	/** HTTPステータスコードキー名 */
	private static final String STATUS = "status";

	/** メッセージキー名 */
	private static final String MESSAGE = "message";

	/** 詳細キー名 */
	private static final String DESCRIPTION = "description";

	/** スタックトレースキー名 */
	private static final String STACKTRACE = "stacktrace";

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractResponseTypeConverter#createResponse(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	protected Response createResponse(GSystemError error) {
		
		Map<String, Object> resultMap = new LinkedHashMap<>();
		resultMap.put(TIMESTAMP, error.getTimeStamp());
		resultMap.put(STATUS, error.getStatusCode().orElseGet(() -> null));
		resultMap.put(MESSAGE, error.getMessage().orElseGet(() -> null));
		resultMap.put(DESCRIPTION, error.getDescription());
		if (error.isEnableStackTrace()) {
			resultMap.put(STACKTRACE, error.getStackTrace());
		}
		
		return Response.status(defaultStatusCode(error.getStatusCode()), defaultMessage(error.getMessage())).entity(resultMap).build();
	}

	private int defaultStatusCode(Optional<Integer> statusCode) {
		return statusCode.orElseGet(() -> GHttpStatus.INTERNAL_SERVER_ERROR.getStatusCode());
	}

	private String defaultMessage(Optional<String> message) {
		return message.orElseGet(() -> GHttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
	}
}
