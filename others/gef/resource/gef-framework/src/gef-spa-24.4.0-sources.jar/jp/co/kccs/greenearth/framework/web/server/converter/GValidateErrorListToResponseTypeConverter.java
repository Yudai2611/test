/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.converter;

import java.util.List;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.SupportedType;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;

/**
 * エンドポイントの戻り値型{@link List}、ジェネリクス型{@link GValidateError}を{@link Response}オブジェクトに変換します.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@SupportedType(value = List.class, genericType = GValidateError.class)
@Priority(GPriority.NORMAL)
public class GValidateErrorListToResponseTypeConverter extends GAbstractResponseTypeConverter<List<GValidateError>> {

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractResponseTypeConverter#createResponse(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	protected Response createResponse(List<GValidateError> result) {
		return Response.status(GHttpStatus.UNPROCESSABLE_ENTITY).entity(result).build();
	}
	
}
