/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;

/**
 * エンドポイントの実行プロセスをコントロールします.<br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GEndpointHandle {
	
	/**
	 * エンドポイントを実行し、結果を返却します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param data データ
	 * @return 結果
	 * @throws Throwable エンドポイント実行に失敗した場合
	 * @author yamashita
	 * @since 23.10.0
	 */
	GWebResponse apply(GWebRequest data) throws Throwable;

}
