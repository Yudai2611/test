/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import java.util.Objects;

import jp.co.kccs.greenearth.commons.provider.GTypeSupporterProvider;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.glassfish.jersey.internal.routing.CombinedMediaType;
import org.glassfish.jersey.internal.routing.CombinedMediaType.EffectiveMediaType;

import jakarta.ws.rs.NotAcceptableException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.internal.GContainerResponse;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import jp.co.kccs.greenearth.framework.web.server.converter.GResponseTypeConverter;
import jp.co.kccs.greenearth.framework.web.server.converter.GResponseTypeConverterProvider;

/**
 * {@link GEndpointHandle}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GEndpointHandleImpl implements GEndpointHandle {

	private static final Log LOGGER = LogFactory.getLog(GEndpointHandle.class);
	
	private GEndpointResource endpointResource;
	private GResponseTypeConverterProvider typeConverterProvider;
	
	public GEndpointHandleImpl(GEndpointResource endpointResource) {
		this.endpointResource = endpointResource;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.handle.GEndpointHandle#apply(java.lang.Object)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GWebResponse apply(GWebRequest request) throws Throwable {
		LOGGER.trace(GFrameworkMessages.$s_APPLY_STARTED.message(GEndpointHandle.class.getSimpleName()));
		Object[] values = GMethodParameterValuesCreator.getInstance().createValues(request,
																			endpointResource.getResourceClass(),
																			endpointResource.getParameters());
		GEndpointInvoker invoker = GEndpointInvoker.getInstance();
		Object result = invoker.invoke(
								endpointResource.getResourceClass(),
								endpointResource.getResourceMethod(),
								values);
		GResponseTypeConverter responseTypeConverter = getTypeConverterProvider().getConverter(
			result,
			endpointResource.getResourceMethod().getGenericReturnType()
		);
		Response response = responseTypeConverter.convert(result);
		GWebResponse webResponse =  new GContainerResponse(request, response);
		((GContainerResponse) webResponse).getContainerResponse().setEntityType(endpointResource.getResourceMethod().getGenericReturnType());
		return webResponse;
	}
	/**
	 * {@link GResponseTypeConverterProvider}のインスタンスを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GResponseTypeConverterProvider}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	GResponseTypeConverterProvider getTypeConverterProvider() {
		if (Objects.isNull(typeConverterProvider)) {
			typeConverterProvider = GResponseTypeConverterProvider.getInstance();
		}
		return typeConverterProvider;
	}
}