/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GWebRequest;

/**
 * {@link GEndpointHandle}を解決します.<br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GEndpointHandleResolver {
	
	/**
	 * 指定したデータに基づいて、{@link GEndpointHandle}を解決します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param data データ
	 * @return {@link GEndpointHandle}
	 * @author yamashita
	 * @since 23.10.0
	 */
	GEndpointHandle resolve(GWebRequest data);

	static GEndpointHandleResolver getInstance() {
		return GFrameworkUtils.getComponent(GEndpointHandleResolver.class);
	}
}
