/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifier;
import jp.co.kccs.greenearth.framework.web.resource.identifier.GResourceIdentifierGeneratorProvider;
import jp.co.kccs.greenearth.framework.web.server.GEndpointResourceMatcher;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;

import java.util.Optional;

/**
 * {@link GWebRequest}に基づいて、{@link GEndpointHandle}を解決します.<br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GEndpointHandleResolverImpl implements GEndpointHandleResolver {

	private static final Log LOGGER = LogFactory.getLog(GEndpointHandleResolverImpl.class);

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.handle.GEndpointHandleResolver#resolve(GWebRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GEndpointHandle resolve(GWebRequest request) {
		LOGGER.trace(GFrameworkMessages.$s_RESOLVE_STARTED.message(GEndpointHandleResolverImpl.class.getSimpleName()));
		GEndpointResource resource = (GEndpointResource) request.getResource().orElseThrow(() -> {
			Optional<GResourceIdentifier> resourceIdentifierOptional = GResourceIdentifierGeneratorProvider.getInstance().getGenerator(request).generate(request);
			return resourceIdentifierOptional.map(
				identifier ->
					new NotFoundException(
						GFrameworkMessages.isNotFound(String.format("%s#%s", identifier.getResourceClassName(), identifier.getResourceMethodName()))
					)
				)
				.orElseGet(NotFoundException::new);
		});
		return new GEndpointHandleImpl(resource);
	}

}