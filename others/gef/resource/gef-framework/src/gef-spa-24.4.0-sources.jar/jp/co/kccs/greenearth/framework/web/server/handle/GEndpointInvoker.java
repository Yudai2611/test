/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * エンドポイントを実行します.<br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GEndpointInvoker extends InvocationHandler {

	/**
	 * エンドポイントを実行します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param resource リソースクラス
	 * @param method リソースメソッド
	 * @param args リソースメソッド引数
	 * @return 実行結果
	 * @throws Throwable
	 * @author yamashita
	 * @since 23.10.0
	 */
	Object invoke(Class<?> resource, Method method, Object[] args) throws Throwable;

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	Object invoke(Object resource, Method method, Object[] args) throws Throwable;

	/**
	 * {@link GEndpointInvoker}のインスタンスを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GEndpointInvoker}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GEndpointInvoker getInstance() {
		return GFrameworkUtils.getComponent(GEndpointInvoker.class.getName());
	}
}
