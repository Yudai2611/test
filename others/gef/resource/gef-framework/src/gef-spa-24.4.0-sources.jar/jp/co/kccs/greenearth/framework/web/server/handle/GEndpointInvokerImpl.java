/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.action.GActionProxy;
import jp.co.kccs.greenearth.framework.web.GContainerException;

/**
 * {@link GEndpointInvoker}の実装クラスです.<br>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GEndpointInvokerImpl implements GEndpointInvoker {
	
	private static final Log LOGGER = LogFactory.getLog(GEndpointInvoker.class);

	public GEndpointInvokerImpl() {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.handle.GEndpointInvoker#invoke(java.lang.Class, java.lang.reflect.Method, java.lang.Object[])
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Object invoke(Class<?> resourceClass, Method resourceMethod, Object[] values) throws Throwable {
		Optional<Object> object = GObjectInstantiator.getInstance().newInstance(resourceClass);
		if (object.isPresent()) {
			return invoke(object.get(), resourceMethod, values);
		}
		throw new GContainerException(GFrameworkMessages.canNotBeCreated(resourceClass));
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.handle.GEndpointInvoker#invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Object invoke(Object resource, Method resourceMethod, Object[] values) throws Throwable {
		logInfo(GFrameworkMessages.$s_INVOKE_STARTED.message(GEndpointInvoker.class.getSimpleName()));
		logDebug("resourceClass : ",	resource.getClass().getName(), ", resourceMethod : ", resourceMethod.getName());
		GStopWatch watch = new GStopWatch();
		watch.start();
		Object result;
		try {
			Object obj = new GActionProxy(resource, resourceMethod).createProxy();
			result = resourceMethod.invoke(obj, values);
		} catch (InvocationTargetException e) {
			if (Objects.nonNull(e.getCause())) {
				throw e.getCause();
			}
			throw e;
		}
		logDebug(Long.toString(watch.stop()));
		return result;
	}
	
	private static void logInfo(String... args) {
		LOGGER.info(join(args));
	}
	
	private static void logDebug(String... args) {
		LOGGER.debug(join(args));
	}
	
	private static String join(String... args) {
		return String.join("", args);
	}
}
