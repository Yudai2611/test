/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.function.Function;

/**
* エンドポイントの引数を解決するインターフェースです.<br>
*
* @create 2023/10/25
* @author KCCS okanishi
* @since 23.10.0
*/
public interface GMethodParameterValueResolver<DATA, RESULT> extends Function<DATA, RESULT> {

	/**
	 * サポートしている型であれば<code>true</code>を返します。
	 * 
	 * @create 2023/10/25
	 * @param rawType 引数の型
	 * @param genericType 引数のジェネリクス型
	 * @param annotations 引数のアノテーション
	 * @return <code>true</code> or <code>false</code> 
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	boolean isSupported(Class<?> rawType, Type genericType, Annotation[] annotations);
	
	/**
	 * 指定された引数を適用します。
	 * 
	 * @create 2023/10/25
	 * @param data Httpリクエスト
	 * @return 適用後の値
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	RESULT apply(DATA data);
}
