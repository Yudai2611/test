/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GMethodParameterValueResolver}を提供します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GMethodParameterValueResolverProvider {
	/**
	 * プロバイダー一覧を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return List プロバイダー一覧
	 * @author yamashita
	 * @since 23.10.0
	 */
	List<Class<?>> getProviders();
	
	/**
	 * {@link GMethodParameterValueResolverProvider}のインスタンスを取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @return {@link GMethodParameterValueResolverProvider}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GMethodParameterValueResolverProvider getInstance() {
		return GFrameworkUtils.getComponent(GMethodParameterValueResolverProvider.class.getName());
	}
}
