/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import java.util.List;

import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;

/**
 * {@link GMethodParameterValueResolverProvider}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
		@Modifier(isPublic = true)
	},
	scannedAssignableTypes = GMethodParameterValueResolver.class)
public class GMethodParameterValueResolverProviderImpl implements GMethodParameterValueResolverProvider {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.handle.GMethodParameterValueResolverProvider#getProviders()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public List<Class<?>> getProviders() {
		return GScanComponentService.getInstance().getScannedClasses(getClass());
	}
}
