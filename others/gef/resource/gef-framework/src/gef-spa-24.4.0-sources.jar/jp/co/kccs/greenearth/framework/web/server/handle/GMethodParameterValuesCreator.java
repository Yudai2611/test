/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.resource.GMethodParameter;

/**
 * リソースメソッドの引数値を生成します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GMethodParameterValuesCreator {
	
	/**
	 * 指定したメソッドパラメータ({@link GMethodParameter})より引数値を生成します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <DATA>
	 * @param data データ
	 * @param resourceClass リソースクラス
	 * @param methodParameters メソッドパラメータ
	 * @return 生成した引数の値リスト
	 * @author yamashita
	 * @since 23.10.0
	 */
	<DATA> Object[] createValues(DATA data, Class<?> resourceClass, List<GMethodParameter> methodParameters);
	
	/**
	 * {@ink GMethodParameterValuesCreator}のインスタンスを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return {@ink GMethodParameterValuesCreator}のインスタンス
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GMethodParameterValuesCreator getInstance() {
		return GFrameworkUtils.getComponent(GMethodParameterValuesCreator.class.getName());
	}
}
