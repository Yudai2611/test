/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle.internal;

import java.util.List;

import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.spi.internal.ParamValueFactoryWithSource;
import org.glassfish.jersey.server.spi.internal.ParameterValueHelper;

import jp.co.kccs.greenearth.commons.provider.GProviderService;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GValueParamProviderFactory;
import jp.co.kccs.greenearth.framework.web.resource.GMethodParameter;
import jp.co.kccs.greenearth.framework.web.server.handle.GMethodParameterValuesCreator;

/**
 * リソースクラスのメソッドパラメーターを生成するためのヘルパークラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public final class GMethodParameterValuesCreatorImpl implements GMethodParameterValuesCreator {

	/**
	 * メソッドパラメーターの値を生成します.<br>
	 * 
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @param resourceClass リソースクラス
	 * @param methodParameters メソッドパラメーター
	 * @return メソッドパラメーターの値
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public <DATA> Object[] createValues(DATA request, Class<?> resourceClass, List<GMethodParameter> methodParameters) {
		List<ParamValueFactoryWithSource<?>> providers = GValueParamProviderFactory.getProvider(resourceClass, methodParameters);
		return ParameterValueHelper.getParameterValues(providers, GProviderService.getInstance().getService(ContainerRequest.class));
	}
}