/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle.internal;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map.Entry;

import org.apache.http.HttpException;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GUploadFile;
import jp.co.kccs.greenearth.framework.web.GContainerException;

/**
 * {@link GParameter}をデコードするクラスです.<br>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
public class GParameterDecoder {

	/**
	 * デコードした{@link GParameter}を返します.<br>
	 * 
	 * @create 2023/10/25
	 * @param parameter 
	 * @param characterName 
	 * @return デコードした{@link GParameter}
	 * @throws IOException
	 * @throws HttpException
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static GParameter decode(GParameter parameter, String characterName) throws IOException, HttpException {
		GParameter decodedParameter = GFrameworkUtils.getComponent(GParameter.class.getName());
		for (Entry<String, String[]> entry : parameter.getValuesMap().entrySet()) {
			if (entry.getValue().length == 1) {
				decodedParameter.setValue(entry.getKey(), decode(entry.getValue()[0], characterName));
			} else {
				String[] decodedValues = new String[entry.getValue().length];
				int i = 0;
				for (String value : entry.getValue()) {
					decodedValues[i] = decode(value, characterName);
					i++;
				}
				decodedParameter.setValues(entry.getKey(), decodedValues);
			}
		}

		for (Entry<String, GUploadFile[]> entry : parameter.getFilesMap().entrySet()) {
			decodedParameter.addFiles(entry.getKey(), entry.getValue());
		}

		return decodedParameter;

	}

	/**
	 * デコードした値を返します.<br>
	 * 
	 * @create 2023/10/25
	 * @param value 変換する値
	 * @param characterName 文字セット名
	 * @return デコードした値
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private static String decode(String value, String characterName) {
		try {
			return URLDecoder.decode(value, characterName);
		} catch (UnsupportedEncodingException e) {
			throw new GContainerException();
		}
	}
}
