/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle.internal;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import jakarta.ws.rs.NotSupportedException;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import org.apache.http.HttpException;
import org.glassfish.jersey.message.internal.MediaTypes;
import org.glassfish.jersey.server.ContainerRequest;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Encoded;
import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContext;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.server.handle.GMethodParameterValueResolver;

/**
 * {@link ContainerRequest}から{@link GParameter}を生成します.<br>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
public class GParameterValueResolver implements GMethodParameterValueResolver<ContainerRequest, GParameter> {
	
	/** サポートクラス */
	private static final Class<?> SUPPORTED_CLASS = GParameter.class;
	
	/** エンコード有無 */
	private boolean encoded;

	/**
	 * {@inheritDoc}
	 *
	 * @see GMethodParameterValueResolver#isSupported(Class, Type, Annotation[])
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean isSupported(Class<?> rawType, Type genericType, Annotation[] annotations) {
		if (rawType == GParameter.class) {
			this.encoded = Stream.of(annotations).anyMatch(annotation -> Encoded.class.equals(annotation.annotationType()));
			return true;
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GMethodParameterValueResolver#apply(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public GParameter apply(ContainerRequest data) {
		checkType();
		HttpServletRequest httpServletRequest = GHttpContextHolder.getContext().getWebRequest().getNativeRequest();
		GParameter parameter = GFrameworkUtils.getComponent(SUPPORTED_CLASS.getName());
		parameter.parseRequest(httpServletRequest);
		if (encoded) {
			return parameter;
		}
		String characterName = Optional.ofNullable(httpServletRequest.getCharacterEncoding()).orElse(StandardCharsets.UTF_8.name());
		try {
			return GParameterDecoder.decode(parameter, characterName);
		} catch (IOException | HttpException e) {
			throw new GContainerException(GFrameworkMessages.canNotBeCreated(SUPPORTED_CLASS));
		}
	}

	private void checkType() {
		GHttpContext context = GHttpContextHolder.getContext();
		if (Objects.isNull(context)) {
			throw new GContainerException(GFrameworkMessages.mustBeInitialized(GHttpContext.class));
		}
		if (!context.getWebRequest().getMethod().equals(GHttpMethod.GET.name()) && !checkMediaType(context.getWebRequest().getMediaType())) {
			throw new NotSupportedException();
		}
	}
	
	/**
	 * サポートしているメディアタイプであれば<code>true</code>を返します.<br>
	 * ※<code>application/x-www-form-urlencoded</code>か<code>multipart/form-data</code>をサポートします。<br>
	 * 
	 * @create 2023/10/25
	 * @param mediaType メディアタイプ
	 * @return <code>true</code> or <code>false</code>
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private boolean checkMediaType(MediaType mediaType) {
		return MediaTypes.typeEqual(MediaType.APPLICATION_FORM_URLENCODED_TYPE, mediaType) || MediaTypes.typeEqual(MediaType.MULTIPART_FORM_DATA_TYPE, mediaType);
	}
}