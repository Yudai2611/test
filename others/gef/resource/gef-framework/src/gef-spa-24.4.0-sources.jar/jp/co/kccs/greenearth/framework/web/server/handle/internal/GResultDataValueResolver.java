/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle.internal;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Optional;

import org.glassfish.jersey.server.ContainerRequest;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.server.handle.GMethodParameterValueResolver;

/**
 * {@link GResultData}を生成します.<br>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
public class GResultDataValueResolver implements GMethodParameterValueResolver<ContainerRequest, GResultData> {

	private static final Class<?> SUPPORTED_CLASS = GResultData.class;

	/**
	 * {@inheritDoc}
	 *
	 * @see GMethodParameterValueResolver#isSupported(Class, Type, Annotation[])
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean isSupported(Class<?> rawType, Type genericType, Annotation[] annotations) {
		if (rawType == SUPPORTED_CLASS) {
			return true;
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GMethodParameterValueResolver#apply(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public GResultData apply(ContainerRequest data) {
		Optional<GResultData> resultData = GObjectInstantiator.getInstance().newInstance(SUPPORTED_CLASS);
		if (resultData.isPresent()) {
			return resultData.get();
		}
		throw new GContainerException(GFrameworkMessages.canNotBeCreated(SUPPORTED_CLASS));
	}
}
