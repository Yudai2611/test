/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.handle.internal;

import java.util.function.Function;

import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.model.Parameter;
import org.glassfish.jersey.server.spi.internal.ValueParamProvider;

import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.priority.GPriorityRegistry;
import jp.co.kccs.greenearth.framework.web.server.handle.GMethodParameterValueResolver;

/**
 * {@link GMethodParameterValueResolver}を{@link ValueParamProvider}として振舞わせるためのアダプタークラスです.<br>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
public class GValueParamProviderAdapter implements ValueParamProvider {

	/** エンドポイントの引数値リゾルバ */
	Class<GMethodParameterValueResolver<ContainerRequest, ?>> adapteeClass;

	/**
	 * コンストラクタです.<br>
	 * 
	 * @create 2023/10/25
	 * @param adapteeClass リゾルバクラス
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public GValueParamProviderAdapter(Class<GMethodParameterValueResolver<ContainerRequest, ?>> adapteeClass) {
		this.adapteeClass = adapteeClass;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see ValueParamProvider#getValueProvider(Parameter)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public Function<ContainerRequest, ?> getValueProvider(Parameter parameter) {
		GMethodParameterValueResolver<ContainerRequest, ?> adaptee = GObjectInstantiator.getInstance().<GMethodParameterValueResolver<ContainerRequest, ?>>newInstance(adapteeClass).get();
		if (!adaptee.isSupported(parameter.getRawType(), parameter.getType(), parameter.getDeclaredAnnotations())) {
			return null;
		}
		return adaptee;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see ValueParamProvider#getPriority()
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public PriorityType getPriority() {
		return new PriorityType() {
			@Override
			public int getWeight() {
				return GPriorityRegistry.getInstance().getPriority(adapteeClass);
			}
		};
	}
}
