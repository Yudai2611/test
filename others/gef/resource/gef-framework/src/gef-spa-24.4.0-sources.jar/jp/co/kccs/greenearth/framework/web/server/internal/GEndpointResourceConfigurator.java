/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.annotation.Priority;
import jakarta.servlet.ServletConfig;
import jakarta.ws.rs.container.ResourceInfo;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.provider.GProviderService;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResourceImpl;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;
import jp.co.kccs.greenearth.framework.web.server.GEndpointResourceMatcher;
import jp.co.kccs.greenearth.framework.web.server.GServletContainer;
import org.glassfish.hk2.api.Factory;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.process.internal.RequestScoped;

/**
 * フレームワークで利用されるコンフィグレーションを管理するクラスです.<br>
 * このクラスは{@link GEndpointResource}のファクトリーを登録します.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GEndpointResourceConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録します.<br>
	 *
	 * @create 2024/04/30
	 * @param context
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		context.register(
			new AbstractBinder() {
				@Override
				protected void configure() {
					bindFactory(GEndpointResourceFactory.class).to(GEndpointResource.class).proxy(false).proxyForSameScope(false).in(RequestScoped.class).ranked(GPriority.NORMAL);
				}
		});
	}
	private static class GEndpointResourceFactory implements Factory<GEndpointResource> {
		@Override
		public GEndpointResource provide() {
			if (isSpaServlet()) {
				GWebRequest webRequest = GProviderService.getInstance().getService(GWebRequest.class);
				return GEndpointResourceMatcher.getInstance().match(webRequest).orElse(null);
			} else {
				ResourceInfo jerseyResourceInfo = GProviderService.getInstance().getService(ResourceInfo.class);
				return new GEndpointResourceImpl(jerseyResourceInfo);
			}
		}

		@Override
		public void dispose(GEndpointResource instance) {

		}
		private boolean isSpaServlet() {
			ServletConfig servletConfig = GProviderService.getInstance().getService(ServletConfig.class);
			String servletName = servletConfig.getServletName();
			String className = GServletContainer.class.getCanonicalName();
			String regClassName = servletConfig.getServletContext().getServletRegistration(servletName).getClassName();
			return regClassName.equals(className);
		}
	}
}
