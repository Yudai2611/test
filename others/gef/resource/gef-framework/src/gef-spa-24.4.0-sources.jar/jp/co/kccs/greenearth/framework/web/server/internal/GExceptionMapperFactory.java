/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.util.Optional;

import jakarta.ws.rs.ext.ExceptionMapper;

import org.glassfish.jersey.internal.ExceptionMapperFactory;

import jp.co.kccs.greenearth.commons.provider.GProviderService;

/**
 * {@link ExceptionMapper}のファクトリクラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GExceptionMapperFactory {

	/**
	 * パラメータtypeにより、exceptionを探します.<br>
	 *
	 * @create 2023/10/25
	 * @param type
	 * @return
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static <T extends Throwable> Optional<ExceptionMapper<T>> find(Class<T> type) {
		return Optional.ofNullable(getInstance().find(type));
	}
	/**
	 * パラメータinstanceにより、exceptionを探します.<br>
	 *
	 * @create 2023/10/25
	 * @param instance
	 * @return
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	public static <T extends Throwable> Optional<ExceptionMapper<T>> find(T instance) {
		return Optional.ofNullable(getInstance().findMapping(instance));
	}

	private static ExceptionMapperFactory getInstance() {
		return GProviderService.getInstance().getService(ExceptionMapperFactory.class);
	}
}
