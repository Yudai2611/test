/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;


import org.glassfish.jersey.internal.inject.InjectionManager;

/**
 * InjectionManagerを保持します.<br>
 *
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public final class GInjectionManagerHolder {

	/** インジェクションマネージャー */
	private static ThreadLocal<InjectionManager> injectionManager = new ThreadLocal<>();

	/**
	 * {@link InjectionManager}を取得します.<br>
	 *
	 * @create 2024/04/30
	 * @return {@link InjectionManager}
	 * @author KCCS dhiaz chebastian
	 * @since 24.4.0
	 */
	public static InjectionManager getInjectionManager() {
		return injectionManager.get();
	}

	/**
	 * {@link InjectionManager}の初期化処理です.<br>
	 *
	 * @create 2024/04/30
	 * @author KCCS dhiaz chebastian
	 * @since 24.4.0
	 */
	public synchronized static void init(InjectionManager injectionManager) {
		GInjectionManagerHolder.injectionManager.set(injectionManager);
	}

	/**
	 * {@link InjectionManager}の破棄処理です.<br>
	 *
	 * @create 2024/04/30
	 * @author KCCS dhiaz chebastian
	 * @since 24.4.0
	 */
	public synchronized static void destroy() {
		injectionManager.remove();
	}
}