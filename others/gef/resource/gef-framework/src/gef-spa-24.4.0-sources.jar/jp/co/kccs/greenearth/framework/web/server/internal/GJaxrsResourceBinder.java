/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.priority.GPrioritySorter;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import org.glassfish.jersey.server.ResourceConfig;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Configurable;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.configuration.GJaxrsResourceConfigBinder;
import jp.co.kccs.greenearth.framework.web.configuration.ResourceType;

import java.util.List;

/**
 * {@link GJaxrsResourceConfigBinder}の実装クラスです.<br>
 * Jaxrsのリソース（@Pathで修飾される）と@Providerで修飾されるクラスを収集し、<br>
 * InjectionManagerに格納しているResourceConfigにレジスタします。<br>
 * ※ 本クラスは、Jerseyバグ対応のパッチとして作りました。将来的に撤去する予定です。<br>
 *
 * @create 2024/04/30
 * @author yamashita
 * @since 24.4.0
 */
@Priority(GPriority.HIGH)
@ResourceType(ResourceConfig.class)
@ScanConfiguration(
	modifiers = {
		@Modifier(
			isPublic = true
		),
		@Modifier(
			isPublic = true,
			isStatic = true
		),
	},
	scannedAnnotations = {Path.class, Provider.class})
public class GJaxrsResourceBinder implements GJaxrsResourceConfigBinder {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void bind(Configurable<?> config) {
		List<Class<?>> classList = GPrioritySorter.sortByClass(GScanComponentService.getInstance().getScannedClasses(getClass()));
		for (Class<?> classObj : classList) {
			config.register(classObj);
		}
	}
}
