/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.util.List;
import java.util.Set;

import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Configuration;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.framework.web.configuration.GJaxrsResourceConfigBinder;
import jp.co.kccs.greenearth.framework.web.configuration.GJaxrsResourceConfigBinderFactory;
import org.glassfish.jersey.internal.inject.Bindings;
import org.glassfish.jersey.internal.inject.InjectionManager;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.spi.ComponentProvider;

import jp.co.kccs.greenearth.framework.web.configuration.GResourceConfigurator;

/**
 * {@link GResourceConfigurator}で定義されたコンポーネントを統合するクラスです.<br>
 * サーブレットコンテナ起動時に{@link org.glassfish.jersey.server.ApplicationHandler}内の<br>
 * {@link org.glassfish.jersey.server.ApplicationConfigurator#init(InjectionManager, org.glassfish.jersey.internal.BootstrapBag)}で実行されます。<br>
 *
 *
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Priority(Integer.MIN_VALUE)
public class GJerseyComponentProvider implements ComponentProvider {

	private InjectionManager injectionManager;
	/**
	 * {@inheritDoc}
	 *
	 * @see ComponentProvider#initialize(InjectionManager)
	 */
	@Override
	public void initialize(InjectionManager injectionManager) {
		GInjectionManagerHolder.init(injectionManager);
		this.injectionManager = injectionManager;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see ComponentProvider#bind(Class, Set)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public boolean bind(Class<?> applicationClass, Set<Class<?>> providerContracts) {
		List<GJaxrsResourceConfigBinder> binders = GJaxrsResourceConfigBinderFactory.getInstance().getBinders(applicationClass);
		if (binders.isEmpty()) {
			return false;
		}
		ResourceConfig resourceConfig = getResourceConfigInstance(applicationClass);
		for (GJaxrsResourceConfigBinder binder : binders) {
			binder.bind(resourceConfig);
		}
		return true;
	}

	/**
	 * 指定applicationClassにより、InjectionManagerからResourceConfigのインスタンスを取得します.<br>
	 * InjectionManagerから取得できない場合、インスタンスを作成してInjectionManagerに格納してから返します。<br>
	 * 
	 * @param applicationClass 指定のapplication（ResourceConfig）
	 * @return ResourceConfigのインスタンス
	 * @create 2024/04/30
	 * @author yangfeng
	 * @since 24.4.0
	 */
	private ResourceConfig getResourceConfigInstance(Class<?> applicationClass) {
		ResourceConfig resourceConfig = (ResourceConfig) injectionManager.getInstance(Configuration.class);
		if (resourceConfig == null ) {
			resourceConfig = (ResourceConfig) GObjectInstantiator.getInstance().newInstance(applicationClass).get();
			injectionManager.register(Bindings.service(resourceConfig).to(applicationClass).to(Configuration.class));
		}
		return resourceConfig;
	}

	@Override
	public void done() {}

}
