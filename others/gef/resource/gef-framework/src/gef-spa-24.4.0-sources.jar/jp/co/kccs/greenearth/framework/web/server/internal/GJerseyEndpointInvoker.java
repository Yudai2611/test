/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jp.co.kccs.greenearth.framework.web.server.converter.GResponseTypeConverter;
import jp.co.kccs.greenearth.framework.web.server.converter.GResponseTypeConverterProvider;
import jp.co.kccs.greenearth.framework.web.server.handle.GEndpointInvoker;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Objects;
import org.glassfish.jersey.server.ResourceConfig;

import org.glassfish.jersey.servlet.ServletContainer;

/**
 * エンドポイントを実行する為のクラスです。<br>
 * このクラスは{@link ServletContainer}のみ有効しますが、有効と無効に切り替えることも出来ます。<br>
 * 有効と無効の切り替えは{@link GResourceConfiguration}と{@link ResourceConfig}のプロパティから設定出来ます。<br>
 * プロパティ名は「spa.InvocationHandler.enabled」で、値はtrue(有効)、false(無効)です。
 * 
 * {@link GResourceConfiguration}の例物。
 * <code>
 * @ResourceConfig
 *	public class SampleConfigurator extends GAbstractResourceConfigurator {
 *	
 *		@Override
 *		public void configure(GFeatureContext context) {
 *			context.property("spa.InvocationHandler.enabled", true);
 *		}
 *  }
 * </code>
 * 
 * {@link ResourceConfig}の例物。
 * <code>
 * public class SampleConfigurator extends ResourceConfig {
 *		public SampleConfigurator() {
 *			property("spa.InvocationHandler.enabled", true);
 *		}
 *	}
 *
 * </code>
 * 
 * 
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GJerseyEndpointInvoker implements InvocationHandler {

	/**
	 * {エンドポイントを実行して、結果は{@link GResponseTypeConverter}で変換します。<br>
	 *
	 * @create 2024/04/30
	 * @param proxy
	 * @param method
	 * @param args
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		try {
			GEndpointInvoker invoker = GEndpointInvoker.getInstance();
			Object result = invoker.invoke(proxy, method, args);
			GResponseTypeConverter responseTypeConverter = getTypeConverterProvider().getConverter(result,
				method.getGenericReturnType());
			return responseTypeConverter.convert(result);
		} catch (Throwable throwable) {
			throw new InvocationTargetException(throwable);
		}
	}
	private GResponseTypeConverterProvider getTypeConverterProvider() {
		return GResponseTypeConverterProvider.getInstance();
	}

}
