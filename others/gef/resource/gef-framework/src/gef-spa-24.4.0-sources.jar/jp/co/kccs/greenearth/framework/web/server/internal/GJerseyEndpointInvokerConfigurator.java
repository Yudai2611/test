/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;


import java.util.Objects;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.server.spi.internal.ResourceMethodInvocationHandlerProvider;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.configuration.GResourceConfigurationProperties;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;

/**
 * フレームワークで利用するコンフィグレーションを管理するクラスです.<br>
 * このクラスは{@link GJerseyEndpointInvoker}を登録します.<br>
 * 
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GJerseyEndpointInvokerConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録します.<br>
	 *
	 * @create 2024/04/30
	 * @param context
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		Object isEnabledProperty = context.getConfiguration().getProperty(GResourceConfigurationProperties.GEFRAME_SPA_RESOURCE_CONFIG_INVOCATION_HANDLER_ENABLED);
		boolean isEnabled = true;
		if (Objects.nonNull(isEnabledProperty)) {
			try {
				isEnabled = (boolean) isEnabledProperty;
			} catch (Exception exception) {
				throw new GFrameworkException(GResourceConfigurationProperties.GEFRAME_SPA_RESOURCE_CONFIG_INVOCATION_HANDLER_ENABLED + " cannot be cast to boolean.", exception);
			}
		}
		if (isEnabled) {
			context.register(new AbstractBinder() {
				@Override
				protected void configure() {
					bind(GResourceMethodJerseyEndpointInvokerProvider.class).to(ResourceMethodInvocationHandlerProvider.class).ranked(1);;
				}
			});
		}
    }
}
