/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import org.glassfish.jersey.internal.inject.InjectionManager;
import org.glassfish.jersey.server.spi.ExternalRequestContext;
import org.glassfish.jersey.server.spi.ExternalRequestScope;

/**
 * {@inheritDoc}。<br>
 * このクラスには{@link org.glassfish.jersey.servlet.ServletContainer}経由の場合、リクエストが来る度に{@link InjectionManager}を初期化と海保します.
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GJerseyExternalRequestScope implements ExternalRequestScope<InjectionManager> {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see ExternalRequestScope#open(InjectionManager)
	 * @param injectionManager
	 * @return {@link ExternalRequestContext}
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public ExternalRequestContext<InjectionManager> open(InjectionManager injectionManager) {
		GInjectionManagerHolder.init(injectionManager);
		return new ExternalRequestContext<>(injectionManager);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see ExternalRequestScope#suspend(ExternalRequestContext, InjectionManager)
	 * @param context
	 * @param injectionManager
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void suspend(ExternalRequestContext<InjectionManager> context, InjectionManager injectionManager) {

	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see ExternalRequestScope#resume(ExternalRequestContext, InjectionManager)
	 * @param context
	 * @param injectionManager
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void resume(ExternalRequestContext<InjectionManager> context, InjectionManager injectionManager) {

	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see ExternalRequestScope#close()
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void close() {
		GInjectionManagerHolder.destroy();
	}
}
