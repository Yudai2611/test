/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.internal.inject.InjectionManager;
import org.glassfish.jersey.server.spi.ExternalRequestScope;


/**
 * {@link InjectionManager}に{@link GJerseyExternalRequestScope}を登録する為のクラスです.
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GJerseyExternalRequestScopeConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link InjectionManager}に{@link GJerseyExternalRequestScope}を登録します.
	 *
	 * @create 2024/04/30
	 * @param context
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		context.register(new AbstractBinder() {
			@Override
			protected void configure() {
				bind(GJerseyExternalRequestScope.class).to(ExternalRequestScope.class);
			}
		});
	}
}
