/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Objects;

import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.internal.inject.Binder;
import org.glassfish.jersey.internal.inject.Binding;
import org.glassfish.jersey.internal.inject.InjectionManager;
import org.glassfish.jersey.process.internal.RequestScoped;

import jakarta.inject.Singleton;
import jp.co.kccs.greenearth.commons.provider.GProviderService;

/**
 * {@link GProviderService}の実装クラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GJerseyProviderService implements GProviderService {

	/**
	 * {@inheritDoc}
	 *
	 * @see GProviderService#getService(Class)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> T getService(Class<T> clazz) {
		return getInjectionManager().getInstance(clazz);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GProviderService#getService(Type)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> T getService(Type type) {
		return getInjectionManager().getInstance(type);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GProviderService#getServices(Class)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> List<T> getServices(Class<T> clazz) {
		return getInjectionManager().getAllInstances(clazz);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GProviderService#register(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> void register(T bind) {
		if (bind instanceof Binder) {
			getInjectionManager().register(Binder.class.cast(bind));
		} else {
			getInjectionManager().register(bind);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GProviderService#register(Object, Type)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> void register(T bind, Type to) {
		register(bind, to, false);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GProviderService#register(Object, Type, boolean)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> void register(T bind, Type to, boolean singleton) {
		register(bind, to, null, singleton);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GProviderService#register(Object, Type, Integer, boolean)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> void register(T bind, Type to, Integer priority, boolean singleton) {
		AbstractBinder binder = singleton ?
			new GAbstractBinder() {
				@Override
				protected void configure() {
					@SuppressWarnings("unchecked")
					Binding<T, ?> binding = getBinding(bind).to(to).in(Singleton.class);
					if (Objects.nonNull(priority)) {
						binding.ranked(priority);
					}
				}
			} :
			new GAbstractBinder() {
				@Override
				protected void configure() {
					@SuppressWarnings("unchecked")
					Binding<T, ?> binding = getBinding(bind).to(to).proxy(true).proxyForSameScope(false).in(RequestScoped.class);
					if (Objects.nonNull(priority)) {
						binding.ranked(priority);
					}
				}
			};
		getInjectionManager().register(binder);
	}

	/**
	 * {@link AbstractBinder}を拡張し、サービスバインディングを構築します.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private abstract class GAbstractBinder extends AbstractBinder {
		@Override
		protected abstract void configure();

		protected <T> Binding<T, ?> getBinding(T bind) {
			if (Class.class.isInstance(bind)) {
				@SuppressWarnings("unchecked")
				Class<T> clazz = Class.class.cast(bind);
				return bind(clazz);
			} else {
				return bind(bind);
			}
		}

	}
	
	private InjectionManager getInjectionManager() {
		return GInjectionManagerHolder.getInjectionManager();
	}
}
