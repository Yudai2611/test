/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import org.glassfish.jersey.server.ResourceConfig;

import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;

/**
* {@link ResourceConfig}拡張クラスです.<br>
* このクラスは、{@link GAbstractResourceConfigurator}の拡張クラスのconfigurationを集約します。<br>
* 
* @create 2023/10/25
* @author okanishi
* @since 23.10.0
*/
public class GJerseyResourceConfig extends ResourceConfig { }
