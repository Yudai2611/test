/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.ws.rs.ApplicationPath;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import org.glassfish.jersey.servlet.ServletContainer;
import org.glassfish.jersey.servlet.ServletProperties;
import org.glassfish.jersey.servlet.internal.Utils;

/**
 * {@link ServletContextListener}の実装クラスです.<br>
 * web.xmlが{@link ServletContainer}で{@link jakarta.ws.rs.core.Application}が指定されていない場合、<br>
 * デフォルトで{@link GJerseyResourceConfig}を設定します。<br>
 *
 * @create 2024/04/30
 * @author KCSS yangfeng
 * @since 24.4.0
 */
@WebListener
public class GJerseyResourceRegistrationInitializer implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		sce.getServletContext().getServletRegistrations().values().stream()
				.filter(registration -> isJerseyServlet(registration.getClassName()))
				.filter(registration ->
						!registration.getInitParameters().containsKey(ServletProperties.JAXRS_APPLICATION_CLASS)
								&& !GReflectionHelper.isAnnotationPresent(registration.getName(), ApplicationPath.class))
				.forEach(registration -> {
					registration.setInitParameter(ServletProperties.JAXRS_APPLICATION_CLASS, GJerseyResourceConfig.class.getName());
					Utils.retrieve(sce.getServletContext(), registration.getName());
				});
	}

	private static boolean isJerseyServlet(String className) {
		return ServletContainer.class.getName().equals(className);
	}
}
