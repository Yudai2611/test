/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.spi.internal.ValueParamProvider;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;
import jp.co.kccs.greenearth.framework.web.server.handle.GMethodParameterValueResolverProvider;
import jp.co.kccs.greenearth.framework.web.server.handle.internal.GValueParamProviderAdapter;


/**
 * フレームワークで利用するコンフィグレーションを管理するクラスです.<br>
 * このクラスは{@link GMethodParameterValueResolverProvider}を登録します.<br>
 * 
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GMethodParameterValueResolveConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録します.<br>
	 *
	 * @create 2024/04/30
	 * @param context
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		context.register(
			new AbstractBinder() {
				@Override
				protected void configure() {
					
					List<Class<?>> resolves = GMethodParameterValueResolverProvider.getInstance().getProviders();
					for (Class<?> resolver : resolves) {
						if (((ParameterizedType) resolver.getGenericInterfaces()[0]).getActualTypeArguments()[0] == ContainerRequest.class) {
							GValueParamProviderAdapter adapter = (GValueParamProviderAdapter) GObjectInstantiator.getInstance()
								.newInstance(GValueParamProviderAdapter.class, new Class<?>[] {Class.class}, new Object[] {resolver}).get();
							bind(adapter).to(ValueParamProvider.class);
						}
					}
				}
			});
	}
    
}
