/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jp.co.kccs.greenearth.framework.web.server.GResourceConfigurationContainer;
import org.glassfish.jersey.server.ApplicationHandler;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GResourceConfigurationContainerImpl implements GResourceConfigurationContainer {
	private ApplicationHandler applicationHandler;

	public GResourceConfigurationContainerImpl() {
		this.applicationHandler = new ApplicationHandler(GJerseyResourceConfig.class);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see GResourceConfigurationContainer#init()
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void init() {
		GInjectionManagerHolder.init(applicationHandler.getInjectionManager());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see GResourceConfigurationContainer#destroy()
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void destroy() {
		GInjectionManagerHolder.destroy();
	}
}
