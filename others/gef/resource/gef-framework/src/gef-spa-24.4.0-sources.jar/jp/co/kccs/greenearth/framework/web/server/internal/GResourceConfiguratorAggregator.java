/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.util.List;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.Configurable;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContextImpl;
import jp.co.kccs.greenearth.framework.web.configuration.GJaxrsResourceConfigBinder;
import jp.co.kccs.greenearth.framework.web.configuration.GResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.ResourceType;
import org.glassfish.jersey.server.ResourceConfig;

/**
 * {@link GJaxrsResourceConfigBinder}の実装クラスです。<br>
 * {@link GResourceConfigurator}を収集し、gef-spa専用リソースと{@link GResourceConfigurator}ユーザリソースをレジスタします。<br>
 * ※　@ResourceConfigを付け　かつ　GAbstractResourceConfiguratorを拡張する　クラス。<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
@ResourceType(ResourceConfig.class)
@ScanConfiguration(
	modifiers = {
			@Modifier(
					isPublic = true
			)
	},
	scannedAnnotations = jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig.class,
	scannedAssignableTypes = GResourceConfigurator.class)
public class GResourceConfiguratorAggregator implements GJaxrsResourceConfigBinder {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void bind(Configurable<?> config) {
		GFeatureContext baseContext = new GFeatureContextImpl(config);
		List<GResourceConfigurator> configurators = GScanComponentService.getInstance().getScannedInstances(getClass());
		for (GResourceConfigurator configurator: configurators) {
			configurator.configure(baseContext);
		}
	}
}