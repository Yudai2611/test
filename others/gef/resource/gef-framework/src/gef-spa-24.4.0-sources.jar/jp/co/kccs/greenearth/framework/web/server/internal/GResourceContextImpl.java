/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.ws.rs.container.ResourceContext;
import jp.co.kccs.greenearth.commons.provider.GProviderService;

/**
 * {@link ResourceContext}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCCS okanishi
 * @since 23.10.0
 */
public class GResourceContextImpl implements ResourceContext {

	/**
	 * {@inheritDoc}
	 *
	 * @see ResourceContext#getResource(Class)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> T getResource(Class<T> resourceClass) {
		final T component = GProviderService.getInstance().getService(resourceClass);
		return component == null ? GInjectionManagerHolder.getInjectionManager().createAndInitialize(resourceClass) : component;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see ResourceContext#initResource(Object)
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public <T> T initResource(T resource) {
		GInjectionManagerHolder.getInjectionManager().inject(resource);
		return resource;
	}

}
