/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import org.glassfish.jersey.server.model.Invocable;
import org.glassfish.jersey.server.spi.internal.ResourceMethodInvocationHandlerProvider;

import java.lang.reflect.InvocationHandler;


/**
 * {@link GJerseyEndpointInvoker}を提供するためです。<br>
 * 
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GResourceMethodJerseyEndpointInvokerProvider implements ResourceMethodInvocationHandlerProvider {
	
	/**
	 * {@link GJerseyEndpointInvoker}を取得します.<br>
	 *
	 * @create 2024/04/30
	 * @param invocable
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public InvocationHandler create(Invocable invocable) {
		return new GJerseyEndpointInvoker();
	}
}
