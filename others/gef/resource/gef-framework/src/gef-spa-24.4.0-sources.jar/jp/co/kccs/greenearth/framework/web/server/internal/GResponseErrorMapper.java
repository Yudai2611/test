/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import org.glassfish.jersey.server.spi.ResponseErrorMapper;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.ext.ExceptionMapper;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link WebApplicationException}と{@link ExceptionMapper}通さない場合、エラー処理はこのクラスに実行されること。<br>
 * 
 * @create 2024/04/30
 * @author KCCS dhiaz chebastian
 * @since 24.4.0
 */
public interface GResponseErrorMapper extends ResponseErrorMapper {
    
    /**
     * DIから{@link GResponseErrorMapper}を取得する。<br>
     * 
     * @create 2024/04/30
     * @return {@link GResponseErrorMapper}
     * @author KCCS dhiaz chebastian
     * @since 24.4.0
     */
    static GResponseErrorMapper getInstance() {
        return GFrameworkUtils.getComponent(GResponseErrorMapper.class.getName());
    }
}
