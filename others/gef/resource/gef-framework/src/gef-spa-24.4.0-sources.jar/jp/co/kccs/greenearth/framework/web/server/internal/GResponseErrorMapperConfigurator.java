/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.server.spi.ResponseErrorMapper;

import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;

/**
 * フレームワークで利用するコンフィグレーションを管理するクラスです.<br>
 * このクラスはJerseyの{@link ResponseErrorMapper}を有効するため、プロパティを「true」にすること.<br>
 * 
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GResponseErrorMapperConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録します.<br>
	 *
	 * @create 2024/04/30
	 * @param context
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		context.property(ServerProperties.PROCESSING_RESPONSE_ERRORS_ENABLED, true);
	}
}
