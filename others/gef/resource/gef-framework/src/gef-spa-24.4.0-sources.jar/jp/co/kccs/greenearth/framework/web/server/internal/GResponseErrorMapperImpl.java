/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Optional;


import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFrameworkPropertyKeys;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;

/**
 * {@link GResponseErrorMapper}の実装クラス。<br>
 *
 * @create 2024/04/30
 * @see GResponseErrorMapper
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Provider
public class GResponseErrorMapperImpl implements GResponseErrorMapper {

	/** スタックトレース表示デフォルト */
	private static String DEFAULT_ENABLE = Boolean.TRUE.toString();

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see GResponseErrorMapper#toResponse(Throwable)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Response toResponse(Throwable throwable) {
		String message;
		int status;
		if (throwable instanceof WebApplicationException webApplicationException) {
			status = webApplicationException.getResponse().getStatus();
			message = webApplicationException.getMessage();
		} else {
			status = GHttpStatus.INTERNAL_SERVER_ERROR.getStatusCode();
			message = GHttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();
		}
		Optional<Response> response = toResponseInternal(throwable, status, message);
		return response.orElseGet(() -> Response.status(status).build());
	}


	/**
	 * エラー情報({@link Throwable})からJAX-RSレスポンス({@link Response})へ変換します.<br/>
	 *
	 * @create 2023/10/25
	 * @param throwable エラー情報({@link Throwable})
	 * @return JAX-RSレスポンス({@link Response})
	 * @author yamashita
	 * @since 23.10.0
	 */
	private Optional<Response> toResponseInternal(Throwable throwable, int status, String message) {
		if (isWriteBodyContent()) {
			GSystemError error = GSystemError.create(throwable);
			error.setTimeStamp(OffsetDateTime.now(ZoneId.of("UTC")));
			error.setStatusCode(status);
			error.setMessage(message);
			return Optional.of(Response.status(status).type(GMediaType.APPLICATION_JSON).entity(error).build());
		}
		return Optional.empty();
	}

	private Boolean isWriteBodyContent() {
		String value = GFrameworkUtils.getProperty(GFrameworkPropertyKeys.GEFRAME_SPA_WEB_SERVER_RESPONSE_ERROR_CONTENT_ENABLE_DEFAULT.getKey(), DEFAULT_ENABLE);
		return Boolean.valueOf(GStringUtils.isNullOrEmpty(value) ? DEFAULT_ENABLE : value);
	}
}
