/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.*;

import jakarta.ws.rs.NotAcceptableException;
import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.framework.web.resource.GEndpointResource;
import jp.co.kccs.greenearth.framework.web.server.GCombinedMediaType;
import jp.co.kccs.greenearth.framework.web.server.GCombinedMediaTypeComparator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.glassfish.jersey.CommonProperties;
import org.glassfish.jersey.message.internal.MediaTypes;
import org.glassfish.jersey.server.ResourceConfig;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.GFrameworkPropertyKeys;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.web.GResponseWriter;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.internal.GContainerResponse;
import jp.co.kccs.greenearth.framework.web.server.GResponseProcessor;


/**
 * {@link GResponseProcessor}の実装クラスです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GResponseProcessorImpl implements GResponseProcessor {
	private static final Log LOGGER = LogFactory.getLog(GResponseProcessor.class);

	/** スタックトレース表示デフォルト */
	private static String DEFAULT_ENABLE = Boolean.TRUE.toString();

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.GResponseProcessor#process(jp.co.kccs.greenearth.framework.web.GWebResponse)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void process(GWebResponse response) {
		LOGGER.trace(GFrameworkMessages.$s_PROCESS_STARTED.message(GResponseProcessor.class.getSimpleName()));
		write(response);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.GResponseProcessor#release(jp.co.kccs.greenearth.framework.web.GWebResponse)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void release(GWebResponse response) {
		if (Objects.nonNull(response)) {
			response.close();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.GResponseProcessor#toResponse(java.lang.Throwable, jp.co.kccs.greenearth.framework.web.GWebRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public GWebResponse toResponse(Throwable throwable, GWebRequest request) {
		try {
			return createWebResponse(request,
					applyWebApplicationException(throwable)
							.orElseGet(() -> 
									applyExceptionMapper(throwable)
											.orElseGet(() -> 
													applyResponseErrorMapper(throwable).get()
											)
							)
			);
		} catch (Exception e) {
			return createWebResponse(request, applyResponseErrorMapper(e).get());
		}
	}
	
	/**
	 * 指定したthrowableが{@link WebApplicationException}である、且つ、内包されるresponseにエンティティがある場合.<br>
	 * 　　responseを返します。<br>
	 * 以外の場合、<br>
	 * 　　Optional.empty()を返します。<br>
	 * 
	 * @param throwable エラー情報({@link Throwable})
	 * @return response レスポンス
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private Optional<Response> applyWebApplicationException(Throwable throwable) {
		if (WebApplicationException.class.isInstance(throwable)) {
			WebApplicationException e = WebApplicationException.class.cast(throwable);
			Optional<Response> response = Optional.ofNullable(e.getResponse());
			if (response.isPresent() && response.get().hasEntity()) {
				return response;
			}
		}
		return Optional.empty();
	}
	
	/**
	 * 指定したthrowableの{@link ExceptionMapper}がある場合.<br>
	 * 　　ExceptionMapperのマッピング結果を返します。<br>
	 * 以外の場合、<br>
	 * 　　Optional.empty()を返します。<br>
	 * 
	 * @param throwable エラー情報({@link Throwable})
	 * @return response レスポンス
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private Optional<Response> applyExceptionMapper(Throwable throwable) {
		Optional<ExceptionMapper<Throwable>> mapper = GExceptionMapperFactory.find(throwable);
		if (mapper.isPresent()) {
			return Optional.of(
					Optional.ofNullable(mapper.get().toResponse(throwable))
							.orElseGet(() -> 
									Response.noContent().build()
							)
			);
		}
		return Optional.empty();
	}
	
	/**
	 * 指定したthrowableに対し、{@link GResponseErrorMapper}のマッピング結果を返します.<br>
	 * 
	 * @param throwable エラー情報({@link Throwable})
	 * @return response レスポンス
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private Optional<Response> applyResponseErrorMapper(Throwable throwable) {
		return Optional.of(GResponseErrorMapper.getInstance().toResponse(throwable));
	}

	protected void write(GWebResponse response) {
		if (Objects.isNull(response)) {
			return;
		}
		GWebRequest request = response.getWebRequest();
		GResponseWriter writer = request.getResponseWriter();
		if (!response.hasEntity()) {
			LOGGER.info(GFrameworkMessages.WRITTEN_AN_EMPTY_BODY.message());
			writer.writeStatusAndHeaders(response, 0);
			return;
		}
		determineResponseMediaType(response, request);
		applyChunkedThresholdSize((GContainerResponse) response);
		try {
			writer.write(response);
		} catch (Throwable throwable) {
			LOGGER.fatal(GFrameworkMessages.anIOErrorHasOccuOccurred("while writing a response message entity to the container output stream"));
			throw throwable;
		}
	}

	private void determineResponseMediaType(GWebResponse webResponse, GWebRequest webRequest) {
		Response response = webResponse.getResponse();
		if (Objects.isNull(response)) {
			return;
		}
		if (Objects.nonNull(response.getMediaType())) {
			webResponse.setMediaType(response.getMediaType());
			return;
		}
		Optional<GEndpointResource> endpointResourceOptional = webRequest.getResource();
		endpointResourceOptional.ifPresent(endpointResource -> webRequest.getResource().ifPresent(resourceInfo -> {
			List<GCombinedMediaType> mediaTypeCandidates = new ArrayList<>();
			for (MediaType acceptable : webRequest.getAcceptableMediaTypes()) {
				for (MediaType produces : endpointResource.getProduces()) {
					if (produces.isCompatible(acceptable)) {
						mediaTypeCandidates.add(GCombinedMediaType.create(acceptable, produces));
					}
				}
			}
			if (mediaTypeCandidates.isEmpty()) {
				throw new NotAcceptableException();
			}

			mediaTypeCandidates = mediaTypeCandidates.stream().sorted(new GCombinedMediaTypeComparator()).toList();

			MediaType selectMediaType = mediaTypeCandidates.get(0);
			if (MediaTypes.isWildcard(selectMediaType)) {
				if (selectMediaType.isWildcardType()
						|| "application".equalsIgnoreCase(selectMediaType.getType())) {
					selectMediaType = MediaType.APPLICATION_OCTET_STREAM_TYPE;
				} else {
					throw new NotAcceptableException();
				}
			}
			webResponse.setMediaType(selectMediaType);
		}));
	}

	/**
	 * 通常（非チャンク）転送を可能とします.<br>
	 * 内部の判定条件：<br>
	 *   レスポンスのEntityのサイズが閾値を超える場合、チャンクとします。<br>
	 *   以外の場合、通常とします。<br>
	 * ※ この処理をしないと、暗黙的にチャンク転送になります。<br>
	 *
	 * @param response HTTPレスポンス
	 * @create 2023/10/25
	 * @author yangfeng
	 * @since 23.10.0
	 */
	protected void applyChunkedThresholdSize(GContainerResponse response) {
		response.getContainerResponse().enableBuffering(
				new ResourceConfig().addProperties(new HashMap<>() {
					{ put(CommonProperties.OUTBOUND_CONTENT_LENGTH_BUFFER, response.getChunkedThresholdSize()); }
				}));
	}

	protected GWebResponse createWebResponse(GWebRequest request, Response response) {
		return new GContainerResponse(request, response);
	}

	private Boolean isWriteBodyContent() {
		String value = GFrameworkUtils.getProperty(GFrameworkPropertyKeys.GEFRAME_SPA_WEB_SERVER_RESPONSE_ERROR_CONTENT_ENABLE_DEFAULT.getKey(), DEFAULT_ENABLE);
		return Boolean.valueOf(GStringUtils.isNullOrEmpty(value) ? DEFAULT_ENABLE : value);
	}
}
