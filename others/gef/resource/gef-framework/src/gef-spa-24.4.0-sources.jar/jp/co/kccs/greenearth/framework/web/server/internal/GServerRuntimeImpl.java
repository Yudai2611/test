/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.glassfish.jersey.process.internal.RequestContext;
import org.glassfish.jersey.process.internal.RequestScope;
import org.glassfish.jersey.server.internal.process.RequestProcessingContext;
import org.glassfish.jersey.server.internal.process.RequestProcessingContextReference;
import org.glassfish.jersey.server.internal.routing.UriRoutingContext;

import jakarta.ws.rs.NotFoundException;
import jp.co.kccs.greenearth.commons.provider.GProviderService;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.filter.GFilterChainController;
import jp.co.kccs.greenearth.framework.web.filter.GFilterChainControllerImpl;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.internal.GContainerRequest;
import jp.co.kccs.greenearth.framework.web.server.GResponseProcessor;
import jp.co.kccs.greenearth.framework.web.server.GServerRuntime;
import jp.co.kccs.greenearth.framework.web.server.handle.GEndpointHandle;
import jp.co.kccs.greenearth.framework.web.server.handle.GEndpointHandleResolver;
import lombok.NoArgsConstructor;

/**
 * {@link GServerRuntime}の実装クラスです.<br>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@NoArgsConstructor
public class GServerRuntimeImpl implements GServerRuntime {

	private static final Log LOGGER = LogFactory.getLog(GServerRuntime.class);
	private GEndpointHandleResolver resolver;
	private GResponseProcessor responseProcessor;
	private GFilterChainController filterChainController;


	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.GServerRuntime#init(jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void init(GFilterChainConfiguration filterChainConfiguration) {
		LOGGER.trace(GFrameworkMessages.$s_INIT_STARTED.message(GServerRuntime.class.getSimpleName()));
		if (Objects.nonNull(filterChainConfiguration)) {
			this.filterChainController = new GFilterChainControllerImpl(filterChainConfiguration);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.GServerRuntime#process(jp.co.kccs.greenearth.framework.web.GWebRequest)
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void process(final GWebRequest request) {
		LOGGER.info(GFrameworkMessages.$s_PROCESS_STARTED.message(GServerRuntime.class.getSimpleName()));
		GProviderService providerService = GProviderService.getInstance();
		RequestScope requestScope = providerService.getService(RequestScope.class);
		RequestContext requestScopeInstance = requestScope.createContext();
		try {
			requestScope.runInScope(requestScopeInstance, createRunnable(request));
		} finally {
			requestScopeInstance.release();
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.web.server.GServerRuntime#destroy()
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void destroy() {
		LOGGER.trace(GFrameworkMessages.$s_DESTROY_STARTED.message(GServerRuntime.class.getSimpleName()));
	}

	protected Runnable createRunnable(GWebRequest request) {
		return () -> {
			RequestProcessingContextReference requestProcessingContextReference = GProviderService.getInstance().getService(RequestProcessingContextReference.class);
			if (Optional.ofNullable(requestProcessingContextReference.get()).isEmpty()) {
				requestProcessingContextReference.set(
						new RequestProcessingContext(GInjectionManagerHolder.getInjectionManager(), ((GContainerRequest) request).getContainerRequest(),  (UriRoutingContext) ((GContainerRequest)request).getContainerRequest().getUriInfo(), null, null)
				);
			}
			ProcessStageContext stageContext = new ProcessStageContext();

			try {
				processRequestFilter(request, stageContext);
				if (!stageContext.isAbort) {
					endpointApply(request, stageContext);
				}
			} catch (Throwable throwable) {
				processExceptionMapper(request, stageContext, throwable);
				LOGGER.error("Error Cause!!!", throwable);
			}

			try {
				processResponseFilter(request, stageContext);
			} catch (Throwable throwable) {
				if (!stageContext.isFailed) {
					processExceptionMapper(request, stageContext, throwable);
				}
				LOGGER.error("Error Cause!!!", throwable);
			}

			try {
				processResponse(stageContext);
			} catch (Throwable throwable) {
				request.getResponseWriter().failure(throwable);
			} finally {
				release(stageContext);
			}
		};
	}

	protected void endpointApply(GWebRequest request, ProcessStageContext stageContext) throws Throwable {
		stageContext.currentResponse = resolve(request).apply(request);
	}

	protected void processExceptionMapper(GWebRequest request, ProcessStageContext stageContext, Throwable throwable) {
		stageContext.isFailed = true;
		stageContext.previousResponse = stageContext.currentResponse;
		stageContext.currentResponse = getResponseProcessor().toResponse(throwable, request);
	}

	protected void processRequestFilter(GWebRequest request, ProcessStageContext stageContext) throws Throwable {
		Optional<GWebResponse> webResponse = filterChainController.applyRequest(request);
		if (webResponse.isPresent()) {
			stageContext.isAbort = true;
			stageContext.currentResponse = webResponse.get();
		}
	}

	protected void processResponse(ProcessStageContext stageContext) {
		getResponseProcessor().process(stageContext.currentResponse);
	}

	protected void processResponseFilter(GWebRequest request, ProcessStageContext stageContext) throws Throwable {
		filterChainController.applyResponse(request, stageContext.currentResponse);
	}

	protected void release(GWebResponse response) {
		getResponseProcessor().release(response);
	}

	protected void release(ProcessStageContext stageContext) {
		release(stageContext.currentResponse);
		release(stageContext.previousResponse);
	}

	protected GEndpointHandle resolve(GWebRequest request) {
		GEndpointHandle handle = getEndpointHandleResolver().resolve(request);
		if (Objects.isNull(handle)) {
			throw new NotFoundException(GFrameworkMessages.isNotFound(GEndpointHandle.class.getSimpleName()));
		}
		return handle;
	}

	GResponseProcessor getResponseProcessor() {
		if (Objects.isNull(responseProcessor)) {
			responseProcessor = GResponseProcessor.getInstance();
		}
		return responseProcessor;
	}

	GEndpointHandleResolver getEndpointHandleResolver() {
		if (Objects.isNull(resolver)) {
			resolver = GFrameworkUtils.getComponent(GEndpointHandleResolver.class.getName());
		}
		return resolver;
	}

	private class ProcessStageContext {
		public GWebResponse previousResponse;
		public GWebResponse currentResponse;
		public boolean isAbort = false;
		public boolean isFailed = false;
	}
}
