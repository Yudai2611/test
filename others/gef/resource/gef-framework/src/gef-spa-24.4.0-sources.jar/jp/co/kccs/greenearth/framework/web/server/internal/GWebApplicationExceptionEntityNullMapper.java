/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GFrameworkPropertyKeys;
import jp.co.kccs.greenearth.framework.data.GSystemError;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Optional;

/**
 * 発生される例外は{@link WebApplicationException}の場合、このクラスは{@link WebApplicationException}のレスポンス情報通（メッセージ、ステータスコード）りに{@link GSystemError}に変換します。<br/>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GWebApplicationExceptionEntityNullMapper implements ExceptionMapper<WebApplicationException> {

	/**
	 * エラー情報({@link Throwable})からJAX-RSレスポンス({@link Response})へ変換します.<br/>
	 *
	 * @param exception エラー情報({@link Throwable})
	 * @return JAX-RSレスポンス({@link Response})
	 * @create 2024/04/30
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Response toResponse(WebApplicationException exception) {
		Response res = exception.getResponse();
		if (res.hasEntity()) {
			return res;
		}
		return getResponseErrorMapper().toResponse(exception);
	}

	private GResponseErrorMapper getResponseErrorMapper() {
		return GFrameworkUtils.getComponent(GResponseErrorMapper.class);
	}
}
