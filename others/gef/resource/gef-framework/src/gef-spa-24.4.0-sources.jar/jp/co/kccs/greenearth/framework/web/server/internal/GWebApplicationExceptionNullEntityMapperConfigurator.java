/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.configuration.GResourceConfigurationProperties;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;
import java.util.Objects;


/**
 * フレームワークで利用するコンフィグレーションを管理するクラスです.<br>
 * このクラスは{@link GWebApplicationExceptionEntityNullMapper}を登録します.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GWebApplicationExceptionNullEntityMapperConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録します.<br>
	 *
	 * @create 2024/04/30
	 * @param context
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		Object isEnabledProperty = context.getConfiguration().getProperty(GResourceConfigurationProperties.GEFRAME_SPA_WEB_APPLICATION_EXCEPTION_ENTITY_IS_NULL_HANDLER_ENABLED);
		boolean isEnabled = true;
		if (Objects.nonNull(isEnabledProperty)) {
			try {
				isEnabled = (boolean) isEnabledProperty;
			} catch (Exception exception) {
				throw new GFrameworkException(GResourceConfigurationProperties.GEFRAME_SPA_WEB_APPLICATION_EXCEPTION_ENTITY_IS_NULL_HANDLER_ENABLED + " cannot be cast to boolean.", exception);
			}
		}
		if (isEnabled) {
			context.register(GWebApplicationExceptionEntityNullMapper.class);
		}
	}
}
