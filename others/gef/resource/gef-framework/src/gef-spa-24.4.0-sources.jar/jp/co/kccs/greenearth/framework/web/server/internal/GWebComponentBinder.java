/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import org.glassfish.jersey.internal.PropertiesDelegate;
import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.internal.inject.ReferencingFactory;
import org.glassfish.jersey.internal.util.collection.Ref;
import org.glassfish.jersey.process.internal.RequestScoped;
import org.glassfish.jersey.servlet.WebConfig;

import jakarta.inject.Inject;
import jakarta.inject.Provider;
import jakarta.inject.Singleton;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.container.ResourceContext;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Request;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.ext.Providers;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GJaxrsProviders;
import jp.co.kccs.greenearth.framework.web.internal.GRequestUriInfo;
import jp.co.kccs.greenearth.framework.web.internal.GRequestUriInfoImpl;
import jp.co.kccs.greenearth.framework.web.server.GServerRuntime;


/**
* {@link AbstractBinder}の実装クラスです.<br/>
* 主に、{@link GServerRuntime}配下で利用するリソースをJersey管理下へエントリーします。<br/>
*
* @create 2023/10/25
* @author KCCS Dhiaz Chebastian
* @since 23.10.0
*/
public class GWebComponentBinder extends AbstractBinder {

	private GWebServletConfig webConfig;

	public GWebComponentBinder(GWebServletConfig webConfig) {
		this.webConfig = webConfig;
	}

	/**
	 *
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.internal.inject.AbstractBinder#configure()
	 * @author KCCS Dhiaz Chebastian
	 * @since 23.10.0
	 */
	@Override
	protected void configure() {
		bindFactory(webConfig::getServletContext).to(ServletContext.class).in(Singleton.class);
		bindFactory(() -> webConfig.getServletConfig()).to(ServletConfig.class).in(Singleton.class);
		bindFactory(() -> webConfig).to(WebConfig.class).in(Singleton.class);
		
		bindFactory(HttpServletRequestFactory.class).to(HttpServletRequest.class).proxy(false).proxyForSameScope(false).in(RequestScoped.class).ranked(GPriority.NORMAL);
		bindFactory(HttpServletResponseFactory.class).to(HttpServletResponse.class).proxy(false).proxyForSameScope(false).in(RequestScoped.class).ranked(GPriority.NORMAL);
		bindFactory(GUriInfoFactory.class).to(GRequestUriInfo.class).to(UriInfo.class).to(ResourceInfo.class).proxy(false).proxyForSameScope(false).in(RequestScoped.class).ranked(GPriority.NORMAL);
		bindFactory(RequestFactory.class).to(HttpHeaders.class).to(Request.class).to(PropertiesDelegate.class).proxy(false).proxyForSameScope(false).in(RequestScoped.class).ranked(GPriority.NORMAL);
		bind(GJaxrsProviders.class).to(Providers.class).in(Singleton.class).ranked(GPriority.NORMAL);
		bind(GResourceContextImpl.class).to(ResourceContext.class).in(Singleton.class).ranked(GPriority.NORMAL);
	}
	
	private static class HttpServletRequestFactory extends ReferencingFactory<HttpServletRequest> {
		@Inject
		public HttpServletRequestFactory(Provider<Ref<HttpServletRequest>> referenceFactory) {
			super(referenceFactory);
		}
		
		@Override
		public HttpServletRequest get() {
			return GHttpContextHolder.getContext().getWebRequest().getNativeRequest();
		}
	}

	private static  class HttpServletResponseFactory extends ReferencingFactory<HttpServletResponse> {
		@Inject
		public HttpServletResponseFactory(Provider<Ref<HttpServletResponse>> referenceFactory) {
			super(referenceFactory);
		}

		public HttpServletResponse get() {
			return GHttpContextHolder.getContext().getWebRequest().getNativeResponse();
		}
	}
	
	private static  class RequestFactory extends ReferencingFactory<Request> {
		@Inject
		public RequestFactory(Provider<Ref<Request>> referenceFactory) {
			super(referenceFactory);
		}

		public Request get() {
			return GHttpContextHolder.getContext().getWebRequest().getRequest();
		}
	}
	
	private static  class GUriInfoFactory extends ReferencingFactory<GRequestUriInfo> {
		@Inject
		public GUriInfoFactory(Provider<Ref<GRequestUriInfo>> referenceFactory) {
			super(referenceFactory);
		}

		public GRequestUriInfo get() {
			return new GRequestUriInfoImpl();
		}
	}
}
