/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import jakarta.annotation.Priority;
import org.glassfish.hk2.api.Factory;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.process.internal.RequestScoped;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.HttpHeaders;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.http.GHttpHeaders;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;

/**
 * フレームワークで利用されるコンフィグレーションを管理するクラスです.<br>
 * このクラスは{@link GWebRequestConfigurator}を登録します.<br>
 * 
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GWebRequestConfigurator extends GAbstractResourceConfigurator {
   
	/**
	 * {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録します.<br>
	 *
	 * @create 2024/04/30
	 * @param context
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		context.register(
			new AbstractBinder() {
				@Override
				protected void configure() {
                    bindFactory(GWebRequestFactory.class).to(GWebRequest.class).to(ContainerRequestContext.class).to(HttpHeaders.class).to(GHttpHeaders.class).proxy(false).proxyForSameScope(false).in(RequestScoped.class).ranked(GPriority.NORMAL);
				}
			});
	}

	private static class GWebRequestFactory implements Factory<GWebRequest> {
		@Override
		public GWebRequest provide() {
			return GHttpContextHolder.getContext().getWebRequest();
		}

		@Override
		public void dispose(GWebRequest instance) {

		}
	}
}
