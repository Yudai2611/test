/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.server.internal;

import java.util.Enumeration;

import org.glassfish.jersey.servlet.WebConfig;

import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jp.co.kccs.greenearth.framework.web.server.GServletContainer;

/**
 * {@link WebConfig}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GWebServletConfig implements WebConfig {

	private final GServletContainer servlet;

	public GWebServletConfig(final GServletContainer servlet) {
		this.servlet = servlet;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.servlet.WebConfig#getConfigType()
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	@Override
	public ConfigType getConfigType() {
		return ConfigType.ServletConfig;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.servlet.WebConfig#getServletConfig()
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	@Override
	public ServletConfig getServletConfig() {
		return servlet.getServletConfig();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.servlet.WebConfig#getFilterConfig()
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	@Override
	public FilterConfig getFilterConfig() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.servlet.WebConfig#getName()
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	@Override
	public String getName() {
		return servlet.getServletName();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.servlet.WebConfig#getInitParameter(java.lang.String)
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public String getInitParameter(final String name) {
		return servlet.getInitParameter(name);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.servlet.WebConfig#getInitParameterNames()
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	@Override
	public Enumeration<String> getInitParameterNames() {
		return servlet.getInitParameterNames();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @see org.glassfish.jersey.servlet.WebConfig#getServletContext()
	 * @create 2023/10/25
	 * @since 23.10.0
	 */
	@Override
	public ServletContext getServletContext() {
		return servlet.getServletContext();
	}
}
