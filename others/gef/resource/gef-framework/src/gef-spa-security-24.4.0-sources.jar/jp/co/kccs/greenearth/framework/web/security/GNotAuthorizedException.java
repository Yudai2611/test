/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security;

import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;

/**
 * {@link NotAuthorizedException}の拡張クラス。<br/>
 *
 * @create 2024/04/30
 * @see NotAuthorizedException
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GNotAuthorizedException extends NotAuthorizedException {

	/**
	 * エラーメッセージのみを設定します。<br/>
	 *
	 * @create 2024/04/30
	 * @param message エラーメッセージ
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	//JAX-RSのスペック的には、WWW-Authenticatedヘッダをレスポンスに含まないと行けないです。
	// 一方でGEFの場合、互換性為、FormAuthenticationをRESTに維持したい、しかし、FormAuthenticateはWWW-Authenticateを要らないです。
	//メッセージのみのコンストラクタがないため、このコンストラクタが必要になります。
	public GNotAuthorizedException(String message) {
		super(message, Response.status(401).build());
	}


	/**
	 * 例外のみを設定します。<br/>
	 *
	 * @create 2024/04/30
	 * @param throwable 例外
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(Throwable throwable) {
		super(throwable.getMessage(), throwable, Response.status(401).build());
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(Object, Object...) 
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(Object challenge, Object... moreChallenges) {
		super(challenge, moreChallenges);
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(String, Object, Object...)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(String message, Object challenge, Object... moreChallenges) {
		super(message, challenge, moreChallenges);
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(Response)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(Response response) {
		super(response);
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(String, Response)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(String message, Response response) {
		super(message, response);
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(Throwable, Object, Object...)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(Throwable cause, Object challenge, Object... moreChallenges) {
		super(cause, challenge, moreChallenges);
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(String, Throwable, Object, Object...)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(String message, Throwable cause, Object challenge, Object... moreChallenges) {
		super(message, cause, challenge, moreChallenges);
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(Response, Throwable) 
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(Response response, Throwable cause) {
		super(response, cause);
	}

	/**
	 * {@inheritDoc}。<br/>
	 *
	 * @create 2024/04/30
	 * @see GNotAuthorizedException#GNotAuthorizedException(String, Response, Throwable) 
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public GNotAuthorizedException(String message, Response response, Throwable cause) {
		super(message, response, cause);
	}
}
