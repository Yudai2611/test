/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * セキュリティープロパティキーの一覧です. <br/>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public enum GSecurityPropertyKeys {

	/** CSRFを検証する時に無視される「HttpMethod」のデフォルトはプロパティに定義します.プロパティキーはこのenumです. **/
	GEFRAME_SPA_WEB_SECURITY_CSRF_IGNORE_HTTP_METHOD_DEFAULT("geframe.spa.web.security.csrf.ignore.httpMethods.default"),
	/** セキュリティーコンテキストのモードのデフォルトはプロパティに定義します.プロパティキーはこのenumです. **/
	GEFRAME_SPA_WEB_SECURITY_CONTEXT_HOLDER_DEFAULT("geframe.spa.web.security.contextHolder.default");
	private String key;
	GSecurityPropertyKeys(String key) {
		this.key = key;
	}

	/**
	 * プロパティキーを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return プロパティキー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getKey() {
		return key;
	}

	/**
	 * プロパティから値を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return プロパティの値
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getValue() {
		return GFrameworkUtils.getProperty(getKey());
	}

	/**
	 * プロパティから値を取得します.<br/>
	 * 指定したキーが存在しない場合、引数指定のデフォルト値を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @param defaultValue デフォルト値
	 * @return プロパティの値
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getValue(String defaultValue) {
		return GFrameworkUtils.getProperty(getKey(), defaultValue);
	}
}
