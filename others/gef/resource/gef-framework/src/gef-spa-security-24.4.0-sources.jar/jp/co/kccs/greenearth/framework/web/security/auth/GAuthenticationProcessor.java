/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.auth;

import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContext;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;


/**
 * 認証プロセスを規定します.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GAuthenticationProcessor {

	/**
	 * 認証のための一連のプロセスを実行します.<br/>
	 * ・認証フローの制御<br/>
	 * ・認証の実行({@link #authenticate(HttpServletRequest, HttpServletResponse)})<br/>
	 * ・認証情報({@link GSubject})の保管({@link GSecurityContextHolder})<br/>
	 * <br/>
	 * ※認証情報は{@link GSecurityContextHolder}が管理する{@link GSecurityContext}に保管されます。
	 * 
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param response HTTPレスポンス
	 * @return 認証結果({@link Optional<GSubject>})
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<GSubject> process(HttpServletRequest request, HttpServletResponse response);

	/**
	 * 認証を実行します.<br/>
	 * ※実行結果の認証情報は、保管しません。<br/>
	 * 
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param response HTTPレスポンス
	 * @return 認証結果({@link Optional<GSubject>})
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<GSubject> authenticate(HttpServletRequest request, HttpServletResponse response);
}
