/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.auth;

import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;

/**
 * リクエストボディの種別に応じたストラテジーを規定します.<br/>
 * 種別は、メディアタイプで区別します。<br/>
 * 複数のストラテジーが存在する場合、{@link jakarta.annotation.Priority}の順に従い、順次実行します。<br>
 * ※実装クラスでは、{@link jakarta.ws.rs.Consumes}により種別を指定する必要があります。<br>
 * 
 * <pre>
 * example.
 * {@code
 * 	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
 * 	&#064;Priority(GPriority.LOW)
 * 	public class GFormBodyAuthenticationProcessorStrategy implements GBodyAuthenticationProcessorStrategy {
 *        ...
 *        }
 * </pre>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GBodyAuthenticationProcessorStrategy {
	/**
	 * 認証を実行します.<br/>
	 * ※実行結果の認証情報は、保管しません。<br/>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @return 認証結果({@link Optional<GSubject>})
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GSubject> authenticate(HttpServletRequest request);
}
