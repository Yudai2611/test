/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.auth;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.MessageBodyReader;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.auth.GUserDao;
import jp.co.kccs.greenearth.framework.auth.GUserImpl;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GMessageBodyFactory;
import jp.co.kccs.greenearth.framework.web.security.GNotAuthorizedException;

/**
 * リクエストボディが{@link GMediaType#APPLICATION_FORM_URLENCODED}の場合のストラテジーとなります.<br/>
 *
 * @see GBodyAuthenticationProcessorStrategy
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
@Priority(GPriority.LOW)
public class GFormBodyAuthenticationProcessorStrategy implements GBodyAuthenticationProcessorStrategy {
	
	/**
	 * 
	 * 
	 * @see jp.co.kccs.greenearth.framework.web.security.auth.GBodyAuthenticationProcessorStrategy#authenticate(jakarta.servlet.http.HttpServletRequest)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubject> authenticate(HttpServletRequest request) {
		MediaType mediaType = GMediaType.valueOf(request.getContentType());
		MessageBodyReader<MultivaluedMap> reader = GMessageBodyFactory.getReader(MultivaluedMap.class, MultivaluedMap.class, null, mediaType);
		try {
			InputStream bodyInputStream = request.getInputStream();
			if (Objects.nonNull(bodyInputStream)) {
				MultivaluedMap<String, Object> body = reader.readFrom(MultivaluedMap.class, MultivaluedMap.class, null, mediaType,
					GHttpContextHolder.getContext().getWebRequest().getHeaders(), bodyInputStream);
				String companyCd = (String) body.get("companycd").get(0);
				String userId = (String) body.get("userid").get(0);
				String password = (String) body.get("password").get(0);
				GUserDao dao = GFrameworkUtils.getComponent(GUserDao.class);
				GUser user;
				try {
					user = dao.findUser(companyCd, userId);
				} catch (GResourceProcessingException e) {
					throw new GNotAuthorizedException(e);
				}

				// 認証
				if (Objects.nonNull(user) && password.equals(user.getPassword())) {
					if (user.isInvalid()) {
						throw new GNotAuthorizedException(GFrameworkMessages.authenticationFailedDueTo("user is invalid"));
					}
					user.setPassword(null);
					GSubject subject = createSubject(user);
					return Optional.of(subject);
				}
				return Optional.empty();
			}
		}  catch (IOException e) {
			throw new GContainerException("Error while reading request body.");
		}

		return Optional.empty();
	}

	private GSubject createSubject(GUser user) {
		GUser userPrincipal = new GUserImpl();
		userPrincipal.setCompany(user.getCompany());
		userPrincipal.setId(user.getId());
		userPrincipal.setLocale(user.getLocale());
		userPrincipal.setName(user.getName());
		GSubject subject = GSubject.create();
		subject.setPrincipal(userPrincipal);
		subject.setAuthenticated(true);
		return subject;
	}
}
