/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.auth;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.MessageBodyReader;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.auth.GUserDao;
import jp.co.kccs.greenearth.framework.auth.GUserImpl;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.http.message.internal.GMessageBodyFactory;
import jp.co.kccs.greenearth.framework.web.security.GNotAuthorizedException;

/**
 * リクエストボディが{@link GMediaType#APPLICATION_JSON}または{@link GMediaType#TEXT_JSON}の場合のストラテジーとなります.<br/>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Consumes({GMediaType.APPLICATION_JSON, GMediaType.TEXT_JSON})
@Priority(GPriority.LOW)
public class GJsonBodyAuthenticationProcessorStrategy implements GBodyAuthenticationProcessorStrategy {
	
	/**
	 * {@inheritDoc}
	 * 
	 * @see jp.co.kccs.greenearth.framework.web.security.auth.GBodyAuthenticationProcessorStrategy#authenticate(jakarta.servlet.http.HttpServletRequest)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubject> authenticate(HttpServletRequest request) {
		MediaType mediaType = GMediaType.valueOf(request.getContentType());
		MessageBodyReader<Map> reader = GMessageBodyFactory.getReader(Map.class, Map.class, null, mediaType);
		try {
			InputStream bodyInputStream = request.getInputStream();
			if (Objects.nonNull(bodyInputStream)) {
				Map<String, Object> body = reader.readFrom(Map.class, Map.class, null, mediaType, GHttpContextHolder.getContext().getWebRequest().getHeaders(), bodyInputStream);
				String companyCd = (String) body.get("companycd");
				String userId = (String) body.get("userid");
				String password = (String) body.get("password");

				GUserDao dao = GFrameworkUtils.getComponent(GUserDao.class);
				GUser user;
				try {
					user = dao.findUser(companyCd, userId);
				} catch (GResourceProcessingException e) {
					throw new GNotAuthorizedException(e);
				}

				// 認証
				if (Objects.nonNull(user) && password.equals(user.getPassword())) {
					if (user.isInvalid()) {
						throw new GNotAuthorizedException(GFrameworkMessages.authenticationFailedDueTo("user is invalid"));
					}
					user.setPassword(null);
					GSubject subject = createSubject(user);
					return Optional.of(subject);
				}
				return Optional.empty();
			}
		} catch (IOException e) {
			throw new GContainerException("Error while reading request body.");
		}
		return Optional.empty();
	}

	/**
	 * {@link GSubject}を作成します。<br>
	 *
	 * @create 2023/10/25
	 * @param user 認証結果のユーザーオブジェクト。
	 * @return {@link GSubject} 渡されるユーザーオブジェクトを入れた「Subject」。
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private GSubject createSubject(GUser user) {
		GUser userPrincipal = new GUserImpl();
		userPrincipal.setCompany(user.getCompany());
		userPrincipal.setId(user.getId());
		userPrincipal.setLocale(user.getLocale());
		userPrincipal.setName(user.getName());
		GSubject subject = GSubject.create();
		subject.setPrincipal(userPrincipal);
		subject.setAuthenticated(true);
		return subject;
	}
}
