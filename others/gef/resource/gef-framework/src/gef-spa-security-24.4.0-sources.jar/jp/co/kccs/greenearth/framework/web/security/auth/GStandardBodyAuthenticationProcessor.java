/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.auth;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContext;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;

/**
 * 認証情報はリクエストボディに入れる場合、このクラスを使います。メディアタイプごとに{@link GBodyAuthenticationProcessorStrategy}を実行されます.<br>
 * デフォルトで提供される{@link GBodyAuthenticationProcessorStrategy}は「x-www-url-formencoded」と「application/json」です。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
		@Modifier(isPublic = true)
	},
	scannedAssignableTypes = GBodyAuthenticationProcessorStrategy.class)
public class GStandardBodyAuthenticationProcessor implements GAuthenticationProcessor {

	/** {@link GBodyAuthenticationProcessorStrategy}のキャシューです。 **/
	private List<GBodyAuthenticationProcessorStrategy> strategies = null;

	/**
	 * {@inheritDoc}
	 * {@link HttpServletRequest#getInputStream()}から見て、各実装の処理によって認証情報を確認されます.<br>
	 *
	 * @see GAuthenticationProcessor#authenticate(HttpServletRequest, HttpServletResponse)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubject> authenticate(HttpServletRequest request, HttpServletResponse response) {
		if (isContentTypePresent(request)) {
			Optional<GBodyAuthenticationProcessorStrategy> strategyOptional = getStrategy(request);
			if (strategyOptional.isPresent()) {
				Optional<GSubject> subjectOptional = strategyOptional.get().authenticate(request);
				subjectOptional.ifPresent(gSubject -> GSecurityContextHolder.getContext().setSubject(gSubject));
				return subjectOptional;
			}
		}
		return Optional.empty();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAuthenticationProcessor#process(HttpServletRequest, HttpServletResponse)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubject> process(HttpServletRequest request, HttpServletResponse response) {
		GSecurityContext securityContext = GSecurityContextHolder.getContext();
		GSubject subject = securityContext.getSubject().orElse(null);
		if (Objects.isNull(subject) || !subject.isAuthenticated()) {
			GSubject result = authenticate(request, response).orElse(null);
			securityContext.setSubject(result);
			return Optional.ofNullable(result);
		}
		return Optional.of(subject);
	}

	private synchronized List<GBodyAuthenticationProcessorStrategy> getStrategies() {
		if (Objects.isNull(strategies)) {
			strategies = GScanComponentService.getInstance().getScannedInstances(getClass());
			strategies = filterNoConsumesAnnotation(strategies);
		}
		return strategies;
	}
	private Optional<GBodyAuthenticationProcessorStrategy> getStrategy(HttpServletRequest request) {
		for (GBodyAuthenticationProcessorStrategy strategy : getStrategies()) {
			if (isSupported(strategy, request)) {
				return Optional.of(strategy);
			}
		}
		return Optional.empty();
	}
	private synchronized List<GBodyAuthenticationProcessorStrategy> filterNoConsumesAnnotation(List<GBodyAuthenticationProcessorStrategy> strategies) {
		return strategies.stream().filter(strategy -> strategy.getClass().isAnnotationPresent(Consumes.class)).collect(Collectors.toList());
	}

	private boolean isContentTypePresent(HttpServletRequest request) {
		return Objects.nonNull(request.getContentType());
	}
	private boolean isSupported(GBodyAuthenticationProcessorStrategy authenticationProcessor, HttpServletRequest httpServletRequest) {
		if (authenticationProcessor.getClass().isAnnotationPresent(Consumes.class)) {
			for (String mediaType: authenticationProcessor.getClass().getAnnotation(Consumes.class).value()) {
				MediaType requestMediaType = GMediaType.valueOf(httpServletRequest.getContentType());
				MediaType supportedMediaType = GMediaType.valueOf(mediaType);
				if (supportedMediaType.isCompatible(requestMediaType)) {
					return true;
				}
			}
		}
		return false;
	}
}
