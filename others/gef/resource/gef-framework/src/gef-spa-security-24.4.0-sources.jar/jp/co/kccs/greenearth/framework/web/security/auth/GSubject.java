/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.auth;

import java.io.Serializable;
import java.security.Principal;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/***
 * 認証関連の情報(Credentialや認証結果など)を格納するためのインタフェースです.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GSubject extends Serializable {

	/**
	 * 主要なオブジェクト({@link Principal})を取得します.<br>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @return 主要なオブジェクト
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T extends Principal & Serializable> T getPrincipal();

	/**
	 * 主要なオブジェクト({@link Principal})を設定します.<br>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param principal 主要なオブジェクト
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T extends Principal & Serializable> void setPrincipal(T principal);

	/**
	 * 詳細情報を取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @return 詳細情報
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T extends Serializable> T getDetails();

	/**
	 * 詳細情報を設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param details 詳細情報
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T extends Serializable> void setDetails(T details);

	/**
	 * クレデンシャルを取得します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @return クレデンシャル
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T extends Serializable> T getCredential();

	/**
	 * クレデンシャルを設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param <T>
	 * @param credential クレデンシャル
	 * @author yamashita
	 * @since 23.10.0
	 */
	<T extends Serializable> void setCredential(T credential);

	/**
	 * 認証済みかどうかを判定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return true:　認証済/　false:　非認証
	 * @author yamashita
	 * @since 23.10.0
	 */
	boolean isAuthenticated();

	/**
	 * 認証済みかどうかを設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param isAuthenticated true:　認証済/　false:　非認証
	 * @author yamashita
	 * @since 23.10.0
	 */
	void setAuthenticated(boolean isAuthenticated);

	/**
	 * {@link GSubject}インスタンスを生成します.<br/>
	 * 
	 * @create 2023/10/25
	 * @return
	 * @author yamashita
	 * @since 23.10.0
	 */
	static GSubject create() {
		return GFrameworkUtils.getComponent(GSubject.class.getName());
	}
}
