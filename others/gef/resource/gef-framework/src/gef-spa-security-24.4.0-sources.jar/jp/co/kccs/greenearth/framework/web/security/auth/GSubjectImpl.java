/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.auth;

import java.io.Serializable;
import java.security.Principal;

import lombok.NoArgsConstructor;

/**
 * {@link GSubject}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@NoArgsConstructor
public class GSubjectImpl implements GSubject {
	private static final long serialVersionUID = 6137167322412973764L;

	private Principal principal;
	private Object details;
	private Object credential;
	private boolean isAuthenticated;

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends Principal & Serializable> T getPrincipal() {
		return (T) principal;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T extends Principal & Serializable> void setPrincipal(T principal) {
		this.principal = principal;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends Serializable> T getDetails() {
		return (T) details;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends Serializable> T getCredential() {
		return (T) credential;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean isAuthenticated() {
		return isAuthenticated;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T extends Serializable> void setDetails(T details) {
		this.details = details;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public <T extends Serializable> void setCredential(T credential) {
		this.credential = credential;
	}
}
