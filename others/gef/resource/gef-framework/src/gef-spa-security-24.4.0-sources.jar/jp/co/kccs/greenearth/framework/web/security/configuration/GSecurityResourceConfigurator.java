/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.configuration;

import jakarta.annotation.Priority;
import jakarta.ws.rs.core.SecurityContext;

import org.glassfish.hk2.api.Factory;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.process.internal.RequestScoped;

import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContext;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;

/**
 * フレームワークで利用するコンフィグレーションを管理するクラスです.<br>
 * 
 * @create 2023/10/25
 * @author okanishi
 * @since 23.10.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GSecurityResourceConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param context
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		context.register(
			new AbstractBinder() {
				@Override
				protected void configure() {
					bindFactory(GSecurityContextFactory.class).to(GSecurityContext.class).to(SecurityContext.class).proxy(false).proxyForSameScope(false).in(RequestScoped.class).ranked(GPriority.NORMAL);
				}
			});
	}

	/**
	 * {@link RequestScoped}のライフサイクルで、{@link GSecurityContext}を取得為のクラスです. <br/>
	 *
	 * @create 2023/10/25
	 * @author KCCS okanishi
	 * @since 23.10.0
	 */
	private static class GSecurityContextFactory implements Factory<SecurityContext> {

		/**
		 * {@link GSecurityContext}を取得します. <br/>
		 *
		 * @create 2023/10/25
		 * @return 作られたセキュリティコンテキスト。
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public SecurityContext provide() {
			return GSecurityContextHolder.getContext();
		}

		/**
		 * {@link GSecurityContext}を削除します. <br/>
		 *
		 * @create 2023/10/25
		 * @param instance
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public void dispose(SecurityContext instance) {

		}
	}
}
