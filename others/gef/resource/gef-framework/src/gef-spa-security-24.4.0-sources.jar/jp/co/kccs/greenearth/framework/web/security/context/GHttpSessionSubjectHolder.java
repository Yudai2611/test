/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.context;

import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.SessionSubjectHolder;
import lombok.NoArgsConstructor;

/**
 * {@link GSubjectHolder}の実装クラスです.<br/>
 * {@link GSubject}の保管先を{@link HttpSession}とします. <br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@NoArgsConstructor
@Priority(GPriority.NORMAL)
@SessionSubjectHolder
public class GHttpSessionSubjectHolder implements GSubjectHolder {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void save(GSubject subject) {
		HttpServletRequest nativeRequest = GHttpContextHolder.getContext().getWebRequest().getNativeRequest();
		nativeRequest.getSession().setAttribute(GHttpSessionSubjectHolder.class.getName(), subject);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubject> get() {
		HttpServletRequest nativeRequest = GHttpContextHolder.getContext().getWebRequest().getNativeRequest();
		GSubject subject =  (GSubject) nativeRequest.getSession().getAttribute(GHttpSessionSubjectHolder.class.getName());
		return Optional.ofNullable(subject);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void revoke() {
		HttpServletRequest nativeRequest = GHttpContextHolder.getContext().getWebRequest().getNativeRequest();
		nativeRequest.getSession().removeAttribute(GHttpSessionSubjectHolder.class.getName());
	}

}
