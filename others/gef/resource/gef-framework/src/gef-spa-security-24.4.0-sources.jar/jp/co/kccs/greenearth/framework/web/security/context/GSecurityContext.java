/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.context;

import java.util.Optional;

import jakarta.ws.rs.core.SecurityContext;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;

/**
 * セキュリティ関連のコンテキストを表現します.<br/>
 * 主に、認証情報へのアクセスを提供します. <br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GSecurityContext extends SecurityContext {

	/**
	 * {@link GSubject}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return サブジェクト
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<GSubject> getSubject();

	/**
	 * {@link GSubject}を設定します.<br/>
	 * 
	 * @create 2023/10/25
	 * @param subject サブジェクト
	 * @author yamashita
	 * @since 23.10.0
	 */
	void setSubject(GSubject subject);

	/**
	 * {@link GSubject}を削除します.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void revoke();
}
