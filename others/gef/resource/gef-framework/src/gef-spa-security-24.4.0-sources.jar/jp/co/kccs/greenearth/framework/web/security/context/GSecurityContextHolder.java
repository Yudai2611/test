/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.context;

import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContext;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;

import java.util.Objects;

/**
 * {@link GSecurityContext}を管理するクラスです. <br/>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public final class GSecurityContextHolder {

	/** 各リクエストのスレッドロカルは{@link GSecurityContext}を保存します. **/
	private static ThreadLocal<GSecurityContext> threadLocal = new ThreadLocal<>();

	/**
	 * {@link GSecurityContext}をinitします. <br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static void init() {
		GSecurityContext securityContext = createSecurityContext();
		threadLocal.set(securityContext);
	}

	/**
	 * {@link GSecurityContext}を取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return 保管される {@link GSecurityContext}
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static GSecurityContext getContext() {
		GSecurityContext context = threadLocal.get();
		return context;
	}

	/**
	 * {@link GSecurityContext}を削除します. <br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	public static void release() {
		GSecurityContext securityContext = threadLocal.get();
		if (Objects.nonNull(securityContext)) {
			threadLocal.remove();
		}
	}

	/**
	 * {@link GHttpContext}より、{@link GWebRequest}を取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return {@link GHttpContext}からの{@link GWebRequest}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static GWebRequest getWebRequest() {
		GHttpContext context = GHttpContextHolder.getContext();
		Objects.requireNonNull(context, GFrameworkMessages.mustBeRequired(GHttpContext.class.getSimpleName()));
		GWebRequest request = context.getWebRequest();
		Objects.requireNonNull(request, GFrameworkMessages.mustBeRequired(GWebRequest.class.getSimpleName()));
		return request;
	}

	/**
	 * {@link GHttpContext}の「WebRequest」で{@link GSecurityContext}を作成します. <br/>
	 *
	 * @create 2023/10/25
	 * @return 作られた {@link GSecurityContext}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static GSecurityContext createSecurityContext() {
		return new GSecurityContextImpl(getWebRequest().getNativeRequest());
	}

	/**
	 * セキュリティコンテキストのモード. <br/>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	public enum Type {
		/** スレッドロカルモード。各スレッドに保管します。 **/
		THREADLOCAL("threadlocal"),
		/** セッションモード。リクエストのセッションに保管します。　**/
		SESSION("session");

		private String value;

		Type(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
}
