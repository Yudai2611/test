/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.context;

import java.security.Principal;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;

/**
 * {@link GSecurityContext}の実装クラスです.<br/>
 * カレントリクエスト({@link GWebRequest})が適用されるセキュリティルールに基づいて、最適な{@link GSubjectHolder}をスイッチします. <br/>
 * これにより、{@link #getSubject()}で取得される保存先の種別（例：セッションか?スレッドローカルか?など）を意識することなく、{@link GSubject}への透過的なアクセスを提供します. <br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public class GSecurityContextImpl implements GSecurityContext {

	/** セキュリティーコンテキストの{@link HttpServletRequest} **/
	private final HttpServletRequest request;

	public GSecurityContextImpl(HttpServletRequest request) {
		this.request = request;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean isUserInRole(String role) {
		return request.isUserInRole(role);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public boolean isSecure() {
		return request.isSecure();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Principal getUserPrincipal() {
		return request.getUserPrincipal();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public String getAuthenticationScheme() {
		return request.getAuthType();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubject> getSubject() {
		Optional<GSubjectHolder> subjectHolder = getStrategy();
		if (subjectHolder.isPresent()) {
			return subjectHolder.get().get();
		}
		return Optional.empty();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void setSubject(GSubject subject) {
		Optional<GSubjectHolder> subjectHolder = getStrategy();
		subjectHolder.ifPresent(s -> s.save(subject));
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void revoke() {
		Optional<GSubjectHolder> subjectHolder = getStrategy();
		subjectHolder.ifPresent(GSubjectHolder::revoke);
	}

	/**
	 * リクエストによって、最適な{@link GSubjectHolder}を探しに行きます.<br>
	 *
	 * @create 2023/10/25
	 * @return 見つかられた {@link GSubjectHolder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private Optional<GSubjectHolder> getStrategy() {
		GWebRequest webRequest = GHttpContextHolder.getContext().getWebRequest();
		return GSubjectHolderResolver.getInstance().resolve(webRequest);
	}
}
