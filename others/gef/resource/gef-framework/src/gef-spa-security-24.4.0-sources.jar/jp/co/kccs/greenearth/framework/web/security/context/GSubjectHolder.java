/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.context;

import java.util.Optional;

import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;

/**
 * {@link GSubject}を保管します.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GSubjectHolder {

	/**
	 * {@link GSubject}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GSubject}
	 * @author yamashita
	 * @since 23.10.0
	 */
	Optional<GSubject> get();

	/**
	 * {@link GSubject}を保存します.<br>
	 *
	 * @create 2023/10/25
	 * @param subject {@link GSubject}
	 * @author yamashita
	 * @since 23.10.0
	 */
	void save(GSubject subject);

	/**
	 * {@link GSubject}を削除します.<br>
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	void revoke();
}
