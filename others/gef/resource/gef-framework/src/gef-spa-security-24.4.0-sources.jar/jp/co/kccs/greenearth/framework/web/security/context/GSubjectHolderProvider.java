/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.context;

import java.lang.annotation.Annotation;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * 各モードで優先される{@link GSubjectHolder}を提供するクラスです.<br>
 * 優先順位は{@link jakarta.annotation.Priority}で判断されます。小さい数字の方が優先されます. <br/>
 * 
 * @create 2023/10/25
 * @author dhiaz chebastian
 * @since 23.10.0
 */
public interface GSubjectHolderProvider {

	/**
	 * アノテーションで{@link GSubjectHolder}を取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @param annotation
	 * @return 見つかられた {@link GSubjectHolder}
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GSubjectHolder> getSubjectHolder(Class<? extends Annotation> annotation);


	/**
	 * DIコンテナーから{@link GSubjectHolderProvider}を取得します。ライフサイクルと実装オブジェクトはDIと合わせます.<br>
	 *
	 * @create 2023/10/25
	 * @return DIからの {@link GSubjectHolderProvider}
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	static GSubjectHolderProvider getInstance() {
		return GFrameworkUtils.getComponent(GSubjectHolderProvider.class.getName());
	}
}
