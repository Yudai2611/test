/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.context;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.SessionSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.ThreadLocalSubjectHolder;
import lombok.NoArgsConstructor;

/**
 * {@link GSubjectHolderProvider}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author dhiaz chebastian
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
			@Modifier(isPublic = true)
	},
	scannedAssignableTypes = GSubjectHolder.class)
@NoArgsConstructor
public class GSubjectHolderProviderImpl implements GSubjectHolderProvider {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GSubjectHolderProvider#getSubjectHolder(Class)
	 * @author dhiaz chebastian
	 * @since 23.10.0
	 */
	public Optional<GSubjectHolder> getSubjectHolder(Class<? extends Annotation> annotation) {
		List<GSubjectHolder> components = GScanComponentService.getInstance().getScannedInstances(getClass());
		for (GSubjectHolder securityContext: components) {
			if (securityContext.getClass().isAnnotationPresent(annotation)) {
				return Optional.of(securityContext);
			}
		}
		return Optional.empty();
	}


}
