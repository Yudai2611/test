/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.context;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GWebRequest;

/**
 * セキュリティルールによって、{@link GSubjectHolder}を提供するクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSubjectHolderResolver {

	/**
	 * セキュリティルールによって、{@link GSubjectHolder}を返します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return {@link GSubjectHolder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GSubjectHolder> resolve(GWebRequest webRequest);

	/**
	 * DIコンテナーから{@link GSubjectHolderResolver}を取得します。ライフサイクルと実装オブジェクトはDIと合わせます.<br>
	 *
	 * @create 2023/10/25
	 * @return DIからの {@link GSubjectHolderResolver}の実装
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static GSubjectHolderResolver getInstance() {
		return GFrameworkUtils.getComponent(GSubjectHolderResolver.class);
	}
}
