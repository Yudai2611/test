/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.context;

import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.GSecurityPropertyKeys;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry;

/**
 * {@link GSubjectHolderResolver}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSubjectHolderResolverImpl implements GSubjectHolderResolver {

	/** プロパティからのデフォルト{@link GSubjectHolder}です。 **/
	private GSubjectHolder defaultHolder;

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GSubjectHolderResolver#resolve(GWebRequest)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubjectHolder> resolve(GWebRequest webRequest) {
		GSubjectHolder subjectHolder = matchesType(webRequest);
		Objects.requireNonNull(subjectHolder, GFrameworkMessages.isNotFound(GSubjectHolder.class.getSimpleName()) + "type = " + subjectHolder.getClass().getSimpleName());
		return Optional.ofNullable(subjectHolder);
	}

	/**
	 * セキュリティルールレジストリに一致するリクエストを探しに行きます。見つからない場合、デフォルト{@link GSubjectHolder}を返します. <br/>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private GSubjectHolder matchesType(GWebRequest request) {
		Optional<GSecurityRule> securityRule = getSecurityRule(request);
		if (securityRule.isPresent()) {
			return securityRule.get().getContextHolder();
		}
		return getDefault();
	}

	/**
	 * プロパティからデフォルト{@link GSubjectHolder}を取得します。ルールの中に見つからない場合、このデフォルト{@link GSubjectHolder}は使われます. <br/>
	 *
	 * @create 2023/10/25
	 * @return デフォルト{@link GSubjectHolder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private GSubjectHolder getDefault() {
		if (Objects.isNull(defaultHolder)) {
			String securityContextClazz = GFrameworkUtils.getProperty(GSecurityPropertyKeys.GEFRAME_SPA_WEB_SECURITY_CONTEXT_HOLDER_DEFAULT.getKey(), GThreadLocalSubjectHolder.class.getCanonicalName());
			Optional<GSubjectHolder> subjectHolderOptional = GObjectInstantiator.getInstance().newInstance(securityContextClazz);
			subjectHolderOptional.ifPresent(holder-> defaultHolder = holder);
		}
		return defaultHolder;
	}

	/**
	 * セキュリティルールレジストリに一致するリクエストを探しに行きます. <br/>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return 一致するセキュリティルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private Optional<GSecurityRule> getSecurityRule(GWebRequest webRequest) {
		return GSecurityRuleRegistry.Factory.getInstance().lookup(webRequest.getNativeRequest());
	}
}
