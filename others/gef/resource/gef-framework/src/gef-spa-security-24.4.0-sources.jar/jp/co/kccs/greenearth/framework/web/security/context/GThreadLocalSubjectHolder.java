/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.context;

import java.util.Optional;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.ThreadLocalSubjectHolder;
import lombok.NoArgsConstructor;

/**
 * {@link GSubjectHolder}の実装クラスです.<br/>
 * {@link GSubject}の保管先を{@link ThreadLocal}とします. <br/>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@NoArgsConstructor
@Priority(GPriority.NORMAL)
@ThreadLocalSubjectHolder
public class GThreadLocalSubjectHolder implements GSubjectHolder {

	/** 各スレッドに{@link GSubject}を保管する変数です。 **/
	private final ThreadLocal<GSubject> subjectThreadLocal = new ThreadLocal<>();

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void save(GSubject subject) {
		subjectThreadLocal.set(subject);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSubject> get() {
		return Optional.ofNullable(subjectThreadLocal.get());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author yamashita
	 * @since 23.10.0
	 */
	@Override
	public void revoke() {
		subjectThreadLocal.remove();
	}
}
