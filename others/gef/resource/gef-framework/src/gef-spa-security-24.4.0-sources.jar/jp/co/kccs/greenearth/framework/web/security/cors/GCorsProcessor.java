/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.cors;

import java.util.Locale;
import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.HttpMethod;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.web.http.GHttpHeaders;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;


/**
 * CorsFilterのプロセス処理のインタフェースです.<br>
 * 
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public interface GCorsProcessor {

	/**
	 * Corsの許可ルールに基づいて、リクエストの有効性をチェックします.<br>
	 *
	 * @param request HTTPリクエスト
	 * @param response HTTPレスポンス
	 * @param configuration Corsコンフィギュレーション
	 * @return Optional<Response> is empty: 正常, is not empty: 異常
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 *
	 */
	Optional<Response> verifyProcess(HttpServletRequest request, HttpServletResponse response,
		GCorsConfiguration configuration);

	/**
	 * リクエストが「PreFlight」リクエストかどうか判断します.<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @return 判断結果
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	static boolean isPreflightRequest(HttpServletRequest request) {
		return (request.getMethod().equalsIgnoreCase(HttpMethod.OPTIONS) && Objects.nonNull(request.getHeader(GHttpHeaders.ORIGIN))
				&& Objects.nonNull(request.getHeader(GHttpHeaders.ACCESS_CONTROL_REQUEST_METHOD)));
	}

	/**
	 * リクエストが「Local」リクエストかどうか判断します.<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @return 判断結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static boolean isLocalRequest(HttpServletRequest request) {
		String originHeader = request.getHeader(GHttpHeaders.ORIGIN);
		if (GStringUtils.isNullOrTrimEmpty(originHeader)) {
			return true;
		}
		// Build scheme://host:port from request
		StringBuilder target = new StringBuilder();
		String scheme = request.getScheme();
		if (Objects.isNull(scheme)) {
			return false;
		} else {
			scheme = scheme.toLowerCase(Locale.ENGLISH);
		}
		target.append(scheme);
		target.append("://");
		String host = request.getServerName();
		if (Objects.isNull(host)) {
			return false;
		}
		target.append(host);
		int port = request.getServerPort();
		if ("http".equals(scheme) && port != 80 || "https".equals(scheme) && port != 443) {
			target.append(':');
			target.append(port);
		}
		return originHeader.equalsIgnoreCase(target.toString());
	}
}
