/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.cors;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.web.http.GHttpHeaders;
import jp.co.kccs.greenearth.framework.web.http.GHttpStatus;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;

/**
 * CorsFilterのプロセス処理のクラスです.<br>
 * 
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public class GCorsProcessorImpl implements GCorsProcessor {

	/** ワイドカードの値です。 **/
	private static final String ALL = "*";

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsProcessor#verifyProcess(HttpServletRequest, HttpServletResponse, GCorsConfiguration)
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	public Optional<Response> verifyProcess(HttpServletRequest request, HttpServletResponse response, GCorsConfiguration configuration) {
		if (GCorsProcessor.isLocalRequest(request)) {
			return Optional.empty();
		}
		return GCorsProcessor.isPreflightRequest(request) ?
					verifyPreFlightRequest(request, response, configuration) :
					verifyMainRequest(request, response, configuration);
	}

	/**
	 * セキュリティルールによって、リクエストは許されるかどうか判断します.<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param response HTTPレスポンス
	 * @param configuration 一致するCORSコンフィグレーション
	 * @return 検証された結果で作られたレスポンス
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	protected Optional<Response> verifyPreFlightRequest(HttpServletRequest request, HttpServletResponse response, GCorsConfiguration configuration) {
		if (!isValidRequestByPreflight(request, configuration)) {
			return Optional.of(createAndGetError(response));
		}
		applyExposeHeaders(response, configuration);
		applyAllowCredentials(response, configuration);
		applyAllowOrigin(request, response);
		applyAllowMethods(request, response);
		applyAllowHeaders(request, response);
		applyMaxAage(response, configuration);
		return Optional.of(Response.status(response.getStatus()).build());
	}

	/**
	 * プリフライトリクエストは有効されるかどうかを判断します.<br>
	 * 「true」は有効。「false」は無効。<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param configuration 一致するCORSコンフィグレーション
	 * @return 判断結果
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	protected boolean isValidRequestByPreflight(HttpServletRequest request, GCorsConfiguration configuration) {
		return (isValidOrigin(request, configuration) &&
			isValidMethod(request.getHeader(GHttpHeaders.ACCESS_CONTROL_REQUEST_METHOD), configuration) && 
			isValidHeaders(request, configuration));
	}

	/**
	 * 本物のリクエストを確認します.<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param response HTTPレスポンス
	 * @param configuration 一致するCORSコンフィグレーション
	 * @return 検証された結果で作られたレスポンス
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	protected Optional<Response> verifyMainRequest(HttpServletRequest request, HttpServletResponse response, GCorsConfiguration configuration) {
		if (!isValidRequestByMain(request, configuration)) {
			return Optional.of(createAndGetError(response));
		}
		applyAllowOrigin(request, response);
		applyExposeHeaders(response, configuration);
		applyAllowCredentials(response, configuration);
		return Optional.empty();
	}

	/**
	 * 本物リクエストは有効されるかどうかを検証します.<br>
	 * 「true」は有効。「false」は無効。<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param configuration 一致するCORSコンフィグレーション
	 * @return 検証結果
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	protected boolean isValidRequestByMain(HttpServletRequest request, GCorsConfiguration configuration) {
		return (isValidOrigin(request, configuration) &&
			isValidMethod(request.getMethod(), configuration));
	}

	/**
	 * リクエストのオリジン(Access-Control-Allow-Origin)は有効かどうかを検証します.<br>
	 * 「true」は有効。「false」は無効。<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param configuration 一致するCORSコンフィグレーション
	 * @return 検証結果
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	protected boolean isValidOrigin(HttpServletRequest request, GCorsConfiguration configuration) {
		String origin = request.getHeader(GHttpHeaders.ORIGIN);
		if (GStringUtils.isNullOrTrimEmpty(origin)) {
			return false;
		}
		List<String> allowedOriginList = configuration.getAllowOrigins();
		List<String> upperCaseList = allowedOriginList.stream().map(String::toUpperCase).collect(Collectors.toList());
		return upperCaseList.contains(ALL) || upperCaseList.contains(origin.trim().toUpperCase());
	}

	/**
	 * リクエストの「HttpMethod」(Access-Control-Allow-Methods)を有効かどうかを検証します.<br>
	 * 「true」は有効。「false」は無効。<br>
	 *
	 * @create 2023/10/25
	 * @param method 検証されたいHttpMethod
	 * @param configuration 一致するCORSコンフィグレーション
	 * @return 検証結果
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	protected boolean isValidMethod(String method, GCorsConfiguration configuration) {
		if (GStringUtils.isNullOrTrimEmpty(method)) {
			return false;
		}
		List<String> allowedMethodList = configuration.getAllowMethods();
		if (Objects.isNull(allowedMethodList) || allowedMethodList.isEmpty()) {
			return false;
		}
		List<String> upperCaseList = allowedMethodList.stream().map(String::toUpperCase).collect(Collectors.toList());
		return upperCaseList.contains(ALL) || upperCaseList.contains(method.trim().toUpperCase());
	}

	/**
	 * リクエストのヘッダー(Access-Control-Allow-Headers)を有効かどうかを検証します.<br>
	 * 「true」は有効。「false」は無効。<br>
	 *
	 * @create 2023/10/25
	 * @param request HTTPリクエスト
	 * @param configuration 一致するCORSコンフィグレーション
	 * @return 検証結果
	 * @author KCCS yangfeng
	 * @since 23.10.0
	 */
	protected boolean isValidHeaders(HttpServletRequest request, GCorsConfiguration configuration) {
		List<String> allowedList = configuration.getAllowHeaders();
		String requestHeaders = request.getHeader(GHttpHeaders.ACCESS_CONTROL_REQUEST_HEADERS);
		if (GStringUtils.isNullOrTrimEmpty(requestHeaders) || allowedList.contains(ALL)) {
			return true;
		}
		List<String> upperCaseList = allowedList.stream().map(String::toUpperCase).collect(Collectors.toList());
		return !Arrays.stream(requestHeaders.split(","))
				.filter(header -> !upperCaseList.contains(header.trim().toUpperCase()))
				.findFirst()
				.isPresent();
	}


	private void applyExposeHeaders(HttpServletResponse response, GCorsConfiguration configuration) {
		if (Objects.nonNull(configuration.getExposeHeaders())) {
			response.setHeader(GHttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS,
					String.join(", ", configuration.getExposeHeaders()));
		}
	}


	private void applyAllowCredentials(HttpServletResponse response, GCorsConfiguration configuration) {
		if (configuration.isAllowCredentials()) {
			response.setHeader(GHttpHeaders.ACCESS_CONTROL_ALLOW_CREDENTIALS, Boolean.toString(true));
		}
	}
	
	private void applyAllowOrigin(HttpServletRequest request, HttpServletResponse response) {
		response.setHeader(GHttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, request.getHeader(GHttpHeaders.ORIGIN));
	}
	
	private void applyAllowMethods(HttpServletRequest request, HttpServletResponse response) {
		response.setHeader(GHttpHeaders.ACCESS_CONTROL_ALLOW_METHODS, request.getHeader(GHttpHeaders.ACCESS_CONTROL_REQUEST_METHOD));
	}
	
	private void applyAllowHeaders(HttpServletRequest request, HttpServletResponse response) {
		String headers = request.getHeader(GHttpHeaders.ACCESS_CONTROL_REQUEST_HEADERS);
		if (!GStringUtils.isNullOrEmpty(headers)) {
			response.setHeader(GHttpHeaders.ACCESS_CONTROL_ALLOW_HEADERS, headers);
		}
	}
	
	private void applyMaxAage(HttpServletResponse response, GCorsConfiguration configuration) {
		response.setHeader(GHttpHeaders.ACCESS_CONTROL_MAX_AGE, Long.toString(configuration.getMaxAge()));
	}
	
	private Response createAndGetError(HttpServletResponse response) {
		response.setStatus(GHttpStatus.FORBIDDEN.getStatusCode());
		return Response.status(response.getStatus()).build();
	}
}
