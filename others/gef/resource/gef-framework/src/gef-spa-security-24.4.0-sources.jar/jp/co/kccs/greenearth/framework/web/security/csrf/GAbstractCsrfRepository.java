/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.csrf;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletResponse;
import jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.token.GToken;
import jp.co.kccs.greenearth.framework.web.security.token.GTokenGenerator;
import jp.co.kccs.greenearth.framework.web.security.token.GUUIDTokenCreator;

/**
 * {@link GCsrfRepository}の基底クラスです.<br/>
 * 
 * @see GCsrfRepository
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public abstract class GAbstractCsrfRepository implements GCsrfRepository {
	/** CSRFトークンの有効期限です **/
	protected Long maxAge;
	/** リクエストに付けるCSRFトークンのヘッダ項目名の「Prefix」です **/
	protected String headerPrefix;
	/** トークンを生成する為のジェネレーターです。 **/
	protected GTokenGenerator tokenGenerator;
	/** CSRFトークンの保管キーです。 **/
	protected String tokenKey;
	/** コンフィグレーションはレポシトリーの追加情報です。**/
	protected Map<String, Object> configuration;

	public GAbstractCsrfRepository() {
		maxAge = Long.valueOf(-1);
		tokenGenerator = new GUUIDTokenCreator();
		tokenKey = GFrameworkReservedWords.PARAMETER_NAME_CSRF_TOKEN.key();
		headerPrefix = "";
		configuration = new HashMap<>();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#generateToken()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GToken generateToken() {
		return tokenGenerator.generate(maxAge);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#setTokenKey(String)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#getTokenKey()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public String getTokenKey() {
		return tokenKey;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#setTokenGenerator(GTokenGenerator)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setTokenGenerator(GTokenGenerator tokenGenerator) {
		this.tokenGenerator = tokenGenerator;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#getTokenGenerator()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GTokenGenerator getTokenGenerator() {
		return tokenGenerator;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#setHeaderPrefix(String)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setHeaderPrefix(String headerPrefix) {
		this.headerPrefix = headerPrefix;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#getHeaderPrefix()
	 */
	@Override
	public String getHeaderPrefix() {
		return headerPrefix;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#setTokenMaxAge(Long)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setTokenMaxAge(Long maxAge) {
		this.maxAge = maxAge;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#getTokenMaxAge() 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Long getTokenMaxAge() {
		return maxAge;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#attachToken(GWebRequest, GToken)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void attachToken(GWebRequest webRequest, GToken token) {
		((HttpServletResponse) webRequest.getNativeResponse()).addHeader(String.format("%s%s", headerPrefix, tokenKey), token.getToken());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#setConfiguration(Map)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setConfiguration(Map<String, Object> configuration) {
		this.configuration = configuration;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#getConfiguration()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Map<String, Object> getConfiguration() {
		return configuration;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepository#verifyToken(GWebRequest, String)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public boolean verifyToken(GWebRequest webRequest, String token) {
		Optional<String> actualToken = getCsrfToken(webRequest);
		if ((Objects.isNull(token) || actualToken.isEmpty())) {
			return false;
		}
		return actualToken.map(s -> s.equals(token)).orElse(false);
	}
}
