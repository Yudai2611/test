/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.csrf;


import static jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords.*;

import java.util.Objects;
import java.util.Optional;

import org.springframework.util.StringUtils;

import jakarta.annotation.Priority;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.GResponseCookie;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.CookieRepository;
import jp.co.kccs.greenearth.framework.web.security.token.GToken;

/**
 * CsrfTokenを格納するCookieリポジトリのクラスです.<br>
 * 
 * @see GAbstractCsrfRepository
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
@CookieRepository
public class GCookieCsrfRepository extends GAbstractCsrfRepository {
	/** CSRFトークためクッキーのキーです。 **/
	protected String cookieKey = PARAMETER_NAME_CSRF_TOKEN.key();

	public GCookieCsrfRepository() {
		super();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#getCsrfToken(GWebRequest)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<String> getCsrfToken(GWebRequest webRequest) {
		Cookie cookie = getCsrfCookie(webRequest, cookieKey);
		if (Objects.isNull(cookie)) {
			return Optional.empty();
		}
		String token = cookie.getValue();
		if (!StringUtils.hasLength(token)) {
			return Optional.empty();
		}
		return Optional.ofNullable(token);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#saveToken(GWebRequest, GToken)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void saveToken(GWebRequest webRequest, GToken token) {
		GResponseCookie cookie = null;
		if (Objects.nonNull(token)) {
			cookie = buildCookie(token.getToken());
		} else {
			cookie = buildCookie(null);
			cookie.setMaxAge(0);
		}
		((HttpServletResponse) webRequest.getNativeResponse()).addHeader("Set-Cookie", cookie.toString());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#release(GWebRequest) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void release(GWebRequest webRequest) {
		GResponseCookie cookie = buildCookie(null);
		cookie.setMaxAge(0);
		((HttpServletResponse) webRequest.getNativeResponse()).addHeader("Set-Cookie", cookie.toString());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#setTokenKey(String)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setTokenKey(String tokenKey) {
		this.cookieKey = tokenKey;
		this.tokenKey = tokenKey;
	}

	/**
	 * CSRFのドメインを取得します. <br/>
	 * ドメインは渡されるコンフィグレーションから取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return コンフィグレーションからのクッキードメイン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getDomain() {
		Object domain = configuration.get(GCookieRepositoryConfigurationKeys.DOMAIN.getValue());
		if (Objects.nonNull(domain)) {
			return domain.toString();
		}
		return null;
	}

	/**
	 * CSRFのパースを取得します. <br/>
	 * パースは渡されるコンフィグレーションから取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return コンフィグレーションからのパース
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getPath() {
		Object path = configuration.get(GCookieRepositoryConfigurationKeys.PATH.getValue());
		if (Objects.nonNull(path)) {
			return path.toString();
		}
		return getRequestContext(GHttpContextHolder.getContext().getWebRequest().getNativeRequest());
	}

	/**
	 * CSRFの「HttpOnly」を取得します. <br/>
	 * 「HttpOnly」は渡されるコンフィグレーションから取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return コンフィグレーションからの「HttpOnly」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public boolean getHttpOnly() {
		Object httpOnly = configuration.get(GCookieRepositoryConfigurationKeys.HTTP_ONLY.getValue());
		if (Objects.nonNull(httpOnly)) {
			return (boolean) httpOnly;
		}
		return false;
	}

	/**
	 * CSRFの「SameSite」を取得します. <br/>
	 * 「SameSite」は渡されるコンフィグレーションから取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return コンフィグレーションからの「SameSite」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public GResponseCookie.SameSite getSameSite() {
		return (GResponseCookie.SameSite) configuration.get(GCookieRepositoryConfigurationKeys.SAME_SITE.getValue());
	}

	/**
	 * CSRFの「Secure」を取得します. <br/>
	 * 「Secure」は渡されるコンフィグレーションから取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @return コンフィグレーションからの「secure」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public boolean getSecure() {
		Object secure = configuration.get(GCookieRepositoryConfigurationKeys.SECURE.getValue());
		if (Objects.nonNull(secure)) {
			return (boolean) secure;
		}
		return false;
	}
	
	/**
	 * リクエストコンテキストの取得します. <br/>
	 * nullの場合はrootパース(「/」)を返します. <br/>
	 *
	 * @create 2023/10/25
	 * @param httpServletRequest リクエスト
	 * @return リクエストのコンテキストパース
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	protected String getRequestContext(HttpServletRequest httpServletRequest) {
		String contextPath = httpServletRequest.getContextPath();
		if (Objects.isNull(contextPath) || contextPath.isEmpty() || contextPath.isBlank()) {
			return "/";
		}
		return contextPath;
	}

	/**
	 * CSRF為のクッキーをビルドします. <br/>
	 *
	 * @create 2023/10/25
	 * @param cookieValue 作成されたCSRFトークン
	 * @return {@link GResponseCookie}CSRFトークンのクッキー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	protected GResponseCookie buildCookie(String cookieValue) {
		GResponseCookie responseCookie = GResponseCookie.builder()
			.cookieKey(cookieKey)
			.cookieValue(cookieValue)
			.domain(getDomain())
			.path(getPath())
			.sameSite(getSameSite())
			.httpOnly(getHttpOnly())
			.secure(getSecure())
			.maxAge(this.maxAge)
			.build();
		return responseCookie;
	}

	/**
	 * リクエストのクッキーからCSRFトークンを取得します. <br/>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @param name クッキーのキー名
	 * @return 取得されたクッキー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private Cookie getCsrfCookie(GWebRequest webRequest, String name) {
		Cookie[] cookies = ((HttpServletRequest) webRequest.getNativeRequest()).getCookies();
		if (Objects.nonNull(cookies)) {
			for (Cookie cookie : cookies) {
				if (name.equals(cookie.getName())) {
					return cookie;
				}
			}
		}
		return null;
	}
}
