/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.csrf;

/**
 * CSRF Cookieの各種属性キーを定義します.<br/>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public enum GCookieRepositoryConfigurationKeys {

	/** Path属性. **/
	PATH("path"),

	/** Domain属性. **/
	DOMAIN("domain"),


	/** HTTP Only属性. **/
	HTTP_ONLY("httpOnly"),

	/** Secure属性. **/
	SECURE("secure"),

	/** SameSite属性. **/
	SAME_SITE("sameSite");

	private String value;

	GCookieRepositoryConfigurationKeys(String value) {
		this.value = value;
	}

	/**
	 * 値を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getValue() {
		return value;
	}
}
