/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.csrf;

import java.util.Map;
import java.util.Optional;

import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.token.GToken;
import jp.co.kccs.greenearth.framework.web.security.token.GTokenGenerator;

/**
 * CsrfTokenを格納するリポジトリのインタフェースです.<br>
 * 
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public interface GCsrfRepository {
	/**
	 * リポジトリから、CsrfTokenを取得します.<br>
	 * @param request リクエスト
	 * @return CSRFトークン
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	Optional<String> getCsrfToken(GWebRequest request);

	/**
	 * CsrfTokenをリポジトリに保存します.<br>
	 *
	 * @param request リクエスト
	 * @param token 保存されたいCSRFトークン
	 * @create 2023/10/25
	 * @author KCSS yangfeng
	 * @since 23.10.0
	 */
	void saveToken(GWebRequest request, GToken token);

	/**
	 * CSRFトークンを生成します。設定される{@link GTokenGenerator}によって、トークンを生成されます.<br>
	 *
	 * @create 2023/10/25
	 * @return 生成されたCSRFトークン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GToken generateToken();

	/**
	 * リクエストに生成されるトークンを添付します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @param token 追加されたいCSRFトークン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void attachToken(GWebRequest webRequest, GToken token);

	/**
	 * トークンを確認します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @param token CSRFトークン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	boolean verifyToken(GWebRequest webRequest, String token);

	/**
	 * CSRFトークンをリクエストから削除します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void release(GWebRequest webRequest);

	/**
	 * トークンキーを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param tokenKey 保管キー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void setTokenKey(String tokenKey);

	/**
	 * トークンキーを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 保管キー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getTokenKey();

	/**
	 * {@link GTokenGenerator}を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param tokenGenerator 設定されたいトークンジェネレーター
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void setTokenGenerator(GTokenGenerator tokenGenerator);

	/**
	 * {@link GTokenGenerator}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GTokenGenerator}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GTokenGenerator getTokenGenerator();

	/**
	 * リクエストヘッダーにあるCSRFトークンのヘッダ項目名のプレフィックスを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param headerPrefix リクエストヘッダーにあるCSRFトークンのヘッダ項目名のプレフィックス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void setHeaderPrefix(String headerPrefix);

	/**
	 * リクエストのヘッダーに付けるCSRFトークンのキーを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return リクエストヘッダーにあるCSRFトークンのヘッダ項目名のプレフィックス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getHeaderPrefix();

	/**
	 * トークンの有効期限を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param maxAge トークンの有効期限
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void setTokenMaxAge(Long maxAge);

	/**
	 * トークンの有効期限を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return トークンの有効期限
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Long getTokenMaxAge();

	/**
	 * {@link GCsrfRepository}のコンフィグレーションを設定します.<br>
	 * コンフィグレーションの項目はルールに設定される値を代表します. <br/>
	 *
	 * @create 2023/10/25
	 * @param configuration レポシトリーのコミュニケーション
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void setConfiguration(Map<String, Object> configuration);

	/**
	 * {@link GCsrfRepository}のコンフィグレーションを取得します.<br>
	 * コンフィグレーションの項目はルールに設定される値を代表します. <br/>
	 *
	 * @create 2023/10/25
	 * @return レポシトリーのコミュニケーション
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Map<String, Object> getConfiguration();
}
