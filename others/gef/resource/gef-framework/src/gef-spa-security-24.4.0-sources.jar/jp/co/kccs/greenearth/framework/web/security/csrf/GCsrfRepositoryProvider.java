/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.csrf;

import java.lang.annotation.Annotation;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * 各モードで優先される{@link GCsrfRepository}を提供するクラスです.<br>
 * 優先順位は{@link jakarta.annotation.Priority}で判断されます。小さい数字の方が優先されます.<br>
 * 
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
public interface GCsrfRepositoryProvider {

	/**
	 * アノテーションで{@link GCsrfRepository}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param annotation
	 * @return {@link GCsrfRepository}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GCsrfRepository> getRepository(Class<? extends Annotation> annotation);

	/**
	 * DIコンテナーから{@link GCsrfRepositoryProvider}を取得します。ライフサイクルと実装オブジェクトはDIと合わせます.<br>
	 *
	 * @create 2023/10/25
	 * @return DIからの {@link GCsrfRepositoryProvider}実装
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static GCsrfRepositoryProvider getInstance() {
		return GFrameworkUtils.getComponent(GCsrfRepositoryProvider.class.getName());
	}
}