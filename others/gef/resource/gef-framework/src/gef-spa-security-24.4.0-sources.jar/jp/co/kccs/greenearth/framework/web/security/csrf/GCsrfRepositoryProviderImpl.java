/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.csrf;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.CookieRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.SessionRepository;
import lombok.NoArgsConstructor;

/**
 * {@link GCsrfRepository}の実装クラスです.<br/>
 * 
 * @see GCsrfRepositoryProvider
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@NoArgsConstructor
@ScanConfiguration(
	modifiers = {
			@Modifier(isPublic = true)
	},
	scannedAssignableTypes = {GCsrfRepository.class}
)
public class GCsrfRepositoryProviderImpl implements GCsrfRepositoryProvider {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @see GCsrfRepositoryProvider#getRepository(Class)
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public Optional<GCsrfRepository> getRepository(Class<? extends Annotation> annotation) {
		List<GCsrfRepository> csrfRepositories = GScanComponentService.getInstance().getScannedInstances(this.getClass());
		for (GCsrfRepository csrfRepository : csrfRepositories) {
			if (csrfRepository.getClass().isAnnotationPresent(annotation)) {
				return Optional.of(csrfRepository);
			}
		}
		return Optional.empty();
	}

}
