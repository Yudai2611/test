/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.csrf;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GWebRequest;

/**
 * セキュリティルールによって、{@link GCsrfRepositoryResolver}を提供するクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfRepositoryResolver {

	/**
	 * セキュリティルールによって、{@link GCsrfRepository}を返します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return 一致する {@link GCsrfRepository}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GCsrfRepository> resolve(GWebRequest webRequest);

	/**
	 * DIコンテナーから{@link GCsrfRepositoryResolver}を取得します.<br/>
	 * ライフサイクルと実装オブジェクトはDIと合わせます。<br>
	 *
	 * @create 2023/10/25
	 * @return DIからの {@link GCsrfRepositoryResolver}の実装
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static GCsrfRepositoryResolver getInstance() {
		return GFrameworkUtils.getComponent(GCsrfRepositoryResolver.class);
	}
}
