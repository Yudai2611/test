/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.csrf;

import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry;

/**
 * {@link GCsrfRepositoryResolver}の実装クラスです.<br/>
 *
 * @see GCsrfRepositoryResolver
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
*/
public class GCsrfRepositoryResolverImpl implements GCsrfRepositoryResolver {

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfRepositoryResolver#resolve(GWebRequest)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GCsrfRepository> resolve(GWebRequest webRequest) {
		GCsrfRepository repository = matchPattern(webRequest);
		if (Objects.nonNull(repository)) {
			Objects.requireNonNull(repository, GFrameworkMessages.isNotFound(GCsrfRepository.class.getSimpleName()) + "type = " + repository.getClass().getSimpleName());
			return Optional.of(repository);
		}
		return Optional.empty();
	}

	/**
	 * リクエストパータンで、セキュリティルールレジストリに{@link GCsrfRepository}を探しに行きます.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return 一致するレポシトリー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private GCsrfRepository matchPattern(GWebRequest request) {
		Optional<GSecurityRule> securityRule = GSecurityRuleRegistry.Factory.getInstance().lookup(request.getNativeRequest());
		if (securityRule.isPresent() && Objects.nonNull(securityRule.get().getCsrfRule())) {
			return securityRule.get().getCsrfRule().getRepository();
		}
		return null;
	}
}
