/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.csrf;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;

/**
 * {@link GCsrfTokenIssuanceShadowEndpoint}をエンドポイント候補に登録する為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@ResourceConfig
@Priority(GPriority.NORMAL)
public class GCsrfResourceConfigurator extends GAbstractResourceConfigurator {

	/**
	 * {@link GCsrfTokenIssuanceShadowEndpoint}がエンドポイント候補に登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param context
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void configure(GFeatureContext context) {
		context.register(GCsrfTokenIssuanceShadowEndpoint.class);
	}
}
