/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.csrf;

import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HEAD;
import jakarta.ws.rs.OPTIONS;
import jakarta.ws.rs.PATCH;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.framework.web.security.filter.csrf.GRewriteCsrfTokenIssuanceUriFilter;

/**
 * CSRFのトークン発行のダミーエンドポイントです.<br>
 * {@link GRewriteCsrfTokenIssuanceUriFilter}で書き換えたURIはこのエンドポイントに回します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Path("jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfTokenIssuanceShadowEndpoint")
public class GCsrfTokenIssuanceShadowEndpoint {

	/**
	 * GETメソッドのダミーエンドポイントです.<br>
	 *
	 * @create 2023/10/25
	 * @return ダミーレスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@GET
	public Response getMethod() {
		return Response.ok().build();
	}

	/**
	 *　POSTメソッドのダミーエンドポイントです.<br>
	 *
	 * @create 2023/10/25
	 * @return ダミーレスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@POST
	public Response postMethod() {
		return Response.ok().build();
	}

	/**
	 * PUTメソッドのダミーエンドポイントです.<br>
	 *
	 * @create 2023/10/25
	 * @return ダミーレスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@PUT
	public Response putMethod() {
		return Response.ok().build();
	}

	/**
	 * PATCHメソッドのダミーエンドポイントです.<br>
	 *
	 * @create 2023/10/25
	 * @return ダミーレスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@PATCH
	public Response patchMethod() {
		return Response.ok().build();
	}

	/**
	 * HEADメソッドのダミーエンドポイントです.<br>
	 *
	 * @create 2023/10/25
	 * @return ダミーレスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@HEAD
	public Response headMethod() {
		return Response.ok().build();
	}

	/**
	 * OPTIONSメソッドのダミーエンドポイントです.<br>
	 *
	 * @create 2023/10/25
	 * @return ダミーレスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@OPTIONS
	public Response optionsMethod() {
		return Response.ok().build();
	}

	/**
	 * DELETEメソッドのダミーエンドポイントです.<br>
	 *
	 * @create 2023/10/25
	 * @return ダミーレスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@DELETE
	public Response deleteMethod() {
		return Response.ok().build();
	}
}
