/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.csrf;


import static jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords.*;

import java.util.Objects;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.SessionRepository;
import jp.co.kccs.greenearth.framework.web.security.token.GToken;

/**
 * CsrfTokenを格納するHttpSessionリポジトリのクラスです.<br>
 * 
 * @see GAbstractCsrfRepository
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
@SessionRepository
public class GHttpSessionCsrfRepository extends GAbstractCsrfRepository {
	/** CSRFトークンのセッションに保管するのキーです.**/
	private String attributeKey = PARAMETER_NAME_CSRF_TOKEN.key();
	public GHttpSessionCsrfRepository() {
		super();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#getCsrfToken(GWebRequest)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<String> getCsrfToken(GWebRequest webRequest) {
		Optional<GToken> actualTokenOptional = getCsrfTokenInternal(webRequest);
		if (actualTokenOptional.isPresent()) {
			GToken actualToken = actualTokenOptional.get();
			if (actualToken.isValid()) {
				return Optional.of(actualToken.getToken());
			}
		}
		return Optional.empty();
	}

	/**
	 * セッションからCSRFトークンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return セッションからのCSRFトークン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private Optional<GToken> getCsrfTokenInternal(GWebRequest webRequest) {
		HttpSession session = ((HttpServletRequest) webRequest.getNativeRequest()).getSession(false);
		if (Objects.isNull(session)) {
			return Optional.empty();
		}

		return Optional.ofNullable((GToken) session.getAttribute(attributeKey));
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#saveToken(GWebRequest, GToken) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void saveToken(GWebRequest webRequest, GToken token) {
		if (Objects.isNull(token)) {
			HttpSession session = ((HttpServletRequest) webRequest.getNativeRequest()).getSession(false);
			if (Objects.nonNull(session)) {
				session.removeAttribute(attributeKey);
			}
		} else {
			HttpSession session = ((HttpServletRequest) webRequest.getNativeRequest()).getSession();
			session.setAttribute(attributeKey, token);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#release(GWebRequest) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void release(GWebRequest webRequest) {
		((HttpServletRequest) webRequest.getNativeRequest()).getSession().removeAttribute(attributeKey);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAbstractCsrfRepository#setTokenKey(String) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void setTokenKey(String tokenKey) {
		this.attributeKey = tokenKey;
		this.tokenKey = tokenKey;
	}
}
