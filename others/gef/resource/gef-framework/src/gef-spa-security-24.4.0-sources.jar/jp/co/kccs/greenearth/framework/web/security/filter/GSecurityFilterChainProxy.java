/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.filter;

import java.io.IOException;
import java.util.Objects;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.core.Context;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.GWebResponse;
import jp.co.kccs.greenearth.framework.web.filter.GFilterChainController;
import jp.co.kccs.greenearth.framework.web.filter.GFilterChainControllerImpl;
import jp.co.kccs.greenearth.framework.web.filter.GFilterChainProxy;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfiguration;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfigurationBuilder;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainProxyConfigurator;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.internal.GContainerResponse;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import lombok.SneakyThrows;

/**
 * セキュリティー向けのフィルターを実行するのフィルタープロキシです.<br>
 * {@link GFilterChainProxy}のように扱い方は同じです.<br>
 * 上記はこのクラスを登録方法です.<br>
 * 1. web.xmlのinit-paramに追加します.<br>
 * <init-param>
 * 		<param-name>filters</param-name>
 * 		<param-value>
 * 			jp.co.kccs.greenearth.framework.web.security.filter.GSecurityFilterChainProxy
 * 		</param-value>
 * </init-param>
 * web.xmlにも、フィルターの実行順番を管理出来ます.下記のようなinit-param入れければ、フィルターの{@link Priority}を気にするかどうかの動きになります.「true」は気にする、「false」は気にしない.<br>
 * <init-param>
 * 		<param-name>priority-order</param-name>
 * 		<param-value>
 * 			true
 * 		</param-value>
 * </init-param>
 *　2. {@link GFilterChainProxyConfigurator}のチェインニ登録します.<br>
 *
 * @see jp.co.kccs.greenearth.framework.web.filter.GFilterChainProxy
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
public class GSecurityFilterChainProxy implements GFilterChainProxy {

	/** {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録される{@link HttpServletRequest}です. **/
	@Context
	private HttpServletRequest httpServletRequest;
	/** {@link org.glassfish.jersey.internal.inject.InjectionManager}に登録される{@link HttpServletResponse}です. **/
	@Context
	private HttpServletResponse httpServletResponse;
	/** サーバレット名と一致する{@link jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainConfigurator}から作られた{@link GFilterChainConfiguration}です. **/
	private GFilterChainConfiguration filterConfiguration;
	/** このフィルターチェーンのコントローラーです. **/
	private GFilterChainController filterChainController;

	public GSecurityFilterChainProxy() {

	}

	/**
	 * セキュリティーフィルターチェーンのリクエストを実行します.<br>
	 *
	 * @create 2023/10/25
	 * @param requestContext リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@SneakyThrows
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		GSecurityContextHolder.init();
		initializeFilterStage();
		requestContext.setSecurityContext(GSecurityContextHolder.getContext());
		filterChainController.applyRequest(GHttpContextHolder.getContext().getWebRequest());
	}

	/**
	 * セキュリティーフィルターチェーンのレスポンスを実行します.<br>
	 *
	 * @create 2023/10/25
	 * @param requestContext リクエスト
	 * @param responseContext レスポンス
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@SneakyThrows
	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
		if (Objects.isNull(GSecurityContextHolder.getContext())) {
			GSecurityContextHolder.init();
		}
		initializeFilterStage();
		GWebResponse webResponse =  new GContainerResponse(GHttpContextHolder.getContext().getWebRequest(), responseContext);
		filterChainController.applyResponse(GHttpContextHolder.getContext().getWebRequest(), webResponse);
		if (Objects.nonNull(GSecurityContextHolder.getContext())) {
			GSecurityContextHolder.release();
		}
	}

	/**
	 * {@link GFilterChainController}を作成する.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	protected void initializeFilterStage() {
		if (Objects.isNull(filterConfiguration)) {
			GWebRequest webRequest = GHttpContextHolder.getContext().getWebRequest();
			this.filterConfiguration = buildConfiguration(webRequest);
			Objects.requireNonNull(filterConfiguration, GFrameworkMessages.mustBeRequired(GFilterChainConfiguration.class.getSimpleName()));
			this.filterChainController = new GFilterChainControllerImpl(filterConfiguration);
		}
	}

	/**
	 * {@link GFilterChainConfiguration}を作成する.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return リクエストのサーバレット名と一致する {@link GFilterChainConfiguration}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	protected GFilterChainConfiguration buildConfiguration(GWebRequest webRequest) {
		final String servletName = getCurrentServletName(webRequest);
		GFilterChainProxyConfigurator configurator = GSecurityFilterChainProxyConfiguratorProvider.getInstance()
													.getProvider(servletName)
													.orElseThrow(GContainerException::new);
		GFilterChainConfigurationBuilder builder = GFilterChainConfiguration.builder(servletName);
		configurator
			.getDefaultFilterChain()
			.forEach(builder.filters()::chain);
		builder.priorityOrder(configurator.isDefaultPriorityOrder());
		return configurator.configure(builder);
	}

	/**
	 * {@link HttpServletRequest}のサーバレット名です.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return リクエストのサーバレット名
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private String getCurrentServletName(GWebRequest webRequest) {
		Objects.requireNonNull(webRequest.getNativeRequest(), GFrameworkMessages.mustBeRequired(HttpServletRequest.class.getSimpleName()));
		return ((HttpServletRequest) webRequest.getNativeRequest()).getHttpServletMapping().getServletName();
	}
}
