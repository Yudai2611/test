/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.filter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainProxyConfigurator;
import jp.co.kccs.greenearth.framework.web.security.filter.annotation.SecurityFilterChainProxyConfigurator;

/**
 * {@link GSecurityFilterChainProxy}為のコンフィグレーターです.<br>
 * 動き方は{@link GFilterChainProxyConfigurator}と同じです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityFilterChainProxyConfigurator extends GFilterChainProxyConfigurator {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @return 関連付けられたサーブレット名のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	default List<String> getAssociatedServletNames() {
		SecurityFilterChainProxyConfigurator annotation = getClass().getAnnotation(SecurityFilterChainProxyConfigurator.class);
		return Objects.nonNull(annotation) ? Arrays.asList(annotation.servletNames()) : Collections.emptyList();
	}
}
