/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.filter;


import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.filter.GFilterChainProxyConfiguratorProvider;

/**
 * サーバレット名によって、{@link GSecurityFilterChainProxyConfigurator}を提供するクラスです.<br>
 *
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
public interface GSecurityFilterChainProxyConfiguratorProvider extends GFilterChainProxyConfiguratorProvider {

	/**
	 * DIコンテナーから{@link GFilterChainProxyConfiguratorProvider}を取得します.ライフサイクルと実装オブジェクトはDIと合わせます.<br>
	 *
	 * @create 2023/10/25
	 * @return DIからの {@link GFilterChainProxyConfiguratorProvider}の実装
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static GFilterChainProxyConfiguratorProvider getInstance() {
		return GFrameworkUtils.getComponent(GSecurityFilterChainProxyConfiguratorProvider.class.getName());
	}
}
