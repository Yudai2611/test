/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.filter;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GFilterChainProxyConfigurator;
import jp.co.kccs.greenearth.framework.web.security.filter.annotation.SecurityFilterChainProxyConfigurator;

/**
 * 
 * @see GSecurityFilterChainProxyConfiguratorProvider
 */
@ScanConfiguration(
	modifiers = {
			@Modifier(isPublic = true)
	},
	scannedAnnotations = SecurityFilterChainProxyConfigurator.class,
	scannedAssignableTypes = GSecurityFilterChainProxyConfigurator.class)
public class GSecurityFilterChainProxyConfiguratorProviderImpl implements GSecurityFilterChainProxyConfiguratorProvider {

	/** サーバレット名と{@link GFilterChainProxyConfigurator}のペアーです. **/
	private Map<String, GFilterChainProxyConfigurator> configurators = null;

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityFilterChainProxyConfiguratorProvider#getProvider(String)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GFilterChainProxyConfigurator> getProvider(String servletName) {
		GFilterChainProxyConfigurator chainProxyConfigurator = getConfigurators().get(servletName);
		if (Objects.isNull(chainProxyConfigurator)) {
			return Optional.of(getConfigurators().get(GFilterChainProxyConfigurator.Default.class.getName()));
		}
		return Optional.ofNullable(chainProxyConfigurator);
	}

	/**
	 * 全{@link GSecurityFilterChainProxyConfigurator}の実装{@link SecurityFilterChainProxyConfigurator}を付けるクラスを取得します.<br>
	 * 取得方針はキャシューをチェックして、なかったら{@link GSecurityFilterChainProxyConfiguratorProviderImpl#loadConfigurators}でスキャンします、スキャン結果はキャシューに保管します.<br>
	 *
	 * @create 2023/10/25
	 * @return サーバレット名と {@link GFilterChainProxyConfigurator}のペアーマップ
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	protected synchronized Map<String, GFilterChainProxyConfigurator> getConfigurators() {
		if (Objects.isNull(configurators)) {
			configurators = new ConcurrentHashMap<>();
			loadConfigurators();
		}
		Objects.requireNonNull(configurators, GFrameworkMessages.mustBeRequired(GFilterChainProxyConfigurator.class.getSimpleName()));
		return configurators;
	}

	/**
	 * 全{@link GSecurityFilterChainProxyConfigurator}の実装{@link SecurityFilterChainProxyConfigurator}を付けるクラスをスキャンして、サーバレット名にマッピングします.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	protected void loadConfigurators() {
		List<GFilterChainProxyConfigurator> instances = GScanComponentService.getInstance().getScannedInstances(getClass());
		for (GFilterChainProxyConfigurator configurator : instances) {
			for (String servletName : configurator.getAssociatedServletNames()) {
				if (getConfigurators().containsKey(servletName)) {
					continue;
				}
				configurators.put(servletName, configurator);
			}
		}
	}
}
