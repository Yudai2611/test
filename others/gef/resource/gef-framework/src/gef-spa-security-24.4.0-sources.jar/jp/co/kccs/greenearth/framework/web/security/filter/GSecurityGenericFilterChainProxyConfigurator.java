/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.filter;

import java.util.Arrays;
import java.util.List;

import jakarta.annotation.Priority;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.web.filter.configuration.GDefaultFilterChainProxyConfigurator;
import jp.co.kccs.greenearth.framework.web.filter.configuration.annotation.FilterChainProxyConfigurator;
import lombok.NoArgsConstructor;

/**
 * 「gef-security-spa」モジュールはアプリに入れる場合、このクラスは自動的に{@link jp.co.kccs.greenearth.framework.web.filter.GFilterChainProxyConfiguratorProvider}でスキャンされて、{@link GSecurityFilterChainProxy}をアプリに入れることです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@FilterChainProxyConfigurator
@Priority(GPriority.NORMAL - 1)
@NoArgsConstructor
public class GSecurityGenericFilterChainProxyConfigurator extends GDefaultFilterChainProxyConfigurator {

	/**
	 * {@inheritDoc}
	 * 
	 * @create 2023/10/25
	 * @return 
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<Class<?>> getDefaultFilterChain() {
		List<Class<?>> chain = super.getDefaultFilterChain();
		chain.addAll(
			Arrays.asList(
				GSecurityFilterChainProxy.class
			)
		);
		return chain;
	}

}
