/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.filter.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link jp.co.kccs.greenearth.framework.web.security.filter.GSecurityFilterChainProxy}を使う時に、フィルターのチェインを管理したい場合、{@link jp.co.kccs.greenearth.framework.web.security.filter.GSecurityFilterChainProxyConfigurator}を作って、クラスレベルにこのアノテーションを付けることです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface SecurityFilterChainProxyConfigurator {

	/**
	 * 関連付けられたサーブレット名を指定します. <br/>
	 * 
	 * @create 2023/10/25
	 * @return サーバレット名の排列
	 * @author yamashita
	 * @since 23.10.0
	 */
	String[] servletNames() default "";
}
