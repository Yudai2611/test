/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.filter.auth;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;

import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.GNotAuthorizedException;
import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.matcher.GRuleMatcher;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry;

/**
 * 認証を処理するのフィルターです.<br>
 * 
 * @create 2023/10/25
 * @author yamashita
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL)
public class GAuthenticationFilter implements ContainerRequestFilter {

	/**
	 * 一致されるルールで認証情報を処理すること.<br>
	 *
	 * @create 2023/10/25
	 * @param containerRequestContext リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void filter(ContainerRequestContext containerRequestContext) throws IOException {
		if (containerRequestContext instanceof GWebRequest) {
			GWebRequest webRequest = (GWebRequest) containerRequestContext;
			Optional<GSecurityRule.GAuthenticationRule> rule = GSecurityRuleRegistry.Factory.getInstance().lookupAuthentication(webRequest.getNativeRequest());
			if (rule.isPresent()) {
				rule = GRuleMatcher.Provider.getMatcherOf(GSecurityRule.GAuthenticationRule.class).match(webRequest.getNativeRequest(), rule.get());
			}
			if (rule.isEmpty()) {
				return;
			}
			authInternal(rule, (GWebRequest) containerRequestContext);
		} else {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GWebRequest.class));
		}
	}

	/**
	 * 認証情報を処理します.<br>
	 *
	 * @create 2023/10/25
	 * @param rule 認証ルール
	 * @param webRequest リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private void authInternal(Optional<GSecurityRule.GAuthenticationRule> rule, GWebRequest webRequest) {
		List<Class<? extends GAuthenticationProcessor>> processors = rule.get().getProcessors();
		for (Class<? extends GAuthenticationProcessor> processor: processors) {
			GAuthenticationProcessor authenticationProcessor = createProcessor(processor);
			if (Objects.nonNull(authenticationProcessor)) {
				Optional<GSubject> subject = authenticationProcessor.process(webRequest.getNativeRequest(), webRequest.getNativeResponse());
				checkIfEmpty(subject);
			}
		}
	}

	/**
	 * {@link GAuthenticationProcessor}のクラス型からオブジェクトに作成します.<br>
	 *
	 * @create 2023/10/25
	 * @param processor {@link GAuthenticationProcessor}の実装クラス
	 * @return {@link GAuthenticationProcessor}のオブジェクト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private GAuthenticationProcessor createProcessor(Class<? extends GAuthenticationProcessor> processor) {
		Optional<GAuthenticationProcessor> authenticationProcessorOptional = GObjectInstantiator.getInstance().newInstance(processor);
		if (authenticationProcessorOptional.isPresent()) {
			return authenticationProcessorOptional.get();
		}
		return null;
	}

	/**
	 * {@link GSubject}は空かどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param subject 検証したいサブジェクト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private void checkIfEmpty(Optional<GSubject> subject) {
		if (subject
			.isEmpty()
			|| !subject
			.get()
			.isAuthenticated()) {
			throw new GNotAuthorizedException(GFrameworkMessages.authenticationFailedDueTo("invalid credential"));
		}
	}
}