/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.filter.cors;

import java.io.IOException;
import java.util.Objects;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.Response;

import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.cors.GCorsProcessor;
import jp.co.kccs.greenearth.framework.web.security.cors.GCorsProcessorImpl;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;
import jp.co.kccs.greenearth.framework.web.security.rule.matcher.GRuleMatcher;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry;
import jp.co.kccs.greenearth.framework.web.filter.context.GFilterChainContextHolder;

/**
 * GCorsFilterの実装クラスです.<br>
 * CorsConfiguration情報により、CrossOriginのリクエストを許可・却下します.<br>
 * 
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL - 200)
public class GCorsFilter implements ContainerRequestFilter {

	/** {@link GCorsProcessor}のオブジェクトを保管します. **/
	private final GCorsProcessor processor = new GCorsProcessorImpl();

	/**
	 * 一致されるセキュリティールールでCORSを処理します.<br>
	 *
	 * @create 2023/10/25
	 * @param containerRequestContext リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void filter(ContainerRequestContext containerRequestContext) throws IOException {
		if (containerRequestContext instanceof GWebRequest) {
			GWebRequest webRequest = (GWebRequest) containerRequestContext;
			Optional<GSecurityRule.GCorsRule> rule = GSecurityRuleRegistry.Factory.getInstance().lookupCors(webRequest.getNativeRequest());
			if (rule.isPresent()) {
				rule = GRuleMatcher.Provider.getMatcherOf(GSecurityRule.GCorsRule.class).match(webRequest.getNativeRequest(), rule.get());
			}
			if (rule.isEmpty()) {
				return;
			}
			processCors(rule, webRequest);
		} else {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GWebRequest.class));
		}
	}

	/**
	 * CORSルールで{@link GWebRequest}が許可されるかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param rule CORSルール
	 * @param webRequest リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private void processCors(Optional<GSecurityRule.GCorsRule> rule, GWebRequest webRequest) {
		GCorsConfiguration configuration = rule.get().getCorsConfigurations().get(0).getCorsConfiguration();
		if (Objects.nonNull(configuration)) {
			Optional<Response> result = processor.verifyProcess(webRequest.getNativeRequest(), webRequest.getNativeResponse(), configuration);
			result.ifPresent((response -> GFilterChainContextHolder.getContext().abortWith(response)));
		}
	}
}
