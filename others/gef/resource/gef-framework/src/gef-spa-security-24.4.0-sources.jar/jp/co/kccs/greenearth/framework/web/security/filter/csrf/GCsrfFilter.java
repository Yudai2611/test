/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.filter.csrf;


import java.io.IOException;
import java.util.Optional;

import jakarta.annotation.Priority;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.filter.context.GFilterChainContextHolder;
import jp.co.kccs.greenearth.framework.web.security.token.GToken;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepositoryResolver;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.matcher.GCsrfRuleMatcher;
import jp.co.kccs.greenearth.framework.web.security.rule.matcher.GRuleMatcher;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry;

import static jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords.HEADER_NAME_CSRF_TOKEN;

/**
 * GCsrfFilterの実装クラスです.<br>
 *
 * CsrfRepositoryにあるcsrfTokenを判断し、リクエストを通過するか・しないかを行います.<br>
 * 　csrfTokenがある場合、通過します.<br>
 * 　csrfTokenがない場合、(仮){@link ForbiddenException}発生します.<br>
 *
 * 初期登録 や GCorsFilterに許可される　のリクエストは、リポジトリにcsrfTokenがありません.<br>
 * これらのリクエストを通過するため、CsrfExcludeMatcherの実装クラスは、matcherListに入れます。.<br>
 * 　CsrfExcludeMatcherDefaultImpl<br>
 * 　CsrfExcludeCorsMatcher<br>
 * 
 * @create 2023/10/25
 * @author KCSS yangfeng
 * @since 23.10.0
 */
@Priority(GPriority.NORMAL - 100)
public class GCsrfFilter implements ContainerRequestFilter {

	/**
	 * 一致されるセキュリティールールで、CSRFを処理します.<br>
	 *
	 * @create 2023/10/25
	 * @param containerRequestContext リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void filter(ContainerRequestContext containerRequestContext) throws IOException {
		if (containerRequestContext instanceof GWebRequest) {
			GWebRequest webRequest = (GWebRequest) containerRequestContext;
			Optional<GCsrfRepository> repository = getRepository(webRequest);
			if (repository.isEmpty()) {
				return;
			}
			if (isMatchTokenIssuancePattern(webRequest.getNativeRequest())) {
				doTokenIssuance(repository.get(), webRequest);
			} else if (isMatchFilterPattern(webRequest.getNativeRequest())) {
				doVerifyToken(repository.get(), webRequest);
			}
		} else {
			throw new GContainerException(GFrameworkMessages.notConcreteClassOfRequest(GWebRequest.class));
		}
	}

	/**
	 * トークンを生成します.<br>
	 * 生成されたら、「isTokenIssuanceHeaderDisabled」フラグは「true」の場合、レスポンスのヘッダーに追加されない。「false」の場合、レスポンスのヘッダーに追加します.<br>
	 *
	 * @create 2023/10/25
	 * @param repository リクエストと一致するCSRFレポシトリー
	 * @param webRequest リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private void doTokenIssuance(GCsrfRepository repository, GWebRequest webRequest) {
		GToken token = repository.generateToken();
		repository.saveToken(webRequest, token);
		GSecurityRule.GCsrfRule csrfRule = getTokenIssuanceMatchedPatternRule(webRequest.getNativeRequest()).get();
		if (!csrfRule.isTokenIssuanceHeaderDisabled()) {
			repository.attachToken(webRequest, token);
		}
		GFilterChainContextHolder.getContext().abortWith(Response.ok().build());
	}

	/**
	 * リクエストヘッダーにあるCSRFトークンは本物のトークンと同じかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param repository リクエストと一致するCSRFレポシトリー
	 * @param webRequest リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private void doVerifyToken(GCsrfRepository repository, GWebRequest webRequest) {
		String actualToken = ((HttpServletRequest) webRequest.getNativeRequest()).getHeader(HEADER_NAME_CSRF_TOKEN.key());
		if (!repository.verifyToken(webRequest, actualToken)) {
			throw new ForbiddenException(GFrameworkMessages.CSRF_TOKEN_VERIFICATION_IS_FAILED.message());
		}
	}

	/**
	 * {@link GWebRequest}と一致するCSRFルールで{@link GCsrfRepository}を取ってきます.<br>
	 *
	 * @create 2023/10/25
	 * @param webRequest リクエスト
	 * @return リクエストと一致するCSRFレポシトリー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private Optional<GCsrfRepository> getRepository(GWebRequest webRequest) {
		return GCsrfRepositoryResolver.getInstance().resolve(webRequest);
	}

	/**
	 * CSRFルールでリクエストは許可されるかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return 検証結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private boolean isMatchFilterPattern(HttpServletRequest request) {
		Optional<GSecurityRule> securityRule = GSecurityRuleRegistry.Factory.getInstance().lookup(request);
		if (securityRule.isPresent()) {
			Optional<GSecurityRule.GCsrfRule> rule = GRuleMatcher.Provider.getMatcherOf(GSecurityRule.GCsrfRule.class).match(request, securityRule.get().getCsrfRule());
			return rule.isPresent();
		}
		return false;
	}

	private Optional<GSecurityRule.GCsrfRule> getTokenIssuanceMatchedPatternRule(HttpServletRequest request) {
		return ((GCsrfRuleMatcher) GRuleMatcher.Provider.getMatcherOf(GSecurityRule.GCsrfRule.class)).getTokenIssuanceMatchedPatternRule(request);
	}

	private boolean isMatchTokenIssuancePattern(HttpServletRequest request) {
		return ((GCsrfRuleMatcher) GRuleMatcher.Provider.getMatcherOf(GSecurityRule.GCsrfRule.class)).isMatchTokenIssuancePattern(request);
	}
}
