/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.filter.csrf;

import java.io.IOException;
import java.net.URI;
import java.util.Objects;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.PreMatching;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfTokenIssuanceShadowEndpoint;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.matcher.GCsrfRuleMatcher;
import jp.co.kccs.greenearth.framework.web.security.rule.matcher.GRuleMatcher;

/**
 * {@link GCsrfTokenIssuanceShadowEndpoint}のパースに書き換える為のフィルターです.<br>
 * JAX-RSの仕組み的には{@link GCsrfFilter}の実行順番はエンドポイントのマッチングした後なので、それを乗っ切る為、マッチングする前に{@link GCsrfTokenIssuanceShadowEndpoint}のURIに書き換えないと行けないです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@PreMatching
@Provider
public class GRewriteCsrfTokenIssuanceUriFilter implements ContainerRequestFilter {

	@Context
	HttpServletRequest servletRequest;

	/**
	 * 一致されるトークン発行パータンで、リクエストのURIが{@link GCsrfTokenIssuanceShadowEndpoint}に書き換えること.<br>
	 *
	 * @create 2023/10/25
	 * @param requestContext リクエスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		setIfGWebRequest(requestContext);
		if (Objects.nonNull(servletRequest) && isMatchTokenIssuancePattern(servletRequest)) {
			UriInfo uriInfo = requestContext.getUriInfo();
			URI targetUri = uriInfo.getBaseUri().resolve(GCsrfTokenIssuanceShadowEndpoint.class.getCanonicalName());
			requestContext.setRequestUri(targetUri);
		}
	}

	private void setIfGWebRequest(ContainerRequestContext request) {
		if ((request instanceof GWebRequest)) {
			servletRequest = ((GWebRequest) request).getNativeRequest();
		}
	}

	/**
	 * CSRFルールで「TokenIssuance」パータンは一致するかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return 検証結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private boolean isMatchTokenIssuancePattern(HttpServletRequest request) {
		return ((GCsrfRuleMatcher) GRuleMatcher.Provider.getMatcherOf(GSecurityRule.GCsrfRule.class)).isMatchTokenIssuancePattern(request);
	}
}
