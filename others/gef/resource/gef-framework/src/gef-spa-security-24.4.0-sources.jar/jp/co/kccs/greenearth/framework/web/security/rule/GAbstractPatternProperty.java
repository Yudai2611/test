/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule;

import java.util.List;

/**
 *
 * @see GPatternProperty
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public abstract class GAbstractPatternProperty implements GPatternProperty {
	protected List<GPatternProperty.Pattern> patterns;
	protected List<GPatternProperty.Pattern> excludePatterns;

	protected GAbstractPatternProperty(List<GPatternProperty.Pattern> patterns, List<GPatternProperty.Pattern> excludePatterns) {
		this.patterns = patterns;
		this.excludePatterns = excludePatterns;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<GPatternProperty.Pattern> getPatterns() {
		return patterns;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GPatternProperty#getExcludePatterns()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<GPatternProperty.Pattern> getExcludePatterns() {
		return excludePatterns;
	}
}
