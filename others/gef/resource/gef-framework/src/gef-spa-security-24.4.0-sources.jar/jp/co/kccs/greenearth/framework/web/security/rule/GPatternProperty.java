/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule;

import java.util.List;

/**
 * 許可されるパータンと除外されるパータンリスト情報を持ってるクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GPatternProperty {

	/**
	 * 許可されるパータンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 許可されるパータン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<Pattern> getPatterns();

	/**
	 * 除外されるパータンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 除外されるパータン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<Pattern> getExcludePatterns();


	/**
	 * セキュリティールールパータンのマーカーインタフェースです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface Pattern {
	}

	/**
	 * セキュリティールールのパータンはURI系の場合、このインタフェースで表現されます.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface PatternUri extends Pattern {

		/**
		 * URIを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return URI
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		String getUri();
	}

	/**
	 * セキュリティールールのパータンは「GEF」のアクションビーンとメソッド系の場合、このインタフェースで表現されます.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface PatternActionBean extends Pattern {

		/**
		 * アクションビーンを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return アクションビーン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		String getActionBean();

		/**
		 * アクションメソッドリストを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return アクションメソッドのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<String> getActionMethods();
	}
}
