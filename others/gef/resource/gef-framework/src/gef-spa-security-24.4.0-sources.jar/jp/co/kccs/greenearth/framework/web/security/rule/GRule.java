/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule;

/**
 * セキュリティールールのマーカーです.<br>
 * フレームワーク用意されるルールは{@link GSecurityRule}, {@link GSecurityRule.GAuthenticationRule}, {@link GSecurityRule.GCsrfRule}, {@link GSecurityRule.GCorsRule}です.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GRule {

}
