/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule;

import java.util.List;

import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;

/**
 * セキュリティールールを代表するのクラスです.<br>
 * 「YAML」と「JAVA」モードで生成されるクラスはこのオブジェクトに変換して、{@link jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry}に保管します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityRule extends GRule, GPatternProperty {

	/**
	 * CORSルールを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsRule getCorsRule();

	/**
	 * CSRFルールを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CSRFルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfRule getCsrfRule();

	/**
	 * 認証ルールを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 認証ルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GAuthenticationRule getAuthenticationRule();

	/**
	 *　{@link GSubjectHolder}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GSubjectHolder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GSubjectHolder getContextHolder();

	/**
	 * 認証ルールを代表するのクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface GAuthenticationRule extends GRule, GPatternProperty {

		/**
		 * セキュリティールールに定義された{@link GAuthenticationProcessor}のリストを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return {@link GAuthenticationProcessor}のリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<Class<? extends GAuthenticationProcessor>> getProcessors();
	}

	/**
	 * CORSルールのグループを代表するのクラスです.<br>
	 * 各グループに{@link GCorsConfiguration}は許可されるパータンと除外されるパータンを持っています.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface GCorsRule extends GRule {

		/**
		 * CORSグループのリストを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return CORSグループのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<GCorsConfigurationRule> getCorsConfigurations();
	}

	/**
	 * CORSルールの単位を代表するのクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface GCorsConfigurationRule extends GPatternProperty {

		/**
		 * CORSルールの単位を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return CORSルールの単位
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		GCorsConfiguration getCorsConfiguration();
	}

	/**
	 * CSRFルールを代表するのクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface GCsrfRule extends GRule, GPatternProperty {

		/**
		 * {@link GCsrfRepository}を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return {@link GCsrfRepository}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		GCsrfRepository getRepository();

		/**
		 * 定義された「tokenIssuancePattern」を取得します.「tokenIssuancePattern」はCSRFトークンを生成する為のエンドポイントパータンです.<br>
		 * 用意されるパータンは{@link GPatternProperty.Pattern}と同じです.<br>
		 *
		 * @create 2023/10/25
		 * @return 「TokenIssuance」の許可されるパータンのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<GPatternProperty.Pattern> getTokenIssuancePatterns();

		/**
		 * CSRFを処理する時に無職される「HttpMethod」を取得します.無職されたら、リクエストはCSRFの対象にならず、次のフィルターに行きます.<br>
		 *
		 * @create 2023/10/25
		 * @return 無職される「HttpMethod」のリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<GHttpMethod> getIgnoreHttpMethods();

		/**
		 * 基本は{@link GCsrfRule#getTokenIssuancePatterns()}に定義されたパータンに入ったら、レスポンスヘッダーに追加します.追加するかどうかの判断はこのメソッドの結果によるです.<br>
		 * 「true」はレスポンスヘッダーに追加されない.「false」はレスポンスヘッダーに追加します.<br>
		 *
		 * @create 2023/10/25
		 * @return レスポンスヘッダーにCSRFトークンを追加するかどうかのフラグ
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		boolean isTokenIssuanceHeaderDisabled();
	}

}
