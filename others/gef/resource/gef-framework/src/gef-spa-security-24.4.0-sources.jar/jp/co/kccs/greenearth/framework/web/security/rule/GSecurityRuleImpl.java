/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule;

import java.util.List;

import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GCorsConfigurationRegistry;

/**
 *
 * @see GSecurityRule
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityRuleImpl extends GAbstractPatternProperty implements GSecurityRule {
	private final GSecurityRule.GCorsRule corsRule;
	private final GSecurityRule.GCsrfRule csrfRule;
	private final GSecurityRule.GAuthenticationRule authenticationRule;
	private final GSubjectHolder contextHolder;

	public GSecurityRuleImpl(List<GPatternProperty.Pattern> patterns, List<GPatternProperty.Pattern> excludePatterns, GSecurityRule.GCorsRule corsRule, GSecurityRule.GCsrfRule csrfRule, GSecurityRule.GAuthenticationRule authenticationRule, GSubjectHolder contextHolder) {
		super(patterns, excludePatterns);
		this.corsRule = corsRule;
		this.csrfRule = csrfRule;
		this.authenticationRule = authenticationRule;
		this.contextHolder = contextHolder;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule#getCorsRule()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GSecurityRule.GCorsRule getCorsRule() {
		return corsRule;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule#getCsrfRule()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GSecurityRule.GCsrfRule getCsrfRule() {
		return csrfRule;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule#getAuthenticationRule()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GSecurityRule.GAuthenticationRule getAuthenticationRule() {
		return authenticationRule;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule#getContextHolder()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GSubjectHolder getContextHolder() {
		return contextHolder;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule.GAuthenticationRule
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class GAuthenticationRule extends GAbstractPatternProperty implements GSecurityRule.GAuthenticationRule {
		private final List<Class<? extends GAuthenticationProcessor>> processors;

		public GAuthenticationRule(List<Class<? extends GAuthenticationProcessor>> processors, List<GSecurityRule.Pattern> patterns, List<GSecurityRule.Pattern> excludePatterns) {
			super(patterns, excludePatterns);
			this.processors = processors;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRule.GAuthenticationRule#getProcessors()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public List<Class<? extends GAuthenticationProcessor>> getProcessors() {
			return processors;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule.GCorsRule
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class GCorsRule implements GSecurityRule.GCorsRule {
		private final List<GSecurityRule.GCorsConfigurationRule> corsConfigurationRules;

		public GCorsRule(List<GSecurityRule.GCorsConfigurationRule> corsConfigurationRules) {
			this.corsConfigurationRules = corsConfigurationRules;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRule.GCorsRule#getCorsConfigurations
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public List<GSecurityRule.GCorsConfigurationRule> getCorsConfigurations() {
			return corsConfigurationRules;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule.GCorsConfigurationRule
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class GCorsConfigurationRule extends GAbstractPatternProperty implements GSecurityRule.GCorsConfigurationRule {
		private final String corsId;

		public GCorsConfigurationRule(String corsId, List<GSecurityRule.Pattern> patterns, List<GSecurityRule.Pattern> excludePatterns) {
			super(patterns, excludePatterns);
			this.corsId = corsId;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRule.GCorsConfigurationRule#getCorsConfiguration()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsConfiguration getCorsConfiguration() {
			return GCorsConfigurationRegistry.Factory.getInstance().lookup(corsId);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRule.GCsrfRule
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class GCsrfRule extends GAbstractPatternProperty implements GSecurityRule.GCsrfRule {
		private final GCsrfRepository repository;
		private final List<GSecurityRule.Pattern> tokenIssuancePatterns;
		private final List<GHttpMethod> ignoreHttpMethods;
		private final boolean tokenIssuanceHeaderDisableState;

		public GCsrfRule(GCsrfRepository repository, List<GSecurityRule.Pattern> patterns, List<GSecurityRule.Pattern> excludePatterns, List<GSecurityRule.Pattern> tokenIssuancePatterns, List<GHttpMethod> ignoreHttpMethods, boolean tokenIssuanceHeaderDisableState) {
			super(patterns, excludePatterns);
			this.repository = repository;
			this.tokenIssuancePatterns = tokenIssuancePatterns;
			this.ignoreHttpMethods = ignoreHttpMethods;
			this.tokenIssuanceHeaderDisableState = tokenIssuanceHeaderDisableState;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRule.GCsrfRule#getRepository()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCsrfRepository getRepository() {
			return repository;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRule.GCsrfRule#getTokenIssuancePatterns()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public List<GSecurityRule.Pattern> getTokenIssuancePatterns() {
			return tokenIssuancePatterns;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRule.GCsrfRule#getIgnoreHttpMethods()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public List<GHttpMethod> getIgnoreHttpMethods() {
			return ignoreHttpMethods;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRule.GCsrfRule#isTokenIssuanceHeaderDisabled()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public boolean isTokenIssuanceHeaderDisabled() {
			return tokenIssuanceHeaderDisableState;
		}
	}

	/**
	 *
	 * @see GPatternProperty.PatternUri
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class PatternUri implements GPatternProperty.PatternUri {
		private final String uri;
		public PatternUri(String uri) {
			this.uri = uri;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GPatternProperty.PatternUri#getUri()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
		 */
		public String getUri() {
			return uri;
		}
	}

	/**
	 *
	 * @see GPatternProperty.PatternActionBean
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class PatternActionBean implements GPatternProperty.PatternActionBean {
		private final String actionBean;
		private final List<String> actionMethods;
		public PatternActionBean(String actionBean, List<String> actionMethods) {
			this.actionBean = actionBean;
			this.actionMethods = actionMethods;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GPatternProperty.PatternActionBean#getActionBean()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public String getActionBean() {
			return actionBean;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GPatternProperty.PatternActionBean#getActionMethods() 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<String> getActionMethods() {
			return actionMethods;
		}
	}

}
