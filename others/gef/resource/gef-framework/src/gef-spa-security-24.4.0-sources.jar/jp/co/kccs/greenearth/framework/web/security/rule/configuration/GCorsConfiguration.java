/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

import java.util.List;


/**
 * CORSルールの情報を保管するクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCorsConfiguration {
	private final String corsId;
	private final List<String> allowMethods;
	private final List<String> allowHeaders;
	private final boolean allowCredentials;
	private final List<String> allowOrigins;
	private final long maxAge;
	private final List<String> exposeHeaders;

	public GCorsConfiguration(String corsId, List<String> allowMethods, List<String> allowHeaders, boolean allowCredentials,
		List<String> allowOrigins, long maxAge, List<String> exposeHeaders) {
		this.corsId = corsId;
		this.allowMethods = allowMethods;
		this.allowHeaders = allowHeaders;
		this.allowCredentials = allowCredentials;
		this.allowOrigins = allowOrigins;
		this.maxAge = maxAge;
		this.exposeHeaders = exposeHeaders;
	}

	/**
	 * 「Access-Control-Allow-Origin」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return Access-Control-Allow-Origin」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getAllowOrigins() {
		return allowOrigins;
	}

	/**
	 * CORSのIDを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSのID
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getCorsId() {
		return corsId;
	}

	/**
	 * 「Access-Control-Allow-Methods」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 「Access-Control-Allow-Methods」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getAllowMethods() {
		return allowMethods;
	}

	/**
	 * 「Access-Control-Allow-Headers」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 「Access-Control-Allow-Headers」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getAllowHeaders() {
		return allowHeaders;
	}

	/**
	 * 「Access-Control-Allow-Credentials」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 「Access-Control-Allow-Credentials」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public boolean isAllowCredentials() {
		return allowCredentials;
	}

	/**
	 * 「Access-Control-Max-Age」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 「Access-Control-Max-Age」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public long getMaxAge() {
		return maxAge;
	}

	/**
	 * 「Access-Control-Expose-Headers」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 「Access-Control-Expose-Headers」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getExposeHeaders() {
		return exposeHeaders;
	}

}