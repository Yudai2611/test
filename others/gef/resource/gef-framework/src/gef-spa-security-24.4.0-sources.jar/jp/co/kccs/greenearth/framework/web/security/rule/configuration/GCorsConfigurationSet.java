/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

import java.util.List;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsConfigurationBuilder;

/**
 * {@link GCorsConfiguration}をビルドする為に、このインタフェースで登録します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsConfigurationSet {

	/**
	 * CORSルールのリストを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param cors CORSルールのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void addAll(GCorsConfigurationBuilder... cors);

	/**
	 * CORSルールを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param cors CORSルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void add(GCorsConfigurationBuilder cors);

	/**
	 * CORSから{@link GCorsConfiguration}に変換するオブジェクトを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSから{@link GCorsConfiguration}に変換するオブジェクト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<GCorsConfiguration> getCorsConfigurations();

}
