/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsConfigurationBuilder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsConfigurationSetBuilder;

/**
 *
 * @see GCorsConfigurationSet
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCorsConfigurationSetImpl implements GCorsConfigurationSet {
	private List<GCorsConfiguration> corsConfigurations = new ArrayList<>();

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationSet#addAll(GCorsConfigurationBuilder...)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void addAll(GCorsConfigurationBuilder... cors)  {
		corsConfigurations.addAll(Arrays.stream(cors).map(c -> ((GCorsConfigurationSetBuilder.Builder) c).build()).collect(Collectors.toList()));
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationSet#add(GCorsConfigurationBuilder)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void add(GCorsConfigurationBuilder cors) {
		corsConfigurations.add(((GCorsConfigurationSetBuilder.Builder) cors).build());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationSet#getCorsConfigurations()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<GCorsConfiguration> getCorsConfigurations() {
		return corsConfigurations;
	}
}
