/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

/**
 * JAVAモードを使う時に、セキュリティルールはこのクラスに定義します.<br>
 * 「FluentAPI」一覧の中に、複数系項目は複数で定義されたら優先順位通り処理される、シングル系項目は複数で定義されたら例外発生する.
 *
 * (★★の間にある文字は注目になります)
 * 複数系項目:
 * ★★.action()★★
 * ★★.uri()★★
 * ★★.config()★★
 * .action(class, ★★methods★★)
 * シングル系項目:
 * ★★.config().allowedHeaders()★★
 * ★★.config().allowedOrigins()★★
 * ★★.config().allowedMethods()★★
 * ★★.config().exposedHeaders()★★
 * ★★.config().maxAge()★★
 * ★★.config().credentials()★★
 * ★★.authentication()★★
 * ★★.authentication().processor()★★
 * ★★.cors()★★
 * ★★.csrf()★★
 * ★★.csrf().repository().sessionRepository()★★
 * ★★.csrf().repository().cookieRepository()★★
 * ★★.csrf().repository().customRepository()★★
 * ★★.csrf().tokenIssuance()★★
 * ★★.csrf().repository().tokenBehavior().creation().uuid()★★
 * ★★.csrf().repository().tokenBehavior().creation().customGenerator()★★
 * ★★.csrf().repository().tokenBehavior().maxAge()★★
 * ★★.csrf().repository().tokenBehavior().saveTokenKey()★★
 * ★★.csrf().repository().tokenBehavior().headerPrefix()★★
 * ★★.csrf().cookieRepository().secure()★★
 * ★★.csrf().cookieRepository().sameSite()★★
 * ★★.csrf().cookieRepository().httpOnly()★★
 * ★★.csrf().cookieRepository().path()★★
 * ★★.csrf().cookieRepository().domain()★★
 * ★★.csrf().ignoreHttpMethods()★★
 * ★★.contextHolder()★★
 * ★★.contextHolder().session()★★
 * ★★.contextHolder().threadLocal()★★
 *
 * 重要:
 * CORSコンフィグレーションに同じID設定されたら、例外が発生する.
 * SecurityRuleの.cors().config(★★ID★★)に同じID設定されたら、別々のCorsRuleのConfigを生成されます.それから、優先順位通りに処理されます.
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityConfiguration {

    /**
     * CORSルールをこのメソッドに定義します.<br>
     *
     * @create 2023/10/25
     * @param corsSet {@link GCorsConfigurationSet}
     * @author KCCS dhiaz chebastian
     * @since 23.10.0
     */
    void configure(GCorsConfigurationSet corsSet);

    /**
     * セキュリティルールをこのメソッドに定義します.<br>
     *
     * @create 2023/10/25
     * @param ruleGroup {@link GSecurityRuleSet}
     * @author KCCS dhiaz chebastian
     * @since 23.10.0
     */
    void configure(GSecurityRuleSet ruleGroup);
}
