/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;

import java.util.List;

/**
 * セキュリティルールを作る為のクラスです.<br>
 * デフォルトでYAMLとJavaモードを提供します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityConfigurationCreator {

	/**
	 * {@link GSecurityRule}のリストを作ります.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GSecurityRule}のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<GSecurityRule> loadRules();

	/**
	 * {@link GCorsConfiguration}のリストを作ります.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GCorsConfiguration}のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<GCorsConfiguration> loadCors();

	/**
	 * DIコンテナーから{@link GSecurityConfigurationCreator}を取得します.ライフサイクルと実装オブジェクトはDIと合わせます.<br>
	 *
	 * @create 2023/10/25
	 * @return DIからの{@link GSecurityConfigurationCreator}の実装
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static GSecurityConfigurationCreator getInstance() {
		return GFrameworkUtils.getComponent(GSecurityConfigurationCreator.class);
	}
}
