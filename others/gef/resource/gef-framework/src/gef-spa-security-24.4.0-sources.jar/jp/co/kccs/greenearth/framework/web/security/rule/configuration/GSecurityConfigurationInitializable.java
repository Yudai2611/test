/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

import jakarta.annotation.Priority;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;
import jp.co.kccs.greenearth.commons.listener.BootstrapInitializable;
import jp.co.kccs.greenearth.commons.listener.GAbstractBootstrapInitializable;
import jp.co.kccs.greenearth.commons.priority.GPriority;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GCorsConfigurationRegistry;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry;

/**
 * アプリを起動する時にDIに定義される{@link GSecurityConfigurationCreator}の実装で{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule}を作ります.<br>
 *
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@BootstrapInitializable
@Priority(GPriority.NORMAL)
public class GSecurityConfigurationInitializable extends GAbstractBootstrapInitializable {
	private static final Log LOGGER = LogFactory.getLog(GSecurityConfigurationInitializable.class);

	public GSecurityConfigurationInitializable() {
	}

	public GSecurityConfigurationInitializable(GBootstrapConfiguration bootstrapConfiguration) {
		super(bootstrapConfiguration);
	}

	/**
	 * アプリを起動する時に、このメソッドを実行して、{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule}を作ります.作られた結果は{@link GSecurityRuleRegistry}に登録します.<br>
	 *
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void initialize() {
		LOGGER.info(GFrameworkMessages.$s_INIT_STARTED.message(GSecurityConfigurationInitializable.class.getSimpleName()));
		GSecurityConfigurationCreator securityConfigurationLoader = GSecurityConfigurationCreator.getInstance();
		try {
			GCorsConfigurationRegistry.Factory.createInstance(securityConfigurationLoader.loadCors());
			GSecurityRuleRegistry.Factory.createInstance(securityConfigurationLoader.loadRules());
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
			throw exception;
		}
	}
	/**
	 * アプリをシャットダウン時に、{@link GSecurityRuleRegistry}にある{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule}を削除します.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void destroy() {
		LOGGER.info(GFrameworkMessages.$s_DESTROY_STARTED.message(GSecurityConfigurationInitializable.class.getSimpleName()));
		GSecurityRuleRegistry.Factory.clearInstance();
		GCorsConfigurationRegistry.Factory.clearInstance();
	}
}
