/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

import jp.co.kccs.greenearth.framework.web.security.rule.*;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;

import java.util.List;

/**
 * {@link GSecurityRule}をビルドする為に、このインタフェースで登録します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityRuleSet {

	/**
	 * セキュリティルールのリストを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param rules セキュリティルールのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void addAll(GRuleRoute... rules);

	/**
	 * セキュリティルールを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param rule セキュリティルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void add(GRuleRoute rule);

	/**
	 * セキュリティルールから{@link GSecurityRule}に変換するオブジェクトを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GSecurityRule}のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<GSecurityRule> getSecurityRules();

}
