/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.parent.GSecurityRuleSetBuilder;

/**
 *
 * @see GSecurityRuleSet
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityRuleSetImpl implements GSecurityRuleSet {

	private List<GSecurityRule> securityRules = new ArrayList<>();
	public GSecurityRuleSetImpl() {

	}
	public GSecurityRuleSetImpl(List<GSecurityRule> securityRuleSets) {
		this.securityRules = securityRuleSets;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleSet#addAll(GRuleRoute...)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void addAll(GRuleRoute... rules) {
		securityRules.addAll(
			Arrays.stream(rules).map(GSecurityRuleSetBuilder.Rule.class::cast)
				.map(GSecurityRuleSetBuilder.Rule::build).collect(Collectors.toList())
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleSet#add(GRuleRoute)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public void add(GRuleRoute rule) {
		securityRules.add(((GSecurityRuleSetBuilder.Rule) rule).build());
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleSet#getSecurityRules()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<GSecurityRule> getSecurityRules() {
		return securityRules;
	}
}
