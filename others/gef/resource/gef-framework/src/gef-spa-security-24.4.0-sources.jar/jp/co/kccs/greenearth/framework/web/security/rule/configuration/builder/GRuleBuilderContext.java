/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.internal.GFrameworkReservedWords;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.security.context.GHttpSessionSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.GThreadLocalSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.SessionSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.ThreadLocalSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepositoryProvider;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.SessionRepository;
import jp.co.kccs.greenearth.framework.web.security.token.GTokenGenerator;
import jp.co.kccs.greenearth.framework.web.security.token.GUUIDTokenCreator;
import jp.co.kccs.greenearth.framework.web.security.GSecurityPropertyKeys;
import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolderProvider;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.rule.GPatternProperty;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRuleImpl;

/**
 *　セキュリティルールをビルド為のコンテキストです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GRuleBuilderContext {
	/** セキュリティルールの許可されるパータンです. **/
	private List<GSecurityRule.Pattern> patterns = new ArrayList<>();
	/** セキュリティルールの除外されるパータンです. **/
	private List<GSecurityRule.Pattern> excludes = new ArrayList<>();
	/** セキュリティルールのセキュリティコンテキストモードです.**/
	private GSubjectHolder contextHolder;
	/** セキュリティルールの認証ビルダーです.**/
	private AuthenticationBuilder authenticationBuilder;
	/** セキュリティルールのCSRFビルダーです.**/
	private CsrfBuilder csrfBuilder;
	/** セキュリティルールのCORSビルダーです.**/
	private CorsBuilder corsBuilder;

	public GRuleBuilderContext() {

	}

	/**
	 * 許可されるパータンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 許可されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<GSecurityRule.Pattern> getPatterns() {
		return patterns;
	}

	/**
	 * 許可されるパータンを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param patterns 許可されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setPatterns(List<GSecurityRule.Pattern> patterns) {
		removeSimilarActionBean(patterns);
		this.patterns = patterns;
	}

	/**
	 * 除外されるパータンを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 除外されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<GSecurityRule.Pattern> getExcludes() {
		return excludes;
	}

	/**
	 * 除外されるパータンを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param excludes 除外されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setExcludes(List<GSecurityRule.Pattern> excludes) {
		removeSimilarActionBean(excludes);
		this.excludes = excludes;
	}

	/**
	 * セキュリティコンテキストモードを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return セキュリティコンテキストのモード
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public GSubjectHolder getContextHolder() {
		return contextHolder;
	}

	/**
	 * 認証ルールのビルダーを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 認証ルールのビルダー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public AuthenticationBuilder getAuthenticationBuilder() {
		return authenticationBuilder;
	}

	/**
	 * CSRFルールのビルダーを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CSRFルールのビルダー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public CsrfBuilder getCsrfBuilder() {
		return csrfBuilder;
	}

	/**
	 * CORSルールのビルダーを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSルールのビルダー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public CorsBuilder getCorsBuilder() {
		return corsBuilder;
	}

	/**
	 * CORSのビルダーを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param corsBuilder CORSルールのビルダー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setCorsBuilder(
		CorsBuilder corsBuilder) {
		this.corsBuilder = corsBuilder;
	}

	/**
	 * コンテキストに許可されるパータンを追加します.<br>
	 *
	 * @create 2023/10/25
	 * @param pattern 許可されるパータン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void addPattern(GSecurityRule.Pattern pattern) {
		removeSimilarActionBean(pattern, this.patterns);
		this.patterns.add(pattern);
	}

	/**
	 * コンテキストに除外されるパータンを追加します.<br>
	 *
	 * @create 2023/10/25
	 * @param exclude 除外されるパータン
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void addExclude(GSecurityRule.Pattern exclude) {
		removeSimilarActionBean(exclude, this.excludes);
		this.excludes.add(exclude);
	}

	/**
	 * {@link GSubjectHolder}を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param contextHolder セキュリティコンテキストのモード
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setContextHolder(GSubjectHolder contextHolder) {
		this.contextHolder = contextHolder;
	}

	/**
	 * 認証ビルダーを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param authenticationBuilder 認証ルールのビルダー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setAuthenticationBuilder(AuthenticationBuilder authenticationBuilder) {
		this.authenticationBuilder = authenticationBuilder;
	}

	/**
	 * CSRFビルダーを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param csrfBuilder CSRFルールのビルダー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setCsrfBuilder(CsrfBuilder csrfBuilder) {
		this.csrfBuilder = csrfBuilder;
	}

	/**
	 * セキュリティルールをビルドします.<br>
	 *
	 * @create 2023/10/25
	 * @return ビルド結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public GSecurityRule build() {
		return new GSecurityRuleImpl(
			patterns,
			excludes,
			Objects.nonNull(corsBuilder) ? corsBuilder.build() : null,
			Objects.nonNull(csrfBuilder) ? csrfBuilder.build() : null,
			Objects.nonNull(authenticationBuilder) ? authenticationBuilder.build() : null,
			Objects.nonNull(contextHolder) ? contextHolder : getDefault()
		);
	}

	/**
	 * デフォルト{@link GSubjectHolder}を取得します.<br>
	 * {@link GSubjectHolder}はルールに設定されない場合、デフォルトを使います.<br>
	 *
	 * @create 2023/10/25
	 * @return デフォルトセキュリティコンテキストのモード
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private GSubjectHolder getDefault() {
		String securityContext = GFrameworkUtils.getProperty(GSecurityPropertyKeys.GEFRAME_SPA_WEB_SECURITY_CONTEXT_HOLDER_DEFAULT.getKey(), "threadLocal");
		if (securityContext.equalsIgnoreCase("threadLocal")) {
			Optional<GSubjectHolder> subjectHolderOptional = GSubjectHolderProvider.getInstance().getSubjectHolder(ThreadLocalSubjectHolder.class);
			return subjectHolderOptional.orElseGet(GThreadLocalSubjectHolder::new);
		} else if (securityContext.equalsIgnoreCase("session")) {
			Optional<GSubjectHolder> subjectHolderOptional = GSubjectHolderProvider.getInstance().getSubjectHolder(SessionSubjectHolder.class);
			return subjectHolderOptional.orElseGet(GHttpSessionSubjectHolder::new);

		} else {
			throw new GFrameworkException(String.format("%s is not supported.", securityContext));
		}
	}

	/**
	 * 認証ルールをビルドする為のクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class AuthenticationBuilder {
		/** {@link GAuthenticationProcessor}のリストです. **/
		private List<Class<? extends GAuthenticationProcessor>> processors = new ArrayList<>();
		/** 認証ルールの許可されるパータンです.**/
		private List<GSecurityRule.Pattern> patterns = new ArrayList<>();
		/** 認証ルールの除外されるパータンです.**/
		private List<GSecurityRule.Pattern> excludes = new ArrayList<>();

		/**
		 * {@link GAuthenticationProcessor}のリストを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return {@link GAuthenticationProcessor}のリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<Class<? extends GAuthenticationProcessor>> getProcessors() {
			return processors;
		}

		/**
		 * 認証ルールの許可されるパータンを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return 認証ルールの許可されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<GSecurityRule.Pattern> getPatterns() {
			return patterns;
		}

		/**
		 * 認証ルールの許可されるパータンを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param patterns 認証ルールの許可されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setPatterns(List<GSecurityRule.Pattern> patterns) {
			removeSimilarActionBean(patterns);
			this.patterns = patterns;
		}

		/**
		 * 認証ルールの除外されるパータンを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return 認証ルールの除外されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<GSecurityRule.Pattern> getExcludes() {
			return excludes;
		}

		/**
		 * 認証ルールの除外されるパータンを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param excludes 認証ルールの除外されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setExcludes(List<GSecurityRule.Pattern> excludes) {
			removeSimilarActionBean(excludes);
			this.excludes = excludes;
		}

		/**
		 * 認証ルールの許可されるパータンを追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param pattern 認証ルールの許可されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void addPattern(GSecurityRule.Pattern pattern) {
			removeSimilarActionBean(pattern, this.patterns);
			this.patterns.add(pattern);
		}

		/**
		 * {@link GAuthenticationProcessor}を追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param processor {@link GAuthenticationProcessor}
		 * @author KCCS dhiaz chebastian
		 * @since 24.4.0
		 */
		public void addProcessor(Class<? extends GAuthenticationProcessor> processor) {
			processors.add(processor);
		}

		/**
		 * 認証ルールの除外されるパータンを追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param pattern 認証ルールの除外されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void addExclude(GSecurityRule.Pattern pattern) {
			removeSimilarActionBean(pattern, this.excludes);
			this.excludes.add(pattern);
		}

		/**
		 * {@link GAuthenticationProcessor}のリストを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param processors {@link GAuthenticationProcessor}のリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setProcessor(List<Class<? extends GAuthenticationProcessor>> processors) {
			this.processors = processors;
		}

		/**
		 * 認証ルールをビルドします.<br>
		 *
		 * @create 2023/10/25
		 * @return ビルド結果
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public GSecurityRule.GAuthenticationRule build() {
			if (processors.size() == 0) {
				throw new GFrameworkException(GFrameworkMessages.mustBeRequired(GAuthenticationProcessor.class.getName()));
			}
			return new GSecurityRuleImpl.GAuthenticationRule(
				this.processors,
				this.patterns,
				this.excludes
			);
		}
	}

	/**
	 * CSRFルールをビルドする為のクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class CsrfBuilder {
		/** CSRFルールのレポシトリーです. **/
		private GCsrfRepository repository;
		/** レポシトリーのコンフィグレーションです. **/
		private Map<String, Object> repositoryConfiguration = new HashMap<>();
		/** CSRFルールの許可されるパータンです. **/
		private List<GSecurityRule.Pattern> filterPatterns = new ArrayList<>();
		/** CSRFルールの除外されるパータンです. **/
		private List<GSecurityRule.Pattern> filterExcludes = new ArrayList<>();
		/** CSRFルールの「TokenIssuance」パータンです. **/
		private List<GSecurityRule.Pattern> tokenIssuancePatterns = new ArrayList<>();
		/** レスポンスヘッダーにCSRFトークンを付けるかどうかのフラグです.**/
		private Boolean disableHeader = false;
		/** トークンを生成為のジェネレータークラスです. **/
		private GTokenGenerator tokenGenerator;
		/** リクエストにあるCSRFトークンのヘッダ項目名のプレフィックスです. **/
		private String headerPrefix;
		/** トークンの保管キーです. **/
		private String saveTokenKey;
		/** トークンの有効期限です.**/
		private Long maxAge;
		/** 無職されるのHttpMethodリストです.**/
		private List<GHttpMethod> ignoreHttpMethods = new ArrayList<>();

		/**
		 * レスポンスヘッダーにCSRFトークンを付けるフラグを取得します.
		 *
		 * @create 2023/10/25
		 * @return レスポンスヘッダーにCSRFトークンを付けるフラグ
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public boolean isDisableHeader() {
			return disableHeader;
		}

		/**
		 * CSRFトークンを生成する為のジェネレータークラスオブジェクトを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return CSRFトークンを生成する為のジェネレータークラスオブジェクト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public GTokenGenerator getTokenGenerator() {
			return tokenGenerator;
		}

		/**
		 * リクエストヘッダーにあるCSRFトークンのヘッダ項目名の「Prefix」を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return リクエストヘッダーにあるCSRFトークンのヘッダ項目名の「Prefix」
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public String getHeaderPrefix() {
			return headerPrefix;
		}

		/**
		 * リクエストヘッダーにあるCSRFトークンのヘッダ項目名を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return リクエストヘッダーにあるCSRFトークンのヘッダ項目名
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public String getSaveTokenKey() {
			return saveTokenKey;
		}

		/**
		 * CSRFトークンの有効期限を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return CSRFトークンの有効期限
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public Long getMaxAge() {
			return maxAge;
		}

		/**
		 * CSRFトークンを生成する為のジェネレータークラスオブジェクトを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param tokenGenerator CSRFトークンを生成する為のジェネレータークラスオブジェクト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setTokenGenerator(GTokenGenerator tokenGenerator) {
			this.tokenGenerator = tokenGenerator;
		}

		/**
		 * リクエストヘッダーにあるCSRFトークンのヘッダ項目名の「Prefix」を設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param headerPrefix リクエストヘッダーにあるCSRFトークンのヘッダ項目名の「Prefix」
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setHeaderPrefix(String headerPrefix) {
			this.headerPrefix = headerPrefix;
		}

		/**
		 * リクエストヘッダーにあるCSRFトークンのヘッダ項目名を設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param saveTokenKey リクエストヘッダーにあるCSRFトークンのヘッダ項目名
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setSaveTokenKey(String saveTokenKey) {
			this.saveTokenKey = saveTokenKey;
		}

		/**
		 * CSRFトークの有効期限を設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param maxAge CSRFトークの有効期限
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setMaxAge(Long maxAge) {
			this.maxAge = maxAge;
		}

		/**
		 * CSRFルールの許可されるパータンを追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param pattern CSRFルールの許可されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void addPattern(GSecurityRule.Pattern pattern) {
			removeSimilarActionBean(pattern, this.filterPatterns);
			this.filterPatterns.add(pattern);
		}

		/**
		 * CSRFルールの除外されるパータンを追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param exclude CSRFルールの除外されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void addExclude(GSecurityRule.Pattern exclude) {
			removeSimilarActionBean(exclude, this.filterExcludes);
			this.filterExcludes.add(exclude);
		}

		/**
		 * CSRFのレポシトリーオブジェクトを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param repository CSRFのレポシトリーオブジェクト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setRepository(GCsrfRepository repository) {
			this.repository = repository;
		}

		/**
		 * 「TokenIssuance」の許可されるパータンを追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param pattern 「TokenIssuance」の許可されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void addTokenIssuancePattern(GSecurityRule.Pattern pattern) {
			removeSimilarActionBean(pattern, this.tokenIssuancePatterns);
			this.tokenIssuancePatterns.add(pattern);
		}

		/**
		 * 無職されるHttpMethodを追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param method 無職されるHttpMethod
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void addIgnoreHttpMethod(GHttpMethod method) {
			this.ignoreHttpMethods.add(method);
		}

		/**
		 * 無視されるHttpMethodおリストを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return 無視されるHttpMethodのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<GHttpMethod> getIgnoreHttpMethods() {
			return ignoreHttpMethods;
		}

		/**
		 * 無視されるHttpMethodのリストを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param ignoreHttpMethods 無視されるHttpMethodのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setIgnoreHttpMethods(List<GHttpMethod> ignoreHttpMethods) {
			this.ignoreHttpMethods = ignoreHttpMethods;
		}

		/**
		 * Csrfレポシトリーオブジェクトを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return Csrfレポシトリーオブジェクト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public GCsrfRepository getRepository() {
			return repository;
		}

		/**
		 * CSRFルール許可されるパータンを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return CSRFルール許可されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<GSecurityRule.Pattern> getFilterPatterns() {
			return filterPatterns;
		}

		/**
		 *　CSRFレポシトリーのコンフィグレーションを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return CSRFレポシトリーのコンフィグレーション
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public Map<String, Object> getRepositoryConfiguration() {
			return repositoryConfiguration;
		}

		/**
		 * CSRFルールの許可されるパータンのリストを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param filterPatterns CSRFルールの許可されるパータンのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setFilterPatterns(List<GSecurityRule.Pattern> filterPatterns) {
			removeSimilarActionBean(filterPatterns);
			this.filterPatterns = filterPatterns;
		}

		/**
		 * CSRFの除外されるパータンのリストを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return CSRFの除外されるパータンのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<GSecurityRule.Pattern> getFilterExcludes() {
			return filterExcludes;
		}

		/**
		 * CSRFルールの除外されるパータンのリストを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param filterExcludes CSRFルールの除外されるパータンのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setFilterExcludes(List<GSecurityRule.Pattern> filterExcludes) {
			removeSimilarActionBean(filterExcludes);
			this.filterExcludes = filterExcludes;
		}

		/**
		 * 「TokenIssuance」の許可されるパータンのリストを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return 「TokenIssuance」の許可されるパータンのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<GSecurityRule.Pattern> getTokenIssuancePatterns() {
			return tokenIssuancePatterns;
		}

		/**
		 * 「TokenIssuance」の許可されるパータンのリストを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param tokenIssuancePatterns 「TokenIssuance」の許可されるパータンのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setTokenIssuancePatterns(
			List<GSecurityRule.Pattern> tokenIssuancePatterns) {
			removeSimilarActionBean(tokenIssuancePatterns);
			this.tokenIssuancePatterns = tokenIssuancePatterns;
		}

		/**
		 * 無視されるHttpMethodをプロパティから取得します.このプロパティの値はデフォルトにとして扱います.<br>
		 *
		 * @create 2023/10/25
		 * @return デフォルト無視されるHttpMethodのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		private List<GHttpMethod> getDefaultHttpMethods() {
			String httpMethodString = GFrameworkUtils.getProperty(
				GSecurityPropertyKeys.GEFRAME_SPA_WEB_SECURITY_CSRF_IGNORE_HTTP_METHOD_DEFAULT.getKey(),
				"GET,TRACE,OPTIONS,HEAD"
			);
			String[] httpMethods = httpMethodString.split(",");
			List<GHttpMethod> methods = new ArrayList<>();
			for (String httpMethod : httpMethods) {
				methods.add(GHttpMethod.valueFrom(httpMethod));
			}
			return methods;
		}

		/**
		 * CSRFトークンはレスポンスヘッダーに付けるのフラグを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param disableHeader CSRFトークンはレスポンスヘッダーに付けるのフラグ
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setDisableHeader(boolean disableHeader) {
			this.disableHeader = disableHeader;
		}

		/**
		 * CSRFルールをビルドします.<br>
		 *
		 * @create 2023/10/25
		 * @return ビルド結果
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public GSecurityRule.GCsrfRule build() {
			if (Objects.isNull(this.repository)) {
				throw new GFrameworkException(GFrameworkMessages.mustBeRequired(GCsrfRepository.class.getName()));
			}
			this.repository.setTokenGenerator(Objects.requireNonNullElse(tokenGenerator, new GUUIDTokenCreator()));
			this.repository.setTokenKey(Objects.requireNonNullElse(saveTokenKey, GFrameworkReservedWords.PARAMETER_NAME_CSRF_TOKEN.key()));
			this.repository.setHeaderPrefix(Objects.requireNonNullElse(headerPrefix, ""));
			this.repository.setTokenMaxAge(Objects.requireNonNullElse(maxAge, Long.valueOf(-1)));
			this.repository.setConfiguration(this.repositoryConfiguration);
			return new GSecurityRuleImpl.GCsrfRule(
				this.repository,
				this.filterPatterns,
				this.filterExcludes,
				this.tokenIssuancePatterns,
				this.ignoreHttpMethods.isEmpty() ? getDefaultHttpMethods() : this.ignoreHttpMethods,
				Objects.requireNonNullElse(this.disableHeader, false)
			);
		}
	}

	/**
	 * CORSルールをビルドする為のクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class CorsBuilder {
		private List<CorsConfigurationBuilder> corsConfigurationRules = new ArrayList<>();

		/**
		 * {@link GSecurityRule.GCorsConfigurationRule}のビルダーを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return {@link GSecurityRule.GCorsConfigurationRule}のビルダー
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public List<CorsConfigurationBuilder> getCorsConfigurationRules() {
			return corsConfigurationRules;
		}

		/**
		 * {@link GSecurityRule.GCorsConfigurationRule}のビルダーを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param corsConfigurationRules {@link GSecurityRule.GCorsConfigurationRule}のビルダー
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setCorsConfigurationRules(List<CorsConfigurationBuilder> corsConfigurationRules) {
			this.corsConfigurationRules = corsConfigurationRules;
		}

		/**
		 * {@link GSecurityRule.GCorsConfigurationRule}のビルダーを追加します.<br>
		 *
		 * @create 2023/10/25
		 * @param corsConfigurationBuilder {@link GSecurityRule.GCorsConfigurationRule}のビルダー
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void addCorsConfigurationRule(CorsConfigurationBuilder corsConfigurationBuilder) {
			this.corsConfigurationRules.add(corsConfigurationBuilder);
		}

		/**
		 * CORSルールをビルドします.<br>
		 *
		 * @create 2023/10/25
		 * @return ビルド結果
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public GSecurityRule.GCorsRule build() {
			return new GSecurityRuleImpl.GCorsRule(
				corsConfigurationRules.stream().map(CorsConfigurationBuilder::build).collect(Collectors.toList())
			);
		}

		/**
		 * {@link GSecurityRule.GCorsConfigurationRule}をビルドする為のクラスです.<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public static class CorsConfigurationBuilder {
			private String configId;
			private List<GSecurityRule.Pattern> patterns = new ArrayList<>();
			private List<GSecurityRule.Pattern> excludes = new ArrayList<>();

			/**
			 * CORSコンフィグレーションのIDを設定します.<br>
			 *
			 * @create 2023/10/25
			 * @param configId CORSコンフィグレーションのID
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public void setConfigId(String configId) {
				this.configId = configId;
			}

			/**
			 * CORSルールの許可されるパータンを追加します.<br>
			 *
			 * @create 2023/10/25
			 * @param pattern CORSルールの許可されるパータン
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public void addPattern(GSecurityRule.Pattern pattern) {
				removeSimilarActionBean(pattern, this.patterns);
				this.patterns.add(pattern);
			}

			/**
			 * CORSルールの除外されるパータンを追加します.<br>
			 *
			 * @create 2023/10/25
			 * @param exclude CORSルールの除外されるパータン
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public void addExclude(GSecurityRule.Pattern exclude) {
				removeSimilarActionBean(exclude, this.excludes);
				this.excludes.add(exclude);
			}

			/**
			 * CORSコンフィグレーションのIDを取得します.<br>
			 *
			 * @create 2023/10/25
			 * @return CORSコンフィグレーションのID
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public String getConfigId() {
				return configId;
			}

			/**
			 * CORSルールの許可されるパータンのリストを取得します.<br>
			 *
			 * @create 2023/10/25
			 * @return CORSルールの許可されるパータンのリスト
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public List<GSecurityRule.Pattern> getPatterns() {
				return patterns;
			}

			/**
			 * CORSルールの許可されるパータンのリストを設定します.<br>
			 *
			 * @create 2023/10/25
			 * @param patterns CORSルールの許可されるパータンのリスト
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public void setPatterns(List<GSecurityRule.Pattern> patterns) {
				removeSimilarActionBean(patterns);
				this.patterns = patterns;
			}

			/**
			 * CORSルールの除外されるパータンのリストを取得します.<br>
			 *
			 * @create 2023/10/25
			 * @return CORSルールの除外されるパータンのリスト
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public List<GSecurityRule.Pattern> getExcludes() {
				return excludes;
			}

			/**
			 * CORSルールの除外されるパータンのリストを設定します.<br>
			 *
			 * @create 2023/10/25
			 * @param excludes CORSルールの除外されるパータンのリスト
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public void setExcludes(List<GSecurityRule.Pattern> excludes) {
				removeSimilarActionBean(excludes);
				this.excludes = excludes;
			}

			/**
			 * CORSルールをビルドします.<br>
			 *
			 * @create 2023/10/25
			 * @return ビルド結果
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public GSecurityRule.GCorsConfigurationRule build() {
				return new GSecurityRuleImpl.GCorsConfigurationRule(
					this.configId,
					this.patterns,
					this.excludes
				);
			}
		}
	}

	private static void removeSimilarActionBean(GPatternProperty.Pattern pattern, List<GPatternProperty.Pattern> patternList) {
		if (pattern instanceof GPatternProperty.PatternActionBean) {
			for (int i = 0; i < patternList.size(); i++) {
				GPatternProperty.Pattern p = patternList.get(i);
				if (p instanceof GPatternProperty.PatternActionBean) {
					if ((((GPatternProperty.PatternActionBean) p).getActionBean().equals(((GPatternProperty.PatternActionBean) pattern).getActionBean()))) {
						patternList.remove(i);
						break;
					}
				}
			}
		}
	}
	private static void removeSimilarActionBean(List<GPatternProperty.Pattern> patterns) {
		Map<String, List<Integer>> actions = new HashMap<>();
		for (int i = 0; i < patterns.size(); i++) {
			if (patterns.get(i) instanceof GPatternProperty.PatternActionBean) {
				GPatternProperty.PatternActionBean pattern = (GPatternProperty.PatternActionBean) patterns.get(i);
				if (!actions.containsKey(pattern.getActionBean())) {
					List<Integer> index = new ArrayList<>();
					index.add(i);
					actions.put(pattern.getActionBean(), index);
				} else {
					actions.get(pattern.getActionBean()).add(i);
				}
			}
		}
		actions.forEach((k, v)-> {
			if (v.size() > 1) {
				for (int i = 0; i < v.size() - 1; i++) {
					int index = v.get(i);
					patterns.remove(index);
				}
			}
		});
	}
}
