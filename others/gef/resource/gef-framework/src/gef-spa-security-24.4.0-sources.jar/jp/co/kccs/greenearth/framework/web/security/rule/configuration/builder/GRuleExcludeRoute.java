/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder;

/**
 * ルールの除外されるパータンを登録する為のインタフェースです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GRuleExcludeRoute<E extends GTemplateBasePatternRoute<E>> extends
	GTemplateBasePatternRoute<E> {

}
