/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.authentication.GAuthenticationGateRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.context.GSecurityContextRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsGateRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf.GCsrfGateRoute;

/**
 * CORS, CSRF, 認証, セキュリティコンテキストルールを登録する為のインタフェースです.<br>
 * 最終に定義されるものは有効になります.例えば、下記見たいなクラスがあります.<br>
 * <pre>
 *     .cors(A)
 *     .csrf(..)
 *     .cors(B)
 * </pre>
 * 最終的にはCORSの値は「B」になります.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GRuleRoute {

	/**
	 * CORSルールを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSルートのAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsGateRoute cors();

	/**
	 * CSRFルールを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @return CSRFルートのAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfGateRoute csrf();

	/**
	 * 認証ルールを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @return 認証ルートのAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GAuthenticationGateRoute authentication();

	/**
	 * セキュリティコンテキストを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @return セキュリティコンテキストルートのAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GSecurityContextRoute<GRuleRoute> contextHolder();
}
