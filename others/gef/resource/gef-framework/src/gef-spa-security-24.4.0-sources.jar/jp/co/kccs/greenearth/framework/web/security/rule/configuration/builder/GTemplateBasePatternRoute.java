/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder;

/**
 * ルールのパータンを登録する為のインタフェースです.<br>
 * 用意されるAPIはGEFの「ActionBean・ActionMethod」とURIパータンです.<br>
 * 各ルールの中に複数パータンを定義するのは可能です.例えば、下記見たいなコードがあります.<br>
 * <pre>
 *     .action(A)
 *     .action(B)
 *     .uri(C)
 * </pre>
 * 最終的には登録されるパータンは「ActionBean・ActionMethod」のリストが{A, B}、URIパータンのリストは{C}になります.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GTemplateBasePatternRoute<PATTERN_ROUTE> {

	/**
	 * GEFの「ActionBean・ActionMethod」を登録します.<br>
	 * 渡される「ActionBean」は文字列の形です.<br>
	 *
	 * @create 2023/10/25
	 * @param actionBean アクションビーン
	 * @param actionMethods アクションメソッドのリスト
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	PATTERN_ROUTE action(String actionBean, String... actionMethods);

	/**
	 * GEFの「ActionBean・ActionMethod」を登録します.<br>
	 * 渡される「ActionBean」は{@link Class}型です.<br>
	 *
	 * @create 2023/10/25
	 * @param actionBean アクションビーン
	 * @param actionMethods アクションメソッドのリスト
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	PATTERN_ROUTE action(Class<?> actionBean, String... actionMethods);

	/**
	 * URIパータンを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param uri URIパータン
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	PATTERN_ROUTE uri(String uri);
}
