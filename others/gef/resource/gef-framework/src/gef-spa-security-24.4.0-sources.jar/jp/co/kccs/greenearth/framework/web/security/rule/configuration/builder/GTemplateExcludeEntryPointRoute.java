/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder;

/**
 * 除外パータンを登録する為のインタフェースです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GTemplateExcludeEntryPointRoute<EXCLUDE_ROUTE> {

	/**
	 * 除外パータンをマークします.<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GTemplateBasePatternRoute<EXCLUDE_ROUTE> exclude();
}
