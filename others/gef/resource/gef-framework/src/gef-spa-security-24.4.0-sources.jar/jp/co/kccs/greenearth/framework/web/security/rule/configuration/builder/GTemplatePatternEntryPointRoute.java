/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder;

/**
 * 許可パータンを登録する為のインタフェースです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GTemplatePatternEntryPointRoute<PATTERN_ROUTE> {

	/**
	 * 許可パータンをマークします.<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	PATTERN_ROUTE pattern();
}
