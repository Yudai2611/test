/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder;

/**
 * 許可と除外されるパータンを登録する為のインタフェースです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GTemplatePatternGateRoute<PATTERN_ROUTE, EXCLUDE_ROUTE> extends GTemplatePatternEntryPointRoute<PATTERN_ROUTE>,
	GTemplateExcludeEntryPointRoute<EXCLUDE_ROUTE> {
}
