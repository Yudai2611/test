/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.authentication;

import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleBuilderContext;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.parent.GSecurityRuleSetBuilder;

/**
 * セキュリティーは「Java」モードを使う場合、{@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration}に定義された認証ルールをビルドする為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GAuthenticationBuilder extends GSecurityRuleSetBuilder.Rule implements GAuthenticationGateRoute {

	public GAuthenticationBuilder(GRuleBuilderContext context) {
		this.builderContext = context;
		if (Objects.isNull(this.builderContext.getAuthenticationBuilder())) {
			this.builderContext.setAuthenticationBuilder(new GRuleBuilderContext.AuthenticationBuilder());
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAuthenticationGateRoute#exclude()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GTemplateBasePatternRoute<GAuthenticationExcludeRoute> exclude() {
		return new AuthenticationExcludeRoute(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAuthenticationGateRoute#pattern()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GTemplateBasePatternRoute<GAuthenticationPatternRoute> pattern() {
		return new AuthenticationPatternRoute(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAuthenticationGateRoute#processor(Class[])
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GAuthenticationEntryPointRoute processor(Class<? extends GAuthenticationProcessor> processor) {
		setProcessor(this.builderContext, processor);
		return new AuthenticationEntryPointRoute(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAuthenticationEntryPointRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class AuthenticationEntryPointRoute extends GSecurityRuleSetBuilder.Rule implements GAuthenticationEntryPointRoute {
		public AuthenticationEntryPointRoute(GRuleBuilderContext builderContext) {
			this.builderContext = builderContext;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationEntryPointRoute#exclude()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GAuthenticationExcludeRoute> exclude() {
			return new AuthenticationExcludeRoute(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationEntryPointRoute#pattern() 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GAuthenticationPatternRoute> pattern() {
			return new AuthenticationPatternRoute(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationEntryPointRoute#processor(Class[])
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationEntryPointRoute processor(Class<? extends GAuthenticationProcessor> processor) {
			setProcessor(this.builderContext, processor);
			return this;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAuthenticationPatternRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class AuthenticationPatternRoute extends GSecurityRuleSetBuilder.Rule implements GAuthenticationPatternRoute {
		public AuthenticationPatternRoute(GRuleBuilderContext context) {
			this.builderContext = context;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationPatternRoute#action(String, String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationPatternRoute action(String actionBean, String... actionMethods) {
			return setPattern(
					(pattern)-> {
					this.builderContext.getAuthenticationBuilder().addPattern(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationPatternRoute#action(Class, String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationPatternRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> this.builderContext.getAuthenticationBuilder().addPattern(pattern), actionBean, actionMethods);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationPatternRoute#uri(String) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationPatternRoute uri(String uri) {
			setPattern((pattern)-> this.builderContext.getAuthenticationBuilder().addPattern(pattern), uri);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationPatternRoute#exclude() 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GAuthenticationExcludeRoute> exclude() {
			return new AuthenticationExcludeRoute(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationPatternRoute#processor(Class[]) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationRoute processor(Class<? extends GAuthenticationProcessor> processor) {
			setProcessor(this.builderContext, processor);
			return new AuthenticationExcludeRoute(this.builderContext);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GAuthenticationExcludeRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class AuthenticationExcludeRoute extends GSecurityRuleSetBuilder.Rule implements GAuthenticationExcludeRoute {
		public AuthenticationExcludeRoute(GRuleBuilderContext context) {
			this.builderContext = context;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationExcludeRoute#processor(Class[]) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationRoute processor(Class<? extends GAuthenticationProcessor> processor) {
			setProcessor(this.builderContext, processor);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationExcludeRoute#action(String, String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationExcludeRoute action(String actionBean, String... actionMethods) {
			return setPattern(
				(pattern)-> {
					this.builderContext.getAuthenticationBuilder().addExclude(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationExcludeRoute#action(Class, String...)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationExcludeRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> this.builderContext.getAuthenticationBuilder().addExclude(pattern), actionBean, actionMethods);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GAuthenticationExcludeRoute#uri(String)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationExcludeRoute uri(String uri) {
			setPattern((pattern)-> this.builderContext.getAuthenticationBuilder().addExclude(pattern), uri);
			return this;
		}
	}

	/**
	 * {@link GRuleBuilderContext}に{@link GAuthenticationProcessor}のリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param builderContext ビルダーコンテキスト
	 * @param processors {@link GAuthenticationProcessor}のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setProcessor(GRuleBuilderContext builderContext, Class<? extends GAuthenticationProcessor> processor) {
		if (Objects.isNull(processor)) {
			throw new GFrameworkException("Processor cannot be null.");
		}
		builderContext.getAuthenticationBuilder().addProcessor(processor);
	}
}
