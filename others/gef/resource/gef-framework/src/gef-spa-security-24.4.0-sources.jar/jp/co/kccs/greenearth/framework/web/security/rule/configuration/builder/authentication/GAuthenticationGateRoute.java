/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.authentication;

import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplatePatternGateRoute;

/**
 * 認証ルール項目の「FluentAPI」を提供します.<br>
 * このインタフェースは{@link GAuthenticationGenericRoute}と似ていますが、ケース的には下記のようなコードに使われます.<br>
 * <pre>
 *     .processor(....)
 *     .pattern()
 *     		.uri(....)
 *     		.action(...)
 * </pre>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GAuthenticationGateRoute extends
	GTemplatePatternGateRoute<GTemplateBasePatternRoute<GAuthenticationPatternRoute>, GAuthenticationExcludeRoute> {

	/**
	 * 認証プロセッサーを定義します.<br>
	 *
	 * @create 2023/10/25
	 * @param processor {@link GAuthenticationProcessor}クラス
	 * @return 次のAPIルート {@link GAuthenticationEntryPointRoute}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GAuthenticationEntryPointRoute processor(Class<? extends GAuthenticationProcessor> processor);

}
