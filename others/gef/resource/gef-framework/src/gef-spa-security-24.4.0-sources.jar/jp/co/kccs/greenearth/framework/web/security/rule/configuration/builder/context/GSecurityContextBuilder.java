/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.context;


import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.security.context.GHttpSessionSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolderProvider;
import jp.co.kccs.greenearth.framework.web.security.context.GThreadLocalSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.SessionSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.ThreadLocalSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleBuilderContext;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.parent.GSecurityRuleSetBuilder;

/**
 * セキュリティーは「Java」モードを使う場合、{@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration}に定義されたセキュリティコンテキストのモードをビルドする為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityContextBuilder implements GSecurityContextRoute<GRuleRoute> {
	/** ビルド情報を持ってるルールビルダーコンテキストです. **/
	private GRuleBuilderContext ruleBuilderContext;

	public GSecurityContextBuilder(GRuleBuilderContext ruleBuilderContext) {
		this.ruleBuilderContext = ruleBuilderContext;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityContextRoute#session()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GRuleRoute session() {
		if (Objects.nonNull(ruleBuilderContext.getContextHolder())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Security Context"));
		}
		Optional<GSubjectHolder> subjectHolderOptional = GSubjectHolderProvider.getInstance().getSubjectHolder(SessionSubjectHolder.class);
		subjectHolderOptional.ifPresentOrElse(gSubjectHolder -> ruleBuilderContext.setContextHolder(gSubjectHolder),
			() -> ruleBuilderContext.setContextHolder(new GHttpSessionSubjectHolder()));
		return new GSecurityRuleSetBuilder.Rule(this.ruleBuilderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityContextRoute#threadLocal()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GRuleRoute threadLocal() {
		if (Objects.nonNull(ruleBuilderContext.getContextHolder())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Security Context"));
		}
		Optional<GSubjectHolder> subjectHolderOptional = GSubjectHolderProvider.getInstance().getSubjectHolder(ThreadLocalSubjectHolder.class);
		subjectHolderOptional.ifPresentOrElse(gSubjectHolder -> ruleBuilderContext.setContextHolder(gSubjectHolder),
			() -> ruleBuilderContext.setContextHolder(new GThreadLocalSubjectHolder()));
		return new GSecurityRuleSetBuilder.Rule(this.ruleBuilderContext);
	}
}
