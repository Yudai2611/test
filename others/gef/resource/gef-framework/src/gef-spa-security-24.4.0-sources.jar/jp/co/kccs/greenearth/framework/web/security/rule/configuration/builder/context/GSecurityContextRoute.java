/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.context;

/**
 * セキュリティコンテキストのモードを定義する為の「FluentAPI」を提供します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityContextRoute<T> {

	/**
	 * セキュリティコンテキストのモードはセッションに定義します.<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	T session();

	/**
	 * セキュリティコンテキストのモードはスレッドロカルに定義します.<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	T threadLocal();
}
