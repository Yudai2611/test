/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors;

import java.util.Objects;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleBuilderContext;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.parent.GSecurityRuleSetBuilder;

/**
 * セキュリティーは「Java」モードを使う場合、{@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration}に定義されたCORSルールをビルドする為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCorsBuilder implements GCorsGateRoute {
	/** ビルド情報を持ってるルールビルダーコンテキストです. **/
	private GRuleBuilderContext context;
	public GCorsBuilder(GRuleBuilderContext context) {
		this.context = context;
		if (Objects.isNull(context.getCorsBuilder())) {
			context.setCorsBuilder(new GRuleBuilderContext.CorsBuilder());
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsGateRoute#config(String)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GCorsConfigRoute config(String id) {
		return new CorsConfigRoute(this.context, setConfig(id, this.context));
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class CorsConfigRoute extends GSecurityRuleSetBuilder.Rule implements GCorsConfigRoute  {

		/** CORSルールのビルダーです.**/
		private GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder corsBuilder;
		public CorsConfigRoute(GRuleBuilderContext context, GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder builder) {
			this.builderContext = context;
			this.corsBuilder = builder;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigRoute#exclude()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GCorsExcludeRoute> exclude() {
			return new CorsExcludeRouteBuilder(this.builderContext, corsBuilder);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigRoute#pattern() 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GCorsPatternRoute> pattern() {
			return new CorsPatternRouteBuilder(this.builderContext, corsBuilder);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigRoute#config(String)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsConfigRoute config(String id) {
			return new CorsConfigRoute(this.builderContext, setConfig(id, this.builderContext));
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsPatternRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class CorsPatternRouteBuilder extends GSecurityRuleSetBuilder.Rule implements GCorsPatternRoute {

		/** CORSルールのビルダーです.**/
		private GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder corsBuilder;

		public CorsPatternRouteBuilder(GRuleBuilderContext context, GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder corsBuilder) {
			this.builderContext = context;
			this.corsBuilder = corsBuilder;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsPatternRoute#config(String) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsConfigRoute config(String id) {
			return new CorsConfigRoute(this.builderContext, setConfig(id, this.builderContext));
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsPatternRoute#action(String, String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsPatternRoute action(String actionBean, String... actionMethods) {
			return setPattern(
				(pattern)-> {
					this.corsBuilder.addPattern(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsPatternRoute#action(Class, String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsPatternRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> {
				this.corsBuilder.addPattern(pattern);
			}, actionBean, actionMethods);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsPatternRoute#uri(String)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsPatternRoute uri(String uri) {
			setPattern((pattern)-> {
				this.corsBuilder.addPattern(pattern);
			}, uri);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsPatternRoute#exclude()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GCorsExcludeRoute> exclude() {
			return new CorsExcludeRouteBuilder(this.builderContext, corsBuilder);
		}
	}

	/**
	 *
	 * @see GCorsExcludeRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class CorsExcludeRouteBuilder extends GSecurityRuleSetBuilder.Rule implements GCorsExcludeRoute {
		/** CORSルールのビルダーです. **/
		private GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder corsBuilder;
		public CorsExcludeRouteBuilder(GRuleBuilderContext context, GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder corsBuilder) {
			this.builderContext = context;
			this.corsBuilder = corsBuilder;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsExcludeRoute#config(String) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsConfigRoute config(String id) {
			return new CorsConfigRoute(this.builderContext, setConfig(id, this.builderContext));
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsExcludeRoute#action(String, String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsExcludeRoute action(String actionBean, String... actionMethods) {
			return setPattern(
				(pattern)-> {
					this.corsBuilder.addExclude(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsExcludeRoute#action(Class, String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsExcludeRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> {
				this.corsBuilder.addExclude(pattern);
			}, actionBean, actionMethods);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsExcludeRoute#uri(String)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsExcludeRoute uri(String uri) {
			setPattern((pattern)-> {
				this.corsBuilder.addExclude(pattern);
			}, uri);
			return this;
		}
	}

	/**
	 * {@link GRuleBuilderContext}に{@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration}のIDを登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param corsId {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration}のID
	 * @param builderContext ビルダーコンテキスト
	 * @return {@link GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder setConfig(String corsId, GRuleBuilderContext builderContext) {
		GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder corsBuilder = new GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder();
		corsBuilder.setConfigId(corsId);
		builderContext.getCorsBuilder().addCorsConfigurationRule(corsBuilder);
		return corsBuilder;
	}
}
