/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplatePatternGateRoute;

/**
 *　CORSルールの許可・除外されるパータンと{@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration}のIDを定義する為の「FluentAPI」を提供します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsConfigRoute extends GTemplatePatternGateRoute<GTemplateBasePatternRoute<GCorsPatternRoute>, GCorsExcludeRoute>,
	GRuleRoute, GCorsRoute {
}
