/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;

/**
 *　{@link GCorsConfiguration}をビルドする為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsConfigurationBuilder {

	/**
	 * 「Access-Control-Allow-Headers」のリストを設定します. <br/>
	 *
	 * @create 2023/10/25
	 * @param headers 「Access-Control-Allow-Headers」のリスト
	 * @return {@link GCorsConfigurationBuilder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsConfigurationBuilder allowedHeaders(String... headers);

	/**
	 * 「Access-Control-Allow-Methods」のリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param methods 「Access-Control-Allow-Methods」のリスト
	 * @return {@link GCorsConfigurationBuilder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */

	GCorsConfigurationBuilder allowedMethods(String... methods);

	/**
	 * 「Access-Control-Expose-Headers」のリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param headers 「Access-Control-Expose-Headers」のリスト
	 * @return {@link GCorsConfigurationBuilder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */

	GCorsConfigurationBuilder exposedHeaders(String... headers);

	/**
	 * 「Access-Control-Max-Age」を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param 「Access-Control-Max-Age」
	 * @return {@link GCorsConfigurationBuilder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsConfigurationBuilder maxAge(long maxAge);

	/**
	 * 「Access-Control-Allow-Origin」のリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param origins 「Access-Control-Allow-Origin」のリスト
	 * @return {@link GCorsConfigurationBuilder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */

	GCorsConfigurationBuilder allowedOrigins(String... origins);

	/**
	 * 「Access-Control-Allow-Credentials」を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param credential 「Access-Control-Allow-Credentials」
	 * @return {@link GCorsConfigurationBuilder}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */

	GCorsConfigurationBuilder credential(boolean credential);

	/**
	 * {@link GCorsConfiguration}にビルドします.<br>
	 *
	 * @create 2023/10/25
	 * @return ビルド結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsConfiguration build();
}
