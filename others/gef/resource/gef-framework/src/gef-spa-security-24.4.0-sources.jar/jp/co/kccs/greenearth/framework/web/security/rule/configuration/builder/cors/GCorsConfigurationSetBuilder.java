/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;

/**
 *　{@link GCorsConfiguration}のビルダーを作成する為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCorsConfigurationSetBuilder {
	private GCorsConfigurationSetBuilder() {
	}

	/**
	 * CORSのIDを設定して、ビルダーに回します.<br>
	 *
	 * @create 2023/10/25
	 * @param id 指定される{@link GCorsConfiguration}のID
	 * @return 作られたCORSビルダー
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static Builder cors(String id) {
		return new Builder(id);
	}

	/**
	 *
	 * @see GCorsConfigurationBuilder
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class Builder implements GCorsConfigurationBuilder {
		/** CORSコンフィグレーションのIDです. **/
		private final String corsId;
		/** 「Access-Control-Allow-Methods」のリストです. **/
		private final List<String> allowMethods;
		/** 「Access-Control-Allow-Headers」のリストです. **/
		private final List<String> allowHeaders;
		/** 「Access-Control-Allow-Credentials」です. **/
		private Boolean allowCredentials;
		/** 「Access-Control-Allow-Origin」のリストです.**/
		private final List<String> allowOrigins;
		/** 「Access-Control-Max-Age」です. **/
		private Long maxAge;
		/** 「Access-Control-Expose-Headers」のリストです. **/
		private final List<String> exposeHeaders;
		public Builder(String id) {
			corsId = id;
			allowMethods = new ArrayList<>();
			allowHeaders = new ArrayList<>();
			allowOrigins = new ArrayList<>();
			exposeHeaders = new ArrayList<>();
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigurationBuilder#allowedHeaders(String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public Builder allowedHeaders(String... headers) {
			if (!allowHeaders.isEmpty()) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInCorsConfiguration("Allowed headers"));
			}
			allowHeaders.addAll(List.of(headers));
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigurationBuilder#allowedMethods(String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public Builder allowedMethods(String... methods) {
			if (!allowMethods.isEmpty()) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInCorsConfiguration("Allowed methods"));
			}
			allowMethods.addAll(List.of(methods));
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigurationBuilder#exposedHeaders(String...) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public Builder exposedHeaders(String... headers) {
			if (!exposeHeaders.isEmpty()) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInCorsConfiguration("Exposed headers"));
			}
			exposeHeaders.addAll(List.of(headers));
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigurationBuilder#maxAge(long) 
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public Builder maxAge(long maxAge) {
			if (Objects.nonNull(this.maxAge)) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInCorsConfiguration("Max age"));
			}
			checkMaxAge(maxAge);
			this.maxAge = maxAge;
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigurationBuilder#allowedOrigins(String...)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public Builder allowedOrigins(String... origins) {
			if (!allowOrigins.isEmpty()) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInCorsConfiguration("Allowed origins"));
			}
			this.allowOrigins.addAll(List.of(origins));
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigurationBuilder#credential(boolean)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public Builder credential(boolean credential) {
			if (Objects.nonNull(allowCredentials)) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInCorsConfiguration("Allowed credential"));
			}
			this.allowCredentials = credential;
			return this;
		}

		private void checkMaxAge(long maxAge) {
			if (maxAge < -1) {
				throw new GFrameworkException(GFrameworkMessages.VALUE_OF_$s_CANNOT_BE_$s.message("maxAge", "less than -1"));
			}
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCorsConfigurationBuilder#build()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsConfiguration build() {
			allowCredentials = Objects.nonNull(allowCredentials) ? allowCredentials : false;
			maxAge = Objects.nonNull(maxAge) ? maxAge : -1;
			return new GCorsConfiguration(corsId, allowMethods, allowHeaders, allowCredentials, allowOrigins, maxAge, exposeHeaders);
		}

	}
}
