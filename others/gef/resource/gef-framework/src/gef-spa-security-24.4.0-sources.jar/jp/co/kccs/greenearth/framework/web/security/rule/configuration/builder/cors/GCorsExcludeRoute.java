/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleExcludeRoute;

/**
 * CORSルールの除外されるパータンの「FluentAPI」を定義します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsExcludeRoute extends GRuleExcludeRoute<GCorsExcludeRoute>, GCorsRoute {

}
