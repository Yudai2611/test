/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors;

/**
 * CORSルール項目の「FluentAPI」を提供します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsGateRoute {

	/**
	 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration}のIDを定義します.<br>
	 *
	 * @create 2023/10/25
	 * @param id 指定される{@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration}のID
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsConfigRoute config(String id);
}
