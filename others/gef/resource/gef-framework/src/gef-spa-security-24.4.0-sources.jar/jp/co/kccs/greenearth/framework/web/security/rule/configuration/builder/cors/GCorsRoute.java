/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;

/**
 *
 * @see GCorsGateRoute
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsRoute extends GRuleRoute, GCorsGateRoute {

}
