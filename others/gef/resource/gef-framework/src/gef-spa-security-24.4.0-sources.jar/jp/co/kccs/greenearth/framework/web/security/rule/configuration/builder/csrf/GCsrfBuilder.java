/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.http.GResponseCookie;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.SessionSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCookieCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCookieRepositoryConfigurationKeys;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepositoryProvider;
import jp.co.kccs.greenearth.framework.web.security.csrf.GHttpSessionCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.CookieRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.SessionRepository;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleBuilderContext;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.parent.GSecurityRuleSetBuilder;
import jp.co.kccs.greenearth.framework.web.security.token.GTokenGenerator;
import jp.co.kccs.greenearth.framework.web.security.token.GUUIDTokenCreator;

/**
 * CSRFルールの「FluentAPI」の実装です。<br>
 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration}の中に使われます。
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCsrfBuilder extends GSecurityRuleSetBuilder.Rule implements GCsrfGateRoute {
	public GCsrfBuilder(GRuleBuilderContext context) {
		this.builderContext = context;
		if (Objects.isNull(context.getCsrfBuilder())) {
			context.setCsrfBuilder(new GRuleBuilderContext.CsrfBuilder());
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfGateRoute#exclude()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GTemplateBasePatternRoute<GCsrfExcludeRoute> exclude() {
		return new CsrfExcludeRoute(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfGateRoute#pattern()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GTemplateBasePatternRoute<GCsrfPatternRoute> pattern() {
		return new CsrfPatternRoute(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfGateRoute#repository()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GCsrfRepositoryRoute<GCsrfEntryPointRoute> repository() {
		return new CsrfEntryPointRouteDetail(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfGateRoute#tokenIssuance() 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GCsrfTokenIssuanceRoute<GCsrfEntryPointRoute> tokenIssuance() {
		setTokenIssuancePattern(this.builderContext);
		return new CsrfEntryPointRouteDetail(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfGateRoute#ignoreHttpMethods(GHttpMethod...)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GCsrfEntryPointRoute ignoreHttpMethods(GHttpMethod... httpMethods) {
		setIgnoreHttpMethods(this.builderContext, httpMethods);
		return new CsrfEntryPointRoute(this.builderContext);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCsrfEntryPointRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class CsrfEntryPointRoute extends GSecurityRuleSetBuilder.Rule implements
		GCsrfEntryPointRoute {

		public CsrfEntryPointRoute(GRuleBuilderContext ruleBuilderContext) {
			this.builderContext = ruleBuilderContext;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCsrfEntryPointRoute#exclude()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GCsrfExcludeRoute> exclude() {
			return new CsrfExcludeRoute(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCsrfEntryPointRoute#repository()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCsrfRepositoryRoute<GCsrfEntryPointRoute> repository() {
			return new CsrfEntryPointRouteDetail(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCsrfEntryPointRoute#tokenIssuance()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCsrfTokenIssuanceRoute<GCsrfEntryPointRoute> tokenIssuance() {
			return new CsrfEntryPointRouteDetail(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCsrfEntryPointRoute#ignoreHttpMethods(GHttpMethod...)
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCsrfEntryPointRoute ignoreHttpMethods(GHttpMethod... httpMethods) {
			setIgnoreHttpMethods(this.builderContext, httpMethods);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GCsrfEntryPointRoute#pattern()
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GCsrfPatternRoute> pattern() {
			return new CsrfPatternRoute(this.builderContext);
		}
	}

	private static class CsrfEntryPointRouteDetail extends GSecurityRuleSetBuilder.Rule implements
		GCsrfRepositoryRoute<GCsrfEntryPointRoute>, GCsrfTokenIssuanceRoute<GCsrfEntryPointRoute>,
		GCsrfHttpSessionRepositoryRoute<GCsrfEntryPointRoute>,
		GCsrfCookieRepositoryRoute<GCsrfEntryPointRoute>,
		GCsrfCustomRepositoryRoute<GCsrfEntryPointRoute>,
		GCsrfTokenBehaviorGateRoute<GCsrfEntryPointRoute>,
		GCsrfTokenIssuanceGatePatternRoute<GCsrfEntryPointRoute>,
		GCsrfTokenBehaviorRoute<GCsrfEntryPointRoute>,
		GCsrfTokenBehaviorCreationGateRoute<GCsrfEntryPointRoute>,
		GCsrfTokenIssuancePatternRoute<GCsrfEntryPointRoute>,
		GCsrfTokenBehaviorCreationRoute<GCsrfEntryPointRoute> {
		public CsrfEntryPointRouteDetail(GRuleBuilderContext builderContext) {
			this.builderContext = builderContext;
		}


		@Override
		public GCsrfHttpSessionRepositoryRoute<GCsrfEntryPointRoute> sessionRepository() {
			Optional<GCsrfRepository> csrfRepository = GCsrfRepositoryProvider.getInstance().getRepository(SessionRepository.class);
			if (csrfRepository.isPresent()) {
				setRepository(csrfRepository.get(), this.builderContext);
			} else {
				setRepository(GHttpSessionCsrfRepository.class, this.builderContext);
			}
			return this;
		}


		@Override
		public GCsrfCookieRepositoryRoute<GCsrfEntryPointRoute> cookieRepository() {
			Optional<GCsrfRepository> csrfRepository = GCsrfRepositoryProvider.getInstance().getRepository(CookieRepository.class);
			if (csrfRepository.isPresent()) {
				setRepository(csrfRepository.get(), this.builderContext);
			} else {
				setRepository(GHttpSessionCsrfRepository.class, this.builderContext);
			}
			return this;
		}


		@Override
		public GCsrfCustomRepositoryRoute<GCsrfEntryPointRoute> customRepository(Class<? extends GCsrfRepository> repositoryClass) {
			setRepository(repositoryClass, this.builderContext);
			return this;
		}


		@Override
		public GCsrfTokenBehaviorGateRoute<GCsrfEntryPointRoute> tokenBehavior() {
			return this;
		}


		@Override
		public GCsrfTokenIssuanceGatePatternRoute<GCsrfEntryPointRoute> pattern() {
			return this;
		}


		@Override
		public GCsrfRepositoryRoute<GCsrfEntryPointRoute> repository() {
			return this;
		}


		@Override
		public GCsrfTokenIssuanceRoute<GCsrfEntryPointRoute> tokenIssuance() {
			return this;
		}


		@Override
		public GCsrfEntryPointRoute ignoreHttpMethods(GHttpMethod... httpMethods) {
			return new CsrfEntryPointRoute(this.builderContext);
		}


		@Override
		public GCsrfCookieRepositoryRoute<GCsrfEntryPointRoute> domain(String domain) {
			setDomainRepository(this.builderContext, domain);
			return this;
		}


		@Override
		public GCsrfCookieRepositoryRoute<GCsrfEntryPointRoute> path(String path) {
			setPathRepository(this.builderContext, path);
			return this;
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfEntryPointRoute> httpOnly(boolean httpOnly) {
			setHttpOnly(this.builderContext, httpOnly);
			return this;
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfEntryPointRoute> sameSite(GResponseCookie.SameSite sameSite) {
			setSameSite(this.builderContext, sameSite);
			return this;
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfEntryPointRoute> secure(boolean secure) {
			setSecure(this.builderContext, secure);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorRoute<GCsrfEntryPointRoute> headerPrefix(String header) {
			setRepositoryHeaderPrefix(this.builderContext, header);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorRoute<GCsrfEntryPointRoute> saveTokenKey(String tokenKey) {
			setRepositoryTokenKey(this.builderContext, tokenKey);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorRoute<GCsrfEntryPointRoute> maxAge(long maxAge) {
			setMaxAge(this.builderContext, maxAge);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorCreationGateRoute<GCsrfEntryPointRoute> creation() {
			return this;
		}

		@Override
		public GCsrfTokenIssuancePatternRoute<GCsrfEntryPointRoute> action(String actionBean, String... actionMethods) {
			setPattern(
				(pattern)-> {
					this.builderContext.getCsrfBuilder().addTokenIssuancePattern(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
			return this;
		}

		@Override
		public GCsrfTokenIssuancePatternRoute<GCsrfEntryPointRoute> action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addTokenIssuancePattern(pattern);
			}, actionBean, actionMethods);
			return this;
		}

		@Override
		public GCsrfTokenIssuancePatternRoute<GCsrfEntryPointRoute> uri(String uri) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addTokenIssuancePattern(pattern);
			}, uri);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorCreationRoute<GCsrfEntryPointRoute> uuid() {
			setTokenGenerator(this.builderContext, GUUIDTokenCreator.class);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorCreationRoute<GCsrfEntryPointRoute> customGenerator(Class<? extends GTokenGenerator> tokenGenerator) {
			setTokenGenerator(this.builderContext, tokenGenerator);
			return this;
		}

		@Override
		public GCsrfEntryPointRoute disableHeaderAttachment() {
			setDisableHeader(this.builderContext);
			return new CsrfEntryPointRoute(this.builderContext);
		}
	}

	private static class CsrfPatternRoute extends GSecurityRuleSetBuilder.Rule implements GCsrfPatternRoute {
		public CsrfPatternRoute(GRuleBuilderContext context) {
			this.builderContext = context;
		}

		@Override
		public GCsrfPatternRoute action(String actionBean, String... actionMethods) {
			return setPattern(
				(pattern)-> {
					this.builderContext.getCsrfBuilder().addPattern(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		@Override
		public GCsrfPatternRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addPattern(pattern);
			}, actionBean, actionMethods);
			return this;
		}

		@Override
		public GCsrfPatternRoute uri(String uri) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addPattern(pattern);
			}, uri);
			return this;
		}

		@Override
		public GCsrfRepositoryRoute<GCsrfRoute> repository() {
			return new RepositoryRouteRoute(this.builderContext);
		}

		@Override
		public GCsrfTokenIssuanceRoute<GCsrfRoute> tokenIssuance() {
			setTokenIssuancePattern(this.builderContext);
			return new RepositoryRouteRoute(this.builderContext);
		}

		@Override
		public GCsrfExcludeRoute ignoreHttpMethods(GHttpMethod... httpMethods) {
			setIgnoreHttpMethods(this.builderContext, httpMethods);
			return new CsrfExcludeRoute(this.builderContext);
		}

		@Override
		public GTemplateBasePatternRoute<GCsrfExcludeRoute> exclude() {
			return new CsrfExcludeRoute(this.builderContext);
		}
	}

	private static class CsrfExcludeRoute extends GSecurityRuleSetBuilder.Rule implements GCsrfExcludeRoute {
		public CsrfExcludeRoute(GRuleBuilderContext context) {
			this.builderContext = context;
		}

		@Override
		public GCsrfExcludeRoute action(String actionBean, String... actionMethods) {
			return setPattern(
				(pattern)-> {
					this.builderContext.getCsrfBuilder().addExclude(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		@Override
		public GCsrfExcludeRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addExclude(pattern);
			}, actionBean, actionMethods);
			return this;
		}

		@Override
		public GCsrfExcludeRoute uri(String uri) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addExclude(pattern);
			}, uri);
			return this;
		}

		@Override
		public GCsrfRepositoryRoute<GCsrfRoute> repository() {
			return new RepositoryRouteRoute(this.builderContext);
		}

		@Override
		public GCsrfTokenIssuanceRoute<GCsrfRoute> tokenIssuance() {
			setTokenIssuancePattern(this.builderContext);
			return new RepositoryRouteRoute(this.builderContext);
		}

		@Override
		public GCsrfExcludeRoute ignoreHttpMethods(GHttpMethod... httpMethods) {
			setIgnoreHttpMethods(this.builderContext, httpMethods);
			return this;
		}
	}

	private static class RepositoryRouteRoute extends GSecurityRuleSetBuilder.Rule
		implements
		GCsrfRepositoryRoute<GCsrfRoute>,
		GCsrfHttpSessionRepositoryRoute<GCsrfRoute>,
		GCsrfCookieRepositoryRoute<GCsrfRoute>,
		GCsrfCustomRepositoryRoute<GCsrfRoute>,
		GCsrfTokenBehaviorGateRoute<GCsrfRoute>,
		GCsrfTokenIssuanceRoute<GCsrfRoute>,
		GCsrfTokenIssuanceGatePatternRoute<GCsrfRoute>,
		GCsrfTokenIssuancePatternRoute<GCsrfRoute>,
		GCsrfTokenBehaviorCreationGateRoute<GCsrfRoute>,
		GCsrfTokenBehaviorCreationRoute<GCsrfRoute>,
		GCsrfTokenBehaviorRoute<GCsrfRoute> {

		public RepositoryRouteRoute(GRuleBuilderContext ruleBuilderContext) {
			this.builderContext = ruleBuilderContext;
		}

		@Override
		public GCsrfHttpSessionRepositoryRoute<GCsrfRoute> sessionRepository() {
			Optional<GCsrfRepository> csrfRepository = GCsrfRepositoryProvider.getInstance().getRepository(SessionRepository.class);
			if (csrfRepository.isPresent()) {
				setRepository(csrfRepository.get(), this.builderContext);

			} else {
				setRepository(GHttpSessionCsrfRepository.class, this.builderContext);
			}
			return this;
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfRoute> cookieRepository() {
			Optional<GCsrfRepository> csrfRepository = GCsrfRepositoryProvider.getInstance().getRepository(CookieRepository.class);
			if (csrfRepository.isPresent()) {
				setRepository(csrfRepository.get(), this.builderContext);
			} else {
				setRepository(GCookieCsrfRepository.class, this.builderContext);
			}
			return this;
		}

		@Override
		public GCsrfCustomRepositoryRoute<GCsrfRoute> customRepository(Class<? extends GCsrfRepository> repositoryClass) {
			setRepository(repositoryClass, this.builderContext);
			return this;
		}


		@Override
		public GCsrfTokenBehaviorGateRoute<GCsrfRoute> tokenBehavior() {
			return this;
		}

		@Override
		public GCsrfRepositoryRoute<GCsrfRoute> repository() {
			return this;
		}

		@Override
		public GCsrfTokenIssuanceRoute<GCsrfRoute> tokenIssuance() {
			setTokenIssuancePattern(this.builderContext);
			return this;
		}

		@Override
		public GCsrfRoute ignoreHttpMethods(GHttpMethod... httpMethods) {
			setIgnoreHttpMethods(this.builderContext, httpMethods);
			return new CsrfBuilderRoute(this.builderContext);
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfRoute> domain(String domain) {
			setDomainRepository(this.builderContext, domain);
			return this;
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfRoute> path(String path) {
			setPathRepository(this.builderContext, path);
			return this;
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfRoute> httpOnly(boolean httpOnly) {
			setHttpOnly(this.builderContext, httpOnly);
			return this;
		}


		@Override
		public GCsrfCookieRepositoryRoute<GCsrfRoute> sameSite(GResponseCookie.SameSite sameSite) {
			setSameSite(this.builderContext, sameSite);
			return this;
		}

		@Override
		public GCsrfCookieRepositoryRoute<GCsrfRoute> secure(boolean secure) {
			setSecure(this.builderContext, secure);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorRoute<GCsrfRoute> headerPrefix(String header) {
			setRepositoryHeaderPrefix(this.builderContext, header);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorRoute<GCsrfRoute> saveTokenKey(String tokenKey) {
			setRepositoryTokenKey(this.builderContext, tokenKey);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorRoute<GCsrfRoute> maxAge(long maxAge) {
			setMaxAge(this.builderContext, maxAge);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorCreationGateRoute<GCsrfRoute> creation() {
			return this;
		}

		@Override
		public GCsrfTokenIssuanceGatePatternRoute<GCsrfRoute> pattern() {
			return this;
		}

		@Override
		public GCsrfTokenIssuancePatternRoute<GCsrfRoute> action(String actionBean, String... actionMethods) {
			setPattern(
				(pattern)-> {
					this.builderContext.getCsrfBuilder().addTokenIssuancePattern(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
			return this;
		}

		@Override
		public GCsrfTokenIssuancePatternRoute<GCsrfRoute> action(Class<?> actionBean, String... actionMethods) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addTokenIssuancePattern(pattern);
			}, actionBean, actionMethods);
			return this;
		}


		@Override
		public GCsrfTokenIssuancePatternRoute<GCsrfRoute> uri(String uri) {
			setPattern((pattern)-> {
				this.builderContext.getCsrfBuilder().addTokenIssuancePattern(pattern);
			}, uri);
			return this;
		}

		@Override
		public GCsrfRoute disableHeaderAttachment() {
			setDisableHeader(this.builderContext);
			return new CsrfBuilderRoute(this.builderContext);
		}

		@Override
		public GCsrfTokenBehaviorCreationRoute<GCsrfRoute> uuid() {
			setTokenGenerator(this.builderContext, GUUIDTokenCreator.class);
			return this;
		}

		@Override
		public GCsrfTokenBehaviorCreationRoute<GCsrfRoute> customGenerator(Class<? extends GTokenGenerator> tokenGenerator) {
			setTokenGenerator(this.builderContext, tokenGenerator);
			return this;
		}
	}

	private static class CsrfBuilderRoute extends GSecurityRuleSetBuilder.Rule implements GCsrfRoute {
		public CsrfBuilderRoute(GRuleBuilderContext builderContext) {
			this.builderContext = builderContext;
		}

		@Override
		public GCsrfRepositoryRoute<GCsrfRoute> repository() {
			return new RepositoryRouteRoute(this.builderContext);
		}

		@Override
		public GCsrfTokenIssuanceRoute<GCsrfRoute> tokenIssuance() {
			setTokenIssuancePattern(this.builderContext);
			return new RepositoryRouteRoute(this.builderContext);
		}

		@Override
		public GCsrfRoute ignoreHttpMethods(GHttpMethod... httpMethods) {
			setIgnoreHttpMethods(this.builderContext, httpMethods);
			return this;
		}
	}

	private static void setRepository(GCsrfRepository repository, GRuleBuilderContext builderContext) {
		if (Objects.nonNull(builderContext.getCsrfBuilder().getRepository())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's repository"));
		}
		builderContext.getCsrfBuilder().setRepository(repository);
	}

	private static void setRepository(Class<? extends GCsrfRepository> repository, GRuleBuilderContext builderContext) {
		if (Objects.nonNull(builderContext.getCsrfBuilder().getRepository())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's repository"));
		}
		Optional<GCsrfRepository> csrfRepository = GObjectInstantiator.getInstance().newInstance(repository);
		csrfRepository.ifPresent(gCsrfRepository -> builderContext.getCsrfBuilder().setRepository(gCsrfRepository));
	}

	/**
	 * {@link GRuleBuilderContext}にある「tokenIssuance」のパータンは空かどうか検証します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setTokenIssuancePattern(GRuleBuilderContext builderContext) {
		if (!builderContext.getCsrfBuilder().getTokenIssuancePatterns().isEmpty()) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's token issuance pattern"));
		}
	}

	/**
	 * 無視される「HttpMethod」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setIgnoreHttpMethods(GRuleBuilderContext builderContext, GHttpMethod... httpMethods) {
		if (!builderContext.getCsrfBuilder().getIgnoreHttpMethods().isEmpty()) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's ignore http methods"));
		}
		builderContext.getCsrfBuilder().setIgnoreHttpMethods(List.of(httpMethods));
	}

	/**
	 * {@link GRuleBuilderContext}にクッキーレポシトリーのドメインを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setDomainRepository(GRuleBuilderContext builderContext, String domain) {
		if (builderContext.getCsrfBuilder().getRepositoryConfiguration().containsKey(GCookieRepositoryConfigurationKeys.DOMAIN.getValue())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's domain"));
		}
		builderContext.getCsrfBuilder().getRepositoryConfiguration().put(GCookieRepositoryConfigurationKeys.DOMAIN.getValue(), domain);
	}

	/**
	 * {@link GRuleBuilderContext}にクッキーレポシトリーのパースを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setPathRepository(GRuleBuilderContext builderContext, String path) {
		if (builderContext.getCsrfBuilder().getRepositoryConfiguration().containsKey(GCookieRepositoryConfigurationKeys.PATH.getValue())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's path"));
		}
		builderContext.getCsrfBuilder().getRepositoryConfiguration().put(GCookieRepositoryConfigurationKeys.PATH.getValue(), path);
	}

	/**
	 * {@link GRuleBuilderContext}にクッキーレポシトリーの「HttpOnly」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setHttpOnly(GRuleBuilderContext builderContext, boolean httpOnly) {
		if (builderContext.getCsrfBuilder().getRepositoryConfiguration().containsKey(GCookieRepositoryConfigurationKeys.HTTP_ONLY.getValue())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's http only"));
		}
		builderContext.getCsrfBuilder().getRepositoryConfiguration().put(GCookieRepositoryConfigurationKeys.HTTP_ONLY.getValue(), httpOnly);
	}

	/**
	 * {@link GRuleBuilderContext}にクッキーレポシトリーの「SameSite」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setSameSite(GRuleBuilderContext builderContext, GResponseCookie.SameSite sameSite) {
		if (builderContext.getCsrfBuilder().getRepositoryConfiguration().containsKey(GCookieRepositoryConfigurationKeys.SAME_SITE.getValue())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's same site"));
		}
		builderContext.getCsrfBuilder().getRepositoryConfiguration().put(GCookieRepositoryConfigurationKeys.SAME_SITE.getValue(), sameSite);
	}

	/**
	 * {@link GRuleBuilderContext}にクッキーレポシトリーの「Secure」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setSecure(GRuleBuilderContext builderContext, boolean secure) {
		if (builderContext.getCsrfBuilder().getRepositoryConfiguration().containsKey(GCookieRepositoryConfigurationKeys.SECURE.getValue())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's secure"));
		}
		builderContext.getCsrfBuilder().getRepositoryConfiguration().put(GCookieRepositoryConfigurationKeys.SECURE.getValue(), secure);
	}

	/**
	 * {@link GRuleBuilderContext}にクッキーレポシトリーの有効期限を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setMaxAge(GRuleBuilderContext builderContext, long maxAge) {
		if (Objects.nonNull((builderContext.getCsrfBuilder().getMaxAge()))) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's max age"));
		}
		builderContext.getCsrfBuilder().setMaxAge(maxAge);
	}

	/**
	 * {@link GRuleBuilderContext}にトークンジェネレーターを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setTokenGenerator(GRuleBuilderContext builderContext, Class<? extends GTokenGenerator> tokenGenerator) {
		if (Objects.nonNull((builderContext.getCsrfBuilder().getTokenGenerator()))) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's token generator"));
		}
		Optional<GTokenGenerator> tokenGeneratorOptional = GObjectInstantiator.getInstance().newInstance(tokenGenerator);
		tokenGeneratorOptional.ifPresent(generator -> builderContext.getCsrfBuilder().setTokenGenerator(generator));
	}

	/**
	 * {@link GRuleBuilderContext}にヘッダープレフィックスを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setRepositoryHeaderPrefix(GRuleBuilderContext builderContext, String headerPrefix) {
		if (Objects.nonNull(builderContext.getCsrfBuilder().getHeaderPrefix())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's header prefix"));
		}
		builderContext.getCsrfBuilder().setHeaderPrefix(headerPrefix);
	}

	/**
	 * {@link GRuleBuilderContext}にトークンの保管キーを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setRepositoryTokenKey(GRuleBuilderContext builderContext, String tokenKey) {
		if (Objects.nonNull(builderContext.getCsrfBuilder().getSaveTokenKey())) {
			throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule's token key"));
		}
		builderContext.getCsrfBuilder().setSaveTokenKey(tokenKey);
	}

	/**
	 * {@link GRuleBuilderContext}にレスポンスにCSRFトークンを入れるかどうかのフラグを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setDisableHeader(GRuleBuilderContext builderContext) {
		builderContext.getCsrfBuilder().setDisableHeader(true);
	}
}
