/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import jp.co.kccs.greenearth.framework.web.http.GResponseCookie;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSet;

/**
 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration#configure(GSecurityRuleSet)}の中にCSRFレポシトリーを設定する時、クッキー項目の「FluentAPI」を提供します。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfCookieRepositoryRoute<T> extends GCsrfGenericRoute<T>, GCsrfRepositoryRoute<T> {

	/**
	 * クッキーの「domain」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param domain CSRFトークンのドメイン
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfCookieRepositoryRoute<T> domain(String domain);

	/**
	 * クッキーの「path」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param path CSRFトークンのパース
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfCookieRepositoryRoute<T> path(String path);

	/**
	 * クッキーの「HttpOnly」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param httpOnly CSRFトークンのHttpOnly
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfCookieRepositoryRoute<T> httpOnly(boolean httpOnly);

	/**
	 * クッキーの「SameSite」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param sameSite CSRFトークンのSameSite
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfCookieRepositoryRoute<T> sameSite(GResponseCookie.SameSite sameSite);

	/**
	 * クッキーの「secure」を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param secure CSRFトークンのsecure
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfCookieRepositoryRoute<T> secure(boolean secure);
}
