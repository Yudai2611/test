/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleExcludeRoute;

/**
 * CSRFルールの除外されるパータンの「FluentAPI」を提供します。<br>
 *
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfExcludeRoute extends GRuleExcludeRoute<GCsrfExcludeRoute>, GCsrfRoute {

}
