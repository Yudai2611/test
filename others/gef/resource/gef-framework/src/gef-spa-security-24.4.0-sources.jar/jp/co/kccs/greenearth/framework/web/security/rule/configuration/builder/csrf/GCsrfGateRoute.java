/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplatePatternGateRoute;

/**
 * CSRFルール項目の「FluentAPI」を提供します。<br>
 * このインタフェースは{@link GCsrfGenericRoute}と似ていますが、ケース的には下記のようなコードに使われます。<br>
 * <pre>
 *     .repository(....)
 *     .pattern()
 *     		.uri(....)
 *     		.action(...)
 * </pre>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfGateRoute extends GTemplatePatternGateRoute<GTemplateBasePatternRoute<GCsrfPatternRoute>, GCsrfExcludeRoute> {

	/**
	 * レポシトリーの詳細を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfRepositoryRoute<GCsrfEntryPointRoute> repository();

	/**
	 * 「TokenIssuance」の詳細を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenIssuanceRoute<GCsrfEntryPointRoute> tokenIssuance();

	/**
	 * 無視されるHttpMethodを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param httpMethods 無職されるHttpMethods
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfEntryPointRoute ignoreHttpMethods(GHttpMethod... httpMethods);
}
