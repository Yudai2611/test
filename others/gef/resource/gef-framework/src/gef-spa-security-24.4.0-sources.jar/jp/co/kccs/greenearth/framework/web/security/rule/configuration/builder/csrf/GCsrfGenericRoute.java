/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;

/**
 * CSRFルール項目の「FluentAPI」を提供します。<br>
 * このインタフェースは{@link GCsrfGateRoute}と似ていますが、ケース的には下記のようなコードに使われます。<br>
 * <pre>
 *     .pattern()
 *     		.uri(....)
 *     		.action(...)
 *     	.repository(....)
 * </pre>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfGenericRoute<T> extends GRuleRoute {

	/**
	 * CSRFレポシトリーの詳細を定義します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfRepositoryRoute<T> repository();

	/**
	 * CSRFの「TokenIssuance」を定義します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenIssuanceRoute<T> tokenIssuance();

	/**
	 * 無視される「HttpMethod」を定義します。<br>
	 *
	 * @create 2023/10/25
	 * @param httpMethods 無職されるHttpMethod
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	T ignoreHttpMethods(GHttpMethod... httpMethods);
}
