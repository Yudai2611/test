/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository;

/**
 * CSRFルールレポシトリーの詳細の「FluentAPI」を提供します。<br>
 * sessionRepository, cookieRepository, customRepositoryは重複することは出来ません、重複されたら、例外が発生します。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfRepositoryRoute<T> {

	/**
	 * セッションレポシトリーを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfHttpSessionRepositoryRoute<T> sessionRepository();

	/**
	 * クッキーレポシトリーを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfCookieRepositoryRoute<T> cookieRepository();

	/**
	 * カスタムレポシトリーを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param repositoryClass カスタムレポシトリークラス
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfCustomRepositoryRoute<T> customRepository(Class<? extends GCsrfRepository> repositoryClass);

	/**
	 * 生成するトークン挙動を設定します。<br>
	 * コントロール出来る挙動は{@link GCsrfTokenBehaviorGateRoute}に見れます。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenBehaviorGateRoute<T> tokenBehavior();
}
