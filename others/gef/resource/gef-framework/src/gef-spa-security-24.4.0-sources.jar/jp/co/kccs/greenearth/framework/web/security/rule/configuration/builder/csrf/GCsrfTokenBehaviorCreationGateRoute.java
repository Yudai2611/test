/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import jp.co.kccs.greenearth.framework.web.security.token.GTokenGenerator;
import jp.co.kccs.greenearth.framework.web.security.token.GUUIDTokenCreator;

/**
 * トークンを生成する為のジェネレータークラスはこのインタフェース「FluentAPI」で設定出来ます。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfTokenBehaviorCreationGateRoute<T> {

	/**
	 * トークンのジェネレーターは{@link GUUIDTokenCreator}に設定します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenBehaviorCreationRoute<T> uuid();

	/**
	 * トークンのジェネレーターはカスタムクラスに設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param tokenGenerator 設定されたいCSRFトークンジェネレータークラス
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenBehaviorCreationRoute<T> customGenerator(Class<? extends GTokenGenerator> tokenGenerator);
}
