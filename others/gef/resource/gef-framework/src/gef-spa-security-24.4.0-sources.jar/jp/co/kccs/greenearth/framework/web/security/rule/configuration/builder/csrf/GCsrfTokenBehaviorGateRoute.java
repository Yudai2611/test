/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

/**
 * トークンを生成する時にヘッダー項目のPrefix、ヘッダー項目名,トークンの有効期限、トークンのジェネレーターはコントロール出来ます。このインタフェースがその為の「FluentAPI」を提供します。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfTokenBehaviorGateRoute<T> {

	/**
	 * リクエストヘッダに付けるCSRFトークンのヘッダ項目名のプレフィックスを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param header リクエストヘッダに付けるCSRFトークンのヘッダ項目名のプレフィックス
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenBehaviorRoute<T> headerPrefix(String header);

	/**
	 * CSRFトークン保管キーを設定します。<br>
	 *　
	 * @create 2023/10/25
	 * @param tokenKey 保管キー
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenBehaviorRoute<T> saveTokenKey(String tokenKey);

	/**
	 * CSRFトークンの有効期限を設定します。<br>
	 *
	 * @create 2023/10/25
	 * @param maxAge トークンの有効期限
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenBehaviorRoute<T> maxAge(long maxAge);


	/**
	 * トークン生成挙動のルートです。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenBehaviorCreationGateRoute<T> creation();

}
