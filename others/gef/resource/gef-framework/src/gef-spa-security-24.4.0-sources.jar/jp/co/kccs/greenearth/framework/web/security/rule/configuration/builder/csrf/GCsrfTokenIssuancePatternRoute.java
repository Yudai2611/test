/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;

/**
 * 「TokenIssuance」項目の「FluentAPI」を提供します。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfTokenIssuancePatternRoute<T> extends GCsrfTokenIssuanceGatePatternRoute<T>, GRuleRoute, GCsrfGenericRoute<T> {

	/**
	 * レスポンスヘッダーにCSRFを付けるのフラグを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	T disableHeaderAttachment();
}
