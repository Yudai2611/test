/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf;

/**
 * 「TokenIssuance」の許可されるパータンマーカーの「FluentAPI」です。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCsrfTokenIssuanceRoute<T> {

	/**
	 * 許可されるパータンのマーカーです。<br>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCsrfTokenIssuanceGatePatternRoute<T> pattern();
}
