/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.parent;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;

/**
 * セキュリティルールの除外されるパータンをビルドする為のクラスです。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityRuleExcludeRoute extends GTemplateBasePatternRoute<GSecurityRuleExcludeRoute>, GRuleRoute {
}
