/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.parent;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.security.rule.GPatternProperty;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRuleImpl;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSet;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleBuilderContext;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplateBasePatternRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GTemplatePatternEntryPointRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.authentication.GAuthenticationBuilder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.authentication.GAuthenticationGateRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.context.GSecurityContextBuilder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.context.GSecurityContextRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsBuilder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsGateRoute;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf.GCsrfBuilder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.csrf.GCsrfGateRoute;

/**
 * セキュリティルールをビルドする為のクラスです。<br>
 * JAVAモードを使う時に、このクラスはビルドする為のAPIを用意します。<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityRuleSetBuilder {

	/**
	 * セキュリティルールをビルドする為の前頭です。
	 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration#configure(GSecurityRuleSet)}の中に、
	 * {@link GSecurityRuleSet#add(GRuleRoute)}か{@link GSecurityRuleSet#addAll(GRuleRoute...)}とかに追加します。例えば、下記のコードを参考になれます。<br>
	 * <pre>
	 *     securityRuleSet.add(
	 *     		rule()
	 *     			.pattern(....)
	 *     			.....
	 *     )
	 * </pre>
	 *
	 * @create 2023/10/25
	 * @return 次のAPIルート
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static GTemplatePatternEntryPointRoute<GTemplateBasePatternRoute<GSecurityRulePatternRoute>> rule() {
		return new GSecurityRuleSetBuilder.EntryPoint();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GTemplatePatternEntryPointRoute
	 */
	static class EntryPoint implements GTemplatePatternEntryPointRoute<GTemplateBasePatternRoute<GSecurityRulePatternRoute>> {

		public EntryPoint() {
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GSecurityRulePatternRoute> pattern() {
			return new GSecurityRuleSetBuilder.SecurityRulePatternRoute(new GRuleBuilderContext());
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	static class SecurityRulePatternRoute extends Rule implements GSecurityRulePatternRoute {
		public SecurityRulePatternRoute(GRuleBuilderContext context) {
			this.builderContext = context;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GTemplateBasePatternRoute<GSecurityRuleExcludeRoute> exclude() {
			return new SecurityRuleExcludedPatternRoute(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GSecurityRulePatternRoute action(String actionBean, String... actionMethods) {
			return setPattern(
				(pattern)-> {
					this.builderContext.addPattern(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GSecurityRulePatternRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern(
				(pattern)-> {
					this.builderContext.addPattern(pattern);
				},
				actionBean,
				actionMethods
			);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GSecurityRulePatternRoute uri(String uri) {
			setPattern(
				(pattern)-> {
					this.builderContext.addPattern(pattern);
				},
				uri
			);
			return this;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static class SecurityRuleExcludedPatternRoute extends Rule implements GSecurityRuleExcludeRoute {
		public SecurityRuleExcludedPatternRoute(GRuleBuilderContext context) {
			this.builderContext = context;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GSecurityRuleExcludeRoute action(String actionBean, String... actionMethods) {
			return setPattern(
				(pattern)-> {
					this.builderContext.addExclude(pattern);
				},
				() -> this,
				actionBean,
				actionMethods);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GSecurityRuleExcludeRoute action(Class<?> actionBean, String... actionMethods) {
			setPattern(
				(pattern)-> {
					this.builderContext.addExclude(pattern);
				},
				actionBean,
				actionMethods
			);
			return this;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GSecurityRuleExcludeRoute uri(String uri) {
			setPattern(
				(pattern)-> {
					this.builderContext.addExclude(pattern);
				},
				uri
			);
			return this;
		}
	}

	/**
	 * {@link GRuleRoute}の実装です。<br>
	 *
	 *
	 * @see GRuleRoute
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public static class Rule implements GRuleRoute {
		/** ビルドする情報を持ってるコンテキストです。 **/
		protected GRuleBuilderContext builderContext;
		public Rule() {
			this.builderContext = new GRuleBuilderContext();
		}
		public Rule(GRuleBuilderContext context) {
			this.builderContext = context;
		}

		/**
		 * {@link GSecurityRule}をビルドします。<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public GSecurityRule build() {
			return builderContext.build();
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCorsGateRoute cors() {
			if (Objects.nonNull(this.builderContext.getCorsBuilder())) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Cors rule"));
			}
			return new GCorsBuilder(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GCsrfGateRoute csrf() {
			if (Objects.nonNull(this.builderContext.getCsrfBuilder())) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Csrf rule"));
			}
			return new GCsrfBuilder(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GAuthenticationGateRoute authentication() {
			if (Objects.nonNull(this.builderContext.getAuthenticationBuilder())) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Authentication rule"));
			}
			return new GAuthenticationBuilder(this.builderContext);
		}

		/**
		 * {@inheritDoc}
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@Override
		public GSecurityContextRoute<GRuleRoute> contextHolder() {
			if (Objects.nonNull(this.builderContext.getContextHolder())) {
				throw new GFrameworkException(GFrameworkMessages.shouldOnlyDefinedOnceInSecurityRule("Context holder"));
			}
			return new GSecurityContextBuilder(this.builderContext);
		}

		/**
		 * 追加されたいパータンはURIパータンの場合、このメソッドを使います。<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		protected static void setPattern(Consumer<GPatternProperty.Pattern> uriSetter, String uri) {
			GSecurityRuleSetBuilder.setPattern(uriSetter, uri);
		}

		/**
		 * 追加されたいパータンはGEFの「ActionBean（{@link Class}型）・ActionMethod」パータンの場合、このメソッドを使います。<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		protected static void setPattern(Consumer<GPatternProperty.Pattern> uriSetter, Class<?> actionBean, String... actionMethods) {
			GSecurityRuleSetBuilder.setPattern(uriSetter, actionBean, actionMethods);
		}

		/**
		 * 追加されたいパータンはGEFの「ActionBean ({@link String}型)・ActionMethod」パータンの場合、このメソッドを使います。<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		protected static <T> T setPattern(Consumer<GPatternProperty.Pattern> uriSetter, Supplier<T> returnFunc, String actionBean, String... actionMethods) {
			return GSecurityRuleSetBuilder.setPattern(uriSetter, returnFunc, actionBean, actionMethods);
		}
	}

	/**
	 * URIパータンを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setPattern(Consumer<GPatternProperty.Pattern> uriSetter, String uri) {
		uriSetter.accept(new GSecurityRuleImpl.PatternUri(uri));
	}

	/**
	 * GEFの「ActionBean({@link Class}型)・ActionMethod」パータンを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static void setPattern(Consumer<GPatternProperty.Pattern> uriSetter, Class<?> actionBean, String... actionMethods) {
		uriSetter.accept(new GSecurityRuleImpl.PatternActionBean(actionBean.getCanonicalName(), List.of(actionMethods)));
	}

	/**
	 * GEFの「ActionBean({@link String}型)・ActionMethod」パータンを設定します。<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	private static <T> T setPattern(Consumer<GPatternProperty.Pattern> uriSetter, Supplier<T> returnFunc, String actionBean, String... actionMethods) {
		actionBean = Objects.requireNonNullElse(actionBean, "").trim();
		uriSetter.accept(new GSecurityRuleImpl.PatternActionBean(actionBean, List.of(actionMethods)));
		return returnFunc.get();
	}
}
