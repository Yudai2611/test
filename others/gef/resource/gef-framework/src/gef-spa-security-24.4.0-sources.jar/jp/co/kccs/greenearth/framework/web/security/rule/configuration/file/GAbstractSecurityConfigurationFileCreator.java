/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file;

import java.util.List;

import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfigurationSet;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfigurationCreator;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSet;

/**
 *
 * @see GSecurityConfigurationCreator
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public abstract class GAbstractSecurityConfigurationFileCreator implements GSecurityConfigurationCreator {
	protected String filePath;
	protected GSecurityConfigurationFileEntity securityConfigurationFileEntity;
	protected GSecurityConfigurationFileParser<? extends GSecurityConfigurationFileEntity> securityConfigurationFileParser;
	protected GSecurityConfigurationFileMapper securityConfigurationFileMapper;

	public GAbstractSecurityConfigurationFileCreator(
		String filePath,
		GSecurityConfigurationFileParser<? extends GSecurityConfigurationFileEntity> securityConfigurationFileParser,
		GSecurityConfigurationFileMapper securityConfigurationFileMapper) {
		this.filePath = filePath;
		this.securityConfigurationFileParser = securityConfigurationFileParser;
		this.securityConfigurationFileMapper = securityConfigurationFileMapper;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationCreator#loadRules()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<GSecurityRule> loadRules() {
		loadEntity();
		GSecurityRuleSet securityRuleGroup = securityConfigurationFileMapper.mappingSecurityRule(securityConfigurationFileEntity.getRules());
		return securityRuleGroup.getSecurityRules();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationCreator#loadCors()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<GCorsConfiguration> loadCors() {
		loadEntity();
		GCorsConfigurationSet corsConfigurationGroup = securityConfigurationFileMapper.mappingCors(securityConfigurationFileEntity.getCors());
		return corsConfigurationGroup.getCorsConfigurations();
	}
	private void loadEntity() {
		securityConfigurationFileEntity = securityConfigurationFileParser.parse(filePath);
	}

}
