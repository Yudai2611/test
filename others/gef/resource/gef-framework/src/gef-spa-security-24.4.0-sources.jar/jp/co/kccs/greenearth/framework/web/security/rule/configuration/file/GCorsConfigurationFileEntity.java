/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file;

import java.util.List;

/**
 * ファイルに定義されるCORSルールを代表します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsConfigurationFileEntity {

	/**
	 * CORSのIDを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CorsコンフィグレーションのID
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getId();

	/**
	 * CORSの「Access-Control-Allow-Methods」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSの「Access-Control-Allow-Methods」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<String> getAllowMethods();

	/**
	 * CORSの「Access-Control-Allow-Headers」のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSの「Access-Control-Allow-Headers」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<String> getAllowHeaders();

	/**
	 * CORSの「Access-Control-Allow-Credentials」のフラグを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSの「Access-Control-Allow-Credentials」のフラグ
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	boolean isAllowCredentials();

	/**
	 * CORSの「Access-Control-Max-Age」を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSの「Access-Control-Max-Age」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Integer getMaxAge();

	/**
	 * CORSの「Access-Control-Expose-Headers」を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSの「Access-Control-Expose-Headers」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<String> getExposeHeaders();

	/**
	 * CORSの「Access-Control-Allow-Origin」を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSの「Access-Control-Allow-Origin」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<String> getAllowOrigins();
}
