/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file;

import java.util.List;

/**
 * ファイルからセキュリティルールとCORSルールを代表するクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityConfigurationFileEntity {

	/**
	 * CORSルールのリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSルールのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<GCorsConfigurationFileEntity> getCors();

	/**
	 * セキュリティルールのリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return セキュリティルールのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<GSecurityRuleFileEntity> getRules();
}
