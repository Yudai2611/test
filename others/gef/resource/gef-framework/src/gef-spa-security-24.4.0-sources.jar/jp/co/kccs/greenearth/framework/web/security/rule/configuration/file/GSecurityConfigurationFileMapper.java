/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfigurationSet;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSet;
import java.util.List;

/**
 * ファイルの代表オブジェクトからビルダーにマッピングする為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityConfigurationFileMapper {

	/**
	 * {@link GCorsConfigurationFileEntity}から{@link GCorsConfigurationSet}に変換します.<br>
	 *
	 * @create 2023/10/25
	 * @param corsConfigs ファイルから{@link GCorsConfigurationFileEntity}に変換されるオブジェクト
	 * @return {@link GCorsConfigurationSet}にマッピングされる結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsConfigurationSet mappingCors(List<GCorsConfigurationFileEntity> corsConfigs);

	/**
	 * {@link GSecurityRuleFileEntity}から{@link GSecurityRuleSet}に変換します.<br>
	 *
	 * @create 2023/10/25
	 * @param ruleConfigs ファイルから{@link GSecurityRuleFileEntity}に変換されるオブジェクト
	 * @return {@link GSecurityRuleSet}にマッピングされる結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GSecurityRuleSet mappingSecurityRule(List<GSecurityRuleFileEntity> ruleConfigs);
}
