	/*
 * Copyright 2023-2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.creation.GObjectInstantiator;
import jp.co.kccs.greenearth.commons.reflection.GReflectionHelper;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.http.GResponseCookie;
import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.GSubjectHolderProvider;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.SessionSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.context.annotation.ThreadLocalSubjectHolder;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCookieRepositoryConfigurationKeys;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepositoryProvider;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.CookieRepository;
import jp.co.kccs.greenearth.framework.web.security.csrf.annotation.SessionRepository;
import jp.co.kccs.greenearth.framework.web.security.rule.GPatternProperty;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRuleImpl;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfigurationSet;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfigurationSetImpl;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSet;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSetImpl;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.GRuleBuilderContext;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsConfigurationBuilder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.builder.cors.GCorsConfigurationSetBuilder;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.yaml.GSecurityRuleYamlEntity;
import jp.co.kccs.greenearth.framework.web.security.token.GTokenGenerator;
import jp.co.kccs.greenearth.framework.web.security.token.GUUIDTokenCreator;

/**
 *
 * @see GSecurityConfigurationFileMapper
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityConfigurationFileMapperImpl implements GSecurityConfigurationFileMapper {

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationFileMapper#mappingCors(List)
	 */
	@Override
	public GCorsConfigurationSet mappingCors(List<GCorsConfigurationFileEntity> corsConfigs) {
		GCorsConfigurationSet corsSet = new GCorsConfigurationSetImpl();
		if (Objects.nonNull(corsConfigs)) {
			List<GCorsConfigurationBuilder> corsBuilders = new ArrayList<>();
			corsConfigs.forEach(cors-> corsBuilders.add(mappingCorsInternal(cors)));
			corsSet.addAll(corsBuilders.toArray(GCorsConfigurationSetBuilder.Builder[]::new));
		}
		return corsSet;
	}
	private GCorsConfigurationBuilder mappingCorsInternal(GCorsConfigurationFileEntity cors) {
		GCorsConfigurationBuilder corsBuilder = new GCorsConfigurationSetBuilder.Builder(cors.getId());
		corsBuilder.credential(cors.isAllowCredentials());
		corsBuilder.exposedHeaders(cors.getExposeHeaders().toArray(String[]::new));
		corsBuilder.allowedOrigins(cors.getAllowOrigins().toArray(String[]::new));
		corsBuilder.allowedMethods(cors.getAllowMethods().toArray(String[]::new));
		corsBuilder.allowedHeaders(cors.getAllowHeaders().toArray(String[]::new));
		corsBuilder.maxAge(cors.getMaxAge());
		return corsBuilder;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationFileMapper#mappingSecurityRule(List) 
	 */
	@Override
	public GSecurityRuleSet mappingSecurityRule(List<GSecurityRuleFileEntity> ruleConfigs) {
		if (Objects.isNull(ruleConfigs) || ruleConfigs.isEmpty()) {
			throw new GFrameworkException("You must define at least 1 rule.");
		}
		List<GSecurityRule> securityConfigurationDetailBuilders = new ArrayList<>();
		ruleConfigs.forEach(rule -> securityConfigurationDetailBuilders.add(createSecurityRule(rule)));
		GSecurityRuleSet ruleSet = new GSecurityRuleSetImpl(securityConfigurationDetailBuilders);
		return ruleSet;
	}
	private GSecurityRule createSecurityRule(GSecurityRuleFileEntity rule) {
		GRuleBuilderContext context = new GRuleBuilderContext();
		mappingSecurityRule(rule, context);
		mappingAuthenticationRule(rule.getAuthentication(), context);
		mappingCorsRule(rule.getCors(), context);
		mappingCsrfRule(rule.getCsrf(), context);
		mappingContextHolder(rule.getContextHolder(), context);
		return context.build();
	}

	private void mappingSecurityRule(GSecurityRuleFileEntity securityRuleFileEntity, GRuleBuilderContext ruleBuilderContext) {
		List<GPatternProperty.Pattern> patterns = extractPattern(securityRuleFileEntity.getPatterns());
		if (patterns.isEmpty()) {
			throw new GFrameworkException("You must define at least 1 pattern in rule.");
		}
		ruleBuilderContext.setPatterns(patterns);
		ruleBuilderContext.setExcludes(extractPattern(securityRuleFileEntity.getExcludes()));
	}

	private void mappingAuthenticationRule(GSecurityRuleFileEntity.Authentication authentication, GRuleBuilderContext ruleBuilderContext) {
		if (Objects.nonNull(authentication) && Objects.nonNull(authentication.getProcessors())) {
			ruleBuilderContext.setAuthenticationBuilder(new GRuleBuilderContext.AuthenticationBuilder());
			ruleBuilderContext.getAuthenticationBuilder().setPatterns(extractPattern(authentication.getPatterns()));
			ruleBuilderContext.getAuthenticationBuilder().setExcludes(extractPattern(authentication.getExcludes()));
			if (Objects.nonNull(authentication.getProcessors())) {
				ruleBuilderContext.getAuthenticationBuilder().setProcessor(extractProcessor(authentication.getProcessors()));
			}
		}
	}
	private List<Class<? extends GAuthenticationProcessor>> extractProcessor(List<String> processors) {
		return processors.stream()
			.map(processor -> GReflectionHelper.classForName(processor))
			.filter(optional -> optional.isPresent())
			.map(optional -> (Class<? extends GAuthenticationProcessor>) optional.get())
			.collect(Collectors.toList());
	}

	private void mappingCsrfRule(GSecurityRuleFileEntity.Csrf csrf, GRuleBuilderContext ruleBuilderContext) {
		if (Objects.nonNull(csrf) && Objects.nonNull(csrf.getRepository())) {
			ruleBuilderContext.setCsrfBuilder(new GRuleBuilderContext.CsrfBuilder());
			ruleBuilderContext.getCsrfBuilder().setFilterPatterns(extractPattern(csrf.getPatterns()));
			ruleBuilderContext.getCsrfBuilder().setFilterExcludes(extractPattern(csrf.getExcludes()));
			if (Objects.nonNull(csrf.getRepository())) {
				ruleBuilderContext.getCsrfBuilder().setRepository(mappingCsrfRepository(csrf.getRepository(), ruleBuilderContext));
			}
			if (Objects.nonNull(csrf.getTokenIssuance())) {
				ruleBuilderContext.getCsrfBuilder().setTokenIssuancePatterns(extractPattern(csrf.getTokenIssuance().getPatterns()));
				if (Objects.nonNull(csrf.getTokenIssuance().isDisableHeaderAttachment())) {
					ruleBuilderContext.getCsrfBuilder().setDisableHeader(csrf.getTokenIssuance().isDisableHeaderAttachment().equals("true"));
				}
			}
			List<GHttpMethod> httpMethods = new ArrayList<>();
			if (Objects.nonNull(csrf.getIgnoreHttpMethods())) {
				for (String httpMethod : csrf.getIgnoreHttpMethods()) {
					httpMethods.add(GHttpMethod.valueFrom(httpMethod));
				}
				ruleBuilderContext.getCsrfBuilder().setIgnoreHttpMethods(httpMethods);
			}

		}
	}
	private GCsrfRepository mappingCsrfRepository(GSecurityRuleFileEntity.Csrf.CsrfRepository csrfRepository, GRuleBuilderContext ruleBuilderContext) {
		GCsrfRepository result = null;
		if (Objects.nonNull(csrfRepository)) {
			GSecurityRuleYamlEntity.Csrf.CsrfTokenRepository csrfRepositoryMap =
				(GSecurityRuleYamlEntity.Csrf.CsrfTokenRepository) csrfRepository;
			if (csrfRepositoryMap.containsKey("customRepository")) {
				Optional<Class<?>> repositoryClassOptional = GReflectionHelper.classForName((String) csrfRepositoryMap.get("customRepository"));
				if (repositoryClassOptional.isPresent()) {
					result = (GCsrfRepository) GObjectInstantiator.getInstance().newInstance(repositoryClassOptional.get()).get();
				}
			} else if (csrfRepositoryMap.containsKey("cookieRepository")) {
				GCsrfRepository cookieCsrfRepository = GCsrfRepositoryProvider.getInstance().getRepository(CookieRepository.class).orElseThrow(() -> new GFrameworkException(
					GFrameworkMessages.isNotFound(String.format("CsrfRepository with %s annotation", CookieRepository.class.getSimpleName()))));
				Map<String, Object> csrfConfiguration = new HashMap<>();
				if (csrfRepositoryMap.get("cookieRepository") instanceof Map) {
					Map<String, String> cookie = (Map<String, String>) csrfRepositoryMap.get("cookieRepository");
					if (cookie.containsKey("domain")) {
						csrfConfiguration.put(GCookieRepositoryConfigurationKeys.DOMAIN.getValue(), cookie.get("domain"));
					}
					if (cookie.containsKey("path")) {
						csrfConfiguration.put(GCookieRepositoryConfigurationKeys.PATH.getValue(), cookie.get("path"));
					}
					if (cookie.containsKey("httpOnly")) {
						Object httpOnly = cookie.get("httpOnly");
						csrfConfiguration.put(GCookieRepositoryConfigurationKeys.HTTP_ONLY.getValue(), httpOnly instanceof Boolean ? (boolean) httpOnly : Boolean.valueOf((String) httpOnly));
					}
					if (cookie.containsKey("sameSite")) {
						String sameSite = cookie.get("sameSite");
						if (sameSite.equals("LAX") || sameSite.equals("NONE") || sameSite.equals("STRICT")) {
							csrfConfiguration.put(GCookieRepositoryConfigurationKeys.SAME_SITE.getValue(), GResponseCookie.SameSite.valueOf(sameSite));
						} else {
							throw new GFrameworkException("SameSite value is not valid. The available values are LAX, NONE, and STRICT.");
						}
					}
					if (cookie.containsKey("secure")) {
						Object secure = cookie.get("secure");
						csrfConfiguration.put(GCookieRepositoryConfigurationKeys.SECURE.getValue(), secure instanceof Boolean ? (boolean) secure : Boolean.valueOf((String) secure));
					}
				}
				ruleBuilderContext.getCsrfBuilder().getRepositoryConfiguration().putAll(csrfConfiguration);
				result = cookieCsrfRepository;

			} else if (csrfRepositoryMap.containsKey("sessionRepository")) {
				result = GCsrfRepositoryProvider.getInstance().getRepository(SessionRepository.class).orElseThrow(() -> new GFrameworkException(
					GFrameworkMessages.isNotFound(String.format("CsrfRepository with %s annotation", SessionRepository.class.getSimpleName()))));
			}
			mappingCsrfTokenBehavior(csrfRepository, ruleBuilderContext);
		}

		return result;
	}

	private void mappingCsrfTokenBehavior(GSecurityRuleFileEntity.Csrf.CsrfRepository csrfRepositoryEntity, GRuleBuilderContext ruleBuilderContext) {
		final ObjectMapper mapper = new ObjectMapper();
		if (Objects.nonNull(((GSecurityRuleYamlEntity.Csrf.CsrfTokenRepository) csrfRepositoryEntity).get("tokenBehavior"))) {
			try {
				final GSecurityRuleYamlEntity.Csrf.CsrfTokenRepository.CsrfTokenBehaviorImpl tokenBehavior = mapper.convertValue(
					((GSecurityRuleYamlEntity.Csrf.CsrfTokenRepository) csrfRepositoryEntity).get("tokenBehavior"),
					GSecurityRuleYamlEntity.Csrf.CsrfTokenRepository.CsrfTokenBehaviorImpl.class
				);
				if (Objects.nonNull(tokenBehavior.getCreation())) {
					if (tokenBehavior.getCreation().containsKey("uuid")) {
						ruleBuilderContext.getCsrfBuilder().setTokenGenerator(new GUUIDTokenCreator());
					} else if (tokenBehavior.getCreation().containsKey("customGenerator")) {
						ruleBuilderContext.getCsrfBuilder().setTokenGenerator(
							(GTokenGenerator) GObjectInstantiator.getInstance().newInstance(
								(String) tokenBehavior.getCreation().get("customGenerator")).get());
					}
				}

				if (Objects.nonNull(tokenBehavior.getMaxAge())) {
					ruleBuilderContext.getCsrfBuilder().setMaxAge(Long.valueOf(tokenBehavior.getMaxAge()));
				}
				if (Objects.nonNull(tokenBehavior.getHeaderPrefix())) {
					ruleBuilderContext.getCsrfBuilder().setHeaderPrefix(tokenBehavior.getHeaderPrefix());
				}
				if (Objects.nonNull(tokenBehavior.getSaveTokenKey())) {
					ruleBuilderContext.getCsrfBuilder().setSaveTokenKey(tokenBehavior.getSaveTokenKey());
				}
			} catch (Exception exception) {
				throw new GFrameworkException("failed to parse token behavior");
			}


		}
	}
	private void mappingCorsRule(List<GSecurityRuleFileEntity.Cors> corsList, GRuleBuilderContext ruleBuilderContext) {
		if (!corsList.isEmpty()) {
			ruleBuilderContext.setCorsBuilder(new GRuleBuilderContext.CorsBuilder());
			corsList.forEach(cors -> {
				GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder corsBuilder = new GRuleBuilderContext.CorsBuilder.CorsConfigurationBuilder();
				corsBuilder.setPatterns(extractPattern(cors.getPatterns()));
				corsBuilder.setExcludes(extractPattern(cors.getExcludes()));
				corsBuilder.setConfigId(cors.getConfig());
				ruleBuilderContext.getCorsBuilder().addCorsConfigurationRule(corsBuilder);
			});
		}

	}

	private void mappingContextHolder(String contextHolder, GRuleBuilderContext ruleBuilderContext) {
		if (contextHolder.equalsIgnoreCase("ThreadLocal")) {
			GSubjectHolderProvider.getInstance().getSubjectHolder(ThreadLocalSubjectHolder.class).ifPresent(
				ruleBuilderContext::setContextHolder
			);
		} else if (contextHolder.equalsIgnoreCase("Session")) {
			GSubjectHolderProvider.getInstance().getSubjectHolder(SessionSubjectHolder.class).ifPresent(
				ruleBuilderContext::setContextHolder
			);
		} else {
			throw new GFrameworkException(String.format("%s is not supported.", contextHolder));
		}
	}

	private List<GSecurityRule.Pattern> extractPattern(List<Map<String, Object>> patterns) {
		List<GSecurityRule.Pattern> patternsTemp = new ArrayList<>();
		if (Objects.nonNull(patterns)) {
			for (Map<String, Object> pattern : patterns) {
				if (pattern.containsKey("uri")) {
					patternsTemp.add(new GSecurityRuleImpl.PatternUri(pattern.get("uri").toString()));
				} else if (pattern.containsKey("actionBean")) {
					String actionBean = pattern.get("actionBean").toString();
					List<String> actionMethod = Collections.emptyList();
					if (pattern.containsKey("actionMethod")) {
						actionMethod = (List<String>) pattern.get("actionMethod");
					}
					actionBean = Objects.requireNonNullElse(actionBean, "").trim();
					patternsTemp.add(new GSecurityRuleImpl.PatternActionBean(actionBean, actionMethod));
				}
			}
		}

		return patternsTemp;
	}
}