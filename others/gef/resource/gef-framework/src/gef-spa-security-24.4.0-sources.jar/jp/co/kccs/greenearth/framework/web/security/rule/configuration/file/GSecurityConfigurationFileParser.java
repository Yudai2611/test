/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file;

/**
 * ファイルを{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule}に解析する為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityConfigurationFileParser<SECURITY_CONFIG extends GSecurityConfigurationFileEntity> {

	/**
	 * ファイルを{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule}に変換します.<br>
	 *
	 * @create 2023/10/25
	 * @param filePath パースされたいファイルのパース
	 * @return パースされる結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	SECURITY_CONFIG parse(String filePath);
}
