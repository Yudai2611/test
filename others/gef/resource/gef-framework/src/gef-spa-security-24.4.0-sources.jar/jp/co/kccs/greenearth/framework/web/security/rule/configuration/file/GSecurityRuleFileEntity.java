/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file;

import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;

import java.util.List;
import java.util.Map;

/**
 * ファイルに定義されるセキュリティールールを代表します.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityRuleFileEntity {

	/**
	 * セキュリティコンテキストモードを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return セキュリティコンテキストモード.threadLocalはスレッドロカルモード,　sessionはセッションモード
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getContextHolder();

	/**
	 * 認証ルールを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return 認証ルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Authentication getAuthentication();

	/**
	 * CSRFルールを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CSRFルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Csrf getCsrf();

	/**
	 * CORSルールを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return CORSルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<Cors> getCors();

	/**
	 * セキュリティールールの許可されるパータンのリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return セキュリティールールの許可されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<Map<String, Object>> getPatterns();

	/**
	 * セキュリティールールの除外されるパータンのリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return セキュリティールールの除外されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<Map<String, Object>> getExcludes();

	/**
	 * ファイルの認証ルールを代表するクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface Authentication extends Pattern {

		/**
		 * プロセッサーのリストを取得します.<br>
		 * プロセッサーの値はパッケージ名+クラス名にすべきです.<br>
		 *
		 * @create 2023/10/25
		 * @return プロセッサーのリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<String> getProcessors();
	}

	/**
	 * ファイルのCORSルールを代表するクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface Cors extends Pattern {

		/**
		 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration}のIDを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return  {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration}のID
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		String getConfig();
	}

	/**
	 * ファイルのCSRFルールを代表するクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface Csrf extends Pattern {

		/**
		 * {@link CsrfRepository}を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return  {@link CsrfRepository}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		CsrfRepository getRepository();

		/**
		 * {@link TokenIssuance}を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return {@link TokenIssuance}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		TokenIssuance getTokenIssuance();

		/**
		 * 無職される「HttpMethod」を取得します.<br>
		 * {@link GSecurityRule.GCsrfRule#getIgnoreHttpMethods()}に書いてる通りの方針です.<br>
		 *
		 * @create 2023/10/25
		 * @return  無職される「HttpMethod」
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<String> getIgnoreHttpMethods();

		/**
		 * CSRFを生成する為のエンドポイントを提供します.<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		interface TokenIssuance {

			/**
			 * 「TokenIssuance」のパータンを取得します.<br>
			 * {@link Map}のキーはファイルにあるパータンのプロパティ名です.値はプロパティの値です.<br>
			 *
			 * @create 2023/10/25
			 * @return 「TokenIssuance」のパータン
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			List<Map<String, Object>> getPatterns();

			/**
			 * レスポンスヘッダーにCSRFトークンを追加するかどうかのフラグを取得します.<br>
			 * {@link GSecurityRule.GCsrfRule#isTokenIssuanceHeaderDisabled()} に書いてる通りの方針です.<br>
			 *
			 * @create 2023/10/25
			 * @return レスポンスヘッダーにCSRFトークンを追加するかどうかのフラグ
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			String isDisableHeaderAttachment();
		}

		/**
		 * CSRFのレポシトリー情報を持っているクラスです.<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		interface CsrfRepository {

			/**
			 * レポシトリーの生成
			 *
			 * @create 2023/10/25
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			interface CsrfTokenBehavior {

				/**
				 * リクエストヘッダーにあるCSRFトークンのヘッダ項目名の「Prefix」を取得します.<br>
				 *
				 * @create 2023/10/25
				 * @return リクエストヘッダーにあるCSRFトークンのヘッダ項目名の「Prefix」
				 * @author KCCS dhiaz chebastian
				 * @since 23.10.0
				 */
				String getHeaderPrefix();

				/**
				 * リクエストヘッダーにあるCSRFトークンのヘッダ項目名を取得します.<br>
				 *
				 * @create 2023/10/25
				 * @return リクエストヘッダーにあるCSRFトークンのヘッダ項目名
				 * @author KCCS dhiaz chebastian
				 * @since 23.10.0
				 */
				String getSaveTokenKey();

				/**
				 * CSRFトークンの有効期限を取得します.<br>
				 *
				 * @create 2023/10/25
				 * @return CSRFトークンの有効期限
				 * @author KCCS dhiaz chebastian
				 * @since 23.10.0
				 */
				String getMaxAge();

				/**
				 * トークン生成の挙動を取得します.<br>
				 *
				 * @create 2023/10/25
				 * @return トークン生成の挙動
				 * @author KCCS dhiaz chebastian
				 * @since 23.10.0
				 */
				Map<String, Object> getCreation();
			}

		}
	}

	/**
	 * セキュリティールールのパータンを代表するクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	interface Pattern {

		/**
		 * 許可されるパータンを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return 許可されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<Map<String, Object>> getPatterns();

		/**
		 * 除外されるパータンを取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return 除外されるパータン
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		List<Map<String, Object>> getExcludes();
	}
}