/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.yaml;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityRuleFileEntity;

/**
 * YAMLモードの時にこのクラスを使います.<br>
 *
 * @see GSecurityRuleFileEntity
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public abstract class GAbstractRuleYamlEntity implements GSecurityRuleFileEntity.Pattern {
	private List<Map<String, Object>> patterns;
	private List<Map<String, Object>> excludes;

	protected GAbstractRuleYamlEntity() {
		this.patterns = new ArrayList<>();
		this.excludes = new ArrayList<>();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity.Pattern#getPatterns()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<Map<String, Object>> getPatterns() {
		return patterns;
	}

	/**
	 * 許可されるパータンを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param patterns 許可されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setPatterns(List<Map<String, Object>> patterns) {
		this.patterns = patterns;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity.Pattern#getExcludes()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<Map<String, Object>> getExcludes() {
		return excludes;
	}

	/**
	 * 除外されるパータンを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param excludes 除外されるパータンのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setExcludes(List<Map<String, Object>> excludes) {
		this.excludes = excludes;
	}
}
