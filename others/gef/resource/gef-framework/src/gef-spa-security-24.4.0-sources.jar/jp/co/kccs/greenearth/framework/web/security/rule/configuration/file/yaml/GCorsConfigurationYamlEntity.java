/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.yaml;

import java.util.ArrayList;
import java.util.List;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GCorsConfigurationFileEntity;

/**
 * YAMLモードの時にこのクラスを使います.<br>
 *
 * @see GCorsConfigurationFileEntity
 */
public class GCorsConfigurationYamlEntity implements GCorsConfigurationFileEntity {
	private String id;
	private List<String> allowMethods;
	private List<String> allowOrigins;
	private List<String> allowHeaders;
	private boolean allowCredentials;
	private Integer maxAge;
	private List<String> exposeHeaders;

	public GCorsConfigurationYamlEntity() {
		allowMethods = new ArrayList<>();
		allowOrigins = new ArrayList<>();
		allowHeaders = new ArrayList<>();
		exposeHeaders = new ArrayList<>();
		maxAge = -1;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationFileEntity#getId()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public String getId() {
		return id;
	}

	/**
	 * CORSのIDを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param id CORSのID
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationFileEntity#getAllowMethods()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getAllowMethods() {
		return allowMethods;
	}

	/**
	 * CORSの「Access-Control-Allow-Methods」のリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param allowMethods CORSの「Access-Control-Allow-Methods」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setAllowMethods(List<String> allowMethods) {
		this.allowMethods = allowMethods;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationFileEntity#getAllowHeaders()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getAllowHeaders() {
		return allowHeaders;
	}

	/**
	 * CORSの「Access-Control-Allow-Headers」のリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param allowHeaders CORSの「Access-Control-Allow-Headers」のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setAllowHeaders(List<String> allowHeaders) {
		this.allowHeaders = allowHeaders;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationFileEntity#isAllowCredentials()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public boolean isAllowCredentials() {
		return allowCredentials;
	}

	/**
	 * CORSの「Access-Control-Allow-Credentials」のフラグを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param allowCredentials CORSの「Access-Control-Allow-Credentials」のフラグ
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setAllowCredentials(boolean allowCredentials) {
		this.allowCredentials = allowCredentials;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationFileEntity#getMaxAge()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public Integer getMaxAge() {
		return maxAge;
	}

	/**
	 * CORSの「Access-Control-Max-Age」を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param maxAge CORSの「Access-Control-Max-Age」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setMaxAge(Integer maxAge) {
		this.maxAge = maxAge;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationFileEntity#getExposeHeaders()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getExposeHeaders() {
		return exposeHeaders;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationFileEntity#getAllowOrigins()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<String> getAllowOrigins() {
		return allowOrigins;
	}

	/**
	 * CORSの「Access-Control-Allow-Origin」を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param allowOrigins CORSの「Access-Control-Allow-Origin」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setAllowOrigins(List<String> allowOrigins) {
		this.allowOrigins = allowOrigins;
	}

	/**
	 * CORSの「Access-Control-Expose-Headers」を設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param exposeHeaders CORSの「Access-Control-Expose-Headers」
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setExposeHeaders(List<String> exposeHeaders) {
		this.exposeHeaders = exposeHeaders;
	}

}
