/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.yaml;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GAbstractSecurityConfigurationFileCreator;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityConfigurationFileMapperImpl;

/**
 * YAMLモードの時にこのクラスを使います.<br>
 *
 * @see GAbstractSecurityConfigurationFileCreator
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityConfigurationYamlCreator extends GAbstractSecurityConfigurationFileCreator {
	public GSecurityConfigurationYamlCreator(String filePath) {
		super(filePath, new GSecurityConfigurationYamlParser(), new GSecurityConfigurationFileMapperImpl());
	}
}
