/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.yaml;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GCorsConfigurationFileEntity;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityConfigurationFileEntity;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityRuleFileEntity;

/**
 * YAMLモードの時にこのクラスを使います.<br>
 *
 * @see GSecurityConfigurationFileEntity
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityConfigurationYamlEntity implements GSecurityConfigurationFileEntity {
	@JsonDeserialize(contentAs = GCorsConfigurationYamlEntity.class)
	private List<GCorsConfigurationFileEntity> cors;
	@JsonDeserialize(contentAs = GSecurityRuleYamlEntity.class)
	private List<GSecurityRuleFileEntity> rules;

	public GSecurityConfigurationYamlEntity() {
		cors = new ArrayList<>();
		rules = new ArrayList<>();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationFileEntity#getCors()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<GCorsConfigurationFileEntity> getCors() {
		return cors;
	}

	/**
	 * CORSルールのリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param cors CORSルールのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setCors(List<GCorsConfigurationFileEntity> cors) {
		this.cors = cors;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationFileEntity#getRules()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public List<GSecurityRuleFileEntity> getRules() {
		return rules;
	}

	/**
	 * セキュリティルールのリストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param rules セキュリティルールのリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setRules(List<GSecurityRuleFileEntity> rules) {
		this.rules = rules;
	}
}
