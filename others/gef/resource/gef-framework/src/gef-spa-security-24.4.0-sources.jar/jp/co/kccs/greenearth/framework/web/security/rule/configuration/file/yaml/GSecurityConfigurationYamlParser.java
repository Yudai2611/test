/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.yaml;

import java.io.IOException;
import java.io.InputStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.utils.GFileUtils;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityConfigurationFileParser;

/**
 * YAMLモードの時にこのクラスを使います.<br>
 *
 * @see GSecurityConfigurationFileParser
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityConfigurationYamlParser implements GSecurityConfigurationFileParser<GSecurityConfigurationYamlEntity> {

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationFileParser#parse(String) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GSecurityConfigurationYamlEntity parse(String filePath) {
		ObjectMapper objectMapper = new YAMLMapper();
		try (InputStream inputStream =  GFileUtils.createURL(filePath).openStream()) {
			return objectMapper.readValue(inputStream, GSecurityConfigurationYamlEntity.class);
		} catch (IOException | IllegalArgumentException e) {
			throw new GFrameworkException(GFrameworkMessages.failedToParse(filePath), e);
		}
	}
}
