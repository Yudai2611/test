/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.yaml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityRuleFileEntity;

/**
 *
 * @see GSecurityRuleFileEntity
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityRuleYamlEntity extends GAbstractRuleYamlEntity implements GSecurityRuleFileEntity {
	@JsonDeserialize(as = Authentication.class)
	private GSecurityRuleFileEntity.Authentication authentication;
	@JsonDeserialize(as = Csrf.class)
	private GSecurityRuleFileEntity.Csrf csrf;
	@JsonDeserialize(contentAs = Cors.class)
	private List<GSecurityRuleFileEntity.Cors> cors;
	private String contextHolder;

	public GSecurityRuleYamlEntity() {
		csrf = new Csrf();
		authentication = new Authentication();
		cors = new ArrayList<>();
		contextHolder = "ThreadLocal";
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity#getContextHolder()
	 */
	@Override
	public String getContextHolder() {
		return contextHolder;
	}

	/**
	 * セキュリティコンテキストを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param contextHolder セキュリティコンテキストモード
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setContextHolder(String contextHolder) {
		this.contextHolder = contextHolder;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity#getAuthentication()
	 */
	@Override
	public GSecurityRuleFileEntity.Authentication getAuthentication() {
		return authentication;
	}

	/**
	 * 認証ルールを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param authentication 認証ルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setAuthentication(GSecurityRuleFileEntity.Authentication authentication) {
		this.authentication = authentication;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity#getCsrf()
	 */
	@Override
	public GSecurityRuleFileEntity.Csrf getCsrf() {
		return csrf;
	}

	/**
	 * CSRFルールを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param csrf CSRFルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setCsrf(GSecurityRuleFileEntity.Csrf csrf) {
		this.csrf = csrf;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity#getCors()
	 */
	@Override
	public List<GSecurityRuleFileEntity.Cors> getCors() {
		return cors;
	}

	/**
	 * CORSルールを設定します.<br>
	 *
	 * @create 2023/10/25
	 * @param cors CORSルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void setCors(List<GSecurityRuleFileEntity.Cors> cors) {
		this.cors = cors;
	}

	/**
	 *　{@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity.Authentication
	 */
	public static class Authentication extends GAbstractRuleYamlEntity implements
		GSecurityRuleFileEntity.Authentication {
		private List<String> processors;

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRuleFileEntity.Authentication#getProcessors()
		 */
		public List<String> getProcessors() {
			return processors;
		}

		/**
		 * プロセッサーのリストを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param processors プロセッサーリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setProcessor(List<String> processors) {
			this.processors = processors;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity.Csrf
	 */
	public static class Csrf extends GAbstractRuleYamlEntity implements GSecurityRuleFileEntity.Csrf {
		@JsonDeserialize(as = CsrfTokenRepository.class)
		private CsrfRepository repository;
		private List<String> ignoreHttpMethods;
		@JsonDeserialize(as = CsrfTokenIssuance.class)
		private TokenIssuance tokenIssuance;

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRuleFileEntity.Csrf#getRepository()
		 */
		@Override
		public CsrfRepository getRepository() {
			return repository;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRuleFileEntity.Csrf#getTokenIssuance()
		 */
		@Override
		public TokenIssuance getTokenIssuance() {
			return tokenIssuance;
		}

		/**
		 * {@link jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository}を設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param repository {@link jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfRepository}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setRepository(CsrfRepository repository) {
			this.repository = repository;
		}

		/**
		 * 無職される「HttpMethod」を設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param ignoreHttpMethods 無職される「HttpMethod」
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setIgnoreHttpMethods(List<String> ignoreHttpMethods) {
			this.ignoreHttpMethods = ignoreHttpMethods;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRuleFileEntity.Csrf#getIgnoreHttpMethods()
		 */
		@Override
		public List<String> getIgnoreHttpMethods() {
			return ignoreHttpMethods;
		}

		/**
		 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityRuleFileEntity.Csrf.TokenIssuance}を設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param tokenIssuance {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.file.GSecurityRuleFileEntity.Csrf.TokenIssuance}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setTokenIssuance(
			TokenIssuance tokenIssuance) {
			this.tokenIssuance = tokenIssuance;
		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRuleFileEntity.Csrf.TokenIssuance
		 */
		public static class CsrfTokenIssuance implements GSecurityRuleFileEntity.Csrf.TokenIssuance {
			private List<Map<String, Object>> patterns;
			private String disableHeaderAttachment;

			/**
			 * {@inheritDoc}
			 *
			 * @see TokenIssuance#getPatterns()
			 */
			@Override
			public List<Map<String, Object>> getPatterns() {
				return patterns;
			}

			/**
			 * {@inheritDoc}
			 *
			 * @see TokenIssuance#isDisableHeaderAttachment()
			 */
			@Override
			public String isDisableHeaderAttachment() {
				return disableHeaderAttachment;
			}

			/**
			 * 「TokenIssuance」のパータンを設定します.<br>
			 * {@link Map}のキーはファイルにあるパータンのプロパティ名です.値はプロパティの値です.<br>
			 *
			 * @create 2023/10/25
			 * @param patterns 許可されるパータンのリスト
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public void setPatterns(List<Map<String, Object>> patterns) {
				this.patterns = patterns;
			}

			/**
			 * レスポンスヘッダーにCSRFトークンを追加するかどうかのフラグを設定します.<br>
			 * {@link GSecurityRule.GCsrfRule#isTokenIssuanceHeaderDisabled()} に書いてる通りの方針です.<br>
			 *
			 * @create 2023/10/25
			 * @param disableHeaderAttachment レスポンスヘッダーにCSRFトークンを追加するかどうかのフラグ
			 * @author KCCS dhiaz chebastian
			 * @since 23.10.0
			 */
			public void setDisableHeaderAttachment(String disableHeaderAttachment) {
				this.disableHeaderAttachment = disableHeaderAttachment;
			}

		}

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRuleFileEntity.Csrf.CsrfRepository
		 */
		public static class CsrfTokenRepository extends HashMap<String, Object> implements GSecurityRuleFileEntity.Csrf.CsrfRepository {

			/**
			 * {@inheritDoc}
			 *
			 * @see CsrfTokenBehavior
			 */
			public static class CsrfTokenBehaviorImpl implements CsrfTokenBehavior {
				private String headerPrefix;
				private String saveTokenKey;
				private String maxAge;
				private Map<String, Object> creation;

				/**
				 *　{@inheritDoc}
				 *
				 * @see CsrfTokenBehavior#getHeaderPrefix()
				 */
				@Override
				public String getHeaderPrefix() {
					return headerPrefix;
				}

				/**
				 * {@inheritDoc}
				 *
				 * @see CsrfTokenBehavior#getSaveTokenKey()
				 */
				@Override
				public String getSaveTokenKey() {
					return saveTokenKey;
				}

				/**
				 * {@inheritDoc}
				 *
				 * @see CsrfTokenBehavior#getMaxAge()
				 */
				@Override
				public String getMaxAge() {
					return maxAge;
				}

				/**
				 * {@inheritDoc}
				 *
				 * @see CsrfTokenBehavior#getCreation()
				 */
				@Override
				public Map<String, Object> getCreation() {
					return creation;
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleFileEntity.Cors
	 */
	public static class Cors extends GAbstractRuleYamlEntity implements GSecurityRuleFileEntity.Cors {
		private String config;

		/**
		 * {@inheritDoc}
		 *
		 * @see GSecurityRuleFileEntity.Cors#getConfig()
		 */
		public String getConfig() {
			return config;
		}

		/**
		 * CORSコンフィグレーションのIDを設定します.<br>
		 *
		 * @create 2023/10/25
		 * @param configId CORSコンフィグレーションのID
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public void setConfig(String configId) {
			this.config = configId;
		}

	}
}
