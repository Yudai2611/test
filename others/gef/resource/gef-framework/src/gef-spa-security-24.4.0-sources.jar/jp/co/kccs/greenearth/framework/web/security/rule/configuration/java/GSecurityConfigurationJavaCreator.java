/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.configuration.java;

import java.util.List;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.priority.GPrioritySorter;
import jp.co.kccs.greenearth.commons.service.GScanComponentService;
import jp.co.kccs.greenearth.commons.service.Modifier;
import jp.co.kccs.greenearth.commons.service.ScanConfiguration;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfigurationSet;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfigurationSetImpl;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfigurationCreator;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSet;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityRuleSetImpl;

/**
 * JAVAモードの時にこのクラスを使います.<br>
 *
 * @see GSecurityConfigurationCreator
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
@ScanConfiguration(
	modifiers = {
			@Modifier(isPublic = true)
	},
	scannedAssignableTypes = GSecurityConfiguration.class
)
public class GSecurityConfigurationJavaCreator implements GSecurityConfigurationCreator {
	private GSecurityConfiguration webSecurityConfiguration;
	private void scanConfiguration() {
		if (Objects.isNull(webSecurityConfiguration)) {
			webSecurityConfiguration = getWebSecurityConfigurationByPriority();
		}
	}

	private GSecurityConfiguration getWebSecurityConfigurationByPriority() {
		List<GSecurityConfiguration> securityConfigurations = GFrameworkUtils.getComponent(GScanComponentService.class).getScannedInstances(this.getClass());
		if (securityConfigurations.isEmpty()) {
			return null;
		}
		return GPrioritySorter.sortByInstance(securityConfigurations).get(0);

	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationCreator#loadRules()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<GSecurityRule> loadRules() {
		scanConfiguration();
		GSecurityRuleSet securityRuleGroup = new GSecurityRuleSetImpl();
		if (Objects.nonNull(webSecurityConfiguration)) {
			webSecurityConfiguration.configure(securityRuleGroup);
		}
		List<GSecurityRule> rules = securityRuleGroup.getSecurityRules();
		if (rules.isEmpty()) {
			throw new GFrameworkException("You must define at least 1 rule.");
		}
		return rules;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityConfigurationCreator#loadCors()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<GCorsConfiguration> loadCors() {
		scanConfiguration();
		GCorsConfigurationSet corsConfigurationGroup = new GCorsConfigurationSetImpl();
		if (Objects.nonNull(webSecurityConfiguration)) {
			webSecurityConfiguration.configure(corsConfigurationGroup);
		}
		return corsConfigurationGroup.getCorsConfigurations();
	}
}
