/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.matcher;

import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.framework.web.security.rule.GRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;

/**
 * {@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule.GAuthenticationRule}と一致するかどうか検証する為のクラスです.<br>
 *
 * @see GRuleMatcher
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GAuthenticationRuleMatcher implements GRuleMatcher<GSecurityRule.GAuthenticationRule> {

	/**
	 * {@inheritDoc}
	 *
	 * @see GRuleMatcher#match(HttpServletRequest, GRule) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule.GAuthenticationRule> match(HttpServletRequest httpServletRequest, GSecurityRule.GAuthenticationRule authenticationRule) {
		if (Objects.nonNull(authenticationRule)) {
			if (authenticationRule.getPatterns().isEmpty() && authenticationRule.getExcludePatterns().isEmpty()) {
				return Optional.of(authenticationRule);
			}
			if (isMatchPattern(httpServletRequest, authenticationRule.getPatterns()) && !isMatchExcludedPattern(httpServletRequest, authenticationRule.getExcludePatterns())) {
				return Optional.of(authenticationRule);
			}
		}

		return Optional.empty();
	}
}
