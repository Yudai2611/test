/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.matcher;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.framework.web.security.rule.GRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRuleImpl;

/**
 * {@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule.GCorsRule}と一致するかどうか検証する為のクラスです.<br>
 *
 * @see GRuleMatcher
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCorsRuleMatcher implements GRuleMatcher<GSecurityRule.GCorsRule> {

	/**
	 * {@inheritDoc}
	 *
	 * @see GRuleMatcher#match(HttpServletRequest, GRule) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule.GCorsRule> match(HttpServletRequest httpServletRequest, GSecurityRule.GCorsRule corsRule) {
 		if (Objects.nonNull(corsRule)) {
			for (GSecurityRule.GCorsConfigurationRule corsConfigurationRule : corsRule.getCorsConfigurations()) {
				if (corsConfigurationRule.getPatterns().isEmpty() && corsConfigurationRule.getExcludePatterns().isEmpty()) {
					return Optional.of(new GSecurityRuleImpl.GCorsRule(List.of(corsConfigurationRule)));
				}
				if (isMatchPattern(httpServletRequest, corsConfigurationRule.getPatterns()) && !isMatchExcludedPattern(httpServletRequest, corsConfigurationRule.getExcludePatterns())
				) {
					return Optional.of(new GSecurityRuleImpl.GCorsRule(List.of(corsConfigurationRule)));
				}
			}
		}

		return Optional.empty();
	}
}
