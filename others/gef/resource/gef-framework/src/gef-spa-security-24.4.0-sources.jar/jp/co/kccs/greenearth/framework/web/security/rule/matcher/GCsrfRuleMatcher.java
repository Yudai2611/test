/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.matcher;

import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.framework.web.http.GHttpMethod;
import jp.co.kccs.greenearth.framework.web.security.csrf.GCsrfTokenIssuanceShadowEndpoint;
import jp.co.kccs.greenearth.framework.web.security.rule.GRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.registry.GSecurityRuleRegistry;

/**
 * {@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule.GCsrfRule}と一致するかどうか検証する為のクラスです.<br>
 *
 * @see GRuleMatcher
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCsrfRuleMatcher implements GRuleMatcher<GSecurityRule.GCsrfRule> {

	/**
	 * {@inheritDoc}
	 *
	 * @see GRuleMatcher#match(HttpServletRequest, GRule)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule.GCsrfRule> match(HttpServletRequest httpServletRequest, GSecurityRule.GCsrfRule csrfRule) {
		if (Objects.nonNull(csrfRule)) {
			if (isIgnoreMethods(httpServletRequest, csrfRule)) {
				return Optional.empty();
			}
			if (csrfRule.getPatterns().isEmpty() && csrfRule.getExcludePatterns().isEmpty()) {
				return Optional.of(csrfRule);
			}
			if (isMatchPattern(httpServletRequest, csrfRule.getPatterns()) && !isMatchExcludedPattern(httpServletRequest, csrfRule.getExcludePatterns())) {
				return Optional.of(csrfRule);
			}
		}
		return Optional.empty();
	}
	private boolean isIgnoreMethods(HttpServletRequest httpServletRequest, GSecurityRule.GCsrfRule csrfRule) {
		for (GHttpMethod httpMethod : csrfRule.getIgnoreHttpMethods()) {
			if (httpMethod.name().equalsIgnoreCase(httpServletRequest.getMethod())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 「TokenIssuancePattern」と一致するかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param httpServletRequest リクエスト
	 * @param csrfRule 一致したCSRFルール
	 * @return 「TokenIssuancePattern」と一致したのCSRFルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public Optional<GSecurityRule.GCsrfRule> matchTokenIssuance(HttpServletRequest httpServletRequest, GSecurityRule.GCsrfRule csrfRule) {
		if (Objects.nonNull(csrfRule)) {
			if (
				(isMatchPattern(httpServletRequest, csrfRule.getTokenIssuancePatterns()) || isMatchRewriteUrlPattern(httpServletRequest)) && !csrfRule.getTokenIssuancePatterns().isEmpty()
			) {
				return Optional.of(csrfRule);
			}
		}
		return Optional.empty();
	}
	private boolean isMatchRewriteUrlPattern(HttpServletRequest request) {
		String uri = request.getRequestURI().substring(request.getContextPath().length());
		return GCsrfTokenIssuanceShadowEndpoint.class.getCanonicalName().equals(uri);
	}


	/**
	 * CSRFルールで「TokenIssuance」パータンは一致するかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return 検証結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public boolean isMatchTokenIssuancePattern(HttpServletRequest request) {
		return getTokenIssuanceMatchedPatternRule(request).isPresent();
	}
	/**
	 * 一致するCSRFルールから「TokenIssuance」パータンを取ってきます.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return 「tokenIssuance」パータンと一致するCSRFルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public Optional<GSecurityRule.GCsrfRule> getTokenIssuanceMatchedPatternRule(HttpServletRequest request) {
		Optional<GSecurityRule> securityRule = GSecurityRuleRegistry.Factory.getInstance().lookup(request);
		if (securityRule.isPresent()) {
			Optional<GSecurityRule.GCsrfRule> rule = matchTokenIssuance(request,
					securityRule.get().getCsrfRule());
			return rule;
		}
		return Optional.empty();
	}
}
