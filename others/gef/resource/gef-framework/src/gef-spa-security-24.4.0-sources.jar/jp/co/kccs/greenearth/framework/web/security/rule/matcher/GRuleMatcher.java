/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.matcher;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.http.protocol.UriPatternMatcher;

import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairExtractor;
import jp.co.kccs.greenearth.framework.web.resource.extract.GResourceKeyPairProvider;
import jp.co.kccs.greenearth.framework.web.security.rule.GRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;

/**
 * {@link GRule}でマーカーされるセキュリティールールが一致するかどうかを検証する為のクラスです.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GRuleMatcher<RULE extends GRule> {

	/**
	 * 渡されるセキュリティールールのパータンと{@link HttpServletRequest}は一致するかどうか検証します.<br>
	 * 検証する判断は許可されるパータンと除外されるパータンによるです.<br>
	 * 一致する条件は「許可されるパータンと一致する」AND「除外されるパータンと一致しない」です.
	 *
	 *
	 * @create 2023/10/25
	 * @param httpServletRequest リクエスト
	 * @param rule 一致ルール
	 * @return パータンと一致ルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<RULE> match(HttpServletRequest httpServletRequest, RULE rule);

	/**
	 * 許可されるパータンと一致するかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param httpServletRequest リクエスト
	 * @param patterns 許可されるパータンのリスト
	 * @return 検証結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	default boolean isMatchPattern(HttpServletRequest httpServletRequest, List<GSecurityRule.Pattern> patterns) {
		if (patterns.isEmpty()) {
			return true;
		}
		return isMatchInternal(httpServletRequest, patterns);
	}

	/**
	 * 除外されるパータンと一致するかどうか検証します.<br>
	 *
	 * @create 2023/10/25
	 * @param httpServletRequest リクエスト
	 * @param patterns 除外されるパータン
	 * @return 検証結果
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	default boolean isMatchExcludedPattern(HttpServletRequest httpServletRequest, List<GSecurityRule.Pattern> patterns) {
		if (patterns.isEmpty()) {
			return false;
		}
		return isMatchInternal(httpServletRequest, patterns);
	}
	private boolean isMatchActionInternal(String actionBean, String actionMethod, GSecurityRule.PatternActionBean securityConfigurationPatternAction) {
		if (Objects.nonNull(actionBean) && Objects.nonNull(actionMethod)) {
			if (isMatchActionBean(actionBean, securityConfigurationPatternAction) && securityConfigurationPatternAction.getActionMethods().isEmpty()) {
				return true;
			}
			for (String actionMethodValue : securityConfigurationPatternAction.getActionMethods()) {
				Pattern pattern = Pattern.compile(actionMethodValue);
				Matcher matcher = pattern.matcher(actionMethod);
				if (isMatchActionBean(actionBean, securityConfigurationPatternAction) && matcher.matches()) {
					return true;
				}
			}
		}
		return false;
	}

	private boolean isMatchActionBean(String actionBean, GSecurityRule.PatternActionBean securityConfigurationPatternAction) {
		return (
			actionBean.equals(securityConfigurationPatternAction.getActionBean())
				||
				securityConfigurationPatternAction.getActionBean().equals("*"));
	}


	private boolean isMatchAction(HttpServletRequest request, GSecurityRule.PatternActionBean patternActionBean) {
		GResourceKeyPairExtractor.GResourceKeyPair resourceKeyPair = GResourceKeyPairProvider.getInstance().extract(request);
		return isMatchActionInternal(resourceKeyPair.getFirst(), resourceKeyPair.getSecond(), patternActionBean);
	}

	private boolean isMatchUri(HttpServletRequest request, GSecurityRule.PatternUri patternUri) {
		if (Objects.nonNull(patternUri)) {
			UriPatternMatcher<String> patternMatcher = new UriPatternMatcher<>();
			patternMatcher.register(patternUri.getUri(), patternUri.getUri());
			String uri = request.getRequestURI().substring(request.getContextPath().length());
			return Objects.nonNull(patternMatcher.lookup(uri));
		}
		return false;
	}

	private boolean isMatchInternal(HttpServletRequest httpServletRequest, List<GSecurityRule.Pattern> patterns) {
		for (GSecurityRule.Pattern pattern : patterns) {
			if ((pattern instanceof GSecurityRule.PatternUri && isMatchUri(httpServletRequest, (GSecurityRule.PatternUri) pattern))
				||
				(pattern instanceof GSecurityRule.PatternActionBean && isMatchAction(httpServletRequest, (GSecurityRule.PatternActionBean) pattern))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * {@link GRule}でマーカーされるクラスを{@link GRuleMatcher}の実装にマッピングするクラスです.<br>
	 * デフォルトで下記のようなペアーを用意します.
	 * [1] {@link GSecurityRule.GAuthenticationRule}→{@link GAuthenticationRuleMatcher}
	 * [2] {@link GSecurityRule.GCsrfRule}→{@link GCsrfRuleMatcher}
	 * [3] {@link GSecurityRule.GCorsRule}→{@link GCorsRuleMatcher}
	 * [4] {@link GSecurityRule}→{@link GSecurityRuleMatcher}
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	class Provider {
		private static Map<Class<? extends GRule>, GRuleMatcher<? extends GRule>> ruleMatcherStrategyMap = Map.of(
			GSecurityRule.GAuthenticationRule.class, new GAuthenticationRuleMatcher(),
			GSecurityRule.GCorsRule.class, new GCorsRuleMatcher(),
			GSecurityRule.GCsrfRule.class, new GCsrfRuleMatcher(),
			GSecurityRule.class, new GSecurityRuleMatcher()
		);
		private Provider() {
		}

		/**
		 * 渡される{@link GRule}({@link Class}タイプ型)を{@link GRuleMatcher}にマッピングします.<br>
		 *
		 * @create 2023/10/25
		 * @param ruleClazz 探したいルールのクラス
		 * @return 渡されたルールクラスと一致した {@link GRuleMatcher}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@SuppressWarnings("unchecked")
		public static <T extends GRule> GRuleMatcher<T> getMatcherOf(Class<T> ruleClazz) {
			return (GRuleMatcher<T>) ruleMatcherStrategyMap.get(ruleClazz);
		}

		/**
		 * 渡される{@link GRule}({@link Object}タイプ型)を{@link GRuleMatcher}にマッピングします.<br>
		 *
		 * @create 2023/10/25
		 * @param ruleClazz 探したいルールのオブジェクト
		 * @return 渡されたルールクラスと一致した {@link GRuleMatcher}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		@SuppressWarnings("unchecked")
		public static <T extends GRule> GRuleMatcher<T> getMatcherOf(T ruleClazz) {
			return (GRuleMatcher<T>) getMatcherOf(ruleClazz.getClass());
		}
	}
}
