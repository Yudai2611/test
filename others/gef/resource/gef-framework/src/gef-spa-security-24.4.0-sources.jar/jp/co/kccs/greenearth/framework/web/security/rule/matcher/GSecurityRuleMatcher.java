/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.matcher;

import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.framework.web.security.rule.GRule;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;

/**
 * {@link GSecurityRule}と一致するかどうか検証する為のクラスです.<br>
 *
 * @see GRuleMatcher
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityRuleMatcher implements GRuleMatcher<GSecurityRule> {

	/**
	 * {@inheritDoc}
	 *
	 * @see GRuleMatcher#match(HttpServletRequest, GRule) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule> match(HttpServletRequest httpServletRequest, GSecurityRule securityRule) {
		if (isMatchPattern(httpServletRequest, securityRule.getPatterns()) && !isMatchExcludedPattern(httpServletRequest, securityRule.getExcludePatterns())) {
			return Optional.of(securityRule);
		}
		return Optional.empty();
	}

}
