/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.registry;

import java.util.List;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;

/**
 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration}とYAMLに定義されたCORSコンフィグレーションは{@link GCorsConfiguration}に変換したものをこのクラスに保管されます.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GCorsConfigurationRegistry {

	/**
	 * {@link GCorsConfiguration}を登録します.<br>
	 *
	 * @create 2023/10/25
	 * @param corsConfiguration 登録されたい{@link GCorsConfiguration}
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	void register(GCorsConfiguration corsConfiguration);

	/**
	 * 渡される「ID」で、一致される{@link GCorsConfiguration}を探しに行きます.<br>
	 *
	 * @create 2023/10/25
	 * @param corsConfigurationId {@link GCorsConfiguration}のID
	 * @return IDと一致した{@link GCorsConfiguration}オブジェクト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GCorsConfiguration lookup(String corsConfigurationId);

	/**
	 * {@link GCorsConfigurationRegistry}を作成するクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	class Factory {
		private static GCorsConfigurationRegistry corsConfigurationProvider;
		private Factory() {
			//
		}

		/**
		 * 渡される{@link GCorsConfiguration}のリストで{@link GCorsConfigurationRegistry}を作成します.作成されたオブジェクトはキャシューに保管します.<br>
		 *
		 * @create 2023/10/25
		 * @param corsConfiguration {@link GCorsConfiguration}のリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public static void createInstance(List<GCorsConfiguration> corsConfiguration) {
			corsConfigurationProvider = new GCorsConfigurationRegistryImpl(corsConfiguration);
		}

		/**
		 * キャシューから作成された{@link GCorsConfigurationRegistry}を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return キャシューからの {@link GCorsConfigurationRegistry}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public static GCorsConfigurationRegistry getInstance() {
			if (Objects.isNull(corsConfigurationProvider)) {
				throw new GFrameworkException(GFrameworkMessages.mustBeInitialized(GCorsConfigurationRegistry.class.getName()));
			}
			return corsConfigurationProvider;
		}

		/**
		 * キャシューにある{@link GCorsConfigurationRegistry}を削除します.<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public static void clearInstance() {
			corsConfigurationProvider = null;
		}
	}
}
