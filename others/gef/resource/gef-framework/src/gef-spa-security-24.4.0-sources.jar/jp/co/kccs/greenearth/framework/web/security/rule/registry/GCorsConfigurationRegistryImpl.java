/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.registry;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import jp.co.kccs.greenearth.commons.GFrameworkException;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.web.security.rule.configuration.GCorsConfiguration;

/**
 * 
 * @see GCorsConfigurationRegistry
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GCorsConfigurationRegistryImpl implements GCorsConfigurationRegistry {
	private final Map<String, GCorsConfiguration> corsConfigurationMap = new HashMap<>();
	public GCorsConfigurationRegistryImpl(List<GCorsConfiguration> corsConfigurations) {
		corsConfigurations.forEach(corsConfiguration -> {
			if (Objects.nonNull(corsConfigurationMap.get(corsConfiguration.getCorsId()))) {
				throw new GFrameworkException(GFrameworkMessages.isDuplicated(String.format("Cors ID (%s)", corsConfiguration.getCorsId())));
			}
			corsConfigurationMap.put(corsConfiguration.getCorsId(), corsConfiguration);
		});
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationRegistry#register(GCorsConfiguration) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public void register(GCorsConfiguration corsConfiguration) {
		corsConfigurationMap.put(corsConfiguration.getCorsId(), corsConfiguration);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GCorsConfigurationRegistry#lookup(String) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	public GCorsConfiguration lookup(String corsConfigurationId) {
		return corsConfigurationMap.get(corsConfigurationId);
	}

}
