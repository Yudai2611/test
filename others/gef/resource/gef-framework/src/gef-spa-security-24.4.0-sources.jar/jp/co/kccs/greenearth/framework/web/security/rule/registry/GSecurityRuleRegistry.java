/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.registry;

import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;

import jakarta.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * {@link jp.co.kccs.greenearth.framework.web.security.rule.configuration.GSecurityConfiguration}とYAMLに定義されたセキュリティールールは{@link GSecurityRule}に変換したものをこのクラスに保管されます.<br>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GSecurityRuleRegistry {

	/**
	 * 保管された{@link GSecurityRule}のリストを取得します.<br>
	 *
	 * @create 2023/10/25
	 * @return {@link GSecurityRule}のリスト
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	List<GSecurityRule> lookupAll();

	/**
	 * 渡される{@link HttpServletRequest}によって、一致されるルールの{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule.GAuthenticationRule}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return リクエストと一致した認証ルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GSecurityRule.GAuthenticationRule> lookupAuthentication(HttpServletRequest request);

	/**
	 * 渡される{@link HttpServletRequest}によって、一致されるルールの{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule.GCorsRule}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return リクエストと一致したCORSルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GSecurityRule.GCorsRule> lookupCors(HttpServletRequest request);

	/**
	 * 渡される{@link HttpServletRequest}によって、一致されるルールの{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule.GCsrfRule}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return リクエストと一致したCSRFルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GSecurityRule.GCsrfRule> lookupCsrf(HttpServletRequest request);

	/**
	 * 渡される{@link HttpServletRequest}によって、一致されるルールの{@link jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule}を取得します.<br>
	 *
	 * @create 2023/10/25
	 * @param request リクエスト
	 * @return リクエストと一致したセキュリティルール
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Optional<GSecurityRule> lookup(HttpServletRequest request);

	/**
	 * {@link GSecurityRuleRegistry}を作成するクラスです.<br>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	class Factory {
		private static GSecurityRuleRegistry securityRuleRegistry;
		private Factory() {

		}

		/**
		 * 渡される{@link GSecurityRule}のリストで{@link GSecurityRuleRegistry}を作成します.作成されたオブジェクトはキャシューに保管します.<br>
		 *
		 * @create 2023/10/25
		 * @param securityRules {@link GSecurityRule}のリスト
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public static void createInstance(List<GSecurityRule> securityRules) {
			securityRuleRegistry = new GSecurityRuleRegistryImpl(securityRules);
		}

		/**
		 * キャシューから作成された{@link GSecurityRuleRegistry}を取得します.<br>
		 *
		 * @create 2023/10/25
		 * @return キャシューから {@link GSecurityRuleRegistry}
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public static GSecurityRuleRegistry getInstance() {
			if (Objects.isNull(securityRuleRegistry)) {
				securityRuleRegistry = new GSecurityRuleRegistryImpl(new ArrayList<>());
			}
			return securityRuleRegistry;
		}

		/**
		 * キャシューにある{@link GSecurityRuleRegistry}を削除します.<br>
		 *
		 * @create 2023/10/25
		 * @author KCCS dhiaz chebastian
		 * @since 23.10.0
		 */
		public static void clearInstance() {
			if (Objects.nonNull(securityRuleRegistry)) {
				securityRuleRegistry.lookupAll().clear();
				securityRuleRegistry = null;
			}
		}
	}
}
