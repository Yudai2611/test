/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.web.security.rule.registry;


import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;
import jp.co.kccs.greenearth.framework.web.security.rule.GSecurityRule;
import jp.co.kccs.greenearth.framework.web.security.rule.matcher.GRuleMatcher;

/**
 *
 * @see GSecurityRuleRegistry
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GSecurityRuleRegistryImpl implements GSecurityRuleRegistry {
	private final GSecurityRuleProvider securityRuleProvider;
	public GSecurityRuleRegistryImpl(List<GSecurityRule> securityRules) {
		securityRuleProvider = new GSecurityRuleProvider(securityRules);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleRegistry#lookupAll() 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public List<GSecurityRule> lookupAll() {
		return securityRuleProvider.getSecurityRules();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleRegistry#lookupAuthentication(HttpServletRequest) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule.GAuthenticationRule> lookupAuthentication(HttpServletRequest request) {
		Optional<GSecurityRule> securityRule = lookupInternal(request);
		return securityRule.map(GSecurityRule::getAuthenticationRule);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleRegistry#lookupCors(HttpServletRequest) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule.GCorsRule> lookupCors(HttpServletRequest request) {
		Optional<GSecurityRule> securityRule = lookupInternal(request);
		return securityRule.map(GSecurityRule::getCorsRule);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleRegistry#lookupCsrf(HttpServletRequest) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule.GCsrfRule> lookupCsrf(HttpServletRequest request) {
		Optional<GSecurityRule> securityRule = lookupInternal(request);
		return securityRule.map(GSecurityRule::getCsrfRule);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GSecurityRuleRegistry#lookup(HttpServletRequest) 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Optional<GSecurityRule> lookup(HttpServletRequest request) {
		return lookupInternal(request);
	}

	private Optional<GSecurityRule> lookupInternal(HttpServletRequest request) {
		for (GSecurityRule securityRule : GSecurityRuleRegistry.Factory.getInstance().lookupAll()) {
			if (Objects.nonNull(securityRule)) {
				Optional<GSecurityRule> rule = GRuleMatcher.Provider.getMatcherOf(GSecurityRule.class).match(request, securityRule);
				if (rule.isPresent()) {
					return rule;
				}
			}
		}
		return Optional.empty();
	}

	private static class GSecurityRuleProvider {
		private final List<GSecurityRule> securityRules;

		GSecurityRuleProvider(List<GSecurityRule> securityRules) {
			this.securityRules = securityRules;
		}

		public List<GSecurityRule> getSecurityRules() {
			if (Objects.isNull(securityRules)) {
				return Collections.emptyList();
			}
			return securityRules;
		}
	}

}
