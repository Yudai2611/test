/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.token;

import java.time.Instant;

/**
 * セキュリティ為のトークン文字列と期限切れを持ってるオブジェクト.<br/>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GToken {

	/**
	 * トークンの最大期限を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Long getMaxAge();

	/**
	 * 創造日付を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	Instant getCreationDate();

	/**
	 * トークン文字列を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	String getToken();

	/**
	 * トークンの有無状態を取得します.<br/>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	boolean isValid();
}
