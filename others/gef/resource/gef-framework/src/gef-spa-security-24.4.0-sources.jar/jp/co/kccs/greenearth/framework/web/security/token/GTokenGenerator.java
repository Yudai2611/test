/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.token;

/**
 * {@link GToken}を生成する為のクラスです.<br/>
 *
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public interface GTokenGenerator {

	/**
	 * {@link GToken}を生成する.<br/>
	 *
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	GToken generate(long maxAge);
}
