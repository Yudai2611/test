/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.token;

import java.time.Instant;

/**
 * {@link GToken}の実装クラスです.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GTokenImpl implements GToken {
	/** トークン文字列　**/
	private String token;
	/** トークンの最大期限 **/
	private Long maxAge;
	/** トークンの創造日付 **/
	private Instant creationTime;
	public GTokenImpl(String token, long maxAge) {
		this.token = token;
		this.maxAge = maxAge;
		this.creationTime = Instant.now();
	}

	/**
	 * {@inheritDoc}
	 * 最大期限の単位は秒です.<br/>
	 *
	 * @see GToken#getMaxAge()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Long getMaxAge() {
		return maxAge;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GToken#getCreationDate()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public Instant getCreationDate() {
		return creationTime;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see GToken#getToken()
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public String getToken() {
		return token;
	}

	/**
	 * トークンの有無状態を取得します.<br/>
	 * 有無状態は「創造日付 + 最大期限」< 検証時間、又は最大期限は0以下.その中の一つの条件が「true」の場合、トークンは有効になります.<br/>
	 * 最大期限は0の場合、いつも「false」になります.<br/>
	 *
	 * @see GToken#isValid() 
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public boolean isValid() {
		return  (Instant.now().isBefore(creationTime.plusSeconds(maxAge))) || maxAge < 0;
	}
}
