/*
 * Copyright 2023 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.web.security.token;

import java.util.UUID;

/**
 * {@link GToken}の文字列にUUIDフォーマットで生成するためのクラスです.<br/>
 * 
 * @create 2023/10/25
 * @author KCCS dhiaz chebastian
 * @since 23.10.0
 */
public class GUUIDTokenCreator implements GTokenGenerator {

	/**
	 * {@link GToken}の文字列にUUIDフォーマットで生成します.<br/>
	 *
	 * @see GTokenGenerator#generate(long)
	 * @create 2023/10/25
	 * @author KCCS dhiaz chebastian
	 * @since 23.10.0
	 */
	@Override
	public GToken generate(long maxAge) {
		return new GTokenImpl(UUID.randomUUID().toString(), maxAge);
	}
}
