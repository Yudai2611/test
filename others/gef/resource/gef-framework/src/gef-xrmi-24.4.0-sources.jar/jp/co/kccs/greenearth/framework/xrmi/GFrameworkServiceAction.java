package jp.co.kccs.greenearth.framework.xrmi;

import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;

/**
 * フレームワークがサーバーサイドに持つ情報を取得するアクションです。<br>
 * 主にプロパティ等で設定された値をクライアントから参照したい場合に利用します。
 * 
 * @create 2011/07/30
 * @author KCCS kitamura
 * @since 3.9.0
 */
public class GFrameworkServiceAction {
	
	/**
	 * {@link GFrameworkServiceAction}インスタンスを初期化します。
	 * 
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GFrameworkServiceAction() {
	}

	/**
	 * システムが取り扱い対象としているロケールのリストを取得します。<br>
	 * {@link GFrameworkUtils#getTargetLocaleList()}の結果を返します。
	 * 
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @create 2011/07/30
	 * @author KCCS kitamura
	 * @since 3.9.0
	 */
	public GResultData getTargetLocaleList(GParameter parameter, GResultData resultData) {
		List<Locale> localeList = GFrameworkUtils.getTargetLocaleList();
		resultData.setData("LocaleList", localeList);
		return resultData;
	}

}
