/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.tools.GStopWatch;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GResponseFilter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;

/**
 * サーバー-クライアント間の通信にXMLを利用するアプリケーションからのリクエストに対応した、
 * {@link jp.co.kccs.greenearth.framework.GResponseFilter}実装です。<br>
 * 
 * {@link jp.co.kccs.greenearth.framework.xrmi.serialize.data.GResultDataSerializer}を利用して、
 * ビジネスロジックの処理結果である{@link jp.co.kccs.greenearth.framework.data.GResultData}の値をXMLにシリアライズし、
 * その内容をレスポンスとしてクライアントに返します。<br>
 * {@link jp.co.kccs.greenearth.framework.data.GResultData}内に格納された各種データは、その型(クラス)に応じて、対応するシリアライザクラスによってXMLにシリアライズされます。
 * 型に対応するシリアライザの関連付けはDI定義ファイルにて行います。<br>
 * 詳細は{@link GXmlSerializerFactory}を参照してください。<br>
 * <br>
 * 
 * <b>【システムエラー時の処理】</b><br>
 * {@link #writeErrorResponse(HttpServletRequest, HttpServletResponse, GParameter, Throwable)}メソッドを呼び出すか、
 * 処理結果である{@link jp.co.kccs.greenearth.framework.data.GResultData}の終了コードに{@value jp.co.kccs.greenearth.framework.data.GResultData#EXIT_CODE_SYSTEM_ERROR}}を指定した場合、
 * その処理はシステムエラーであると見なし、エラー用のXMLを生成します。<br>
 * <br>
 * 
 * <b>【文字エンコーディング】</b><br>
 * 生成するXMLの文字エンコーディングは、プロパティファイルにて指定する事が出来ます。<br>
 * クライアント側で利用する文字コードとあわせて適切な値を指定してください。<br>
 * プロパティファイルにて指定する項目は以下になります。<br>
 * <code>geframe.xrmi.Response.Encoding=UTF-8</code><br>
 * <br>
 * 
 * <b>【レスポンス書き込み時のバッファリングサイズ】</b><br>
 * 情報量の多い{@link jp.co.kccs.greenearth.framework.data.GResultData}を処理する場合などは、レスポンスへの書き出しをバッファリングします。<br>
 * このバッファーサイズはプロパティファイルにて以下のように指定する事が出来ます。<br>
 * <code>geframe.xrmi.Response.BufferingSize=1024</code><br>
 * 
 * @create 2009/08/24
 * @author yamashita
 * @since 3.6.0
 */
public class GXrmiResponseFilter extends GResponseFilter {
	
	/** XMLバージョン. */
	private String _version = "1.0";
	/** XML文字エンコーディング. */
	private String _encoding = null;
	/** レスポンス出力用ライタのバッファサイズ */
	private static final String BUFFER_SIZE_KEY = "geframe.xrmi.Response.BufferingSize";
	/** XML文字エンコーディングキー */
	private static final String ENCODING_KEY = "geframe.xrmi.Response.Encoding";
	/** ロガー */
	private static final Log LOGGER = LogFactory.getLog(GResponseFilter.class);
	
	/**
	 * {@link GXrmiResponseFilter}インスタンスを初期化します。
	 * 
	 * @create 2009/08/30
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GXrmiResponseFilter() {
	}

	/**
	 * プロパティファイルよりエンコーディングを読み込んでいます。
	 * 
	 * @create 2009/08/24
	 * @see jp.co.kccs.greenearth.commons.filter.GExcludableFilter#init(jakarta.servlet.FilterConfig)
	 * @param filterConfig フィルターコンフィグ
	 * @throws ServletException フィルターの初期化に失敗した場合
	 * @author yamashita
	 * @since 3.6.0
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);
		
		_encoding = GFrameworkUtils.getProperty(ENCODING_KEY, System.getProperty("file.encoding"));
	}
	
	/**
	 * シリアライズするXMLのバージョンを指定します。
	 * 
	 * @create 2008/12/08
	 * @param version XMLバージョン
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void setVersion(String version) {
		_version = version;
	}

	/**
	 * シリアライズするXMLのバージョンを取得します。
	 * 
	 * @create 2008/12/08
	 * @return XMLバージョン
	 * @author yamashita
	 * @since 3.6.0
	 */
	public String getVersion() {
		return _version;
	}

	/**
	 * XMLの文字エンコードを指定します。
	 * 
	 * @create 2008/12/08
	 * @param encoding XML文字エンコーディング
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void setEncoding(String encoding) {
		_encoding = encoding;
	}

	/**
	 * XMLの文字エンコードを取得します。
	 * 
	 * @create 2008/12/08
	 * @return XML文字エンコーディング
	 * @author yamashita
	 * @since 3.6.0
	 */
	public String getEncoding() {
		return _encoding;
	}
	
	/**
	 * 指定された{@link GResultData}の内容をXMLにシリアライズし、レスポンスに書き出します。<br>
	 * 
	 * @create 2009/08/19
	 * @see GResponseFilter#writeNomalResponse(HttpServletRequest, HttpServletResponse, GParameter, GResultData)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param resultData 結果オブジェクト
	 * @throws IOException レスポンスの書き込みに失敗した場合
	 * @author kitamura
	 * @since 3.6.0
	 */
	@Override
	protected void writeNomalResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter, GResultData resultData) throws IOException {
		if (resultData == null) {
			throw new NullPointerException("ResultData is Null");
		}

		GStopWatch watch = new GStopWatch();
		watch.start();

		int bufferSize = GFrameworkUtils.getIntProperty(BUFFER_SIZE_KEY, 8192);
		response.setBufferSize(bufferSize);
		response.setContentType("text/xml; charset=" + getEncoding());
		PrintWriter writer = response.getWriter();
		try {
			writer.println(createXmlDeclarationString());
			GXmlSerializerFactory factory = GXmlSerializerFactory.getInstance();
			GXmlElementSerializer serializer = factory.getSerializer(resultData);
			serializer.serialize(writer, null, resultData);
			LOGGER.trace("Write Xrmi Response (" + watch.stop() + ")");
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}
	
	/**
	 * 指定した例外情報をエラー情報としてXMLにシリアライズします。<br>
	 * 
	 * @create 2009/08/19
	 * @see GResponseFilter#writeErrorResponse(HttpServletRequest, HttpServletResponse, GParameter, java.lang.Throwable)
	 * @param request リクエスト
	 * @param response レスポンス
	 * @param parameter パラメータ
	 * @param e 例外オブジェクト
	 * @throws IOException シリアライズに失敗した場合
	 * @author yamashita
	 * @since 3.6.0
	 */
	@Override
	protected void writeErrorResponse(HttpServletRequest request, HttpServletResponse response, GParameter parameter, Throwable e) throws IOException {
		GResultData resultData = GResultData.Factory.create(GResultData.EXIT_CODE_SYSTEM_ERROR);
		resultData.setException(e);
		writeNomalResponse(request, response, parameter, resultData);
	}

	/**
	 * XML宣言部分の文字列を生成します。
	 * 
	 * @create 2008/12/08
	 * @return XML宣言
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected String createXmlDeclarationString() {
		StringBuilder xml = new StringBuilder();
		xml.append("<?xml version=\"");
		xml.append(getVersion());
		xml.append("\" encoding=\"");
		xml.append(getEncoding());
		xml.append("\"?>");
		return xml.toString();
	}
}
