package jp.co.kccs.greenearth.framework.xrmi.authorization;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.auth.GUserDao;
import jp.co.kccs.greenearth.framework.authorization.GRole;
import jp.co.kccs.greenearth.framework.authorization.GRoleFinder;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;

public class GRoleAction {
	
	// パラメータキー
	protected static final String PARAM_SEARCH_ROLE_ID = "RoleID";
	protected static final String PARAM_SEARCH_COMPANY_CODE = "CompanyCode";
	protected static final String PARAM_SEARCH_OBJECT_ID = "ObjectID";
	protected static final String PARAM_USER_COMPANY_CODE = "UserCompanyCode";
	protected static final String PARAM_USER_ID = "UserID";
	
	// 結果データキー
	protected static final String RESULT_ROLE = "Role";
	/** 権限有無を表す */
	protected static final String RESULT_HAS_AUTHORITY ="HasAuthority";
	protected static final String RESULT_DISPLAY_NAME_MAP = "DisplayNameMap";
	
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findRole(GParameter parameter, GResultData resultData) {
		String companyCode = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_COMPANY_CODE));
		String roleID = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_ROLE_ID));
		GRoleFinder finder = GRoleFinder.Factory.getInstance();
		GRole role = finder.getRole(companyCode, roleID);
		resultData.setData(RESULT_ROLE, role);
		return resultData;
	}
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData checkAuthority(GParameter parameter, GResultData resultData) throws GResourceProcessingException {
		// Roleの生成
		String objectID = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_OBJECT_ID));
		GRoleFinder finder = GRoleFinder.Factory.getInstance();
		GRole role = finder.getRole(objectID);
		
		// Userの生成
		String userCompanyCode = GStringUtils.blankToNull(parameter.getValue(PARAM_USER_COMPANY_CODE));
		String userID = GStringUtils.blankToNull(parameter.getValue(PARAM_USER_ID));
		GUserDao dao = (GUserDao) GFrameworkUtils.getComponent(GUserDao.class.getName());
		GUser user = dao.findUser(userCompanyCode, userID);
		
		boolean hasAuthority = role.hasAuthority(user);
		resultData.setData(RESULT_HAS_AUTHORITY, hasAuthority);
		return resultData;
	}	
}
