/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package jp.co.kccs.greenearth.framework.xrmi.log.log4j;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.core.LogEvent;

import jp.co.kccs.greenearth.commons.log.log4j.GLogPatternFormatter;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;

/**
 * ログにリクエストを一意に識別するためのIDを出力する{@link GLogPatternFormatter}クラスです.
 * 
 * @create 2022/03/31
 * @author oka
 * @since 22.3.0
 */
public class GLogRequestIdPatternFormatter implements GLogPatternFormatter {

	private String pattern;

	/**
	 * コンストラクタ.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	public GLogRequestIdPatternFormatter(String pattern) {
		this.pattern = pattern;
	}

	/**
	 * リクエストIDを戻します.
	 * 
	 * @create 2022/03/31
	 * @param event ログイベント、toAppendTo ログ出力文字列
	 * @return 出力文字列
	 * @author oka
	 * @since 22.3.0
	 */
	@Override
	public void format(final LogEvent event, final StringBuilder toAppendTo) {
		GParameter parameter = getParameter();
		if (parameter == null) {
			return;
		}
		toAppendTo.append(GStringUtils.nullToBlank(parameter.getValue("requestid")));
	}

	/**
	 * パラメータを取得します.<br>
	 * 本メソッドがサーバ起動直後(BeanCreationExceptionを送出時)に実行された場合、nullを返します.<br>
	 * SpringによるGWebContextのインスタンスのライフサイクルは、HTTPのリクエスト単位です.<br>
	 * サーバ起動直後（HTTPリクエストを受信するまで）は、GWebContextインスタンスは生成されず、取得できません.<br>
	 * 
	 * @create 2022/03/31
	 * @return GParameter
	 * @author oka
	 * @since 22.3.0
	 */
	private GParameter getParameter() {
		try {
			HttpServletRequest request = GWebContext.getInstance().getRequest();
			return (GParameter) request.getAttribute(GConstants.PARAMETER_KEY);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * patternを取得します.
	 * 
	 * @create 2022/03/31
	 * @auther oka
	 * @since 22.3.0
	 */
	public String getPattern() {
		return this.pattern;
	}
}
