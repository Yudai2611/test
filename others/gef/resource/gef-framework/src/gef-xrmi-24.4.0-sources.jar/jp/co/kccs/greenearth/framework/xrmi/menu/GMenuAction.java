/*
 * Copyright 2011 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.menu;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.auth.GUserDao;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.menu.GMenuFinder;


public class GMenuAction {
	
	// パラメータキー
	protected static final String PARAM_SEARCH_MENU_ID = "MenuID";
	protected static final String PARAM_SEARCH_COMPANY_CODE = "CompanyCode";
	protected static final String PARAM_USER_COMPANY_CODE = "UserCompanyCode";
	protected static final String PARAM_USER_ID = "UserID";
	protected static final String PARAM_SEARTH_OBJECT_ID = "ObjectID";

	// 結果データキー
	protected static final String RESULT_MENU = "menu";
	protected static final String RESULT_ROLE = "role";
	protected static final String RESULT_MENU_LIST = "MenuList";
	/** 権限有無を表す */
	protected static final String RESULT_HAS_AUTHORITY ="hasAuthority";
	//private static final String RESULT_DISPLAY_NAME_MAP = "DisplayNameMap";
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findRootMenuList(GParameter parameter, GResultData resultData) {
		String companyCode = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_COMPANY_CODE));
		GMenuFinder manager = GMenuFinder.Factory.getInstance();
		List<GMenu> list = manager.getRootMenuList(companyCode);
		resultData.setData(RESULT_MENU_LIST, list);
		return resultData;
	}
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findMenu(GParameter parameter, GResultData resultData) {
		String companyCode = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_COMPANY_CODE));
		String menuID = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARCH_MENU_ID));
		GMenuFinder manager = GMenuFinder.Factory.getInstance();
		GMenu menu = manager.getMenu(companyCode, menuID);
		resultData.setData(RESULT_MENU, menu);
		return resultData;
	}
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findParentMenu(GParameter parameter, GResultData resultData) {
		GMenu menu = findMenuByOID(parameter);
		if (menu != null) {
			resultData.setData(RESULT_MENU, menu.getParent());
		}
		return resultData;
	}
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findChildMenuList(GParameter parameter, GResultData resultData) {
		GMenu menu = findMenuByOID(parameter);
		if (menu != null) {
			resultData.setData(RESULT_MENU_LIST, menu.getChildren());
		}
		return resultData;
	}
	
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData checkAuthority(GParameter parameter, GResultData resultData) throws GResourceProcessingException {
		GMenu menu = findMenuByOID(parameter);
		
		// Userの生成
		String userCompanyCode = GStringUtils.blankToNull(parameter.getValue(PARAM_USER_COMPANY_CODE));
		String userID = GStringUtils.blankToNull(parameter.getValue(PARAM_USER_ID));
		GUserDao dao = (GUserDao) GFrameworkUtils.getComponent(GUserDao.class.getName());
		GUser user = dao.findUser(userCompanyCode, userID);
		
		resultData.setData(RESULT_HAS_AUTHORITY, menu.hasAuthority(user));
		return resultData;
	}
	
	public GMenu findMenuByOID(GParameter parameter) {
		String objectID = GStringUtils.blankToNull(parameter.getValue(PARAM_SEARTH_OBJECT_ID));
		GMenuFinder manager = GMenuFinder.Factory.getInstance();
		return manager.getMenu(objectID);
	}		
	
	/**
	 * メニューにセットしたロールを取得します.
	 * 
	 * @param parameter
	 * @return GRole
	 * @create 2011/05/26
	 * @author KCCS kyo
	 * @since 3.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData findRole(GParameter parameter,GResultData resultData) {
		GMenu menu = findMenuByOID(parameter);
		if(menu!=null){
			resultData.setData(RESULT_ROLE, menu.getRole());
		}
		return resultData;
	}	
}
