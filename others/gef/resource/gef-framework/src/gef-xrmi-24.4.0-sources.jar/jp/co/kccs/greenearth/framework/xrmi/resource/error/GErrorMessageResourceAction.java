/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.resource.error;

import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;

/**
 * エラーメッセージ取得用アクション
 * 
 * @author KCCS N.Nishimura
 * @since 2014/06/06
 */
public class GErrorMessageResourceAction {

	/**
	 * エラーコードよりエラーメッセージを取得
	 * 
	 * @param parameter エラーコードが格納されたパラメータ
	 * @param resultdata エラーメッセージを格納する結果セット
	 * @return エラーメッセージが格納された結果セット
	 * @author KCCS N.Nishimura
	 * @create 2014/06/20
	 * @since 3.16.0
	 */
	public GResultData getErrorMessage(GParameter parameter, GResultData resultdata) {
		String errorcode = parameter.getValue("ErrorCode");
		Locale locale = getLocale(parameter);
		GErrorMessage errorMessage = GErrorMessages.getErrorMessage(errorcode, locale);
		resultdata.setData("ErrorMessage", errorMessage);
		return resultdata;
	}

	private Locale getLocale(GParameter parameter) {
		String language = parameter.getValue("Locale");
		return GLocaleUtils.getLocale(language);
	}

	/**
	 * 全てのエラーメッセージを取得
	 * 
	 * @param parameter 画面パラメータ
	 * @param resultdata 全てのエラーメッセージを格納する結果セット
	 * @return 全てのエラーメッセージが格納された結果セット
	 * @author KCCS N.Nishimura
	 * @create 2014/06/20
	 * @since 3.16.0
	 */
	public GResultData getAllErrorMessages(GParameter parameter, GResultData resultdata) {
		Map<Locale, Map<String, GErrorMessage>> allResources = GErrorMessages.getAllErrorMessages();
		resultdata.setData("AllErrorMessages", allResources);
		return resultdata;

		// String diKey = GErrorMessages.class.getPackage().getName() +
		// ".ErrorMessageManager";
		// GErrorMessageManager errorManager =
		// GFrameworkUtils.getComponent(diKey);
		// Map<Locale, Map<String, GErrorMessage>> allResource =
		// errorManager.getResourceDao().findResourceAll();
		// resultdata.setData("AllErrorMessages", allResource);
		// return resultdata;
	}
}
