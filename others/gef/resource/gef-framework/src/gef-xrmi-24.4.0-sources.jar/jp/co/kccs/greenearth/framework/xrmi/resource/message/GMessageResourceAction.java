/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.resource.message;

import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.commons.utils.GLocaleUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;

/**
 * メッセージ取得用アクション
 * 
 * @author KCCS N.Nishimura
 * @since 2014/06/06
 */
public class GMessageResourceAction {

	/**
	 * IDよりメッセージを取得
	 * 
	 * @param parameter メッセージIDが格納されたパラメータ
	 * @param resultdata メッセージを格納する結果セット
	 * @return メッセージが格納された結果セット
	 * @author KCCS N.Nishimura
	 * @create 2014/06/20
	 * @since 3.16.0
	 */
	public GResultData getMessage(GParameter parameter, GResultData resultdata) {
		String messageid = parameter.getValue("MessageID");
		Locale locale = getLocale(parameter);
		
		String message = GMessageResources.getMessage(messageid, locale);
		resultdata.setData("Message", message);
		return resultdata;
	}

	private Locale getLocale(GParameter parameter) {
		String language = parameter.getValue("Locale");
		return GLocaleUtils.getLocale(language);
	}

	/**
	 * 全てのメッセージを取得
	 * 
	 * @param parameter 画面パラメータ
	 * @param resultdata 全てのメッセージを格納する結果セット
	 * @return 全てのメッセージが格納された結果セット
	 * @author KCCS N.Nishimura
	 * @create 2014/06/20
	 * @since 3.16.0
	 */
	public GResultData getAllMessages(GParameter parameter, GResultData resultdata) {
		Map<Locale, Map<String, String>> allMessages = GMessageResources.getAllMessages();
		resultdata.setData("AllMessages", allMessages);
		return resultdata;
		
//		String diKey = GMessageResources.class.getPackage().getName() + ".MessageResourceManager";
//		GMessageResourceManager resourceManager = GFrameworkUtils.getComponent(diKey);
//		Map<Locale, Map<String, String>> allMessage = resourceManager.getResourceDao().findResourceAll();
//		resultdata.setData("AllMessages", allMessage);
//		return resultdata;
	}

}
