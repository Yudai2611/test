/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;
import java.math.BigDecimal;

/**
 * {@link BigDecimal}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link BigDecimal}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>" scale="<b>スケール</b>" &gt;<b>値</b>&lt;/data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link BigDecimal}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"bigDecimal"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link BigDecimal}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>スケール</b></td><td>{@link BigDecimal#scale()}で取得できるスケール</td><td>5</td></tr>
 * <tr><td><b>値</b></td><td>{@link BigDecimal#unscaledValue()}.{@link java.math.BigInteger#toString()}で取得できる値の文字列</td><td>"1234"</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>bigDecimal</b>" type="<b>java.math.BigDecimal</b>" scale="<b>5</b>" &gt;<b>1234</b>&lt;/data&gt;</code></pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/22
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(BigDecimal.class)
public class GBigDecimalSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/08
	 * @auther yamashita
	 * @since 3.6.0
	 */
	public GBigDecimalSerializer() {
	}

	/**
	 * {@link BigDecimal}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2008/12/08
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof BigDecimal)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + BigDecimal.class.getName() + "\".");
		}
		BigDecimal value = (BigDecimal) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("scale", Integer.toString(value.scale()));
		String valueString = value.toPlainString();
		if (value.scale() > 0) {
			valueString = valueString.substring(0, valueString.length() - value.scale() - 1) + valueString.substring(valueString.length() - value.scale(), valueString.length());
		}
		xmlBuilder.setInnerText(valueString);

		writer.print(xmlBuilder.createStartEndTagString());
	}
}
