/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;

import jp.co.kccs.greenearth.commons.GFrameworkException;

/**
 * {@link GFrameworkException}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GFrameworkException}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>" &gt;
 *   &lt;message&gt;
 *     <b>エラーメッセージ</b>
 *   &lt;/message&gt;
 *&lt;data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GFrameworkException}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>例外を特定する一意なキー(任意の値)</td><td>"gframeworkException"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GFrameworkException}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>エラーメッセージ</b></td><td>{@link GFrameworkException#getMessage()}で取得できるエラーメッセージ</td><td>It is necessary to define 'menu id' uniquely in Acl infomation.</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>gframeworkException</b>" type="<b>jp.co.kccs.greenearth.commons.GFrameworkException</b>" &gt;
 *   &lt;message&gt;
 *     <b>It is necessary to define 'menu id' uniquely in Acl infomation.</b>
 *   &lt;/message&gt;
 *&lt;data&gt;</code></pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/30
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GFrameworkException.class)
public class GFrameworkExceptionSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2009/03/10
	 * @auther yamashita
	 * @since 3.6.0
	 */
	public GFrameworkExceptionSerializer() {
	}

	/**
	 * {@link GFrameworkException}をXML文字列に変換します.<br>
	 * 
	 * @create 2009/03/10
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {

		if (!(data instanceof GFrameworkException)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GFrameworkException.class.getName() + "\".");
		}
		GFrameworkException value = (GFrameworkException) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);

		writer.print(xmlBuilder.createStartTagString());

		if (value.getMessage() != null) {
			writer.print(createMessageTag(value));
		}

		writer.print(xmlBuilder.createEndTagString());
	}
	
	/**
	 * 指定された{@link GFrameworkException}に設定されたメッセージを内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;message&gt;{@link GFrameworkException}にセットされたエラーメッセージ&lt;/message&gt;
	 * </pre>
	 * 
	 * @create 2009/07/31
	 * @param value 値
	 * @return XML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	protected String createMessageTag(GFrameworkException value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("message");
		xml.setInnerText(value.getMessage());
		return xml.createStartEndTagString();
	}
}
