/*
 * Copyright 2016 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.util.LinkedHashMap;

/**
 * {@link LinkedHashMap}型のデータをXML文字列に変換する為のシリアライザクラスです.<br>
 * 
 * @create 2016/01/26
 * @author hashimoto
 * @since 3.17.0
 */
@SerializeTarget(LinkedHashMap.class)
public class GLinkedHashMapSerializer extends GMapSerializer {
	
	public GLinkedHashMapSerializer() {
	}
}
