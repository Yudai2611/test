/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;
import java.util.List;

/**
 * {@link List}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link List}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>" &gt; 
 *　&lt;list&gt;
 *　　&lt;data type="XXXX" .../&gt; <b>// 値</b>
 *　　...
 *  &lt;/list&gt;
 *&lt;/data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link List}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"list"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link List}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>値</b></td><td>{@link List#get(int)}で取得できるオブジェクト</td><td>任意のオブジェクト<b>※</b></td></tr>
 * </table><br>
 * <b>※{@link List}には、任意のオブジェクトが設定できる為、シリアライズ時に使用するシリアライザクラスは、 <br>
 * 保存されているインスタンスの型によって変化します。</b>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>list</b>" type="<b>java.util.List</b>" &gt; 
 *　&lt;list&gt;
 *    <b>// シリアライズされたオブジェクトのXML</b>
 *　　...
 *  &lt;/list&gt;
 *&lt;/data&gt;</code></pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/30
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(List.class)
public class GListSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2009/04/17
	 * @auther murashige
	 * @since 3.6.0
	 */
	public GListSerializer() {
	}

	/**
	 * {@link List}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/04/17
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author murashige
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof List)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + List.class.getName() + "\".");
		}
		List< ? > value = (List< ? >) data;
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);

		// dataタグを開く
		writer.print(xmlBuilder.createStartTagString());

		printElement(writer, value);

		// dataタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * {@link List}に格納されているオブジェクトを追加します.<br>
	 * 
	 * @create 2009/04/17
	 * @param writer ライタ
	 * @param value リストデータ
	 * @author murashige
	 * @since 3.6.0
	 */
	protected void printElement(PrintWriter writer, List< ? > value) {

		if (value.size() == 0) {
			return;
		}

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("list");
		// listタグを開く
		writer.print(xmlBuilder.createStartTagString());

		// ListにセットされたObjectをシリアライズ
		GXmlSerializerFactory factory = getSerializerFactory();
		for (Object object : value) {
			GXmlElementSerializer serializer = factory.getSerializer(object);
			serializer.serialize(writer, null, object);
		}

		// listタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}

}
