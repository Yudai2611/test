/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;
import java.util.Locale;

/**
 * {@link Locale}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link Locale}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>"
 *      type="<b>クラス名</b>"
 *      language="<b>言語コード</b>" 
 *      country="<b>国コード</b>" 
 *      variant="<b>地域コード</b>" /&gt; </code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link Locale}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"locale"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link Locale}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>言語コード</b></td><td>{@link Locale#getLanguage()}で取得できる言語コード</td><td>"ja"</td></tr>
 * <tr><td><b>国コード</b></td><td>{@link Locale#getCountry()}で取得できる国コード</td><td>"JP"</td></tr>
 * <tr><td><b>地域コード</b></td><td>{@link Locale#getVariant()}で取得できる地域コード</td><td>"Kansai"</td></tr>
 * </table><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>locale</b>"
 *      type="<b>java.util.Locale</b>"
 *      language="<b>ja</b>" 
 *      country="<b>JP</b>" 
 *      variant="<b>Kansai</b>" /&gt;</code></pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/30
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(Locale.class)
public class GLocaleSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2009/02/16
	 * @auther aono
	 * @since 3.6.0
	 */
	public GLocaleSerializer() {
	}

	/**
	 * {@link Locale}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/02/16
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author aono
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof Locale)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + Locale.class.getName() + "\".");
		}
		Locale value = (Locale) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		if (!"".equals(value.getLanguage())) {
			xmlBuilder.setAttribute("language", value.getLanguage());
		}
		if (!"".equals(value.getCountry())) {
			xmlBuilder.setAttribute("country", value.getCountry());
		}
		if (!"".equals(value.getVariant())) {
			xmlBuilder.setAttribute("variant", value.getVariant());
		}

		writer.print(xmlBuilder.createStartEndTagString());
	}
}
