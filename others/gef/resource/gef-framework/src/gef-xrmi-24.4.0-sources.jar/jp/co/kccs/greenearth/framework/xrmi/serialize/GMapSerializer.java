package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;
import java.util.Map;

@SerializeTarget(Map.class)
public class GMapSerializer extends GXmlElementSerializerBase {
	
	public GMapSerializer() {
	}

	public void serialize(PrintWriter writer, String name, Object data) {
		Map<?,?> value = (Map<?,?>) data;
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);

		// dataタグを開く
		writer.print(xmlBuilder.createStartTagString());

		printElement(writer, value);

		// dataタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}
	
	protected void printElement(PrintWriter writer, Map<?,?> value) {

		if (value.size() == 0) {
			return;
		}

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("map");
		// listタグを開く
		writer.print(xmlBuilder.createStartTagString());

		// ListにセットされたObjectをシリアライズ
		GXmlSerializerFactory factory = getSerializerFactory();
		for (Map.Entry<?, ?> entry : value.entrySet()) {
			GXmlElementBuilder entryBuilder = new GXmlElementBuilder("entry");
			writer.print(entryBuilder.createStartTagString());
			GXmlElementSerializer keySerializer = factory.getSerializer(entry.getKey());
			keySerializer.serialize(writer, "key", entry.getKey());
			GXmlElementSerializer valueSerializer = factory.getSerializer(entry.getValue());
			valueSerializer.serialize(writer, "value", entry.getValue());
			writer.print(entryBuilder.createEndTagString());
		}

		// listタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}

}
