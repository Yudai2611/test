/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;

/**
 * {@link Object}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link Object}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>" &gt;<b>値</b>&lt;/data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link Object}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"object"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link Object}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>値</b></td><td>{@link Object#toString()}で取得できる文字列</td><td>"オブジェクト"</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>object</b>" type="<b>java.lang.Object</b>" &gt;<b>オブジェクト</b>&lt;/data&gt;</code></pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/30
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(Object.class)
public class GObjectSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/26
	 * @auther yamashita
	 * @since 3.6.0
	 */
	public GObjectSerializer() {
	}

	/**
	 * データをXML文字列に変換します.<br>
	 * 
	 * @create 2008/12/26
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (data == null) {
			throw new NullPointerException("data is null.");
		}
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setInnerText(data.toString());
		writer.print(xmlBuilder.createStartEndTagString());
	}
}
