/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;

/**
 * {@link Throwable}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link Throwable}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>" concreteClass="<b>具体的なクラス名</b>" &gt;
 *   &lt;message&gt;
 *     <b>エラーメッセージ</b>
 *   &lt;/message&gt;
 *&lt;data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link Throwable}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"throwable"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link Throwable}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>メッセージ</b></td><td>{@link Throwable#getMessage()}で取得できるエラーメッセージ</td><td>"'actionbean' is not found!"</td></tr>
 * <tr><td><b>具体的なクラス名</b></td><td>{@link Throwable#getClass()}で取得できる具体的なクラスのクラス名</td><td>{@link NullPointerException}オブジェクト</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>throwable</b>" type="<b>java.lang.Throwable</b>" concreteClass="<b>java.lang.NullPointerException</b>" &gt;
 *   &lt;message&gt;
 *     <b>'actionbean' is not found!</b>
 *   &lt;/message&gt;
 *&lt;data&gt;</code></pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/30
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(Throwable.class)
public class GThrowableSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/08
	 * @auther yamashita
	 * @since 3.6.0
	 */
	public GThrowableSerializer() {
	}

	/**
	 * {@link Throwable}型のデータをXML文字列に変換する為のシリアライザクラスです.<br><br>
	 * 
	 * @create 2008/12/15
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof Throwable)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + Throwable.class.getName() + "\".");
		}
		Throwable value = (Throwable) data;
		
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("concreteClass", value.getClass().getName());

		writer.print(xmlBuilder.createStartTagString());

		if (value.getMessage() != null) {
			writer.print(createMessageTag(value));
		}

		writer.print(xmlBuilder.createEndTagString());
	}
	
	/**
	 * 指定された{@link Throwable}に設定されたメッセージを内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;message&gt;{@link Throwable}にセットされたエラーメッセージ&lt;/message&gt;
	 * </pre>
	 * 
	 * @create 2009/07/31
	 * @param value 値
	 * @return XML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	protected String createMessageTag(Throwable value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("message");
		xml.setInnerText(value.getMessage());
		return xml.createStartEndTagString();
	}
}
