/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.framework.auth.GStatus;

/**
 * XMLを形成するタグを生成するクラスです.<br>
 * <br>
 * このクラスにセットされた以下の値を使用してXMLタグを生成します。<br>
 * <br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>値</td><td>値をセットするメソッド</td></tr>
 * <tr><td><b>タグの名称</b></td><td>{@link #setName(String)}</td></tr>
 * <tr><td><b>インナーテキスト</b></td><td>{@link #setInnerText(String)}</td></tr>
 * <tr><td><b>タグの属性</b></td><td>{@link #setAttribute(String, String)}、<br>
 * {@link #setAttribute(String, boolean)}、<br>
 * {@link #setAttribute(String, String, String)}
 * </td></tr>
 * </table>
 * <br/>
 * また、XMLタグの生成には以下のようなメソッドが使用できます。<br/>
 * ※詳細は各メソッドのJavadocを参照して下さい。<br/>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>メソッド名</td><td>説明</td></tr>
 * <tr><td>{@link #createStartTagString()}</td><td>XMLタグの開始要素XML文字列を生成します。</td></tr>
 * <tr><td>{@link #createEndTagString()}</td><td>XMLタグの終了要素XML文字列を生成します。</td></tr>
 * <tr><td>{@link #createStartEndTagString()}</td><td>XMLタグの開始-終了要素XML文字列を生成します。</td></tr>
 * <tr><td>{@link #createTagString()}</td><td>XMLタグの開始-終了要素XML文字列または閉じた開始要素XML文字列を生成します。</td></tr>
 * </table>
 * <br>
 * @create 2008/12/08
 * @author yamashita
 * @since 3.6.0
 */
public class GXmlElementBuilder {

	/** タグ名称. **/
	private String _name = null;
	/** 属性. **/
	private Map<String, String> _attributes = null;
	/** インナーテキスト. */
	private String _innerText = null;

	// ----- コンストラクタ ----------------------------------------------------------
	/**
	 * {@link GXmlElementBuilder}の新しいインスタンスを初期化します.
	 * 
	 * @create 2008/12/08
	 * @author yamashita
	 * @since 3.6.0
	 */
	public GXmlElementBuilder() {
	}

	/**
	 * タグ名を指定して、{@link GXmlElementBuilder}の新しいインスタンスを初期化します.
	 * 
	 * @create 2008/12/08
	 * @param name タグ名
	 * @author yamashita
	 * @since 3.6.0
	 */
	public GXmlElementBuilder(String name) {
		setName(name);
	}

	// ----- パブリックメソッド ----------------------------------------------------------

	/**
	 * 要素の終了を表現した文字列表現を取得します.<br>
	 * <br>
	 * 【生成されるXMLタグ】<br>
	 * &lt;/ タグ名 &gt; <br>
	 * 
	 * @create 2008/12/08
	 * @return 要素の終了のXML文字列表現
	 * @author yamashita
	 * @since 3.6.0
	 */
	public String createEndTagString() {
		String xml = "";

		String name = getName();
		if (name != null) {
			xml = "</" + name + ">";
		}

		return xml;
	}

	/**
	 * 開始-終了要素の文字列表現を取得します.<br>
	 * インナーテキストがnullの場合であっても、常に開始-終了要素の文字列を取得します。<br>
	 * インナーテキストはエスケープ文字列に変換して取得します。<br>
	 * <br>
	 * 【生成されるXMLタグ】<br>
	 * &lt; タグ名 属性名="属性値" &gt;インナーテキスト&lt;/ タグ名 &gt;<br>
	 * 
	 * @create 2008/12/08
	 * @return 開始-終了要素を表現したXML文字列
	 * @author yamashita
	 * @since 3.6.0
	 */
	public String createStartEndTagString() {
		StringBuilder xml = new StringBuilder();
		String name = getName();
		if (name != null) {
			xml.append(createStartTagString());
			if (getInnerText() != null) {
				xml.append(GXmlUtils.escapeXMLAttribute(getInnerText()));
			}
			xml.append(createEndTagString());
		}
		return xml.toString();
	}

	/**
	 * 開始要素の開始部分の文字列表現を取得します.<br>
	 * 属性の値が<code>null</code>の場合、属性は含まれません。<br>
	 * <br>
	 * 【生成されるXMLタグ】<br>
	 * &lt; タグ名 属性名="属性値" &gt;<br>
	 * 
	 * @create 2008/12/08
	 * @return 開始要素のXML文字列表現
	 * @author yamashita
	 * @since 3.6.0
	 */
	public String createStartTagString() {
		StringBuilder xml = new StringBuilder();
		String name = getName();
		if (name != null) {
			xml.append("<");
			xml.append(name);
			if (_attributes != null) {
				for (String key : _attributes.keySet()) {
					String value = _attributes.get(key);
					if (value != null) {
						xml.append(" ");
						xml.append(key);
						xml.append("=\"");
						xml.append(GXmlUtils.escapeXMLAttribute(value));
						xml.append("\"");
					}
				}
			}
			xml.append(">");
		}
		return xml.toString();
	}

	/**
	 * 開始-終了要素の文字列表現を取得します.<br>
	 * 内部テキストがnullの場合、開始要素の文字列のみを取得します。<br>
	 * ※常に開始-終了要素の文字列を取得する場合、{@link #createStartEndTagString()}を使用してください。
	 * フラグによって、内部テキストのエスケープを決定します。<br><br>
	 * 【生成されるXMLタグ(インナーテキストあり)】<br>
	 * &lt; タグ名 属性名="属性値" &gt;インナーテキスト&lt;/ タグ名 &gt;<br><br>
	 * 【生成されるXMLタグ(インナーテキストなし)】<br>
	 * &lt; タグ名 属性名="属性値" /&gt;<br>
	 * 
	 * @create 2009/08/26
	 * @return 開始-終了要素のXML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	public String createTagString() {
		StringBuilder xml = new StringBuilder();

		String name = getName();
		if (name != null) {
			xml.append(createStartTagString());

			if (getInnerText() != null) {
				xml.append(GXmlUtils.escapeXMLAttribute(getInnerText()));
				xml.append(createEndTagString());
			} else {
				xml.replace(xml.length() - 1, xml.length(), " />");
			}
		}
		return xml.toString();
	}

	/**
	 * マップから指定キーの属性を削除します.
	 * 
	 * @create 2008/12/08
	 * @param key キー
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void removeAttribute(String key) {
		_attributes.remove(key);
	}

	// ----- パブリックプロパティ ------------------------------------------------------

	/**
	 * 属性マップを戻します.<br>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。
	 * 
	 * @create 2008/12/08
	 * @return 属性マップ
	 * @author yamashita
	 * @since 3.6.0
	 */
	public Map<String, String> getAttributes() {
		return _attributes;
	}

	/**
	 * インナーテキストを取得します.<br>
	 * 
	 * @create 2008/12/17
	 * @return インナーテキスト
	 * @author aono
	 * @since 3.6.0
	 */
	public String getInnerText() {
		return _innerText;
	}

	/**
	 * タグの名称を戻します.
	 * 
	 * @create 2008/12/08
	 * @return タグの名称
	 * @author yamashita
	 * @since 3.6.0
	 */
	public String getName() {
		return _name;
	}

	/**
	 * タグに属性を追加します.<br>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。
	 * 
	 * @create 2008/12/08
	 * @param key 属性名
	 * @param value 属性値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void setAttribute(String key, boolean value) {
		setAttribute(key, String.valueOf(value));
	}
	
	/**
	 * タグに属性を追加します.<br>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。<br>
	 * valueにnullを指定した場合は、Attributeとして追加されず、無視されます。
	 * 
	 * @create 2008/12/08
	 * @param key 属性名
	 * @param value 属性値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void setAttribute(String key, String value) {
		// valueがnullの場合は無視する
		if (value == null) {
			return;
		}
		if (_attributes == null) {
			_attributes = new HashMap<String, String>();
		}

		_attributes.put(key, value);
	}

	/**
	 * タグに属性を追加します.<br>
	 * 属性の追加順序と記述順序は、保証されません。順不同になります。<br>
	 * valueにnullを指定した場合は、defaultValueに指定した値が属性値として指定されます。
	 * 
	 * @create 2008/12/08
	 * @param key 属性名
	 * @param value 属性値
	 * @param defaultValue デフォルト値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void setAttribute(String key, String value, String defaultValue) {
		if (value == null) {
			setAttribute(key, defaultValue);
		} else {
			setAttribute(key, value);
		}
	}

	/**
	 * インナーテキストを設定します.<br>
	 * 
	 * @create 2008/12/17
	 * @param text インナーテキスト
	 * @author aono
	 * @since 3.6.0
	 */
	public void setInnerText(String text) {
		_innerText = text;
	}

	/**
	 * タグに名称を設定します.
	 * 
	 * @create 2008/12/08
	 * @param name タグ名称
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void setName(String name) {
		_name = name;
	}
}
