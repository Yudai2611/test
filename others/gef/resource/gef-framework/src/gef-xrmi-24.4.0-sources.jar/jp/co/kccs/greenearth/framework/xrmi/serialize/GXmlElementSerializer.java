/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.io.PrintWriter;

/**
 * 指定された値をXML文字列へシリアライズします.br>
 * 
 * @create 2008/12/08
 * @author yamashita
 * @since 3.6.0
 */
public interface GXmlElementSerializer {

	/**
	 * 指定された値をXML文字列へシリアライズします。<br>
	 * 
	 * @create 2008/12/08
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	void serialize(PrintWriter writer, String name, Object data);

	/**
	 * シリアライズ対象のクラスを取得します.
	 * 
	 * @create 2009/05/12
	 * @return シリアライズ対象クラス
	 * @author kitamura
	 * @since 3.6.0
	 */
	Class< ? > getSerializeTarget();
}
