/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

/**
 * {@link GXmlElementSerializer}インターフェースの実装をサポートするベースクラスです.<br>
 * <br>
 * このベースクラスでは以下のようなメソッドを提供します。<br>
 * ※詳細については各メソッドのJavadocを参照して下さい。<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>メソッド</td><td>説明</td></tr>
 * <tr><td><b>{@link #decorateRequiredAttribute(GXmlElementBuilder, String)}</b></td><td>シリアライズしたXMLに必須となる属性を設定します。</td></tr>
 * <tr><td><b>{@link #getSerializeTarget()}</b></td><td>シリアライズ処理のターゲットとなるクラスを取得します。</td></tr>
 * </table>
 * <br>
 * 【ベースクラスの拡張について】<br>
 * {@link GXmlElementSerializerBase}を拡張したクラスにおいて、このベースクラスのメソッドを使用する場合には<br>
 * 拡張したクラスに{@link SerializeTarget}アノテーションを定義する必要があります。<br>
 * {@link SerializeTarget}アノテーションの指定は以下のようになります。<br>
 * <pre>
 * 　&#064;@SerializeTarget(String.class)
 *   public class GStringSerializer extends GXmlElementSerializerBase{}
 * </pre>
 * 
 * @create 2009/05/12
 * @author kitamura
 * @since 3.6.0
 */
public abstract class GXmlElementSerializerBase implements GXmlElementSerializer {
	
	private GXmlSerializerFactory _factory = null;

	/**
	 * XMLの要素に必須となる属性を設定します。<br/>
	 * 以下の属性が設定されます。<br/>
	 * ・name属性：引数に指定されたname<br/>
	 * ・type属性：{@link SerializeTarget}アノテーションに定義されたクラスの完全修飾クラス名<br/>
	 * 
	 * @create 2009/07/08
	 * @param builder XMLビルダー
	 * @param name 要素名
	 * @author murashige
	 * @since 3.6.0
	 */
	public void decorateRequiredAttribute(GXmlElementBuilder builder, String name) {
		builder.setAttribute("name", name);
		builder.setAttribute("type", getSerializeTarget().getName());
	}

	/**
	 * シリアライズ対象のクラスを取得します.<br>
	 * <br>
	 * {@link SerializeTarget}アノテーションに定義されたクラスを取得します。<br>
	 * {@link SerializeTarget}アノテーションが定義されていない場合はIllegalStateException例外がスローされます。<br>
	 * 
	 * @create 2009/05/12
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#getSerializeTarget()
	 * @return シリアライズ対象クラス
	 * @author kitamura
	 * @since 3.6.0
	 */
	public Class< ? > getSerializeTarget() {
		if (getClass().isAnnotationPresent(SerializeTarget.class)) {
			SerializeTarget target = getClass().getAnnotation(SerializeTarget.class);
			return target.value();
		} else {
			throw new IllegalStateException("It is necessary to specify the SerializeTarget annotation for XmlElementSerializer.");
		}
	}
	
	protected GXmlSerializerFactory getSerializerFactory() {
		if (_factory == null) {
			_factory = GXmlSerializerFactory.getInstance();
		}
		return _factory;
	}
}
