/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * {@link GXmlElementSerializer}のインスタンスを生成するファクトリクラスです<br>
 * 
 * @create 2008/12/09
 * @author yamashita
 * @since 3.6.0
 */
public abstract class GXmlSerializerFactory {

	/**
	 * {@link GXmlSerializerFactory}クラスのインスタンスを取得します.<br>
	 * 
	 * @create 2008/12/09
	 * @return XMLシリアライザクラスファクトリ
	 * @author yamashita
	 * @since 3.6.0
	 */
	public static GXmlSerializerFactory getInstance() {
		return GFrameworkUtils.getComponent(GXmlSerializerFactory.class.getName());
	}

	/**
	 * シリアライザクラスが存在しない場合は、必ずデフォルトシリアライザクラスを返却して下さい.<br>
	 * 
	 * @create 2008/12/09
	 * @param target シリアライザクラス対象データ
	 * @return XMLシリアライザクラス
	 * @author yamashtia
	 * @since 3.6.0
	 */
	public abstract GXmlElementSerializer getSerializer(Object target);

	/**
	 * シリアライザクラスが存在しない場合は、必ずデフォルトシリアライザクラスを返却して下さい.<br>
	 * 
	 * @create 2008/12/09
	 * @param type シリアライザクラス対象データ
	 * @return XMLシリアライザクラス
	 * @author yamashita
	 * @since 3.6.0
	 */
	public abstract GXmlElementSerializer getSerializer(Class< ? > type);

	/**
	 * XMLシリアライザ用のNullを表すクラスです.<br>
	 * 
	 * @create 2009/08/27
	 * @author murashige
	 * @since 3.6.0
	 */
	public static class Null {

		/**
		 * デフォルトコンストラクタ.<br>
		 * 
		 * @create 2009/08/27
		 * @auther murashige
		 * @since 3.6.0
		 */
		public Null() {
		}
	}
}
