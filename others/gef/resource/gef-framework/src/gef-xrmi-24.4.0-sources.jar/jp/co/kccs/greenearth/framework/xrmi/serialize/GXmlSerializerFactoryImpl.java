/*
 * Copyright 2009-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * {@link GXmlSerializerFactory}のデフォルト実装クラスです.<br>
 * <br>
 * このファクトリでは以下の機能を提供します。<br>
 * ※詳細については各メソッドのJavadocを参照して下さい。<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>メソッド</td><td>説明</td></tr>
 * <tr><td><b>{@link #getSerializer(Object)}</b></td><td>ファクトリにセットされたシリアライザの一覧から、指定された<b>値</b>に対応したシリアライザを取得</td></tr>
 * <tr><td><b>{@link #getSerializer(Class)}</b></td><td>ファクトリにセットされたシリアライザの一覧から、指定された<b>型</b>に対応したシリアライザを取得</td></tr>
 * </table>
 * <br>
 * 【シリアライザの取得について】<br>
 * 継承関係にあるクラスの型や、インターフェースの実装クラスの値などを指定した場合、<br>
 * 以下のルールに基づいてシリアライザを取得します。<br><br>
 * ○継承関係にあるクラスのシリアライザ<br>
 * ファクトリが保持するシリアライザのリストの順番に基づき、スーパークラスに対応したシリアライザを優先的に取得します。<br><br>
 * 例：以下のようなシリアライザが設定されている場合<br>
 * 　①{@link GThrowableSerializer}：{@link Throwable}に対応したシリアライザ<br>
 * 　②{@link jp.co.kccs.greenearth.framework.xrmi.serialize.GApplicationExceptionSerializer}：{@link jp.co.kccs.greenearth.commons.GApplicationException}に対応したシリアライザ<br>
 * 　※{@link jp.co.kccs.greenearth.commons.GApplicationException}は{@link Throwable}を拡張したクラスです。<br>
 * <br>
 * 上記のシリアライザを保持するファクトリから{@link jp.co.kccs.greenearth.commons.GApplicationException}を指定して取得した場合には、<br>
 * スーパークラスに対応したシリアライザを優先的に取得するため、{@link GThrowableSerializer}が取得できます。<br>
 * また、サブクラスに対応したシリアライザを取得したい場合には、上記の①と②の順番を入れ替えて設定します。<br>
 * <br>
 * ○インターフェースのシリアライザ<br>
 * インターフェースに対応したシリアライザが保持されている場合には、インターフェースを実装したクラスの値や型を<br>
 * 指定した場合にもシリアライザを取得できます。<br>
 * <br>
 * 例：以下のようなシリアライザが設定されている場合<br>
 * 　{@link jp.co.kccs.greenearth.framework.xrmi.serialize.auth.GUserSerializer}：{@link jp.co.kccs.greenearth.framework.auth.GUser}インターフェースに対応したシリアライザ<br>
 * <br>
 * 上記のシリアライザを保持するファクトリから{@link jp.co.kccs.greenearth.framework.auth.GUser}を実装したクラス{@link jp.co.kccs.greenearth.framework.auth.GJk2UserImpl}のクラスや値を指定した場合に、<br>
 * {@link jp.co.kccs.greenearth.framework.xrmi.serialize.auth.GUserSerializer}が取得できます。<br>
 * <br>
 * 【シリアライザのキャッシュについて】<br>
 * このファクトリクラスでは、取得する度にシリアライザをインスタンス化しないように、<br>
 * 一度取得したシリアライザはキャッシュに保持し、次回からはキャッシュから取得する仕組みになっています。<br>
 * 
 * @create 2009/09/03
 * @author murashige
 * @since 3.6.0
 */
public final class GXmlSerializerFactoryImpl extends GXmlSerializerFactory {

	/** シリアライザの一覧. */
	private List<GXmlElementSerializer> _serializerList = new ArrayList<GXmlElementSerializer>();
	/** キャッシュ用のプール */
	private Map<Class< ? >, GXmlElementSerializer> _serializerCachePool = new ConcurrentHashMap<Class< ? >, GXmlElementSerializer>();

	/**
	 * {@link GXmlSerializerFactory}インスタンスを初期化します.<br>
	 * <br>
	 * 初期化されたインスタンスには引数に指定されたシリアライザのリストがセットされます。<br>
	 * 
	 * @create 2008/12/09
	 * @param serializer シリアライザのリスト
	 * @author yamashita
	 * @since 3.6.0
	 */
	public GXmlSerializerFactoryImpl(List<GXmlElementSerializer> serializer) {
		_serializerList = serializer;
	}

	/**
	 * 指定された値に対応するシリアライザを取得します。<br>
	 * <br>
	 * <code>null</code>が指定された場合には<code>null</code>に対応するシリアライザを返します。<br>
	 * <code>null</code>以外の値が指定された場合には指定された値に対応するシリアライザを返します。<br>
	 * 
	 * @create 2008/12/09
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory#getSerializer(Object)
	 * @param target 値
	 * @return {@link GXmlElementSerializer}インスタンス
	 * @author yamashita
	 * @since 3.6.0
	 */
	public GXmlElementSerializer getSerializer(Object target) {
		if (target == null) {
			return getSerializer((Class< ? >) null);
		} else {
			return getSerializer(target.getClass());
		}
	}

	/**
	 * 指定された型に対応するシリアライザを取得します。<br>
	 * <br>
	 * <code>null</code>が指定された場合には<code>null</code>に対応するシリアライザを返します。<br>
	 * <code>null</code>以外の型が指定された場合には指定された型に対応するシリアライザを返します。<br>
	 * 
	 * 取得したシリアライザはキャッシュに保持しておき、次回からはキャッシュから取得します。<br>
	 * また、指定した型に対応するシリアライザがない場合には<code>null</code>を返します。<br>
	 * 
	 * @create 2008/12/09
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory#getSerializer(Class)
	 * @param type 型
	 * @return {@link GXmlElementSerializer}インスタンス
	 * @author yamashita
	 * @since 3.6.0
	 */
	public GXmlElementSerializer getSerializer(Class< ? > type) {

		if (type == null) {
			type = Null.class;
		}

		if (_serializerCachePool.containsKey(type)) {
			return _serializerCachePool.get(type);
		}

		Map<Class< ? >, Class< ? >> genealogyClasses = getGenealogyClasses(type);

		for (GXmlElementSerializer serializer : _serializerList) {
			Class< ? > key = serializer.getSerializeTarget();
			if (genealogyClasses.containsKey(key)) {
				// キャッシュに登録
				_serializerCachePool.put(type, serializer);
				return serializer;
			}
		}

		return null;
	}

	/**
	 * 指定された型と継承関係にある全てのスーパークラス、インターフェースを<br>
	 * キーと値にそれぞれ型をそれぞれセットしたマップを返します。<br>
	 * 
	 * @create 2009/09/03
	 * @param type 型
	 * @return 型一覧マップ
	 * @author murashige
	 * @since 3.6.0
	 */
	protected Map<Class< ? >, Class< ? >> getGenealogyClasses(Class< ? > type) {
		Map<Class< ? >, Class< ? >> map = new HashMap<Class< ? >, Class< ? >>();
		map.put(type, type);

		Class< ? >[] interfaces = type.getInterfaces();
		for (Class< ? > interfaceClass : interfaces) {
			map.putAll(getGenealogyClasses(interfaceClass));
		}
		Class< ? > superClass = type.getSuperclass();
		if (superClass == null) {
			return map;
		}
		map.put(superClass, superClass);
		map.putAll(getGenealogyClasses(superClass));
		return map;
	}
}
