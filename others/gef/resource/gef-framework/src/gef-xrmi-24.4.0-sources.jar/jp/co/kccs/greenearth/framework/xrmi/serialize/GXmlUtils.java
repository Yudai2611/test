/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;

/**
 * XML文字列生成用のユーティリティクラスです.<br>
 * 
 * @create 2008/12/08
 * @author yamashita
 * @since 3.6.0
 */
public final class GXmlUtils {

	/** 半角スペースをエスケープするかどうかのフラグ */
	private static final String WHITE_SPACE_ESCAPE_FLAG = "geframe.xrmi.Response.EscapeWhiteSpace";
	
	/**
	 * コンストラクタ.<br>
	 * 
	 * @create 2008/12/08
	 * @author yamashita
	 * @since 3.6.0
	 */
	private GXmlUtils() {
	}

	/**
	 * <code>XML</code>の属性として出力する文字列をエスケープします.<br>
	 * [1]次の変換を行います。<br>
	 * [1-1]<code>'&lt;'</code> -> <code>"&amp;lt;"</code><br>
	 * [1-2]<code>'&gt;'</code> -> <code>"&amp;gt;"</code><br>
	 * [1-3]<code>'&amp;'</code> -> <code>"&amp;amp;"</code><br>
	 * [1-4]<code>'"'</code> -> <code>"&amp;quot;"</code><br>
	 * [1-5]<code>'''</code> -> <code>"&amp;#39;"</code><br>
	 * 注意：<code>null</code>は属性の出力可否の判断に使用する場合があるので、そのまま<code>null</code>を返します。<br>
	 * 
	 * @create 2008/12/08
	 * @param str 変換対象文字列
	 * @return エスケープ済み文字列
	 * @author yamashita
	 * @since 3.6.0
	 */
	public static String escapeXMLAttribute(String str) {
		if (str == null) {
			return null;
		}
		StringBuilder builder = new StringBuilder();

		boolean isWhiteSpaceEscape = GBooleanUtils.toBoolean(GFrameworkUtils.getProperty(WHITE_SPACE_ESCAPE_FLAG, "false"));
		
		// 一文字ずつ評価、置換
		for (int i = 0; i < str.length(); i++) {
			switch (str.charAt(i)) {
				// エスケープ文字の置換
				case '<' :
					builder.append("&lt;");
					break;
				case '>' :
					builder.append("&gt;");
					break;
				case '&' :
					builder.append("&amp;");
					break;
				case '\"' :
					builder.append("&quot;");
					break;
				case '\'' :
					builder.append("&#39;");
					break;
				case ' ' :
					if(isWhiteSpaceEscape){
						builder.append("&#32;");
					}else{
						builder.append(str.charAt(i));						
					}
					break;
				// 非エスケープ文字の置換
				default :
					builder.append(str.charAt(i));
					break;
			}
		}
		return builder.toString();
	}
}
