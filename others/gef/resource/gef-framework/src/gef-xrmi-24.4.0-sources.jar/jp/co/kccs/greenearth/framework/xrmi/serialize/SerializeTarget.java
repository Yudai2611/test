/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 個々の{@link GXmlElementSerializer}がシリアライズ対象とするクラスを指定するアノテーションです。<br>
 * {@link GXmlElementSerializer}のクラスに指定してください。<br>
 * 
 * @create 2009/09/03
 * @author murashige
 * @since 3.6.0
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface SerializeTarget {

	/**
	 * シリアライズ対象クラスを指定します。
	 * 
	 * @create 2009/09/16
	 * @author murashige
	 * @since 3.6.0
	 */
	Class< ? > value();
}
