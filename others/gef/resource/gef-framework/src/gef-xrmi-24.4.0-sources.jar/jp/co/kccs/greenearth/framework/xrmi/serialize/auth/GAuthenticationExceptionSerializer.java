/*
 * Copyright 2009 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.auth;

import java.io.PrintWriter;

import jp.co.kccs.greenearth.framework.auth.GAuthenticationException;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GAuthenticationException}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GAuthenticationException}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>"
 *      errorCode="<b>エラーコード</b>" errorType="<b>エラータイプ</b>" &gt;
 *   &lt;message&gt;
 *     <b>エラーメッセージ</b>
 *   &lt;/message&gt;
 * 　&lt;description&gt;
 *     <b>詳細情報</b>
 *   &lt;/description&gt;
 *&lt;/data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GAuthenticationException}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>例外を特定する一意なキー(任意の値)</td><td>"authenticationException"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GAuthenticationException}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>エラーコード</b></td><td>{@link GAuthenticationException#getCode()}で取得できるエラーコード</td><td>"GEF-001002"</td></tr>
 * <tr><td><b>エラータイプ</b></td><td>{@link GAuthenticationException#getType()}で取得できるエラータイプ</td><td>{@link jp.co.kccs.greenearth.commons.resource.error.GErrorType#ERROR}(値は"error")</td></tr>
 * <tr><td><b>エラーメッセージ</b></td><td>{@link GAuthenticationException#getMessage()}で取得できるエラーメッセージ</td><td>"Authentication Error!!!"</td></tr>
 * <tr><td><b>詳細情報</b></td><td>{@link GAuthenticationException#getDescription()}で取得できる詳細情報</td><td>"詳細"</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 * <pre><code>&lt;data name="<b>authenticationException</b>" type="<b>jp.co.kccs.greenearth.framework.auth.GAuthenticationException</b>"
 *      errorCode="<b>GEF-001002</b>" errorType="<b>error</b>" &gt;
 *    &lt;message&gt;
 *      <b>Authentication Error!!!</b>
 *    &lt;/message&gt;
 *    &lt;description&gt;
 *      <b>詳細</b>
 *    &lt;/description&gt;
 * &lt;/data&gt;</pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * 
 * @create 2009/07/02
 * @author kitamura
 * @since 3.6.0
 */
@SerializeTarget(GAuthenticationException.class)
public class GAuthenticationExceptionSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2009/07/07
	 * @auther kitamura
	 * @since 3.6.0
	 */
	public GAuthenticationExceptionSerializer() {
	}

	/**
	 * {@link GAuthenticationException}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/07/07
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライター
	 * @param name キー
	 * @param data 値
	 * @author kitamura
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {

		if (!(data instanceof GAuthenticationException)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GAuthenticationException.class.getName() + "\".");
		}
		GAuthenticationException value = (GAuthenticationException) data;

		StringBuilder xml = new StringBuilder();

		GXmlElementBuilder builder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(builder, name);
		builder.setAttribute("errorCode", value.getCode());
		String errorType = value.getType() != null ? value.getType().toString() : null;
		builder.setAttribute("errorType", errorType);

		xml.append(builder.createStartTagString());

		if (value.getMessage() != null) {
			xml.append(createMessageTag(value));
		}

		if (value.getDescription() != null) {
			xml.append(createDescriptionTag(value));
		}
		xml.append(builder.createEndTagString());

		writer.print(xml.toString());
	}

	/**
	 * 指定された{@link GAuthenticationException}に設定された詳細情報を内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;description&gt;{@link GAuthenticationException}にセットされた詳細情報&lt;/description&gt;
	 * </pre>
	 * 
	 * @create 2009/07/07
	 * @param value 値
	 * @return XML文字列
	 * @author kitamura
	 * @since 3.6.0
	 */
	protected String createDescriptionTag(GAuthenticationException value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("description");
		xml.setInnerText(value.getDescription());
		return xml.createStartEndTagString();
	}

	/**
	 * 指定された{@link GAuthenticationException}に設定されたメッセージを内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;message&gt;{@link GAuthenticationException}にセットされたエラーメッセージ&lt;/message&gt;
	 * </pre>
	 * 
	 * @create 2009/07/31
	 * @param value 値
	 * @return XML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	protected String createMessageTag(GAuthenticationException value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("message");
		xml.setInnerText(value.getMessage());
		return xml.createStartEndTagString();
	}

}
