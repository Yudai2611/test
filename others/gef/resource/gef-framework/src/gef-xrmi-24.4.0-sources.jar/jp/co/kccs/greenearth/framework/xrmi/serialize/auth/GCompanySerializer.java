/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.auth;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GCompany}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GCompany}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data code="<b>会社コード</b>" status="<b>停止フラグ</b>"
 *  type="<b>クラス名</b>"&gt;
 *  &lt;parent&gt;　
 *    &lt;data code="XXXX" companyName="XXXX" .../&gt; <b>// 親会社</b>
 *  &lt;/parent&gt;
 *  &lt;companyName&gt;
 *    &lt;data type="XXXX".../&gt; <b>// 会社名</b>
 *  &lt;/companyName&gt;
 *  &lt;values&gt;
 *    &lt;data name="XXXX" type="XXXX".../&gt; <b>// バインドされたオブジェクト</b>  
 *    ...
 *  &lt;/values&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GCompany}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"company"</td></tr>
 * <tr><td><b>会社コード</b></td><td>{@link GCompany#getCode()}で取得できる会社コード</td><td>"15"</td></tr>
 * <tr><td><b>会社名</b></td><td>{@link GCompany#getName()}で取得できる会社名</td><td>"KCCS"</td></tr>
 * <tr><td><b>停止フラグ</b></td><td>{@link GCompany#isInvalid()}で取得できる停止フラグ</td><td>false</td></tr>
 * <tr><td><b>状態</b></td><td>{@link GCompany#getStatus()}で取得できる状態</td><td>Active</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GCompany}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>親会社</b></td><td>{@link GCompany#getParent()}で取得できる親会社</td><td>{@link GCompany}のオブジェクト</td></tr>
 * <tr><td><b>バインドされたオブジェクト</b></td><td>{@link GCompany#getValue(String)}で取得できるオブジェクト</td><td>任意のオブジェクト<b>※</b></td></tr>
 * </table>
 * <b>※ロールとバインドされたオブジェクトには、任意のオブジェクトが設定できる為、シリアライズ時に使用するシリアライザクラスは、 保存されているインスタンスの型によって変化します。</b>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data code="<b>15</b>" status="<b>Active</b>"
 *  type="<b>jp.co.kccs.greenearth.framework.auth.GCompany</b>"&gt;
 *  &lt;parent&gt;　
 *    <b>シリアライズされた{@link GCompany}のXML</b>
 *  &lt;/parent&gt;
 *  &lt;companyName&gt;
 *  　<b>シリアライズされたオブジェクトのXML文字列</b>
 *  &lt;/companyName&gt;
 *  &lt;values&gt;
 *  　<b>シリアライズされたオブジェクトのXML文字列</b>
 *    ...
 *  &lt;/values&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/08
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GCompany.class)
public class GCompanySerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2009/07/08
	 * @auther murashige
	 * @since 3.6.0
	 */
	public GCompanySerializer() {
	}

	/**
	 * {@link GCompany}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/07/08
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author murashige
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		GCompany company = (GCompany) data;
		
		GXmlElementBuilder companyXmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(companyXmlBuilder, name);
		companyXmlBuilder.setAttribute("code", company.getCode());
//		companyXmlBuilder.setAttribute("invalidFlag", Boolean.toString(company.getStatus()));
		companyXmlBuilder.setAttribute("status", company.getStatus().toString());

		// dataタグを開く
		writer.print(companyXmlBuilder.createStartTagString());
		
		// name要素作成
		printNameElement(writer, company);

		// parent要素作成
		printParentElement(writer, company);

		// values要素作成
		printValuesElement(writer, company);

		// dataタグを閉じる
		writer.print(companyXmlBuilder.createEndTagString());
	}
	
	// TODO : xsdファイルの見直し
	protected void printNameElement(PrintWriter writer, GCompany company) {
		Map<Locale, String> nameMap = company.getLocaleNameMap();
		if (nameMap == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder builder = new GXmlElementBuilder("companyName");
		writer.print(builder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(nameMap);
		serializer.serialize(writer, null, nameMap);
		writer.print(builder.createEndTagString());
	}

	/**
	 * parent要素を追加します.<br>
	 * 
	 * @create 2009/07/09
	 * @param writer ライタ 
	 * @param company 会社情報
	 * @author murashige
	 * @since 3.6.0
	 */
	protected void printParentElement(PrintWriter writer, GCompany company) {
		GCompany parent = company.getParent();
		if (parent == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder parentXmlBuilder = new GXmlElementBuilder("parent");
		writer.print(parentXmlBuilder.createStartTagString());
		GXmlElementSerializer parentSerializer = factory.getSerializer(parent);
		parentSerializer.serialize(writer, null, parent);
		writer.print(parentXmlBuilder.createEndTagString());
	}

	/**
	 * values要素を追加します.<br>
	 * 
	 * @create 2009/07/09
	 * @param writer ライタ
	 * @param company 会社情報
	 * @author murashige
	 * @since 3.6.0
	 */
	protected void printValuesElement(PrintWriter writer, GCompany company) {
		Iterator<String> valuesKeys = company.getValueKeys();
		if (!valuesKeys.hasNext()) {
			return;
		}
		
		GXmlSerializerFactory factory = getSerializerFactory();

		// valuesタグを開く
		GXmlElementBuilder valueXmlBuilder = new GXmlElementBuilder("values");
		writer.print(valueXmlBuilder.createStartTagString());

		// valuesの内容を出力する
		while (valuesKeys.hasNext()) {
			String key = valuesKeys.next();
			Object value = company.getValue(key);
			GXmlElementSerializer valuesSerializer = factory.getSerializer(value);
			valuesSerializer.serialize(writer, key, value);
		}

		// valuesタグを閉じる
		writer.print(valueXmlBuilder.createEndTagString());
	}
}
