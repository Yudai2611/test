/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.auth;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.auth.GGroup;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GGroup}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GGroup}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data groupId="<b>グループID</b>" status="<b>状態</b>"
 *　type="<b>クラス名</b>"&gt;
 *  &lt;company&gt;　
 *    &lt;data code="XXXX" companyName="XXXX" .../&gt; <b>// グループが属する会社</b>
 *  &lt;/company&gt;
 *  &lt;parent&gt;　
 *    &lt;data groupId="XXXX" groupName="XXXX" .../&gt; <b>// 親グループ</b>
 *  &lt;/parent&gt;
 *  &lt;groupName&gt;
 *     &lt;data name="XXXX" type="XXXX".../&gt;
 *       ・・・
 *     &lt;/data&gt;
 *  &lt;/groupName&gt;
 *  &lt;values&gt;
 *    &lt;data name="XXXX" type="XXXX".../&gt; <b>// バインドされたオブジェクト</b>  
 *    ...
 *  &lt;/values&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GGroup}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"group"</td></tr>
 * <tr><td><b>グループID</b></td><td>{@link GGroup#getId()}で取得できるグループID</td><td>"testgroup"</td></tr>
 * <tr><td><b>グループ名</b></td><td>{@link GGroup#getName()}で取得できるグループ名</td><td>"テストグループ"</td></tr>
 * <tr><td><b>停止フラグ</b></td><td>{@link GGroup#isInvalid()}で取得できる停止フラグ</td><td>true</td></tr>
 * <tr><td><b>状態</b></td><td>{@link GGroup#getStatus()}で取得できる状態</td><td>Active</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GGroup}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>グループが属する会社</b></td><td>{@link GGroup#getCompany()}で取得できるグループが属する会社</td><td>{@link GCompany}のオブジェクト</td></tr>
 * <tr><td><b>親グループ</b></td><td>{@link GGroup#getParent()}で取得できる親グループ</td><td>{@link GGroup}のオブジェクト</td></tr>
 * <tr><td><b>ロール</b></td><td>{@link GGroup#getRoll()}で取得できるロール</td><td>任意のオブジェクト<b>※</b></td></tr>
 * <tr><td><b>バインドされたオブジェクト</b></td><td>{@link GGroup#getValue(String)}で取得できるバインドされたオブジェクト</td><td>任意のオブジェクト<b>※</b></td></tr>
 * </table>
 * <b>※ロールとバインドされたオブジェクトには、任意のオブジェクトが設定できる為、シリアライズ時に使用するシリアライザクラスは、 保存されているインスタンスの型によって変化します。</b>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data groupId="<b>testgroup</b>" status="<b>Active</b>"
 *　type="<b>jp.co.kccs.greenearth.framework.auth.GGroup</b>"&gt;
 *  &lt;company&gt;　
 *   <b>// シリアライズされた{@link GCompany}のXML</b>
 *  &lt;/company&gt;
 *  &lt;parent&gt;　
 *   <b>// シリアライズされた{@link GGroup}のXML</b>
 *  &lt;/parent&gt;
 *  &lt;groupName&gt;
 *   <b>// シリアライズされたオブジェクトのXML</b>
 *  &lt;/groupName&gt;
 *  &lt;values&gt;
 *   <b>// シリアライズされたオブジェクトのXML</b>
 *    ...
 *  &lt;/values&gt;
 * &lt;/data&gt;</pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/15
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GGroup.class)
public class GGroupSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/18
	 * @auther aono
	 * @since 3.6.0
	 */
	public GGroupSerializer() {
	}

	/**
	 * {@link GGroup}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/07/15
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author murashige
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		GGroup group = (GGroup) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("groupId", group.getId());
//		xmlBuilder.setAttribute("invalidFlag", Boolean.toString(group.getStatus()));
		xmlBuilder.setAttribute("status", group.getStatus().toString());

		// dataタグを開く
		writer.print(xmlBuilder.createStartTagString());

		// company要素を書き込み
		printCompanyElement(writer, group);

		// parent(親グループ)要素作成
		printGroupElement(writer, group);
		
		// name要素
		printNameElement(writer, group);

		// value要素作成
		printValuesElements(writer, group);

		// dataタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * company要素を追加します.
	 * @create 2008/12/18
	 * @param writer ライタ
	 * @param group グループ情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printCompanyElement(PrintWriter writer, GGroup group) {
		GCompany company = group.getCompany();
		if (company == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder companyXmlBuilder = new GXmlElementBuilder("company");
		writer.print(companyXmlBuilder.createStartTagString());

		GXmlElementSerializer companySerializer = factory.getSerializer(company);
		companySerializer.serialize(writer, null, company);

		writer.print(companyXmlBuilder.createEndTagString());
	}

	/**
	 * group要素を追加します.
	 * @create 2008/12/18
	 * @param writer ライタ
	 * @param group グループ情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printGroupElement(PrintWriter writer, GGroup group) {
		GGroup parent = group.getParent();
		if (parent == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder parentXmlBuilder = new GXmlElementBuilder("parent");
		writer.print(parentXmlBuilder.createStartTagString());

		GXmlElementSerializer groupSerializer = factory.getSerializer(parent);
		groupSerializer.serialize(writer, null, parent);

		writer.print(parentXmlBuilder.createEndTagString());
	}
	
	// TODO : xsdファイルの見直し
	protected void printNameElement(PrintWriter writer, GGroup group) {
		Map<Locale, String> nameMap = group.getLocaleNameMap();
		if (nameMap == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder builder = new GXmlElementBuilder("groupName");
		writer.print(builder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(nameMap);
		serializer.serialize(writer, null, nameMap);
		writer.print(builder.createEndTagString());
	}

	/**
	 * values要素を追加します.
	 * @create 2008/12/18
	 * @param writer ライタ
	 * @param group グループ情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printValuesElements(PrintWriter writer, GGroup group) {
		Iterator<String> valuesKeys = group.getValueKeys();
		if (!valuesKeys.hasNext()) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder valueXmlBuilder = new GXmlElementBuilder("values");
		writer.print(valueXmlBuilder.createStartTagString());
		while (valuesKeys.hasNext()) {
			String key = valuesKeys.next();
			Object value = group.getValue(key);
			GXmlElementSerializer valuesSerializer = factory.getSerializer(value);
			valuesSerializer.serialize(writer, key, value);
		}
		writer.print(valueXmlBuilder.createEndTagString());
	}
}
