/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.auth;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.auth.GGroup;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GUser}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GUser}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data password="<b>パスワード</b>" userId="<b>ユーザーID</b>" status="<b>状態</b>"
 *  type="<b>クラス名</b>"&gt;
 *  &lt;company&gt;　
 *    &lt;data code="XXXX" type="XXXX" status="XXXX" .../&gt; <b>// ユーザーが属する会社</b>
 *  &lt;/company&gt;
 *  &lt;userName&gt;　
 *    &lt;data type="XXXX"&gt; <b>// ユーザーの名前</b>
 *    ・・・
 *    &lt;/data&gt;
 *  &lt;/userName&gt;
 *  &lt;values&gt;　
 *    &lt;data type="XXXX" name="XXXX"&gt; <b>// バインドされたオブジェクト</b>
 *    XXXX
 *    &lt;/data&gt;
 *  &lt;/values&gt;
 *  &lt;locale&gt;　
 *    &lt;data type="XXXX" language="XXXX" .../&gt; <b>// ロケール情報</b>
 *  &lt;/locale&gt;
 *  &lt;groupMatrix&gt;
 *     &lt;groupMap index="インデックス"&gt;　<b>// ユーザーが属するグループリスト</b>
 *         &lt;data name="XXXX" type="XXXX".../&gt;
 *       ・・・
 *     &lt;/groupMap&gt;
 *     ・・・
 *  &lt;/groupMatrix&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GUser}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"user"</td></tr>
 * <tr><td><b>ユーザーID</b></td><td>{@link GUser#getId()}で取得できるユーザーID</td><td>"testuser"</td></tr>
 * <tr><td><b>ユーザー名</b></td><td>{@link GUser#getName()}で取得できるユーザー名</td><td>"テストユーザー"</td></tr>
 * <tr><td><b>パスワード</b></td><td>{@link GUser#getPassword()}で取得できるパスワード</td><td>"testtest"</td></tr>
 * <tr><td><b>停止フラグ</b></td><td>{@link GUser#isInvalid()}で取得できる停止フラグ</td><td>false</td></tr>
 * <tr><td><b>ユーザーが所属するグループ情報</b></td><td>{@link GUser#getGroupMatrix()}で取得できるグループのマップ</td><td>{@link Map}のオブジェクト</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GUser}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>ユーザーが属する会社</b></td><td>{@link GUser#getCompany()}で取得できる会社</td><td>{@link GCompany}のオブジェクト</td></tr>
 * <tr><td><b>ユーザーが属するグループリスト</b></td><td>{@link GUser#getGroupMap(int)}で取得できるグループマップのリスト</td><td>{@link java.util.List}(<code>List&ltMap&lt;String, GGroup&gt;&gt;</code>)のオブジェクト</td></tr>
 * <tr><td><b>インデックス</b></td><td>{@link GUser#getGroupMap(int)}で取得できるグループマップのインデックス</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>ロール</b></td><td>{@link GUser#getRoll()}で取得できるロール</td><td>任意のオブジェクト<b>※</b></td></tr>
 * <tr><td><b>バインドされたオブジェクト</b></td><td>{@link GUser#getValue(String)}で取得できるオブジェクト</td><td>任意のオブジェクト<b>※</b></td></tr>
 * <tr><td><b>ユーザーの状態</b></td><td>{@link GUser#getStatus()}で取得できる文字列</td><td>任意のオブジェクト<b>※</b></td></tr>
 * </table>
 * <b>※ロールとバインドされたオブジェクトには、任意のオブジェクトが設定できる為、シリアライズ時に使用するシリアライザクラスは、 保存されているインスタンスの型によって変化します。</b>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data password="<b>testtest</b>" userId="<b>testuser</b>" status="<b>Active</b>"
 *  type="<b>jp.co.kccs.greenearth.framework.auth.GUser</b>"&gt;
 *  &lt;company&gt;　
 *    <b>// シリアライズされた{@link GCompany}のXML</b>
 *  &lt;/company&gt;
 *  &lt;groupCategory&gt;
 *    <b>// シリアライズされた{@link java.util.List}のXML</b>
 *  &lt;/groupCategory&gt;
 *  &lt;values&gt;
 *    <b>// シリアライズされたオブジェクトのXML</b>
 *    ...
 *  &lt;/values&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2008/07/14
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GUser.class)
public class GUserSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/18
	 * @auther aono
	 * @since 3.6.0
	 */
	public GUserSerializer() {
	}

	/**
	 * {@link GUser}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2008/12/08
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		GUser user = (GUser) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("userId", user.getId());
		xmlBuilder.setAttribute("password", user.getPassword());
//		xmlBuilder.setAttribute("invalidFlag", Boolean.toString(user.getStatus()));
		xmlBuilder.setAttribute("status", user.getStatus().toString());
		writer.print(xmlBuilder.createStartTagString());

		// company情報作成
		printCompanyElement(writer, user);
		
		// name要素作成
		printNameElement(writer, user);
		
		// value情報作成
		printValuesElement(writer, user);
		
		// locale情報作成
		printLocaleElement(writer, user);

		// groupCategory要素作成
		printGroupCategoryElement(writer, user);
		
		// groupMatrix要素
		printGroupMatrixElement(writer, user);

		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * 会社情報要素を追加します.<br>
	 * 
	 * @create 2008/12/25
	 * @param writer ライタ
	 * @param user ユーザ情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printCompanyElement(PrintWriter writer, GUser user) {
		GCompany company = user.getCompany();
		if (company == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("company");
		writer.print(xmlBuilder.createStartTagString());

		GXmlElementSerializer userSerializer = factory.getSerializer(user.getCompany());
		userSerializer.serialize(writer, null, user.getCompany());

		writer.print(xmlBuilder.createEndTagString());
	}
	
	/**
	 * グループ一覧要素を追加します.<br>
	 * 
	 * @create 2008/12/18
	 * @param writer ライタ
	 * @param user ユーザ情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printGroupCategoryElement(PrintWriter writer, GUser user) {
		try {
			user.getGroupCount();
		}
		catch (UnsupportedOperationException e) {
			return;
		}
		
		// グループ情報がある場合はgroupCategory要素を作成
		if (user.getGroupCount() == 0) {
			return;
		}
		// groupCategoryタグを開く
		GXmlElementBuilder groupCategoryXmlBuilder = new GXmlElementBuilder("groupCategory");
		writer.print(groupCategoryXmlBuilder.createStartTagString());

		GXmlSerializerFactory factory = getSerializerFactory();

		// Group情報作成
		for (int i = 0; i < user.getGroupCount(); i++) {
			// groupMapタグを開く
			GXmlElementBuilder groupMapXmlBuilder = new GXmlElementBuilder("groupMap");
			groupMapXmlBuilder.setAttribute("index", Integer.toString(i));
			writer.print(groupMapXmlBuilder.createStartTagString());

			Map<String, GGroup> groups = user.getGroupMap(i);
			for (String groupkey : groups.keySet()) {
				// group要素を追加する
				GGroup group = groups.get(groupkey);
				GXmlElementSerializer groupSerializer = factory.getSerializer(group);
				groupSerializer.serialize(writer, groupkey, group);
			}

			// groupMapタグを閉じる
			writer.print(groupMapXmlBuilder.createEndTagString());
		}
		// groupCategoryタグを閉じる
		writer.print(groupCategoryXmlBuilder.createEndTagString());
	}
	
	protected void printGroupMatrixElement(PrintWriter writer, GUser user) {
		try {
			user.getGroupMatrix();
		}
		catch (UnsupportedOperationException e) {
			return;
		}
		if (user.getGroupMatrix() == null || user.getGroupMatrix().size() == 0) {
			return;
		}		
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder builder = new GXmlElementBuilder("groupMatrix");
		writer.print(builder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(user.getGroupMatrix());
		serializer.serialize(writer, null, user.getGroupMatrix());
		writer.print(builder.createEndTagString());
		
	}
	
	protected void printLocaleElement(PrintWriter writer, GUser user) {
		Locale data = user.getLocale();
		if (data == null) {
			return;
		}		
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("locale");
		writer.print(xmlBuilder.createStartTagString());

		GXmlElementSerializer serializer = factory.getSerializer(data);
		serializer.serialize(writer, null, data);

		writer.print(xmlBuilder.createEndTagString());
	}
	
	// TODO : xsdファイルの見直し
	protected void printNameElement(PrintWriter writer, GUser user) {
		Map<Locale, String> nameMap = user.getLocaleNameMap();
		if (nameMap == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder builder = new GXmlElementBuilder("userName");
		writer.print(builder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(nameMap);
		serializer.serialize(writer, null, nameMap);
		writer.print(builder.createEndTagString());
	}
	
	/**
	 * values要素を追加します.
	 * @create 2008/12/18
	 * @param writer ライタ
	 * @param user ユーザ情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printValuesElement(PrintWriter writer, GUser user) {
		Iterator<String> valuesKeys = user.getValueKeys();
		if (!valuesKeys.hasNext()) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();

		// valuesタグを開く
		GXmlElementBuilder valueXmlBuilder = new GXmlElementBuilder("values");
		writer.print(valueXmlBuilder.createStartTagString());

		// valuesの内容を出力する
		while (valuesKeys.hasNext()) {
			String key = valuesKeys.next();
			Object value = user.getValue(key);
			GXmlElementSerializer valuesSerializer = factory.getSerializer(value);
			valuesSerializer.serialize(writer, key, value);
		}

		// valuesタグを閉じる
		writer.print(valueXmlBuilder.createEndTagString());
	}
}
