/*
 * Copyright 2010 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.authorization;

import java.io.PrintWriter;

import jp.co.kccs.greenearth.framework.authorization.GAuthorizationException;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**TODO doc
 * {@link GAuthorizationException}型のデータをXML文字列に変換する為の例外シリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GAuthorizationException}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>"
 *      errorCode="<b>エラーコード</b>" errorType="<b>エラータイプ</b>" &gt;
 *   &lt;message&gt;
 *     <b>エラーメッセージ</b>
 *   &lt;/message&gt;
 * 　&lt;description&gt;
 *     <b>詳細情報</b>
 *   &lt;/description&gt;
 *&lt;/data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GAuthorizationException}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>例外を特定する一意なキー(任意の値)</td><td>"applicationException"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GAuthorizationException}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>エラーコード</b></td><td>{@link GAuthorizationException#getCode()}で取得できるエラーコード</td><td>"GEF-001001"</td></tr>
 * <tr><td><b>エラータイプ</b></td><td>{@link GAuthorizationException#getType()}で取得できるエラータイプ</td><td>{@link jp.co.kccs.greenearth.commons.resource.error.GErrorType#ERROR}(値は"error")</td></tr>
 * <tr><td><b>エラーメッセージ</b></td><td>{@link GAuthorizationException#getMessage()}で取得できるエラーメッセージ</td><td>"Application Error!!!"</td></tr>
 * <tr><td><b>詳細情報</b></td><td>{@link GAuthorizationException#getDescription()}で取得できる詳細情報</td><td>"詳細"</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 * <pre><code>&lt;data name="<b>authorizationException</b>" type="<b>jp.co.kccs.greenearth.commons.GAuthorizationException</b>"
 *      errorCode="<b>GEF-001001</b>" errorType="<b>error</b>" &gt;
 *    &lt;message&gt;
 *      <b>Application Error!!!</b>
 *    &lt;/message&gt;
 *    &lt;description&gt;
 *      <b>詳細</b>
 *    &lt;/description&gt;
 * &lt;/data&gt;</pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/22
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GAuthorizationException.class)
public class GAuthorizationExceptionSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2009/03/10
	 * @auther yamashita
	 * @since 3.6.0
	 */
	public GAuthorizationExceptionSerializer() {
	}

	/**
	 * {@link GAuthorizationException}型のデータをXMLにシリアライズします.<br>
	 * 
	 * @create 2009/03/10
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {

		if (!(data instanceof GAuthorizationException)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GAuthorizationException.class.getName() + "\".");
		}
		GAuthorizationException value = (GAuthorizationException) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("errorCode", value.getCode());
		String errorType = value.getType() != null ? value.getType().toString() : null;
		xmlBuilder.setAttribute("errorType", errorType);

		writer.print(xmlBuilder.createStartTagString());

		if (value.getMessage() != null) {
			writer.print(createMessageTag(value));
		}

		if (value.getDescription() != null) {
			writer.print(createDescriptionTag(value));
		}
		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * 指定された{@link GAuthorizationException}に設定された詳細情報を内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;description&gt;{@link GAuthorizationException}にセットされた詳細情報&lt;/description&gt;
	 * </pre>
	 * 
	 * @create 2009/07/30
	 * @param value 値
	 * @return XML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	protected String createDescriptionTag(GAuthorizationException value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("description");
		xml.setInnerText(value.getDescription());
		return xml.createStartEndTagString();
	}

	/**
	 * 指定された{@link GAuthorizationException}に設定されたメッセージを内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;message&gt;{@link GAuthorizationException}にセットされたエラーメッセージ&lt;/message&gt;
	 * </pre>
	 * 
	 * @create 2009/07/31
	 * @param value 値
	 * @return XML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	protected String createMessageTag(GAuthorizationException value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("message");
		xml.setInnerText(value.getMessage());
		return xml.createStartEndTagString();
	}

}
