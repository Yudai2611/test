/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.authorization;

import java.io.PrintWriter;
import java.util.Date;

import jp.co.kccs.greenearth.framework.authorization.GEditableRole;
import jp.co.kccs.greenearth.framework.authorization.GRole;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

@SerializeTarget(GRole.class)
public class GEditableRoleSerializer extends GRoleSerializer {
	
	@Override
	protected void decorateAttribute(GXmlElementBuilder builder, GRole role) {
		super.decorateAttribute(builder, role);
		
		GEditableRole editableRole = (GEditableRole) role;
		builder.setAttribute("displayNameResourceID", editableRole.getDisplayNameResourceID());
		builder.setAttribute("updatedPerson", editableRole.getUpdatedPerson());
		builder.setAttribute("exclusiveKey", editableRole.getExclusiveKey());
	}
	
	@Override
	protected void printInnerText(PrintWriter writer, GRole role) {
		super.printInnerText(writer, role);
		
		GEditableRole editableRole = (GEditableRole) role;
		printDescriptionElement(writer, editableRole);
		printUpdatedDateElement(writer, editableRole);
	}
	
	protected void printDescriptionElement(PrintWriter writer, GEditableRole value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("description");
		xml.setInnerText(value.getDescription());
		writer.print(xml.createStartEndTagString());
	}
	
	protected void printUpdatedDateElement(PrintWriter writer, GEditableRole value) {
		Date updatedDate = value.getUpdatedDate();
		if (updatedDate == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("updatedDate");
		writer.print(xmlBuilder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(updatedDate);
		serializer.serialize(writer, null, updatedDate);
		writer.print(xmlBuilder.createEndTagString());
	}

}
