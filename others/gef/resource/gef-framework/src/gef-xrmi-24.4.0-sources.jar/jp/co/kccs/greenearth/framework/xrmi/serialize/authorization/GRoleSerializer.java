/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.authorization;

import java.io.PrintWriter;
import java.util.Locale;
import java.util.Map;

import jp.co.kccs.greenearth.framework.authorization.GRole;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GRole}型のデータをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GRole}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data objectID="<b>オブジェクトID</b>" roleID="<b>ロールID</b>"
 *   &lt;authoritySet&gt;<b>権限セット</b>&lt;/authoritySet&gt;
 *   &lt;displayNameMap&gt;
 *   	&lt;data type="XXXX"&gt;
 *   		&lt;map&gt;
 *   			・・・
 *   		&lt;/map&gt;
 *   	&lt;/data&gt;
 *   &lt;/displayNameMap&gt;
 *&lt;/data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GRole}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>例外を特定する一意なキー(任意の値)</td><td>""</td></tr>
 * <tr><td><b>オブジェクトID</b></td><td>{@link GRole#getObjectID()}で取得できるオブジェクトID</td><td>"objectid..."</td></tr>
 * <tr><td><b>ロールID</b></td><td>{@link GRole#getRoleID()}で取得できるロールID</td><td>"roleid..."</td></tr>
 * <tr><td><b>表示名</b></td><td>{@link GRole#getDisplayNameMap()}で取得できる表示名のマップ</td><td>"表示名の{@link Map}"</td></tr>
 * <tr><td><b>ロール名</b></td><td>{@link GRole#getDisplayName(Locale)}で取得できるメニュー名</td><td>"ロール名"</td></tr>
 * <tr><td><b>会社コード</b></td><td>{@link GRole#getCompanyCode()}で取得できる会社コード</td><td>"15"</td></tr>
 * <tr><td><b>権限集合</b></td><td>{@link GRole#getAuthoritySet()}で取得できる権限集合</td><td>"role.aaa"</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data objectID="<b>objectid...</b>" roleID="<b>roleid...</b>"
 *   &lt;authoritySet&gt;
 *     <b>authoritySet...</b>
 *   &lt;/authoritySet&gt;
 * 　&lt;displayNameMap&gt;
 *     ・・・
 *   &lt;/displayNameMap&gt;
 *&lt;/data&gt;</code></pre>
 *</tr></td></table>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/22
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GRole.class)
public class GRoleSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/18
	 * @auther aono
	 * @since 3.6.0
	 */
	public GRoleSerializer() {
	}

	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GRole)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GRole.class.getName() + "\".");
		}
		GRole value = (GRole) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		decorateAttribute(xmlBuilder, value);

		writer.print(xmlBuilder.createStartTagString());
		printInnerText(writer, value);
		writer.print(xmlBuilder.createEndTagString());
	}
	
	protected void decorateAttribute(GXmlElementBuilder builder, GRole role) {
		builder.setAttribute("objectID", role.getObjectID());
		builder.setAttribute("companyCode", role.getCompanyCode());
		builder.setAttribute("roleID", role.getRoleID());
	}
	
	protected void printInnerText(PrintWriter writer, GRole role) {
		printAuthoritySetElement(writer, role);
		printDisplayNameMapElement(writer, role);
	}

	protected void printAuthoritySetElement(PrintWriter writer, GRole value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("authoritySet");
		xml.setInnerText(value.getAuthoritySet());
		writer.print(xml.createStartEndTagString());
	}

	protected void printDisplayNameMapElement(PrintWriter writer, GRole value) {
		Map<Locale, String> displayNameMap = value.getDisplayNameMap();
		if (displayNameMap == null) {
			return;
		}		
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder xml = new GXmlElementBuilder("displayNameMap");
		writer.print(xml.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(value.getDisplayNameMap());
		serializer.serialize(writer, null, value.getDisplayNameMap());
		
		writer.print(xml.createEndTagString());	
	}
}

