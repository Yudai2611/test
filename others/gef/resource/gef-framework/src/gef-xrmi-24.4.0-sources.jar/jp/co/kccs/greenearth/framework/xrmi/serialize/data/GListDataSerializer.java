/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.data;

import java.io.PrintWriter;
import java.util.ListIterator;

import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GListData}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GListData}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>キー名</b>" startIndex="<b>リストの開始インデックス</b>" totalSize="<b>リストの合計サイズ</b>"
 *　maxListSize="<b>1ページに表示する最大件数</b>" type="<b>クラス名</b>"&gt;
 *  &lt;rows&gt;　
 *    &lt;data name="XXXX" type="XXXX" .../&gt; <b>// 行データ</b>
 *    ...
 *  &lt;/rows&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GListData}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"listdata"</td></tr>
 * <tr><td><b>リストの開始インデックス</b></td><td>{@link GListData#getStartIndex()}で取得できるリストの開始インデックス</td><td>5</td></tr>
 * <tr><td><b>リストの合計サイズ</b></td><td>{@link GListData#getTotalSize()}で取得できるリストの合計サイズ</td><td>20</td></tr>
 * <tr><td><b>1ページに表示する最大件数</b></td><td>{@link GListData#getMaxListSize()}で取得できる1ページに表示する最大件数</td><td>10</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GListData}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>行データ</b></td><td>{@link GListData#get(int)}で取得できる行データ</td><td>{@link GRowData}のオブジェクト<b>※</b></td></tr>
 * </table>
 * <b>※行データに保持されるオブジェクトは{@link GRowData}型であるため、シリアライズ時に使用するシリアライザクラスは、 {@link GRowData}に対応したシリアライザクラスになります。。</b>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>listdata</b>" startIndex="<b>5</b>" totalSize="<b>20</b>"
 *　maxListSize="<b>10</b>" type="<b>jp.co.kccs.greenearth.framework.data.GListData</b>"&gt;
 *  &lt;rows&gt;　
 *   <b>// シリアライズされたGRowDataのXML</b>
 *    ...
 *  &lt;/rows&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/15
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GListData.class)
public class GListDataSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/18
	 * @auther aono
	 * @since 3.6.0
	 */
	public GListDataSerializer() {
	}

	/**
	 * {@link GListData}型のデータと内包するデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/07/15
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author murashige
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GListData)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GListData.class.getName() + "\".");
		}
		GListData value = (GListData) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("maxListSize", Integer.toString(value.getMaxListSize()));
		xmlBuilder.setAttribute("startIndex", Integer.toString(value.getStartIndex()));
		xmlBuilder.setAttribute("totalSize", Integer.toString(value.getTotalSize()));

		// GListDataタグを開く
		writer.print(xmlBuilder.createStartTagString());

		// GRowData内に含まれるデータのシリアライズ
		printRowsElement(writer, value);

		// GListDataタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * rows要素を追加します.
	 * @create 2008/12/25
	 * @param writer ライタ
	 * @param value リストデータ
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printRowsElement(PrintWriter writer, GListData value) {

		ListIterator<GRowData> iterator = value.listIterator();
		if (!iterator.hasNext()) {
			return;
		}
		// rowsタグを開く
		GXmlElementBuilder rowsXmlBuilder = new GXmlElementBuilder("rows");
		writer.print(rowsXmlBuilder.createStartTagString());

		GXmlSerializerFactory factory = getSerializerFactory();

		while (iterator.hasNext()) {
			GRowData row = iterator.next();
			GXmlElementSerializer serializer = factory.getSerializer(row);
			serializer.serialize(writer, null, row);
		}

		writer.print(rowsXmlBuilder.createEndTagString());
	}
}
