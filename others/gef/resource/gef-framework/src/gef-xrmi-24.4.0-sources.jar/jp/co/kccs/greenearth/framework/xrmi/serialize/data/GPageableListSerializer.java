/*
 * Copyright 2011-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.data;


import java.io.PrintWriter;
import java.util.ListIterator;

import jp.co.kccs.greenearth.framework.data.GPageableList;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

@SerializeTarget(GPageableList.class)
public class GPageableListSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/18
	 * @auther aono
	 * @since 3.6.0
	 */
	public GPageableListSerializer() {
	}

	/**
	 * {@link GPageableListSerializer}型のデータと内包するデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/07/15
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author murashige
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GPageableList<?>)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GPageableList.class.getName() + "\".");
		}
		GPageableList<?> value = (GPageableList<?>) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("maxListSize", Integer.toString(value.getMaxListSize()));
		xmlBuilder.setAttribute("startIndex", Integer.toString(value.getStartIndex()));
		xmlBuilder.setAttribute("totalSize", Integer.toString(value.getTotalSize()));

		// GBeanListDataタグを開く
		writer.print(xmlBuilder.createStartTagString());

		// Bean内に含まれるデータのシリアライズ
		printBeanElement(writer, value);

		// GListDataタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * rows要素を追加します.
	 * @create 2008/12/25
	 * @param writer ライタ
	 * @param value リストデータ
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printBeanElement(PrintWriter writer, GPageableList<?> value) {

		ListIterator<?> iterator = value.listIterator();
		if (!iterator.hasNext()) {
			return;
		}
		// beanタグを開く
		GXmlElementBuilder beansXmlBuilder = new GXmlElementBuilder("beans");
		writer.print(beansXmlBuilder.createStartTagString());

		GXmlSerializerFactory factory = getSerializerFactory();

		while (iterator.hasNext()) {
			Object bean = iterator.next();
			GXmlElementSerializer serializer = factory.getSerializer(bean);
			serializer.serialize(writer, null, bean);
		}

		writer.print(beansXmlBuilder.createEndTagString());
	}
}

