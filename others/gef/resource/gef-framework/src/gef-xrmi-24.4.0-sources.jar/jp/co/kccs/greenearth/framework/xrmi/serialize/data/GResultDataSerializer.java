/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.data;

import java.io.PrintWriter;
import java.util.List;

import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GResultData}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GResultData}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;resultData exitCode="<b>終了コード</b>" type="<b>クラス名</b>"&gt;
 *  &lt;datas&gt;　
 *    &lt;data name="XXXX" type="XXXX" .../&gt; <b>// 処理結果データ</b>
 *     ・・・
 *  &lt;/datas&gt;
 *  &lt;errors&gt;
 *     &lt;data type="XXXX".../&gt; <b>// 検証エラーリスト</b>
 *     ・・・
 *  &lt;/errors&gt;
 *  &lt;exception&gt;
 *     &lt;data type="XXXX".../&gt; <b>// システムエラー</b>
 *  &lt;/exception&gt;
 * &lt;/resultData&gt;
 *</pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GResultData}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>終了コード</b></td><td>{@link GResultData#getExitCode()}で取得できる終了コード</td><td>"success"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GResultData}の完全修飾名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>処理結果データ</b></td><td>{@link GResultData#getData(String)}で取得できる処理結果データ</td><td>任意のオブジェクト<b>※1</b></td></tr>
 * <tr><td><b>検証エラーリスト</b></td><td>{@link GResultData#getErrors()}で取得できる検証エラーリスト</td><td>{@link GValidateError}型のオブジェクト</td></tr>
 * <tr><td><b>システムエラー</b></td><td>{@link GResultData#getException(String)}で取得できる、<br>キー名が{@link GConstants#EXCEPTION_KEY}の例外オブジェクト</td><td>例外オブジェクト<b>※2</b></td></tr>
 * </table>
 * <b>※1処理結果データには、任意のオブジェクトが設定できる為、シリアライズ時に使用するシリアライザクラスは、 保存されているインスタンスの型によって変化します。</b><br>
 * <b>※2システムエラーとして設定される例外オブジェクトは、サーブレットがスローした例外になります。({@link jp.co.kccs.greenearth.framework.GResponseFilter}が補足し、{@link GResultData}に設定します。)<br>
 * また、システムエラーが設定された{@link GResultData}の終了コードには{@link GResultData#EXIT_CODE_SYSTEM_ERROR}がセットされています。</b><br>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;resultData exitCode="<b>success</b>" type="<b>jp.co.kccs.greenearth.framework.data.GResultData</b>"&gt;
 *  &lt;datas&gt;　
 *    <b>// シリアライズされたオブジェクトのXML</b>
 *  &lt;/datas&gt;
 *  &lt;errors&gt;
 *    <b>// シリアライズされた{@link GValidateError}のXML</b>
 *  &lt;/errors&gt;
 *  &lt;exception&gt;
 *    <b>// シリアライズされた{@link Throwable}のXML</b>
 *  &lt;/exception&gt;
 * &lt;/resultData&gt;
 *</pre>
 *</tr></td></table>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/18
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GResultData.class)
public class GResultDataSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/26
	 * @auther yamashita
	 * @since 3.6.0
	 */
	public GResultDataSerializer() {
	}

	/**
	 * {@link GResultData}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2008/12/08
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 結果セット({@link GResultData})オブジェクト
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GResultData)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GResultData.class.getName() + "\".");
		}
		GResultData resultData = (GResultData) data;

		GXmlElementBuilder resultDataBuilder = new GXmlElementBuilder("resultData");
		String exitCode = resultData.getExitCode();
		resultDataBuilder.setAttribute("exitCode", exitCode); // 終了コード
		resultDataBuilder.setAttribute("type", GResultData.class.getName());
		writer.print(resultDataBuilder.createStartTagString());

		// データ
		printDataElement(writer, resultData);

		// 検証エラー
		printValidateErrorElement(writer, resultData);

		// システムエラー
		if (GResultData.EXIT_CODE_SYSTEM_ERROR.equals(exitCode)) {
			printExceptionElement(writer, resultData);
		}

		writer.print(resultDataBuilder.createEndTagString());
	}

	/**
	 * 結果セットデータをXML文字列に変換します.<br>
	 * 
	 * @create 2008/12/26
	 * @param writer ライタ
	 * @param resultData 結果セット({@link GResultData})オブジェクト
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected void printDataElement(PrintWriter writer, GResultData resultData) {
		if (resultData.datasSize() == 0) {
			return;
		}
		
		GXmlSerializerFactory factory = getSerializerFactory();		

		GXmlElementBuilder datasBuilder = new GXmlElementBuilder("datas");
		writer.print(datasBuilder.createStartTagString());
		for (String name : resultData.dataNameSet()) {
			if (GConstants.EXCEPTION_KEY.equals(name)) {
				continue; // システムエラーとして詰まれた例外はパス
			}
			Object value = resultData.getData(name);
			GXmlElementSerializer serializer = factory.getSerializer(value);
			serializer.serialize(writer, name, value);
		}
		writer.print(datasBuilder.createEndTagString());
	}

	/**
	 * システムエラー時に処理を行います.<br>
	 * {@link Throwable}オブジェクトをXML文字列に変換します。<br>
	 * 
	 * @create 2008/12/26
	 * @param writer ライタ
	 * @param resultData 結果セット({@link GResultData})オブジェクト
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected void printExceptionElement(PrintWriter writer, GResultData resultData) {
		Throwable e = resultData.getException();
		if (e == null) {
			throw new NullPointerException("It is necessary to set the exception value to GResultData of the system error.");
		}
		GXmlSerializerFactory factory = getSerializerFactory();		

		GXmlElementBuilder exceptionBuilder = new GXmlElementBuilder("exception");
		writer.print(exceptionBuilder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(e);
		serializer.serialize(writer, null, e);
		writer.print(exceptionBuilder.createEndTagString());
	}

	/**
	 * 検証エラー時に処理を行います.<br>
	 * {@link GValidateError}オブジェクトをXML文字列に変換します。<br>
	 * 
	 * @create 2008/12/26
	 * @param writer ライタ
	 * @param resultData 結果セット({@link GResultData})オブジェクト
	 * @author yamashita
	 * @since 3.6.0
	 */
	protected void printValidateErrorElement(PrintWriter writer, GResultData resultData) {
		List<GValidateError> errors = resultData.getErrors();
		if (errors.size() == 0) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();		

		GXmlElementBuilder errorsBuilder = new GXmlElementBuilder("errors");
		writer.print(errorsBuilder.createStartTagString());

		for (GValidateError error : errors) {
			GXmlElementSerializer validateSerializer = factory.getSerializer(error);
			validateSerializer.serialize(writer, null, error);
		}
		writer.print(errorsBuilder.createEndTagString());
	}
}
