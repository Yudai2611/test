/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.data;

import java.io.PrintWriter;
import java.util.Map;

import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GRowData}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GRowData}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>"&gt;
 *  &lt;cells&gt;
 *    &lt;data name="XXXX" type="XXXX".../&gt; <b>// セルデータ</b>  
 *    ...
 *  &lt;/cells&gt;
 * &lt;/data&gt;
 *</pre>
 *
 * {@link jp.co.kccs.greenearth.framework.auth.GUser}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GRowData}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"rowdata"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GRowData}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>セルデータ</b></td><td>{@link GRowData#getData(String)}で取得できるセルデータ</td><td>任意のオブジェクト</td></tr>
 * </table>
 * <b>※セルデータには、任意のオブジェクトが設定できる為、シリアライズ時に使用するシリアライザクラスは、 保存されているインスタンスの型によって変化します。</b>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>rowdata</b>" type="<b>jp.co.kccs.greenearth.framework.data.GRowData</b>"&gt;
 *  &lt;cells&gt;
 *    <b>// シリアライズされたオブジェクトのXML</b>
 *  &lt;/cells&gt;
 * &lt;/data&gt;
 *</pre>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2008/12/08
 * @author yamashita
 * @since 3.6.0
 */
@SerializeTarget(GRowData.class)
public class GRowDataSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/18
	 * @auther aono
	 * @since 3.6.0
	 */
	public GRowDataSerializer() {
	}

	/**
	 * {@link GRowData}型のデータと内包するデータをXML文字列に変換します.<br>
	 * 
	 * @create 2008/12/15
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author yamashita
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GRowData)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GRowData.class.getName() + "\".");
		}
		GRowData value = (GRowData) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);

		// GRowDataタグを開く
		writer.print(xmlBuilder.createStartTagString());

		// GRowData内に含まれるデータのシリアライザクラス
		printCellsElement(writer, value);

		// GRowDataタグを閉じる
		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * rows要素を追加します.
	 * @create 2008/12/25
	 * @param writer ライタ
	 * @param value Rowデータ
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printCellsElement(PrintWriter writer, GRowData value) {
		Map<String, Object> cells = value.getCells();
		if (cells.size() == 0) {
			return;
		}
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("cells");
		writer.print(xmlBuilder.createStartTagString());

		GXmlSerializerFactory factory = getSerializerFactory();

		for (String key : cells.keySet()) {
			Object celldata = cells.get(key);
			GXmlElementSerializer serializer = factory.getSerializer(celldata);
			serializer.serialize(writer, key, celldata);
		}
		writer.print(xmlBuilder.createEndTagString());
	}
}
