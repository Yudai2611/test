/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.data;

import java.io.PrintWriter;
import java.util.List;

import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GValidateError}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GValidateError}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>キー名</b>" errorCode="<b>エラーコード</b>" errorType="<b>エラータイプ</b>"
 * label="<b>エラー項目名</b>" labelSpace="<b>エラー項目の名前空間</b>" type="<b>クラス名</b>"&gt;
 *  &lt;message&gt;
 *    <b>メッセージ</b>
 *  &lt;/message&gt;
 *  &lt;fieldIds&gt;
 *    &lt;data type="XXXX".../&gt; <b>// エラー項目ID</b>  
 *    ...
 *  &lt;/fieldIds&gt;
 *  &lt;description&gt;
 *    <b>詳細情報</b>
 *  &lt;/description&gt;
 * &lt;/data&gt;
 *</pre></tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GValidateError}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"validateerror"</td></tr>
 * <tr><td><b>エラーコード</b></td><td>{@link GValidateError#getCode()}で取得できるエラーコード</td><td>"GEF-000001"</td></tr>
 * <tr><td><b>エラータイプ</b></td><td>{@link GValidateError#getType()}で取得できるエラータイプ</td><td>"error"</td></tr>
 * <tr><td><b>エラー項目名</b></td><td>{@link GValidateError#getLabel()}で取得できるエラー項目名</td><td>"エラー項目"</td></tr>
 * <tr><td><b>エラー項目の名前空間</b></td><td>{@link GValidateError#getLabelspace()}で取得できるエラー項目の名前空間</td><td>"エラー項目の名前空間"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GValidateError}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>メッセージ要素</b></td><td>{@link GValidateError#getMessage()}で取得できるエラーメッセージ</td><td>"エラーメッセージ"</td></tr>
 * <tr><td><b>エラー項目ID要素</b></td><td>{@link GValidateError#getFieldIdList()}で取得できるエラー項目IDの一覧</td><td>"エラー項目ID"</td></tr>
 * <tr><td><b>詳細情報</b></td><td>{@link GValidateError#getDescription()}で取得できる詳細情報</td><td>"詳細"</td></tr>
 * </table>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>validateerror</b>" errorCode="<b>GEF-000001</b>" errorType="<b>error</b>"
 * label="<b>エラー項目名</b>" labelSpace="<b>エラー項目の名前空間</b>" type="<b>jp.co.kccs.greenearth.framework.data.GValidateError</b>"&gt;
 *  &lt;message&gt;
 *    <b>エラーメッセージ</b>
 *  &lt;/message&gt;
 *  &lt;fieldIds&gt;
 *    <b>// シリアライズされた{@link String}型のXML</b>  
 *    ...
 *  &lt;/fieldIds&gt;
 *  &lt;description&gt;
 *    <b>詳細</b>
 *  &lt;/description&gt;
 * &lt;/data&gt;
 *</pre></tr></td></table>
 *<br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * 
 * @create 2009/07/21
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GValidateError.class)
public class GValidateErrorSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2008/12/18
	 * @auther aono
	 * @since 3.6.0
	 */
	public GValidateErrorSerializer() {
	}

	/**
	 * {@link GValidateError}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/07/21
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author murashige
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GValidateError)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GValidateError.class.getName() + "\".");
		}
		GValidateError value = (GValidateError) data;

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("errorCode", value.getCode());
		xmlBuilder.setAttribute("label", value.getLabel());
		xmlBuilder.setAttribute("labelSpace", value.getLabelspace());
		if (value.getType() != null) {
			xmlBuilder.setAttribute("errorType", value.getType().toString());
		}

		// data要素を開く
		writer.print(xmlBuilder.createStartTagString());

		// メッセージを出力
		if (value.getMessage() != null) {
			writer.print(createMessageTag(value));
		}
		
		// エラー項目idを出力
		printFieldIdElement(writer, value.getFieldIdList());

		// 詳細情報を出力
		if (value.getDescription() != null) {
			writer.print(createDescriptionTag(value));
		}
		
		// data要素を閉じる
		writer.print(xmlBuilder.createEndTagString());
	}
	
	/**
	 * エラー項目id一覧要素を追加します.
	 * @create 2008/12/18
	 * @param writer ライタ
	 * @param fieldIds エラー項目リスト
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printFieldIdElement(PrintWriter writer, List<String> fieldIds) {
		if (fieldIds.size() == 0) {
			return;
		}
		GXmlElementBuilder grouplistXmlBuilder = new GXmlElementBuilder("fieldIds");

		// fieldIds要素を開く
		writer.print(grouplistXmlBuilder.createStartTagString());

		GXmlSerializerFactory factory = getSerializerFactory();
		// id要素を追加
		for (Object field : fieldIds) {
			GXmlElementSerializer serializer = factory.getSerializer(field);
			serializer.serialize(writer, null, field);
		}

		// fieldIds要素を閉じる
		writer.print(grouplistXmlBuilder.createEndTagString());
	}
	
	/**
	 * 指定された{@link GValidateError}に設定された詳細情報を内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;description&gt;{@link GValidateError}にセットされた詳細情報&lt;/description&gt;
	 * </pre>
	 * 
	 * @create 2009/07/31
	 * @param value 値
	 * @return XML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	protected String createDescriptionTag(GValidateError value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("description");
		xml.setInnerText(value.getDescription());
		return xml.createStartEndTagString();
	}

	/**
	 * 指定された{@link GValidateError}に設定されたメッセージを内包するXML文字列を返します。<br>
	 * <br>
	 * 返されるXML文字列のフォーマットは以下の通りです。<br>
	 * <pre>
	 * &lt;message&gt;{@link GValidateError}にセットされたエラーメッセージ&lt;/message&gt;
	 * </pre>
	 * 
	 * @create 2009/07/31
	 * @param value 値
	 * @return XML文字列
	 * @author murashige
	 * @since 3.6.0
	 */
	protected String createMessageTag(GValidateError value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("message");
		xml.setInnerText(value.getMessage());
		return xml.createStartEndTagString();
	}
	
}
