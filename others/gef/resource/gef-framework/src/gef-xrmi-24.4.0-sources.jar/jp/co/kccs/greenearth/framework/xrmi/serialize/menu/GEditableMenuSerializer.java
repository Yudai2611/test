/*
 * Copyright 2011-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.menu;

import java.io.PrintWriter;
import java.util.Date;

import jp.co.kccs.greenearth.framework.menu.GEditableMenu;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

@SerializeTarget(GMenu.class)
public class GEditableMenuSerializer extends GMenuSerializer {
	
	public GEditableMenuSerializer() {
	}
	
	@Override
	protected void decorateAttribute(GXmlElementBuilder builder, GMenu value) {
		super.decorateAttribute(builder, value);
		
		GEditableMenu menu = (GEditableMenu) value;
		builder.setAttribute("updatedPerson", menu.getUpdatedPerson());
		builder.setAttribute("exclusiveKey", menu.getExclusiveKey());
		builder.setAttribute("displayNameResourceID", menu.getDisplayNameResourceID());
		builder.setAttribute("parentObjectID", menu.getParentObjectID());
		builder.setAttribute("roleObjectID", menu.getRoleObjectID());
	}
	
	@Override
	protected void printInnerText(PrintWriter writer, GMenu value) {
		super.printInnerText(writer, value);
		
		GEditableMenu menu = (GEditableMenu) value;
		printDescriptionElement(writer, menu);
		printSortIndexElement(writer, menu);
		printUpdatedDateElement(writer, menu);
	}
	
	protected void printDescriptionElement(PrintWriter writer, GEditableMenu value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("description");
		xml.setInnerText(value.getDescription());
		writer.print(xml.createStartEndTagString());
	}
	
	protected void printSortIndexElement(PrintWriter writer, GEditableMenu value) {
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("sortIndex");
		writer.print(xmlBuilder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(value.getSortIndex());
		serializer.serialize(writer, null, value.getSortIndex());
		writer.print(xmlBuilder.createEndTagString());
	}
	
	protected void printUpdatedDateElement(PrintWriter writer, GEditableMenu value) {
		Date updatedDate = value.getUpdatedDate();
		if (updatedDate == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("updatedDate");
		writer.print(xmlBuilder.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(updatedDate);
		serializer.serialize(writer, null, updatedDate);
		writer.print(xmlBuilder.createEndTagString());
	}

}
