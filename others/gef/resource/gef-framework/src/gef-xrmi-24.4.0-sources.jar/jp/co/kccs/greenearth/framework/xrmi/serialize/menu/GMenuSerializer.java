/*
 * Copyright 2010-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.menu;

import java.io.PrintWriter;
import java.util.Locale;
import java.util.Map;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

@SerializeTarget(GMenu.class)
public class GMenuSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @author KCCS nishimura
	 * @since 2010/10/20
	 */
	public GMenuSerializer() {
	}

	/**
	 * {@link GMenu}型のデータをXML文字列に変換します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(java.io.PrintWriter,
	 *      java.lang.String, java.lang.Object)
	 * @param writer
	 * @param name
	 * @param data
	 * @author KCCS nishimura
	 * @since 2010/10/20
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GMenu)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \""
				+ GMenu.class.getName() + "\".");
		}
		GMenu value = (GMenu) data;
		
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		decorateAttribute(xmlBuilder, value);
		
		writer.print(xmlBuilder.createStartTagString());
		printInnerText(writer, value);
		writer.print(xmlBuilder.createEndTagString());
	}
	
	protected void decorateAttribute(GXmlElementBuilder builder, GMenu value) {
		builder.setAttribute("objectID", value.getObjectID());
		builder.setAttribute("companyCode", value.getCompanyCode());
		builder.setAttribute("menuID", value.getMenuID());
		builder.setAttribute("applicationType", value.getApplicationType());
		builder.setAttribute("menuType", value.getMenuType());
		builder.setAttribute("isItem", Boolean.valueOf(value.isItem()));
		builder.setAttribute("status", value.getStatus().toString());
	}
	
	protected void printInnerText(PrintWriter writer, GMenu value) {
		// StartModule
		printStartModuleElement(writer, value);
		// Parameter
		printParameterElement(writer, value);
		// Role
		//printRoleElement(writer, value);
		// DisplayName
		printDisplayNameMapElement(writer, value);
	}
	
	protected void printStartModuleElement(PrintWriter writer, GMenu value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("startModule");
		xml.setInnerText(value.getStartModule());
		writer.print(xml.createStartEndTagString());
	}
	
	protected void printParameterElement(PrintWriter writer, GMenu value) {
		GXmlElementBuilder xml = new GXmlElementBuilder("parameter");
		xml.setInnerText(value.getParameter());
		writer.print(xml.createStartEndTagString());
	}

	protected void printDisplayNameMapElement(PrintWriter writer, GMenu value) {
		Map<Locale, String> displayNameMap = value.getDisplayNameMap();
		if (displayNameMap == null) {
			return;
		}
		
		GXmlSerializerFactory factory = getSerializerFactory();
		GXmlElementBuilder xml = new GXmlElementBuilder("displayNameMap");
		writer.print(xml.createStartTagString());
		GXmlElementSerializer serializer = factory.getSerializer(value.getDisplayNameMap());
		serializer.serialize(writer, null, value.getDisplayNameMap());
		
		writer.print(xml.createEndTagString());	
	}
}
