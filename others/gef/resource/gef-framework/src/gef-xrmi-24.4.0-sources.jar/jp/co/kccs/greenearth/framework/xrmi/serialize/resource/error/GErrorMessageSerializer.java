/*
 * Copyright 2014 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.resource.error;

import java.io.PrintWriter;

import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GErrorMessage}型のデータをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * ・{@link GErrorMessage}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre>
 *<code>&lt;data name="<b>キー名</b>" type="<b>クラス名</b>"
 *      errorCode="<b>エラーコード</b>"
 *      errorMessage="<b>エラーメッセージ</b>"
 *      errorType="<b>エラータイプ</b>"
 *&lt;/data&gt;</code></pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GErrorMessage}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"errorMessage"</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GErrorMessage}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>エラーコード</b></td><td>{@link GErrorMessage#getCode()}で取得できるエラーコード</td><td>"GEF-000001"</td></tr>
 * <tr><td><b>エラーメッセージ</b></td><td>{@link GErrorMessage#getMessage()}で取得できるエラーメッセージ</td><td>"入力してください"</td></tr>
 * <tr><td><b>エラータイプ</b></td><td>{@link GErrorMessage#getType()}で取得できるエラータイプを文字列に変換したもの</td><td>"error"</td></tr>
 * </table><br>
 * 
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 * <pre><code>&lt;data name="<b>errorMessage</b>" type="<b>jp.co.kccs.greenearth.commons.resource.error.GErrorMessage</b>"
 *      errorCode="<b>GEF-000001</b>" errorMessage="<b>入力してください</b>" errorType="<b>error</b>" &gt;
 * &lt;/data&gt;</pre>
 *</tr></td></table>
 * <br>
 * 
 * このシリアライザクラスを使用する場合の設定については、{@link jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2014/06/21
 * @author KCCS N.Nishimura
 * @since 3.16.0
 */
@SerializeTarget(GErrorMessage.class)
public class GErrorMessageSerializer extends GXmlElementSerializerBase {

	/**
	 * {@link GErrorMessage}型のデータをXML文字列に変換します.<br>
	 * 
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(java.io.PrintWriter, java.lang.String, java.lang.Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author KCCS N.Nishimura
	 * @create 2014/06/20
	 * @since 3.16.0
	 */
	@Override
	public void serialize(PrintWriter writer, String name, Object data) {
		GErrorMessage errorMessage = castToTargetClass(data);
		String xmlString = buildXmlString(errorMessage, name);
		writer.print(xmlString);
	}

	private GErrorMessage castToTargetClass(Object data) {
		if (!(data instanceof GErrorMessage)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GErrorMessage.class.getName() + "\".");
		}
		return (GErrorMessage) data;
	}

	private String buildXmlString(GErrorMessage errorMessage, String name) {
		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		decorateAttribute(xmlBuilder, errorMessage);
		return xmlBuilder.createStartEndTagString();
	}

	private void decorateAttribute(GXmlElementBuilder builder, GErrorMessage errorMessage) {
		builder.setAttribute("errorCode", errorMessage.getCode());
		builder.setAttribute("errorMessage", errorMessage.getMessage());
		if (errorMessage.getType() != null) {
			builder.setAttribute("errorType", errorMessage.getType().toString());
		}
	}
}
