/*
 * Copyright 2009-2015 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.serialize.session;

import java.io.PrintWriter;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementBuilder;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializerBase;
import jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlSerializerFactory;
import jp.co.kccs.greenearth.framework.xrmi.serialize.SerializeTarget;

/**
 * {@link GSession}型データをXML文字列に変換する為のシリアライザクラスです.<br><br>
 * <br>
 * 
 * 【シリアライズされたXML文字列の形式】<br>
 * ・{@link GSession}型のデータは以下のような形式でXML文字列にシリアライズされます。<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>キー名</b>" sessionId="<b>セッションID</b>" invalid="<b>停止フラグ</b>"
 *  type="<b>クラス名</b>"&gt;
 *  &lt;createTime&gt;　
 *    &lt;data type="XXXX".../&gt; <b>// セッション生成時刻</b>
 *  &lt;/createTime&gt;
 *  &lt;loginUser&gt;
 *    &lt;data userID="XXXX" userName="XXXX" .../&gt; <b>// ログインユーザー</b>
 *  &lt;/loginUser&gt;
 *  &lt;locale&gt;
 *    &lt;data language="XXXX" country="XXXX".../&gt; <b>// ロケール</b>  
 *  &lt;/locale&gt;
 *  &lt;values&gt;
 *    &lt;data name="XXXX" type="XXXX".../&gt; <b>// バインドされたオブジェクト</b>  
 *    ...
 *  &lt;/values&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table>
 *<br>
 * 【シリアライズの例】 
 * <br>
 * 以下の情報が設定された{@link GSession}型のデータをシリアライズする場合<br>
 * <table border="1" cellpadding="3" cellspacing="0">
 * <tr bgcolor="#CCCCFF"><td>XML文字列の値</td><td>設定される内容</td><td>設定例</td></tr>
 * <tr><td><b>キー名</b></td><td>オブジェクトを特定する一意なキー(任意の値)</td><td>"session"</td></tr>
 * <tr><td><b>セッションID</b></td><td>{@link GSession#getId()}で取得できるセッションID</td><td>"1234567890"</td></tr>
 * <tr><td><b>停止フラグ</b></td><td>{@link GSession#isInvalid()}で取得できる停止フラグ</td><td>false</td></tr>
 * <tr><td><b>クラス名</b></td><td>{@link GSession}の完全修飾クラス名</td><td> - (シリアライザが設定)</td></tr>
 * <tr><td><b>セッション生成時刻</b></td><td>{@link GSession#getCreationTime()}で取得できるセッション生成時刻</td><td>{@link Date}オブジェクト</td></tr>
 * <tr><td><b>ログインユーザー</b></td><td>{@link GSession#getLoginUser()}で取得できるログインユーザー</td><td>{@link GUser}オブジェクト</td></tr>
 * <tr><td><b>ロケール</b></td><td>{@link GSession#getLocale()}で取得できるロケール</td><td>{@link Locale}オブジェクト</td></tr>
 * <tr><td><b>バインドされたオブジェクト</b></td><td>{@link GSession#getValue(String)}で取得できるオブジェクト</td><td>任意のオブジェクト<b>※</b></td></tr>
 * </table>
 * <b>※バインドされたオブジェクトには、任意のオブジェクトが設定できる為、シリアライズ時に使用するシリアライザクラスは、 保存されているインスタンスの型によって変化します。</b>
 * <br><br>
 * [XML文字列へシリアライズした結果]<br>
 *<table border="1"><tr><td><br>
 *<pre><code>&lt;data name="<b>session</b>" sessionId="<b>1234567890</b>" invalid="<b>false</b>"
 *  type="<b>jp.co.kccs.greenearth.framework.session.GSession</b>"&gt;
 *  &lt;createTime&gt;　
 *    <b>// シリアライズされた{@link Date}のXML</b>
 *  &lt;/createTime&gt;
 *  &lt;loginUser&gt;
 *    <b>// シリアライズされた{@link GUser}のXML</b>
 *  &lt;/loginUser&gt;
 *  &lt;locale&gt;
 *    <b>// シリアライズされた{@link Locale}のXML</b>
 *  &lt;/locale&gt;
 *  &lt;values&gt;
 *    <b>// シリアライズされたオブジェクトのXML</b>
 *    ...
 *  &lt;/values&gt;
 * &lt;/data&gt;
 *</pre>
 *</tr></td></table> 
 * <br>
 * 
 * 【シリアライズクラスの使用】<br>
 * このシリアライザクラスを使用する場合の設定については、{@link GXmlSerializerFactory}クラスを参照してください。<br>
 * 
 * @create 2009/07/30
 * @author murashige
 * @since 3.6.0
 */
@SerializeTarget(GSession.class)
public class GSessionSerializer extends GXmlElementSerializerBase {

	/**
	 * デフォルトコンストラクタ.<br>
	 * 
	 * @create 2009/02/16
	 * @auther aono
	 * @since 3.6.0
	 */
	public GSessionSerializer() {
	}

	/**
	 * {@link GSession}型のデータをXML文字列に変換します.<br>
	 * 
	 * @create 2009/02/16
	 * @see jp.co.kccs.greenearth.framework.xrmi.serialize.GXmlElementSerializer#serialize(PrintWriter, String, Object)
	 * @param writer ライタ
	 * @param name キー
	 * @param data 値
	 * @author aono
	 * @since 3.6.0
	 */
	public void serialize(PrintWriter writer, String name, Object data) {
		if (!(data instanceof GSession)) {
			throw new ClassCastException("The type that corresponds to the specified value is not \"" + GSession.class.getName() + "\".");
		}
		GSession session = (GSession) data;
		boolean invalid = session.isInvalid();

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("data");
		decorateRequiredAttribute(xmlBuilder, name);
		xmlBuilder.setAttribute("invalid", Boolean.toString(invalid));
		if (invalid) {
			writer.println(xmlBuilder.createStartEndTagString());
			return;
		}
		xmlBuilder.setAttribute("sessionId", session.getId());

		writer.print(xmlBuilder.createStartTagString());


		// creationTime情報作成
		printCreationTimeElement(writer, session);

		// locale要素作成
		printLocaleElement(writer, session);

		// loginUser要素作成
		printLoginuserElement(writer, session);

		// value情報作成
		printValuesElement(writer, session);

		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * セッションの生成日時要素を追加します.
	 * @create 2009/02/16
	 * @param writer ライタ
	 * @param session セッション情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printCreationTimeElement(PrintWriter writer, GSession session) {
		Date data = session.getCreationTime();
		if (data == null) {
			return;
		}
		
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("creationTime");
		writer.print(xmlBuilder.createStartTagString());

		GXmlElementSerializer serializer = factory.getSerializer(data);
		serializer.serialize(writer, null, data);

		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * セッションのロケール要素を追加します.
	 * @create 2009/02/16
	 * @param writer ライタ
	 * @param session セッション情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printLocaleElement(PrintWriter writer, GSession session) {
		Locale data = session.getLocale();
		if (data == null) {
			return;
		}		
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("locale");
		writer.print(xmlBuilder.createStartTagString());

		GXmlElementSerializer serializer = factory.getSerializer(data);
		serializer.serialize(writer, null, data);

		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * セッションのログインユーザ要素を追加します.
	 * @create 2009/02/16
	 * @param writer ライタ
	 * @param session セッション情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printLoginuserElement(PrintWriter writer, GSession session) {
		GUser data = session.getLoginUser();
		if (data == null) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();

		GXmlElementBuilder xmlBuilder = new GXmlElementBuilder("loginUser");
		writer.print(xmlBuilder.createStartTagString());

		GXmlElementSerializer serializer = factory.getSerializer(data);
		serializer.serialize(writer, null, data);

		writer.print(xmlBuilder.createEndTagString());
	}

	/**
	 * values要素を追加します.
	 * @create 2009/12/18
	 * @param writer ライタ
	 * @param session セッション情報
	 * @author aono
	 * @since 3.6.0
	 */
	protected void printValuesElement(PrintWriter writer, GSession session) {
		Iterator<String> valuesKeys = session.getValueNames();
		if (!valuesKeys.hasNext()) {
			return;
		}
		GXmlSerializerFactory factory = getSerializerFactory();
		
		// valuesタグを開く
		GXmlElementBuilder valueXmlBuilder = new GXmlElementBuilder("values");
		writer.print(valueXmlBuilder.createStartTagString());

		// valuesの内容を出力する
		while (valuesKeys.hasNext()) {
			String key = valuesKeys.next();
			Object value = session.getValue(key);
			GXmlElementSerializer serializer = factory.getSerializer(value);
			serializer.serialize(writer, key, value);
		}

		// valuesタグを閉じる
		writer.print(valueXmlBuilder.createEndTagString());
	}
}
