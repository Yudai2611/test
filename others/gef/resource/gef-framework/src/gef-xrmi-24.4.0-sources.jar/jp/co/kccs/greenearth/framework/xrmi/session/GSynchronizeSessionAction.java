/*
 * Copyright 2009-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.session;

import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.framework.GConstants;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.session.GSessionManager;
import jp.co.kccs.greenearth.framework.session.GSessionManagerFactory;

/**
 * セッション情報復元用アクションクラスです.
 * 
 * @create 2009/03/04
 * @author aono
 * @since 3.6.0
 */
public class GSynchronizeSessionAction {

	/**
	 * {@link GSynchronizeSessionAction}インスタンスを初期化します。
	 * 
	 * @create 2009/03/04
	 * @author aono
	 * @since 3.6.0
	 */
	public GSynchronizeSessionAction() {
	}

	/**
	 * セッション情報復元用アクションメソッドです.
	 * 
	 * @create 2009/03/04
	 * @param parameter パラメーター
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @author aono
	 * @since 3.6.0
	 */
	public GResultData synchronizeSession(GParameter parameter, GResultData resultData) {
		HttpSession httpSession = GWebContext.getInstance().getRequest().getSession(false);
		if (httpSession == null) {
			throw new IllegalStateException("The session of the object doesn't exist.");
		}
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session = manager.getSession(httpSession);
		if (session == null) {
			throw new IllegalStateException("The session of the object doesn't exist.");
		}

		resultData.setData(GConstants.GSESSION_KEY, session);
		return resultData;
	}

	/**
	 * セッションをクローズします。
	 * 
	 * @create 2009/08/27
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @author aono
	 * @since 3.6.0
	 */
	public GResultData closeSession(GParameter parameter, GResultData resultData) {
		HttpSession httpSession = GWebContext.getInstance().getRequest().getSession(false);
		if (httpSession == null) {
			throw new IllegalStateException("The session of the object doesn't exist. ");
		}
		GSessionManager manager = GSessionManagerFactory.getSessionManager();
		GSession session = manager.getSession(httpSession);
		if (session == null || session.isInvalid()) {
			throw new IllegalStateException("The session of the object doesn't exist or invalid. ");
		}

//		manager.closeSession(session);
		manager.closeSession(session, httpSession);
		return resultData;
	}
}
