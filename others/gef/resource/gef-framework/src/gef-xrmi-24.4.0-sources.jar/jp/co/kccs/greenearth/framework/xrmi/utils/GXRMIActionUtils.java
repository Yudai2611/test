/*
 * Copyright 2007-2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package jp.co.kccs.greenearth.framework.xrmi.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GRowData;

/**
 * アクションで利用する操作を簡素化する機能を提供します.<br>
 *
 * @create 2007/03/07
 * @author fujikawa
 * @since 3.0.0
 */
public class GXRMIActionUtils {

	/** アクションIDを指定するパラメータキー名. */
	private static final String ACTION_ID_KEY = "actionid";

	/**
	 * Don't let anyone instantiate this class.
	 *
	 * @create 2007/03/07
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected GXRMIActionUtils() {
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたセルのIDを返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2011/07/24
	 * @param parameter パラメータ
	 * @return セルのID
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String getCellNameInActionId(GParameter parameter) {
		String[] actionId = parseActionIdInList(parameter);
		return actionId[2];
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたインデックスを返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2007/03/13
	 * @param parameter パラメータ
	 * @return インデックス
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static int getRowIndexInActionId(GParameter parameter) {
		int result = 0;
		String[] actionId = parseActionIdInList(parameter);
		result = Integer.parseInt(actionId[1]);
		return result;
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたリスト名を返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2007/03/13
	 * @param parameter パラメータ
	 * @return リスト名
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static String getListNameInActionId(GParameter parameter) {
		String[] actionId = parseActionIdInList(parameter);
		return actionId[0];
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたリスト・インデックスの各値を取得し、
	 * 結果セット行データ{@link jp.co.kccs.greenearth.framework.data.GRowData}で返却します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 *
	 * @create 2007/03/13
	 * @param parameter パラメータ
	 * @return 結果セット行データ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static GRowData extractRowData(GParameter parameter) {
		// 戻り値用のリストデータ
		GRowData rowData = new GRowData();

		int index = getRowIndexInActionId(parameter);
		String listName = getListNameInActionId(parameter);

		Set<String> keys = parameter.getValuesMap().keySet();
		Iterator<String> iterator = keys.iterator();

		while (iterator.hasNext()) {
			String keyName = iterator.next();
			String[] keyStrings = keyName.split("\\.");
			// 分割できない場合は飛ばす。基本的にはないはず。
			if (keyStrings.length == 0 || keyStrings.length == 1) {
				continue;
			}
			if (keyStrings[0].equals(listName) && keyStrings[1].equals(String.valueOf(index))) {
				rowData.setData(keyStrings[keyStrings.length - 1], parameter.getValue(keyName));
			}
		}

		return rowData;
	}

	/**
	 * アクションIDより、該当するセルデータを取得します.<br/>
	 *
	 * @create 2011/07/24
	 * @param parameter パラメータ
	 * @return セルの値
	 * @author yamashita
	 * @since 3.9.0
	 */
	public static String extractCellData(GParameter parameter) {
		GRowData rowData = extractRowData(parameter);
		if (rowData != null) {
			return rowData.getString(getCellNameInActionId(parameter));
		}
		return null;
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から指定されたリスト名の各値を取得し
	 * 結果セットリストデータ{@link jp.co.kccs.greenearth.framework.data.GListData}で返却します.<br>
	 * パラメータには、以下の形式のキー名で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[(任意)].[項目名]<br>
	 * インデックス部分が数値以外の場合や欠番の場合は正しく返却されません。<br>
	 *
	 * @create 2007/03/07
	 * @param parameter パラメータ
	 * @param listName リスト名
	 * @return 結果セットリストデータ
	 * @author fujikawa
	 * @since 3.0.0
	 */
	public static GListData extractListData(GParameter parameter, String listName) {
		// 戻り値用のリストデータ
		GListData listData = new GListData();

		// 指定されたリスト名がnullの場合
		if (listName == null) {
			return listData;
		}

		Set<String> keys = parameter.getValuesMap().keySet();
		Iterator<String> iterator = keys.iterator();

		// 一時格納用のマップ
		Map<String, GRowData> tempMap = new HashMap<String, GRowData>();

		while (iterator.hasNext()) {
			GRowData rowData = null;

			String keyName = iterator.next();
			String[] keyStrings = keyName.split("\\.");
			// 分割できない場合は飛ばす。基本的にはないはず。
			if (keyStrings.length == 0 || keyStrings.length == 1) {
				continue;
			}
			if (keyStrings[0].equals(listName)) {
				rowData = tempMap.get(keyStrings[1]);
				if (rowData == null) {
					rowData = new GRowData();
				}
				rowData.setData(keyStrings[keyStrings.length - 1], parameter.getValue(keyName));
				tempMap.put(keyStrings[1], rowData);
			}
		}

		// リストデータへロウデータを詰め込みます。
		// パラメータキー名のインデックス部分が数値以外の場合や欠番の場合は正しく返却されません。
		int rowSize = tempMap.size();
		for (int i = 0; i < rowSize; i++) {
			GRowData row = (GRowData) tempMap.get(Integer.toString(i));
			if (row != null) {
				listData.add(row);
			}
		}
		return listData;
	}

	/**
	 * パラメータ{@link jp.co.kccs.greenearth.framework.GParameter}から
	 * アクションIDで指定されたパラメータを解析します.<br>
	 * アクションIDは、以下の形式で値が設定されている前提です。<br>
	 * 　[リスト名].[インデックス].[セル名].[項目名]<br>
	 * アクションIDパラメータ解析結果は以下のような形式の配列で返却されます。<br>
	 * 　解析結果[0]　リスト名<br>
	 * 　解析結果[1]　インデックス<br>
	 * 　解析結果[3]　項目名<br>
	 *
	 * @create 2007/03/13
	 * @param parameter パラメータ
	 * @return アクションIDパラメータ解析結果
	 * @author fujikawa
	 * @since 3.0.0
	 */
	protected static String[] parseActionIdInList(GParameter parameter) {
		String actionId = parameter.getValue(ACTION_ID_KEY);
		if (actionId == null) {
			throw new IllegalArgumentException("The actionid is null.");
		}
		String[] actionStrings = actionId.split("\\.");
		if (actionStrings.length < 3) {
			throw new IllegalArgumentException("The actionid is invalid.");
		}
		return actionStrings;
	}
}
