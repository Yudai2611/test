/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.GActionInvoker;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.utils.GActionUtils;

/**
 * バッチ詳細画面のアクションクラスです.<br>
 *
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class JobDetailAction {

	/**
	 * タスク詳細画面からタスク一覧画面へ遷移する時のアクションです.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param resultData 事前アクションの処理結果
	 * @return resultData 処理結果
	 * @throws Throwable
	 * @author okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GResultData doCancel(GParameter parameter, GResultData resultData) throws Throwable {

		GActionInvoker invoker = GActionInvoker.getInstance();
		resultData = invoker.invoke(JobExecuteAction.class.getName(), "doSearch", parameter, resultData);

		GActionUtils.copyValue(resultData, parameter);
		return resultData;
	}
}
