/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;

import org.quartz.CronTrigger;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.utils.GDateUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.richview.utils.GRIAActionUtils;
import sample.ria.batchexecute.dao.BatchJobExecutionDao;
import sample.ria.batchexecute.dao.BatchJobExecutionParamsDao;
import sample.ria.batchexecute.dao.BatchJobInstanceDao;
import sample.ria.batchexecute.dao.BatchStepExecutionDao;
import sample.ria.common.SampleConstants;

/**
 * バッチ指示画面のアクションクラスです.<br>
 *
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class JobExecuteAction {

	/** 日付フォーマット. */
	private static final String DATE_FORMAT = "yyyy/MM/dd";
	/** 日付(FROM). */
	private static final String DATEFROM = "DateFrom";
	/** 日付(TO). */
	private static final String DATETO = "DateTo";

	/** 曜日. */
	private static final String DAY_OF_WEEK = ".Dow.";
	/** 日. */
	private static final String DAY = ".Day";
	/** 時. */
	private static final String HOURS = ".Hours";
	/** 分. */
	private static final String MINUTES = ".Minutes";
	/** Jobリスト. */
	private static final String JOB_LIST_PREFIX = "JobList";
	/** Jobリスト(複製). */
	private static final String DUPLICATE_JOB_LIST_PREFIX = "DuplicateJobList";

	/** スペース. */
	private static final String SPACE = " ";
	/** コロン. */
	private static final String COLON = ":";
	/** アスタリスク. */
	private static final String ASTERISK = "*";
	/** クエッションマーク. */
	private static final String QUESTION = "?";
	/** 区切り. */
	private static final String COMMA_SEPARATED = ",";
	/** 曜日. */
	private static final String CHECKED_DOW = "1";

	/** 実行方式. */
	private static final String EXECUTE_TYPE = "executeType";

	/** 実行方式：即時実行. */
	private static final String IMMEDIATE_EXECUTE_VAL = "0";
	
	/** スケジュールモード. */
	private static final String SCHEDULEMODE = "scheduleMode";
	
	/** スケジュールモード：毎時. */
	private static final String HOURLY = "Hourly";
	/** スケジュールモード：毎日. */
	private static final String DAILY = "Daily";
	/** スケジュールモード：毎週. */
	private static final String WEEKLY ="Weekly";
	/** スケジュールモード：毎月. */
	private static final String MONTHLY = "Monthly";

	/** ジョブパラメータ：日付(FROM). */
	private static final String PARAM_DATEFROM = "DateFrom";
	/** ジョブパラメータ：日付(TO). */
	private static final String PARAM_DATETO = "DateTo";
	/** ジョブパラメータ：実行日時. */
	private static final String PARAM_EXECDATE = "ExecDate";
	/** ジョブパラメータ：会社コード. */
	private static final String PARAM_COMPANYCD = "CompanyCD";
	/** ジョブパラメータ：実行ユーザ. */
	private static final String PARAM_USER = "User";
	
	/** タイプコード：文字列. */
	private static final String TYPE_CODE_STRING = "STRING";
	/** タイプコード：日付. */
	private static final String TYPE_CODE_DATE = "DATE";
	/** タイプコード：整数. */
	private static final String TYPE_CODE_LONG = "LONG";
	
	/** jobランチャ. */
	private static final String JOBLAUNCHER = "jobLauncher";
	
	/** spring batchジョブ. */
	private static final String SPRING_JOB = "batchExecute";
	/** spring batchジョブパラメータ. */
	private static final String SPRING_JOB_PARAMETERS = "jobParameters";
	
	/** quartzスケジューラー. */
	private static final String QUARTZ_SCHEDULER = "quartzScheduler";
	/** quartzジョブ. */
	private static final String QUARTZ_JOB = "quartzJob";
	/** quartzジョブ. */
	private static final String QUARTZ_TRIGGER = "jobTrigger";
	
	/**
	 * Job実行ボタン押下時のアクションです.<br>
	 * 商品マスタ整理ジョブを実行します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param resultData 事前アクションの処理結果
	 * @return resultData 処理結果
	 * @throws Throwable
	 * @author okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public GResultData doExecuteJob(final GParameter parameter, final GResultData resultData) throws Throwable  {

		List<GValidateError> errors = new ArrayList<GValidateError>();

		if (IMMEDIATE_EXECUTE_VAL.equals(parameter.getValue(EXECUTE_TYPE))) {
			JobExecution jobExecution = immediateExecute(parameter);
			List<Throwable> exceptions = jobExecution.getAllFailureExceptions();

			if (exceptions.size() != 0) {
				Iterator<Throwable> iterator = exceptions.iterator();

				while (iterator.hasNext()) {
					Throwable th = iterator.next();
					GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_ITEMMASTERADJUSTEND);
					error.setDescription(th.getMessage());
					errors.add(error);
				}
				resultData.setExitCode(GResultData.EXIT_CODE_VALIDATE_ERROR);
				resultData.setErrors(errors);
				return resultData;
			}
		} else {
			scheduledExecute(parameter);
		}

		resultData.setData(JOB_LIST_PREFIX, getJobList(DUPLICATE_JOB_LIST_PREFIX, parameter));
		return resultData;
	}

	/**
	 * ジョブリスト最新表示時のアクションです.<br>
	 * 検索処理を実行します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param resultData 事前アクションの処理結果
	 * @return resultData 処理結果
	 * @throws SQLException SQL実行例外
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData doSearch(final GParameter parameter, final GResultData resultData) throws SQLException {
		resultData.setData(JOB_LIST_PREFIX, getJobList(JOB_LIST_PREFIX, parameter));
		return resultData;
	}

	/**
	 * タスク一覧画面からタスク詳細画面へ遷移する時のアクションです.<br>
	 * クリックされたタスクの情報とバッチログ情報を取得し結果セットにセットします。<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param resultData 事前アクションの処理結果
	 * @return resultData 処理結果
	 * @throws SQLException SQL実行例外
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData doSearchDetail(final GParameter parameter, final GResultData resultData) throws SQLException {

		GRowData rowData = GRIAActionUtils.extractRowData(parameter);
		String jobID = rowData.getString("JobID");

		GGjdbcActionUtils.copyValue(resultData, getJobName(jobID));
		GGjdbcActionUtils.copyValue(resultData, getJobInfo(jobID));
		resultData.setData("UpdateCount", getUpdateCount(getStepInfo(jobID)));
		resultData.setData("Parameter", createJobParameter(getJobParameter(jobID)));
		resultData.setData("UserID", getUser(getJobParameter(jobID)));
		resultData.setData("JobDetailList", getStepInfo(jobID));
		resultData.setData("JobList.listsize", parameter.getValue("JobList.listsize"));

		return resultData;
	}

	/**
	 * 画面パラメータからcron式を生成します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @return cron式
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private String createCronExpression(final GParameter parameter) {
		String dow = null;
		String minutes = null;
		String hours = null;
		String day = null;
		
		String scheduleMode = parameter.getValue(SCHEDULEMODE);
		
		switch (scheduleMode){
			case HOURLY : 
				minutes = parameter.getValue(scheduleMode + MINUTES);
				hours = ASTERISK;
				day = ASTERISK;
				dow = QUESTION;
				break;
			case DAILY :
				minutes = parameter.getValue(scheduleMode + MINUTES);
				hours = parameter.getValue(scheduleMode + HOURS);
				day = ASTERISK;
				dow = QUESTION;
				break;
			case WEEKLY :
				minutes = parameter.getValue(scheduleMode + MINUTES);
				hours = parameter.getValue(scheduleMode + HOURS);
				day = QUESTION;
				dow = createDayOfWeekExpression(parameter, scheduleMode + DAY_OF_WEEK);
				break;
			case MONTHLY :
				minutes = parameter.getValue(scheduleMode + MINUTES);
				hours = parameter.getValue(scheduleMode + HOURS);
				day = parameter.getValue(scheduleMode + DAY);
				dow = QUESTION;
				break;
		}
		
		StringBuilder cronExpression = new StringBuilder();
		cronExpression.append("0"); // SECOND
		cronExpression.append(SPACE);
		cronExpression.append(minutes);
		cronExpression.append(SPACE);
		cronExpression.append(hours);
		cronExpression.append(SPACE);
		cronExpression.append(day);
		cronExpression.append(SPACE);
		cronExpression.append(ASTERISK); // MONTH
		cronExpression.append(SPACE);
		cronExpression.append(dow); // DAY_OF_WEEK

		return cronExpression.toString();
	}

	/**
	 * ジョブを即時実行する際のパラメータを生成します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param locale ロケール
	 * @return JobParameters ジョブ実行パラメータ
	 * @throws ParseException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private JobParameters createJobParameters(final GParameter parameter, final Locale locale) throws ParseException {
		JobParameters jobParameters = createScheduledJobParameters(parameter, locale);
		return new JobParametersBuilder(jobParameters).addString(PARAM_EXECDATE, String.valueOf(System.currentTimeMillis())).toJobParameters();
	}

	/**
	 * スケジュールされたジョブ実行時のパラメータを生成します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param locale ロケール
	 * @return JobParameters ジョブ実行パラメータ
	 * @throws ParseException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private JobParameters createScheduledJobParameters(final GParameter parameter, final Locale locale) throws ParseException {
		return new JobParametersBuilder()
			.addDate(PARAM_DATEFROM, GDateUtils.toDate(parameter.getValue(DATEFROM), DATE_FORMAT, locale, false))
			.addDate(PARAM_DATETO, GDateUtils.toDate(parameter.getValue(DATETO), DATE_FORMAT, locale, false))
			.addString(PARAM_COMPANYCD, GEXActionUtils.getLoginCompany().getCode())
			.addString(PARAM_USER, GEXActionUtils.getLoginUser().getName())
			.toJobParameters();
	}

	/**
	 * 商品マスタ整理ジョブを実行します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @return JobExecution ジョブ実行結果
	 * @throws Throwable
	 * @author okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private JobExecution immediateExecute(final GParameter parameter) throws Throwable {

		Locale locale = GWebContext.getInstance().getLocale();
		JobLauncher jobLauncher = GFrameworkUtils.getComponent(JOBLAUNCHER);
		Job job = GFrameworkUtils.getComponent(SPRING_JOB);

		return jobLauncher.run(job, createJobParameters(parameter, locale));
	}

	/**
	 * スケジュール押下時のアクションです.<br>
	 * 商品マスタ整理ジョブのスケジュール・パラメータを変更します。<br>
	 *
	 * @param parameter 画面パラメータ
	 * @author okanishi
	 * @throws ParseException
	 * @throws SchedulerException
	 * @throws Throwable
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private void scheduledExecute(final GParameter parameter) throws ParseException, SchedulerException  {

		Locale locale = GWebContext.getInstance().getLocale();

		Scheduler scheduler = GFrameworkUtils.getComponent(QUARTZ_SCHEDULER);
		CronTriggerImpl cronTrigger = new CronTriggerImpl();
		JobDetail QuartzJob = scheduler.getJobDetail(JobKey.jobKey(QUARTZ_JOB));

		JobDataMap jobDataMap = QuartzJob.getJobDataMap();
		jobDataMap.put(SPRING_JOB_PARAMETERS, createScheduledJobParameters(parameter, locale));

		cronTrigger.setName(QUARTZ_TRIGGER);
		cronTrigger.setJobName(QUARTZ_JOB);
		cronTrigger.setCronExpression(createCronExpression(parameter));
		cronTrigger.setDescription(parameter.getValue(SCHEDULEMODE));
		cronTrigger.setJobDataMap(jobDataMap);

		List<? extends Trigger> triList = scheduler.getTriggersOfJob(JobKey.jobKey(QUARTZ_JOB));

		if (triList.size() != 0) {
			CronTrigger trigger = (CronTrigger) triList.get(0);
			scheduler.rescheduleJob(trigger.getKey(), cronTrigger);
		} else {
			scheduler.scheduleJob(cronTrigger);
		}
	}

	/**
	 * 曜日リストのcron式を生成します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param prefix スケジュールモード
	 * @return cron式
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private String createDayOfWeekExpression(final GParameter parameter, final String prefix) {

		List<String> checkedDowList = getCheckedDowList(parameter, prefix);
		StringJoiner dowExpression = new StringJoiner(COMMA_SEPARATED);
		checkedDowList.forEach(i -> dowExpression.add(i));

		return dowExpression.toString();
	}

	/**
	 * Jobパラメータを連結します.<br>
	 *
	 * @param list パラメーターリスト
	 * @return param 連結したパラメータ
	 * @throws SQLException SQL例外
	 * @author okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private StringBuilder createJobParameter(final GListData list) {
		StringBuilder param = new StringBuilder();
		String type = null;
		String key = null;
		String val = null;

		for (GRowData row : list) {
			type = row.getString(SampleConstants.EXECUTION_PARAMS_TYPE_CD);
			key = row.getString(SampleConstants.EXECUTION_PARAMS_KEY_NAME);

			if (PARAM_DATEFROM.equals(key) || PARAM_DATETO.equals(key)) {
				switch (type){
					case TYPE_CODE_STRING :
						val = row.getString(SampleConstants.EXECUTION_PARAMS_STRING_VAL);
						break;
					case TYPE_CODE_DATE :
						val = row.getDate(SampleConstants.EXECUTION_PARAMS_DATE_VAL).toString();
						break;
					case TYPE_CODE_LONG :
						val = row.getLong(SampleConstants.EXECUTION_PARAMS_LONG_VAL).toString();
						break;
				}
				param.append(key);
				param.append(COLON);
				param.append(val);
				param.append(SPACE);
			}
		}
		return param;
	}

	/**
	 * 画面パラメータで選択された曜日リストを生成します.<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param prefix スケジュールモード
	 * @return 選択された曜日リスト
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private List<String> getCheckedDowList(final GParameter parameter, final String prefix) {

		Map<String, String> dowMap = new HashMap<String, String>();
		for (String key : parameter.getValuesMap().keySet()) {
			if (key.startsWith(prefix)) {
				dowMap.put(key, parameter.getValue(key));
			}
		}

		List<String> checkedDowList = new ArrayList<String>();
		dowMap.entrySet().stream()
		.filter(o -> CHECKED_DOW.equals(o.getValue()))
		.sorted(Map.Entry.comparingByKey())
		.forEach(t -> checkedDowList.add(
			SampleConstants.DAY_OF_WEEK.get(
				Integer.parseInt(t.getKey().substring(t.getKey().lastIndexOf(".") + 1))
				)));

		return checkedDowList;
	}

	/**
	 * ジョブ詳細情報を取得します.<br>
	 *
	 * @param jobID ジョブID
	 * @return {@link GRecord}オブジェクト
	 * @throws SQLException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GRecord getJobInfo(String jobID) throws SQLException {
		BatchJobExecutionDao jobExecutionDao = BatchJobExecutionDao.Factory.getInstance();
		return jobExecutionDao.findJobExecutionRecord(jobID);
	}

	/**
	 * ジョブリスト情報を取得します.<br>
	 *
	 * @param listPrefix
	 * @param parameter
	 * @return {@link GListData}オブジェクト
	 * @throws SQLException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GListData getJobList(String listPrefix, GParameter parameter) throws SQLException {
		BatchJobExecutionDao jobExecutionDao = BatchJobExecutionDao.Factory.getInstance();
		return jobExecutionDao.findJobExecutionList(GEXActionUtils.getLoginCompany().getCode(), listPrefix, parameter);
	}

	/**
	 * ジョブ名称を取得します.<br>
	 *
	 * @param jobID ジョブID
	 * @return {@link GRecord}オブジェクト
	 * @throws SQLException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GRecord getJobName(final String jobID) throws SQLException {
		BatchJobInstanceDao jobInstanceDao = BatchJobInstanceDao.Factory.getInstance();
		return jobInstanceDao.findJobInstanceRecord(jobID);
	}

	/**
	 * ジョブパラメーター情報を取得します.<br>
	 *
	 * @param jobID ジョブID
	 * @return {@link GListData}オブジェクト
	 * @throws SQLException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GListData getJobParameter(String jobID) throws SQLException {
		BatchJobExecutionParamsDao jobExecutionParamsDao = BatchJobExecutionParamsDao.Factory.getInstance();
		return jobExecutionParamsDao.findJobExecutionParamsList(jobID);
	}

	/**
	 * ステップ情報を取得します.<br>
	 *
	 * @param jobID ジョブID
	 * @return {@link GListData}オブジェクト
	 * @throws SQLException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GListData getStepInfo(String jobID) throws SQLException {
		BatchStepExecutionDao stepExecutionDao = BatchStepExecutionDao.Factory.getInstance();
		return stepExecutionDao.findStepExecutionList(jobID);
	}

	/**
	 * ステップ情報から削除件数を取得します.<br>
	 *
	 * @param list step情報リスト
	 * @return cnt 削除件数
	 * @throws SQLException SQL例外
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private int getUpdateCount(final GListData list) {
		int cnt = 0;
		for (GRowData row : list) {
			cnt = cnt + row.getInteger("StepUpdateCount");
		}
		return cnt;
	}

	/**
	 * ジョブパラメータに設定されたUserを取得します.<br>
	 *
	 * @param list ジョブパラメータ
	 * @return val 実行ユーザ
	 * @throws SQLException SQL例外
	 * @author okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private String getUser(final GListData list) {
		String key = null;
		String val = null;

		for (GRowData row : list) {
			key = row.getString(SampleConstants.EXECUTION_PARAMS_KEY_NAME);
			val = "User".equals(key) ? row.getString(SampleConstants.EXECUTION_PARAMS_STRING_VAL) : "";
			if (!val.isEmpty()) {
				break;
			}
		}
		return val;
	}
}