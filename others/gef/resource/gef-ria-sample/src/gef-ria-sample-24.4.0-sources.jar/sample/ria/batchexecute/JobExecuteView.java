/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import jakarta.servlet.jsp.PageContext;

import org.quartz.CronTrigger;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.springframework.batch.core.JobParameters;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.utils.GDateUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRDate;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPCheckBox;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLabel;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPRadioGroup;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPSelect;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GView;
import sample.ria.common.SampleConstants;

/**
 * バッチ指示画面用のビュークラスです.<br>
 *
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class JobExecuteView extends GView {

	/** 日付フォーマット. */
	private static final String DATE_FORMAT = "yyyy/MM/dd";
	/** 日付(FROM). */
	private static final String DATEFROM = "DateFrom";
	/** 日付(TO). */
	private static final String DATETO = "DateTo";
	/** 曜日. */
	private static final String DAY_OF_WEEK = ".Dow.";
	/** 日. */
	private static final String DAY = ".Day";
	/** 時. */
	private static final String HOURS = ".Hours";
	/** 分. */
	private static final String MINUTES = ".Minutes";

	/** 実行. */
	private static final String JOB_EXECUTE = "execute";

	/** スケジュールモード：毎週. */
	private static final String SCHEDULED_WEEKLY = "Weekly";

	/** スケジュールモード：日曜日. */
	private static final String SUNDAY =	"Weekly" + DAY_OF_WEEK + "1";
	/** スケジュールモード：月曜日. */
	private static final String MONDAY =	"Weekly" + DAY_OF_WEEK + "2";
	/** スケジュールモード：火曜日. */
	private static final String TUESDAY =	"Weekly" + DAY_OF_WEEK + "3";
	/** スケジュールモード：水曜日. */
	private static final String WEDNESDAY =	"Weekly" + DAY_OF_WEEK + "4";
	/** スケジュールモード：木曜日. */
	private static final String THURSDAY =	"Weekly" + DAY_OF_WEEK + "5";
	/** スケジュールモード：金曜日. */
	private static final String FRIDAY =	"Weekly" + DAY_OF_WEEK + "6";
	/** スケジュールモード：土曜日. */
	private static final String SATURDAY =	"Weekly" + DAY_OF_WEEK + "7";

	/** ジョブスケジュールラベル. */
	private static final String SCHEDULE_LABEL = "Schedule_L";

	/** ジョブスケジュールラベル スタイル. */
	private static final String SCHEDULE_LABEL_ERROR_STYLE = "color: #ff0000;";

	/** 実行方式. */
	private static final String EXECUTE_TYPE = "executeType";

	/** 実行方式：即時実行. */
	private static final String IMMEDIATE_EXECUTE_VAL = "0";

	/** 実行方式：スケジュール実行. */
	private static final String SCHEDULE_EXECUTE_VAL = "1";

	/** スケジュールモード. */
	private static final String SCHEDULE_MODE = "scheduleMode";

	/**
	 * バッチ指示画面の検証処理を行います.<br>
	 *
	 * @param parameter
	 * @return GValidateError
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	public List<GValidateError> onValidate(GParameter parameter) {

		List<GValidateError> errors = new ArrayList<GValidateError>();
		if (JOB_EXECUTE.equals(parameter.getValue("mode"))) {
			errors.addAll(validateScheduleFields());
			try {
				errors.addAll(validateDateFields(parameter));
			} catch (GValidateException e) {
				errors.addAll(e.getValidateErrors());
			}
		}
		return errors;
	}

	/**
	 * バッチ指示画面のロードクラスです.<br>
	 * Quartz Jobに設定されているスケジュールとパラメーターを画面に設定します.<br>
	 *
	 * @param resultData
	 * @param parameter
	 * @author KCCS okanishi
	 * @throws Exception
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		super.onLoad(resultData, parameter, pageContext);

		Scheduler scheduler = GFrameworkUtils.getComponent("quartzScheduler");
		List<? extends Trigger> triggerJobList = scheduler.getTriggersOfJob(JobKey.jobKey("quartzJob"));

		if (triggerJobList.size() == 0) {
			return;
		}

		loadExecuteType();
		loadScheduleMode(triggerJobList);
		loadJobParameters((CronTrigger) triggerJobList.get(0));
	}

	/**
	 * ジョブパラメータの日付を整合性を検証します.<br>
	 *
	 * @param fromDate
	 * @param toDate
	 * @return int
	 * @throws GValidateException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private int compare(GRDate fromDate, GRDate toDate) throws GValidateException {
		Locale locale = GWebContext.getInstance().getLocale();
		try {
			Date dateFrom = GDateUtils.toDate(fromDate.getValue(), fromDate.getFormat(), locale, false);
			Date dateTo = GDateUtils.toDate(toDate.getValue(), toDate.getFormat(), locale, false);
			return dateFrom.compareTo(dateTo);
		} catch (ParseException e) {
			throw new GValidateException(createValidateError(SampleConstants.ERROR_CD_DATEFROMTOCHECK, toDate.getLabel()));
		}
	}

	/**
	 * 検証を作成します.<br>
	 *
	 * @param errorCode
	 * @param errorLabel
	 * @return GValidateError
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GValidateError createValidateError(String errorCode, String errorLabel) {
		GErrorMessage message = GErrorMessages.getErrorMessage(errorCode, GWebContext.getInstance().getLocale());
		GValidateError error = new GValidateError(message);
		error.setLabel(errorLabel);
		return error;
	}

	/**
	 * 複数の検証を作成します.<br>
	 *
	 * @param errorCode
	 * @param errorControls
	 * @return GValidateError
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GValidateError createValidateError(String errorCode, GUIControl... errorControls) {
		GErrorMessage message = GErrorMessages.getErrorMessage(errorCode, GWebContext.getInstance().getLocale());
		GValidateError error = new GValidateError(message);
		for(GUIControl errorControl : errorControls) {
			error.setLabel(errorControl.getLabel());
			error.addFieldId(errorControl.getId());	
		}
		return error;
	}
	
	/**
	 * バッチ指示画面の実行方式をロードします.<br>
	 *
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private void loadExecuteType() {
		GPRadioGroup executeType = (GPRadioGroup) findControl(EXECUTE_TYPE);
		executeType.setValue(SCHEDULE_EXECUTE_VAL);
	}

	/**
	 * バッチ指示画面のジョブパラメーターをロードします.<br>
	 *
	 * @param trigger
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private void loadJobParameters(Trigger trigger) {
		JobParameters jobParameters = (JobParameters) trigger.getJobDataMap().get("jobParameters");

		GRDate dateFrom = (GRDate) findControl(DATEFROM);
		dateFrom.setValue(GDateUtils.formatToString(jobParameters.getDate(DATEFROM), DATE_FORMAT));

		GRDate dateTo = (GRDate) findControl(DATETO);
		dateTo.setValue(GDateUtils.formatToString(jobParameters.getDate(DATETO), DATE_FORMAT));
	}

	/**
	 * バッチ指示画面のスケジュールをロードします.<br>
	 *
	 * @param triggerJobList
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private void loadScheduleMode(List<? extends Trigger> triggerJobList) {
		CronTrigger trigger = (CronTrigger) triggerJobList.get(0);
		String scheduleMode = trigger.getDescription();
		GPRadioGroup scheduleModeControl = (GPRadioGroup) findControl(SCHEDULE_MODE);
		scheduleModeControl.setValue(scheduleMode);

		String[] cronExpression = trigger.getCronExpression().split(" ");

		Optional<GPSelect> minutes = Optional.ofNullable((GPSelect) findControl(scheduleMode + MINUTES));
		minutes.ifPresent(i -> i.setValue(cronExpression[1]));

		Optional<GPSelect> hours = Optional.ofNullable((GPSelect) findControl(scheduleMode + HOURS));
		hours.ifPresent(i -> i.setValue(cronExpression[2]));

		Optional<GPSelect> day = Optional.ofNullable((GPSelect) findControl(scheduleMode + DAY));
		day.ifPresent(i -> i.setValue(cronExpression[3]));

		for (String val : cronExpression[5].toString().split(",")) {
			for (Integer key : SampleConstants.DAY_OF_WEEK.keySet()) {
				if (SampleConstants.DAY_OF_WEEK.get(key).equalsIgnoreCase(val)) {
					Optional<GPCheckBox> dow = Optional.ofNullable((GPCheckBox) findControl(scheduleMode + DAY_OF_WEEK + key));
					dow.ifPresent(i -> i.setChecked(true));
				}
			}
		}
	}

	/**
	 * ジョブスケジュール：毎週時の曜日必須チェック.<br>
	 *
	 * @param ids
	 * @return boolean
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private boolean isChecked(String...ids) {
		boolean checked = false;
		for (String id : ids) {
			GUIControl control =  findControl(id);
			if (control instanceof GPCheckBox) {
				checked = ((GPCheckBox) control).isChecked();
			}
			if (checked) {
				break;
			}
		}
		return checked;
	}

	/**
	 * ジョブパラメータの日付を検証します.<br>
	 *
	 * @param parameter
	 * @return List<GValidateError>
	 * @throws GValidateException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private List<GValidateError> validateDateFields(GParameter parameter) throws GValidateException {
		List<GValidateError> errors = new ArrayList<>();
		GRDate fromDate = (GRDate) findControl(DATEFROM);
		GRDate toDate = (GRDate) findControl(DATETO);
		errors.addAll(fromDate.validate(parameter));
		errors.addAll(toDate.validate(parameter));
		if (!errors.isEmpty()) {
			return errors;
		}
		if (compare(fromDate, toDate) > 0) {
			errors.add(createValidateError(SampleConstants.ERROR_CD_DATEFROMTOCHECK, fromDate, toDate));
		}
		return errors;
	}

	/**
	 * スケジュール実行時のジョブスケジュール必須チェック.<br>
	 *
	 * @return List<GValidateError>
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public List<GValidateError> validateScheduleFields() {
		List<GValidateError> errors = new ArrayList<>();
		GPRadioGroup executeType = (GPRadioGroup) findControl(EXECUTE_TYPE);
		if (IMMEDIATE_EXECUTE_VAL.equals(executeType.getValue())) {
			return errors;
		}

		GPRadioGroup scheduleMode = (GPRadioGroup) findControl(SCHEDULE_MODE);
		Optional.ofNullable(GStringUtils.blankToNull(scheduleMode.getValue()))
		.ifPresentOrElse(
			i -> {
				if (SCHEDULED_WEEKLY.equals(i)) {
					errors.addAll(validateWeekly());
				}
			}, () -> {
				GPLabel scheduleLabel = (GPLabel) findControl(SCHEDULE_LABEL);
				scheduleLabel.setStyle(SCHEDULE_LABEL_ERROR_STYLE);
				errors.add(createValidateError(SampleConstants.ERROR_CD_SCHEDULMODE, scheduleLabel.getValue()));
			}
			);
		return errors;
	}

	/**
	 * ジョブスケジュール：毎週時の曜日必須チェック.<br>
	 *
	 * @return List<GValidateError>
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public List<GValidateError> validateWeekly() {
		List<GValidateError> errors = new ArrayList<>();
		boolean checked = isChecked(SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY);
		if (!checked) {
			GPLabel scheduleLabel = (GPLabel) findControl(SCHEDULE_LABEL);
			scheduleLabel.setStyle(SCHEDULE_LABEL_ERROR_STYLE);
			errors.add(createValidateError(SampleConstants.ERROR_CD_DAY_OF_WEEK, scheduleLabel.getValue()));
		}
		return errors;
	}
}
