/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;

public interface BatchJobExecutionDao {

	/**
	 * 会社コードを基にジョブリスト用データを取得します.<br>
	 *
	 * @param companyCode
	 * @param listPrefix
	 * @param parameter
	 * @return Jobリスト
	 * @throws SQLException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	GListData findJobExecutionList(String companyCode, String listPrefix, GParameter parameter) throws SQLException;

	/**
	 * 会社コードを基にジョブリスト用データを取得します.<br>
	 *
	 * @param jobID
	 * @return Jobレコード
	 * @throws SQLException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	GRecord findJobExecutionRecord(String jobID) throws SQLException;

	/**
	 * BatchJobExecutionDaoインスタンスのファクトリークラスです.<br>
	 *
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class Factory {

		/**
		 * {@link BatchJobExecutionDao}のインスタンスを取得します.<br>
		 *
		 * @return {@link BatchJobExecutionDao}インスタンス
		 * @author KCCS okanishi
		 * @since 21.9.0
		 * @create 2021/09/30
		 */
		public static BatchJobExecutionDao getInstance() {
			return new BatchJobExecutionDaoImpl();
		}
	}
}
