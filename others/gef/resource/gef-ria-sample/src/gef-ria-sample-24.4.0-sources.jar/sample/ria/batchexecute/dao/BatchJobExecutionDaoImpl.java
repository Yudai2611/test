/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GPagingNavigator;
import jp.co.kccs.greenearth.framework.data.GSearchMode;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import sample.ria.common.SampleConstants;

public class BatchJobExecutionDaoImpl implements BatchJobExecutionDao {

	@Override
	public GListData findJobExecutionList(String companyCode, String listPrefix, GParameter parameter) throws SQLException {
		GSearchMode searchMode = GSearchMode.create(Objects.nonNull(parameter.getValue(GActionServlet.ACTION_MODE_KEY))
			? parameter.getValue(GActionServlet.ACTION_MODE_KEY) : parameter.getValue(GPagingNavigator.DESTPAGE));
		return GGjdbcActionUtils.findList(createJobListEntity(companyCode), listPrefix, parameter, searchMode);
	}

	@Override
	public GRecord findJobExecutionRecord(String jobID) throws SQLException {
		return select(SampleConstants.BATCH_JOB_EXECUTION, "job")
			.where(exp("job.Job_Execution_ID = ?", jobID))
			.findRecord();
	}

	/**
	 * Jobリストを取得するためのエンティティクエリを作成します.<br>
	 *
	 * @param companyCode
	 * @return GEntitySelect
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	private GEntitySelect createJobListEntity(String companyCode) {

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("Key", "CompanyCD");
		paramMap.put("CompanyCD", companyCode);

		return select(SampleConstants.BATCH_JOB_EXECUTION, "job")
			.innerJoinFK("BatchJobExecutionParamsReference", "params")
			.innerJoinFK("BatchJobInstanceReference", "instance")
			.where(expMap($("params.key_name = :Key")
				.AND("params.string_val = :CompanyCD"), paramMap))
			.orderBy(asc("job.JobID"));
	}
}
