/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.data.GListData;

public interface BatchJobExecutionParamsDao {

	/**
	 * ジョブIDを基にジョブパラメーター情報を取得します.<br>
	 *
	 * @param jobID
	 * @return {@link GListData}オブジェクト
	 * @throws SQLException SQL例外
	 * @author okanishi
	 * @since 21.9.0
	 * @create 2021/09/30
	 */
	GListData findJobExecutionParamsList(String jobID) throws SQLException;

	/**
	 * BatchJobExecutionParamsDaoインスタンスのファクトリークラスです.<br>
	 *
	 * @author KCCS okanishi
	 * @since 21.9.0
	 * @create 2021/09/30
	 */
	public static class Factory {

		/**
		 * {@link BatchJobExecutionParamsDao}のインスタンスを取得します.<br>
		 *
		 * @return {@link BatchJobExecutionParamsDao}インスタンス
		 * @author KCCS okanishi
		 * @since 21.9.0
		 * @create 2021/09/30
		 */
		public static BatchJobExecutionParamsDao getInstance() {
			return new BatchJobExecutionParamsDaoImpl();
		}
	}
}
