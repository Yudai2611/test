/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.SQLException;
import java.util.List;

import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import sample.ria.common.SampleConstants;

public class BatchJobExecutionParamsDaoImpl implements BatchJobExecutionParamsDao {

	@Override
	public GListData findJobExecutionParamsList(String jobID) throws SQLException {
		List<GRecord> paramRecord = select(SampleConstants.BATCH_JOB_EXECUTION_PARAMS, "params")
			.where(exp("params.Job_Execution_ID = ?", jobID))
			.findList();

		return  GGjdbcActionUtils.createListData(paramRecord);
	}

}
