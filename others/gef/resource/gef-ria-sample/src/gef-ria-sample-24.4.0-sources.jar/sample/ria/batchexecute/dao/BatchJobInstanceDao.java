/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;

public interface BatchJobInstanceDao {

	/**
	 * ジョブIDを基にジョブインスタンス情報を取得します.<br>
	 *
	 * @param jobID
	 * @return {@link GListData}オブジェクト
	 * @throws SQLException SQL例外
	 * @author okanishi
	 * @since 21.9.0
	 * @create 2021/09/30
	 */
	GRecord findJobInstanceRecord(String jobID) throws SQLException;

	/**
	 * BatchJobInstanceDaoインスタンスのファクトリークラスです.<br>
	 *
	 * @author KCCS okanishi
	 * @since 21.9.0
	 * @create 2021/09/30
	 */
	public static class Factory {

		/**
		 * {@link BatchJobInstanceDao}のインスタンスを取得します.<br>
		 *
		 * @return {@link BatchJobInstanceDao}インスタンス
		 * @author KCCS okanishi
		 * @since 21.9.0
		 * @create 2021/09/30
		 */
		public static BatchJobInstanceDao getInstance() {
			return new BatchJobInstanceDaoImpl();
		}
	}
}
