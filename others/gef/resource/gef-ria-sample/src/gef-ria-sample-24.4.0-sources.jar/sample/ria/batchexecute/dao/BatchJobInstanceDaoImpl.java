/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import sample.ria.common.SampleConstants;

public class BatchJobInstanceDaoImpl implements BatchJobInstanceDao {

	@Override
	public GRecord findJobInstanceRecord(String jobID) throws SQLException {
		return select(SampleConstants.BATCH_JOB_INSTANCE, "instance")
			.where(exp("instance.Job_Instance_ID = ?", jobID))
			.orderBy(asc("instance.JobInstanceID"))
			.findRecord();
	}

}
