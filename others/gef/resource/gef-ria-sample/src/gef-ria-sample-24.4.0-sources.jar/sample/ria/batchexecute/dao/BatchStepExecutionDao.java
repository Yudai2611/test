/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import java.sql.SQLException;

import jp.co.kccs.greenearth.framework.data.GListData;

public interface BatchStepExecutionDao {

	/**
	 * ジョブIDを基にステップ情報を取得します。<br>
	 *
	 * @param jobID
	 * @return {@link GListData}オブジェクト
	 * @throws SQLException SQL例外
	 * @author okanishi
	 * @since 21.9.0
	 * @create 2021/09/30
	 */
	GListData findStepExecutionList(String jobID) throws SQLException;

	/**
	 * BatchJobExecutionDaoインスタンスのファクトリークラスです.<br>
	 *
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	public static class Factory {

		/**
		 * {@link BatchStepExecutionDao}のインスタンスを取得します.<br>
		 *
		 * @return {@link BatchJobExecutionDao}インスタンス
		 * @author KCCS okanishi
		 * @since 21.9.0
		 * @create 2021/09/30
		 */
		public static BatchStepExecutionDao getInstance() {
			return new BatchStepExecutionDaoImpl();
		}
	}
}
