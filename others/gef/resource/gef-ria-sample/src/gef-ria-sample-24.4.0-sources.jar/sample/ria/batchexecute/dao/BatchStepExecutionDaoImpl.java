/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.dao;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.SQLException;
import java.util.List;

import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import sample.ria.common.SampleConstants;

public class BatchStepExecutionDaoImpl implements BatchStepExecutionDao {

	@Override
	public GListData findStepExecutionList(String jobID) throws SQLException {

		List<GRecord> stepRecord = select(SampleConstants.BATCH_STEP_EXECUTION, "step")
			.where(exp("step.Job_Execution_ID = ?", jobID))
			.orderBy(asc("step.StepID"))
			.findList();

		GListData stepListData = GGjdbcActionUtils.createListData(stepRecord);

		return stepListData;
	}

}
