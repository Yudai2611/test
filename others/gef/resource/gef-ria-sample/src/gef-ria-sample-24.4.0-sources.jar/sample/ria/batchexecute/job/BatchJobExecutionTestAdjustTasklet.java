/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.job;

import java.sql.Connection;
import java.util.Date;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import jp.co.kccs.greenearth.commons.db.GConnectionManager;
import sample.ria.batchexecute.job.dao.BatchJobExecutionTestDao;

/**
 * タスクレット実行クラスです.<br>
 *
 * @create 2024/04/30
 * @author KCSS yangfeng
 * @since 24.4.0
 */
public class BatchJobExecutionTestAdjustTasklet implements Tasklet {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(BatchJobExecutionTestAdjustTasklet.class);

	/** ステップコンテキスト. */
	private StepContext stepContext;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		LOGGER.info(getClass().getName() + " started.");
		
		stepContext = chunkContext.getStepContext();
		int deleteCount = 0;
		
		GConnectionManager manager = GConnectionManager.getInstance();
		Connection connection = null;
		
		connection = manager.catchNewConnection();
		manager.beginTransaction(connection);
		
		try {
			// バッチジョブテスト用テーブルを整理
			deleteCount = deleteBatchJobExecutionTest(connection);
			contribution.setExitStatus(ExitStatus.COMPLETED);
			contribution.incrementWriteCount(deleteCount);
			manager.commitTransaction(connection);
			LOGGER.info(getClass().getName() + " finished.");
		} catch (Exception e) {
			contribution.setExitStatus(ExitStatus.FAILED);
			manager.rollbackTransaction(connection);
			LOGGER.error(getClass().getName() + " failured.", e);
			throw e;
		} finally {
			manager.releaseConnection(connection);
		}
		
		return RepeatStatus.FINISHED;
	}

	/**
	 * 整理SQLを実行します.<br>
	 *
	 * @param connection
	 * @return int
	 * @throws Exception
	 *
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	private int deleteBatchJobExecutionTest(Connection connection) throws Exception {
		Map<String, Object> jobParametersMap = stepContext.getJobParameters();
		Date dateFrom = (Date) jobParametersMap.get("DateFrom");
		Date dateTo = (Date) jobParametersMap.get("DateTo");
		String companyCD = (String) jobParametersMap.get("CompanyCD");
		
		BatchJobExecutionTestDao batchJobExecutionTestDao = BatchJobExecutionTestDao.Factory.getInstance();
		
		return batchJobExecutionTestDao.deleteRecord(connection, companyCD, dateFrom, dateTo);
	}
}
