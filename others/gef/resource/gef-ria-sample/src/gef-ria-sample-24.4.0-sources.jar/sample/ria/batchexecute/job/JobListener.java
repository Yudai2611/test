/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.job;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;

/**
 * ジョブのリスナークラスです.<br>
 *
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class JobListener extends JobExecutionListenerSupport {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(JobListener.class);

	@Override
	public void beforeJob(JobExecution jobExecution) {
		LOGGER.info("job started. JobName:" + jobExecution.getJobInstance().getJobName() + ", jobExecutionId:" + jobExecution.getId());
	}

	@Override
	public void afterJob(JobExecution jobExecution) {

		List<Throwable> exceptions = jobExecution.getAllFailureExceptions();

		if (exceptions.isEmpty()) {
			LOGGER.info("job finished. JobName:" + jobExecution.getJobInstance().getJobName() 
						+ ", jobExecutionId:" + jobExecution.getId() 
						+ ", jobStatus:" + jobExecution.getExitStatus().getExitCode());
			return;
		}

		exceptions.forEach(
			th -> LOGGER.error("job failured. JobName:" + jobExecution.getJobInstance().getJobName() + ", jobExecutionId:" + jobExecution.getId(), th)
		);
	}
}
