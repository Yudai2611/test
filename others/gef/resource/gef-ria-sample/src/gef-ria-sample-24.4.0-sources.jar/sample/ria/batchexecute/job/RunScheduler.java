/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * quartzスケジューラーからバッチを実行するクラス.<br>
 *
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
@DisallowConcurrentExecution
public class RunScheduler extends QuartzJobBean {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(BatchJobExecutionTestAdjustTasklet.class);

	/**
	 * quartzスケジューラーからのエントリーポイントです.<br>
	 * spring batchを起動します.<br>
	 *
	 * @param context
	 * @throws JobExecutionException
	 * @author KCCS okanishi
	 * @create 2021/09/30
	 * @since 21.9.0
	 */
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

		JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
		Job job = (Job) jobDataMap.get("jobName");

		LOGGER.info(getClass().getName() + " started. JobName:" + job.getName());

		JobLauncher jobLauncher = (JobLauncher) jobDataMap.get("jobLauncher");
		JobParameters jobParameters = (JobParameters) context.getTrigger().getJobDataMap().get("jobParameters");
		JobParameters aaa = new JobParametersBuilder(jobParameters).addString("ExecDate", String.valueOf(System.currentTimeMillis())).toJobParameters();
		try {
			jobLauncher.run(job, aaa);
		} catch (Exception e) {
			LOGGER.error(getClass().getName() + " failured.", e);
		}
		LOGGER.info(getClass().getName() + " finished. JobName:" + job.getName());
	}
}
