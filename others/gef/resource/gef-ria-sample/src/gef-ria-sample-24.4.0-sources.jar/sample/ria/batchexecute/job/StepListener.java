/*
 * Copyright 2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.job;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepListenerSupport;

/**
 * ステップのリスナークラスです.<br>
 *
 * @author KCCS okanishi
 * @create 2021/09/30
 * @since 21.9.0
 */
public class StepListener extends StepListenerSupport<Object, Object> {

	/** ロガー. */
	private static final Log LOGGER = LogFactory.getLog(StepListener.class);

	@Override
	public void beforeStep(StepExecution stepExecution) {
		LOGGER.info("step started. stepName:" + stepExecution.getStepName()
					+ ", stepExecutionId:" + stepExecution.getId());
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		List<Throwable> exceptions = stepExecution.getFailureExceptions();
		if (exceptions.isEmpty()) {
			LOGGER.info("step finished. stepName:" + stepExecution.getStepName()
						+ ", stepExecutionId:" + stepExecution.getId()
						+ ", stepStatus:" + stepExecution.getStatus());
			return ExitStatus.COMPLETED;
		}
		exceptions.forEach(
			th -> LOGGER.error("step failured. JobName:" + stepExecution.getStepName()
								+ ", stepExecutionId:" + stepExecution.getId(), th)
			);
		return ExitStatus.FAILED;
	}
}
