/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.job.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

/**
 * {@link BatchJobExecutionTestDao}クラスです.<br>
 *
 * @create 2024/04/30
 * @author KCSS yangfeng
 * @since 24.4.0
 */
public interface BatchJobExecutionTestDao {
	
	/**
	 * ジョブパラメータを基にレコードを削除します.<br>
	 *
	 * @param connection
	 * @param companyCD
	 * @param from
	 * @param to
	 * @return 削除件数
	 * @throws SQLException SQL例外
	 *
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	int deleteRecord(Connection connection, String companyCD, Date from, Date to) throws SQLException;
	
	/**
	 * BatchJobExecutionTestDaoインスタンスのファクトリークラスです.<br>
	 *
	 * @create 2024/04/30
	 * @author KCSS yangfeng
	 * @since 24.4.0
	 */
	public static class Factory {

		/**
		 * {@link BatchJobExecutionTestDao}のインスタンスを取得します.<br>
		 *
		 * @return {@link BatchJobExecutionTestDao}インスタンス
		 * @create 2024/04/30
		 * @author KCSS yangfeng
		 * @since 24.4.0
		 */
		public static BatchJobExecutionTestDao getInstance() {
			return new BatchJobExecutionTestDaoImpl();
		}
	}
}
