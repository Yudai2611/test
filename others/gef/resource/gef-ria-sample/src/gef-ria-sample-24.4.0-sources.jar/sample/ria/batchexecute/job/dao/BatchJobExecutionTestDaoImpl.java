/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.batchexecute.job.dao;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * {@link BatchJobExecutionTestDao}の実装クラスです.<br>
 *
 * @create 2024/04/30
 * @author KCSS yangfeng
 * @since 24.4.0
 */
public class BatchJobExecutionTestDaoImpl implements BatchJobExecutionTestDao {

	@Override
	public int deleteRecord(Connection connection, String companyCD, Date from, Date to) throws SQLException {
		
		Map<String, Object> bindMap = new HashMap<String, Object>();
		bindMap.put("CompanyCD", companyCD);
		bindMap.put("from", from);
		bindMap.put("to", to);
		
		return delete("BatchJobExecutionTest")
				.where(expMap("BATCH_JOB_EXECUTION_TEST.UpdatedDT >= :from AND BATCH_JOB_EXECUTION_TEST.UpdatedDT <= :to AND BATCH_JOB_EXECUTION_TEST.CompanyCD = :CompanyCD",bindMap))
				.execute(connection);
	}

}
