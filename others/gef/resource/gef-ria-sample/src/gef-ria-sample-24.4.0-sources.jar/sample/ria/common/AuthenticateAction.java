/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.common;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.action.GActionInvoker;
import jp.co.kccs.greenearth.framework.auth.GAuthentication;
import jp.co.kccs.greenearth.framework.auth.GAuthenticationException;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.session.GSession;
import sample.ria.menu.MenuAction;

/**
 * ログイン認証用のアクションクラスです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class AuthenticateAction {

	/** ログイン画面の会社コードテキストボックスの要素ID */
	private static final String COMPANYCD = "companycd";
	/** ログイン画面のユーザーIDテキストボックスの要素ID */
	private static final String USERID = "userid";
	/** ログイン画面のパスワードテキストボックスの要素ID */
	private static final String PASSWORD = "password";

	/**
	 * {@link AuthenticateAction}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public AuthenticateAction() {
	}

	/**
	 * ログイン認証を行います。
	 *
	 * @create 2020/6/23
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @throws Throwable 認証エラー
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GResultData login(GParameter parameter, GResultData resultData) throws Throwable {
		GWebContext context = GWebContext.getInstance();
		HttpServletRequest request = context.getRequest();
		HttpServletResponse response = context.getResponse();
		GSession session = context.getSession();
		GAuthentication auth = (GAuthentication) GFrameworkUtils.getComponent(GAuthentication.class.getName());
		try {
			session = auth.login(request, response, session);
			context.setSession(session);
		} catch (GAuthenticationException e) {
			GValidateError error = new GValidateError(e.getCode(), e.getMessage(), e.getType(), e.getDescription());
			error.addFieldId(COMPANYCD);
			error.addFieldId(USERID);
			error.addFieldId(PASSWORD);
			throw new GValidateException(error);
		}
		return resultData;
	}

	/**
	 * ログイン認証を行い、その後トップメニューの一覧を取得します。
	 *
	 * @create 2020/6/23
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @throws Throwable 認証エラー/メニュー情報取得エラー
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GResultData loginAndFindMenu(GParameter parameter, GResultData resultData) throws Throwable {
		GActionInvoker invoker = GActionInvoker.getInstance();

		// ログイン処理
		resultData = invoker.invoke(this, "login", parameter, resultData);

		// メニューの取得
		return invoker.invoke(MenuAction.class.getName(), "launchMenu", parameter, resultData);
	}

	/**
	 * ログアウト処理を行います。
	 *
	 * @create 2020/6/23
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return GResultData 結果セット
	 * @author miwa
	 * @throws GAuthenticationException ログアウトに失敗した場合
	 * @since 20.6.0.0b
	 */
	public GResultData logout(GParameter parameter, GResultData resultData) throws GAuthenticationException {
		GWebContext context = GWebContext.getInstance();
		HttpServletRequest request = context.getRequest();
		HttpServletResponse response = context.getResponse();
		GSession session = context.getSession();

		GAuthentication auth = (GAuthentication) GFrameworkUtils.getComponent(GAuthentication.class.getName());
		auth.logout(request, response, session);

		return resultData;
	}

}
