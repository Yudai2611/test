/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.common;

import java.util.Locale;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLabel;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPMenuLinkedLabel;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.view.component.GView;
import sample.ria.menu.MenuAction;

/**
 * ヘッダ画面用のビュークラスです。
 *
 * @create 2020/6/23
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author miwa
 * @since 20.6.0.0b
 */
public class HeaderView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/** メニュー情報を格納したマップのセッションキー. */
	public static final String SESSION_KEY_MENU_MAP = MenuAction.SESSION_KEY_MENU_MAP;
	/** ヘッダーの「[ MENU ]」アンカーの要素ID. */
	private static final String ELEMENT_ID_MENU_HEADER_MENU = "MenuHeaderMenu";
	/** ヘッダーの「Program :」ラベルの要素ID. */
	private static final String ELEMENT_ID_PROGRAM_PREFIX = "MenuDisplayNameTitle";
	/** ヘッダーのプログラム名表示ラベルの要素ID. */
	private static final String ELEMENT_ID_PROGRAM_TITLE = "MenuDisplayName";
	/** ヘッダーのユーザー名表示ラベルの要素ID. */
	private static final String ELEMENT_ID_USER_ID = "UserID";


	/**
	 * {@link HeaderView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public HeaderView() {
	}

	/**
	 * アクションの実行結果をメニュー画面に読込みます。
	 *
	 * @create 2020/6/23
	 * @param resultData 結果セット
	 * @param parameter パラメータ
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter) {
		HttpServletRequest request = GWebContext.getInstance().getRequest();
		HttpSession session = request.getSession();
		GSession gsession = GWebContext.getInstance().getSession();
		GUser user = gsession.getLoginUser();

		GPLabel userid = (GPLabel) findControl(ELEMENT_ID_USER_ID);
		if (user != null) {
			userid.setValue((String) user.getName());
		}

		String parentMenuId = "";
		String menuDisplayName = "";
		String menuid = parameter.getValue("menuid");
		Map<String, GMenu> menuMap = (Map<String, GMenu>) session.getAttribute(SESSION_KEY_MENU_MAP);
		if (menuMap.containsKey(menuid)) {
			GMenu item = menuMap.get(menuid);
			String menuID = item.getParent() != null ? item.getParent().getMenuID() : null;
			parentMenuId = GStringUtils.nullToBlank(menuID);
			if (item.isItem()) {
				Locale locale = GWebContext.getInstance().getLocale();
				menuDisplayName = GStringUtils.nullToBlank(item.getDisplayName(locale));
			}
		}

		GPLabel menuDisplayNameLabel = (GPLabel) findControl(ELEMENT_ID_PROGRAM_TITLE);
		if (menuDisplayNameLabel != null) {
			GPLabel menuDisplayNameTitle = (GPLabel) findControl(ELEMENT_ID_PROGRAM_PREFIX);
			if (menuDisplayName.length() != 0) {
				menuDisplayNameTitle.setVisible(true);
			} else {
				menuDisplayNameTitle.setVisible(false);
			}
			menuDisplayNameLabel.setValue(menuDisplayName);
		}

		GPMenuLinkedLabel menuAnchor = (GPMenuLinkedLabel) findControl(ELEMENT_ID_MENU_HEADER_MENU);
		if (menuAnchor != null) {
			menuAnchor.setMenu(parentMenuId);
		}
	}
}
