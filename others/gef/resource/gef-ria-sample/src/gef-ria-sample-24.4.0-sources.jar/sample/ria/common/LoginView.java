/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPPassword;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPText;
import jp.co.kccs.greenearth.framework.view.component.GView;
import jp.co.kccs.greenearth.framework.view.validator.GValidator;

/**
 * ログイン画面のビュークラスです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class LoginView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/** ログイン画面の会社コードテキストボックスの要素ID */
	private static final String COMPANYCD = "companycd";
	/** ログイン画面のユーザーIDテキストボックスの要素ID */
	private static final String USERID = "userid";
	/** ログイン画面のパスワードテキストボックスの要素ID */
	private static final String PASSWORD = "password";

	/**
	 * {@link LoginView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public LoginView() {
		super();
	}

	/**
	 * 検証処理の拡張ポイントです。<br>
	 * GView要素に含まれる{@link GValidator}を検証します。
	 *
	 * @create 2020/6/23
	 * @param parameter パラメータ
	 * @return エラーリスト
	 * @see jp.co.kccs.greenearth.framework.view.component.GView#onValidate(GParameter)
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public List<GValidateError> onValidate(GParameter parameter) {
		List<GValidateError> errors = new ArrayList<GValidateError>();

		errors = super.onValidate(parameter);

		GPText txtcompanycd = (GPText) findControl(COMPANYCD);
		GPText txtuserid = (GPText) findControl(USERID);
		GPPassword txtpassword = (GPPassword) findControl(PASSWORD);

		if ("".equals(txtcompanycd.getValue()) && "".equals(txtuserid.getValue()) && "".equals(txtpassword.getValue())) {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			GErrorMessage message = GErrorMessages.getErrorMessage("GEF-000001", locale);
			GValidateError error1 = new GValidateError(message);
			error1.addFieldId(COMPANYCD);
			error1.setLabel("会社コード");
			GValidateError error2 = new GValidateError(message);
			error2.addFieldId(USERID);
			error2.setLabel("ユーザID");
			GValidateError error3 = new GValidateError(message);
			error3.addFieldId(PASSWORD);
			error3.setLabel("パスワード");
			errors.add(error1);
			errors.add(error2);
			errors.add(error3);
		}
		return errors;
	}
}
