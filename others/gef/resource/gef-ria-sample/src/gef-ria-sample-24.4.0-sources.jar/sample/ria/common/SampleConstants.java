/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.common;

import java.util.HashMap;
import java.util.Map;

/**
 * サンプル用定数クラスです。<br>
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class SampleConstants {

	/**
	 * {@link SampleConstants}インスタンスを初期化します。
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private SampleConstants() {
	}
	
	// アクションID
	/** 検索 */
	public static final String ID_SEARCH = "Search";

	/** 新規 */
	public static final String ID_INSERT = "Insert";

	/** 更新 */
	public static final String ID_UPDATE = "Update";

	/** 削除 */
	public static final String ID_DELETE = "Delete";

	// エラーコード
	/** リストが0行の時のエラーコード */
	public static final String ERROR_CD_NOLIST = "GES-100001";

	/** 選択チェックボックスが未チェック時のエラーコード */
	public static final String ERROR_CD_NOCHECK = "GES-100002";

	/** 商品マスタに対象の商品が存在しない場合のエラーコード */
	public static final String ERROR_CD_NOITEM = "GES-100003";

	/** 伝票番号の採番が、上限に達した時のエラーコード */
	public static final String ERROR_CD_OVERSLIPNO = "GES-100004";

	/** 表示できる明細行の限界を超えた時のエラーコード */
	public static final String ERROR_CD_OVERADDROW = "GES-100005";

	/** 該当データがありません場合のエラーコード */
	public static final String ERROR_CD_NODATA = "GES-000113";

	/** 停止日が開始日より過去の日付を入力された場合のエラーコード */
	public static final String ERROR_CD_STARTINVALIDDTCHECK = "GES-000055";

	/** 削除されている場合のエラーコード */
	public static final String ERROR_CD_DATADELETED = "GES-000103";

	/** 他のユーザが更新している場合のエラーコード */
	public static final String ERROR_CD_OTHERUSING = "GES-000102";
	
	/** 日付(TO)が日付(FROM)より過去の日付を入力された場合のエラーコード */
	public static final String ERROR_CD_DATEFROMTOCHECK = "SMP-010001";
	
	/** 商品マスタ整理が異常終了した場合のエラーコード */
	public static final String ERROR_CD_ITEMMASTERADJUSTEND = "SMP-010003";
	
	/** 商品マスタ整理のスケジュール設定が異常終了した場合のエラーコード */
	public static final String ERROR_CD_SCHEDULING = "SMP-010004";
	
	// インフォーコード
	/** 商品マスタ整理が終了した場合のインフォーコード */
	public static final String INFO_CD_ITEMMASTERADJUSTEND = "SMP-010002";
	
	/** 商品マスタ整理のスケジュールが選択されていない場合のエラーコード */
	public static final String ERROR_CD_SCHEDULMODE = "SMP-010005";
	
	/** 商品マスタ整理のスケジュール(曜日)が選択されていない場合のエラーコード */
	public static final String ERROR_CD_DAY_OF_WEEK = "SMP-010006";

	// 一覧更新
	// 仮想項目名（フレームワーク共通項目）
	/** 排他フラグ */
	public static final String EXCLUSIVEFG = "ExclusiveFG";

	/** 会社コード */
	public static final String COMPANYCD = "CompanyCD";

	/** ユーザーID */
	public static final String USERID = "UserID";

	/** 登録者 */
	public static final String REGISTEREDPERSON = "RegisteredPerson";

	/** 登録日 */
	public static final String REGISTEREDDT = "RegisteredDT";

	/** 更新者 */
	public static final String UPDATEDPERSON = "UpdatedPerson";

	// 仮想項目名（商品マスタ情報）
	/** 開始日 */
	public static final String ITEMMASTER_STARTDT = "StartDT";

	/** 停止日 */
	public static final String ITEMMASTER_INVALIDDT = "InvalidDT";

	/** 商品コード */
	public static final String ITEMMASTER_ITEMCD = "ItemCD";

	/** 商品名称 */
	public static final String ITEMMASTER_ITEMNA = "ItemNA";

	/** 商品名称(カナ) */
	public static final String ITEMMASTER_ITEMNA_KANA = "ItemNA_KANA";

	/** 規格 */
	public static final String ITEMMASTER_STANDARD = "Standard";

	/** 単位 */
	public static final String ITEMMASTER_UNIT = "Unit";

	/** 単価 */
	public static final String ITEMMASTER_UNITPRICE = "UnitPrice";

	/** 在庫区分 */
	public static final String ITEMMASTER_STOCKFG = "StockFG";

	/** 検査区分 */
	public static final String ITEMMASTER_INSPECTIONFG = "InspectionFG";

	// ヘッダ明細
	// エンティティ名
	/** 発注ヘッダ */
	public static final String ORDERHEADER = "OrderHeader";

	/** 発注明細 */
	public static final String ORDERDETAIL = "OrderDetail";

	/** 商品マスタ */
	public static final String ITEMMASTER = "ItemMaster";

	/** 採番マスタ */
	public static final String SNUMBERING = "SNumbering";

	// 仮想項目名（発注ヘッダ）
	/** 伝票番号 */
	public static final String ORDERHEADER_SLIPNO = "SlipNO";
	/** 会社名（カナ） */
	public static final String ORDERHEADER_CORPORATENA_KANA = "CorporateNA_KANA";
	/** 会社名 */
	public static final String ORDERHEADER_CORPORATE_NA = "CorporateNA";

	// ユニークキー（発注ヘッダ）
	/** 発注ユニークキー */
	public static final String ORDERHEADER_SLIPNO_KEY = "SlipNOKey";

	// 仮想項目名（発注明細）
	/** 伝票番号 */
	public static final String ORDERDETAIL_SLIPNO = "SlipNO";
	/** 商品コード */
	public static final String ORDERDETAIL_ITEMCD = "ItemCD_0";
	/** 発注数 */
	public static final String ORDERDETAIL_ORDERQT = "OrderQT";
	/** 単価 */
	public static final String ORDERDETAIL_UNITPRICE = "UnitPrice";
	/** 納期 */
	public static final String ORDERDETAIL_DELIVERYDT = "DeliveryDT";
	/** 備考 */
	public static final String ORDERDETAIL_REMARK = "Remark";
	/** 明細番号 */
	public static final String ORDERDETAIL_DETAILNO = "DetailNo";
	/** 明細ID */
	public static final String ORDERDETAIL_DETAILID = "DetailID";
	/** 発注金額 */
	public static final String ORDERDETAIL_ORDERAT = "OrderAT";

	// ユニークキー
	/** 発注明細ユニークキー */
	public static final String ORDERDETAIL_DETAILID_KEY = "DetailIDKey";

	// 外部キー
	/** 商品マスタ引当キー */
	public static final String ORDERDETAIL_ITEMMASTER_REFERENCEKEY = "ItemMasterReferenceKey";

	// 仮想項目名（採番マスタ）
	/** 固定値 */
	public static final String SNUMBERING_CONSTVALUE = "ConstValue";
	/** 終了値 */
	public static final String SNUMBERING_ENDVALUE = "EndValue";
	/** 現在値 */
	public static final String SNUMBERING_CURRENTVALUE = "CurrentValue";
	/** 増減値 */
	public static final String SNUMBERING_INCREMENTVALUE = "IncrementValue";

	// 単票更新
	// エンティティ名
	/** 単位マスタ */
	public static final String UNITMASTER = "UnitMaster";
	
	// バッチ指示
	// Cron式
	public static final Map<Integer, String> DAY_OF_WEEK = new HashMap<>();
	static {
		DAY_OF_WEEK.put(1, "SUN");
		DAY_OF_WEEK.put(2, "MON");
		DAY_OF_WEEK.put(3, "TUE");
		DAY_OF_WEEK.put(4, "WED");
		DAY_OF_WEEK.put(5, "THU");
		DAY_OF_WEEK.put(6, "FRI");
		DAY_OF_WEEK.put(7, "SAT");
	}

	/** テーブル:ジョブ情報 */
	public static final String BATCH_JOB_INSTANCE = "BatchJobInstance";
	
	/** テーブル:ジョブ実行状況 */
	public static final String BATCH_JOB_EXECUTION = "BatchJobExecution";

	/** テーブル:ジョブパラメータ */
	public static final String BATCH_JOB_EXECUTION_PARAMS = "BatchJobExecutionParams";
	
	/** テーブル:ステップ実行状況 */
	public static final String BATCH_STEP_EXECUTION = "BatchStepExecution";
	
	/** タイプコード */
	public static final String EXECUTION_PARAMS_TYPE_CD = "TypeCD";
	/** キー名 */
	public static final String EXECUTION_PARAMS_KEY_NAME = "KeyName";
	/** String値 */
	public static final String EXECUTION_PARAMS_STRING_VAL = "StringVAL";
	/** DATE値 */
	public static final String EXECUTION_PARAMS_DATE_VAL = "DateVAL";
	/** LONG名 */
	public static final String EXECUTION_PARAMS_LONG_VAL = "LongVAL";

}
