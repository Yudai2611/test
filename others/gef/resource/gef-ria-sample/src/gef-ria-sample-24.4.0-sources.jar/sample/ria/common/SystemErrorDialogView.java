/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.common;

import jakarta.servlet.jsp.PageContext;

import jp.co.kccs.greenearth.commons.GApplicationException;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.utils.GBooleanUtils;
import jp.co.kccs.greenearth.commons.utils.GExceptionUtils;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLabel;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPTextarea;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPList;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListRow;
import jp.co.kccs.greenearth.framework.view.component.GView;
import sample.ria.common.utils.SampleUtils;

/**
 * システムエラー画面用のビュークラスです。
 *
 * @create 2020/6/23
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author miwa
 * @since 20.6.0.0b
 */
public class SystemErrorDialogView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/** 標準エラーコード. */
	private static final String DEFAULT_ERROR_CODE = "GEF-000000";

	private static final String ERROR_LIST_ID = "errorList";

	/**
	 * {@link SystemErrorDialogView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public SystemErrorDialogView() {
	}

	/**
	 * 画面表示時のイベントです。
	 *
	 * @create 2020/6/23
	 * @param resultData 結果セット
	 * @param parameter 画面パラメータ
	 * @param pageContext ページコンテキスト
	 * @throws Exception 読み込みに失敗した場合
	 * @see jp.co.kccs.greenearth.framework.view.component.GView#onLoad(GResultData, GParameter)
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		super.onLoad(resultData, parameter, pageContext);
		Throwable e = getSystemException(pageContext);
		GErrorType kind = GErrorType.ERROR;			// デフォルト値設定
		String code = DEFAULT_ERROR_CODE;
		String message = "The error not anticipated occurred.";
		if (e instanceof GApplicationException) {
			kind = ((GApplicationException) e).getType();
			code = ((GApplicationException) e).getCode();
			message = ((GApplicationException) e).getMessage();
		}
		GPList errorList = (GPList) findControl(ERROR_LIST_ID);
		GPListRow row = errorList.createRow();
		errorList.addRow(row);
		GPLabel kindUi = (GPLabel) row.findElement("ErrorKind");		// エラー種別表示
		kindUi.setValue(kind != null ? kind.toString() : null);
		GPLabel codeUi = (GPLabel) row.findElement("ErrorCode");		// エラーコード表示
		codeUi.setValue(GStringUtils.nullToBlank(code));
		GPLabel messageUi = (GPLabel) row.findElement("ErrorMessage");	// エラーメッセージ表示
		messageUi.setValue(GStringUtils.nullToBlank(message));
		GPTextarea trace = (GPTextarea) findControl("trace");			// スタックトレース表示制御
		String showTrace = SampleUtils.getProperty("sample.ria.ErrorPage.ShowTrace");
		boolean isShowTrace = GBooleanUtils.toBoolean(showTrace, false);
		trace.setVisible(isShowTrace);
		if (isShowTrace && e != null) {
			trace.setValue(GExceptionUtils.getStringStackTrace(e));
		}
	}
}
