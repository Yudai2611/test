/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.common;

import jakarta.servlet.jsp.PageContext;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorType;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.view.component.GView;

/**
 * 検証エラーの通知画面です。
 *
 * @create 2020/6/23
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author miwa
 * @since 20.6.0.0b
 */
public class ValidateErrorView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/**
	 * {@link ValidateErrorView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public ValidateErrorView() {
	}

	/**
	 * 検証エラー情報を画面に反映しています。
	 *
	 * @create 2020/6/23
	 * @param resultData 結果データ
	 * @param parameter パラメータ
	 * @param pageContext ページコンテキスト
	 * @throws Exception 画面のロードに失敗した場合
	 * @see jp.co.kccs.greenearth.framework.view.component.GView#onLoad(GResultData, GParameter)
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		GListData listData = new GListData();
		for (GValidateError error : resultData.getErrors()) {
			GRowData rowData = new GRowData();
			if (GErrorType.WARNING == error.getType()) {
				rowData.setData("ErrorKind", getMessage("WARNING"));
			} else if (GErrorType.ERROR == error.getType()) {
				rowData.setData("ErrorKind", getMessage("ERROR"));
			} else if (GErrorType.INFO == error.getType()) {
				rowData.setData("ErrorKind", getMessage("INFORMATION"));
			}
			//ErrorKind
			rowData.setData("ErrorCode", error.getCode());
			rowData.setData("ErrorMessage", error.getMessage());
			rowData.setData("ErrorField", error.getLabel());
			rowData.setData("ErrorPosition", error.getLabelspace());
			rowData.setData("ErrorDescription", error.getDescription());
			listData.add(rowData);
		}
		resultData.setData("ValidateErrors", listData);

		super.onLoad(resultData, parameter, pageContext);
		resultData.removeData("ValidateErrors");
	}

	/**
	 * 指定したIDのメッセージリソースを取得します。
	 *
	 * @create 2020/6/23
	 * @param resourceid リソースID
	 * @return メッセージリソース
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private String getMessage(String resourceid) {
		return GMessageResources.getMessage(resourceid, GFrameworkContext.getInstance().getLocale());
	}
}
