/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.common.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GList;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;

/**
 * サンプルアプリケーションで使用する共通処理を提供します。<br>
 *
 * @since 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public final class SampleUtils {

	/** サンプルアプリケーション用のプロパティファイル名. */
	public static final String SAMPLE_PROPERTY_NAME = "sample-application";

	/** Don't let anyone instantiate this class. */
	private SampleUtils() {
	}

	/**
	 * サンプルで使用するプロパティファイル内の指定したキーに対応する値を返却します。
	 *
	 * @create 2020/6/23
	 * @param key キー
	 * @return 値
	 * @throws MissingResourceException プロパティファイル内に指定したキーが存在しない場合
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public static String getProperty(final String key) throws MissingResourceException {
		if (key == null) {
			return key;
		}
		ResourceBundle rb = null;
		try {
			rb = ResourceBundle.getBundle(SAMPLE_PROPERTY_NAME);
		} catch (MissingResourceException mex) {
			throw mex;
		}
		return rb.getString(key);
	}

	/**
	 * 指定された{@link GUIControl}に対してvalidateを実行します。<br>
	 * コントロールでエラーが発生した場合、引数のエラーリストに エラー情報を追記します。
	 *
	 * @create 2020/6/23
	 * @param key キー
	 * @param errors エラーリスト
	 * @param control コントロール
	 * @param parameter 画面パラメータ
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public static void validate(List<GValidateError> errors, GUIControl control, GParameter parameter) {
		List<GValidateError> controlError = null;

		if (control instanceof GList) {
			GList element = (GList) control;
			String value = parameter.getValue(element.getParameterKey());
			controlError = element.validate(value, parameter.getValidationLevel());
		} else {
			controlError = control.validate(parameter);
		}

		if (controlError != null) {
			if (errors == null) {
				errors = new ArrayList<GValidateError>();
			}
			errors.addAll(controlError);
		}
	}

	/**
	 * 桁数指定でランダム文字列を取得します。<br>
	 * 生成される文字列はアルファベット（大文字のみ）と数字の37文字から構成されます。<br>
	 *
	 * @create 2020/6/23
	 * @param length 桁数
	 * @return ランダム文字列
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public static String getRandomString(int length) {
		StringBuilder sb = new StringBuilder();
		final char[] ch = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
		for (int i = 0; i < length; i++) {
			int rand = (int) Math.round(Math.random() * (ch.length - 1));

			sb.append(ch[rand]);
		}
		return sb.toString();
	}

}
