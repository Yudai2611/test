/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.ria.fqe.action;

import javax.xml.parsers.ParserConfigurationException;

import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;
import jp.co.kccs.greenearth.framework.fqeria.helper.GDatasourceHelper;




/**
 * データソース読込処理を行うアクションクラスです.
 * 
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.3.0 β
 */
public class DatasourceAction {

	/**
	 * {@link DatasourceAction}インスタンスを初期化します.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public DatasourceAction() {
	}

	/**
	 * データソース一覧表示のアクションです.<br>
	 * データソース名の一覧を結果セットに設定します.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws ParserConfigurationException, IOException,
	 *             GXmlAttributeIsMissingException, SAXException
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public GResultData findAllDatasourceMetadata(GParameter parameter, GResultData resultData) throws GValidateException {
		GRange paginationCondition = GDatasourceHelper.getPaginationCondition(parameter);
		return GDatasourceHelper.convertTo(GDatasourceMetadataService.getInstance().extract(paginationCondition), resultData);
	}

	/**
	 * データソース選択のアクションです.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws ParserConfigurationException, IOException,
	 *             GXmlAttributeIsMissingException, SAXException,
	 *             GDatasourceException
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public GResultData findDatasourceMetadataById(GParameter parameter, GResultData resultData) {
		String datasourceId = GEXActionUtils.extractRowData(parameter).getString("datasourceId");
		return GDatasourceHelper.convertTo(GDatasourceMetadataService.getInstance().lookupById(datasourceId), resultData);
	}

}
