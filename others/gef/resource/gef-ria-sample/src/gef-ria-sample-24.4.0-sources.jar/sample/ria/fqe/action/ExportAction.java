/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.ria.fqe.action;

import java.io.File;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasource;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportService;
import jp.co.kccs.greenearth.framework.fqecore.domain.exports.GExportedResult;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GImportService;
import jp.co.kccs.greenearth.framework.fqeria.helper.GExportConditionHelper;
import jp.co.kccs.greenearth.framework.fqeria.helper.GImportConditionHelper;

/**
 * 出力条件定義に対する処理を行うアクションクラスです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.3.0 β
 */
public class ExportAction {

	/**
	 * {@link ExportAction}インスタンスを初期化します.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public ExportAction() {
	}

	/**
	 * クエリデータを出力します.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セットg
	 * @return resultData 結果セット
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public GResultData export(GParameter parameter, GResultData resultData)  {
		GImportCondition importCondition = GImportConditionHelper.convertTo(parameter);
		GExportCondition exportCondition = GExportConditionHelper.convertTo(parameter);
		GDatasource datasource = GImportService.getInstance().imports(importCondition);
		GExportedResult<File> file = GExportService.getInstance().export(datasource, exportCondition);
		return GExportConditionHelper.convertTo(file, resultData);
	}
	
	/**
	 * 出力するデータの件数をカウントします.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public GResultData count(GParameter parameter, GResultData resultData)  {
		GImportCondition importCondition = GImportConditionHelper.convertTo(parameter);
		int datasourceSize = GImportService.getInstance().importsSize(importCondition);
		resultData.setData("SelectCount", datasourceSize);
		return resultData;
	}

}
