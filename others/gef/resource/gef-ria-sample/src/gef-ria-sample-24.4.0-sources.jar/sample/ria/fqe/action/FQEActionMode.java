/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.ria.fqe.action;

/**
 * アクションのモードを示す列挙型クラスです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.3.0 β
 */
public enum FQEActionMode {

	/** 出力モードです. */
	EXPORT("export"),

	/** 保存モードです. */
	SAVE("save"),

	/** 選択モードです. */
	SELECT("select"),
	
	/** 件数確認モードです. */
	COUNT("count");

	/** モードを格納する変数です. */
	private String mode;

	/**
	 * コンストラクターです.
	 *
	 * @create 2023/10/25
	 * @param mode アクションのモード
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	FQEActionMode(String mode) {
		this.mode = mode;
	}

	/**
	 * モードを返します.
	 *
	 * @create 2023/10/25
	 * @return mode アクションのモード
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public String getMode() {
		return mode;
	}
}
