/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.ria.fqe.action;

import java.sql.SQLException;

import jp.co.kccs.greenearth.commons.data.GRange;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.db.GTransactionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryCondition;
import jp.co.kccs.greenearth.framework.fqecore.domain.history.GHistoryConditionService;
import jp.co.kccs.greenearth.framework.fqeria.helper.GHistoryConditionHelper;




/**
 * 出力条件の履歴に対する処理を行うアクションクラスです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.3.0 β
 */
public class HistoryConditionAction {

	/**
	 * デフォルトコンストラクタです.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public HistoryConditionAction() {
	}

	/**
	 * 出力条件削除のアクションです.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData deleteHistory(GParameter parameter, GResultData resultData) {
		GListData listData = GEXActionUtils.extractListData(parameter, "historyConditionList");
		for (GRowData rowData : listData) {
			boolean isDelete = rowData.getBoolean("DeleteFG");
			if (isDelete) {
				GHistoryConditionService.getInstance().deleteById(rowData.getString("historyId"));
			}
		}
		return searchHistory(parameter, resultData);
	}

	/**
	 * 出力条件定義保存のアクションです.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws SQLException
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData saveHistory(GParameter parameter, GResultData resultData) {
		GHistoryCondition historyCondition = GHistoryConditionHelper.convertTo(parameter);
		GHistoryConditionService.getInstance().save(historyCondition);
		return resultData;
	}

	/**
	 * 出力条件定義一覧検索のアクションです.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public GResultData searchHistory(GParameter parameter, GResultData resultData) {
		GRange range = GHistoryConditionHelper.getPaginationCondition(parameter);
		GRangeResult<GHistoryCondition> listData = GHistoryConditionService.getInstance().findByContains(parameter.getValue("datasourceLabelKeyword"),
				parameter.getValue("historyNameKeyword"), parameter.getValue("savedByKeyword"), range);
		return GHistoryConditionHelper.convertTo(listData, resultData);
	}

	/**
	 * 出力条件読み込みのアクションです.
	 *
	 * @create 2023/10/25
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public GResultData selectHistory(GParameter parameter, GResultData resultData) {
		GHistoryCondition historyCondition = GHistoryConditionService.getInstance().findById(GEXActionUtils.extractRowData(parameter).getString("historyId"));
		return GHistoryConditionHelper.convertTo(historyCondition, resultData);
	}
}
