/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.ria.fqe.view;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import jakarta.servlet.jsp.PageContext;
import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.formatter.GBigDecimalFormatter;
import jp.co.kccs.greenearth.commons.formatter.GDateFormatter;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.fqecore.GFqePropertyKey;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceFieldMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceMetadata;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceType;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GDatasourceUtil;
import jp.co.kccs.greenearth.framework.fqecore.datasource.GFieldDataType;
import jp.co.kccs.greenearth.framework.fqecore.domain.imports.GSqlQueryOperator;
import jp.co.kccs.greenearth.framework.fqecore.domain.registry.GDatasourceMetadataService;
import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQEList;
import jp.co.kccs.greenearth.framework.fqeria.ui.control.GFQETab;
import jp.co.kccs.greenearth.framework.richview.rich.ui.control.dialog.GRDialog;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPButton;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPCheckBox;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPHidden;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPSelect;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPText;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPTextarea;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListRow;
import jp.co.kccs.greenearth.framework.view.component.GUIControl;
import jp.co.kccs.greenearth.framework.view.component.GView;
import jp.co.kccs.greenearth.framework.view.validator.GMaxByteLengthValidator;
import jp.co.kccs.greenearth.framework.view.validator.GRequiredValidator;
import sample.ria.fqe.action.FQEActionMode;

/**
 * 出力条件定義の入力を表示するViewクラスです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.3.0 β
 */
public class ExportView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/** 出力有無のチェックボックス */
	private static final String EXPORT_CHECKBOX = "isUsed";

	/** 出力条件名格納hidenタグ */
	private static final String INPUT_CONDITION_NAME_HIDDEN = "historyName";

	/** 出力フィールドリスト */
	private static final String EXPORT_COLUMN_LIST = "fieldList";

	/** 出力有無の全チェックボックス */
	private static final String EXPORT_FIELD_CHECKBOX_ALL_VALID = "fieldList.header.isUsedAll";

	/** フィルターフィールドリスト */
	private static final String FILTER_COLUMN_LIST = "filterFieldList";

	/** フィルターフィールドタブ */
	private static final String FILTER_COLUMN_LIST_TAB = "filterFieldGroupList";

	/** 出力ファイル名格納hidenタグ */
	private static final String INPUT_FILE_NAME_HIDDEN = "exportName";

	/** データソース表示ラベル */
	private static final String DATASOURCE_LABEL = "datasourceLabel";

	/** データ出力ボタン */
	private static final String EXPORT_BUTTON = "DataExportBtn";

	/** 条件保存ボタン */
	private static final String SAVE_BUTTON = "SaveBtn";

	/** データソースID */
	private static final String DATASOURCE_ID = "datasourceId";

	/** フィールドID */
	private static final String FIELD_ID = "fieldId";

	/** フィルター条件値 */
	private static final String VALUE = "value";
	
	/** フィルター条件値 */
	private static final String OPERATOR = "operator";

	/** フィルター条件値最大バイト数 */
	private static final int VALUE_MAX_SIZE = 100;
	
	/** 件数確認OKボタン */
	private static final String SELECT_COUNT_OK_BUTTON = "SelectCountOkBtn";
	
	/** データソース選択ボタン */
	private static final String SELECT_DATASOURCE_BUTTON = "DatasourceSelectBtn";
	
	/** 件数確認ダイアログ */
	private static final String SELECT_COUNT_DIALOG = "SelectCountDialog";
	
	/** 件数確認ボタン */
	private static final String SELECT_COUNT_BUTTON = "CountsCheckBtn";


	/**
	 * {@link ExportView}インスタンスを初期化します.
	 *
	 * @create 2023/10/25
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public ExportView() {
		super();
	}

	/**
	 * 画面のコントロールを初期化します。<br>
	 *
	 * @create 2023/10/25
	 * @param resultData 事前アクションの処理結果
	 * @param parameter 画面パラメータ
	 * @param pageContext ページコンテキスト
	 * @throws Exception 読み込みに失敗した場合
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		super.onLoad(resultData, parameter, pageContext);
		String mode = parameter.getValue(GActionServlet.ACTION_MODE_KEY);
		resetView(mode);
		setDisplaySize(mode, resultData);
		setButtonState();
		setDialogState (mode, resultData);
	}

	/**
	 * 画面入力値のチェックです.<br>
	 *
	 * @create 2023/10/25
	 * @param parameter 画面パラメータ
	 * @return エラーリスト
	 * @author KCCS oka
	 * @since 23.3.0 β
	 *
	 */
	@Override
	public List<GValidateError> onValidate(GParameter parameter) {
		List<GValidateError> errors = super.onValidate(parameter);
		String mode = parameter.getValue(GActionServlet.ACTION_MODE_KEY);
		if (FQEActionMode.EXPORT.getMode().equals(mode) || FQEActionMode.SAVE.getMode().equals(mode) || FQEActionMode.COUNT.getMode().equals(mode)) {
			validateGeneralAction(parameter, errors);
		}
		if (FQEActionMode.EXPORT.getMode().equals(mode)) {
			validateExportAction(parameter, errors);
		}
		if (FQEActionMode.SAVE.getMode().equals(mode)) {
			validateSaveAction(parameter, errors);
		}
		return errors;
	}

	private void validateExportAction(GParameter parameter, List<GValidateError> errors) {
		GFQEList exportColumnList = (GFQEList) findControl(EXPORT_COLUMN_LIST);
		GUIControl exportNameControl = findControl(INPUT_FILE_NAME_HIDDEN);
		String exportName = parameter.getValue(INPUT_FILE_NAME_HIDDEN);
		if (exportName == null || "".equals(exportName)) {
			errors.add(createValidateError(GRequiredValidator.DEFAULT_ERROR_CODE, exportNameControl,
				exportNameControl.getLabel()));
		}
		if (exportName.matches(".*[\\\\/:\\*\\?<>|\"].*")) {
			errors.add(createValidateError(FQEErrorCode.ERROR_CD_FORBIDDEN_CHARACTER.getCode(), exportNameControl,
				exportNameControl.getLabel()));
		}
		GMaxByteLengthValidator maxByteLengthValidator = new GMaxByteLengthValidator();
		maxByteLengthValidator.setArgs("50");
		GValidateError saveNameError = maxByteLengthValidator.validate(exportNameControl, exportName, errors,
			GFrameworkContext.getInstance().getLocale());
		if (saveNameError != null) {
			errors.add(saveNameError);
		}
		boolean isChecked = false;
		for (GListRow listRow : exportColumnList.getRows()) {
			GPCheckBox outputFG = (GPCheckBox) listRow.findElement(EXPORT_CHECKBOX);
			if (outputFG.isChecked()) {
				isChecked = true;
				break;
			}
		}
		if (!isChecked) {
			GUIControl control = findControl(EXPORT_FIELD_CHECKBOX_ALL_VALID);
			GValidateError error = createValidateError(FQEErrorCode.ERROR_CD_NOOUTPUT.getCode(), control, null);
			String labelSpace = error.getLabelspace().replaceAll("\\[\\d+\\]", "");
			error.setLabelspace(labelSpace);
			errors.add(error);
		}
	}

	private void validateGeneralAction(GParameter parameter, List<GValidateError> errors) {
		GFQEList exportColumnList = (GFQEList) findControl(EXPORT_COLUMN_LIST);
		checkFilterValue(parameter, errors);
		boolean isChecked = false;
		for (GListRow listRow : exportColumnList.getRows()) {
			GPCheckBox outputFG = (GPCheckBox) listRow.findElement(EXPORT_CHECKBOX);
			if (outputFG.isChecked()) {
				isChecked = true;
				break;
			}
		}
		if (!isChecked) {
			GUIControl control = findControl(EXPORT_FIELD_CHECKBOX_ALL_VALID);
			GValidateError error = createValidateError(FQEErrorCode.ERROR_CD_NOOUTPUT.getCode(), control, null);
			String labelSpace = error.getLabelspace().replaceAll("\\[\\d+\\]", "");
			error.setLabelspace(labelSpace);
			errors.add(error);
		}
	}

	private void validateSaveAction(GParameter parameter, List<GValidateError> errors) {
		GUIControl saveNameControl = findControl(INPUT_CONDITION_NAME_HIDDEN);
		String saveName = parameter.getValue(INPUT_CONDITION_NAME_HIDDEN);
		if (saveName == null || "".equals(saveName)) {
			errors.add(createValidateError(GRequiredValidator.DEFAULT_ERROR_CODE, saveNameControl,
				saveNameControl.getLabel()));
		}
		GMaxByteLengthValidator maxByteLengthValidator = new GMaxByteLengthValidator();
		maxByteLengthValidator.setArgs("50");
		GValidateError saveNameError = maxByteLengthValidator.validate(saveNameControl, saveName, errors,
			GFrameworkContext.getInstance().getLocale());
		if (saveNameError != null) {
			errors.add(saveNameError);
		}
	}

	/**
	 * エラーオブジェクトを生成します.
	 *
	 * @create 2023/10/25
	 * @param errorCode エラーコード
	 * @param control UIコントロール
	 * @param label 表示名
	 * @return エラー
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	private GValidateError createValidateError(String errorCode, GUIControl control, String label) {
		GValidateError error = GEXActionUtils.createValidateError(errorCode);
		error.addFieldId(control.getParameterKey());
		error.setLabel(label != null ? label : control.getLabel());
		error.setLabelspace(control.getLabelspace());
		return error;
	}

	/**
	 * タブの最大表示数を設定します.
	 * 
	 * @create 2023/10/25
	 * @param mode モード
	 * @param resultData 結果セット
	 * @throws CloneNotSupportedException
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	private void setDisplaySize(String mode, GResultData resultData) throws CloneNotSupportedException {
		if (Objects.isNull(mode)) {
			return;
		}
		String displaySize = resultData.getString(FILTER_COLUMN_LIST_TAB + ".displaysize");
		int tabSize = 1;
		int listCount = 0;
		GFQETab tab = (GFQETab) findControl(FILTER_COLUMN_LIST_TAB);
		if (displaySize != null) {
			tabSize = Integer.parseInt(displaySize);
		} else {
			tabSize = Integer.parseInt(tab.getSize());
		}
		if (FQEActionMode.SELECT.getMode().equals(mode)) {
			for (int i = 0; i < tabSize; i++) {
				GListData listData = (GListData) resultData.getData(FILTER_COLUMN_LIST + i);
				if (listData != null) {
					listCount++;
				}
			}
			tab.setDisplaysize(listCount > 0 ? listCount : 1);
			tab.setTabSelected(0);
		}
	}

	private void setButtonState() {
		GPText datasourceName = (GPText) findControl(DATASOURCE_LABEL);
		if (GStringUtils.isNotEmpty(datasourceName.getValue())) {
			GPButton exportButton = (GPButton) findControl(EXPORT_BUTTON);
			GPButton saveButton = (GPButton) findControl(SAVE_BUTTON);
			GPButton countButton = (GPButton) findControl(SELECT_COUNT_BUTTON);
			exportButton.setEnabled(true);
			saveButton.setEnabled(true);
			countButton.setEnabled(true);
		}
	}

	private void resetView(String mode) {
		if (GStringUtils.isNullOrEmpty(mode)) {
			this.reset();
		}
		if (FQEActionMode.SELECT.getMode().equals(mode)) {
			GPCheckBox checkBox = (GPCheckBox) findControl(EXPORT_FIELD_CHECKBOX_ALL_VALID);
			checkBox.reset();
		}
	}
	
	private void setDialogState (String mode, GResultData resultData) {
		GRDialog dialog = (GRDialog) findControl(SELECT_COUNT_DIALOG);
		if (FQEActionMode.COUNT.getMode().equals(mode) && resultData.getExitCode().equals(GResultData.EXIT_CODE_SUCCESS)) {
			dialog.setVisible(true);
			GPButton selectCountBtn = (GPButton) findControl(SELECT_COUNT_OK_BUTTON);
			selectCountBtn.focus();
		} else {
			dialog.setVisible(false);
			GPButton datasourceBtn = (GPButton) findControl(SELECT_DATASOURCE_BUTTON);
			datasourceBtn.focus();
		}
	}

	private void checkFilterValue(GParameter parameter, List<GValidateError> errors) {

		int displaySize = parameter.getInteger(FILTER_COLUMN_LIST_TAB + ".displaysize");
		String datasourceId = ((GPHidden) findControl(DATASOURCE_ID)).getValue();

		GDatasourceMetadata< ? extends GDatasourceType> datasourceMetadata =
			GDatasourceMetadataService.getInstance().lookupById(datasourceId);
		Map<String, GDatasourceFieldMetadata> datasourceFieldMetadataMap =
			GDatasourceUtil.toFieldMetadataMap(datasourceMetadata.getDatasourceFields());

		for (int i = 0; i < displaySize; i++) {

			GFQEList filterList = (GFQEList) findControl(FILTER_COLUMN_LIST + i);
			int columnIndex = 0;
			for (GListRow listRow : filterList.getRows()) {
				GPTextarea textArea = (GPTextarea) listRow.findElement(VALUE);
				List<String> valueList = new ArrayList<String>();
				valueList = Arrays.asList(textArea.getValue().split("\r\n", -1));
				String columnId = ((GPHidden) listRow.findElement(FIELD_ID)).getValue();
				
				GMaxByteLengthValidator maxByteLengthValidator = new GMaxByteLengthValidator();
				maxByteLengthValidator.setArgs(String.valueOf(VALUE_MAX_SIZE));
				GValidateError valueMaxLengthError = maxByteLengthValidator.validate(textArea,
					String.join("\r\n", valueList), errors, GFrameworkContext.getInstance().getLocale());
				if (valueMaxLengthError != null) {
					valueMaxLengthError.setLabel(datasourceFieldMetadataMap.get(columnId).getLabel());
					errors.add(valueMaxLengthError);
				}
				
				GPSelect select = (GPSelect) listRow.findElement(OPERATOR);
				if (String.valueOf(GSqlQueryOperator.FORWARD_MATCH.getInternalParam()).equals(select.getValue()) || 
				    String.valueOf(GSqlQueryOperator.PARTIAL_MATCH.getInternalParam()).equals(select.getValue()) ||
				    String.valueOf(GSqlQueryOperator.BACKWARD_MATCH.getInternalParam()).equals(select.getValue())) {
					columnIndex++;
					continue;
				}
				
				for (String value : valueList) {

					if (datasourceFieldMetadataMap.get(columnId).getDataType().equals(GFieldDataType.DATE)) {
						String[] dateFormats = GFqePropertyKey.IMPORT_DATE_FORMAT.getPropertyValue().split("\\|");
						Boolean isError = false;
						for (String format : dateFormats) {
							isError = false;
							try {
								GDateFormatter dateFormatter =
									GFrameworkUtils.getComponent(GDateFormatter.class.getName());
								dateFormatter.parse(value, GFrameworkContext.getInstance().getLocale(), format);

							} catch (ParseException exception) {
								isError = true;
							}
							if (!isError) {
								break;
							}
						}
						if (isError) {
							List<String> idList = new ArrayList<String>();
							idList.add(FILTER_COLUMN_LIST + i + "." + columnIndex + "." + VALUE);
							GValidateError validateError =
								createValidateError(FQEErrorCode.ERROR_CD_INCORRECT_FORMAT.getCode(), textArea,
									datasourceFieldMetadataMap.get(columnId).getLabel());
							validateError.setFieldIdList(idList);
							errors.add(validateError);
						}
					}
					if (datasourceFieldMetadataMap.get(columnId).getDataType().equals(GFieldDataType.NUMERIC)) {
						String[] dateFormats = GFqePropertyKey.IMPORT_NUMBER_FORMAT.getPropertyValue().split("\\|");
						Boolean isError = false;
						for (String format : dateFormats) {
							try {
								isError = false;
								GBigDecimalFormatter formatter =
									GFrameworkUtils.getComponent(GBigDecimalFormatter.class.getName());
								formatter.parse(value, GFrameworkContext.getInstance().getLocale(), format);
							} catch (ParseException exception) {
								isError = true;
							}
							if (!isError) {
								break;
							}
						}
						if (isError) {
							List<String> idList = new ArrayList<String>();
							idList.add(FILTER_COLUMN_LIST + i + "." + columnIndex + "." + VALUE);
							GValidateError validateError =
								createValidateError(FQEErrorCode.ERROR_CD_INCORRECT_FORMAT.getCode(), textArea,
									datasourceFieldMetadataMap.get(columnId).getLabel());
							validateError.setFieldIdList(idList);
							errors.add(validateError);
						}
					}
				}
				columnIndex++;
			}
		}
	}
}
