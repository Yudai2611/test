/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.ria.fqe.view;

/**
 * エラーコードを示す列挙型クラスです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.3.0 β
 */
public enum FQEErrorCode {

	GENERAL_ERROR("GEF-000000"),
	/** ファイル形式が未選択 */
	ERROR_CD_NOFILETYPE("GES-100017"),

	/** 出力項目が未選択 */
	ERROR_CD_NOOUTPUT("GES-100015"),
	
	/** 禁止文字列が入っている */
	ERROR_CD_FORBIDDEN_CHARACTER("GEM-000007"),
	ERROR_CD_INCORRECT_FORMAT("GES-100016");

	/** エラーコードを格納する変数です. */
	private String errorCode;

	/**
	 * コンストラクターです.
	 *
	 * @create 2023/10/25
	 * @param errorCode エラーコード
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	FQEErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * エラーコードを返します.
	 *
	 * @create 2023/10/25
	 * @return エラーコード
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	public String getCode() {
		return errorCode;
	}

}
