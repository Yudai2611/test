/*
 * Copyright 2022 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.ria.fqe.view;

import jakarta.servlet.jsp.PageContext;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPCheckBox;
import jp.co.kccs.greenearth.framework.view.component.GView;

/**
 * 出力条件定義の履歴を表示するViewクラスです.
 *
 * @create 2023/10/25
 * @author KCCS oka
 * @since 23.3.0 β
 */
public class HistoryConditionView extends GView {

	/** 削除チェックボックス */
	public static final String CHECKBOX_HISTORY = "historyConditionList.header.DeleteFG";
	
	/** 登録名 */
	public static final String HISTORY_NAME_KEYWORD = "historyNameKeyword";
	
	/** データソース名*/
	public static final String DATASOURCE_LABEL_KEYWORD = "datasourceLabelKeyword";
	
	/** 登録者名*/
	public static final String SAVED_BY_KEYWORD = "savedByKeyword";
	
	/** zoom画面オープン時モード */
	public static final String MODE_SEARCH = "search";
	
	/** 履歴削除 */
	public static final String MODE_DELETE = "delete";

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/**
	 * デフォルトコンストラクタです.
	 * 
	 * @author KCCS oka
	 * @create 2023/10/25
	 * @since 23.3.0 β
	 */
	public HistoryConditionView() {
	}

	/**
	 * チェックボックスの状態を初期状態に戻します.
	 *
	 * @create 2023/10/25
	 * @see jp.co.kccs.greenearth.framework.view.component.GView#onLoad(jp.co.kccs.greenearth.framework.data.GResultData,
	 *      jp.co.kccs.greenearth.framework.GParameter,
	 *      jakarta.servlet.jsp.PageContext)
	 * @param resultData 結果セット
	 * @param parameter パラメータ
	 * @param pageContext ページコンテキスト
	 * @throws Exception 画面のロードに失敗した場合
	 * @author KCCS oka
	 * @since 23.3.0 β
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		super.onLoad(resultData, parameter, pageContext);
		GPCheckBox checkBox = (GPCheckBox) findControl(CHECKBOX_HISTORY);
		checkBox.reset();
		if (MODE_SEARCH.equals(parameter.getValue(GActionServlet.ACTION_MODE_KEY)) || MODE_DELETE.equals(parameter.getValue(GActionServlet.ACTION_MODE_KEY))) {
			return;
		}
		findControl(HISTORY_NAME_KEYWORD).clear();
		findControl(DATASOURCE_LABEL_KEYWORD).clear();
		findControl(SAVED_BY_KEYWORD).clear();
	}
}
