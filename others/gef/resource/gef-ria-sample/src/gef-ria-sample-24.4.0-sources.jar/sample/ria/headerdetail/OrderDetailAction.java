/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.headerdetail;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import jp.co.kccs.greenearth.commons.GApplicationException;
import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.data.GValidateException;
import jp.co.kccs.greenearth.framework.db.GTransactionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.view.action.Validatefull;
import sample.ria.common.SampleConstants;
import sample.ria.common.utils.SampleUtils;

/**
 * 発注明細画面のアクションクラスです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class OrderDetailAction {

	/**
	 * {@link OrderDetailAction}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public OrderDetailAction() {
	}

	/** 伝票番号採番コード. */
	private final String NUMCODE_SLIPNO = "D02";

	/** 伝票番号のフォーマット */
	private final String SLIPNO_FORMAT = "00000";

	/** 明細行の更新タイプ */
	private enum ActionType {
		/** 更新. */
		DELETE,
		/** 変更. */
		MODIFY,
		/** 新規. */
		NEW
	};

	/**
	 * 登録ボタン押下時のアクションです。<br>
	 * 商品コードが存在するかをチェックし、
	 * 存在すれば、発注ヘッダ、発注明細を登録します。
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Validatefull
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData doInsert(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		checkInputDetail(parameter, resultData);

		parameter.setValue(SampleConstants.ORDERHEADER_SLIPNO, numberingSlipNO());

		try {
			updateHeader(parameter, ActionType.NEW);
			updateDetail(parameter);
		} catch (GOptimisticLockException e) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OTHERUSING);
			throw new GValidateException(error);
		}

		return resultData;
	}

	/**
	 * 更新ボタン押下時のアクションです。<br>
	 * 商品コードが存在するかをチェックし、
	 * 存在すれば、発注ヘッダ、発注明細を更新します。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Validatefull
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData doUpdate(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		checkInputDetail(parameter, resultData);
		try {
			updateHeader(parameter, ActionType.MODIFY);
			updateDetail(parameter);
		} catch (GOptimisticLockException e) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OTHERUSING);
			throw new GValidateException(error);
		}

		return resultData;
	}

	/**
	 * 伝票削除ボタン押下時のアクションです。<br>
	 * 発注ヘッダ、発注明細を削除します。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Validatefull
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData doDelete(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		try {
			updateHeader(parameter, ActionType.DELETE);
			deleteDetail(parameter);
		} catch (GOptimisticLockException e) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OTHERUSING);
			throw new GValidateException(error);
		}
		return resultData;
	}

	/**
	 * 行追加時のアクションです。
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GResultData doAddRow(GParameter parameter, GResultData resultData) throws SQLException {
		return resultData;
	}

	/**
	 * 明細削除ボタン押下時のアクションです。<br>
	 * 発注明細を削除します。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @since 20.6.0.0b
	 */
	@Validatefull
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData doDeleteRow(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		try {
			updateDetail(parameter);
		} catch (GOptimisticLockException e) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OTHERUSING);
			throw new GValidateException(error);
		}
		return resultData;
	}

	/**
	 * キャンセルボタン押下時のアクションです。
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GResultData doCancel(GParameter parameter, GResultData resultData) {
		return resultData;
	}

	/**
	 * 発注ヘッダの登録、更新、削除処理を行います。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param actionType 更新タイプ
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void updateHeader(GParameter parameter, ActionType actionType) throws SQLException {
		GRecord headerRecord = createRecord();

		GGjdbcActionUtils.copyValue(headerRecord, parameter, SampleConstants.ORDERHEADER);

		headerRecord.setObject(SampleConstants.COMPANYCD, GEXActionUtils.getLoginCompany().getCode());

		if (ActionType.NEW.equals(actionType)) {
			headerRecord.setObject(SampleConstants.REGISTEREDPERSON, GEXActionUtils.getLoginUser().getId());
			headerRecord.setObject(SampleConstants.UPDATEDPERSON, GEXActionUtils.getLoginUser().getId());
			insert(SampleConstants.ORDERHEADER).values(headerRecord).execute();
		} else if (ActionType.MODIFY.equals(actionType)) {
			headerRecord.setObject(SampleConstants.UPDATEDPERSON, GEXActionUtils.getLoginUser().getId());
			update(SampleConstants.ORDERHEADER)
				.set(headerRecord)
				.excludes(SampleConstants.REGISTEREDDT, SampleConstants.REGISTEREDPERSON)
				.whereUK(SampleConstants.ORDERHEADER_SLIPNO_KEY)
				.execute();
		} else if (ActionType.DELETE.equals(actionType)) {
			delete(SampleConstants.ORDERHEADER).whereUK(SampleConstants.ORDERHEADER_SLIPNO_KEY, headerRecord).execute();
		}
	}

	/**
	 * 発注明細の、登録、更新、削除処理を行います。 <br>
	 * 更新対象行のみを対象として、更新処理を行います。<br>
	 * 明細行の更新後、明細番号の欠番を無くすために、明細番号を設定し直します。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void updateDetail(GParameter parameter) throws SQLException {
		GListData detailListData = GEXActionUtils.extractListData(parameter, OrderDetailView.ORDERDETAIL_LIST);
		int i = 0;
		for (GRowData rowData : detailListData) {
			i++;
			if (isUpdateRow(parameter.getValue(GActionServlet.ACTION_ID), rowData)) {
				ActionType actionType = getActionType(parameter.getValue(GActionServlet.ACTION_ID), rowData);

				rowData.setData(SampleConstants.ORDERDETAIL_DETAILNO, i);

				GRecord detailRecord = createRecord();
				GGjdbcActionUtils.copyValue(detailRecord, rowData, SampleConstants.ORDERDETAIL);
				detailRecord.setObject(SampleConstants.COMPANYCD, GEXActionUtils.getLoginCompany().getCode());
				detailRecord.setObject(SampleConstants.ORDERHEADER_SLIPNO, parameter.getValue(SampleConstants.ORDERHEADER_SLIPNO));

				if (ActionType.NEW.equals(actionType)) {
					detailRecord.setObject(SampleConstants.ORDERDETAIL_DETAILID, SampleUtils.getRandomString(32));
					detailRecord.setObject(SampleConstants.REGISTEREDPERSON, GEXActionUtils.getLoginUser().getId());
					detailRecord.setObject(SampleConstants.UPDATEDPERSON, GEXActionUtils.getLoginUser().getId());
					insert(SampleConstants.ORDERDETAIL).values(detailRecord).execute();
				} else if (ActionType.MODIFY.equals(actionType)) {
					detailRecord.setObject(SampleConstants.UPDATEDPERSON, GEXActionUtils.getLoginUser().getId());
					update(SampleConstants.ORDERDETAIL)
						.set(detailRecord)
						.excludes(SampleConstants.REGISTEREDDT, SampleConstants.REGISTEREDPERSON)
						.wherePK()
						.execute();
				} else if (ActionType.DELETE.equals(actionType)) {
					delete(SampleConstants.ORDERDETAIL).wherePK(detailRecord).execute();
				}
			}
		}
		numberingDetailNo(GEXActionUtils.getLoginCompany().getCode(), parameter.getValue(SampleConstants.ORDERHEADER_SLIPNO));
	}

	/**
	 * 明細行の更新タイプを取得します。<br>
	 * 新規登録ボタン押下時には、NEWを返します。<br>
	 * 更新ボタン押下時には、画面で追加された行であればNEWを、そうでなければMODIFYを返します。<br>
	 * 明細削除ボタン押下時には、DELETEを返します。<br>
	 *
	 * @create 2020/6/23
	 * @param actionid アクションID
	 * @param rowData 明細行データ
	 * @return 更新タイプ
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private ActionType getActionType(String actionid, GRowData rowData) {
		ActionType actionType = ActionType.NEW;
		if (OrderDetailView.ID_UPDATE_H.equals(actionid)) {
			if (!rowData.getBoolean(OrderDetailView.ID_ADDROW_FG)) {
				actionType = ActionType.MODIFY;
			}
		}
		else if (OrderDetailView.ID_DELETEROW_H.equals(actionid)) {
			actionType = ActionType.DELETE;
		}
		return actionType;
	}

	/**
	 * 発注ヘッダに対する明細を全て削除します。<br>
	 * 発注ヘッダから伝票番号を取得して、 伝票番号が一致する明細を削除します。
	 *
	 * @create 2020/6/23
	 * @param slipNo 伝票番号
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void deleteDetail(GParameter parameter) throws SQLException {
		delete(SampleConstants.ORDERDETAIL)
			.where(exp($(SampleConstants.ORDERHEADER_SLIPNO + " = ?").AND($(SampleConstants.COMPANYCD + " = ?")),
				parameter.getValue(SampleConstants.ORDERHEADER_SLIPNO), GEXActionUtils.getLoginCompany().getCode()))
			.execute();
	}

	/**
	 * 発注明細行に入力された商品コードの存在チェックを行います。<br>
	 * 商品コードが存在しない場合、例外が投げられます。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void checkInputDetail(GParameter parameter, GResultData resultData) throws GValidateException, SQLException {

		List<GValidateError> errors = resultData.getErrors();

		// 商品コードの存在チェックを行います
		errors = checkItemCd(errors, parameter, resultData);

		if (!errors.isEmpty()) {
			throw new GValidateException(errors);
		}

	}

	/**
	 * 商品コードが商品マスタに存在するかチェックします。<br>
	 * 商品マスタに存在しない場合、エラー情報に追加します。
	 *
	 * @create 2020/6/23
	 * @param errors エラーコード
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return エラー情報
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private List<GValidateError> checkItemCd(List<GValidateError> errors, GParameter parameter, GResultData resultData) throws SQLException {

		GListData detailListData = GEXActionUtils.extractListData(parameter, OrderDetailView.ORDERDETAIL_LIST);
		if (detailListData == null) {
			return errors;
		}

		int i = 0;
		for (GRowData rowData : detailListData) {
			String addRowFG = rowData.getString(OrderDetailView.ID_ADDROW_FG);

			if (rowData.getBoolean(OrderDetailView.ID_CHECK_FG) && Boolean.valueOf(addRowFG)) {
				String parameterKey = OrderDetailView.ORDERDETAIL_LIST + "." + i + "." + SampleConstants.ORDERDETAIL_ITEMCD;
				boolean checkErrorFlag = true;
				if (errors != null) {
					for (GValidateError errorData : errors) {
						List<String> fieldIdList = errorData.getFieldIdList();
						if (fieldIdList.contains(parameterKey)) {
							checkErrorFlag = false;
							break;
						}
					}
				}

				if (checkErrorFlag) {
					String itemCd = rowData.getString(SampleConstants.ORDERDETAIL_ITEMCD);

					int count = select(SampleConstants.ITEMMASTER)
									.where(exp($(SampleConstants.COMPANYCD + " = ?").AND($(SampleConstants.ITEMMASTER_ITEMCD + " = ?")),
											GEXActionUtils.getLoginCompany().getCode(), itemCd))
									.count();

					if (count == 0) {
						Locale locale = GFrameworkContext.getInstance().getLocale();
						String label = GMessageResources.getMessage("ITEM-CODE", locale);
						GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_NOITEM);
						error.addFieldId(parameterKey);
						error.setLabel(label);
						error.setLabelspace("[" + (i + 1) + "]");
						if (errors == null) {
							errors = new ArrayList<GValidateError>();
						}
						errors.add(error);
					}
				}
			}
			i++;
		}
		return errors;
	}

	/**
	 * 伝票番号を採番します<br>
	 * 採番マスタから値を取得して、伝票番号を組み立てます。
	 *
	 * @create 2020/6/23
	 * @return slipNO 採番された伝票番号
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private String numberingSlipNO() throws GValidateException, SQLException {

		GEntitySelect select = select(SampleConstants.SNUMBERING)
								.wherePK(GEXActionUtils.getLoginCompany().getCode(), NUMCODE_SLIPNO);
		GRecord record = select.findRecord();

		if (record == null || record.getBigDecimal(SampleConstants.SNUMBERING_CURRENTVALUE) == null) {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			GErrorMessage message = GErrorMessages.getErrorMessage("GEF-000051", locale);
			message.setMessage(message.getMessage() + "[" + select.getEntity().getName() + "]");
			throw new GApplicationException(message);
		}

		String constValue = record.getString(SampleConstants.SNUMBERING_CONSTVALUE);

		BigDecimal endValue = record.getBigDecimal(SampleConstants.SNUMBERING_ENDVALUE);
		BigDecimal currentValue = record.getBigDecimal(SampleConstants.SNUMBERING_CURRENTVALUE);
		BigDecimal incrementValue = record.getBigDecimal(SampleConstants.SNUMBERING_INCREMENTVALUE);

		BigDecimal value = currentValue.add(incrementValue);

		if (endValue.compareTo(value) < 0) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OVERSLIPNO);
			if (error != null) {
				throw new GValidateException(error);
			}
		}
		record.setObject(SampleConstants.SNUMBERING_CURRENTVALUE, value);

		update(SampleConstants.SNUMBERING).set(record).wherePK().execute();

		DecimalFormat df = new DecimalFormat(SLIPNO_FORMAT);
		String slipNO = constValue + df.format(value);

		return slipNO;

	}

	/**
	 * 明細番号に１からの連番を設定します。<br>
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param slipNO 明細番号
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void numberingDetailNo(String companyCD, String slipNO) throws SQLException {

		List<GRecord> detailList = select(SampleConstants.ORDERDETAIL, "od")
										.leftOuterJoinFK(SampleConstants.ORDERDETAIL_ITEMMASTER_REFERENCEKEY, "im")
										.where(exp($("od." + SampleConstants.ORDERDETAIL_SLIPNO + " = ?").AND($("od." + SampleConstants.COMPANYCD + " = ?")), slipNO, companyCD))
										.orderBy(asc("od." + SampleConstants.ORDERDETAIL_DETAILNO))
										.findList();

		int i = 0;
		for (GRecord record : detailList) {
			record.setObject(SampleConstants.ORDERDETAIL_DETAILNO, ++i);
			update(SampleConstants.ORDERDETAIL).set(record).whereUK(SampleConstants.ORDERDETAIL_DETAILID_KEY).execute();
		}
	}

	/**
	 * 明細行データが更新対象かを判定します。<br>
	 * 更新対象行ならtrueを、 そうでなければfalseを返します。
	 *
	 * @create 2020/6/23
	 * @param actionid アクションID
	 * @param rowData 明細行データ
	 * @return boolean 更新対象行ならtrue、更新対象行でなければfalse
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private boolean isUpdateRow(String actionid, GRowData rowData) {
		if (rowData.getBoolean(OrderDetailView.ID_CHECK_FG)) {
			if (OrderDetailView.ID_DELETEROW_H.equals(actionid)) {
				if (rowData.getBoolean(OrderDetailView.ID_ADDROW_FG)) {
					return false;
				}
			}
			return true;
		}
		return false;
	}
}