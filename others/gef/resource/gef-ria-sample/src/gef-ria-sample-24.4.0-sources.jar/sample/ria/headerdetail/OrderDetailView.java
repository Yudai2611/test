/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.headerdetail;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.jsp.PageContext;

import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPCheckBox;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPHidden;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPLinkedImg;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPText;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GListRow;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPList;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPListRow;
import jp.co.kccs.greenearth.framework.view.component.GView;
import sample.ria.common.SampleConstants;
import sample.ria.common.utils.SampleUtils;

/**
 * 発注明細画面のビュークラスです。
 *
 * @create 2020/6/23
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author miwa
 * @since 20.6.0.0b
 */
public class OrderDetailView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/**
	 * {@link OrderDetailView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public OrderDetailView() {
	}

	/** 新規登録（一覧画面からの遷移） */
	public static final String ID_ENTRY = "Entry";

	/** 一覧の伝票番号クリック時. */
	public static final String ID_EDIT = "SlipNO";

	// ボタン
	/** 登録ボタン(上部) */
	public static final String ID_ENTRY_H = "EntryH";
	/** 登録ボタン(下部) */

	/** 更新ボタン(上部) */
	public static final String ID_UPDATE_H = "UpdateH";
	/** 更新ボタン(下部) */

	/** 行追加ボタン(上部) */
	public static final String ID_ADDROW_H = "AddRowH";
	/** 行追加ボタン(下部) */

	/** 明細削除ボタン(上部) */
	public static final String ID_DELETEROW_H = "DeleteRowH";
	/** 明細削除ボタン(下部) */

	/** 伝票削除ボタン(上部) */
	public static final String ID_DELETE_H = "DeleteH";
	/** 伝票削除ボタン(下部) */

	// ヘッダ
	/** 行追加サイズ */
	public static final String ID_ADDROWSIZE = "AddRowSize";

	// 明細
	/** 発注明細情報のID. */
	public static final String ORDERDETAIL_LIST = "OrderDetailList";

	/** 選択チェックボックスの状態 */
	public static final String ID_CHECK_FG = "CheckFG";

	/** 新規の明細かを確認するフラグ */
	public static final String ID_ADDROW_FG = "AddRowFG";

	/** ズームイメージ */
	public static final String ID_ITEMLISTZOOM = "ItemListZoomImg";

	/** 伝票合計金額 */
	public static final String ID_ALLAT = "AllAT";

	/**
	 * 発注明細画面の画面表示設定を行います。<br>
	 * 画面の遷移元を判断して、
	 * 新規登録画面の表示、更新画面の表示、行追加のいずれかを行います。<br>
	 *
	 * @create 2020/6/23
	 * @param resultData 結果セット
	 * @param parameter 画面パラメータ
	 * @param pageContext ページコンテキスト
	 * @throws Exception 読み込みに失敗した場合
	 * @see jp.co.kccs.greenearth.framework.view.component.GView#onLoad(GResultData, GParameter)
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		super.onLoad(resultData, parameter, pageContext);
		String actionid = parameter.getValue(GActionServlet.ACTION_ID);

		if (ID_ENTRY.equals(actionid) || actionid.endsWith(ID_EDIT)) {
			if (ID_ENTRY.equals(actionid)) {
				reset();
				addEmptyDetailRow(5, false, true);
			}
			buttonControl(resultData, actionid);
		} else if (ID_ADDROW_H.equals(actionid)) {
			List<GValidateError> errors = new ArrayList<GValidateError>();
			errors = resultData.getErrors();

			if (errors.size() == 0) {
				String addRowSize = parameter.getValue(ID_ADDROWSIZE);
				addEmptyDetailRow(Integer.parseInt(addRowSize), true, false);
			}
		} else if (ID_DELETEROW_H.equals(actionid)) {
			List<GValidateError> errors = new ArrayList<GValidateError>();
			errors = resultData.getErrors();

			if (errors.size() == 0) {
				GPList detailListView = (GPList) findControl(ORDERDETAIL_LIST);
				//チェックが入った行を削除します。
				for (int i = 0; i < detailListView.getRowSize(); i++ ) {
					GPListRow row = detailListView.getRow(i);
					GPCheckBox check = (GPCheckBox) row.findElement(ID_CHECK_FG);
					if (check.isChecked()) {
						detailListView.removeRow(i);
						i--;
					}
				}
			}
		}
		setControl();
	}

	/**
	 * 発注明細画面の入力より、検証処理を行います。<br>
	 * 以下の検証を行います。
	 * ①行追加時に行数が200行を超えていないか。
	 * ②選択チェックボックスがチェックされている行に、入力エラーがないか。
	 * ③明細削除ボタン押下時に、明細行が０行になっていないか。
	 * ④明細削除ボタン押下時に、選択チェックボックスがチェックされているか。
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @return エラーリスト
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public List<GValidateError> onValidate(GParameter parameter) {
		GValidateError error = null;
		List<GValidateError> errors = new ArrayList<GValidateError>();

		GPList detailList = (GPList) findControl(ORDERDETAIL_LIST);
		String actionid = parameter.getValue(GActionServlet.ACTION_ID);
		String label = GMessageResources.getMessage("SELECT", GFrameworkContext.getInstance().getLocale());

		// 行追加の際、行数が200を超えた場合エラー
		if (ID_ADDROW_H.equals(actionid) ) {
			int addRowSize = Integer.parseInt(parameter.getValue(ID_ADDROWSIZE));
			GListData detailListData = GEXActionUtils.extractListData(parameter, ORDERDETAIL_LIST);
			int listSize = detailListData.size();
			if (addRowSize + listSize > 200) {
				error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OVERADDROW);
				error.setLabel(label);
				errors.add(error);
			}
		}

		if (ID_ENTRY_H.equals(actionid)  || ID_UPDATE_H.equals(actionid)) {

			SampleUtils.validate(errors, findControl(SampleConstants.ORDERHEADER_CORPORATENA_KANA), parameter);
			SampleUtils.validate(errors, findControl(SampleConstants.ORDERHEADER_CORPORATE_NA), parameter);

			// 選択チェックボックスがチェックされている明細のみ、明細の基本チェックを行います
			for (GListRow row : detailList.getRows()) {
				GPCheckBox check = (GPCheckBox) row.findElement(ID_CHECK_FG);
				if (check.isChecked()) {
					List<GValidateError> e = row.validate(parameter);
					if (e != null && !e.isEmpty()) {
						errors.addAll(e);
					}
				}
			}
		}

		// 明細削除時
		if (ID_DELETEROW_H.equals(actionid)) {
			// 明細が0行の時
			if (detailList.getRows().size() == 0) {
				error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_NOLIST);
				error.setLabel(label);
				errors.add(error);
			} else {
				boolean updateFgChecked = false;
				for (GListRow row : detailList.getRows()) {
					GPCheckBox check = (GPCheckBox) row.findElement(ID_CHECK_FG);
					if (check.isChecked()) {
						updateFgChecked = true;
					}
				}
				// 選択チェックボックスがチェックされていない場合、エラー
				if (!updateFgChecked) {
					error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_NOCHECK);
					error.setLabel(label);
					errors.add(error);
				}
			}
		}
		return errors;
	}

	/**
	 * 指定された行数の空行を作成します。<br>
	 *
	 * @create 2020/6/23
	 * @param number 作成する行数
	 * @param checkFG 選択チェックボックスの選択状態
	 * @param clearFG リストのクリアを行うかのフラグ
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void addEmptyDetailRow(int number, boolean checkFG, boolean clearFG) {
		GPList detailListView = (GPList) findControl(ORDERDETAIL_LIST);
		if (clearFG) {
			detailListView.clear();
		}
		for (int i = 0; i < number; i++) {
			GListRow row = detailListView.createRow();
			((GPCheckBox) row.findElement(ID_CHECK_FG)).setChecked(checkFG);
			detailListView.addRow(row);
		}
	}

	/**
	 * 画面遷移によって表示するボタンを切り替えます。<br>
	 * 新規登録画面では、更新ボタン、明細削除ボタン、伝票削除ボタンを非表示にします。<br>
	 * 更新画面では、登録ボタンを非表示にします。<br>
	 *
	 * @create 2020/6/23
	 * @param resultData 結果セット
	 * @param actionid アクションID
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void buttonControl(GResultData resultData, String actionid) {
		if (ID_ENTRY.equals(actionid)) {
			findControl(ID_ENTRY_H).setVisible(true);
			findControl(ID_UPDATE_H).setVisible(false);
			findControl(ID_DELETEROW_H).setVisible(false);
			findControl(ID_DELETE_H).setVisible(false);
		} else {
			findControl(ID_ENTRY_H).setVisible(false);
			findControl(ID_UPDATE_H).setVisible(true);
			findControl(ID_DELETEROW_H).setVisible(true);
			findControl(ID_DELETE_H).setVisible(true);
		}
	}

	/**
	 * 各コントロールを設定します。<br>
	 * 新規の明細行の場合、ズームを有効にします。<br>
	 * 既に登録されている明細行の場合、ズームを非表示にして、商品コードを読み取り専用にします。<br>
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private void setControl() {
		GPList detailListView = (GPList) findControl(ORDERDETAIL_LIST);
		detailListView.setStartIndex(0);

//		for (GListRow row : detailListView.getRows()) {
//			if (Boolean.valueOf(((GPHidden)row.findElement(ID_ADDROW_FG)).getValue())) {
//				((GPLinkedImg) row.findElement(ID_ITEMLISTZOOM)).setStyle("");
//			} else {
//				((GPLinkedImg) row.findElement(ID_ITEMLISTZOOM)).setStyle("display: none;");
//				((GPText) row.findElement(SampleConstants.ORDERDETAIL_ITEMCD)).setReadonly(true);
//			}
//		}
		for (GListRow row : detailListView.getRows()) {
			if (Boolean.valueOf(((GPHidden)row.findElement(ID_ADDROW_FG)).getValue())) {
				((GPLinkedImg) row.findElement(ID_ITEMLISTZOOM)).setVisible(true);
			} else {
				((GPLinkedImg) row.findElement(ID_ITEMLISTZOOM)).setVisible(false);
				((GPText) row.findElement(SampleConstants.ORDERDETAIL_ITEMCD)).setReadonly(true);
			}
		}
	}
}