/*
 * Copyright 2020-2021 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.headerdetail;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GPagingNavigator;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.data.GSearchMode;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import sample.ria.common.SampleConstants;

/**
 * 発注情報一覧画面のアクションクラスです。
 *
 * @since 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class OrderListAction {

	/**
	 * {@link OrderListAction}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public OrderListAction() {
	}

	/**
	 * パラメータのmode値から、検索モードに転換し、<br>
	 * 共通の doSearch(GParameter parameter, GResultData resultData, GSearchMode searchMode)を呼び出す<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param resultData {@link GResultData}オブジェクト
	 * @return {@link GResultData}オブジェクト
	 * @throws SQLException SQL例外
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData doSearch(GParameter parameter, GResultData resultData) throws SQLException {
		GSearchMode searchMode =  GSearchMode.create(parameter.getValue(GActionServlet.ACTION_MODE_KEY));
		return doSearch(parameter,resultData,searchMode);
	}

	/**
	 * パラメータのdestpage値から、検索モードに転換し、<br>
	 * 共通の doSearch(GParameter parameter, GResultData resultData, GSearchMode searchMode)を呼び出す<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws SQLException SQL例外
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData doPaginationSearch(GParameter parameter, GResultData resultData) throws SQLException {
		GSearchMode searchMode = GSearchMode.create(parameter.getValue(GPagingNavigator.DESTPAGE));
		return doSearch(parameter,resultData,searchMode);
	}

	/**
	 * 検索モードにより、一覧画面で入力された、「伝票番号」と「取引先名称」の前方一致で検索を行います。<br>
	 *
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @param searchMode 検索モード
	 * @return 結果セット
	 * @throws SQLException
	 * @create 2021/09/30
	 * @author KCSS
	 * @since 21.9.0
	 */
	public GResultData doSearch(GParameter parameter, GResultData resultData, GSearchMode searchMode) throws SQLException {

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("CompanyCD", GEXActionUtils.getLoginCompany().getCode());
		paramMap.put("SlipNO_0", GStringUtils.blankToNull(parameter.getValue("SlipNO_0")));
		paramMap.put("CorporateNA_1", GStringUtils.blankToNull(parameter.getValue("CorporateNA_1")));

		GEntitySelect select = select(SampleConstants.ORDERHEADER)
				.where(expMap($(SampleConstants.COMPANYCD + " = :CompanyCD")
						.AND($(SampleConstants.ORDERHEADER_SLIPNO + " LIKE :[" + "SlipNO_0%" + "]"))
						.AND($(SampleConstants.ORDERHEADER_CORPORATE_NA + " LIKE :[" + "CorporateNA_1%" + "]")), paramMap))
				.orderBy(asc(SampleConstants.ORDERHEADER_SLIPNO));

		GListData orderListData = GGjdbcActionUtils.findList(select, OrderListView.ORDER_LIST, parameter, searchMode);
		resultData.setData(OrderListView.ORDER_LIST, orderListData);

		return resultData;
	}
	/**
	 * 伝票番号のリンク押下時のアクションです。<br>
	 * 押下した伝票の情報を、結果セットにセットします。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData doEdit(GParameter parameter, GResultData resultData) throws SQLException {

		String companyCD = GEXActionUtils.getLoginCompany().getCode();
		String slipNO = GEXActionUtils.extractCellData(parameter);

		// 発注ヘッダ、明細の情報を取得
		GRecord headerRecord = findOrderHeader(companyCD, slipNO);
		GListData detailList = findOrderDetailList(companyCD, slipNO);
		resultData.setData(OrderDetailView.ID_ALLAT, getSlipAT(detailList));

		// 取得した発注ヘッダ、明細の情報を、結果セットにセットします
		GGjdbcActionUtils.copyValue(resultData, headerRecord);
		resultData.setData(OrderDetailView.ORDERDETAIL_LIST, detailList);

		return resultData;
	}

	/**
	 * 新規登録ボタン押下時のアクションです。<br>
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData {@link GResultData}オブジェクト
	 * @return {@link GResultData}オブジェクト
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GResultData doEntry(GParameter parameter, GResultData resultData) {
		return resultData;
	}

	/**
	 * 発注ヘッダ情報を取得します。<br>
	 * 会社コードと、指定した伝票番号で検索を行い、発注ヘッダ情報を取得します。<br>
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param slipNO 伝票番号
	 * @return {@link GDBRecord}オブジェクト
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private GRecord findOrderHeader(String companyCD, String slipNO) throws SQLException {
		GRecord headerRecord = select(SampleConstants.ORDERHEADER)
				.whereUK(SampleConstants.ORDERHEADER_SLIPNO_KEY, companyCD, slipNO)
				.findRecord();
		return headerRecord;
	}

	/**
	 * 発注明細情報を取得します。<br>
	 * 会社コードと、指定した伝票番号で検索を行い、発注明細情報を取得します。<br>
	 *
	 * @create 2020/6/23
	 * @param companyCD 会社コード
	 * @param slipNO 伝票番号
	 * @return {@link GListData}オブジェクト
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private GListData findOrderDetailList(String companyCD, String slipNO) throws SQLException {

		List<GRecord> detailList = select(SampleConstants.ORDERDETAIL, "od")
				.leftOuterJoinFK(SampleConstants.ORDERDETAIL_ITEMMASTER_REFERENCEKEY, "im")
				.where(exp("od." + SampleConstants.COMPANYCD + " = ? AND " + "od." + SampleConstants.ORDERDETAIL_SLIPNO + " = ?", companyCD, slipNO))
				.orderBy(asc("od." + SampleConstants.ORDERDETAIL_DETAILNO))
				.findList();

		GListData detailListData = GGjdbcActionUtils.createListData(detailList);

		int i = 0;
		for (GRowData rowData : detailListData) {
			rowData.setData(OrderDetailView.ID_ADDROW_FG, false);
			detailListData.set(i, rowData);
			i++;
		}

		return detailListData;
	}

	/**
	 * 伝票の発注合計金額を計算します。<br>
	 * 各明細行の発注金額の合計を計算して計算結果を返します。<br>
	 *
	 * @create 2020/6/23
	 * @param listData 発注明細リスト
	 * @return slipAT 発注合計金額
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	private long getSlipAT(GListData listData) {
		long slipAT = 0;

		for (GRowData rowData : listData) {
			slipAT += Long.parseLong(rowData.getString(SampleConstants.ORDERDETAIL_ORDERAT));
		}
		return slipAT;
	}
}