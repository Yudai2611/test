/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.headerdetail;

import jp.co.kccs.greenearth.framework.view.component.GView;

/**
 * 発注情報一覧画面のビュークラスです。
 *
 * @since 2020/6/23
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author miwa
 * @since 20.6.0.0b
 */
public class OrderListView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/**
	 * {@link OrderListView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @auther miwa
	 * @since 20.6.0.0b
	 */
	public OrderListView() {
	}

	/** 発注情報リストのID. */
	public static final String ORDER_LIST = "OrderList";

}