/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.menu;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import jp.co.kccs.greenearth.commons.GApplicationException;
import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.data.GRowData;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.menu.GMenuFinder;
import jp.co.kccs.greenearth.framework.session.GSession;
import jp.co.kccs.greenearth.framework.view.menu.GMenuStarter;
import jp.co.kccs.greenearth.framework.view.menu.GMenuStarterFactory;

/**
 * メニュー画面遷移機能を提供するアクションクラスです.
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class MenuAction {

	/** メニュー情報格納用マップの保存用セッションキー. */
	public static final String SESSION_KEY_MENU_MAP = "jp.co.kccs.greenearth.framework.menu.MENU_MAP";

	/**
	 * {@link MenuAction}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public MenuAction() {
	}

	/**
	 * メニューに表示する情報を取得するアクションメソッドです.
	 *
	 * @create 2020/6/23
	 * @param parameter パラメータ
	 * @param resultData 結果セット
	 * @throws Throwable 予期せぬ例外
	 * @return メニューに表示する内容
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public GResultData launchMenu(GParameter parameter, GResultData resultData) throws Throwable {
		GWebContext context = GWebContext.getInstance();
		HttpServletRequest request = context.getRequest();
		HttpServletResponse response = context.getResponse();

		GSession gsession = context.getSession();
		GUser user = gsession.getLoginUser();

		// 移動先のメニューID取得
		String menuID = parameter.getValue("menuid");

		// 現在のメニュー階層表示を作成
		if ("".equals(menuID)) {
			// メニュー情報を作成
			return getChildMenuInfo(null, parameter, resultData);
		} else {
			// カレントアイテム情報取得
			GMenuFinder menuManager = GMenuFinder.Factory.getInstance();
			GMenu menu = menuManager.getMenu(user.getCompany().getCode(), menuID);

			// 該当メニューが存在するかどうかをチェック
			if (menu == null || ! (GStatus.Active == menu.getStatus())){
				Locale locale = GFrameworkContext.getInstance().getLocale();
				GErrorMessage message = GErrorMessages.getErrorMessage("GEF-001001", locale);
				throw new GApplicationException(message);
			}

			// メニュー移動チェック
			if (!menu.isItem()) {
				// メニュー移動
				return getChildMenuInfo(menu, parameter, resultData);
			} else {
				// セッションのメニュー情報に、アプリケーションが所属するメニューIDを保存
				HttpSession session = request.getSession();
				Map<String, GMenu> menuMap = (Map<String, GMenu>) session.getAttribute(SESSION_KEY_MENU_MAP);
				if (menuMap == null) {
					menuMap = new HashMap<String, GMenu>();
					session.setAttribute(SESSION_KEY_MENU_MAP, menuMap);
				}
				menuMap.put(menuID, menu);
				GMenuStarter launcher = GMenuStarterFactory.getMenuExecuter(menu);
				return launcher.start(menu, resultData, request, response);
			}
		}
	}

	/**
	 * メニューに表示する情報を取得します。<br>
	 * ・処理一覧<br>
	 * [1]セッションに対する操作<br>
	 * 　[1-1]カレントプログラムの表示名の消去(キー：{@value #SESSION_KEY_MENUNAME})<br>
	 * 　[1-2]カレントメニューIDの保存(キー：{@value #SESSION_KEY_MENU_ID})<br>
	 * 　[1-3]親メニューIDの保存(キー：{@value #SESSION_KEY_PARENT_MENU_ID})<br>
	 * [2]結果データに対する操作<br>
	 * 　[2-1]カレントメニューオブジェクトの保存(キー：{@value MenuView#ELEMENT_ID_PARENT_MENU_LINK})<br>
	 * 　[2-2]子メニュー一覧の保存(キー：{@value MenuView#ELEMENT_ID_PARENT_MENU_LINK})<br>
	 *
	 * @create 2020/6/23
	 * @param parentMenu 親メニュー
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return 子メニュー一覧情報
	 * @throws GResourceProcessingException リソース処理中の例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected GResultData getChildMenuInfo(GMenu parentMenu, GParameter parameter, GResultData resultData) throws GResourceProcessingException {
		GWebContext context = GWebContext.getInstance();
		HttpSession httpSession = context.getRequest().getSession();

		// カレントメニューの設定
		Map<String, GMenu> menumap = (Map<String, GMenu>) httpSession.getAttribute(SESSION_KEY_MENU_MAP);
		if (menumap == null) {
			menumap = new HashMap<String, GMenu>();
			httpSession.setAttribute(SESSION_KEY_MENU_MAP, menumap);
		}
		if (parentMenu != null) {
			menumap.put(parentMenu.getMenuID(), parentMenu);
		}

		resultData.setData(MenuView.ELEMENT_ID_PARENT_MENU_LINK, parentMenu);

		// 子メニュー取得
		GMenuFinder manager = GMenuFinder.Factory.getInstance();
		List<GMenu> list = null;
		if (parentMenu == null) {
			list = manager.getRootMenuList(GEXActionUtils.getLoginCompany().getCode());
		}
		else {
			list = parentMenu.getChildren();
		}

		// 子メニューの設定
		GListData listData = new GListData();
		for (GMenu item : list) {
			GRowData rowData = new GRowData();
			rowData.setData(MenuView.ELEMENT_ID_SUB_MENU_LINK, item);
			listData.add(rowData);
		}
		resultData.setData(MenuView.ELEMENT_ID_MENU_LIST, listData);

		return resultData;
	}
}
