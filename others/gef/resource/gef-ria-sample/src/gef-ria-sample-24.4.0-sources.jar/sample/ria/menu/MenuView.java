/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.menu;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jakarta.servlet.jsp.PageContext;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.GWebContext;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.menu.GMenu;
//import jp.co.kccs.greenearth.framework.richview.rich.ui.control.GRMenuLinkedLabel;
import jp.co.kccs.greenearth.framework.richview.ui.GUIComponentBase;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPImg;
import jp.co.kccs.greenearth.framework.richview.ui.control.GPMenuLinkedLabel;
import jp.co.kccs.greenearth.framework.richview.ui.control.list.GPList;
import jp.co.kccs.greenearth.framework.richview.ui.event.GActionEvent;
import jp.co.kccs.greenearth.framework.richview.ui.event.GEvent;
import jp.co.kccs.greenearth.framework.view.component.GView;

/**
 * メニュー画面用のビュークラスです。
 *
 * @create 2020/6/23
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author miwa
 * @since 20.6.0.0b
 */
public class MenuView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/** メニューView内で子のメニュー情報{@link GJk2MenuItem}一覧を格納するリスト要素のID. */
	public static final String ELEMENT_ID_MENU_LIST = "MenuList";
	/** カレントメニューアイテムのアイコンイメージの要素ID. */
	public static final String ELEMENT_ID_PARENT_MENU_IMAGE = "ParentMenuImage";
	/** メニューView内で親のメニュー情報{@link GJk2MenuItem}をレンダリングする要素のID. */
	public static final String ELEMENT_ID_PARENT_MENU_LINK = "ParentMenuLink";
	/** 子メニューアイテムのアイコンイメージの要素ID. */
	public static final String ELEMENT_ID_SUB_MENU_IMAGE = "SubMenuImage";
	/** メニューView内で子のメニュー情報{@link GJk2MenuItem}をレンダリングする要素のID. */
	public static final String ELEMENT_ID_SUB_MENU_LINK = "SubMenuLink";

	/** EMv3用メニューアイコンのファイルパス. */
	protected Map<String, String> _iconMap = null;
	private static final String MENU_ICON_BASE_DIR = "/public/images/menu";

	/**
	 * {@link MenuView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public MenuView() {

		//TODO EM アイコンを見直す
		_iconMap = new HashMap<String, String>();
		_iconMap.put(null, MENU_ICON_BASE_DIR + "/menu.gif");
		_iconMap.put("Category",MENU_ICON_BASE_DIR + "/submenu.gif");
		_iconMap.put("Entry",MENU_ICON_BASE_DIR + "/entry.gif");
		_iconMap.put("Batch",MENU_ICON_BASE_DIR + "/batch.gif");
		_iconMap.put("Report",MENU_ICON_BASE_DIR + "/query.gif");
		_iconMap.put("List",MENU_ICON_BASE_DIR + "/list.gif");
		_iconMap.put("Other",MENU_ICON_BASE_DIR + "/other.gif");
	}

	/**
	 * メニュー画面の表示情報を設定します。
	 *
	 * @create 2020/6/23
	 * @param resultData 結果セット
	 * @param parameter パラメータ
	 * @param pageContext ページコンテキスト
	 * @throws Exception 読み込みに失敗した場合
	 * @see jp.co.kccs.greenearth.framework.view.component.GView#onLoad(GResultData, GParameter)
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@Override
	public void onLoad(GResultData resultData, GParameter parameter, PageContext pageContext) throws Exception {
		super.onLoad(resultData, parameter, pageContext);

		// 親メニュー表示
		onLoadParentMenuItem(resultData);

		// 子メニュー一覧表示
		onLoadChildMenuItems(resultData);
	}

	/**
	 * 子メニューのUIに属性を設定します。
	 *
	 * @create 2020/6/23
	 * @param resultData アクションの結果情報
	 * @throws GResourceProcessingException ロール取得に失敗
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected void onLoadChildMenuItems(GResultData resultData) throws GResourceProcessingException {
		GListData listData = resultData.getListData(ELEMENT_ID_MENU_LIST);

		// 子アイテムのアイコン設定
		GPList list = (GPList) findControl(ELEMENT_ID_MENU_LIST);

		for (int i = 0; i < listData.size(); i++) {
			GPImg childImg = (GPImg) list.getRow(i).findElement(ELEMENT_ID_SUB_MENU_IMAGE);
			GMenu menu = (GMenu) listData.get(i).getData(ELEMENT_ID_SUB_MENU_LINK);

			setMenuIcon(childImg, menu);

			GPMenuLinkedLabel menuLinkedLabel = (GPMenuLinkedLabel) list.getRow(i).findElement(ELEMENT_ID_SUB_MENU_LINK);
			String menuApplicationType = menu.getApplicationType();
			// 権限のない(ロール)メニューは表示しない
			// クライアント専用アプリケーションの場合以外は表示する
			GUser user = GWebContext.getInstance().getSession().getLoginUser();
			boolean hasAuthority = menu.hasAuthority(user);
			if (!hasAuthority || (menuApplicationType != null) && ("SmartClientItem".equals(menuApplicationType)) || (menuApplicationType != null) &&("SmartClientCategory".equals(menuApplicationType))) {
				((GUIComponentBase) list.getRow(i)).setVisible(false);
				menuLinkedLabel.setVisible(false);
				continue;
			}

			// TODO 設定からとるべき
			// 処理中メッセージの設定
			if ("JK2WebItem".equals(menuApplicationType)
					|| "ClickOnceItem".equals(menuApplicationType)
					|| "ExternalItem".equals(menuApplicationType)) {
				// Web用リッチクライアント　又は、
				// Web・デスクトップ共用リッチクライアント
				// リッチクライアントは処理中メッセージ非表示
				List<GEvent> events = menuLinkedLabel.getEvents();
				if (events != null) {
					for (GEvent event : events) {
						if (!(event instanceof GActionEvent)) {
							continue;
						}
						GActionEvent actionevent = (GActionEvent)event;
						actionevent.setIndicator(null);
						if ("ClickOnceItem".equals(menuApplicationType)) {
							actionevent.addActionParam("affectState", false);
						}
					}
				}
			}
		}
	}

	/**
	 * 親メニューのUIに属性を設定します。
	 *
	 * @create 2020/6/23
	 * @param resultData アクションの結果情報
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected void onLoadParentMenuItem(GResultData resultData) {

		// 階層表示部のアイコン設定・
		// アイコン表示
		GMenu parentMenu = (GMenu) resultData.getData(ELEMENT_ID_PARENT_MENU_LINK);

		GPImg parentImg = (GPImg) findControl(ELEMENT_ID_PARENT_MENU_IMAGE);
		GPMenuLinkedLabel parentLink = (GPMenuLinkedLabel) findControl(ELEMENT_ID_PARENT_MENU_LINK);

		setMenuIcon(parentImg, parentMenu);

		if (parentMenu == null) {
			// ルート階層の場合
			parentLink.setValue(((GPMenuLinkedLabel) parentLink.getRepository()).getValue());
			parentLink.setEnabled(false);
		}  else {
			// ハイパーリンクを親階層へのリンクにする為にMenuIDを親MenuIDに差し替え
			Locale locale = GWebContext.getInstance().getLocale();
			parentLink.setValue(parentMenu.getDisplayName(locale));
			String menuID = parentMenu.getParent() != null ? parentMenu.getParent().getMenuID() : null;
			parentLink.setMenu(GStringUtils.nullToBlank(menuID));
		}
	}

	/**
	 * メニューアイテムに該当するイメージを設定します。
	 *
	 * @create 2020/6/23
	 * @param childImg {@link GPImg}
	 * @param menu メニュー情報
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	protected void setMenuIcon(GPImg childImg, GMenu menu) {
		String contextPath = GWebContext.getInstance().getRequest().getContextPath();
		// アイコンの設定
		if (menu == null) {
			childImg.setSrc(contextPath + _iconMap.get(null));
		}else if(!menu.isItem()){
			childImg.setSrc(contextPath + _iconMap.get("Category"));
		} else{
			String menuIcon = GStringUtils.isEmpty(menu.getMenuType()) ? null : menu.getMenuType();
			if(_iconMap.containsKey(menuIcon)){
				childImg.setSrc(contextPath+_iconMap.get(menuIcon));
			}else{
				childImg.setSrc(contextPath+ _iconMap.get("Other"));
			}
		}
	}
}
