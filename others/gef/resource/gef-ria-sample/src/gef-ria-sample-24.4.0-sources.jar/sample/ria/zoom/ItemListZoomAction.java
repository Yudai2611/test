/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.zoom;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import sample.ria.common.SampleConstants;

/**
 * 単位マスタズームのアクションクラスです。
 *
 * @create 2020/6/23
 * @author miwa
 * @since 20.6.0.0b
 */
public class ItemListZoomAction {

	/**
	 * {@link ItemListZoomAction}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public ItemListZoomAction() {
	}

	/**
	 * 商品マスタの検索時のアクションです。
	 *
	 * @create 2020/6/23
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws SQLException SQL例外
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData doSearch(GParameter parameter, GResultData resultData) throws SQLException {

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("CompanyCD", GEXActionUtils.getLoginCompany().getCode());
		paramMap.put("ItemCD_0", GStringUtils.blankToNull(parameter.getValue("ItemCD_0")));
		GEntitySelect select = select(SampleConstants.ITEMMASTER)
									.where(expMap($(SampleConstants.COMPANYCD + " = :CompanyCD")
											.AND($(SampleConstants.ITEMMASTER_ITEMCD + " LIKE :[" + "ItemCD_0%" + "]")), paramMap))
									.orderBy(asc(SampleConstants.ITEMMASTER_ITEMCD));
		GListData listData = GGjdbcActionUtils.findListData(select, ItemListZoomView.ID_ZOOMLIST, parameter);
		resultData.setData(ItemListZoomView.ID_ZOOMLIST, listData);

		GEXActionUtils.copyValue(resultData, parameter);

		resultData.setExitCode(GResultData.EXIT_CODE_SUCCESS);
		return resultData;
	}
}
