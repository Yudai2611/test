/*
 * Copyright 2020 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.ria.zoom;

import jp.co.kccs.greenearth.framework.view.component.GView;

/**
 * 商品マスタズーム画面のビュークラスです。
 *
 * @create 2020/6/23
 * @see jp.co.kccs.greenearth.framework.view.component.GView
 * @author miwa
 * @since 20.6.0.0b
 */
public class ItemListZoomView extends GView {

	/** シリアルバージョンID */
	private static final long serialVersionUID = 1L;

	/** 商品ズームリスト */
	public static final String ID_ZOOMLIST = "ZoomItemList";

	/**
	 * {@link ItemListZoomView}インスタンスを初期化します。
	 *
	 * @create 2020/6/23
	 * @author miwa
	 * @since 20.6.0.0b
	 */
	public ItemListZoomView() {
	}
}
