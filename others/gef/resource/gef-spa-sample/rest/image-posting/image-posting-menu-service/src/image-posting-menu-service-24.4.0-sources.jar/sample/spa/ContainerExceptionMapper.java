/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import jp.co.kccs.greenearth.framework.web.GContainerException;

/**
 * {@link GContainerException}が発生する時にハンドルする.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Provider
public class ContainerExceptionMapper implements ExceptionMapper<GContainerException> {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see ExceptionMapper#toResponse(Throwable)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Response toResponse(GContainerException exception) {
        return Response.status(200).entity("test").build();
    }
}
