/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Form;
import jakarta.ws.rs.core.MediaType;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GFrameworkMessages;
import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.auth.GCompanyImpl;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.auth.GUserImpl;
import jp.co.kccs.greenearth.framework.web.security.auth.GAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubjectImpl;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import sample.spa.utils.KeycloakConstant;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * JWTの認証をハンドルする.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class JwtAuthenticationProcessor implements GAuthenticationProcessor {

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see GAuthenticationProcessor#process(HttpServletRequest, HttpServletResponse)
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Optional<GSubject> process(HttpServletRequest request, HttpServletResponse response) {
		GSubject subject = new GSubjectImpl();
		String token = getToken(request);
		Map<String, Object> result = checkIfTokenIsValid(token);
		boolean status = (Boolean) Objects.requireNonNullElse(result.get("active"), false);
		if (status) {
			GUser user = new GUserImpl();
			GCompany company = new GCompanyImpl();
			company.setCode(((String) result.get("company_cd")));
			user.setCompany(company);
			user.setName((String) result.get("preferred_username"));
			subject.setPrincipal(user);
		}
		subject.setAuthenticated(status);
		GSecurityContextHolder.getContext().setSubject(subject);
		return Optional.of(subject);
	}

	protected String getToken(HttpServletRequest request) {
		String authorizationHeader = request
			.getHeader("Authorization");
		if (authorizationHeader == null) {
			return "";
		}
		String token = authorizationHeader.replace("Bearer ", "");
		if (token
			.isEmpty()) {
			throw new NotAuthorizedException(GFrameworkMessages.authenticationFailedDueTo("token is invalid"));
		}
		return token;
	}
	protected Map<String, Object> checkIfTokenIsValid(String token) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(GFrameworkUtils.getProperty("sample.spa.keycloak.host"))
			.path(KeycloakConstant.INTROSPECT_TOKEN_URI);

		Entity<Form> entity = Entity.entity(
			new Form()
				.param("token", token)
				.param("client_id", GFrameworkUtils.getProperty("sample.spa.keycloak.clientId"))
				.param("client_secret", GFrameworkUtils.getProperty("sample.spa.keycloak.clientSecret")),
			MediaType.APPLICATION_FORM_URLENCODED_TYPE);
		return target.request().post(entity, Map.class);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @create 2024/04/30
	 * @see GAuthenticationProcessor#authenticate(HttpServletRequest, HttpServletResponse) 
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Override
	public Optional<GSubject> authenticate(HttpServletRequest request, HttpServletResponse response) {
		return Optional.empty();
	}
}