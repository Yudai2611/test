/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import java.util.List;
import java.util.stream.Collectors;

import jakarta.annotation.Resource;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import sample.spa.usecase.MenuUsecase;

/**
 * メニューリソースのリソースクラスです.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
@Path("/menus")
public class MenuResource {
    private final MenuUsecase menuUsecase;

    public MenuResource() {
        this.menuUsecase = MenuUsecase.getInstance();
    }

	/**
	 * メニュー一覧を取得する為のエンドポイントです.<br>
	 *
	 * @create 2024/04/30
	 * @return Response
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
    @GET
    public Response getMenus() {
        GUser user = GSecurityContextHolder.getContext().getSubject().get().getPrincipal();
        List<MenuResponse> menus = convertToMenuDTO(menuUsecase.getMenus(user));
        return Response.ok(menus).build();
    }
    private List<MenuResponse> convertToMenuDTO(List<GMenu> menus) {
		return menus.stream()
			.filter(menu ->
				menu.getApplicationType().equals("SPASampleRest") && menu.getStatus() == GStatus.Active
			)
			.map(menu-> {
				MenuResponse menuDTO = new MenuResponse();
				menuDTO.setMenuId(menu.getMenuID());
				menuDTO.setMenuLabel(menu.getDisplayName(GFrameworkUtils.getDefaultLocale()));
				menuDTO.setMenuPageUri(menu.getStartModule());
				menuDTO.setMenuChildren(convertToMenuDTO(menu.getChildren()));
				return menuDTO;
			}).collect(Collectors.toList());
	}
}
