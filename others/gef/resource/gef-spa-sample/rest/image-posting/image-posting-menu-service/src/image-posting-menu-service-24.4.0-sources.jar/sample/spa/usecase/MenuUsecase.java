/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.usecase;


import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.menu.GMenu;

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface MenuUsecase {

    /**
     * 渡されたユーザによる、メニュー一覧を取得する為のメソッドです.<br>
     *
     * @create 2024/04/30
     * @param user ユーザ
     * @return メニュー一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    List<GMenu> getMenus(GUser user);


    /**
     * DIから{@link MenuUsecase}の実装を取得します.<br>
     *
     * @create 2024/04/30
     * @return {@link MenuUsecase}のインスタンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    static MenuUsecase getInstance() {
        return GFrameworkUtils.getComponent(MenuUsecase.class);
    }
}
