/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.usecase;

import java.util.List;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.menu.GMenuFinder;

/**
 * {@inheritDoc}.
 *
 * @create 2024/04/30
 * @see MenuUsecase
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class MenuUsecaseImpl implements MenuUsecase {

	/**
	 * {@inheritDoc}.
	 *
	 * @create 2024/04/30
	 * @see MenuUsecase#getMenus(GUser) 
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
    @Override
    public List<GMenu> getMenus(GUser user) {
        GMenuFinder menuFinder = GFrameworkUtils.getComponent(GMenuFinder.class);
		String companyCD = user.getCompany().getCode();
		return menuFinder.getRootMenuList(companyCD);
    }
}
