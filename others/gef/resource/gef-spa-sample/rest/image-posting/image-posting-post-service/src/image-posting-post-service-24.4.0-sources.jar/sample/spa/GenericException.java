/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jp.co.kccs.greenearth.framework.data.GSystemError;

/**
 * {@link Throwable}は発生する場合、このクラスをハンドルします.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GenericException implements ExceptionMapper<Throwable> {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see ExceptionMapper#toResponse(Throwable)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Response toResponse(Throwable exception) {
        if (exception instanceof WebApplicationException) {
            WebApplicationException ex = (WebApplicationException) exception;
            return Response.fromResponse(ex.getResponse()).entity(GSystemError.create(exception)).build();
        }
        return Response.status(500).entity(GSystemError.create(exception)).build();
    }

}
