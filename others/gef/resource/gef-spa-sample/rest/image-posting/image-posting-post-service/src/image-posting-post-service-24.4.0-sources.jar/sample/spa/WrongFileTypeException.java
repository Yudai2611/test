/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa;

/**
 * アップロードされたファイルタイプは不一致の場合、この例外を投げます. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class WrongFileTypeException extends RuntimeException {
    
}
