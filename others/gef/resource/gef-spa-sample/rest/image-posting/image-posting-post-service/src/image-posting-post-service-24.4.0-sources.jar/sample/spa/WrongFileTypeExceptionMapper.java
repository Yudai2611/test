/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jp.co.kccs.greenearth.framework.data.GValidateError;

/**
 * {@link WrongFileTypeException}が発生する場合、このクラスがハンドルします.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class WrongFileTypeExceptionMapper implements ExceptionMapper<WrongFileTypeException> {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see ExceptionMapper#toResponse(Throwable)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Response toResponse(WrongFileTypeException exception) {
        return Response.status(400).entity(new GValidateError("Uploaded file type is wrong")).build();
    }

}
