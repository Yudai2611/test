/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.config;

import java.util.Map;

import jp.co.kccs.greenearth.commons.configuration.bootstrap.BootstrapConfigurator;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfiguration;
import jp.co.kccs.greenearth.commons.configuration.bootstrap.GBootstrapConfigurator;
import jp.co.kccs.greenearth.commons.listener.GBootstrapInitializable;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessageBootstrapInitializableAdapter;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResourceBootstrapInitializableAdapter;

/**
 * ブットストラップの初期状態を設定する為のクラスです.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@BootstrapConfigurator
public class BootstrapConfiguration implements GBootstrapConfigurator {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see GBootstrapConfigurator#configure(Map)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void configure(Map<Class<? extends GBootstrapInitializable>, GBootstrapConfiguration> config) {
        config.put(GErrorMessageBootstrapInitializableAdapter.class, GBootstrapConfiguration.builder().bootOn(false).build());
        config.put(GMessageResourceBootstrapInitializableAdapter.class, GBootstrapConfiguration.builder().bootOn(false).build());
    }

}
