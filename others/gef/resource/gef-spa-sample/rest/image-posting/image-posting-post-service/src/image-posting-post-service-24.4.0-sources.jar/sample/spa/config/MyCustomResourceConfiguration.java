/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.config;

import jp.co.kccs.greenearth.framework.web.configuration.GAbstractResourceConfigurator;
import jp.co.kccs.greenearth.framework.web.configuration.GFeatureContext;
import jp.co.kccs.greenearth.framework.web.resource.annotation.ResourceConfig;
import sample.spa.GenericException;
import sample.spa.WrongFileTypeExceptionMapper;

/**
 * Injectionマネージャーにコンポネントを登録するためのクラスです.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@ResourceConfig
public class MyCustomResourceConfiguration extends GAbstractResourceConfigurator {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see GAbstractResourceConfigurator#configure(GFeatureContext)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void configure(GFeatureContext context) {
        context.register(GenericException.class);
        context.register(WrongFileTypeExceptionMapper.class);
    }

}
