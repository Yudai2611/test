/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.config;

import org.glassfish.jersey.server.ResourceConfig;

/**
 * デフォルト{@link ResourceConfig}クラスです.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class MyResource extends ResourceConfig {
}
