/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.OneToOne;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.Comment;


/**
 * DBのオブジェクトクラスです.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Entity(keyType = Entity.KeyType.PRIMARY)
public class CommentData {
    private String commentId;
    private String postId;
    private String text;
    private UserData createdBy;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public CommentData(Comment comment) {
        this.commentId = comment.getCommentId();
        this.postId = comment.getPostId();
        this.text = comment.getText();
        this.createdBy = new UserData(comment.getCreatedBy());
        this.createdAt = Timestamp.valueOf(LocalDateTime.ofInstant(comment.getCreatedAt(), ZoneOffset.systemDefault()));
        this.updatedAt = Timestamp.valueOf(LocalDateTime.ofInstant(comment.getUpdatedAt(), ZoneOffset.systemDefault()));
    }

    /**
     * コメントIDを取得します. <br>
     *
     * @create 2024/04/30
     * @return コメントID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "CommentId")
    public String getCommentId() {
        return commentId;
    }

    /**
     * ポストIDを取得します. <br>
     *
     * @create 2024/04/30
     * @return ポストID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "PostId")
    public String getPostId() {
        return postId;
    }


    /**
     * コメントを取得します. <br>
     *
     * @create 2024/04/30
     * @return コメント
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "CommentText")
    public String getText() {
        return text;
    }


    /**
     * 作成者を取得します. <br>
     *
     * @create 2024/04/30
     * @return 作成者
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @OneToOne(foreignKey = "FkCommentCreatedBy", joinType = GJoinData.JoinType.INNER_JOIN, mappedAlias = "user")
    public UserData getCreatedBy() {
        return createdBy;
    }


    /**
     * 作成日付を取得します. <br>
     *
     * @create 2024/04/30
     * @return 作成日付
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "CreatedAt")
    public Timestamp getCreatedAt() {
        return createdAt;
    }


    /**
     * 更新日付を取得します. <br>
     *
     * @create 2024/04/30
     * @return 更新日付
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "UpdatedAt")
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    /**
     * {@link CommentData}から{@link Comment}に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link Comment}
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public Comment toComment() {
        return new Comment(
            commentId, 
            postId,
            text, 
            createdBy.toUser(),
            createdAt.toInstant(),
            updatedAt.toInstant());
    }

    /**
     * {@link CommentData}のリストから{@link Comment}のリストに変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link Comment}のリスト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static List<Comment> toComments(List<CommentData> comments) {
        return comments.stream().map(CommentData::toComment).toList();
    }
}
