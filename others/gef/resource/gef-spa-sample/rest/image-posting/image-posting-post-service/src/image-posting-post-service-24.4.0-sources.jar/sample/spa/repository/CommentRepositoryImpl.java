/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.$;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.delete;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.exp;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.orm.GORMapper;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import sample.spa.usecase.core.Comment;
import sample.spa.usecase.repository.CommentRepository;
import sample.spa.usecase.repository.UserRepository;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see CommentRepository
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class CommentRepositoryImpl implements CommentRepository {
    private static final UserRepository USER_REPOSITORY = new UserRepositoryImpl();

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CommentRepository#getComments(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public List<Comment> getComments(String postId) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GEntitySelect select = GQueryAssistants.select("Comment")
                .where(exp($("#PostId = ?"), postId))
                .innerJoinFK("FkCommentCreatedBy", "user");
        try {
            select = mapper.buildFields(select, CommentData.class);
            List<GRecord> records = select.findList();
            List<CommentData> comments = mapper.mapMultiple(select, CommentData.class, records);
            List<Comment> commentList = CommentData.toComments(comments);
            commentList.forEach(comment -> {
                USER_REPOSITORY.getUserById(comment.getCreatedBy().getUserId()).ifPresent(comment::setCreatedBy);
            });
            return commentList;
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CommentRepository#getCommentById(String, String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Comment> getCommentById(String postId, String commentId) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GEntitySelect select = GQueryAssistants
                .select("Comment")
                .where(exp($("#PostId = ?").AND("#CommentId = ?"), postId, commentId))
                .innerJoinFK("FkCommentCreatedBy", "user");
        try {
            select = mapper.buildFields(select, CommentData.class);
            List<GRecord> records = select.findList();
            List<CommentData> comments = mapper.mapMultiple(select, CommentData.class, records);
            if (comments.isEmpty()) {
                return Optional.empty();
            }
            return Optional.of(comments.get(0).toComment());
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CommentRepository#addComment(Comment)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Comment> addComment(Comment comment) {
        GORMapper mapper = GORMapper.Factory.getInstance();

        GRecord record = mapper.mapDTOSingle(new CommentData(comment));
        record.setObject("CreatedBy", comment.getCreatedBy().getUserId());
        try {
            GQueryAssistants.insert("Comment").values(record)
            		 .execute();
            return Optional.of(comment);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CommentRepository#updateComment(Comment)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Comment> updateComment(Comment comment) {
        GORMapper mapper = GORMapper.Factory.getInstance();

        Optional<Comment> oldPost = getCommentById(comment.getPostId(), comment.getCommentId());
        if (oldPost.isPresent()) {
            comment.setCreatedAt(oldPost.get().getCreatedAt());
            comment.setCreatedBy(oldPost.get().getCreatedBy());
        }
        GRecord record = mapper.mapDTOSingle(new CommentData(comment));
        try {
            GQueryAssistants.update("Comment").set(record)
            		 .execute();
            return Optional.of(comment);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CommentRepository#deleteCommentById(String, String) 
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void deleteCommentById(String postId, String commentId) {
        try {
            delete("Comment").where(exp($("#CommentId = ?").AND($("#PostId = ?")), commentId, postId)).execute();
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }
}
