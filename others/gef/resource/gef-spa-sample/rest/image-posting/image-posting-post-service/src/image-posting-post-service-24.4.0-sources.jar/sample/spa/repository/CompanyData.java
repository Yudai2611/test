/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;

import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.Company;

import java.util.List;

/**
 * DBの会社オブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Entity(keyType = Entity.KeyType.PRIMARY)
public class CompanyData {
    private String companyCode;
    private String companyName;

    /**
     * 会社コードを取得します. <br>
     *
     * @create 2024/04/30
     * @return 会社コード
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "CompanyCD")
    public String getCompanyCode() {
        return companyCode;
    }

    /**
     * 会社名を取得します. <br>
     *
     * @create 2024/04/30
     * @return 会社名
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "Name")
    public String getCompanyName() {
        return companyName;
    }

    /**
     * {@link Company}から{@link CompanyData}に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link Company}
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public Company toCompany() {
        return new Company(companyCode, companyName);
    }

    /**
     * {@link Company}一覧から{@link CompanyData}一覧に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link Company}一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static List<Company> toCompanies(List<CompanyData> companyData) {
        return companyData.stream().map(CompanyData::toCompany).toList();
    }
}
