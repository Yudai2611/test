/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;

import jp.co.kccs.greenearth.commons.exception.GResourceProcessingException;
import jp.co.kccs.greenearth.framework.auth.GCompany;
import jp.co.kccs.greenearth.framework.auth.GCompanyDao;
import jp.co.kccs.greenearth.framework.auth.GCompanyDaoImpl;
import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.orm.GORMapper;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import sample.spa.usecase.core.Company;
import sample.spa.usecase.repository.CompanyRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see CompanyRepository
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class CompanyRepositoryImpl implements CompanyRepository {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CompanyRepository#getCompanies()
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public List<Company> getCompanies() {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GEntitySelect select = GQueryAssistants.select("CompanyMaster");
        try {
            select = mapper.buildFields(select, CompanyData.class);
            List<GRecord> records = select.findList();
            List<CompanyData> companies = mapper.mapMultiple(select, CompanyData.class, records);
            return CompanyData.toCompanies(companies);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CompanyRepository#getCompanyByCode(String) 
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Company> getCompanyByCode(String code) {
        GCompanyDao companyDao = new GCompanyDaoImpl();
        try {
            GCompany company = companyDao.findCompany(code);
            return Optional.of(new Company(company.getCode(), company.getName()));
        } catch (GResourceProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
