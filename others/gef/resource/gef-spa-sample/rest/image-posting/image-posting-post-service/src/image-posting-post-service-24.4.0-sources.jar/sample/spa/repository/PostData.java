/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;

import java.io.InputStream;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;

import jp.co.kccs.greenearth.framework.jdbc.entity.GJoinData;
import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.OneToOne;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.Post;


/**
 * DBのポストオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Entity(keyType = Entity.KeyType.PRIMARY)
public class PostData {
    private String postId;
    private String postDetail;
    private UserData createdBy;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private InputStream postFile;

    public PostData(Post post) {
        this.postId = post.getPostId();
        this.postDetail = post.getPostDetail();
        this.createdBy = new UserData(post.getCreatedBy());
        if (Objects.nonNull(post.getCreatedAt())) {
            this.createdAt = Timestamp.valueOf(LocalDateTime.ofInstant(post.getCreatedAt(), ZoneOffset.systemDefault()));
        }
        this.updatedAt = Timestamp.valueOf(LocalDateTime.ofInstant(post.getUpdatedAt(), ZoneOffset.systemDefault()));
        this.postFile = post.getPostFile();
    }


    /**
     * ポストIDを取得します. <br>
     *
     * @create 2024/04/30
     * @return ポストID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "PostId")
    public String getPostId() {
        return postId;
    }

    /**
     * ポスト詳細を取得します. <br>
     *
     * @create 2024/04/30
     * @return ポスト詳細
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "PostDetail")
    public String getPostDetail() {
        return postDetail;
    }

    /**
     * 作成者を取得します. <br>
     *
     * @create 2024/04/30
     * @return 作成者
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @OneToOne(foreignKey = "FkPostCreatedBy", joinType = GJoinData.JoinType.INNER_JOIN, mappedAlias = "user")
    public UserData getCreatedBy() {
        return createdBy;
    }

    /**
     * 作成日付を取得します. <br>
     *
     * @create 2024/04/30
     * @return 作成日付
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "CreatedAt")
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    /**
     * 更新日付を取得します. <br>
     *
     * @create 2024/04/30
     * @return 更新日付
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "UpdatedAt")
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    /**
     * ポストファイルのストリームを取得します. <br>
     *
     * @create 2024/04/30
     * @return ポストファイルのストリーム
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "PostFile")
    public InputStream getPostFile() {
        return postFile;
    }

    /**
     * {@link PostData}から{@link Post}に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link Post}
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public Post toPost() {
        return new Post(
            postId,
            postDetail,
            createdBy.toUser(),
            createdAt.toInstant(),
            updatedAt.toInstant(),
            postFile
        );
    }

    /**
     * {@link PostData}一覧から{@link Post}一覧に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link Post}一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static List<Post> toPosts(List<PostData> postDatas) {
        return postDatas.stream().map(PostData::toPost).toList();
    }
}
