/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.$;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.delete;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.exp;
import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.select;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.data.GRangeImpl;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.commons.data.GRangeResultImpl;
import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.orm.GORMapper;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import sample.spa.usecase.core.Post;
import sample.spa.usecase.repository.PostRepository;
import sample.spa.usecase.repository.UserRepository;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see PostRepository
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class PostRepositoryImpl implements PostRepository {
    private static final UserRepository USER_REPOSITORY = new UserRepositoryImpl();

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostRepository#getPosts(String, int, int)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public GRangeResult<Post> getPosts(String keyword, int startIndex, int size) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        keyword = "%" + keyword + "%";
        GEntitySelect select = GQueryAssistants.select("Post").where(
                exp($("#PostDetail LIKE ?"), keyword
                )).innerJoinFK("FkPostCreatedBy", "user").range(startIndex, startIndex + size);
        select = mapper.buildFields(select, PostData.class);
        try {
            List<GRecord> records = select.findList();
            GEntitySelect selectCount = GQueryAssistants.select("Post")
                .where(
                exp($("#PostDetail LIKE ?"), keyword
            ));

            List<PostData> posts = mapper.mapMultiple(select, PostData.class, records);
            List<Post> postList = PostData.toPosts(posts);

            postList.forEach((post -> {
                USER_REPOSITORY.getUserById(post.getCreatedBy().getUserId()).ifPresent(post::setCreatedBy);
            }));
            return new GRangeResultImpl<>(postList, new GRangeImpl(startIndex, startIndex + postList.size()), selectCount.count());
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostRepository#getPostById(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Post> getPostById(String postId) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GEntitySelect select = select("Post")
                .where(exp($("#PostId = ?"), postId))
                .innerJoinFK("FkPostCreatedBy", "user");
        select = mapper.buildFields(select, PostData.class);
        try {
            List<GRecord> records = select.findList();
            List<PostData> posts = mapper.mapMultiple(select, PostData.class, records);
            if (posts.isEmpty()) {
                return Optional.empty();
            }
            Post post = PostData.toPosts(posts).get(0);
            return Optional.of(post);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostRepository#savePost(Post)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Post> savePost(Post post) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GRecord record = mapper.mapSingle(
                GQueryAssistants.entity("Post"), new PostData(post));

        record.setObject("CreatedBy", post.getCreatedBy().getUserId());
        try {
            GQueryAssistants.insert("Post").values(record)
            		 .execute();
            return Optional.of(post);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostRepository#updatePost(Post)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Post> updatePost(Post post) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        Optional<Post> oldPost = getPostById(post.getPostId());
        if (oldPost.isPresent()) {
            post.setCreatedAt(oldPost.get().getCreatedAt());
            post.setCreatedBy(oldPost.get().getCreatedBy());
        }
        GRecord record = mapper.mapSingle(
                GQueryAssistants.entity("Post"), new PostData(post));
        record.setObject("CreatedBy", post.getCreatedBy().getUserId());
        try {
            GQueryAssistants.update("Post").set(record)
                    .where(exp($("#PostId = ?"), post.getPostId()))
            		 .execute();
            return Optional.of(post);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostRepository#deletePostById(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void deletePostById(String postId) {
        try {
            delete("Post").where(exp($("#PostId=?"), postId)).execute();
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }
}
