/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;


import java.util.List;

import jp.co.kccs.greenearth.framework.jdbc.orm.Column;
import jp.co.kccs.greenearth.framework.jdbc.orm.entity.Entity;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.User;

/**
 * DBのユーザオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Entity(keyType = Entity.KeyType.PRIMARY)
public class UserData {
    private String userId;
    private String username;
    private String firstName;
    private String lastName;
    private String role;
    private int companyCode;

    public UserData(User user) {
        this.userId = user.getUserId();
        this.username = user.getUsername();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.role = user.getRole();
        this.companyCode = user.getCompanyCode();
    }

    /**
     * ユーザIDを取得します. <br>
     *
     * @create 2024/04/30
     * @return ユーザID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "UserId")
    public String getUserId() {
        return userId;
    }


    /**
     * ユーザネームを取得します. <br>
     *
     * @create 2024/04/30
     * @return ユーザネーム
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "Username")
    public String getUsername() {
        return username;
    }

    /**
     * ファーストネームを取得します. <br>
     *
     * @create 2024/04/30
     * @return ファーストネーム
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "FirstName")
    public String getFirstName() {
        return firstName;
    }

    /**
     * ラストネームを取得します. <br>
     *
     * @create 2024/04/30
     * @return ラストネーム
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "LastName")
    public String getLastName() {
        return lastName;
    }

    /**
     * ロールを取得します. <br>
     *
     * @create 2024/04/30
     * @return ロール
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "Role")
    public String getRole() {
        return role;
    }

    /**
     * ユーザIDを設定します. <br>
     *
     * @create 2024/04/30
     * @param userId ユーザID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * ユーザネームを設定します. <br>
     *
     * @create 2024/04/30
     * @param username ユーザネーム
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * ファーストネームを設定します. <br>
     *
     * @create 2024/04/30
     * @param firstName ファーストネーム
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * ラストネームを設定します. <br>
     *
     * @create 2024/04/30
     * @param lastName ラストネーム
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * ロールを設定します. <br>
     *
     * @create 2024/04/30
     * @param role ロール
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * 会社コードを取得します. <br>
     *
     * @create 2024/04/30
     * @return 会社コード
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Column(name = "CompanyCode")
    public int getCompanyCode() {
        return companyCode;
    }

    /**
     * 会社コードを設定します. <br>
     *
     * @create 2024/04/30
     * @param companyCode 会社コード
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setCompanyCode(int companyCode) {
        this.companyCode = companyCode;
    }

    /**
     * {@link UserData}から{@link User}に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link User}
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public User toUser() {
        return new User(
            userId,
            username,
            firstName,
            lastName,
            role,
            companyCode
        );
    }

    /**
     * {@link UserData}一覧から{@link User}一覧に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link User}一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static List<User> toUsers(List<UserData> userDatas) {
        return userDatas.stream().map(UserData::toUser).toList();
    }
}
