/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.data.GRangeImpl;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.commons.data.GRangeResultImpl;
import jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.jdbc.orm.GORMapper;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import sample.spa.usecase.core.User;
import sample.spa.usecase.repository.UserRepository;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;


/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see UserRepository
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class UserRepositoryImpl implements UserRepository {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserRepository#getUserById(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> getUserById(String userId) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GEntitySelect select = select("UserProfile");
        try {
            List<GRecord> records = select.where(exp($("#UserId = ?"), userId)).findList();
            List<UserData> users = mapper.mapMultiple(select, UserData.class, records);
            if (users.isEmpty()) {
                return Optional.empty();
            }
            return Optional.of(UserData.toUsers(users).get(0));
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserRepository#addUser(User)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> addUser(User user) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GRecord record = mapper.mapDTOSingle(new UserData(user));
        try {
            GQueryAssistants.insert("UserProfile").values(record)
            		 .execute();
            return Optional.of(user);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserRepository#updateUser(User)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> updateUser(User user) {
        GORMapper mapper = GORMapper.Factory.getInstance();

        GRecord record = mapper.mapDTOSingle(new UserData(user));
        try {
            GQueryAssistants.update("UserProfile").set(record)
            		 .execute();
            return Optional.of(user);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserRepository#deleteUserById(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> deleteUserById(String userId) {
        try {
            delete("UserProfile").where(exp($("#UserId=?"), userId)).execute();
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
        return Optional.empty();
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserRepository#getUsers(String, int, int)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public GRangeResult<User> getUsers(String keyword, int startIndex, int size) {
        GORMapper mapper = GORMapper.Factory.getInstance();
        GEntitySelect select = select("UserProfile");
        try {
            List<UserData> users = mapper.mapMultiple(select, UserData.class, select.findList());
            List<User> userList = UserData.toUsers(users);
            return new GRangeResultImpl<>(userList, new GRangeImpl(startIndex, startIndex + userList.size()), 100);
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserRepository#getUserByUsername(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> getUserByUsername(String username) {
        try {
            GORMapper mapper = GORMapper.Factory.getInstance();
            GEntitySelect entitySelect = select("UserProfile");
            List<GRecord> records = entitySelect.where(exp($("#Username = ?"), username)).findList();
            List<UserData> users = mapper.mapMultiple(entitySelect, UserData.class, records);
            if (users.isEmpty()) {
                return Optional.empty();
            }
            return Optional.of(UserData.toUsers(users).get(0));
        } catch (SQLException e) {
            throw new GContainerException(e);
        }
    }
}
