/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.Comment;
import sample.spa.usecase.core.User;

/**
 * コメントエンドポイントのリクエストオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CommentRequest {
    private String commentId;
    private String postId;
    private String text;
    private User createdBy;

    /**
     * {@link CommentRequest}から{@link Comment}に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link Comment}
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public Comment toComment() {    
        if (Objects.isNull(commentId)) {
            return new Comment(postId, text, createdBy);
        } 
        return new Comment(commentId, postId, text);
    }
}
