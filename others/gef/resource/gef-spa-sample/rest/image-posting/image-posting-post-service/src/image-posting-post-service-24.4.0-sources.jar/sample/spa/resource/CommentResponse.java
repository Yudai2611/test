/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.Comment;
import sample.spa.usecase.core.User;
import sample.spa.utils.DayUtils;

/**
 * コメントエンドポイントのレスポンスオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CommentResponse {
    private String commentId;
    private String postId;
    private String text;
    private User createdBy;
    private String updatedAt;
    private boolean isMine;

    public CommentResponse(Comment comment, User loggedInUser) {
        this.commentId = comment.getCommentId();
        this.postId = comment.getPostId();
        this.text = comment.getText();
        this.createdBy = comment.getCreatedBy();
        this.updatedAt = DayUtils.compareDateToNow(comment.getUpdatedAt());
        this.isMine = loggedInUser.getUsername().equals(createdBy.getUsername());
    }

    /**
     * {@link Comment}一覧から{@link CommentResponse}一覧に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link CommentResponse}一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static List<CommentResponse> toCommentResponses(List<Comment> comments, User loggedInUser) {
        return comments.stream().map(comment -> new CommentResponse(comment, loggedInUser)).toList();
    }
}
