/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import jakarta.annotation.Resource;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import sample.spa.usecase.CompanyUsecase;
import sample.spa.usecase.core.Company;

import java.util.List;
import java.util.Optional;

/**
 * 会社リソースです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
@Path("companies")
public class CompanyResource {
    private final CompanyUsecase companyUsecase;
    public CompanyResource() {
        companyUsecase = CompanyUsecase.getInstance();
    }

    /**
     * 会社一覧を取得するエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @GET
    public Response getCompanies() {
        List<Company> companyList = companyUsecase.getCompanies();
        if (companyList.isEmpty()) {
            return Response.status(404).build();
        }
        return Response.status(200).entity(companyList).build();
    }

    /**
     * 会社コードで会社情報を取得します. <br>
     *
     * @create 2024/04/30
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @GET
    @Path("{companyCode}")
    public Response getCompanyByCode(String companyCode) {
        Optional<Company> companyOptional = companyUsecase.getCompanyByCode(companyCode);
        if (companyOptional.isEmpty()) {
            return Response.status(404).build();
        }
        return Response.status(200).entity(companyOptional.get()).build();
    }

}
