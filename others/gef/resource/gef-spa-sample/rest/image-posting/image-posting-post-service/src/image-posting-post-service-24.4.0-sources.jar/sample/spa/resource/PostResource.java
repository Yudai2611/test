/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import jakarta.annotation.Resource;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GDownloadFile;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import sample.spa.WrongFileTypeException;
import sample.spa.usecase.CommentUsecase;
import sample.spa.usecase.PostUsecase;
import sample.spa.usecase.UserUsecase;
import sample.spa.usecase.core.Comment;
import sample.spa.usecase.core.Post;
import sample.spa.usecase.core.User;

/**
 * ポストリソースです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
@Path("posts")
public class PostResource {
    private final PostUsecase postUsecase;
    private final CommentUsecase commentUsecase;
    private final UserUsecase userUsecase;

    public PostResource() {
        postUsecase = PostUsecase.getInstance();
        commentUsecase = CommentUsecase.getInstance();
        userUsecase = UserUsecase.getInstance();
    }

    /**
     * ポスト一覧を取得する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param keyword 検索キーワード
     * @param startIndex ページネーションのスタートインデックス
     * @param size サイズ
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @GET
    @RolesAllowed("USER")
    @TimeLogging
    public Response getPosts(
        @QueryParam("keyword") String keyword,
        @QueryParam("startIndex") int startIndex,
        @QueryParam("size") int size
    ) {
        GRangeResult<Post> posts = postUsecase.getPosts(keyword, startIndex, size);
        if (posts.getResult().isEmpty()) {
            return Response.noContent().build();
        }
        return Response.ok(PostResponse.from(posts, getLoggedInUser())).build();
    }

    /**
     * ポストを追加する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param parameter フォームデータのペイロード
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @POST
    @Consumes(GMediaType.MULTIPART_FORM_DATA)
    @TimeLogging
    public Response addPost(GParameter parameter) throws IOException {
        if (!parameter.getFile("postFile").getContentType().startsWith("image")) {
            throw new WrongFileTypeException();
        }
        Optional<Post> post = postUsecase.savePost(new Post(
            parameter.getValue("postDetail"),
            parameter.getFile("postFile").getInputStream(),
            getLoggedInUser()
        ));
        if (post.isPresent()) {
            return Response.ok(new PostResponse(post.get(), getLoggedInUser())).build();
        }
        return Response.status(500).build();
    }

    /**
     * 画像をダウンロードする為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @GET
    @RolesAllowed("USER")
    @Path("{postId}/download-picture")
    @TimeLogging
    @Produces(GMediaType.APPLICATION_OCTET_STREAM)
    public Response downloadPicture(@PathParam("postId") String postId) {
        Optional<Post> post = postUsecase.getPostById(postId);
        if (post.isPresent()) {
            InputStream postFile = post.get().getPostFile();
            GDownloadFile downloadFile = new GDownloadFile(postFile);
            downloadFile.setContentType("image/png");
            downloadFile.setName(postFile + ".png");
            downloadFile.setDeleteFlag(true);
            return Response.ok(downloadFile).build();
        }
        return Response.status(404).build();
    }

    /**
     * ポストを削除する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @DELETE
    @RolesAllowed("USER")
    @Path("{postId}")
    @TimeLogging
    public Response deletePost(@PathParam("postId") String postId) {
        try {
            postUsecase.deletePostById(postId);
            return Response.ok("Delete is success!").build();
        } catch (NotFoundException exception) {
            return Response.status(404).build();
        }
    }

    /**
     * ポストを更新する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param parameter フォームデータのペイロード
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @PATCH
    @Consumes(GMediaType.MULTIPART_FORM_DATA)
    @RolesAllowed("USER")
    @TimeLogging
    public Response updatePost(GParameter parameter) throws IOException {
        if (!parameter.getFile("postFile").getContentType().startsWith("image")) {
            throw new WrongFileTypeException();
        }
        Optional<Post> post = null;
        post = postUsecase.updatePost(new Post(
            parameter.getValue("postId"),
            parameter.getValue("postDetail"),
            parameter.getFile("postFile").getInputStream()
        ));
        if (post.isPresent()) {
            return Response.ok(new PostResponse(post.get(), getLoggedInUser())).build();
        }
        return Response.status(500).build();
    }

    /**
     * コメントを追加する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param commentRequest コメントのオブジェクト
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @POST
    @RolesAllowed("USER")
    @Consumes(GMediaType.APPLICATION_JSON)
    @Path("comments")
    @TimeLogging
    public Response addComment(CommentRequest commentRequest) {
        commentRequest.setCreatedBy(getLoggedInUser());
        Optional<Comment> comment = commentUsecase.addComment(commentRequest.toComment());
        if (comment.isPresent()) {
            return Response.ok(new CommentResponse(comment.get(), getLoggedInUser())).build();
        }
        return Response.status(500).build();
    }

    /**
     * コメント一覧を取得する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @GET
    @RolesAllowed("USER")
    @Path("{postId}/comments")
    @TimeLogging
    public Response getComments(@PathParam("postId") String postId) {
        List<Comment> comments = commentUsecase.getComments(postId);
        return Response.ok(CommentResponse.toCommentResponses(comments, getLoggedInUser())).build();
    }

    /**
     * コメントを削除する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @param commentId コメントID
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @DELETE
    @RolesAllowed("USER")
    @Path("{postId}/comments/{commentId}")
    @TimeLogging
    public Response deleteComment(@PathParam("postId") String postId, @PathParam("commentId") String commentId) {
        try {
            commentUsecase.deleteCommentById(postId, commentId);
            return Response.ok("Delete is success!").build();
        } catch (NotFoundException exception) {
            return Response.status(404).build();
        }
    }

    /**
     * ポストIDでポストオブジェクトを取得する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @GET
    @RolesAllowed("USER")
    @Path("{postId}")
    @TimeLogging
    public Response getPostById(@PathParam("postId") String postId) {
        Optional<Post> post = postUsecase.getPostById(postId);
        if (post.isPresent()) {
            return Response.ok(new PostResponse(post.get(), getLoggedInUser())).build();
        }
        return Response.status(404).build();
    }
    
    private User getLoggedInUser() {
        GUser userPrincipal = GSecurityContextHolder.getContext().getSubject().get().getPrincipal();
        Optional<User> user = userUsecase.getUserByUsername(userPrincipal.getName());
        return user.orElse(null);
    }
}
