/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import java.util.List;

import jp.co.kccs.greenearth.commons.data.GRangeResult;
import jp.co.kccs.greenearth.commons.data.GRangeResultImpl;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.Post;
import sample.spa.usecase.core.User;
import sample.spa.utils.DayUtils;

/**
 * ポストエンドポイントのレスポンスオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class PostResponse {
    private String postId;
    private String postDetail;
    private String updatedAt;
    private User createdBy;
    private boolean isMine;

    public PostResponse(Post post, User loggedInUser) {
        this.postId = post.getPostId();
        this.postDetail = post.getPostDetail();
        this.createdBy = post.getCreatedBy();
        this.updatedAt = DayUtils.compareDateToNow(post.getUpdatedAt());
        this.isMine = loggedInUser.getUsername().equals(createdBy.getUsername());
    }

    /**
     * {@link Post}ページネーションオブジェクトから{@link PostResponse}ページネーションオブジェクトに変換します. <br>
     *
     * @create 2024/04/30
     * @param posts ポストのページネーションオブジェクト
     * @param user 投稿するユーザ
     * @return {@link PostResponse}のページネーションオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static GRangeResult<PostResponse> from(GRangeResult<Post> posts, User user) {
        List<PostResponse> postResponses = posts.getResult().stream().map(post->new PostResponse(post, user)).toList();
        GRangeResult<PostResponse> postResponseRange = new GRangeResultImpl<>(postResponses, posts.getRange(), posts.getOverallSize());
        return postResponseRange;
    }
}
