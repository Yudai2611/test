/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;


import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.kccs.greenearth.framework.action.GActionInterceptor;

/**
 * メソッドの事項タイミングを測るする為のインターセプターです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class TimeInterceptor implements GActionInterceptor {
	private static final Log LOGGER = LogFactory.getLog(TimeInterceptor.class);
    private String[] _parameters = null;

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see GActionInterceptor#invoke(MethodInvocation)
     * @author dhiaz chebastian
     * @since 24.4.0
     */

    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        long startTime = System.currentTimeMillis();

        Object result = invocation.proceed();

        long endTime = System.currentTimeMillis();
        long requestTime = endTime - startTime;

        LOGGER.info("Request Time: " + requestTime + " ms");
        return result;
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see GActionInterceptor#getParameters()
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public String[] getParameters() {
        return _parameters;
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see GActionInterceptor#setParameters(String[])
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void setParameters(String[] parameters) {
        this._parameters = parameters;
    }

}
