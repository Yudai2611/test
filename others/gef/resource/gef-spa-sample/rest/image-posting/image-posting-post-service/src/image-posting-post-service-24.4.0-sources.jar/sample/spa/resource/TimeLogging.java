/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.co.kccs.greenearth.framework.action.GActionInterceptor;
import jp.co.kccs.greenearth.framework.action.MethodInterceptor;

/**
 * {@link TimeInterceptor}のアノテーションです. <br>
 *
 * @create 2024/04/30
 * @see GActionInterceptor#setParameters(String[])
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@MethodInterceptor(interceptBy = TimeInterceptor.class)
public @interface TimeLogging {
    String[] params() default {};
}
