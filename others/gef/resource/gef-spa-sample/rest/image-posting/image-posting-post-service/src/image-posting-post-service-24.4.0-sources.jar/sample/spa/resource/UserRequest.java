/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.spa.usecase.core.User;

/**
 * ユーザのリクエストオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UserRequest {
    private String username;
    private String firstName;
    private String lastName;
    private String password;
    private String confirmationPassword;
    private int companyCode;

    /**
     * {@link UserRequest}から{@link User}に変換します. <br>
     *
     * @create 2024/04/30
     * @return {@link User}
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public User toUser() {
        User user = new User(
                username,
                firstName,
                lastName,
                "USER",
                companyCode
        );
        user.setPassword(password);
        return user;
    }
}
