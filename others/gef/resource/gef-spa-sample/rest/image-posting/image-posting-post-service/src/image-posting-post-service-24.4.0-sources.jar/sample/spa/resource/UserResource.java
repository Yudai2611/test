/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.resource;

import java.io.IOException;
import java.util.Optional;

import jakarta.annotation.Resource;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.GValidateError;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import sample.spa.usecase.UserUsecase;
import sample.spa.usecase.core.User;

/**
 * ユーザリソースです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
@Path("users")
public class UserResource {
    private final UserUsecase userUsecase;
    public UserResource() {
        this.userUsecase = UserUsecase.getInstance();
    }

    /**
     * 認証された情報次第、プロファイルを取得する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @GET
    @Path("profile")
    @TimeLogging
    public Response getProfile() {
        Optional<GSubject> subjectOptional = GSecurityContextHolder.getContext().getSubject();
        if (subjectOptional.isPresent()) {
            GUser userPrincipal = subjectOptional.get().getPrincipal();
            Optional<User> user = userUsecase.getUserByUsername(userPrincipal.getName());
            if (user.isPresent()) {
                UserProfileResponse response = new UserProfileResponse(user.get());
                response.setCompanyName(userPrincipal.getCompany().getName());
                return Response.ok(response).build();
            }
            return Response.status(404).build();
        }
        return Response.status(401).build();
    }

    /**
     * ユーザを登録する為のエンドポイントです. <br>
     *
     * @create 2024/04/30
     * @param userRequest ユーザリクエスト
     * @return レスポンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @POST
    @Consumes(GMediaType.APPLICATION_JSON)
    @Path("register")
    @TimeLogging
    public Response registerUser(UserRequest userRequest) throws IOException {
        if (userRequest.getPassword().equals(userRequest.getConfirmationPassword())) {
            Optional<User> userOptional = userUsecase.addUser(userRequest.toUser());
            if (userOptional.isPresent()) {
                return Response.ok(new UserProfileResponse(userOptional.get())).build();
            }
            return Response.status(500).build();
        }
        GValidateError validateError = new GValidateError();
        validateError.addFieldId("Confirmation Password");
        validateError.setMessage("Confirmation password is not match with password.");
        return Response.status(400).entity(validateError).build();
    }
}
