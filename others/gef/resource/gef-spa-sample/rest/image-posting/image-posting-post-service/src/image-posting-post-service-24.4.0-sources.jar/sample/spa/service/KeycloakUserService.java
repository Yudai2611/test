/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.service;

import sample.spa.usecase.core.User;

/**
 * Keycloak情報と合わせるためのサービスです。. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface KeycloakUserService {

    /**
     * ユーザを追加します. <br>
     *
     * @create 2024/04/30
     * @param user ユーザ
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    void addUser(User user);
}
