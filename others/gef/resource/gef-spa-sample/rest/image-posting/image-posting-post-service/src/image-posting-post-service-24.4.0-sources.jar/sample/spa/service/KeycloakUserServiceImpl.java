/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Form;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.web.GContainerException;
import sample.spa.utils.KeycloakConstant;
import sample.spa.usecase.core.User;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see KeycloakUserService
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class KeycloakUserServiceImpl implements KeycloakUserService {

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see KeycloakUserService#addUser(User) 
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void addUser(User user) {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(GFrameworkUtils.getProperty("sample.spa.keycloak.host"))
            .path(KeycloakConstant.USER_MANAGEMENT_URI);
        Map<String, Object> body = new HashMap<>();
        body.put("firstName", user.getFirstName());
        body.put("lastName", user.getLastName());
        body.put("username", user.getUsername());
        body.put("enabled", "true");
        body.put("attributes", Map.of(
                    "company_cd", user.getCompanyCode(),
                    "role", user.getRole()
        ));
        body.put("credentials", List.of(Map.of(
            "type", "password",
            "value", user.getPassword(),
            "temporary", "false"
        )));
        Entity<Map<String, Object>> entity = Entity.entity(body, MediaType.APPLICATION_JSON);
        
        Response response = target.request()
                .header("Authorization", "Bearer " + getAccessToken())
                .header("Content-Type", MediaType.APPLICATION_JSON)
                .post(entity);
        if (response.getStatus() != Response.Status.CREATED.getStatusCode()) {
            throw new GContainerException("Add to keycloak is failed.");
        } 
    }

    private String getAccessToken() {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(GFrameworkUtils.getProperty("sample.spa.keycloak.host"))
                .path(KeycloakConstant.GENERATE_TOKEN_URI);
        Form form = new Form();
        form.param("client_id", GFrameworkUtils.getProperty("sample.spa.keycloak.clientId"));
        form.param("grant_type", "password");
        form.param("username", GFrameworkUtils.getProperty("sample.spa.keycloak.sync.account.username"));
        form.param("password", GFrameworkUtils.getProperty("sample.spa.keycloak.sync.account.password"));
        form.param("client_secret", GFrameworkUtils.getProperty("sample.spa.keycloak.clientSecret"));
        Entity<Form> entity = Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED);

        Response response = target.request()
                .post(entity);
        Object map = response.readEntity(Object.class);
        return (String) ((Map<?, ?>) map).get("access_token");
    }
}
