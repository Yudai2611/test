/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import java.util.List;
import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import sample.spa.usecase.core.Comment;

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface CommentUsecase {

    /**
     * ポストIDで、コメント一覧を取得します. <br>
     *
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return {@link Comment}のリスト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    List<Comment> getComments(String postId);

    /**
     * コメントを追加します. <br>
     *
     *
     * @create 2024/04/30
     * @param comment コメント
     * @return {@link Comment}　追加されたコメント
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Comment> addComment(Comment comment);

    /**
     * コメントを更新します. <br>
     *
     *
     * @create 2024/04/30
     * @param comment コメント
     * @return {@link Comment}更新されたコメント
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Comment> updateComment(Comment comment);

    /**
     * コメントを削除します. <br>
     *
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @param commentId コメントID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    void deleteCommentById(String postId, String commentId);

    /**
     * DIから{@link CommentUsecase}のインスタンスを取得します. <br>
     *
     *
     * @create 2024/04/30
     * @return {@link CommentUsecase}のインスタンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    static CommentUsecase getInstance() {
        return GFrameworkUtils.getComponent(CommentUsecase.class);
    }
}
