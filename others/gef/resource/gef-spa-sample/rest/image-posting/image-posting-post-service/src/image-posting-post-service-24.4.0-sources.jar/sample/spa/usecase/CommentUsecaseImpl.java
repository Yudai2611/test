/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import jakarta.ws.rs.NotFoundException;
import sample.spa.usecase.core.Comment;
import sample.spa.usecase.repository.CommentRepository;

/**
 * {@inheritDoc}
 *
 *
 * @create 2024/04/30
 * @see CommentUsecase
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class CommentUsecaseImpl implements CommentUsecase {
    private final CommentRepository commentRepository;
    public CommentUsecaseImpl(CommentRepository commentRepository) {
        this.commentRepository = commentRepository;
    }

    /**
     * {@inheritDoc}
     *
     *
     * @create 2024/04/30
     * @see CommentUsecase#getComments(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public List<Comment> getComments(String postId) {
        return commentRepository.getComments(postId);
    }

    /**
     * {@inheritDoc}
     *
     *
     * @create 2024/04/30
     * @see CommentUsecase#addComment(Comment)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Comment> addComment(Comment comment) {
        comment.setUpdatedAt(Instant.now());
        comment.setCreatedAt(Instant.now());
        return commentRepository.addComment(comment);
    }

    /**
     * {@inheritDoc}
     *
     *
     * @create 2024/04/30
     * @see CommentUsecase#updateComment(Comment)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Comment> updateComment(Comment comment) {
        comment.setUpdatedAt(Instant.now());
        return commentRepository.updateComment(comment);
    }

    /**
     * {@inheritDoc}
     *
     *
     * @create 2024/04/30
     * @see CommentUsecase#deleteCommentById(String, String) 
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void deleteCommentById(String postId, String commentId) {
        Optional<Comment> commentOptional = commentRepository.getCommentById(postId, commentId);
        if (commentOptional.isEmpty()) {
            throw new NotFoundException();
        }
        commentRepository.deleteCommentById(postId, commentId);
    }
}
