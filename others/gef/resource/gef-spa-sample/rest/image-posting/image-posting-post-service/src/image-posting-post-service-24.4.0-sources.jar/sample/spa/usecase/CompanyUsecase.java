/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import sample.spa.usecase.core.Company;

import java.util.List;
import java.util.Optional;

/**
 *
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface CompanyUsecase {

    /**
     * 会社一覧を取得します. <br>
     *
     * @create 2024/04/30
     * @return {@link Company}のリスト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    List<Company> getCompanies();

    /**
     * 会社コードで会社オブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param code 会社コード
     * @return 会社オブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Company> getCompanyByCode(String code);

    /**
     * DIから、{@link CompanyUsecase}インスタンスを取得します. <br>
     *
     * @create 2024/04/30
     * @return {@link CompanyUsecase}のインスタンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    static CompanyUsecase getInstance() {
        return GFrameworkUtils.getComponent(CompanyUsecase.class);
    }
}
