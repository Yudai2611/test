/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import sample.spa.usecase.core.Company;
import sample.spa.usecase.repository.CompanyRepository;

import java.util.List;
import java.util.Optional;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see CompanyUsecase
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class CompanyUsecaseImpl implements CompanyUsecase {
    private final CompanyRepository companyRepository;

    public CompanyUsecaseImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CompanyUsecase#getCompanies()
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public List<Company> getCompanies() {
        return companyRepository.getCompanies();
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see CompanyUsecase#getCompanyByCode(String) 
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Company> getCompanyByCode(String code) {
        return companyRepository.getCompanyByCode(code);
    }
}
