/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import sample.spa.usecase.core.Post;

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface PostUsecase {

    /**
     * ポストのページネーションオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param keyword 検索キーワード
     * @param startIndex ページネーションのスタートインデックス
     * @param size ページネーションのさいず
     * @return {@link Post}のページネーションオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    GRangeResult<Post> getPosts(String keyword, int startIndex, int size);

    /**
     * ポストIDでポストオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return {@link Post}オブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Post> getPostById(String postId);

    /**
     * ポストオブジェクトを追加します. <br>
     *
     * @create 2024/04/30
     * @param post 追加されたいポストオブジェクト
     * @return 追加されたポストオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Post> savePost(Post post);

    /**
     * ポストを更新します. <br>
     *
     * @create 2024/04/30
     * @param post 更新されたポストオブジェクト
     * @return 更新されたポストオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Post> updatePost(Post post);

    /**
     * ポストを削除します. <br>
     *
     * @create 2024/04/30
     * @param postId 削除したいのポストID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    void deletePostById(String postId);

    /**
     * DIから、{@link PostUsecase}インスタンスを取得します. <br>
     *
     * @create 2024/04/30
     * @return {@link PostUsecase}のインスタンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    static PostUsecase getInstance() {
        return GFrameworkUtils.getComponent(PostUsecase.class);
    }
}
