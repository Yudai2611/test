/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import java.time.Instant;
import java.util.Optional;

import jakarta.ws.rs.NotFoundException;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import sample.spa.usecase.core.Post;
import sample.spa.usecase.repository.PostRepository;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see PostUsecase
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class PostUsecaseImpl implements PostUsecase {
    private final PostRepository postRepository;

    public PostUsecaseImpl(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostUsecase#getPosts(String, int, int)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public GRangeResult<Post> getPosts(String keyword, int startIndex, int size) {
        return postRepository.getPosts(keyword, startIndex, size);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostUsecase#getPostById(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Post> getPostById(String postId) {
        return postRepository.getPostById(postId);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostUsecase#savePost(Post)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Post> savePost(Post post) {
        post.setCreatedAt(Instant.now());
        post.setUpdatedAt(Instant.now());
        return postRepository.savePost(post);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostUsecase#updatePost(Post)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<Post> updatePost(Post post) {
        post.setUpdatedAt(Instant.now());
        return postRepository.updatePost(post);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see PostUsecase#deletePostById(String) 
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void deletePostById(String postId) {
        Optional<Post> post = postRepository.getPostById(postId);
        if (post.isEmpty()) {
            throw new NotFoundException("Post with id: " + postId + " is not found");
        }
        postRepository.deletePostById(postId);
    }

    
}
