/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import sample.spa.usecase.core.User;

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface UserUsecase {

    /**
     * ユーザIDで、ユーザオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param userId 検索されたいのユーザID
     * @return 検索されたのユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> getUserById(String userId);

    /**
     * ユーザネームで、ユーザオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param username ユーザネーム
     * @return 検索されたのユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> getUserByUsername(String username);

    /**
     * ユーザオブジェクトを追加します. <br>
     *
     * @create 2024/04/30
     * @param user 追加されたいユーザオブジェクト
     * @return 追加されたユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> addUser(User user);

    /**
     *　ユーザを更新します. <br>
     *
     * @create 2024/04/30
     * @param user 更新されたユーザオブジェクト
     * @return 更新されたユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> updateUser(User user);

    /**
     * ユーザIDで、ユーザを削除します. <br>
     *
     * @create 2024/04/30
     * @param userId ユーザID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    void deleteUserById(String userId);

    /**
     * ユーザの一覧を取得します. <br>
     *
     * @create 2024/04/30
     * @param keyword 検索キーワード
     * @param startIndex　ページネーションのスタートインデックス
     * @param size ページネーションのサイズ
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    GRangeResult<User> getUsers(String keyword, int startIndex, int size);

    /**
     * DIから、{@link UserUsecase}のインスタンスを取得します. <br>
     *
     * @create 2024/04/30
     * @return {@link UserUsecase}のインスタンス
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    static UserUsecase getInstance() {
        return GFrameworkUtils.getComponent(UserUsecase.class);
    }
}
