/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase;

import java.util.Optional;

import jakarta.ws.rs.NotFoundException;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import sample.spa.service.KeycloakUserService;
import sample.spa.service.KeycloakUserServiceImpl;
import sample.spa.usecase.core.User;
import sample.spa.usecase.repository.UserRepository;

/**
 * {@inheritDoc}
 *
 * @create 2024/04/30
 * @see UserUsecase
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class UserUsecaseImpl implements UserUsecase {
    private final UserRepository userRepository;
    private final KeycloakUserService keycloakUserService;
    public UserUsecaseImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.keycloakUserService = new KeycloakUserServiceImpl();
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserUsecase#getUserById(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> getUserById(String userId) {
        return userRepository.getUserById(userId);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserUsecase#addUser(User)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> addUser(User user) {
        Optional<User> userOptional = userRepository.addUser(user);
        try {
            keycloakUserService.addUser(user);
            return userOptional;
        } catch (Exception exception) {
            deleteUserById(user.getUserId());
            throw exception;
        }
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserUsecase#updateUser(User)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> updateUser(User user) {
        return userRepository.updateUser(user);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserUsecase#deleteUserById(String)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public void deleteUserById(String userId) {
        Optional<User> user = getUserById(userId);
        if (user.isEmpty()) {
            throw new NotFoundException("User with id: " + userId + " is not found");
        }
        userRepository.deleteUserById(userId);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserUsecase#getUsers(String, int, int)
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public GRangeResult<User> getUsers(String keyword, int startIndex, int size) {
        return userRepository.getUsers(keyword, startIndex, size);
    }

    /**
     * {@inheritDoc}
     *
     * @create 2024/04/30
     * @see UserUsecase#getUserByUsername(String) 
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    @Override
    public Optional<User> getUserByUsername(String username) {
        return userRepository.getUserByUsername(username);
    }
}
