/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.usecase.core;

import java.time.Instant;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * コメントオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Comment {
    private String commentId;
    private String postId;
    private String text;
    private User createdBy;
    private Instant createdAt;
    private Instant updatedAt;

    public Comment(String postId, String text, User createdBy) {
        this.commentId = UUID.randomUUID().toString();
        this.postId = postId;
        this.text = text;
        this.createdBy = createdBy;
        this.createdAt = Instant.now();
        this.updatedAt = Instant.now();
    }

    public Comment(String commentId, String postId, String text) {
        this.commentId = commentId;
        this.postId = postId;
        this.text = text;
        this.updatedAt = Instant.now();
    }
}
