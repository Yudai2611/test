/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.usecase.core;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 会社オブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Company {
    private String companyCode;
    private String companyName;
}
