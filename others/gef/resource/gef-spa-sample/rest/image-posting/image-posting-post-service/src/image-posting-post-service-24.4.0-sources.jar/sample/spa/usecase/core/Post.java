/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.usecase.core;

import java.io.InputStream;
import java.time.Instant;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ポストオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Post {
    private String postId;
    private String postDetail;
    private User createdBy;
    private Instant createdAt;
    private Instant updatedAt;
    private InputStream postFile;

    public Post(String postDetail, InputStream postFile, User createdBy) {
        this.postId = UUID.randomUUID().toString();
        this.postDetail = postDetail;
        this.postFile = postFile;
        this.createdBy = createdBy;
        this.updatedAt = Instant.now();
        this.createdAt = Instant.now();
    }
    public Post(String postId, String postDetail, InputStream postFile) {
        this.postId = postId;
        this.postDetail = postDetail;
        this.postFile = postFile;
        this.updatedAt = Instant.now();
    }

}
