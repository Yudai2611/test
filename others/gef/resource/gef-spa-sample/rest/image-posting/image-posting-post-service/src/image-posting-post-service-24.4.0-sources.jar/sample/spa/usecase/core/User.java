/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.usecase.core;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ユーザオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class User {
    private String userId;
    private String username;
    private String firstName;
    private String lastName;
    private String password;
    private int companyCode;
    private String role;


    public User(String username, String firstName, String lastName, String role, int companyCode) {
        this.userId = UUID.randomUUID().toString();
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
        this.companyCode = companyCode;
    }
    public User(String userId, String username, String firstName, String lastName, String role, int companyCode) {
        this.userId = userId;
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
        this.companyCode = companyCode;
    }
}
