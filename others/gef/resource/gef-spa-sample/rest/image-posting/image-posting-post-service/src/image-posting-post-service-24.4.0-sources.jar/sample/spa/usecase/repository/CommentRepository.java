/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.usecase.repository;

import java.util.List;
import java.util.Optional;

import sample.spa.usecase.core.Comment;

/**
 * コメントのレポシトリーです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface CommentRepository {

    /**
     * ポストIDによる、コメント一覧を取得します. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return コメント一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    List<Comment> getComments(String postId);

    /**
     * ポストID、コメントIDによる、コメントオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @param commentId コメントID
     * @return コメントイブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Comment> getCommentById(String postId, String commentId);

    /**
     * コメントを追加します. <br>
     *
     * @create 2024/04/30
     * @param comment コメント
     * @return 追加されたコメントオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Comment> addComment(Comment comment);

    /**
     * コメントを更新します. <br>
     *
     * @create 2024/04/30
     * @param comment コメント
     * @return 更新されたコメント
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Comment> updateComment(Comment comment);

    /**
     * コメントIDで、コメントを削除します. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @param commentId コメントID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    void deleteCommentById(String postId, String commentId);
}
