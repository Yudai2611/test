/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase.repository;

import sample.spa.usecase.core.Company;

import java.util.List;
import java.util.Optional;

/**
 * 会社レポシトリーです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface CompanyRepository {

    /**
     * 会社一覧を取得します. <br>
     *
     * @create 2024/04/30
     * @return {@link Company}のリスト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    List<Company> getCompanies();

    /**
     * 会社コードで会社オブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @return {@link Company}
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Company> getCompanyByCode(String code);
}
