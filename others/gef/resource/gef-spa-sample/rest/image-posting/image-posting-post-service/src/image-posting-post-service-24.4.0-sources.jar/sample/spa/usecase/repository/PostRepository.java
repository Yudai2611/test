/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase.repository;

import java.util.Optional;

import jp.co.kccs.greenearth.commons.data.GRangeResult;
import sample.spa.usecase.core.Post;

/**
 * ポストレポシトリーです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface PostRepository {

    /**
     * ポスト一覧を取得します. <br>
     *
     * @create 2024/04/30
     * @param keyword 検索キーワード
     * @param startIndex ページネーションオブジェクのスタートインデックス
     * @param size ページネーションのサイズ
     * @return ポストのページネーションオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    GRangeResult<Post> getPosts(String keyword, int startIndex, int size);

    /**
     * ポストIDでポストオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @return ポストオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Post> getPostById(String postId);

    /**
     * ポストオブジェクトを追加します. <br>
     *
     * @create 2024/04/30
     * @param post ポストオブジェクト
     * @return 追加されたポストオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Post> savePost(Post post);

    /**
     * ポストオブジェクトを更新します. <br>
     *
     * @create 2024/04/30
     * @param post ポストオブジェクト
     * @return 更新されたポストオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<Post> updatePost(Post post);

    /**
     * ポストオブジェクトを削除します. <br>
     *
     * @create 2024/04/30
     * @param postId ポストID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    void deletePostById(String postId);
}
