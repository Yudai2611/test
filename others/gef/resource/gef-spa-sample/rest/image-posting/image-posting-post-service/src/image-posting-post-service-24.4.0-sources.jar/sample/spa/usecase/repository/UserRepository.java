/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.usecase.repository;

import java.util.Optional;
import jp.co.kccs.greenearth.commons.data.GRangeResult;
import sample.spa.usecase.core.User;

/**
 * ユーザレポシトリーです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public interface UserRepository {

    /**
     * ユーザネームでユーザオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param username ユーザネーム
     * @return ユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> getUserByUsername(String username);

    /**
     * ユーザIDでユーザを取得します. <br>
     *
     * @create 2024/04/30
     * @param userId ユーザID
     * @return ユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> getUserById(String userId);

    /**
     * ユーザオブジェクトを追加します. <br>
     *
     * @create 2024/04/30
     * @param user ユーザ
     * @return 追加されたユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> addUser(User user);

    /**
     * ユーザオブジェクトを更新します. <br>
     *
     * @create 2024/04/30
     * @param user ユーザ
     * @return 更新されたユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> updateUser(User user);

    /**
     * ユーザを削除します. <br>
     *
     * @create 2024/04/30
     * @param userId ユーザID
     * @return 削除されたユーザ
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    Optional<User> deleteUserById(String userId);

    /**
     * ユーザページネーションのオブジェクトを取得します. <br>
     *
     * @create 2024/04/30
     * @param keyword 検索キーワード
     * @param startIndex ページネーションのスタートインデックス
     * @param size ページネーションのサイズ
     * @return 追加されたユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    GRangeResult<User> getUsers(String keyword, int startIndex, int size);
}
