/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.utils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * 日付処理のユーティリティクラスです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class DayUtils {

    /**
     * 渡された日付と現時点の時間を比較します。 <br>
     * 結果としては　<br>
     * [1] 1分以下は"「秒単位」seconds ago"を返します。<br>
     * [2] 1時間以下は"「分単位」minutes ago"を返します。<br>
     * [3] 1日以下は"「時間単位」hours ago"を返します。<br>
     * [4] 1週間以下は"「日単位」days ago"を返します。<br>
     * [5] 1週間以上は"「週単位」weeks ago"を返します。<br>
     *
     * @create 2024/04/30
     * @param instant 比較されたい日付
     * @return 比較結果
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static String compareDateToNow(Instant instant) {
        long seconds = ChronoUnit.SECONDS.between(instant, Instant.now());
        NumberFormat formatter = new DecimalFormat("#0");
        if (seconds < 60) {
            return seconds + " seconds ago";
        } else if (seconds < 3600) {
            return formatter.format(Math.floor((double) seconds / 60))  + " minutes ago";
        } else if (seconds < 86400) {
            return formatter.format(Math.floor((double) seconds / 3600)) + " hours ago";
        } else if (seconds < 604800) {
            return formatter.format(Math.floor((double) seconds / 86400)) + " days ago";
        }
        return formatter.format(Math.floor((double) seconds / 604800)) + " weeks ago";
    }
}
