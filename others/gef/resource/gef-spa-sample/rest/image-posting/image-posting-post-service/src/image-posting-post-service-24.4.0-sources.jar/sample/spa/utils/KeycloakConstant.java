/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.utils;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;

/**
 * キークロックの必要な引数です.<br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class KeycloakConstant {
    public static final String USER_MANAGEMENT_URI = "/admin/realms/" + GFrameworkUtils.getProperty("sample.spa.keycloak.realmId") + "/users/";
    public static final String GENERATE_TOKEN_URI = "realms/" + GFrameworkUtils.getProperty("sample.spa.keycloak.realmId") + "/protocol/openid-connect/token";
    public static final String INTROSPECT_TOKEN_URI = "/realms/" + GFrameworkUtils.getProperty("sample.spa.keycloak.realmId") + "/protocol/openid-connect/token/introspect";
}
