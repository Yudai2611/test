/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface PostCommentResponse {
  commentId: string;
  fullName: string;
  profilePicture: string;
  text: string;
  updatedAt: string;
  isMine: boolean;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface PostCommentRequest {
  postId: string;
  text: string;
}
