/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface PostResponse {
  postId: string;
  fullName: string;
  profilePicture: string;
  updatedAt: string;
  postDetail: string;
  postPicture: string;
  isMine: boolean;
  postPictureExt: string;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface PostRequest {
  postId: string?;
  postFile: File;
  postDetail: string;
}
