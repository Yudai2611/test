/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./App.css";
import { MyRouter } from "./router";
import { usePost } from "./store/postStore";
import LoadingComponent from "./ui-components/LoadingComponent";
import { useAuthentication } from "./store/authenticationStore";
import { useComment } from "./store/commentStore";
import { useMenu } from "./store/menuStore";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
function App() {
  const { loadingPost } = usePost();
  const { loadingAuth } = useAuthentication();
  const { loadingComment } = useComment();
  const { loadingMenu } = useMenu();
  return (
    <>
      <MyRouter />
      <ToastContainer autoClose={1000} />
      <LoadingComponent
        isShown={loadingPost || loadingAuth || loadingComment || loadingMenu}
      />
    </>
  );
}

export default App;
