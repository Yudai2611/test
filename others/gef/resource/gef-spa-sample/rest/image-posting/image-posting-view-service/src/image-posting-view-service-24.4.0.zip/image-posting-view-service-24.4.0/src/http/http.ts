/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import axios, { AxiosResponse } from "axios";
import { ENV } from "../utils/constants";
import { notifyError } from "../utils/notify";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const http = axios.create({
  baseURL: ENV.POST_SERVICE_BASE_URI,
  withCredentials: true,
});

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const setupInterceptors = () => {
  http.interceptors.request.use((config) => {
    const token = sessionStorage.getItem(ENV.ACCESS_TOKEN_COOKIE_KEY);
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  });
  http.interceptors.response.use(
    (response: AxiosResponse): AxiosResponse => {
      return response;
    },
    async (error) => {
      notifyError("Something when wrong!");
      return Promise.reject(error);
    },
  );
};
