/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { Button, Flex, ScrollView, View } from "@aws-amplify/ui-react";
import PostComponent from "../ui-components/PostComponent";
import { SyntheticEvent, useEffect, useState } from "react";
import CommentsDialog from "../ui-components/CommentsDialog";
import LoadingDialog from "../ui-components/LoadingDialog";
import AddPostDialog from "../ui-components/AddPostDialog";
import { usePost } from "../store/postStore";
import { useComment } from "../store/commentStore";
import { getFullNameFirstChar } from "../utils/helper";
import { useAuthentication } from "../store/authenticationStore";
import MyPostComponent from "../ui-components/MyPostComponent";
import { useMenu } from "../store/menuStore";
import { notifyInfo, notifySuccess } from "../utils/notify";
import EmptyComponent from "../ui-components/EmptyComponent";

const noImageUrl =
  "https://img.freepik.com/free-vector/illustration-gallery-icon_53876-27002.jpg?w=740&t=st=1706756955~exp=1706757555~hmac=f0c185a3e5ce1b3b2d2e35717e67288050a4fd8941b58f1061fe3f4d7b723353";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export default function ApplicationPage() {
  const [isShowCommentDialog, setShowCommentDialog] = useState(false);
  const [isShowDownloadDialog, setShowDownloadDialog] = useState(false);
  const [isShowPostDialog, setShowPostDialog] = useState(false);
  const [caption, setCaption] = useState<string>("");
  const [postPicture, setPostPicture] = useState<File>();
  const [postPictureUrl, setPostPictureUrl] = useState<string>(noImageUrl);
  const [captionHasError, setCaptionHasError] = useState<boolean>(false);
  const [commentText, setCommentText] = useState<string>("");
  const [commentTextHasError, setCOmmentTextHasError] =
    useState<boolean>(false);
  const { comments, getComments, addComment } = useComment();
  const { posts, addPost, getPosts, deletePost, updatePost } = usePost();
  const [currentPostId, setCurrentPostId] = useState<string>();
  const { getProfile } = useAuthentication();
  const { getMenus, setCurrentMenu } = useMenu();

  const onDownloadPostAction = (post: PostResponse) => {
    const link = document.createElement("a");
    link.download = post.postId + "." + post.postPictureExt;
    link.href = post.postPicture;
    link.click();
  };
  const openCommentDialog = (postId: string) => {
    getComments(postId).then(() => {
      setCurrentPostId(postId);
      setShowCommentDialog(true);
    });
  };
  useEffect(() => {
    setCurrentMenu("画像投稿");
    getMenus();
    getPosts("");
    getProfile();
  }, [getPosts, getProfile, getMenus, setCurrentMenu]);
  return (
    <ScrollView maxHeight={"80vh"}>
      <View position={"relative"} left={"0"} top={"0"} width={"100%"}>
        <Flex
          direction="row"
          justifyContent="flex-start"
          alignItems="stretch"
          alignContent="flex-start"
          wrap="wrap"
          gap="1.5rem"
          paddingBottom={"10px"}
        >
          {posts && posts.length > 0 ? (
            posts.map((post) =>
              post.isMine ? (
                <MyPostComponent
                  role="listitem"
                  aria-label="My Post Component"
                  profilePictureLabel={getFullNameFirstChar(post.fullName)}
                  onDeleteAction={async () => {
                    await deletePost(post.postId);
                    notifySuccess("Delete post is success!");
                    getPosts("");
                  }}
                  onEditAction={() => {
                    setCaption(post.postDetail);
                    setCurrentPostId(post.postId);
                    setPostPicture(undefined);
                    setShowPostDialog(true);
                  }}
                  onCommentAction={() => {
                    openCommentDialog(post.postId);
                  }}
                  onDownloadAction={() => {
                    onDownloadPostAction(post);
                  }}
                  fullName={post.fullName}
                  createdAt={post.updatedAt}
                  caption={post.postDetail}
                  postImage={post.postPicture}
                />
              ) : (
                <PostComponent
                  role="listitem"
                  aria-label="Post Component"
                  profilePictureLabel={getFullNameFirstChar(post.fullName)}
                  onCommentAction={() => {
                    openCommentDialog(post.postId);
                  }}
                  onDownloadAction={() => {
                    onDownloadPostAction(post);
                  }}
                  fullName={post.fullName}
                  createdAt={post.updatedAt}
                  caption={post.postDetail}
                  profilePicture={post.profilePicture}
                  postImage={post.postPicture}
                />
              ),
            )
          ) : (
            <EmptyComponent label="Post is Empty." />
          )}
        </Flex>
        <Button
          position={"fixed"}
          right={"40px"}
          bottom={"40px"}
          backgroundColor={"#000000"}
          color={"#FFFFFF"}
          borderRadius={"100px"}
          width={"50px"}
          height={"50px"}
          fontSize={"25px"}
          role="button"
          aria-label="Show Post Dialog"
          onClick={() => {
            setShowPostDialog(true);
          }}
        >
          +
        </Button>
      </View>

      <View
        role="dialog"
        aria-label="Comment Dialog"
        position={"fixed"}
        left={"0"}
        top={"0"}
        backgroundColor={"rgba(0,0,0,0.5)"}
        height={"100vh"}
        width={"100vw"}
        display={isShowCommentDialog ? "block" : "none"}
        paddingTop={"50px"}
      >
        <CommentsDialog
          onClose={() => {
            setShowCommentDialog(false);
            setCurrentPostId(undefined);
          }}
          onCommentTextChange={(e: SyntheticEvent) => {
            setCommentText((e.currentTarget as HTMLInputElement).value!);
          }}
          postId={currentPostId!}
          comments={comments}
          commentText={commentText}
          commentTextHasError={commentTextHasError}
          onSubmitComment={async () => {
            setCOmmentTextHasError(commentText == "");
            if (commentText != null) {
              const commentData: PostCommentRequest = {
                postId: currentPostId!,
                text: commentText,
              };
              await addComment(commentData);
              notifySuccess("Add comment is success");
              getComments(currentPostId!);
              setCommentText("");
            }
          }}
        />
      </View>
      <View
        position={"fixed"}
        left={"0"}
        top={"0"}
        backgroundColor={"rgba(0,0,0,0.5)"}
        height={"100vh"}
        width={"100vw"}
        display={isShowDownloadDialog ? "block" : "none"}
        paddingTop={"50px"}
      >
        <LoadingDialog
          onClose={() => {
            setShowDownloadDialog(false);
          }}
          margin={"auto"}
          percentage={0}
        />
      </View>
      <View
        role="dialog"
        aria-label="Post Dialog"
        position={"fixed"}
        left={"0"}
        top={"0"}
        backgroundColor={"rgba(0,0,0,0.5)"}
        height={"100vh"}
        width={"100vw"}
        display={isShowPostDialog ? "block" : "none"}
        paddingTop={"50px"}
      >
        <AddPostDialog
          postPicture={postPictureUrl}
          onPost={async () => {
            setCaptionHasError(caption === "");
            if (postPicture == null || postPicture == undefined) {
              notifyInfo("Post picture should be added!");
            }
            if (
              caption != "" &&
              postPicture != null &&
              postPicture != undefined
            ) {
              setShowPostDialog(false);
              if (currentPostId) {
                await updatePost({
                  postId: currentPostId,
                  postFile: postPicture,
                  postDetail: caption,
                });
                notifySuccess("Update post is success!");
              } else {
                await addPost({
                  postFile: postPicture,
                  postDetail: caption,
                  postId: null,
                });
                notifySuccess("Add post is success!");
              }

              setCaption("");
              setPostPicture(undefined);
              setPostPictureUrl(noImageUrl);
              getPosts("");
            }
          }}
          onClose={() => {
            setShowPostDialog(false);
            setCurrentPostId(undefined);
          }}
          margin={"auto"}
          caption={caption}
          captionHasError={captionHasError}
          onPostPictureChange={(e: SyntheticEvent) => {
            const file = (e.currentTarget as HTMLInputElement)!.files![0];
            setPostPicture(file);
            setPostPictureUrl(URL.createObjectURL(file));
          }}
          onCaptionChange={(e: SyntheticEvent) => {
            setCaption((e.currentTarget as HTMLInputElement).value!);
          }}
        />
      </View>
    </ScrollView>
  );
}
