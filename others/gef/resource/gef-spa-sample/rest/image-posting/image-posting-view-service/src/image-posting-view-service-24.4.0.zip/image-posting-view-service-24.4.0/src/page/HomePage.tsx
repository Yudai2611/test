/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { Card, Grid, View } from "@aws-amplify/ui-react";
import HeaderComponent from "../ui-components/HeaderComponent";
import { useEffect } from "react";
import { useComment } from "../store/commentStore";
import { getFullNameFirstChar } from "../utils/helper";
import { useAuthentication } from "../store/authenticationStore";
import { Outlet, useNavigate } from "react-router-dom";
import { useMenu } from "../store/menuStore";
import { Tree } from "react-arborist";
import MenuNode from "../ui-components/MenuNode";
import { usePost } from "../store/postStore";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export default function HomePage() {
  const { clearComment } = useComment();
  const { currentLoginUser, getProfile, logout, clearAuth } =
    useAuthentication();
  const { menus, getMenus, clearMenu, currentMenu } = useMenu();
  const { clearPost } = usePost();
  const navigate = useNavigate();

  useEffect(() => {
    getMenus();
    getProfile();
  }, [getMenus, getProfile]);
  return (
    <View position={"fixed"}>
      <View position={"fixed"} left={"0"} top={"0"} width={"100%"}>
        <Grid
          columnGap="0"
          rowGap="0"
          templateColumns="1fr 8fr"
          templateRows="1fr"
        >
          <Card columnStart="1" padding={"0"} columnEnd="-1">
            <HeaderComponent
              companyName={currentLoginUser.companyName}
              headerTitle={currentMenu}
              onLogout={async () => {
                await logout();
                clearAuth();
                clearPost();
                clearComment();
                clearMenu();
                navigate("/");
              }}
              fullName={
                currentLoginUser.firstName + " " + currentLoginUser.lastName
              }
              profilePictureLabel={getFullNameFirstChar(
                currentLoginUser.firstName,
              )}
            />
          </Card>
          <Card
            columnStart="1"
            columnEnd="1"
            padding={"0px"}
            paddingRight={"5px"}
          >
            <View
              overflow={"scroll"}
              width={"200px"}
              paddingTop={"30px"}
              paddingLeft={"10px"}
            >
              <Tree data={menus} openByDefault={true}>
                {MenuNode}
              </Tree>
            </View>
          </Card>
          <Card
            columnStart="2"
            columnEnd="-1"
            padding={"0px"}
            paddingTop={"10px"}
          >
            <View
              backgroundColor={"rgb(248,248,248)"}
              padding={"40px"}
              borderRadius={"30px"}
              minHeight={"80vh"}
            >
              <Outlet />
            </View>
          </Card>
        </Grid>
      </View>
    </View>
  );
}
