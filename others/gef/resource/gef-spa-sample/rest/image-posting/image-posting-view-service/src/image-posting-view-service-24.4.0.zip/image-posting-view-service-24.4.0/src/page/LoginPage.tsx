/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { useNavigate } from "react-router-dom";
import LoginForm from "../ui-components/LoginForm";
import { SyntheticEvent, useEffect, useState } from "react";
import { useAuthentication } from "../store/authenticationStore";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export default function LoginPage() {
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [usernameHasError, setUsernameHasError] = useState<boolean>(false);
  const [passwordHasError, setPasswordHasError] = useState<boolean>(false);
  const { isAuthenticated, error, login } = useAuthentication();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/home");
    }
  }, [isAuthenticated, navigate]);

  return (
    <LoginForm
      username={username}
      isLoginFailed={error != ""}
      usernameHasError={usernameHasError}
      passwordHasError={passwordHasError}
      onChangeUsername={(e: SyntheticEvent) => {
        setUsername((e.currentTarget as HTMLInputElement).value!);
      }}
      password={password}
      onChangePassword={(e: SyntheticEvent) => {
        setPassword((e.currentTarget as HTMLInputElement).value!);
      }}
      onLogin={async () => {
        setUsernameHasError(username === "");
        setPasswordHasError(password === "");

        if (
          username != "" &&
          password != "" &&
          username != null &&
          password != null
        ) {
          login(username, password);
        }
      }}
      onRegister={() => {
        navigate("/register");
      }}
    />
  );
}
