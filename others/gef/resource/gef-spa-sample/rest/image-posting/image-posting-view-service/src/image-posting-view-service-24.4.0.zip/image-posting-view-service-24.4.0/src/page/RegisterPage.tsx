/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { useNavigate } from "react-router-dom";
import RegisterForm from "../ui-components/RegisterForm";
import { SyntheticEvent, useEffect, useState } from "react";
import { useAuthentication } from "../store/authenticationStore";
import { useCompany } from "../store/companyStore";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export default function RegisterPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState<string>("");
  const [companyCode, setCompanyCode] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [firstName, setFirstName] = useState<string>("");
  const [lastName, setLastName] = useState<string>("");
  const [confirmationPassword, setConfirmationPassword] = useState<string>("");
  const [usernameHasError, setUsernameHasError] = useState<boolean>(false);
  const [companyCodeHasError, setCompanyCodeHasError] =
    useState<boolean>(false);
  const [passwordHasError, setPasswordHasError] = useState<boolean>(false);
  const [firstNameHasError, setFirstnameHasError] = useState<boolean>(false);
  const [lastNameHasError, setLastNameHasError] = useState<boolean>(false);
  const [confirmationPasswordHasError, setConfirmationPasswordHasError] =
    useState<boolean>(false);
  const { companies, getCompanies } = useCompany();
  const { register } = useAuthentication();

  useEffect(() => {
    getCompanies();
  }, [getCompanies]);

  return (
    <RegisterForm
      onChangeUsername={(e: SyntheticEvent) => {
        setUsername((e.currentTarget as HTMLInputElement).value!);
      }}
      onChangePassword={(e: SyntheticEvent) => {
        setPassword((e.currentTarget as HTMLInputElement).value!);
      }}
      onChangeFirstName={(e: SyntheticEvent) => {
        setFirstName((e.currentTarget as HTMLInputElement).value!);
      }}
      onChangeLastName={(e: SyntheticEvent) => {
        setLastName((e.currentTarget as HTMLInputElement).value!);
      }}
      onChangeConfirmationPassword={(e: SyntheticEvent) => {
        setConfirmationPassword((e.currentTarget as HTMLInputElement).value!);
      }}
      onChangeCompanyCode={(e: SyntheticEvent) => {
        setCompanyCode((e.currentTarget as HTMLInputElement).value!);
      }}
      username={username}
      companyCode={companyCode}
      password={password}
      firstName={firstName}
      lastName={lastName}
      companies={companies}
      confirmationPassword={confirmationPassword}
      usernameHasError={usernameHasError}
      companyCodeHasError={companyCodeHasError}
      passwordHasError={passwordHasError}
      firstNameHasError={firstNameHasError}
      lastNameHasError={lastNameHasError}
      confirmationPasswordHasError={confirmationPasswordHasError}
      onRegister={async () => {
        setUsernameHasError(username === "");
        setPasswordHasError(password === "");
        setFirstnameHasError(firstName === "");
        setLastNameHasError(lastName === "");
        setCompanyCodeHasError(companyCode === "");
        setConfirmationPasswordHasError(
          confirmationPassword === "" || confirmationPassword != password,
        );

        if (
          username != "" &&
          password != "" &&
          firstName != "" &&
          lastName != "" &&
          confirmationPassword != "" &&
          confirmationPassword === password
        ) {
          await register({
            username: username,
            password: password,
            confirmationPassword: confirmationPassword,
            firstName: firstName,
            lastName: lastName,
            companyCode:
              companyCode == "" ? companies[0].companyCode : companyCode,
          });
          navigate("/");
        }
      }}
    />
  );
}
