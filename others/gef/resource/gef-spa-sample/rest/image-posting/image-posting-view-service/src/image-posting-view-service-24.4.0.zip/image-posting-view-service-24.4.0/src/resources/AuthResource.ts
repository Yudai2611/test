/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import axios from "axios";
import { ENV } from "../utils/constants";
import { http } from "../http/http";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const login = async (username: string, password: string) => {
  return await axios.post(
    ENV.KEYCLOAK_SERVICE_BASE_URI +
      "realms/" +
      ENV.KEYCLOAK_SERVICE_REALMS_ID +
      "/protocol/openid-connect/token",
    {
      username: username,
      password: password,
      client_id: ENV.KEYCLOAK_SERVICE_CLIENT_ID,
      client_secret: ENV.KEYCLOAK_SERVICE_CLIENT_SECRET,
      grant_type: ENV.KEYCLOAK_SERVICE_GRANT_TYPE,
    },
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    },
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const logout = async () => {
  const requestBody = {
    client_id: ENV.KEYCLOAK_SERVICE_CLIENT_ID,
    token: sessionStorage.getItem(ENV.ACCESS_TOKEN_COOKIE_KEY),
    client_secret: ENV.KEYCLOAK_SERVICE_CLIENT_SECRET,
  };
  await http.post(
    ENV.KEYCLOAK_SERVICE_BASE_URI +
      "realms/" +
      ENV.KEYCLOAK_SERVICE_REALMS_ID +
      "/protocol/openid-connect/revoke",
    requestBody,
    {
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
    },
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getCsrf = async () => {
  return await http.get(ENV.POST_SERVICE_BASE_URI + "csrf");
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const register = async (user: User) => {
  return await http.post(
    ENV.POST_SERVICE_BASE_URI + "users/register",
    {
      username: user.username,
      password: user.password,
      confirmationPassword: user.confirmationPassword,
      firstName: user.firstName,
      lastName: user.lastName,
      companyCode: user.companyCode,
    },
    {
      headers: {
        "Content-Type": "application/json",
      },
    },
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getProfile = async () => {
  return await http.get(ENV.POST_SERVICE_BASE_URI + "users/profile");
};
