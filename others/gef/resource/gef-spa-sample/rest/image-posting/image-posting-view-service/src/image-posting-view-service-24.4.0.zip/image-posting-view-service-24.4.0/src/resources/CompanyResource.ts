/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { http } from "../http/http";
import { ENV } from "../utils/constants";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getCompanies = async () => {


  return await http.get(ENV.POST_SERVICE_BASE_URI + "companies");
};
