/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { ENV } from "../utils/constants";
import { http } from "../http/http";
import { getCsrf } from "./AuthResource";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const addPost = async (post: PostRequest) => {
  const form = new FormData();
  form.append("postDetail", post.postDetail);
  form.append("postFile", post.postFile);
  const csrfToken = (await getCsrf()).headers["csrf_token"];
  return await http.post(ENV.POST_SERVICE_BASE_URI + "posts", form, {
    headers: {
      "Content-Type": "multipart/form-data",
      "X-csrf-token": csrfToken,
    },
  });
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getPosts = async (keyword: string) => {
  return await http.get(
    ENV.POST_SERVICE_BASE_URI + "posts?keyword=" + keyword + "&size=1000",
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const updatePost = async (post: PostRequest) => {
  const form = new FormData();
  form.append("postId", post.postId!);
  form.append("postDetail", post.postDetail);
  form.append("postFile", post.postFile);
  const csrfToken = (await getCsrf()).headers["csrf_token"];
  return await http.patch(ENV.POST_SERVICE_BASE_URI + "posts", form, {
    headers: {
      "Content-Type": "multipart/form-data",
      "X-csrf-token": csrfToken,
    },
  });
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const deletePost = async (postId: string) => {
  const csrfToken = (await getCsrf()).headers["csrf_token"];
  return await http.delete(ENV.POST_SERVICE_BASE_URI + "posts/" + postId, {
    headers: {
      "X-csrf-token": csrfToken,
    },
  });
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const downloadPost = async (postId: string) => {
  return await http.get(
    ENV.POST_SERVICE_BASE_URI + "posts/" + postId + "/download-picture",
    {
      responseType: "blob",
    },
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getComments = async (postId: string) => {
  return await http.get(
    ENV.POST_SERVICE_BASE_URI + "posts/" + postId + "/comments",
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const deleteComment = async (postId: string, commentId: string) => {
  const csrfToken = (await getCsrf()).headers["csrf_token"];
  return await http.delete(
    ENV.POST_SERVICE_BASE_URI + "posts/" + postId + "/comments/" + commentId,
    {
      headers: {
        "X-csrf-token": csrfToken,
      },
    },
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const addComment = async (comment: PostCommentRequest) => {
  const csrfToken = (await getCsrf()).headers["csrf_token"];
  return await http.post(
    ENV.POST_SERVICE_BASE_URI + "posts/comments",
    {
      postId: comment.postId,
      text: comment.text,
    },
    {
      headers: {
        "Content-Type": "application/json",
        "X-csrf-token": csrfToken,
      },
    },
  );
};
