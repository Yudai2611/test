/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { create } from "zustand";
import { getProfile, login, logout, register } from "../resources/AuthResource";
import { ENV } from "../utils/constants";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface AuthenticationStore {
  isAuthenticated: boolean;
  error: string;
  currentLoginUser: any;
  loadingAuth: boolean;
  setIsAuthenticated: (isAuthenticated: boolean) => void;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (user: User) => Promise<void>;
  getProfile: () => Promise<void>;
  clearAuth: () => Promise<void>;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const useAuthentication = create<AuthenticationStore>((set) => ({
  isAuthenticated: false,
  currentLoginUser: {
    firstName: "",
    lastName: "",
    companyName: "",
  },
  loadingAuth: false,
  setIsAuthenticated: (isAuthenticated: boolean) =>
    set(() => ({
      isAuthenticated: isAuthenticated,
    })),
  error: "",
  login: async (username: string, password: string) => {
    set(() => ({
      loadingAuth: true,
    }));
    try {
      const loginRes = await login(username, password);
      sessionStorage.setItem(
        ENV.ACCESS_TOKEN_COOKIE_KEY,
        loginRes.data.access_token,
      );
      if (loginRes && loginRes.status == 200) {
        set(() => ({
          isAuthenticated: true,
          error: "",
        }));
      }
    } catch (exception) {
      set(() => ({
        isAuthenticated: false,
        error: "Login is failed",
      }));
    } finally {
      set(() => ({
        loadingAuth: false,
      }));
    }
  },
  logout: async () => {
    set(() => ({
      loadingAuth: true,
    }));
    try {
      await logout();
      sessionStorage.removeItem(ENV.ACCESS_TOKEN_COOKIE_KEY);
      set(() => ({
        isAuthenticated: false,
        error: "",
        currentLoginUser: {
          firstName: "",
          lastName: "",
        },
      }));
    } finally {
      set(() => ({
        loadingAuth: false,
      }));
    }
  },
  register: async (user: User) => {
    set(() => ({
      loadingAuth: true,
    }));
    try {
      await register(user);
    } finally {
      set(() => ({
        loadingAuth: false,
      }));
    }
  },
  getProfile: async () => {
    set(() => ({
      loadingAuth: true,
    }));
    try {
      const res = await getProfile();
      if (res && res.status == 200) {
        set(() => ({
          currentLoginUser: {
            username: res.data.username,
            firstName: res.data.firstName,
            lastName: res.data.lastName,
            companyName: res.data.companyName,
          },
        }));
      }
    } finally {
      set(() => ({
        loadingAuth: false,
      }));
    }
  },
  clearAuth: async () => {
    set(() => ({
      isAuthenticated: false,
      error: "",
      currentLoginUser: {
        firstName: "",
        lastName: "",
      },
    }));
  },
}));
