/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { create } from "zustand";
import {
  addComment,
  deleteComment,
  getComments,
} from "../resources/PostResource";
import { AxiosResponse } from "axios";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface CommentStore {
  comments: PostCommentResponse[];
  loadingComment: boolean;
  addComment: (comment: PostCommentRequest) => Promise<void>;
  getComments: (postId: string) => Promise<void>;
  deleteComment: (postId: string, commentId: string) => Promise<void>;
  clearComment: () => Promise<void>;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const useComment = create<CommentStore>((set) => ({
  comments: [],
  loadingComment: false,
  addComment: async (comment: PostCommentRequest) => {
    set(() => ({
      loadingComment: true,
    }));
    try {
      await addComment(comment);
    } finally {
      set(() => ({
        loadingComment: false,
      }));
    }
  },
  getComments: async (postId: string) => {
    set(() => ({
      loadingComment: true,
    }));
    try {
      const res: AxiosResponse = await getComments(postId);
      if (res.status == 200) {
        const commentResponses: PostCommentResponse[] =
          await convertToCommentResponse(res.data);
        set(() => ({
          comments: [...commentResponses],
        }));
      }
    } finally {
      set(() => ({
        loadingComment: false,
      }));
    }
  },
  deleteComment: async (postId: string, commentId: string) => {
    set(() => ({
      loadingComment: true,
    }));
    try {
      await deleteComment(postId, commentId);
    } finally {
      set(() => ({
        loadingComment: false,
      }));
    }
  },
  clearComment: async () => {
    set(() => ({
      comments: [],
    }));
  },
}));


/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
const convertToCommentResponse = (res: any[]) => {
  const comments: PostCommentResponse[] = [];
  for (const element of res) {
    comments.push({
      commentId: element.commentId,
      text: element.text,
      fullName: element.createdBy.firstName + " " + element.createdBy.lastName,
      updatedAt: element.updatedAt,
      profilePicture: "",
      isMine: element.mine,
    });
  }
  return comments;
};
