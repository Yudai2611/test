/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { create } from "zustand";
import { getCompanies } from "../resources/CompanyResource";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface CompanyStore {
  loadingCompany: boolean;
  companies: Company[];
  getCompanies: () => Promise<void>;
  clearCompany: () => Promise<void>;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const useCompany = create<CompanyStore>((set) => ({
  companies: [],
  loadingCompany: false,
  getCompanies: async () => {
    set(() => ({
      loadingCompany: true,
    }));
    try {
      const res = await getCompanies();
      if (res.status == 200) {
        set(() => ({
          companies: [...res.data],
        }));
      }
    } finally {
      set(() => ({
        loadingCompany: false,
      }));
    }
  },
  clearCompany: async () => {
    set(() => ({
      companies: [],
    }));
  },
}));
