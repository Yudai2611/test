/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { create } from "zustand";
import {
  addPost,
  deletePost,
  downloadPost,
  getPosts,
  updatePost,
} from "../resources/PostResource";
import { AxiosResponse } from "axios";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface PostStore {
  posts: PostResponse[];
  loadingPost: boolean;
  addPost: (post: PostRequest) => Promise<void>;
  getPosts: (keyword: string) => Promise<void>;
  deletePost: (postId: string) => Promise<void>;
  updatePost: (post: PostRequest) => Promise<void>;
  clearPost: () => Promise<void>;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const usePost = create<PostStore>((set) => ({
  posts: [],
  loadingPost: false,
  addPost: async (post: PostRequest) => {
    set(() => ({
      loadingPost: true,
    }));
    try {
      await addPost(post);
    } finally {
      set(() => ({
        loadingPost: false,
      }));
    }
  },
  getPosts: async (keyword: string) => {
    set(() => ({
      loadingPost: true,
    }));
    try {
      const res: AxiosResponse = await getPosts(keyword);
      if (res.status == 200) {
        const postResponses: PostResponse[] = await convertToPostResponse(
          res.data.result,
        );
        set(() => ({
          posts: [...postResponses],
        }));
      } else if (res.status == 204) {
        set(() => ({
          posts: [],
        }));
      }
    } finally {
      set(() => ({
        loadingPost: false,
      }));
    }
  },
  deletePost: async (postId: string) => {
    set(() => ({
      loadingPost: true,
    }));
    try {
      await deletePost(postId);
    } finally {
      set(() => ({
        loadingPost: false,
      }));
    }
  },
  updatePost: async (post: PostRequest) => {
    set(() => ({
      loadingPost: true,
    }));
    try {
      await updatePost(post);
    } finally {
      set(() => ({
        loadingPost: false,
      }));
    }
  },
  clearPost: async () => {
    set(() => ({
      posts: [],
    }));
  },
}));

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
const getFileExtension = (contentDisposition: string) => {
  const matches = contentDisposition.match(
    /filename\*?=['"]?(?:UTF-\d['"]*)?([^;\r\n"']*)["']?;?/i,
  );
  if (matches && matches.length > 1) {
    const filename = matches[1];
    const lastDotIndex = filename.lastIndexOf(".");
    if (lastDotIndex !== -1) {
      return filename.slice(lastDotIndex + 1);
    }
  }
  return null;
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
const convertToPostResponse = async (res: any[]) => {
  const posts: PostResponse[] = [];
  for (const element of res) {
    const picRes = await downloadPost(element.postId);
    const picExt = getFileExtension(picRes.headers["content-disposition"]);
    const pic = picRes.data;
    const blobUrl = URL.createObjectURL(pic);
    posts.push({
      postId: element.postId,
      fullName: element.createdBy.firstName + " " + element.createdBy.lastName,
      profilePicture: "",
      updatedAt: element.updatedAt,
      postDetail: element.postDetail,
      postPicture: blobUrl,
      isMine: element.mine,
      postPictureExt: picExt!,
    });
  }
  return posts;
};
