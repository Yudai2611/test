/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import {
  ButtonProps,
  FlexProps,
  ImageProps,
  TextAreaFieldProps,
  TextProps,
  ViewProps,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type PostDialogOverridesProps = {
  PostDialog?: PrimitiveOverrideProps<ViewProps>;
  "Frame 43"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 40"?: PrimitiveOverrideProps<FlexProps>;
  Post?: PrimitiveOverrideProps<TextProps>;
  "Frame 41"?: PrimitiveOverrideProps<FlexProps>;
  "image 4"?: PrimitiveOverrideProps<ImageProps>;
  TextAreaField?: PrimitiveOverrideProps<TextAreaFieldProps>;
  "Frame 42"?: PrimitiveOverrideProps<FlexProps>;
  Button3906186?: PrimitiveOverrideProps<ButtonProps>;
  Button3906194?: PrimitiveOverrideProps<ButtonProps>;
} & EscapeHatchProps;
export declare type PostDialogProps = React.PropsWithChildren<
  Partial<ViewProps> & {
    postPicture?: string;
    onPost?: (event: SyntheticEvent) => void;
    caption?: string;
    onClose?: (event: SyntheticEvent) => void;
    captionHasError?: boolean;
    onCaptionChange?: (event: SyntheticEvent) => void;
    onPostPictureChange?: (event: SyntheticEvent) => void;
  } & {
    overrides?: PostDialogOverridesProps | undefined | null;
  }
>;
export default function PostDialog(props: PostDialogProps): React.ReactElement;
