/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import {
  Button,
  DropZone,
  Flex,
  Image,
  ScrollView,
  Text,
  TextAreaField,
  View,
  VisuallyHidden,
} from "@aws-amplify/ui-react";
const acceptedFileTypes = ["image/png", "image/jpeg"];
export default function AddPostDialog(props) {
  const {
    postPicture,
    onPost,
    caption,
    onClose,
    captionHasError,
    onCaptionChange,
    onPostPictureChange,
    overrides,
    ...rest
  } = props;
  const [files, setFiles] = React.useState([]);
  const hiddenInput = React.useRef(null);

  const onFilePickerChange = (event) => {
    const { files } = event.target;
    if (!files || files.length === 0) {
      return;
    }
    setFiles(Array.from(files));
  };

  return (
    <View
      width="356px"
      height="80vh"
      display="block"
      gap="unset"
      overflow={"hidden"}
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      borderRadius="10px"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "PostDialog")}
      {...rest}
    >
      <Flex
        gap="10px"
        direction="column"
        width="356px"
        height="600px"
        justifyContent="flex-start"
        alignItems="flex-start"
        overflow="hidden"
        position="absolute"
        top="0px"
        left="0px"
        padding="7px 0px 7px 0px"
        {...getOverrideProps(overrides, "Frame 43")}
      >
        <Flex
          gap="10px"
          direction="row"
          width="unset"
          height="46px"
          justifyContent="center"
          overflow={"visible"}
          alignItems="center"
          shrink="0"
          alignSelf="stretch"
          position="relative"
          padding="28px 162px 28px 162px"
          {...getOverrideProps(overrides, "Frame 40")}
        >
          <Text
            fontFamily="Roboto"
            fontSize="20px"
            fontWeight="800"
            color="rgba(0,0,0,1)"
            lineHeight="22px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="Post"
            {...getOverrideProps(overrides, "Post")}
          ></Text>
        </Flex>
        <Flex
          gap="10px"
          direction="column"
          width="356px"
          height="60vh"
          justifyContent="flex-start"
          alignItems="center"
          overflow="hidden scroll"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          {...getOverrideProps(overrides, "Frame 41")}
        >
          <Image
            width="356px"
            height="177px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            shrink="0"
            position="relative"
            role="img"
            aria-label="Post Picture in Post Dialog"
            padding="0px 0px 0px 0px"
            objectFit="cover"
            src={postPicture}
            {...getOverrideProps(overrides, "image 4")}
          ></Image>
          <DropZone
            acceptedFileTypes={acceptedFileTypes}
            onDropComplete={({ acceptedFiles, rejectedFiles }) => {
              setFiles(acceptedFiles);
            }}
          >
            <Flex direction="column" alignItems="center">
              <Text>Drag images here or</Text>
              <Button
                size="small"
                onClick={() => hiddenInput.current.click()}
                role="button"
                aria-label="Browse Post Picture in Post Dialog"
              >
                Browse
              </Button>
            </Flex>
            <VisuallyHidden>
              <input
                type="file"
                role="textbox"
                aria-label="Post Picture Input in Post Dialog"
                tabIndex={-1}
                ref={hiddenInput}
                onChange={onPostPictureChange}
                multiple={false}
              />
            </VisuallyHidden>
          </DropZone>
          {files.map((file) => (
            <Text key={file.name}>{file.name}</Text>
          ))}
          <TextAreaField
            width="328px"
            height="unset"
            placeholder="Type your caption here..."
            shrink="0"
            role="textbox"
            aria-label="Caption Box in Post Dialog"
            size="default"
            isDisabled={false}
            labelHidden={true}
            variation="default"
            value={caption}
            isRequired={true}
            hasError={captionHasError}
            errorMessage="Caption cannot be empty."
            onChange={onCaptionChange}
            {...getOverrideProps(overrides, "TextAreaField")}
          ></TextAreaField>
          <Flex
            gap="10px"
            direction="row"
            width="unset"
            height="unset"
            justifyContent="flex-end"
            alignItems="center"
            overflow="hidden"
            shrink="0"
            alignSelf="stretch"
            position="relative"
            padding="10px 10px 10px 10px"
            {...getOverrideProps(overrides, "Frame 42")}
          >
            <Button
              width="unset"
              height="unset"
              shrink="0"
              size="default"
              isDisabled={false}
              role="button"
              aria-label="Submit Post in Post Dialog"
              variation="primary"
              children="Submit"
              onClick={onPost}
              {...getOverrideProps(overrides, "Button3906186")}
            ></Button>
          </Flex>
        </Flex>
      </Flex>
      <Button
        width="unset"
        height="unset"
        position="absolute"
        border="0px SOLID rgba(174,179,183,1)"
        borderRadius="4px"
        top="6px"
        left="306px"
        size="default"
        isDisabled={false}
        variation="default"
        children="X"
        role="button"
        aria-label="Close Button in Post Dialog"
        onClick={onClose}
        {...getOverrideProps(overrides, "Button3906194")}
      ></Button>
    </View>
  );
}
