/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { FlexProps, IconProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type CircleButtonOverridesProps = {
  CircleButton?: PrimitiveOverrideProps<FlexProps>;
  "\uD83D\uDD12Icon"?: PrimitiveOverrideProps<IconProps>;
} & EscapeHatchProps;
export declare type CircleButtonProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    overrides?: CircleButtonOverridesProps | undefined | null;
  }
>;
export default function CircleButton(
  props: CircleButtonProps,
): React.ReactElement;
