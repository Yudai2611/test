/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Flex, Icon } from "@aws-amplify/ui-react";
export default function CircleButton(props) {
  const { overrides, ...rest } = props;
  return (
    <Flex
      gap="10px"
      direction="row"
      width={100}
      height={100}
      justifyContent="center"
      alignItems="center"
      overflow="hidden"
      position="relative"
      borderRadius="100px"
      padding="25px 27px 25px 27px"
      backgroundColor="rgba(4,125,149,1)"
      {...getOverrideProps(overrides, "CircleButton")}
      {...rest}
    >
      <Icon
        width={40}
        height={40}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        shrink="0"
        position="relative"
        padding="0px 0px 0px 0px"
        type="add"
        fontSize="40px"
        color="#FFFFFF"
        {...getOverrideProps(overrides, "\uD83D\uDD12Icon")}
      ></Icon>
    </Flex>
  );
}
