/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { Button, ScrollView, View } from "@aws-amplify/ui-react";
import PostCommentItemComponent from "./PostCommentItemComponent";
import PostCommentBoxComponent from "./PostCommentBoxComponent";
import { SyntheticEvent } from "react";
import { getFullNameFirstChar } from "../utils/helper";
import MyPostCommentItemComponent from "./MyPostCommentItemComponent";
import { useComment } from "../store/commentStore";
import { notifySuccess } from "../utils/notify";
import EmptyComponent from "./EmptyComponent";

interface Props {
  onClose?: (event: SyntheticEvent) => void;
  comments?: PostCommentResponse[];
  commentText?: string;
  onCommentTextChange?: (event: SyntheticEvent) => void;
  commentTextHasError?: boolean;
  onSubmitComment?: (event: SyntheticEvent) => void;
  postId: string;
}

export default function CommentsDialog(props: Props) {
  const {
    onClose,
    comments,
    commentText,
    onCommentTextChange,
    commentTextHasError,
    onSubmitComment,
    postId,
  } = props;
  const { deleteComment, getComments } = useComment();

  return (
    <View
      position={"relative"}
      width={"400px"}
      margin={"auto"}
      backgroundColor={"#FFFFFF"}
      padding={"5px"}
      borderRadius={"10px"}
    >
      <Button
        role="button"
        aria-label="Comment Close Button"
        position={"absolute"}
        right={"15px"}
        top={"10px"}
        color={"#000000"}
        fontWeight={"bold"}
        onClick={onClose}
        borderWidth={"0"}
      >
        X
      </Button>
      <View
        textAlign={"center"}
        fontSize={"20px"}
        fontWeight={"bold"}
        padding={"20px 0"}
      >
        Comments
      </View>

      <ScrollView maxHeight={"40vh"} margin={"20px 0"}>
        {comments && comments.length > 0 ? (
          comments?.map((comment) =>
            comment.isMine ? (
              <MyPostCommentItemComponent
                role="listitem"
                aria-label="My Comment Component"
                onDeleteAction={async () => {
                  await deleteComment(postId, comment.commentId);
                  notifySuccess("Delete comment is success!");
                  getComments(postId);
                }}
                comment={comment.text}
                profilePictureLabel={getFullNameFirstChar(comment.fullName)}
                fullName={comment.fullName}
                createdAt={comment.updatedAt}
              />
            ) : (
              <PostCommentItemComponent
                role="listitem"
                aria-label="Comment Component"
                comment={comment.text}
                profilePictureLabel={getFullNameFirstChar(comment.fullName)}
                profilePicture={comment.profilePicture}
                fullName={comment.fullName}
                createdAt={comment.updatedAt}
              />
            ),
          )
        ) : (
          <EmptyComponent label="Comments is empty." />
        )}
      </ScrollView>

      <PostCommentBoxComponent
        bottom={"0"}
        textAlign={"left"}
        onSubmitComment={onSubmitComment}
        commentText={commentText}
        onCommentTextChange={onCommentTextChange}
        comemntTextHasError={commentTextHasError}
      />
    </View>
  );
}
