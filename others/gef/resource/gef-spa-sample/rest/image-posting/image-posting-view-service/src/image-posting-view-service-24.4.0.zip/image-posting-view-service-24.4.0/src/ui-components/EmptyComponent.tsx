/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { Flex, Image, Text } from "@aws-amplify/ui-react";

export default function EmptyComponent(props: any) {
  const { label } = props;
  return (
    <Flex
      width={"100%"}
      direction="column"
      justifyContent="center"
      alignItems="center"
      alignContent="center"
      wrap="no-rap"
    >
      <Image
        alt="emptyImage"
        margin={"auto"}
        width={"200px"}
        src={
          "https://img.freepik.com/free-vector/flat-design-no-data-illustration_23-2150527130.jpg?w=740&t=st=1706757163~exp=1706757763~hmac=4f3805727b5d6679d6f1a87b494916f2a18dd9245f0cc3514637ca8dc39d8f24"
        }
      ></Image>
      <Text
        fontFamily="Roboto"
        fontSize="20px"
        fontWeight="800"
        color="rgba(0,0,0,1)"
        lineHeight="22px"
        textAlign="center"
        display="block"
        width="unset"
        height="unset"
      >
        {label}
      </Text>
    </Flex>
  );
}
