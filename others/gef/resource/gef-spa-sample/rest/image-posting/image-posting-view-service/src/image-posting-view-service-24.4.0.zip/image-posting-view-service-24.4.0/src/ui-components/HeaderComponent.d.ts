/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { DividerProps, FlexProps, TextProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type HeaderComponentOverridesProps = {
  HeaderComponent?: PrimitiveOverrideProps<FlexProps>;
  "Frame 28"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 27"?: PrimitiveOverrideProps<FlexProps>;
  "GreenEarth Framework Sample"?: PrimitiveOverrideProps<TextProps>;
  "Dhiaz Chebastian"?: PrimitiveOverrideProps<TextProps>;
  "Frame 44"?: PrimitiveOverrideProps<FlexProps>;
  D?: PrimitiveOverrideProps<TextProps>;
  Divider?: PrimitiveOverrideProps<DividerProps>;
} & EscapeHatchProps;
export declare type HeaderComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    profilePicture?: string;
    fullName?: string;
    profilePictureLabel?: string;
    companyName: string;
    headerTitle: string;
    onLogout?: (event: SyntheticEvent) => void;
  } & {
    overrides?: HeaderComponentOverridesProps | undefined | null;
  }
>;
export default function HeaderComponent(
  props: HeaderComponentProps,
): React.ReactElement;
