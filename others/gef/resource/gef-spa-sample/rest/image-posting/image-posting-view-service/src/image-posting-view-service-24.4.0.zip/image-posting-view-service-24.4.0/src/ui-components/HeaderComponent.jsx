/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Button, Flex, Text } from "@aws-amplify/ui-react";
export default function HeaderComponent(props) {
  const {
    profilePicture,
    fullName,
    profilePictureLabel,
    onLogout,
    headerTitle,
    companyName,
    overrides,
    ...rest
  } = props;
  return (
    <Flex
      gap="10px"
      direction="column"
      width="auto"
      height="71px"
      justifyContent="center"
      alignItems="center"
      overflow="hidden"
      position="relative"
      paddingTop="30px"
      paddingBottom={"30px"}
      paddingLeft={"30px"}
      paddingRight={"30px"}
      backgroundColor={"#195399"}
      {...getOverrideProps(overrides, "HeaderComponent")}
      {...rest}
    >
      <Flex
        gap="10px"
        direction="row"
        width="unset"
        height="53px"
        justifyContent="center"
        alignItems="center"
        overflow="hidden"
        shrink="0"
        alignSelf="stretch"
        position="relative"
        padding="10px 10px 10px 10px"
        {...getOverrideProps(overrides, "Frame 28")}
      >
        <Flex
          gap="-69px"
          direction="column"
          width="unset"
          height="unset"
          justifyContent="flex-end"
          alignItems="center"
          overflow="hidden"
          grow="1"
          shrink="1"
          basis="0"
          position="relative"
          padding="0px 10px 0px 10px"
          {...getOverrideProps(overrides, "Frame 27")}
        >
          <Text
            fontFamily="Inter"
            fontSize="20px"
            fontWeight="700"
            color="rgb(255,255,255)"
            lineHeight="25px"
            textAlign="center"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="25px"
            gap="unset"
            alignItems="unset"
            shrink="0"
            alignSelf="stretch"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            role="heading"
            aria-label="Header Title"
            children={headerTitle}
            {...getOverrideProps(overrides, "GreenEarth Framework Sample")}
          ></Text>
        </Flex>

        <Flex
          gap="10px"
          direction="column"
          width="50px"
          height="50px"
          marginLeft={"20px"}
          justifyContent="center"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          borderRadius="100px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(5,5,5,1)"
          {...getOverrideProps(overrides, "Frame 44")}
        >
          <Text
            fontFamily="Inter"
            fontSize="12px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            lineHeight="15px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            role="heading"
            aria-label="Profile Picture"
            children={profilePictureLabel}
            {...getOverrideProps(overrides, "D")}
          ></Text>
        </Flex>
        <Flex gap="5px" direction={"column"}>
          <Text
            fontFamily="Inter"
            fontSize="12px"
            fontWeight="700"
            lineHeight="15px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            color="rgb(255,255,255)"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            role="heading"
            aria-label="Full Name"
            children={"🙎‍♂️ " + fullName}
            {...getOverrideProps(overrides, "Dhiaz Chebastian")}
          ></Text>

          <Text
            fontFamily="Inter"
            fontSize="12px"
            fontWeight="700"
            lineHeight="15px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            color="rgb(255,255,255)"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            role="heading"
            aria-label="Company Name"
            children={"🏦 " + companyName}
            {...getOverrideProps(overrides, "Dhiaz Chebastian")}
          ></Text>
        </Flex>

        <Button
          onClick={onLogout}
          marginLeft={"20px"}
          backgroundColor={"#9b1212"}
          borderWidth={"0px"}
          color="rgb(255,255,255)"
        >
          Logout
        </Button>
      </Flex>
      {/* <Divider
        width="unset"
        height="1px"
        shrink="0"
        alignSelf="stretch"
        size="small"
        orientation="horizontal"
        {...getOverrideProps(overrides, "Divider")}
      ></Divider> */}
    </Flex>
  );
}
