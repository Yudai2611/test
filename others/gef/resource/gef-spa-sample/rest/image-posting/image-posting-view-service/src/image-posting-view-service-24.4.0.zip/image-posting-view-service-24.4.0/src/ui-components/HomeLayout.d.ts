/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { FlexProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type HomeLayoutOverridesProps = {
  HomeLayout?: PrimitiveOverrideProps<FlexProps>;
  "Frame 13"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 14"?: PrimitiveOverrideProps<FlexProps>;
} & EscapeHatchProps;
export declare type HomeLayoutProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    sideComponent?: React.ReactNode;
    mainComponent?: React.ReactNode;
  } & {
    overrides?: HomeLayoutOverridesProps | undefined | null;
  }
>;
export default function HomeLayout(props: HomeLayoutProps): React.ReactElement;
