/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { Flex, Loader, useTheme } from "@aws-amplify/ui-react";

interface LoadingProps {
  isShown: boolean;
}

export default function LoadingComponent(props: LoadingProps) {
  const { tokens } = useTheme();
  const { isShown } = props;
  return (
    <Flex
      position={"fixed"}
      display={isShown ? "flex" : "none"}
      top={"0px"}
      left={"0px"}
      width={"100%"}
      height={"100%"}
      direction="column"
      justifyContent="center"
      alignItems="center"
      alignContent="center"
      wrap="nowrap"
      backgroundColor={"rgba(0,0,0,0.5)"}
    >
      <Loader
        size={"large"}
        width={"100px"}
        emptyColor={tokens.colors.black}
        filledColor={tokens.colors.orange[40]}
      />
    </Flex>
  );
}
