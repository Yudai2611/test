/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import {
  ButtonProps,
  FlexProps,
  LoaderProps,
  TextProps,
  ViewProps,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type LoadingDialogOverridesProps = {
  LoadingDialog?: PrimitiveOverrideProps<ViewProps>;
  "Frame 38"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 36"?: PrimitiveOverrideProps<FlexProps>;
  Download?: PrimitiveOverrideProps<TextProps>;
  "Frame 37"?: PrimitiveOverrideProps<FlexProps>;
  "0%"?: PrimitiveOverrideProps<TextProps>;
  Loader?: PrimitiveOverrideProps<LoaderProps>;
  Button?: PrimitiveOverrideProps<ButtonProps>;
} & EscapeHatchProps;
export declare type LoadingDialogProps = React.PropsWithChildren<
  Partial<ViewProps> & {
    onClose?: (event: SyntheticEvent) => void;
    percentage?: number;
  } & {
    overrides?: LoadingDialogOverridesProps | undefined | null;
  }
>;
export default function LoadingDialog(
  props: LoadingDialogProps,
): React.ReactElement;
