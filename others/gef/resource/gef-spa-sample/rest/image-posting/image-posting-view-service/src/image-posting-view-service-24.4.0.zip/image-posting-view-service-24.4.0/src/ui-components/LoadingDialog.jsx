/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Button, Flex, Loader, Text, View } from "@aws-amplify/ui-react";
export default function LoadingDialog(props) {
  const { onClose, percentage, overrides, ...rest } = props;
  return (
    <View
      width="460px"
      height="167px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      borderRadius="10px"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      onClick={onClose}
      {...getOverrideProps(overrides, "LoadingDialog")}
      {...rest}
    >
      <Flex
        gap="10px"
        direction="column"
        width="unset"
        height="unset"
        justifyContent="center"
        alignItems="center"
        overflow="hidden"
        position="absolute"
        top="0px"
        left="0px"
        padding="0px 0px 0px 0px"
        {...getOverrideProps(overrides, "Frame 38")}
      >
        <Flex
          gap="10px"
          direction="row"
          width="460px"
          height="63px"
          justifyContent="center"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          padding="4px 171px 4px 171px"
          {...getOverrideProps(overrides, "Frame 36")}
        >
          <Text
            fontFamily="Inter"
            fontSize="24px"
            fontWeight="700"
            color="rgba(0,0,0,1)"
            lineHeight="36px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="Download"
            {...getOverrideProps(overrides, "Download")}
          ></Text>
        </Flex>
        <Flex
          gap="6px"
          direction="column"
          width="460px"
          height="unset"
          justifyContent="flex-start"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          padding="14px 27px 14px 27px"
          {...getOverrideProps(overrides, "Frame 37")}
        >
          <Text
            fontFamily="Inter"
            fontSize="16px"
            fontWeight="700"
            color="rgba(0,0,0,1)"
            lineHeight="24px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children={`${percentage}${"%"}`}
            {...getOverrideProps(overrides, "0%")}
          ></Text>
          <Loader
            width="377px"
            shrink="0"
            size="large"
            variation="linear"
            {...getOverrideProps(overrides, "Loader")}
          ></Loader>
        </Flex>
      </Flex>
      <Button
        width="unset"
        height="unset"
        position="absolute"
        border="0px SOLID rgba(174,179,183,1)"
        borderRadius="4px"
        top="7.5px"
        left="407.5px"
        size="default"
        isDisabled={false}
        variation="default"
        children="X"
        {...getOverrideProps(overrides, "Button")}
      ></Button>
    </View>
  );
}
