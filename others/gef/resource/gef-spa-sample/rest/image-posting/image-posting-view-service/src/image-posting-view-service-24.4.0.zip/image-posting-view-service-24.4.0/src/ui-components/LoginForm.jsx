/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import {
  Button,
  Flex,
  PasswordField,
  Text,
  TextField,
} from "@aws-amplify/ui-react";
export default function LoginForm(props) {
  const {
    onLogin,
    onRegister,
    onChangeUsername,
    onChangePassword,
    username,
    password,
    usernameHasError,
    passwordHasError,
    usernameErrorMessage,
    passwordErrorMessage,
    isLoginFailed = true,
    overrides,
    ...rest
  } = props;
  return (
    <Flex
      gap="0"
      direction="row"
      width="584px"
      height="487px"
      justifyContent="center"
      alignItems="center"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "LoginForm")}
      {...rest}
    >
      <Flex
        gap="16px"
        direction="column"
        width="600px"
        height="unset"
        justifyContent="center"
        alignItems="center"
        shrink="0"
        alignSelf="stretch"
        position="relative"
        padding="16px 60px 16px 60px"
        {...getOverrideProps(overrides, "Frame 1")}
      >
        <Text
          fontFamily="Inter"
          fontSize="32px"
          fontWeight="700"
          color="rgba(13,26,38,1)"
          lineHeight="48px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          alignSelf="stretch"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="GreenEarth Framework&#xA; SPA Sample"
          {...getOverrideProps(overrides, "GreenEarth Framework SPA Sample")}
        ></Text>
        <TextField
          width="483px"
          height="unset"
          label="Username"
          placeholder="Username"
          shrink="0"
          size="default"
          isDisabled={false}
          labelHidden={false}
          variation="default"
          textAlign="left"
          value={username}
          hasError={usernameHasError}
          errorMessage="Username is required."
          role="usernameTextField"
          onChange={onChangeUsername}
          {...getOverrideProps(overrides, "TextField")}
        ></TextField>
        <PasswordField
          width="482px"
          height="unset"
          label="Password"
          placeholder="Password"
          shrink="0"
          size="default"
          isDisabled={false}
          labelHidden={false}
          variation="default"
          hideShowPassword={false}
          textAlign="left"
          value={password}
          hasError={passwordHasError}
          errorMessage="Password is required."
          role="passwordTextField"
          onChange={onChangePassword}
          {...getOverrideProps(overrides, "PasswordField")}
        ></PasswordField>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="700"
          color="rgba(178,12,12,1)"
          lineHeight="14.522727012634277px"
          textAlign="left"
          display={isLoginFailed == true ? "block" : "none"}
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          role="errorMessage"
          children="Login is failed!"
          {...getOverrideProps(overrides, "Login is failed!")}
        ></Text>
        <Button
          width="484px"
          height="unset"
          shrink="0"
          backgroundColor="rgba(4,125,149,1)"
          size="default"
          isDisabled={false}
          variation="default"
          color="#FFFFFF"
          role="loginButton"
          children="Login"
          onClick={onLogin}
          {...getOverrideProps(overrides, "Button39111169")}
        ></Button>
        <Flex
          gap="8px"
          direction="column"
          width="unset"
          height="unset"
          justifyContent="flex-start"
          alignItems="center"
          shrink="0"
          alignSelf="stretch"
          position="relative"
          padding="0px 0px 0px 0px"
          {...getOverrideProps(overrides, "sign up")}
        >
          <Text
            fontFamily="Inter"
            fontSize="16px"
            fontWeight="400"
            color="rgba(13,26,38,1)"
            lineHeight="24px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="Don't have an account? "
            {...getOverrideProps(overrides, "Don't have an account?")}
          ></Text>
        </Flex>
        <Button
          width="unset"
          height="unset"
          border="0px SOLID rgba(174,179,183,1)"
          borderRadius="4px"
          shrink="0"
          size="default"
          isDisabled={false}
          variation="default"
          role="signUpButton"
          children="Sign Up"
          onClick={onRegister}
          {...getOverrideProps(overrides, "Button39111173")}
        ></Button>
      </Flex>
    </Flex>
  );
}
