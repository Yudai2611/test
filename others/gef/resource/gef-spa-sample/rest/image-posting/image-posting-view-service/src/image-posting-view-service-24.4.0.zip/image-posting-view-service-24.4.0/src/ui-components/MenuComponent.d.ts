/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { FlexProps, ViewProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type MenuComponentOverridesProps = {
  MenuComponent?: PrimitiveOverrideProps<FlexProps>;
  "Frame 18"?: PrimitiveOverrideProps<ViewProps>;
} & EscapeHatchProps;
export declare type MenuComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    menuItems?: React.ReactNode;
    fullName?: string;
    username?: string;
    profilePicture?: string;
  } & {
    overrides?: MenuComponentOverridesProps | undefined | null;
  }
>;
export default function MenuComponent(
  props: MenuComponentProps,
): React.ReactElement;
