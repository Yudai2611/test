/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Flex, View } from "@aws-amplify/ui-react";
export default function MenuComponent(props) {
  const { menuItems, fullName, username, profilePicture, overrides, ...rest } =
    props;
  return (
    <Flex
      gap="10px"
      direction="row"
      width="204px"
      height='"100vh"'
      justifyContent="center"
      alignItems="flex-start"
      overflow="hidden"
      position="relative"
      padding="16px 0px 16px 0px"
      backgroundColor="rgba(0,0,0,0)"
      {...getOverrideProps(overrides, "MenuComponent")}
      {...rest}
    >
      <View
        width="176px"
        height="282px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        shrink="0"
        position="relative"
        padding="0px 0px 0px 0px"
        children={menuItems}
        {...getOverrideProps(overrides, "Frame 18")}
      ></View>
    </Flex>
  );
}
