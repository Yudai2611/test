/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { ButtonProps, FlexProps } from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type MenuItemComponentOverridesProps = {
  MenuItemComponent?: PrimitiveOverrideProps<FlexProps>;
  Button?: PrimitiveOverrideProps<ButtonProps>;
} & EscapeHatchProps;
export declare type MenuItemComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    menuLabel?: string;
    targetUrl?: string;
    onClick?: (event: SyntheticEvent) => void;
  } & {
    overrides?: MenuItemComponentOverridesProps | undefined | null;
  }
>;
export default function MenuItemComponent(
  props: MenuItemComponentProps,
): React.ReactElement;
