/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps, useNavigateAction } from "./utils";
import { Button, Flex } from "@aws-amplify/ui-react";
export default function MenuItemComponent(props) {
  const { menuLabel, targetUrl, onClick, overrides, ...rest } = props;
  const menuItemComponentOnClick = useNavigateAction({
    type: "url",
    url: targetUrl,
  });
  return (
    <Flex
      gap="10px"
      direction="row"
      width="176px"
      height="unset"
      justifyContent="center"
      alignItems="center"
      overflow="hidden"
      position="relative"
      padding="10px 10px 10px 10px"
      backgroundColor="rgba(0,0,0,0)"
      onClick={() => {
        menuItemComponentOnClick();
      }}
      {...getOverrideProps(overrides, "MenuItemComponent")}
      {...rest}
    >
      <Button
        width="175px"
        height="38px"
        border="0px SOLID rgba(174,179,183,1)"
        borderRadius="4px"
        shrink="0"
        size="default"
        isDisabled={false}
        variation="default"
        fontSize={12}
        children={menuLabel}
        onClick={onClick}
        {...getOverrideProps(overrides, "Button")}
      ></Button>
    </Flex>
  );
}
