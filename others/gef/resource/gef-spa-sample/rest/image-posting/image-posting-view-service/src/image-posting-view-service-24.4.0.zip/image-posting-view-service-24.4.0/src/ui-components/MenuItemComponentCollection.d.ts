/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { MenuItemComponentProps } from "./MenuItemComponent";
import { CollectionProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type MenuItemComponentCollectionOverridesProps = {
  MenuItemComponentCollection?: PrimitiveOverrideProps<CollectionProps>;
  MenuItemComponent?: MenuItemComponentProps;
} & EscapeHatchProps;
export declare type MenuItemComponentCollectionProps = React.PropsWithChildren<
  Partial<CollectionProps<any>> & {
    items?: any[];
    overrideItems?: (collectionItem: {
      item: any;
      index: number;
    }) => MenuItemComponentProps;
  } & {
    overrides?: MenuItemComponentCollectionOverridesProps | undefined | null;
  }
>;
export default function MenuItemComponentCollection(
  props: MenuItemComponentCollectionProps,
): React.ReactElement;
