/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import MenuItemComponent from "./MenuItemComponent";
import { getOverrideProps } from "./utils";
import { Collection } from "@aws-amplify/ui-react";
export default function MenuItemComponentCollection(props) {
  const { items, overrideItems, overrides, ...rest } = props;
  return (
    <Collection
      type="list"
      direction="column"
      justifyContent="left"
      items={items || []}
      {...getOverrideProps(overrides, "MenuItemComponentCollection")}
      {...rest}
    >
      {(item, index) => (
        <MenuItemComponent
          key={item.id}
          {...(overrideItems && overrideItems({ item, index }))}
        ></MenuItemComponent>
      )}
    </Collection>
  );
}
