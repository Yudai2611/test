/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { NodeRendererProps } from "react-arborist";
import { useNavigate } from "react-router-dom";
import { Text, View } from "@aws-amplify/ui-react";

export default function MenuNode({
  node,
  style,
  dragHandle,
}: NodeRendererProps<any>) {
  const navigate = useNavigate();
  return (
    <View
      fontSize="12px"
      className={"menu-item"}
      role="menuitem"
      aria-label={node.data.name}
      marginLeft="-200px"
      style={style}
      ref={dragHandle}
      onClick={() => node.toggle()}
    >
      {node.isLeaf ? (
        <Text
          marginLeft="50px"
          onClick={() => {
            navigate(node.data.uri);
          }}
        >
          ➤ {node.data.name}
        </Text>
      ) : (
        <Text color={"rgb(0,0,0)"} fontWeight={"bold"}>
          🗀 {node.data.name}
        </Text>
      )}
    </View>
  );
}
