/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { FlexProps, IconProps, TextProps } from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type MyPostCommentItemComponentOverridesProps = {
  MyPostCommentItemComponent?: PrimitiveOverrideProps<FlexProps>;
  "Frame 45"?: PrimitiveOverrideProps<FlexProps>;
  D?: PrimitiveOverrideProps<TextProps>;
  "Frame 23"?: PrimitiveOverrideProps<FlexProps>;
  text?: PrimitiveOverrideProps<TextProps>;
  "Frame 34"?: PrimitiveOverrideProps<FlexProps>;
  Comment?: PrimitiveOverrideProps<TextProps>;
  "Frame 46"?: PrimitiveOverrideProps<FlexProps>;
  "1\u6642\u9593\u524D"?: PrimitiveOverrideProps<TextProps>;
  DeleteFilled?: PrimitiveOverrideProps<FlexProps>;
  Vector?: PrimitiveOverrideProps<IconProps>;
} & EscapeHatchProps;
export declare type MyPostCommentItemComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    fullName?: string;
    createdAt?: string;
    profilePictureLabel?: string;
    onDeleteAction?: (event: SyntheticEvent) => void;
    comment?: string;
  } & {
    overrides?: MyPostCommentItemComponentOverridesProps | undefined | null;
  }
>;
export default function MyPostCommentItemComponent(
  props: MyPostCommentItemComponentProps,
): React.ReactElement;
