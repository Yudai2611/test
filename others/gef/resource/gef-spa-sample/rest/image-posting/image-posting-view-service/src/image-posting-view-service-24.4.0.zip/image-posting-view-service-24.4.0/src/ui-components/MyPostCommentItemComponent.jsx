/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Flex, Icon, Text } from "@aws-amplify/ui-react";
export default function MyPostCommentItemComponent(props) {
  const {
    fullName,
    createdAt,
    profilePictureLabel,
    onDeleteAction,
    comment,
    overrides,
    ...rest
  } = props;
  return (
    <Flex
      gap="10px"
      direction="row"
      width="unset"
      height="unset"
      justifyContent="center"
      alignItems="flex-start"
      overflow="hidden"
      position="relative"
      padding="9px 20px 9px 20px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "MyPostCommentItemComponent")}
      {...rest}
    >
      <Flex
        gap="10px"
        direction="column"
        width="35px"
        height="35px"
        justifyContent="center"
        alignItems="center"
        overflow="hidden"
        shrink="0"
        position="relative"
        borderRadius="100px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(5,5,5,1)"
        {...getOverrideProps(overrides, "Frame 45")}
      >
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          lineHeight="15px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          role="img"
          aria-label="My Comment Profile Picture"
          children={profilePictureLabel}
          {...getOverrideProps(overrides, "D")}
        ></Text>
      </Flex>
      <Flex
        gap="0"
        direction="column"
        width="251px"
        height="unset"
        justifyContent="flex-start"
        alignItems="flex-start"
        overflow="hidden"
        shrink="0"
        position="relative"
        padding="0px 50px 0px 0px"
        {...getOverrideProps(overrides, "Frame 23")}
      >
        <Text
          fontFamily="Roboto"
          fontSize="10px"
          fontWeight="800"
          color="rgba(0,0,0,0.85)"
          lineHeight="22px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          role="listitem"
          aria-label="My Comment Fullname"
          children={fullName}
          {...getOverrideProps(overrides, "text")}
        ></Text>
        <Flex
          gap="10px"
          direction="row"
          width="unset"
          height="unset"
          justifyContent="flex-start"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          borderRadius="14px"
          padding="2px 10px 2px 10px"
          backgroundColor="rgba(4,125,149,1)"
          {...getOverrideProps(overrides, "Frame 34")}
        >
          <Text
            fontFamily="Roboto"
            fontSize="10px"
            fontWeight="400"
            color="rgba(255,255,255,1)"
            lineHeight="22px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            role="listitem"
            aria-label="My Comment Text"
            children={comment}
            {...getOverrideProps(overrides, "Comment")}
          ></Text>
        </Flex>
      </Flex>
      <Flex
        gap="0"
        direction="column"
        width="unset"
        height="unset"
        justifyContent="flex-start"
        alignItems="center"
        overflow="hidden"
        shrink="0"
        position="relative"
        padding="0px 0px 0px 0px"
        {...getOverrideProps(overrides, "Frame 46")}
      >
        <Text
          fontFamily="Roboto"
          fontSize="10px"
          fontWeight="400"
          color="rgba(190,190,190,1)"
          lineHeight="22px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          role="listitem"
          aria-label="My Comment Created At"
          children={createdAt}
          {...getOverrideProps(overrides, "1\u6642\u9593\u524D")}
        ></Text>
        <Flex
          gap="10px"
          direction="row"
          width="unset"
          height="unset"
          justifyContent="center"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          padding="2px 2px 2px 2px"
          {...getOverrideProps(overrides, "DeleteFilled")}
        >
          <Icon
            width="19px"
            height="20px"
            viewBox={{ minX: 0, minY: 0, width: 19, height: 20 }}
            paths={[
              {
                d: "M18.2083 3.6L15.0417 3.6L15.0417 1.6C15.0417 0.7175 14.3316 0 13.4583 0L5.54167 0C4.66836 0 3.95833 0.7175 3.95833 1.6L3.95833 3.6L0.791667 3.6C0.353776 3.6 0 3.9575 0 4.4L0 5.2C0 5.31 0.0890625 5.4 0.197917 5.4L1.69219 5.4L2.30326 18.475C2.34284 19.3275 3.04049 20 3.88411 20L15.1159 20C15.962 20 16.6572 19.33 16.6967 18.475L17.3078 5.4L18.8021 5.4C18.9109 5.4 19 5.31 19 5.2L19 4.4C19 3.9575 18.6462 3.6 18.2083 3.6ZM13.2604 3.6L5.73958 3.6L5.73958 1.8L13.2604 1.8L13.2604 3.6Z",
                fill: "rgba(189,20,20,1)",
                fillRule: "nonzero",
              },
            ]}
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            shrink="0"
            position="relative"
            id="postCommentAction"
            role="button"
            aria-label="My Comment Delete Action"
            onClick={onDeleteAction}
            {...getOverrideProps(overrides, "Vector")}
          ></Icon>
        </Flex>
      </Flex>
    </Flex>
  );
}
