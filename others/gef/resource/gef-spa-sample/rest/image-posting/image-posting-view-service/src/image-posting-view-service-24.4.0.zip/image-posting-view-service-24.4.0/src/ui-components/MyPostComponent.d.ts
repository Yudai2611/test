/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import {
  FlexProps,
  IconProps,
  ImageProps,
  TextProps,
  ViewProps,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type MyPostComponentOverridesProps = {
  MyPostComponent?: PrimitiveOverrideProps<FlexProps>;
  "Frame 29"?: PrimitiveOverrideProps<ViewProps>;
  "image 4"?: PrimitiveOverrideProps<ImageProps>;
  "Frame 30"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 31"?: PrimitiveOverrideProps<FlexProps>;
  '\uD83E\uDD86 icon "message"'?: PrimitiveOverrideProps<FlexProps>;
  Vector3937268?: PrimitiveOverrideProps<IconProps>;
  "Frame 32"?: PrimitiveOverrideProps<FlexProps>;
  EditOutlined?: PrimitiveOverrideProps<ViewProps>;
  Vector3937331?: PrimitiveOverrideProps<IconProps>;
  "Frame 33"?: PrimitiveOverrideProps<FlexProps>;
  DeleteFilled?: PrimitiveOverrideProps<FlexProps>;
  Vector3937326?: PrimitiveOverrideProps<IconProps>;
  "Frame 34"?: PrimitiveOverrideProps<FlexProps>;
  '\uD83E\uDD86 icon "cloud download"'?: PrimitiveOverrideProps<FlexProps>;
  Vector3937293?: PrimitiveOverrideProps<IconProps>;
  Vector3937294?: PrimitiveOverrideProps<IconProps>;
  "Frame 20"?: PrimitiveOverrideProps<FlexProps>;
  text3937274?: PrimitiveOverrideProps<TextProps>;
  "Frame 21"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 45"?: PrimitiveOverrideProps<FlexProps>;
  D?: PrimitiveOverrideProps<TextProps>;
  "Frame 22"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 23"?: PrimitiveOverrideProps<FlexProps>;
  text3937280?: PrimitiveOverrideProps<TextProps>;
  "Frame 25"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 243937282"?: PrimitiveOverrideProps<FlexProps>;
  text3937283?: PrimitiveOverrideProps<TextProps>;
  "Frame 243937284"?: PrimitiveOverrideProps<FlexProps>;
  text3937285?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type MyPostComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    fullName?: string;
    profilePictureLabel?: string;
    createdAt?: string;
    caption?: string;
    postImage?: string;
    onCommentAction?: (event: SyntheticEvent) => void;
    onDownloadAction?: (event: SyntheticEvent) => void;
    onEditAction?: (event: SyntheticEvent) => void;
    onDeleteAction?: (event: SyntheticEvent) => void;
  } & {
    overrides?: MyPostComponentOverridesProps | undefined | null;
  }
>;
export default function MyPostComponent(
  props: MyPostComponentProps,
): React.ReactElement;
