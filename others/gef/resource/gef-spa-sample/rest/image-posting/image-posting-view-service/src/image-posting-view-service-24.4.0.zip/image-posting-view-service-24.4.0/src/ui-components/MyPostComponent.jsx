/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Flex, Icon, Image, Text, View } from "@aws-amplify/ui-react";
export default function MyPostComponent(props) {
  const {
    fullName,
    profilePictureLabel,
    createdAt,
    caption,
    postImage,
    onCommentAction,
    onDownloadAction,
    onEditAction,
    onDeleteAction,
    overrides,
    ...rest
  } = props;
  return (
    <Flex
      gap="5px"
      direction="column"
      width="278px"
      height="unset"
      justifyContent="flex-start"
      alignItems="flex-start"
      overflow="hidden"
      position="relative"
      boxShadow="0px 0px 4px rgba(0, 0, 0, 0.25)"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "MyPostComponent")}
      {...rest}
    >
      <View
        width="278px"
        height="151px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        shrink="0"
        position="relative"
        padding="0px 0px 0px 0px"
        {...getOverrideProps(overrides, "Frame 29")}
      >
        <Image
          width="278px"
          height="151px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          padding="0px 0px 0px 0px"
          objectFit="cover"
          role="img"
          aria-label="My Post Image"
          src={postImage}
          {...getOverrideProps(overrides, "image 4")}
        ></Image>
        <Flex
          gap="10px"
          direction="row"
          width="278px"
          height="151px"
          justifyContent="center"
          alignItems="center"
          overflow="hidden"
          position="absolute"
          top="0px"
          left="0px"
          padding="10px 0px 10px 0px"
          backgroundColor="rgba(0,0,0,0.35)"
          id="myPostPictureOverlay"
          {...getOverrideProps(overrides, "Frame 30")}
        >
          <Flex
            gap="10px"
            direction="column"
            width="unset"
            height="unset"
            justifyContent="center"
            alignItems="center"
            overflow="hidden"
            grow="1"
            shrink="1"
            basis="0"
            alignSelf="stretch"
            position="relative"
            padding="0px 0px 0px 0px"
            {...getOverrideProps(overrides, "Frame 31")}
          >
            <Flex
              padding="0px 0px 0px 0px"
              width="26.89px"
              height="25px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              shrink="0"
              position="relative"
              {...getOverrideProps(overrides, '\uD83E\uDD86 icon "message"')}
            >
              <Icon
                role="button"
                aria-label="My Post Comment Action"
                width="26.89px"
                height="25px"
                viewBox={{
                  minX: 0,
                  minY: 0,
                  width: 26.88873863220215,
                  height: 25,
                }}
                paths={[
                  {
                    d: "M25.8421 7.65627C25.1674 6.1622 24.1858 4.8042 22.9521 3.65795C21.722 2.5097 20.2609 1.59678 18.6516 0.971007C17.0031 0.326843 15.2318 -0.00335477 13.443 2.56956e-05L13.3828 2.56956e-05C11.5634 0.00839622 9.80411 0.343217 8.14708 1.0017C6.55161 1.63388 5.10419 2.54843 3.88572 3.69422C2.66394 4.83789 1.6936 6.19115 1.02877 7.67859C0.338634 9.22536 -0.0110588 10.8846 0.000266543 12.5586C0.00928849 14.495 0.508503 16.4174 1.44077 18.1362L1.44077 22.3772C1.44077 23.0859 2.06028 23.6607 2.82113 23.6607L7.38623 23.6607C9.24738 24.532 11.3012 24.9905 13.3858 25L13.449 25C15.2474 25 16.9886 24.6763 18.6306 24.043C20.2317 23.4247 21.6874 22.5224 22.916 21.3867C24.155 20.2455 25.1294 18.9118 25.812 17.4247C26.5188 15.8845 26.8796 14.2467 26.8887 12.5558C26.8947 10.8566 26.5398 9.20761 25.8421 7.65627ZM7.44036 13.8393C6.64643 13.8393 5.99986 13.2394 5.99986 12.5C5.99986 11.7606 6.64643 11.1607 7.44036 11.1607C8.23429 11.1607 8.88087 11.7606 8.88087 12.5C8.88087 13.2394 8.2373 13.8393 7.44036 13.8393ZM13.443 13.8393C12.649 13.8393 12.0025 13.2394 12.0025 12.5C12.0025 11.7606 12.649 11.1607 13.443 11.1607C14.2369 11.1607 14.8835 11.7606 14.8835 12.5C14.8835 13.2394 14.2369 13.8393 13.443 13.8393ZM19.4456 13.8393C18.6516 13.8393 18.0051 13.2394 18.0051 12.5C18.0051 11.7606 18.6516 11.1607 19.4456 11.1607C20.2395 11.1607 20.8861 11.7606 20.8861 12.5C20.8861 13.2394 20.2395 13.8393 19.4456 13.8393Z",
                    fill: "rgba(255,255,255,1)",
                    fillRule: "nonzero",
                  },
                ]}
                display="block"
                gap="unset"
                alignItems="unset"
                justifyContent="unset"
                position="absolute"
                top="0%"
                bottom="0%"
                left="0%"
                right="0%"
                onClick={onCommentAction}
                {...getOverrideProps(overrides, "Vector3937268")}
              ></Icon>
            </Flex>
          </Flex>
          <Flex
            gap="10px"
            direction="column"
            width="unset"
            height="unset"
            justifyContent="center"
            alignItems="center"
            overflow="hidden"
            grow="1"
            shrink="1"
            basis="0"
            alignSelf="stretch"
            position="relative"
            padding="0px 0px 0px 0px"
            {...getOverrideProps(overrides, "Frame 32")}
          >
            <View
              width="32px"
              height="32px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              overflow="hidden"
              shrink="0"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "EditOutlined")}
            >
              <Icon
                width="28.57px"
                height="28.57px"
                viewBox={{
                  minX: 0,
                  minY: 0,
                  width: 28.571430206298828,
                  height: 28.571430206298828,
                }}
                paths={[
                  {
                    d: "M5.20357 22.8571C5.275 22.8571 5.34643 22.85 5.41786 22.8393L11.425 21.7857C11.4964 21.7714 11.5643 21.7393 11.6143 21.6857L26.7536 6.54643C26.7867 6.51339 26.8129 6.47414 26.8309 6.43094C26.8488 6.38773 26.858 6.34142 26.858 6.29464C26.858 6.24787 26.8488 6.20155 26.8309 6.15835C26.8129 6.11514 26.7867 6.0759 26.7536 6.04286L20.8179 0.103571C20.75 0.0357143 20.6607 0 20.5643 0C20.4679 0 20.3786 0.0357143 20.3107 0.103571L5.17143 15.2429C5.11786 15.2964 5.08571 15.3607 5.07143 15.4321L4.01786 21.4393C3.98311 21.6306 3.99553 21.8275 4.05403 22.013C4.11252 22.1984 4.21534 22.3668 4.35357 22.5036C4.58929 22.7321 4.88572 22.8571 5.20357 22.8571ZM7.61071 16.6286L20.5643 3.67857L23.1821 6.29643L10.2286 19.2464L7.05357 19.8071L7.61071 16.6286ZM27.4286 25.8571L1.14286 25.8571C0.510714 25.8571 0 26.3679 0 27L0 28.2857C0 28.4429 0.128571 28.5714 0.285714 28.5714L28.2857 28.5714C28.4429 28.5714 28.5714 28.4429 28.5714 28.2857L28.5714 27C28.5714 26.3679 28.0607 25.8571 27.4286 25.8571Z",
                    fill: "rgba(255,255,255,1)",
                    fillRule: "nonzero",
                  },
                ]}
                display="block"
                gap="unset"
                alignItems="unset"
                justifyContent="unset"
                position="absolute"
                top="5.36%"
                bottom="5.36%"
                left="5.36%"
                right="5.36%"
                role="button"
                aria-label="My Post Edit Action"
                onClick={onEditAction}
                {...getOverrideProps(overrides, "Vector3937331")}
              ></Icon>
            </View>
          </Flex>
          <Flex
            gap="10px"
            direction="column"
            width="unset"
            height="unset"
            justifyContent="center"
            alignItems="center"
            overflow="hidden"
            grow="1"
            shrink="1"
            basis="0"
            alignSelf="stretch"
            position="relative"
            padding="0px 0px 0px 0px"
            {...getOverrideProps(overrides, "Frame 33")}
          >
            <Flex
              gap="10px"
              direction="row"
              width="unset"
              height="unset"
              justifyContent="center"
              alignItems="center"
              overflow="hidden"
              shrink="0"
              position="relative"
              padding="2px 2px 2px 2px"
              {...getOverrideProps(overrides, "DeleteFilled")}
            >
              <Icon
                width="27.43px"
                height="28.57px"
                viewBox={{
                  minX: 0,
                  minY: 0,
                  width: 27.428573608398438,
                  height: 28.571430206298828,
                }}
                paths={[
                  {
                    d: "M26.2857 5.14286L21.7143 5.14286L21.7143 2.28571C21.7143 1.025 20.6893 0 19.4286 0L8 0C6.73929 0 5.71429 1.025 5.71429 2.28571L5.71429 5.14286L1.14286 5.14286C0.510714 5.14286 0 5.65357 0 6.28571L0 7.42857C0 7.58571 0.128571 7.71429 0.285714 7.71429L2.44286 7.71429L3.325 26.3929C3.38214 27.6107 4.38929 28.5714 5.60714 28.5714L21.8214 28.5714C23.0429 28.5714 24.0464 27.6143 24.1036 26.3929L24.9857 7.71429L27.1429 7.71429C27.3 7.71429 27.4286 7.58571 27.4286 7.42857L27.4286 6.28571C27.4286 5.65357 26.9179 5.14286 26.2857 5.14286ZM19.1429 5.14286L8.28572 5.14286L8.28572 2.57143L19.1429 2.57143L19.1429 5.14286Z",
                    fill: "rgba(255,255,255,1)",
                    fillRule: "nonzero",
                  },
                ]}
                display="block"
                gap="unset"
                alignItems="unset"
                justifyContent="unset"
                shrink="0"
                position="relative"
                role="button"
                aria-label="My Post Delete Action"
                onClick={onDeleteAction}
                {...getOverrideProps(overrides, "Vector3937326")}
              ></Icon>
            </Flex>
          </Flex>
          <Flex
            gap="10px"
            direction="column"
            width="unset"
            height="unset"
            justifyContent="center"
            alignItems="center"
            overflow="hidden"
            grow="1"
            shrink="1"
            basis="0"
            alignSelf="stretch"
            position="relative"
            padding="0px 0px 0px 0px"
            {...getOverrideProps(overrides, "Frame 34")}
          >
            <Flex
              padding="0px 0px 0px 0px"
              width="31.82px"
              height="25px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              shrink="0"
              position="relative"
              {...getOverrideProps(
                overrides,
                '\uD83E\uDD86 icon "cloud download"',
              )}
            >
              <Icon
                width="8.52px"
                height="14.49px"
                viewBox={{
                  minX: 0,
                  minY: 0,
                  width: 8.52424430847168,
                  height: 14.488181114196777,
                }}
                paths={[
                  {
                    d: "M8.23957 8.88888L5.60806 8.88888L5.60806 0.284103C5.60806 0.127846 5.48022 0 5.32396 0L3.19318 0C3.03693 0 2.90908 0.127846 2.90908 0.284103L2.90908 8.88888L0.284677 8.88888C0.0467409 8.88888 -0.0846564 9.16233 0.0609465 9.347L4.03839 14.3792C4.06497 14.4131 4.09892 14.4406 4.13769 14.4595C4.17645 14.4784 4.219 14.4882 4.26212 14.4882C4.30524 14.4882 4.3478 14.4784 4.38656 14.4595C4.42532 14.4406 4.45928 14.4131 4.48585 14.3792L8.4633 9.347C8.6089 9.16233 8.4775 8.88888 8.23957 8.88888Z",
                    fill: "rgba(255,255,255,1)",
                    fillRule: "nonzero",
                  },
                ]}
                display="block"
                gap="unset"
                alignItems="unset"
                justifyContent="unset"
                position="absolute"
                top="42.05%"
                bottom="0%"
                left="36.61%"
                right="36.61%"
                {...getOverrideProps(overrides, "Vector3937293")}
              ></Icon>
              <Icon
                width="31.82px"
                height="21.31px"
                viewBox={{
                  minX: 0,
                  minY: 0,
                  width: 31.819561004638672,
                  height: 21.307741165161133,
                }}
                paths={[
                  {
                    d: "M26.5423 7.34052C24.9159 3.05056 20.7715 0 15.9169 0C11.0623 0 6.91791 3.04701 5.29142 7.33697C2.24797 8.13601 0 10.9096 0 14.2052C0 18.1293 3.1784 21.3077 7.09903 21.3077L8.5231 21.3077C8.67935 21.3077 8.8072 21.1799 8.8072 21.0236L8.8072 18.8929C8.8072 18.7366 8.67935 18.6088 8.5231 18.6088L7.09903 18.6088C5.90224 18.6088 4.77648 18.1329 3.93838 17.2699C3.10383 16.4105 2.65992 15.2528 2.69898 14.0525C2.73094 13.1149 3.05056 12.2342 3.62942 11.492C4.22248 10.7356 5.05349 10.1851 5.97682 9.94006L7.32276 9.58848L7.81639 8.28871C8.1218 7.47902 8.54795 6.72259 9.0842 6.03719C9.6136 5.35786 10.2407 4.76068 10.9451 4.2651C12.4047 3.23878 14.1235 2.69543 15.9169 2.69543C17.7103 2.69543 19.4291 3.23878 20.8887 4.2651C21.5954 4.76228 22.2204 5.3589 22.7496 6.03719C23.2858 6.72259 23.712 7.48257 24.0174 8.28871L24.5075 9.58493L25.8498 9.94006C27.7746 10.4585 29.1206 12.2093 29.1206 14.2052C29.1206 15.3806 28.6625 16.4886 27.8315 17.3196C27.4239 17.7296 26.9391 18.0546 26.4051 18.2758C25.8711 18.4971 25.2986 18.6103 24.7205 18.6088L23.2965 18.6088C23.1402 18.6088 23.0124 18.7366 23.0124 18.8929L23.0124 21.0236C23.0124 21.1799 23.1402 21.3077 23.2965 21.3077L24.7205 21.3077C28.6412 21.3077 31.8196 18.1293 31.8196 14.2052C31.8196 10.9131 29.5787 8.14311 26.5423 7.34052Z",
                    fill: "rgba(255,255,255,1)",
                    fillRule: "nonzero",
                  },
                ]}
                display="block"
                gap="unset"
                alignItems="unset"
                justifyContent="unset"
                position="absolute"
                top="0%"
                bottom="14.77%"
                left="0%"
                right="0%"
                role="button"
                aria-label="My Post Download Action"
                onClick={onDownloadAction}
                {...getOverrideProps(overrides, "Vector3937294")}
              ></Icon>
            </Flex>
          </Flex>
        </Flex>
      </View>
      <Flex
        gap="10px"
        direction="row"
        width="unset"
        height="unset"
        justifyContent="flex-start"
        alignItems="flex-start"
        overflow="hidden"
        shrink="0"
        alignSelf="stretch"
        position="relative"
        padding="6px 20px 6px 20px"
        {...getOverrideProps(overrides, "Frame 20")}
      >
        <Text
          fontFamily="Roboto"
          fontSize="10px"
          fontWeight="700"
          color="rgba(0,0,0,0.85)"
          lineHeight="22px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          role="listitem"
          aria-label="My Post Caption"
          children={caption}
          {...getOverrideProps(overrides, "text3937274")}
        ></Text>
      </Flex>
      <Flex
        gap="7px"
        direction="row"
        width="unset"
        height="unset"
        justifyContent="flex-start"
        alignItems="center"
        overflow="hidden"
        shrink="0"
        alignSelf="stretch"
        position="relative"
        padding="3px 20px 11px 20px"
        {...getOverrideProps(overrides, "Frame 21")}
      >
        <Flex
          gap="10px"
          direction="column"
          width="35px"
          height="35px"
          justifyContent="center"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          borderRadius="100px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(5,5,5,1)"
          {...getOverrideProps(overrides, "Frame 45")}
        >
          <Text
            fontFamily="Inter"
            fontSize="12px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            lineHeight="15px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            role="button"
            aria-label="My Post Profile Picture"
            children={profilePictureLabel}
            {...getOverrideProps(overrides, "D")}
          ></Text>
        </Flex>
        <Flex
          gap="4px"
          direction="row"
          width="unset"
          height="unset"
          justifyContent="center"
          alignItems="flex-start"
          overflow="hidden"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          {...getOverrideProps(overrides, "Frame 22")}
        >
          <Flex
            gap="10px"
            direction="row"
            width="unset"
            height="unset"
            justifyContent="center"
            alignItems="flex-start"
            overflow="hidden"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            {...getOverrideProps(overrides, "Frame 23")}
          >
            <Text
              fontFamily="Roboto"
              fontSize="10px"
              fontWeight="400"
              color="rgba(0,0,0,0.85)"
              lineHeight="22px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="unset"
              height="unset"
              gap="unset"
              alignItems="unset"
              shrink="0"
              position="relative"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              role="listitem"
              aria-label="My Post Fullname"
              children={fullName}
              {...getOverrideProps(overrides, "text3937280")}
            ></Text>
          </Flex>
          <Flex
            gap="0"
            direction="column"
            width="unset"
            height="unset"
            justifyContent="center"
            alignItems="flex-start"
            overflow="hidden"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            {...getOverrideProps(overrides, "Frame 25")}
          >
            <Flex
              gap="10px"
              direction="row"
              width="unset"
              height="unset"
              justifyContent="center"
              alignItems="flex-start"
              overflow="hidden"
              shrink="0"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "Frame 243937282")}
            >
              <Text
                fontFamily="Roboto"
                fontSize="10px"
                fontWeight="100"
                color="rgba(0,0,0,0.85)"
                lineHeight="22px"
                textAlign="left"
                display="block"
                direction="column"
                justifyContent="unset"
                width="unset"
                height="unset"
                gap="unset"
                alignItems="unset"
                shrink="0"
                position="relative"
                padding="0px 0px 0px 0px"
                whiteSpace="pre-wrap"
                children="・"
                {...getOverrideProps(overrides, "text3937283")}
              ></Text>
            </Flex>
          </Flex>
          <Flex
            gap="10px"
            direction="row"
            width="unset"
            height="unset"
            justifyContent="center"
            alignItems="flex-start"
            overflow="hidden"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            {...getOverrideProps(overrides, "Frame 243937284")}
          >
            <Text
              fontFamily="Roboto"
              fontSize="10px"
              fontWeight="100"
              color="rgba(170,161,161,0.85)"
              lineHeight="22px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="unset"
              height="unset"
              gap="unset"
              alignItems="unset"
              shrink="0"
              position="relative"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              role="listitem"
              aria-label="My Post Created At"
              children={createdAt}
              {...getOverrideProps(overrides, "text3937285")}
            ></Text>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
}
