/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import {
  ButtonProps,
  FlexProps,
  TextAreaFieldProps,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type PostCommentBoxComponentOverridesProps = {
  PostCommentBoxComponent?: PrimitiveOverrideProps<FlexProps>;
  TextAreaField?: PrimitiveOverrideProps<TextAreaFieldProps>;
  Button?: PrimitiveOverrideProps<ButtonProps>;
} & EscapeHatchProps;
export declare type PostCommentBoxComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    commentText?: string;
    onCommentTextChange?: (event: SyntheticEvent) => void;
    comemntTextHasError?: boolean;
    onSubmitComment?: (event: SyntheticEvent) => void;
  } & {
    overrides?: PostCommentBoxComponentOverridesProps | undefined | null;
  }
>;
export default function PostCommentBoxComponent(
  props: PostCommentBoxComponentProps,
): React.ReactElement;
