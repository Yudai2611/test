/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Button, Flex, TextAreaField } from "@aws-amplify/ui-react";
export default function PostCommentBoxComponent(props) {
  const {
    commentText,
    onCommentTextChange,
    comemntTextHasError,
    onSubmitComment,
    overrides,
    ...rest
  } = props;
  return (
    <Flex
      gap="10px"
      direction="row"
      width="377px"
      height="unset"
      justifyContent="flex-start"
      alignItems="flex-start"
      overflow="hidden"
      position="relative"
      padding="10px 15px 10px 15px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "PostCommentBoxComponent")}
      {...rest}
    >
      <TextAreaField
        width="272px"
        height="unset"
        placeholder="Type your comment here..."
        shrink="0"
        size="default"
        isDisabled={false}
        labelHidden={true}
        variation="default"
        role="textbox"
        aria-label="Comment Box"
        value={commentText}
        hasError={comemntTextHasError}
        onChange={onCommentTextChange}
        {...getOverrideProps(overrides, "TextAreaField")}
      ></TextAreaField>
      <Button
        width="unset"
        height="unset"
        shrink="0"
        size="default"
        isDisabled={false}
        variation="primary"
        fontSize={12}
        children="Send"
        role="button"
        aria-label="Submit Comment"
        onClick={onSubmitComment}
        {...getOverrideProps(overrides, "Button")}
      ></Button>
    </Flex>
  );
}
