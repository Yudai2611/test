/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { FlexProps, TextProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type PostCommentItemComponentOverridesProps = {
  PostCommentItemComponent?: PrimitiveOverrideProps<FlexProps>;
  "Frame 45"?: PrimitiveOverrideProps<FlexProps>;
  D?: PrimitiveOverrideProps<TextProps>;
  "Frame 23"?: PrimitiveOverrideProps<FlexProps>;
  text?: PrimitiveOverrideProps<TextProps>;
  "Frame 34"?: PrimitiveOverrideProps<FlexProps>;
  Comment?: PrimitiveOverrideProps<TextProps>;
  "1\u6642\u9593\u524D"?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type PostCommentItemComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    profilePicture?: string;
    fullName?: string;
    comment?: string;
    createdAt?: string;
    profilePictureLabel?: string;
  } & {
    overrides?: PostCommentItemComponentOverridesProps | undefined | null;
  }
>;
export default function PostCommentItemComponent(
  props: PostCommentItemComponentProps,
): React.ReactElement;
