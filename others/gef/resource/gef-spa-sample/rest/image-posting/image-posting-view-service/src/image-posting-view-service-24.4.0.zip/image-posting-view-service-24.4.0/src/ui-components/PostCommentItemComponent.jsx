/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import { Flex, Text } from "@aws-amplify/ui-react";
export default function PostCommentItemComponent(props) {
  const {
    profilePicture,
    fullName,
    comment,
    createdAt,
    profilePictureLabel,
    overrides,
    ...rest
  } = props;
  return (
    <Flex
      gap="10px"
      direction="row"
      width="unset"
      height="unset"
      justifyContent="center"
      alignItems="flex-start"
      overflow="hidden"
      position="relative"
      padding="9px 20px 9px 20px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "PostCommentItemComponent")}
      {...rest}
    >
      <Flex
        gap="10px"
        direction="column"
        width="35px"
        height="35px"
        justifyContent="center"
        alignItems="center"
        overflow="hidden"
        shrink="0"
        position="relative"
        borderRadius="100px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(5,5,5,1)"
        {...getOverrideProps(overrides, "Frame 45")}
      >
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          lineHeight="15px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          role="img"
          aria-label="Comment Profile Picture"
          children={profilePictureLabel}
          {...getOverrideProps(overrides, "D")}
        ></Text>
      </Flex>
      <Flex
        gap="0"
        direction="column"
        width="251px"
        height="unset"
        justifyContent="flex-start"
        alignItems="flex-start"
        overflow="hidden"
        shrink="0"
        position="relative"
        padding="0px 50px 0px 0px"
        {...getOverrideProps(overrides, "Frame 23")}
      >
        <Text
          fontFamily="Roboto"
          fontSize="10px"
          fontWeight="800"
          color="rgba(0,0,0,0.85)"
          lineHeight="22px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          role="listitem"
          aria-label="Comment Fullname"
          children={fullName}
          {...getOverrideProps(overrides, "text")}
        ></Text>
        <Flex
          gap="10px"
          direction="row"
          width="unset"
          height="unset"
          justifyContent="flex-start"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          borderRadius="14px"
          padding="2px 10px 2px 10px"
          backgroundColor="rgba(4,125,149,1)"
          {...getOverrideProps(overrides, "Frame 34")}
        >
          <Text
            fontFamily="Roboto"
            fontSize="10px"
            fontWeight="400"
            color="rgba(255,255,255,1)"
            lineHeight="22px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            role="listitem"
            aria-label="Comment Text"
            children={comment}
            {...getOverrideProps(overrides, "Comment")}
          ></Text>
        </Flex>
      </Flex>
      <Text
        fontFamily="Roboto"
        fontSize="10px"
        fontWeight="400"
        color="rgba(190,190,190,1)"
        lineHeight="22px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="unset"
        height="unset"
        gap="unset"
        alignItems="unset"
        shrink="0"
        position="relative"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        role="listitem"
        aria-label="Comment Created At"
        children={createdAt}
        {...getOverrideProps(overrides, "1\u6642\u9593\u524D")}
      ></Text>
    </Flex>
  );
}
