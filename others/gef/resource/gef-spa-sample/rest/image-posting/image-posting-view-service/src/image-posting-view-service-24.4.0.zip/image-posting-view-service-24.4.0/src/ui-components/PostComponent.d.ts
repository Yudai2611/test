/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import {
  FlexProps,
  IconProps,
  ImageProps,
  TextProps,
  ViewProps,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type PostComponentOverridesProps = {
  PostComponent?: PrimitiveOverrideProps<FlexProps>;
  "Frame 29"?: PrimitiveOverrideProps<ViewProps>;
  "image 4"?: PrimitiveOverrideProps<ImageProps>;
  "Frame 30"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 31"?: PrimitiveOverrideProps<FlexProps>;
  '\uD83E\uDD86 icon "message"'?: PrimitiveOverrideProps<FlexProps>;
  Vector389176?: PrimitiveOverrideProps<IconProps>;
  "Frame 32"?: PrimitiveOverrideProps<FlexProps>;
  '\uD83E\uDD86 icon "cloud download"'?: PrimitiveOverrideProps<FlexProps>;
  Vector389178?: PrimitiveOverrideProps<IconProps>;
  Vector389179?: PrimitiveOverrideProps<IconProps>;
  "Frame 20"?: PrimitiveOverrideProps<FlexProps>;
  text3879105?: PrimitiveOverrideProps<TextProps>;
  "Frame 21"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 45"?: PrimitiveOverrideProps<FlexProps>;
  D?: PrimitiveOverrideProps<TextProps>;
  "Frame 22"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 23"?: PrimitiveOverrideProps<FlexProps>;
  text3879114?: PrimitiveOverrideProps<TextProps>;
  "Frame 25"?: PrimitiveOverrideProps<FlexProps>;
  "Frame 243879117"?: PrimitiveOverrideProps<FlexProps>;
  text3879118?: PrimitiveOverrideProps<TextProps>;
  "Frame 243879113"?: PrimitiveOverrideProps<FlexProps>;
  text3879115?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type PostComponentProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    postImage?: string;
    caption?: string;
    profilePicture?: string;
    fullName?: string;
    createdAt?: string;
    onCommentAction?: (event: SyntheticEvent) => void;
    onDownloadAction?: (event: SyntheticEvent) => void;
    profilePictureLabel?: string;
  } & {
    overrides?: PostComponentOverridesProps | undefined | null;
  }
>;
export default function PostComponent(
  props: PostComponentProps,
): React.ReactElement;
