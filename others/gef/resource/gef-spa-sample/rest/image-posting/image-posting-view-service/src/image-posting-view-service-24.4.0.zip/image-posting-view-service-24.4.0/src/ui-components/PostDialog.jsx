/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import {
  Button,
  Flex,
  Image,
  Text,
  TextAreaField,
  View,
} from "@aws-amplify/ui-react";
export default function PostDialog(props) {
  const {
    postPicture,
    onPost,
    caption,
    onClose,
    captionHasError,
    onCaptionChange,
    onPostPictureChange,
    overrides,
    ...rest
  } = props;
  return (
    <View
      width="356px"
      height="432px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      borderRadius="10px"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "PostDialog")}
      {...rest}
    >
      <Flex
        gap="10px"
        direction="column"
        width="356px"
        height="433px"
        justifyContent="flex-start"
        alignItems="flex-start"
        overflow="hidden"
        position="absolute"
        top="0px"
        left="0px"
        padding="7px 0px 7px 0px"
        {...getOverrideProps(overrides, "Frame 43")}
      >
        <Flex
          gap="10px"
          direction="row"
          width="unset"
          height="46px"
          justifyContent="center"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          alignSelf="stretch"
          position="relative"
          padding="28px 162px 28px 162px"
          {...getOverrideProps(overrides, "Frame 40")}
        >
          <Text
            fontFamily="Roboto"
            fontSize="20px"
            fontWeight="800"
            color="rgba(0,0,0,1)"
            lineHeight="22px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="unset"
            height="unset"
            gap="unset"
            alignItems="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="Post"
            {...getOverrideProps(overrides, "Post")}
          ></Text>
        </Flex>
        <Flex
          gap="10px"
          direction="column"
          width="356px"
          height="unset"
          justifyContent="flex-start"
          alignItems="center"
          overflow="hidden"
          shrink="0"
          position="relative"
          padding="0px 0px 0px 0px"
          {...getOverrideProps(overrides, "Frame 41")}
        >
          <Image
            width="356px"
            height="177px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            shrink="0"
            position="relative"
            padding="0px 0px 0px 0px"
            objectFit="cover"
            src={postPicture}
            {...getOverrideProps(overrides, "image 4")}
          ></Image>
          <TextAreaField
            width="328px"
            height="unset"
            placeholder="Type your caption here..."
            shrink="0"
            size="default"
            isDisabled={false}
            labelHidden={true}
            variation="default"
            value={caption}
            isRequired={true}
            hasError={captionHasError}
            errorMessage="Caption cannot be empty."
            onChange={onCaptionChange}
            {...getOverrideProps(overrides, "TextAreaField")}
          ></TextAreaField>
          <Flex
            gap="10px"
            direction="row"
            width="unset"
            height="unset"
            justifyContent="flex-end"
            alignItems="center"
            overflow="hidden"
            shrink="0"
            alignSelf="stretch"
            position="relative"
            padding="10px 10px 10px 10px"
            {...getOverrideProps(overrides, "Frame 42")}
          >
            <Button
              width="unset"
              height="unset"
              shrink="0"
              size="default"
              isDisabled={false}
              variation="primary"
              children="Submit"
              onClick={onPost}
              {...getOverrideProps(overrides, "Button3906186")}
            ></Button>
          </Flex>
        </Flex>
      </Flex>
      <Button
        width="unset"
        height="unset"
        position="absolute"
        border="0px SOLID rgba(174,179,183,1)"
        borderRadius="4px"
        top="6px"
        left="306px"
        size="default"
        isDisabled={false}
        variation="default"
        children="X"
        onClick={onClose}
        {...getOverrideProps(overrides, "Button3906194")}
      ></Button>
    </View>
  );
}
