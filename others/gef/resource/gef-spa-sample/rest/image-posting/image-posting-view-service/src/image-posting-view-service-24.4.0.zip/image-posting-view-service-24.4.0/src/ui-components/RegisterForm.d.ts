/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import {
  ButtonProps,
  FlexProps,
  PasswordFieldProps,
  TextFieldProps,
  TextProps,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type RegisterFormOverridesProps = {
  RegisterForm?: PrimitiveOverrideProps<FlexProps>;
  "Frame 1"?: PrimitiveOverrideProps<FlexProps>;
  Register?: PrimitiveOverrideProps<TextProps>;
  TextField39111124?: PrimitiveOverrideProps<TextFieldProps>;
  TextField39111131?: PrimitiveOverrideProps<TextFieldProps>;
  TextField39111138?: PrimitiveOverrideProps<TextFieldProps>;
  PasswordField39111145?: PrimitiveOverrideProps<PasswordFieldProps>;
  PasswordField39111157?: PrimitiveOverrideProps<PasswordFieldProps>;
  Button?: PrimitiveOverrideProps<ButtonProps>;
} & EscapeHatchProps;
export declare type RegisterFormProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    username?: string;
    firstName?: string;
    lastName?: string;
    password?: string;
    confirmationPassword?: string;
    companyCode?: string;
    companies?: Company[];
    onRegister?: (event: SyntheticEvent) => void;
    usernameHasError?: boolean;
    passwordHasError?: boolean;
    confirmationPasswordHasError?: boolean;
    firstNameHasError?: boolean;
    lastNameHasError?: boolean;
    companyCodeHasError?: boolean;
    onChangeUsername?: (event: SyntheticEvent) => void;
    onChangeFirstName?: (event: SyntheticEvent) => void;
    onChangeLastName?: (event: SyntheticEvent) => void;
    onChangePassword?: (event: SyntheticEvent) => void;
    onChangeConfirmationPassword?: (event: SyntheticEvent) => void;
    onChangeCompanyCode?: (event: SyntheticEvent) => void;
  } & {
    overrides?: RegisterFormOverridesProps | undefined | null;
  }
>;
export default function RegisterForm(
  props: RegisterFormProps,
): React.ReactElement;
