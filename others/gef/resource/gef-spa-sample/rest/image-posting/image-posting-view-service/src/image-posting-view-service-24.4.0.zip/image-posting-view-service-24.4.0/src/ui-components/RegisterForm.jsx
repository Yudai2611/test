/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { getOverrideProps } from "./utils";
import {
  Button,
  Flex,
  PasswordField,
  SelectField,
  Text,
  TextField,
} from "@aws-amplify/ui-react";
export default function RegisterForm(props) {
  const {
    username,
    firstName,
    lastName,
    password,
    confirmationPassword,
    companyCode,
    onRegister,
    companies,
    usernameHasError,
    passwordHasError,
    confirmationPasswordHasError,
    firstNameHasError,
    lastNameHasError,
    companyCodeHasError,
    onChangeUsername,
    onChangeFirstName,
    onChangeLastName,
    onChangePassword,
    onChangeConfirmationPassword,
    onChangeCompanyCode,
    overrides,
    ...rest
  } = props;
  return (
    <Flex
      gap="0"
      direction="row"
      width="651px"
      height="718px"
      justifyContent="center"
      alignItems="center"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "RegisterForm")}
      {...rest}
    >
      <Flex
        gap="16px"
        direction="column"
        width="600px"
        height="unset"
        justifyContent="center"
        alignItems="center"
        shrink="0"
        alignSelf="stretch"
        position="relative"
        padding="16px 60px 16px 60px"
        {...getOverrideProps(overrides, "Frame 1")}
      >
        <Text
          fontFamily="Inter"
          fontSize="32px"
          fontWeight="700"
          color="rgba(13,26,38,1)"
          lineHeight="48px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          shrink="0"
          alignSelf="stretch"
          position="relative"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Register"
          {...getOverrideProps(overrides, "Register")}
        ></Text>
        <TextField
          width="478px"
          height="unset"
          label="Username"
          placeholder="Username"
          shrink="0"
          size="default"
          isDisabled={false}
          labelHidden={false}
          variation="default"
          textAlign="left"
          value={username}
          hasError={usernameHasError}
          errorMessage="Username is required."
          role="usernameTextField"
          onChange={onChangeUsername}
          {...getOverrideProps(overrides, "TextField39111124")}
        ></TextField>
        <SelectField
          width="478px"
          height="unset"
          label="Company Code"
          value={companyCode}
          onChange={onChangeCompanyCode}
          textAlign="left"
        >
          {companies ? (
            companies.map((company) => {
              return (
                <option value={company.companyCode}>
                  {company.companyName}
                </option>
              );
            })
          ) : (
            <></>
          )}
        </SelectField>
        <TextField
          width="478px"
          height="unset"
          label="First Name"
          placeholder="First Name"
          shrink="0"
          size="default"
          isDisabled={false}
          labelHidden={false}
          variation="default"
          textAlign="left"
          value={firstName}
          hasError={firstNameHasError}
          errorMessage="First name is required."
          role="firstNameTextField"
          onChange={onChangeFirstName}
          {...getOverrideProps(overrides, "TextField39111131")}
        ></TextField>
        <TextField
          width="478px"
          height="unset"
          label="Last Name"
          placeholder="Last Name"
          shrink="0"
          size="default"
          isDisabled={false}
          labelHidden={false}
          variation="default"
          textAlign="left"
          value={lastName}
          hasError={lastNameHasError}
          errorMessage="Last name is required."
          role="lastNameTextField"
          onChange={onChangeLastName}
          {...getOverrideProps(overrides, "TextField39111138")}
        ></TextField>
        <PasswordField
          width="478px"
          height="unset"
          label="Password"
          placeholder="Password"
          shrink="0"
          size="default"
          isDisabled={false}
          labelHidden={false}
          variation="default"
          hideShowPassword={false}
          textAlign="left"
          value={password}
          hasError={passwordHasError}
          errorMessage="Password is required."
          role="passwordTextField"
          onChange={onChangePassword}
          {...getOverrideProps(overrides, "PasswordField39111145")}
        ></PasswordField>
        <PasswordField
          width="478px"
          height="unset"
          label="Confirmation Password"
          placeholder="Confirmation Password"
          shrink="0"
          size="default"
          isDisabled={false}
          labelHidden={false}
          variation="default"
          hideShowPassword={false}
          textAlign="left"
          value={confirmationPassword}
          hasError={confirmationPasswordHasError}
          errorMessage="Confirmation password is required and match with password."
          role="confirmationPasswordTextField"
          onChange={onChangeConfirmationPassword}
          {...getOverrideProps(overrides, "PasswordField39111157")}
        ></PasswordField>
        <Button
          width="484px"
          height="unset"
          shrink="0"
          backgroundColor="rgba(4,125,149,1)"
          size="default"
          isDisabled={false}
          variation="default"
          color="#FFFFFF"
          role="signUpButton"
          children="Sign Up"
          onClick={onRegister}
          {...getOverrideProps(overrides, "Button")}
        ></Button>
      </Flex>
    </Flex>
  );
}
