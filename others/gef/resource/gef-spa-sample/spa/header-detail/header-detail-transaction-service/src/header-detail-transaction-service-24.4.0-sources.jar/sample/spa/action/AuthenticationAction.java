/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.action;

import java.util.Optional;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.Produces;

import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.web.GWebRequest;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.http.context.GHttpContextHolder;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Endpoint;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Resource;
import jp.co.kccs.greenearth.framework.web.security.auth.GStandardBodyAuthenticationProcessor;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContext;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;

/**
 * ログイン認証用のアクションクラスです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
public class AuthenticationAction {

	/**
	 * ログイン照明のエンドポイントです. <br>
	 *
	 * @create 2024/04/30
	 * @param parameter ログイン情報のパラメータ
	 * @param resultData 結果データ
	 * @return ログインが結果
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	@Produces(GMediaType.APPLICATION_JSON)
	public GResultData login(GParameter parameter, GResultData resultData) {
		GWebRequest webRequest = GHttpContextHolder.getContext().getWebRequest();
		Optional<GSubject>
			subject = (new GStandardBodyAuthenticationProcessor()).authenticate(webRequest.getNativeRequest(), webRequest.getNativeResponse());
		GSecurityContext securityContext = GSecurityContextHolder.getContext();
		subject.ifPresent(securityContext::setSubject);
		if (subject.isEmpty()) {
			throw new NotAuthorizedException("Username or password is wrong");
		}
		resultData.setData("loggedInUser", UserResponse.from(subject.get().getPrincipal()));
		return resultData;
	}

	/**
	 * ログアウト処理のエンドポイントです. <br>
	 *
	 * @create 2024/04/30
	 * @param parameter パラメータ
	 * @param resultData 結果データ
	 * @return ログアウト結果
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	@Produces(GMediaType.APPLICATION_JSON)
	public GResultData logout(GParameter parameter, GResultData resultData) {
		GSecurityContextHolder.getContext().revoke();
		resultData.setData("message", "logout is success");
		return resultData;
	}
}
