/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.action;

import java.util.List;

/**
 * メニューのDTOオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class GMenuDTO {
    private String menuId;
    private String menuLabel;
    private List<GMenuDTO> menuChild;
    private String menuPageUri;

    public GMenuDTO() {}

    /**
     * メニューIDを取得します. <br>
     *
     * @create 2024/04/30
     * @return メニューID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public String getMenuId() {
        return menuId;
    }

    /**
     * メニューIDを設定します. <br>
     *
     * @create 2024/04/30
     * @param menuId メニューID
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    /**
     * メニューラベルを取得します. <br>
     *
     * @create 2024/04/30
     * @return メニューラベル
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public String getMenuLabel() {
        return menuLabel;
    }

    /**
     * メニューラベルを設定します. <br>
     *
     * @create 2024/04/30
     * @param menuLabel メニューラベル
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setMenuLabel(String menuLabel) {
        this.menuLabel = menuLabel;
    }

    /**
     * 子メニューの一覧を取得します. <br>
     *
     * @create 2024/04/30
     * @return 子メニューの一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public List<GMenuDTO> getMenuChild() {
        return menuChild;
    }

    /**
     * 子メニューの一覧を設定します. <br>
     *
     * @create 2024/04/30
     * @param menuChild　メニューの一覧
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setMenuChild(List<GMenuDTO> menuChild) {
        this.menuChild = menuChild;
    }

    /**
     * メニューのURIを取得します. <br>
     *
     * @create 2024/04/30
     * @return メニューのURI
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public String getMenuPageUri() {
        return menuPageUri;
    }

    /**
     * メニューのURIを設定します. <br>
     *
     * @create 2024/04/30
     * @param menuPageUri メニューのURI
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public void setMenuPageUri(String menuPageUri) {
        this.menuPageUri = menuPageUri;
    }
}
