/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.action;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.data.GListData;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Endpoint;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Resource;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import sample.spa.common.SampleConstants;
import sample.spa.common.SampleUtils;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Produces;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

/**
 * 単位マスタズームのアクションクラスです. <br>
 *
 * @create 2024/04/30
 * @return メニューのURI
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
public class ItemListZoomAction {

	/** 商品ズームリスト */
	public static final String ID_ZOOMLIST = "ZoomItemList";
	public ItemListZoomAction() {
	}

	/**
	 * 商品マスタの検索時のアクションです. <br>
	 *
	 * @create 2024/04/30
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws SQLException SQL例外
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	@Produces(GMediaType.APPLICATION_JSON)
	public GResultData doSearch(GParameter parameter, GResultData resultData) throws SQLException {

		Map<String, Object> paramMap = new HashMap<String, Object>();
		Optional<GSubject> subject = GSecurityContextHolder.getContext().getSubject();
		if (subject.isPresent()) {
			paramMap.put("CompanyCD", (SampleUtils.getLoggedInUser().getCompany().getCode()));
		}
		paramMap.put("ItemCD_0", GStringUtils.blankToNull(parameter.getValue("ItemCD_0")));
		GEntitySelect select = select(SampleConstants.ITEMMASTER)
									.where(expMap($(SampleConstants.COMPANYCD + " = :CompanyCD")
											.AND($(SampleConstants.ITEMMASTER_ITEMCD + " LIKE :[" + "ItemCD_0%" + "]")), paramMap))
									.orderBy(asc(SampleConstants.ITEMMASTER_ITEMCD));
		GListData listData = GGjdbcActionUtils.findListData(select, ID_ZOOMLIST, parameter);
		resultData.setData(ID_ZOOMLIST, listData);

		GEXActionUtils.copyValue(resultData, parameter);

		resultData.setExitCode(GResultData.EXIT_CODE_SUCCESS);
		return resultData;
	}
}
