/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.action;

import jp.co.kccs.greenearth.commons.GFrameworkUtils;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.auth.GStatus;
import jp.co.kccs.greenearth.framework.data.GResultData;
import jp.co.kccs.greenearth.framework.menu.GMenu;
import jp.co.kccs.greenearth.framework.menu.GMenuFinder;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Endpoint;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Resource;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import sample.spa.common.SampleUtils;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Produces;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * メニューのアクションクラスです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
public class MenuAction {

	/**
	 * 認証情報の会社コードによる、メニュー一覧を取得する為のエンドポイントです. <br>
	 *
	 * @create 2024/04/30
	 * @param parameter パラメーター
	 * @param resultData 結果データ
	 * @return 結果データ
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Endpoint
	@Consumes(GMediaType.WILDCARD)
	@Produces(GMediaType.APPLICATION_JSON)
	@GET
	public GResultData launchMenuSPA(GParameter parameter, GResultData resultData) {
		GMenuFinder menuFinder = GFrameworkUtils.getComponent(GMenuFinder.class);
		String companyCD = null;
		Optional<GSubject> subject = GSecurityContextHolder.getContext().getSubject();
		if (subject.isPresent()) {
			companyCD = (SampleUtils.getLoggedInUser().getCompany().getCode());
		}
		List<GMenu> menus = menuFinder.getRootMenuList(companyCD);
		resultData.setData("menus", convertToMenuDTO(menus));
		return resultData;
	}

	private List<GMenuDTO> convertToMenuDTO(List<GMenu> menus) {
		return menus.stream()
			.filter(menu ->
				menu.getApplicationType().equals("SPASampleRIA") && menu.getStatus() == GStatus.Active
			)
			.map(menu-> {
				GMenuDTO menuDTO = new GMenuDTO();
				menuDTO.setMenuId(menu.getMenuID());
				menuDTO.setMenuLabel(menu.getDisplayName(GFrameworkUtils.getDefaultLocale()));
				menuDTO.setMenuPageUri(menu.getStartModule());
				menuDTO.setMenuChild(convertToMenuDTO(menu.getChildren()));
				return menuDTO;
			}).collect(Collectors.toList());
	}
}
