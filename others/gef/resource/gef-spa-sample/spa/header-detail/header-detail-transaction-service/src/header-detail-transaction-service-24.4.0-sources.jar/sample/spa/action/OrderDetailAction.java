/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.action;

import jp.co.kccs.greenearth.commons.GApplicationException;
import jp.co.kccs.greenearth.commons.GFrameworkContext;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessage;
import jp.co.kccs.greenearth.commons.resource.error.GErrorMessages;
import jp.co.kccs.greenearth.commons.resource.message.GMessageResources;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.data.*;
import jp.co.kccs.greenearth.framework.db.GTransactionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GOptimisticLockException;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.view.action.Validatefull;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Endpoint;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Resource;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;
import jakarta.ws.rs.Consumes;
import sample.spa.common.SampleConstants;
import sample.spa.common.SampleUtils;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;

/**
 * 発注明細画面のアクションクラスです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
public class OrderDetailAction {

	/** 更新ボタン(上部) */
	public static final String ID_UPDATE_H = "UpdateH";
	/** 更新ボタン(下部) */

	/** 明細削除ボタン(上部) */
	public static final String ID_DELETEROW_H = "DeleteRowH";

	// 明細
	/** 発注明細情報のID. */
	public static final String ORDERDETAIL_LIST = "OrderDetailList";

	/** 選択チェックボックスの状態 */
	public static final String ID_CHECK_FG = "CheckFG";

	/** 新規の明細かを確認するフラグ */
	public static final String ID_ADDROW_FG = "AddRowFG";
	/** 伝票番号採番コード. */
	private final String NUMCODE_SLIPNO = "D02";

	/** 伝票番号のフォーマット */
	private final String SLIPNO_FORMAT = "00000";

	/** 明細行の更新タイプ */
	private enum ActionType {
		/** 更新. */
		DELETE,
		/** 変更. */
		MODIFY,
		/** 新規. */
		NEW
	};

	/**
	 * 伝票削除ボタン押下時のアクションです。<br>
	 * 発注ヘッダ、発注明細を削除します. <br>
	 *
	 * @create 2024/04/30
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	@ActionInterceptor(GTransactionInterceptor.class)
	public GResultData doDelete(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		try {
			updateHeader(parameter, ActionType.DELETE);
			deleteDetail(parameter);
		} catch (GOptimisticLockException e) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OTHERUSING);
			throw new GValidateException(error);
		}
		return resultData;
	}
	private void deleteDetail(GParameter parameter) throws SQLException {
		GSubject subject = GSecurityContextHolder.getContext().getSubject().get();
		GUser user = subject.getPrincipal();
		delete(SampleConstants.ORDERDETAIL)
			.where(exp($(SampleConstants.ORDERHEADER_SLIPNO + " = ?").AND($(SampleConstants.COMPANYCD + " = ?")),
				parameter.getValue(SampleConstants.ORDERHEADER_SLIPNO), user.getCompany().getCode()))
			.execute();
	}

	/**
	 * 登録ボタン押下時のアクションです。<br>
	 * 商品コードが存在するかをチェックし、<br>
	 * 存在すれば、発注ヘッダ、発注明細を登録します. <br>
	 *
	 * @create 2024/04/30
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Validatefull
	@ActionInterceptor(GTransactionInterceptor.class)
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	public GResultData doInsert(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		checkInputDetail(parameter, resultData);

		parameter.setValue(SampleConstants.ORDERHEADER_SLIPNO, numberingSlipNO());

		try {
			updateHeader(parameter, ActionType.NEW);
			updateDetail(parameter);
		} catch (GOptimisticLockException e) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OTHERUSING);
			throw new GValidateException(error);
		}

		return resultData;
	}

	/**
	 * 更新ボタン押下時のアクションです。<br>
	 * 商品コードが存在するかをチェックし、
	 * 存在すれば、発注ヘッダ、発注明細を更新します. <br>
	 *
	 * @create 2024/04/30
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return resultData 結果セット
	 * @throws SQLException SQL例外
	 * @throws GValidateException 入力例外
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Validatefull
	@ActionInterceptor(GTransactionInterceptor.class)
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	public GResultData doUpdate(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		checkInputDetail(parameter, resultData);
		try {
			updateHeader(parameter, ActionType.MODIFY);
			updateDetail(parameter);
		} catch (GOptimisticLockException e) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OTHERUSING);
			throw new GValidateException(error);
		}

		return resultData;
	}

	private void updateHeader(GParameter parameter, ActionType actionType) throws SQLException {
		GRecord headerRecord = createRecord();

		GGjdbcActionUtils.copyValue(headerRecord, parameter, SampleConstants.ORDERHEADER);

		headerRecord.setObject(SampleConstants.COMPANYCD, SampleUtils.getLoggedInUser().getCompany().getCode());

		if (ActionType.NEW.equals(actionType)) {
			headerRecord.setObject(SampleConstants.REGISTEREDPERSON, SampleUtils.getLoggedInUser().getId());
			headerRecord.setObject(SampleConstants.UPDATEDPERSON, SampleUtils.getLoggedInUser().getId());
			insert(SampleConstants.ORDERHEADER).values(headerRecord).execute();
		} else if (ActionType.MODIFY.equals(actionType)) {
			headerRecord.setObject(SampleConstants.UPDATEDPERSON, SampleUtils.getLoggedInUser().getId());
			update(SampleConstants.ORDERHEADER)
				.set(headerRecord)
				.excludes(SampleConstants.REGISTEREDDT, SampleConstants.REGISTEREDPERSON)
				.whereUK(SampleConstants.ORDERHEADER_SLIPNO_KEY)
				.execute();
		} else if (ActionType.DELETE.equals(actionType)) {
			delete(SampleConstants.ORDERHEADER).where(
				exp($(SampleConstants.ORDERHEADER_SLIPNO + " = ?").AND($(SampleConstants.COMPANYCD + " = ?")),
				parameter.getValue(SampleConstants.ORDERHEADER_SLIPNO), headerRecord.getString("CompanyCD")))
				.execute();
		}
	}

	private void updateDetail(GParameter parameter) throws SQLException, GValidateException {
		GListData detailListData = GEXActionUtils.extractListData(parameter, ORDERDETAIL_LIST);
		int i = 0;
		for (GRowData rowData : detailListData) {
			i++;
			if (isUpdateRow(parameter.getValue(GActionServlet.ACTION_ID), rowData)) {
				ActionType actionType = getActionType(parameter.getValue(GActionServlet.ACTION_ID), rowData);

				rowData.setData(SampleConstants.ORDERDETAIL_DETAILNO, i);

				GRecord detailRecord = createRecord();
				if (rowData.getInteger("OrderQT") <= 0) {
					throw new GValidateException(new GValidateError("Order QT cannot be negative or zero"));
				}
				GGjdbcActionUtils.copyValue(detailRecord, rowData, SampleConstants.ORDERDETAIL);
				detailRecord.setObject(SampleConstants.COMPANYCD, SampleUtils.getLoggedInUser().getCompany().getCode());
				detailRecord.setObject(SampleConstants.ORDERHEADER_SLIPNO, parameter.getValue(SampleConstants.ORDERHEADER_SLIPNO));

				if (ActionType.NEW.equals(actionType)) {
					detailRecord.setObject(SampleConstants.ORDERDETAIL_DETAILID, SampleUtils.getRandomString(32));
					detailRecord.setObject(SampleConstants.REGISTEREDPERSON, SampleUtils.getLoggedInUser().getId());
					detailRecord.setObject(SampleConstants.UPDATEDPERSON, SampleUtils.getLoggedInUser().getId());
					insert(SampleConstants.ORDERDETAIL).values(detailRecord).execute();
				} else if (ActionType.MODIFY.equals(actionType)) {
					detailRecord.setObject(SampleConstants.UPDATEDPERSON, SampleUtils.getLoggedInUser().getId());
					update(SampleConstants.ORDERDETAIL)
						.set(detailRecord)
						.excludes(SampleConstants.REGISTEREDDT, SampleConstants.REGISTEREDPERSON)
						.wherePK()
						.execute();
				} else if (ActionType.DELETE.equals(actionType)) {
					delete(SampleConstants.ORDERDETAIL).wherePK(detailRecord).execute();
				}
			}
		}
		numberingDetailNo(SampleUtils.getLoggedInUser().getCompany().getCode(), parameter.getValue(SampleConstants.ORDERHEADER_SLIPNO));
	}

	private ActionType getActionType(String actionid, GRowData rowData) {
		ActionType actionType = ActionType.NEW;
		if (ID_UPDATE_H.equals(actionid)) {
			if (!rowData.getBoolean(ID_ADDROW_FG)) {
				actionType = ActionType.MODIFY;
			}
		}
		else if (ID_DELETEROW_H.equals(actionid)) {
			actionType = ActionType.DELETE;
		}
		return actionType;
	}
	private void checkInputDetail(GParameter parameter, GResultData resultData) throws GValidateException, SQLException {

		List<GValidateError> errors = resultData.getErrors();

		// 商品コードの存在チェックを行います
		errors = checkItemCd(errors, parameter, resultData);

		if (!errors.isEmpty()) {
			throw new GValidateException(errors);
		}

	}


	private List<GValidateError> checkItemCd(List<GValidateError> errors, GParameter parameter, GResultData resultData) throws SQLException {

		GListData detailListData = GEXActionUtils.extractListData(parameter, ORDERDETAIL_LIST);
		if (detailListData == null) {
			return errors;
		}

		int i = 0;
		for (GRowData rowData : detailListData) {
			String addRowFG = rowData.getString(ID_ADDROW_FG);

			if (rowData.getBoolean(ID_CHECK_FG) && Boolean.valueOf(addRowFG)) {
				String parameterKey = ORDERDETAIL_LIST + "." + i + "." + SampleConstants.ORDERDETAIL_ITEMCD;
				boolean checkErrorFlag = true;
				if (errors != null) {
					for (GValidateError errorData : errors) {
						List<String> fieldIdList = errorData.getFieldIdList();
						if (fieldIdList.contains(parameterKey)) {
							checkErrorFlag = false;
							break;
						}
					}
				}

				if (checkErrorFlag) {
					String itemCd = rowData.getString(SampleConstants.ORDERDETAIL_ITEMCD);

					int count = select(SampleConstants.ITEMMASTER)
									.where(exp($(SampleConstants.COMPANYCD + " = ?").AND($(SampleConstants.ITEMMASTER_ITEMCD + " = ?")),
										SampleUtils.getLoggedInUser().getCompany().getCode(), itemCd))
									.count();

					if (count == 0) {
						Locale locale = GFrameworkContext.getInstance().getLocale();
						String label = GMessageResources.getMessage("ITEM-CODE", locale);
						GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_NOITEM);
						error.addFieldId(parameterKey);
						error.setLabel(label);
						error.setLabelspace("[" + (i + 1) + "]");
						if (errors == null) {
							errors = new ArrayList<GValidateError>();
						}
						errors.add(error);
					}
				}
			}
			i++;
		}
		return errors;
	}


	private String numberingSlipNO() throws GValidateException, SQLException {

		GEntitySelect select = select(SampleConstants.SNUMBERING)
								.wherePK(SampleUtils.getLoggedInUser().getCompany().getCode(), NUMCODE_SLIPNO);
		GRecord record = select.findRecord();

		if (record == null || record.getBigDecimal(SampleConstants.SNUMBERING_CURRENTVALUE) == null) {
			Locale locale = GFrameworkContext.getInstance().getLocale();
			GErrorMessage message = GErrorMessages.getErrorMessage("GEF-000051", locale);
			message.setMessage(message.getMessage() + "[" + select.getEntity().getName() + "]");
			throw new GApplicationException(message);
		}

		String constValue = record.getString(SampleConstants.SNUMBERING_CONSTVALUE);

		BigDecimal endValue = record.getBigDecimal(SampleConstants.SNUMBERING_ENDVALUE);
		BigDecimal currentValue = record.getBigDecimal(SampleConstants.SNUMBERING_CURRENTVALUE);
		BigDecimal incrementValue = record.getBigDecimal(SampleConstants.SNUMBERING_INCREMENTVALUE);

		BigDecimal value = currentValue.add(incrementValue);

		if (endValue.compareTo(value) < 0) {
			GValidateError error = GEXActionUtils.createValidateError(SampleConstants.ERROR_CD_OVERSLIPNO);
			if (error != null) {
				throw new GValidateException(error);
			}
		}
		record.setObject(SampleConstants.SNUMBERING_CURRENTVALUE, value);

		update(SampleConstants.SNUMBERING).set(record).wherePK().execute();

		DecimalFormat df = new DecimalFormat(SLIPNO_FORMAT);
		String slipNO = constValue + df.format(value);

		return slipNO;

	}


	private void numberingDetailNo(String companyCD, String slipNO) throws SQLException {

		List<GRecord> detailList = select(SampleConstants.ORDERDETAIL, "od")
										.leftOuterJoinFK(SampleConstants.ORDERDETAIL_ITEMMASTER_REFERENCEKEY, "im")
										.where(exp($("od." + SampleConstants.ORDERDETAIL_SLIPNO + " = ?").AND($("od." + SampleConstants.COMPANYCD + " = ?")), slipNO, companyCD))
										.orderBy(asc("od." + SampleConstants.ORDERDETAIL_DETAILNO))
										.findList();

		int i = 0;
		for (GRecord record : detailList) {
			record.setObject(SampleConstants.ORDERDETAIL_DETAILNO, ++i);
			update(SampleConstants.ORDERDETAIL).set(record).whereUK(SampleConstants.ORDERDETAIL_DETAILID_KEY).execute();
		}
	}

	private boolean isUpdateRow(String actionid, GRowData rowData) {
		if (rowData.getBoolean(ID_CHECK_FG)) {
			if (ID_DELETEROW_H.equals(actionid)) {
				if (rowData.getBoolean(ID_ADDROW_FG)) {
					return false;
				}
			}
			return true;
		}
		return false;
	}
}