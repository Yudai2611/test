/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.action;

import jp.co.kccs.greenearth.commons.utils.GStringUtils;
import jp.co.kccs.greenearth.framework.GActionServlet;
import jp.co.kccs.greenearth.framework.GParameter;
import jp.co.kccs.greenearth.framework.action.ActionInterceptor;
import jp.co.kccs.greenearth.framework.data.*;
import jp.co.kccs.greenearth.framework.db.GConnectionInterceptor;
import jp.co.kccs.greenearth.framework.ex.action.GEXActionUtils;
import jp.co.kccs.greenearth.framework.ex.action.GGjdbcActionUtils;
import jp.co.kccs.greenearth.framework.jdbc.GRecord;
import jp.co.kccs.greenearth.framework.jdbc.entity.GEntitySelect;
import jp.co.kccs.greenearth.framework.web.http.GMediaType;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Endpoint;
import jp.co.kccs.greenearth.framework.web.resource.annotation.Resource;
import sample.spa.common.SampleConstants;
import sample.spa.common.SampleUtils;

import jakarta.ws.rs.Consumes;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.kccs.greenearth.framework.jdbc.GQueryAssistants.*;
import static sample.spa.action.OrderDetailAction.ID_ADDROW_FG;
import static sample.spa.action.OrderDetailAction.ORDERDETAIL_LIST;

/**
 * 発注情報一覧画面のアクションクラスです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Resource
public class OrderListAction {
	/** 伝票合計金額 */
	public static final String ID_ALLAT = "AllAT";

	/** 発注情報リストのID. */
	public static final String ORDER_LIST = "OrderList";
	public OrderListAction() {
	}

	/**
	 * パラメータのmode値から、検索モードに転換し、<br>
	 * 共通の doSearch(GParameter parameter, GResultData resultData, GSearchMode searchMode)を呼び出す<br>
	 *
	 * @create 2024/04/30
	 * @param parameter 画面パラメータ
	 * @param resultData {@link GResultData}オブジェクト
	 * @return {@link GResultData}オブジェクト
	 * @throws SQLException SQL例外
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	@ActionInterceptor(GConnectionInterceptor.class)
	public GResultData doSearch(GParameter parameter, GResultData resultData) throws SQLException, GValidateException {
		GSearchMode searchMode =  GSearchMode.create(parameter.getValue(GActionServlet.ACTION_MODE_KEY));
		return doSearch(parameter, resultData, searchMode);
	}

	private GResultData doSearch(GParameter parameter, GResultData resultData, GSearchMode searchMode) throws GValidateException, SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("CompanyCD", SampleUtils.getLoggedInUser().getCompany().getCode());
		paramMap.put("SlipNO_0", GStringUtils.blankToNull(parameter.getValue("SlipNO_0")));
		paramMap.put("CorporateNA_1", GStringUtils.blankToNull(parameter.getValue("CorporateNA_1")));

		GEntitySelect select = select(SampleConstants.ORDERHEADER)
				.where(expMap($(SampleConstants.COMPANYCD + " = :CompanyCD")
						.AND($(SampleConstants.ORDERHEADER_SLIPNO + " LIKE :[" + "SlipNO_0%" + "]"))
						.AND($(SampleConstants.ORDERHEADER_CORPORATE_NA + " LIKE :[" + "CorporateNA_1%" + "]")), paramMap))
				.orderBy(asc(SampleConstants.ORDERHEADER_SLIPNO));

		GListData orderListData = GGjdbcActionUtils.findList(select, ORDER_LIST, parameter, searchMode);
		resultData.setData(ORDER_LIST, orderListData);

		return resultData;
	}

	/**
	 * 伝票番号のリンク押下時のアクションです。<br>
	 * 押下した伝票の情報を、結果セットにセットします。<br>
	 *
	 * @create 2024/04/30
	 * @param parameter 画面パラメータ
	 * @param resultData 結果セット
	 * @return 結果セット
	 * @throws SQLException SQL例外
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	@ActionInterceptor(GConnectionInterceptor.class)
	@Endpoint
	@Consumes(GMediaType.APPLICATION_FORM_URLENCODED)
	public GResultData doEdit(GParameter parameter, GResultData resultData) throws SQLException {
		String slipNO = GEXActionUtils.extractCellData(parameter);
		String companyCD = SampleUtils.getLoggedInUser().getCompany().getCode();
		// 発注ヘッダ、明細の情報を取得
		GRecord headerRecord = findOrderHeader(companyCD, slipNO);
		GListData detailList = findOrderDetailList(companyCD, slipNO);
		resultData.setData(ID_ALLAT, getSlipAT(detailList));

		// 取得した発注ヘッダ、明細の情報を、結果セットにセットします
		GGjdbcActionUtils.copyValue(resultData, headerRecord);
		resultData.setData(ORDERDETAIL_LIST, detailList);

		return resultData;
	}


	private GRecord findOrderHeader(String companyCD, String slipNO) throws SQLException {
		GRecord headerRecord = select(SampleConstants.ORDERHEADER)
				.whereUK(SampleConstants.ORDERHEADER_SLIPNO_KEY, companyCD, slipNO)
				.findRecord();
		return headerRecord;
	}

	private GListData findOrderDetailList(String companyCD, String slipNO) throws SQLException {

		List<GRecord> detailList = select(SampleConstants.ORDERDETAIL, "od")
				.leftOuterJoinFK(SampleConstants.ORDERDETAIL_ITEMMASTER_REFERENCEKEY, "im")
				.where(exp("od." + SampleConstants.COMPANYCD + " = ? AND " + "od." + SampleConstants.ORDERDETAIL_SLIPNO + " = ?", companyCD, slipNO))
				.orderBy(asc("od." + SampleConstants.ORDERDETAIL_DETAILNO))
				.findList();

		GListData detailListData = GGjdbcActionUtils.createListData(detailList);

		int i = 0;
		for (GRowData rowData : detailListData) {
			rowData.setData(ID_ADDROW_FG, false);
			detailListData.set(i, rowData);
			i++;
		}

		return detailListData;
	}

	private long getSlipAT(GListData listData) {
		long slipAT = 0;

		for (GRowData rowData : listData) {
			slipAT += Long.parseLong(rowData.getString(SampleConstants.ORDERDETAIL_ORDERAT));
		}
		return slipAT;
	}
}