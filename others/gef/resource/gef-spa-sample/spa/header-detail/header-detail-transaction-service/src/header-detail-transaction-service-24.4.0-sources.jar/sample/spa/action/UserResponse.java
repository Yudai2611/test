/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */

package sample.spa.action;

import jp.co.kccs.greenearth.framework.auth.GUser;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ユーザレスポンスオブジェクトです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {
    private String username;
    private String fullName;
    private String companyName;

    /**
     * {@link GUser}から{@link UserResponse}に変換します. <br>
     *
     * @create 2024/04/30
     * @param user ユーザオブジェクト
     * @return 変換されたユーザオブジェクト
     * @author dhiaz chebastian
     * @since 24.4.0
     */
    public static UserResponse from(GUser user) {
        return new UserResponse(user.getId(), user.getName(), user.getCompany().getName());
    }
}
