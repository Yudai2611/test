/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.common;

/**
 * サンプル用定数クラスです. <br>
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public class SampleConstants {

	private SampleConstants() {
	}

	/** 商品マスタに対象の商品が存在しない場合のエラーコード */
	public static final String ERROR_CD_NOITEM = "GES-100003";

	/** 伝票番号の採番が、上限に達した時のエラーコード */
	public static final String ERROR_CD_OVERSLIPNO = "GES-100004";

	/** 他のユーザが更新している場合のエラーコード */
	public static final String ERROR_CD_OTHERUSING = "GES-000102";

	/** 会社コード */
	public static final String COMPANYCD = "CompanyCD";

	/** 登録者 */
	public static final String REGISTEREDPERSON = "RegisteredPerson";

	/** 登録日 */
	public static final String REGISTEREDDT = "RegisteredDT";

	/** 更新者 */
	public static final String UPDATEDPERSON = "UpdatedPerson";

	/** 商品コード */
	public static final String ITEMMASTER_ITEMCD = "ItemCD";

	// ヘッダ明細
	// エンティティ名
	/** 発注ヘッダ */
	public static final String ORDERHEADER = "OrderHeader";

	/** 発注明細 */
	public static final String ORDERDETAIL = "OrderDetail";

	/** 商品マスタ */
	public static final String ITEMMASTER = "ItemMaster";

	/** 採番マスタ */
	public static final String SNUMBERING = "SNumbering";

	// 仮想項目名（発注ヘッダ）
	/** 伝票番号 */
	public static final String ORDERHEADER_SLIPNO = "SlipNO";

	// ユニークキー（発注ヘッダ）
	/** 発注ユニークキー */
	public static final String ORDERHEADER_SLIPNO_KEY = "SlipNOKey";

	// 仮想項目名（発注明細）
	/** 伝票番号 */
	public static final String ORDERDETAIL_SLIPNO = "SlipNO";
	/** 商品コード */
	public static final String ORDERDETAIL_ITEMCD = "ItemCD_0";
	/** 明細番号 */
	public static final String ORDERDETAIL_DETAILNO = "DetailNo";
	/** 明細ID */
	public static final String ORDERDETAIL_DETAILID = "DetailID";

	// ユニークキー
	/** 発注明細ユニークキー */
	public static final String ORDERDETAIL_DETAILID_KEY = "DetailIDKey";

	// 外部キー
	/** 商品マスタ引当キー */
	public static final String ORDERDETAIL_ITEMMASTER_REFERENCEKEY = "ItemMasterReferenceKey";
	public static final String ORDERDETAIL_ORDERAT = "OrderAT";

	// 仮想項目名（採番マスタ）
	/** 固定値 */
	public static final String SNUMBERING_CONSTVALUE = "ConstValue";
	/** 終了値 */
	public static final String SNUMBERING_ENDVALUE = "EndValue";
	/** 現在値 */
	public static final String SNUMBERING_CURRENTVALUE = "CurrentValue";
	/** 増減値 */
	public static final String SNUMBERING_INCREMENTVALUE = "IncrementValue";

	/** 会社名（カナ） */
	public static final String ORDERHEADER_CORPORATENA_KANA = "CorporateNA_KANA";
	/** 会社名 */
	public static final String ORDERHEADER_CORPORATE_NA = "CorporateNA";

}
