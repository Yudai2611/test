/*
 * Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.
 */
package sample.spa.common;

import jp.co.kccs.greenearth.framework.auth.GUser;
import jp.co.kccs.greenearth.framework.web.security.auth.GSubject;
import jp.co.kccs.greenearth.framework.web.security.context.GSecurityContextHolder;

import java.util.Optional;

/**
 * サンプルアプリケーションで使用する共通処理を提供します. <br>
 *
 * @since 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
public final class SampleUtils {

	/**
	 * 桁数指定でランダム文字列を取得します。<br>
	 * 生成される文字列はアルファベット（大文字のみ）と数字の37文字から構成されま.<br>
	 *
	 * @create 2024/04/30
	 * @param length 桁数
	 * @return ランダム文字列
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public static String getRandomString(int length) {
		StringBuilder sb = new StringBuilder();
		final char[] ch = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
		for (int i = 0; i < length; i++) {
			int rand = (int) Math.round(Math.random() * (ch.length - 1));
			sb.append(ch[rand]);
		}
		return sb.toString();
	}

	/**
	 * {@link GSecurityContextHolder}から認証されたユーザを取得します. <br>
	 *
	 * @create 2024/04/30
	 * @return 認証されたユーザ
	 * @author dhiaz chebastian
	 * @since 24.4.0
	 */
	public static GUser getLoggedInUser() {
		Optional<GSubject> subject = GSecurityContextHolder.getContext().getSubject();
		return subject.map(
			s -> ((GUser) subject.get().getPrincipal())).orElse(null);
	}
}
