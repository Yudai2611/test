/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface IItem {
  UpdatedPerson: string;
  ExclusiveFG: string;
  RegisteredPerson: string;
  ItemNA: string;
  UpdatedDT: string;
  InvalidDT: string;
  Standard: string;
  Unit: string;
  ItemNA_KANA: string;
  StartDT: string;
  UnitPrice: string;
  StockFG: string;
  ItemCD: string;
  RegisteredDT: string;
  StockQT: string;
  InspectionFG: string;
}
