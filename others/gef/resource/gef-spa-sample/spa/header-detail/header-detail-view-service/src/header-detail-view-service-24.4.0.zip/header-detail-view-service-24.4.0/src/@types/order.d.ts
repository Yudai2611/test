/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface OrderHeader {
  CorporateNA_KANA: string;
  CorporateNA: string;
  CompanyCD: string;
  UpdatedPerson: string;
  ExclusiveFG: string;
  RegisteredPerson: string;
  SlipNO: string;
  UpdatedDT: string;
  RegisteredDT: string;
  OrderDetailList: OrderDetail[];
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface OrderDetail {
  CompanyCD: string;
  ExclusiveFG: string;
  DetailNo: string;
  Remark: string;
  DetailID: string;
  OrderQT: number;
  StockFG: boolean;
  SlipNO: string;
  OrderAT: number;
  AddRowFG: boolean;
  UnitPrice: number;
  ItemCD: string;
  InspectionFG: boolean;
}
