/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface User {
  username: string;
  firstName: string;
  lastName: string;
  password: string;
  confirmationPassword: string;
}
