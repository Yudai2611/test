/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./App.css";
import { MyRouter } from "./router";
import LoadingComponent from "./ui-components/LoadingComponent";
import { useAuthentication } from "./store/authenticationStore";
import { useMenu } from "./store/menuStore";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
function App() {
  const { loadingAuth } = useAuthentication();
  const { loadingMenu } = useMenu();
  return (
    <>
      <MyRouter />
      <ToastContainer autoClose={1000} />
      <LoadingComponent isShown={loadingAuth || loadingMenu} />
    </>
  );
}

export default App;
