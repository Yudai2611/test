/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import axios from "axios";
import { ENV } from "../utils/constants";
import { notifyError } from "../utils/notify";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const http = axios.create({
  baseURL: ENV.BASE_URI,
  withCredentials: true,
});

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const setupInterceptors = () => {
  http.interceptors.response.use(
    (response: any): any => {
      return response;
    },
    async (error) => {
      notifyError("Something when wrong!");
      return Promise.reject(error);
    },
  );
};
