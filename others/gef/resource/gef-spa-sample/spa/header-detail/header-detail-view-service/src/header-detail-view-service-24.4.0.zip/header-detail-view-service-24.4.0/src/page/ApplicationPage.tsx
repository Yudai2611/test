/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { Button, Flex, ScrollView, View } from "@aws-amplify/ui-react";
import { SyntheticEvent, useCallback, useEffect, useState } from "react";
import LoadingDialog from "../ui-components/LoadingDialog";
import { onChange } from "../utils/helper";
import { useMenu } from "../store/menuStore";
import HeaderDetailTableComponent from "../ui-components/HeaderDetailTableComponent";
import { useHeaderDetail } from "../store/headerDetailStore";
import SearchComponent from "../ui-components/SearchComponent";
import HeaderDetailFormComponent from "../ui-components/HeaderDetailFormComponent";
import { notifyInfo, notifySuccess } from "../utils/notify";

const totalSizePerPage = 5;

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export default function ApplicationPage() {
  const [isShowDownloadDialog, setShowDownloadDialog] = useState(false);
  const [isShowPostDialog, setShowPostDialog] = useState(false);
  const {
    getHeaderDetail,
    headerDetails,
    totalSize,
    maxListSize,
    startIndex,
    getItems,
    items,
    editHeaderDetail,
    deleteHeaderDetail,
    headerDetail,
    setHeaderDetail,
    saveHeaderDetail,
    updateHeaderDetail,
  } = useHeaderDetail();
  const { getMenus, setCurrentMenu } = useMenu();
  const [slipNoKeyword, setSlipNoKeyword] = useState("");
  const [corporateNAKeyword, setCorporateNAKeyword] = useState("");
  const [currentPageIndex, setCurrentPageIndex] = useState(1);
  const [currentSlipNo, setCurrentSlipNo] = useState("");
  const [isCheckValidation, setIsCheckValidation] = useState(false);

  const reset = useCallback(() => {
      setCurrentPageIndex(1);
      getHeaderDetail(0, totalSizePerPage, 1, "", "");
  }, [getHeaderDetail]);
  useEffect(() => {
    reset();
    setCurrentMenu("ヘーダ明細");
    getMenus();
    getItems("");
  }, [getMenus, getItems, setCurrentMenu, reset]);
  return (
    <ScrollView maxHeight={"80vh"}>
      <View position={"relative"} left={"0"} top={"0"} width="100%">
        <Flex
          direction="row"
          justifyContent="flex-start"
          alignItems="stretch"
          alignContent="flex-start"
          wrap="wrap"
          gap="1.5rem"
          paddingBottom={"10px"}
        >
          <SearchComponent
            label={"Slip No"}
            placeholder={"Type your Slip No here..."}
            keyword={slipNoKeyword}
            onKeywordChange={(e: SyntheticEvent) => {
              const keyword = (e.currentTarget as HTMLInputElement).value!;
              setSlipNoKeyword(keyword);
              setCurrentPageIndex(1);
              getHeaderDetail(
                startIndex,
                totalSizePerPage,
                currentPageIndex,
                keyword,
                corporateNAKeyword,
              );
            }}
            onClear={() => {
              setSlipNoKeyword("");
              setCurrentPageIndex(1);
              getHeaderDetail(
                startIndex,
                totalSizePerPage,
                currentPageIndex,
                "",
                corporateNAKeyword,
              );
            }}
          />
          <SearchComponent
            label={"Corporate Name"}
            placeholder={"Type your Corporate Name here..."}
            keyword={corporateNAKeyword}
            onKeywordChange={(e: SyntheticEvent) => {
              const keyword = (e.currentTarget as HTMLInputElement).value!;
              setCorporateNAKeyword(keyword);
              setCurrentPageIndex(1);
              getHeaderDetail(
                startIndex,
                totalSizePerPage,
                currentPageIndex,
                slipNoKeyword,
                keyword,
              );
            }}
            onClear={() => {
              setCorporateNAKeyword("");
              setCurrentPageIndex(1);
              getHeaderDetail(
                startIndex,
                totalSizePerPage,
                currentPageIndex,
                slipNoKeyword,
                "",
              );
            }}
          />
          <HeaderDetailTableComponent
            onEdit={async (slipNo: string) => {
              setCurrentSlipNo(slipNo);
              await editHeaderDetail(slipNo);
              setShowPostDialog(true);
              reset();
            }}
            onDelete={async (headerDetail: any) => {
              await deleteHeaderDetail(headerDetail);
              reset();
              notifySuccess("Delete is success");
            }}
            currentPageIndex={currentPageIndex}
            datas={headerDetails}
            totalSizePerPage={maxListSize}
            totalData={totalSize}
            onChange={(startIndex: number, currentPageIndex: number) => {
              setCurrentPageIndex(currentPageIndex);
              getHeaderDetail(
                startIndex,
                totalSizePerPage,
                currentPageIndex,
                slipNoKeyword,
                corporateNAKeyword,
              );
            }}
          />
        </Flex>

        <Button
          role="button"
          aria-label="Header Detail Form Open Button"
          position={"fixed"}
          right={"40px"}
          bottom={"40px"}
          backgroundColor={"#000000"}
          color={"#FFFFFF"}
          borderRadius={"100px"}
          width={"50px"}
          height={"50px"}
          fontSize={"25px"}
          onClick={() => {
            setShowPostDialog(true);
          }}
        >
          +
        </Button>
      </View>
      <View
        position={"fixed"}
        left={"0"}
        top={"0"}
        backgroundColor={"rgba(0,0,0,0.5)"}
        height={"100vh"}
        width={"100vw"}
        display={isShowDownloadDialog ? "block" : "none"}
        paddingTop={"50px"}
      >
        <LoadingDialog
          onClose={() => {
            setShowDownloadDialog(false);
          }}
          margin={"auto"}
          percentage={0}
        />
      </View>
      <View
        position={"fixed"}
        left={"0"}
        top={"0"}
        backgroundColor={"rgba(0,0,0,0.5)"}
        height={"100vh"}
        width={"100vw"}
        display={isShowPostDialog ? "block" : "none"}
        paddingTop={"50px"}
      >
        <HeaderDetailFormComponent
          isCheckValidation={isCheckValidation}
          form={headerDetail}
          items={items}
          onClose={() => {
            setCurrentSlipNo("");
            setHeaderDetail({
              SlipNO: "",
              CorporateNA: "",
              CorporateNA_KANA: "",
              OrderDetailList: [],
            });
            setIsCheckValidation(false);
            setShowPostDialog(false);
          }}
          onFormChange={(e: SyntheticEvent) => {
            onChange(e, headerDetail, setHeaderDetail, "OrderDetailList");
          }}
          onDelete={(index: number) => {
            const temp: any[] = [];
            if (headerDetail.OrderDetailList) {
              headerDetail.OrderDetailList.map((item: any, i: number) => {
                if (i != index) {
                  temp.push(item);
                }
              });
              setHeaderDetail({
                ...headerDetail,
                OrderDetailList: [...temp],
              });
            }
          }}
          onItemAdd={() => {
            setHeaderDetail({
              ...headerDetail,
              OrderDetailList: [
                ...headerDetail.OrderDetailList,
                {
                  CompanyCD: "",
                  ExclusiveFG: "",
                  DetailNo: "",
                  Remark: "",
                  DetailID: "",
                  OrderQT: 0,
                  StockFG: 0,
                  SlipNO: currentSlipNo,
                  OrderAT: 0,
                  AddRowFG: true,
                  UnitPrice: 0,
                  ItemCD: items[0].cells.ItemCD,
                  InspectionFG: 0,
                },
              ],
            });
          }}
          onSubmit={async () => {
            if (
              headerDetail.CorporateNA == "" ||
              headerDetail.CorporateNA_KANA == ""
            ) {
              setIsCheckValidation(true);
              return;
            }
            if (
              !headerDetail.OrderDetailList ||
              headerDetail.OrderDetailList.length == 0
            ) {
              notifyInfo("You should input at least 1 item");
              return;
            }
            for (const index in headerDetail.OrderDetailList) {
              const temp: any = headerDetail.OrderDetailList[index];
              if (
                temp.OrderQT <= 0 ||
                temp.OrderQT == "" ||
                temp.UnitPrice == "" ||
                temp.UnitPrice <= 0
              ) {
                setIsCheckValidation(true);
                return;
              }
            }
            const temp = {
              ...headerDetail,
              OrderDetailList: Object.values(headerDetail.OrderDetailList),
            };
            if (currentSlipNo == "") {
              await saveHeaderDetail(temp);
              notifySuccess("Insert Header Detail is success!");
            } else {
              await updateHeaderDetail(temp);
              notifySuccess("Update Header Detail is success!");
            }
            setShowPostDialog(false);
            setIsCheckValidation(false);
            setHeaderDetail({
              SlipNO: "",
              CorporateNA: "",
              CorporateNA_KANA: "",
              OrderDetailList: [],
            });
            reset();
          }}
        />
      </View>
    </ScrollView>
  );
}
