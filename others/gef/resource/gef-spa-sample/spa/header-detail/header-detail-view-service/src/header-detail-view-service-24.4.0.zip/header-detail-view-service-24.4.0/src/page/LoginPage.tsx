/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { useNavigate } from "react-router-dom";
import LoginForm from "../ui-components/LoginForm";
import { SyntheticEvent, useCallback, useEffect, useState } from "react";
import { useAuthentication } from "../store/authenticationStore";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export default function LoginPage() {
  const [companyCode, setCompanyCode] = useState<string>("");
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [companyCodeHasError, setCompanyCodeHasError] =
    useState<boolean>(false);
  const [usernameHasError, setUsernameHasError] = useState<boolean>(false);
  const [passwordHasError, setPasswordHasError] = useState<boolean>(false);
  const { isAuthenticated, error, login, getCsrfToken } = useAuthentication();
  const navigate = useNavigate();
  const init = useCallback(async () => {
      await getCsrfToken();
      navigate("/home");
  }, [getCsrfToken, navigate]);
  useEffect(() => {
    if (isAuthenticated) {
      init();
    }
  }, [isAuthenticated, init]);

  return (
    <LoginForm
      username={username}
      isLoginFailed={error != ""}
      companyCodeHasError={companyCodeHasError}
      usernameHasError={usernameHasError}
      passwordHasError={passwordHasError}
      onChangeUsername={(e: SyntheticEvent) => {
        setUsername((e.currentTarget as HTMLInputElement).value!);
      }}
      password={password}
      onChangePassword={(e: SyntheticEvent) => {
        setPassword((e.currentTarget as HTMLInputElement).value!);
      }}
      onChangeCompanyCode={(e: SyntheticEvent) => {
        setCompanyCode((e.currentTarget as HTMLInputElement).value!);
      }}
      onLogin={async () => {
        setCompanyCodeHasError(companyCode === "");
        setUsernameHasError(username === "");
        setPasswordHasError(password === "");

        if (
          companyCode != "" &&
          username != "" &&
          password != "" &&
          username != null &&
          password != null &&
          companyCode != null
        ) {
          login(companyCode, username, password);
        }
      }}
    />
  );
}
