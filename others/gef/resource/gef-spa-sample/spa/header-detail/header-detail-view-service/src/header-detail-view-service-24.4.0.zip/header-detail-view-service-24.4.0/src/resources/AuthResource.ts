/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { ENV } from "../utils/constants";
import { http } from "../http/http";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const login = async (
  companyCode: string,
  username: string,
  password: string,
) => {
  return await http.post(
    ENV.BASE_URI,
    {
      companycd: companyCode,
      userid: username,
      password: password,
    },
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Action-Bean": "sample.spa.action.AuthenticationAction",
        "X-Action-Method": "login",
        "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
      },
    },
  );
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const logout = async () => {
  return await http.post(ENV.BASE_URI, null, {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Action-Bean": "sample.spa.action.AuthenticationAction",
      "X-Action-Method": "logout",
      "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
    },
  });
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getCsrfToken = async () => {
  const res = await http.post(ENV.BASE_URI, null, {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Action-Bean": "CsrfTokenIssuanceAction",
      "X-Action-Method": "issuance",
    },
  });
  return res.headers["csrf_token"];
};
