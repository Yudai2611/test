/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { http } from "../http/http";
import { ENV } from "../utils/constants";
import queryString from "querystring";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getHeaderDetail = (
  slipNo: string,
  corporateNA: string,
  startIndex: any,
  pageSize: any,
  mode: any,
) => {
  const res: any = http.post(
    ENV.BASE_URI,
    {
      SlipNO_0: slipNo,
      CorporateNA_1: corporateNA,
      "OrderList.startindex": startIndex,
      "OrderList.listsize": pageSize,
      mode: mode,
    },
    {
      headers: {
        "content-type": "application/x-www-form-urlencoded",
        "X-Action-Bean": "sample.spa.action.OrderListAction",
        "X-Action-Method": "doSearch",
        "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
      },
    },
  );
  return res;
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const editHeaderDetail = (slipNo?: string) => {
  const res: any = http.post(
    ENV.BASE_URI,
    {
      actionid: "OrderList.0.SlipNO",
      "OrderList.SlipNO": slipNo,
    },
    {
      headers: {
        "content-type": "application/x-www-form-urlencoded",
        "X-Action-Bean": "sample.spa.action.OrderListAction",
        "X-Action-Method": "doEdit",
        "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
      },
    },
  );
  return res;
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const updateHeaderDetail = async (headerDetail: any) => {
  const temp = await constructOrder(headerDetail, 1);
  const res: any = http.post(ENV.BASE_URI, queryString.stringify({ ...temp }), {
    headers: {
      "content-type": "application/x-www-form-urlencoded",
      "X-Action-Bean": "sample.spa.action.OrderDetailAction",
      "X-Action-Method": "doUpdate",
      "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
    },
  });
  return res;
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const insertHeaderDetail = async (headerDetail: any) => {
  const temp = await constructOrder(headerDetail, 0);
  const res: any = http.post(ENV.BASE_URI, queryString.stringify({ ...temp }), {
    headers: {
      "content-type": "application/x-www-form-urlencoded",
      "X-Action-Bean": "sample.spa.action.OrderDetailAction",
      "X-Action-Method": "doInsert",
      "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
    },
  });
  return res;
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const deleteHeaderDetail = (headerDetail: any) => {
  const res: any = http.post(ENV.BASE_URI, headerDetail, {
    headers: {
      "content-type": "application/x-www-form-urlencoded",
      "X-Action-Bean": "sample.spa.action.OrderDetailAction",
      "X-Action-Method": "doDelete",
      "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
    },
  });
  return res;
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getItems = (itemCd: string) => {
  const res: any = http.post(
    ENV.BASE_URI,
    {
      ItemCD_0: itemCd,
    },
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Action-Bean": "sample.spa.action.ItemListZoomAction",
        "X-Action-Method": "doSearch",
        "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
      },
    },
  );
  return res;
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
const constructOrder = async (order: any, actionType: any) => {
  const orderDetailList = order.OrderDetailList;
  const orderObj = {
    CorporateNA_KANA: order.CorporateNA_KANA,
    CorporateNA: order.CorporateNA,
    SlipNO: order.SlipNO,
    "OrderDetailList.DeliveryDT": null,
    "OrderDetailList.InspectionFG": orderDetailList.map(
      (orderDetail: any) => orderDetail.InspectionFG,
    ),
    "OrderDetailList.OrderAT": orderDetailList.map(
      (orderDetail: any) => orderDetail.OrderQT * orderDetail.UnitPrice,
    ),
    "OrderDetailList.DetailNo": orderDetailList.map(
      (orderDetail: any) => orderDetail.DetailNo,
    ),
    "OrderDetailList.StockFG": orderDetailList.map(
      (orderDetail: any) => orderDetail.StockFG,
    ),
    "OrderDetailList.CheckFG": orderDetailList.map((orderDetail: any) =>
      orderDetail.CheckFG === undefined ? false : true,
    ),
    "OrderDetailList.AddRowFG": orderDetailList.map((orderDetail: any) =>
      orderDetail.AddRowFG === undefined ? true : orderDetail.AddRowFG,
    ),
    "OrderDetailList.OrderQT": orderDetailList.map(
      (orderDetail: any) => orderDetail.OrderQT,
    ),
    "OrderDetailList.ItemCD": orderDetailList.map(
      (orderDetail: any) => orderDetail.ItemCD,
    ),
    "OrderDetailList.ItemCD_0": orderDetailList.map(
      (orderDetail: any) => orderDetail.ItemCD,
    ),
    "OrderDetailList.Remark": orderDetailList.map(
      (orderDetail: any) => orderDetail.Remark,
    ),
    "OrderDetailList.ExclusiveFG": orderDetailList.map(
      (orderDetail: any) => orderDetail.ExclusiveFG,
    ),
    "OrderDetailList.UnitPrice": orderDetailList.map(
      (orderDetail: any) => orderDetail.UnitPrice,
    ),
    "OrderDetailList.DetailID": orderDetailList.map(
      (orderDetail: any) => orderDetail.DetailID,
    ),
    ExclusiveFG: order.ExclusiveFG,
    actionid: actionType === 0 ? "EntryH" : "UpdateH",
    mode: actionType === 0 ? "insert" : "update",
  };
  return orderObj;
};
