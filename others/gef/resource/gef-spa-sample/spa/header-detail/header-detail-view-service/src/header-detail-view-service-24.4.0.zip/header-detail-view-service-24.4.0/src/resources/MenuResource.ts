/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { http } from "../http/http";
import { ENV } from "../utils/constants";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getMenus = async () => {
  return await http.get(ENV.BASE_URI, {
    headers: {
      "X-Action-Bean": "sample.spa.action.MenuAction",
      "X-Action-Method": "launchMenuSPA",
      "X-Csrf-Token": sessionStorage.getItem(ENV.CSRF_TOKEN_KEY),
    },
  });
};
