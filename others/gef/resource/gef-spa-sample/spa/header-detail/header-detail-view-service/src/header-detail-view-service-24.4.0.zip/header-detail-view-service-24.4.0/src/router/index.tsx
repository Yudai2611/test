/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { BrowserRouter, Route, Routes } from "react-router-dom";
import LoginPage from "../page/LoginPage";
import HomePage from "../page/HomePage";
import { useState } from "react";
import { setupInterceptors } from "../http/http";
import ApplicationPage from "../page/ApplicationPage";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
function NavigateFunctionComponent() {
  const [ran, setRan] = useState(false);

  if (!ran) {
    setupInterceptors();
    setRan(true);
  }
  return <></>;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const MyRouter = () => {
  return (
    <BrowserRouter>
      {<NavigateFunctionComponent />}
      <Routes>
        <Route path="" element={<LoginPage />} />
        <Route path="/home" element={<HomePage />}>
          <Route path="" element={<></>} />
          <Route path="application" element={<ApplicationPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};
