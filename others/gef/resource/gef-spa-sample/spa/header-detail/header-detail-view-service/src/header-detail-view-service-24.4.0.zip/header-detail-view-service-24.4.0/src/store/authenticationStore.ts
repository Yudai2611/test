/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { create } from "zustand";
import { getCsrfToken, login, logout } from "../resources/AuthResource";
import { ENV } from "../utils/constants";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface AuthenticationStore {
  isAuthenticated: boolean;
  error: string;
  currentLoginUser: any;
  loadingAuth: boolean;
  setIsAuthenticated: (isAuthenticated: boolean) => void;
  login: (
    companyCode: string,
    username: string,
    password: string,
  ) => Promise<void>;
  logout: () => Promise<void>;
  getCsrfToken: () => Promise<void>;
  getProfile: () => Promise<void>;
  clearAuth: () => Promise<void>;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const useAuthentication = create<AuthenticationStore>((set) => ({
  isAuthenticated: false,
  currentLoginUser: {
    username: "",
    fullName: "",
    companyName: "",
  },
  loadingAuth: false,
  setIsAuthenticated: (isAuthenticated: boolean) =>
    set(() => ({
      isAuthenticated: isAuthenticated,
    })),
  error: "",
  login: async (companyCode: string, username: string, password: string) => {
    set(() => ({
      loadingAuth: true,
    }));
    try {
      const loginRes = await login(companyCode, username, password);
      if (loginRes && loginRes.status == 200) {
        const loggedInUser = loginRes.data.datas.loggedInUser;
        sessionStorage.setItem(
          ENV.LOGGED_IN_USER_KEY,
          JSON.stringify(loggedInUser),
        );
        set(() => ({
          isAuthenticated: true,
          error: "",
        }));
      }
    } catch (exception: any) {
      set(() => ({
        isAuthenticated: false,
        error: "Login is failed",
      }));
    } finally {
      set(() => ({
        loadingAuth: false,
      }));
    }
  },
  getCsrfToken: async () => {
    const csrfToken = await getCsrfToken();
    sessionStorage.setItem(ENV.CSRF_TOKEN_KEY, csrfToken);
  },
  getProfile: async () => {
    const loggedInUser: any = JSON.parse(
      sessionStorage.getItem(ENV.LOGGED_IN_USER_KEY)!,
    );
    set(() => ({
      currentLoginUser: {
        username: loggedInUser.username,
        fullName: loggedInUser.fullName,
        companyName: loggedInUser.companyName,
      },
    }));
  },
  logout: async () => {
    set(() => ({
      loadingAuth: true,
    }));
    try {
      await logout();
      sessionStorage.removeItem(ENV.LOGGED_IN_USER_KEY);
      set(() => ({
        isAuthenticated: false,
        error: "",
        currentLoginUser: {
          fullName: "",
          username: "",
          companyName: "",
        },
      }));
    } finally {
      set(() => ({
        loadingAuth: false,
      }));
    }
  },
  clearAuth: async () => {
    set(() => ({
      isAuthenticated: false,
      error: "",
      currentLoginUser: {
        fullName: "",
        username: "",
      },
    }));
  },
}));
