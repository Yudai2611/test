/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { create } from "zustand";
import {
  deleteHeaderDetail,
  editHeaderDetail,
  getHeaderDetail,
  getItems,
  insertHeaderDetail,
  updateHeaderDetail,
} from "../resources/HeaderDetailResource";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface HeaderDetailStore {
  headerDetails: any[];
  headerDetail: any;
  totalSize: number;
  maxListSize: number;
  startIndex: number;
  loadingHeaderDetail: boolean;
  items: any[];
  getHeaderDetail: (
    startIndex: any,
    pageSize: any,
    mode: any,
    slipNo?: string,
    corporateNA?: string,
  ) => Promise<void>;
  saveHeaderDetail: (order: OrderHeader) => Promise<void>;
  updateHeaderDetail: (order: OrderHeader) => Promise<void>;
  deleteHeaderDetail: (order: OrderHeader) => Promise<void>;
  editHeaderDetail: (slipNo: string) => Promise<void>;
  setHeaderDetail: (order: any) => void;
  getItems: (itemCd: string) => Promise<void>;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const useHeaderDetail = create<HeaderDetailStore>((set) => ({
  headerDetails: [],
  headerDetail: {
    SlipNO: "",
    CorporateNA: "",
    CorporateNA_KANA: "",
    OrderDetailList: [],
  },
  items: [],
  totalSize: 0,
  maxListSize: 0,
  startIndex: 0,
  loadingHeaderDetail: false,
  getHeaderDetail: async (
    startIndex: any,
    pageSize: any,
    mode: any,
    slipNo?: string,
    corporateNA?: string,
  ) => {
    set(() => ({
      loadingHeaderDetail: true,
    }));
    try {
      const res: any = await getHeaderDetail(
        slipNo!,
        corporateNA!,
        startIndex,
        pageSize,
        mode,
      );
      if (res.status == 200) {
        set(() => ({
          headerDetails: res.data.datas.OrderList.rows,
          totalSize: res.data.datas.OrderList.totalSize,
          maxListSize: res.data.datas.OrderList.maxListSize,
          startIndex: res.data.datas.OrderList.startIndex,
        }));
      }
    } finally {
      set(() => ({
        loadingHeaderDetail: false,
      }));
    }
  },
  saveHeaderDetail: async (order: OrderHeader) => {
    set(() => ({
      loadingHeaderDetail: true,
    }));
    try {
      await insertHeaderDetail(order);
    } finally {
      set(() => ({
        loadingHeaderDetail: false,
      }));
    }
  },
  updateHeaderDetail: async (order: OrderHeader) => {
    set(() => ({
      loadingHeaderDetail: true,
    }));
    try {
      await updateHeaderDetail(order);
    } finally {
      set(() => ({
        loadingHeaderDetail: false,
      }));
    }
  },
  deleteHeaderDetail: async (order: OrderHeader) => {
    set(() => ({
      loadingHeaderDetail: true,
    }));
    try {
      await deleteHeaderDetail(order);
    } finally {
      set(() => ({
        loadingHeaderDetail: false,
      }));
    }
  },
  editHeaderDetail: async (slipNo: string) => {
    set(() => ({
      loadingHeaderDetail: true,
    }));
    try {
      const res: any = await editHeaderDetail(slipNo);
      if (res.status == 200) {
        const temp: any[] = [];
        res.data.datas.OrderDetailList.rows.map((item: any) => {
          temp.push({
            CompanyCD: item.cells.CompanyCD,
            ExclusiveFG: item.cells.ExclusiveFG,
            ItemCD_0: item.cells.ItemCD_0,
            ItemNA: item.cells.ItemNA,
            Standard: item.cells.Standard,
            Unit: item.cells.Unit,
            DetailNo: item.cells.DetailNo,
            ItemNA_KANA: item.cells.ItemNA_KANA,
            Remark: item.cells.Remark,
            DetailID: item.cells.DetailID,
            OrderQT: item.cells.OrderQT,
            StockFG: item.cells.StockFG,
            UpdatedPerson: item.cells.UpdatedPerson,
            RegisteredPerson: item.cells.RegisteredPerson,
            SlipNO: slipNo,
            OrderAT: item.cells.OrderAT,
            InvalidDT: item.cells.InvalidDT,
            DeliveryDT: item.cells.DeliveryDT,
            AddRowFG: false,
            StartDT: item.cells.StartDT,
            UnitPrice: item.cells.UnitPrice,
            ItemCD: item.cells.ItemCD_0,
            RegisteredDT: item.cells.RegisteredDT,
            StockQT: item.cells.StockFG,
            InspectionFG: item.cells.InspectionFG,
          });
        });
        set(() => ({
          headerDetail: {
            SlipNO: res.data.datas.SlipNO,
            CorporateNA: res.data.datas.CorporateNA,
            CorporateNA_KANA: res.data.datas.CorporateNA_KANA,
            UpdatedPerson: res.data.datas.UpdatedPerson,
            ExclusiveFG: res.data.datas.ExclusiveFG,
            OrderDetailList: [...temp],
          },
        }));
      }
    } finally {
      set(() => ({
        loadingHeaderDetail: false,
      }));
    }
  },
  setHeaderDetail: async (order: OrderHeader) => {
    set(() => ({
      headerDetail: { ...order },
    }));
  },
  getItems: async (itemCd: string) => {
    set(() => ({
      loadingHeaderDetail: true,
    }));
    try {
      const res: any = await getItems(itemCd);
      if (res.status == 200) {
        set(() => ({
          items: res.data.datas.ZoomItemList.rows,
        }));
      }
    } finally {
      set(() => ({
        loadingHeaderDetail: false,
      }));
    }
  },
}));
