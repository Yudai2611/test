/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { create } from "zustand";
import { getMenus } from "../resources/MenuResource";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
interface MenuStore {
  menus: MenuItem[];
  loadingMenu: boolean;
  currentMenu: string;
  getMenus: () => Promise<void>;
  clearMenu: () => Promise<void>;
  setCurrentMenu: (currentMenu: string) => void;
}

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const useMenu = create<MenuStore>((set) => ({
  menus: [],
  loadingMenu: false,
  currentMenu: "GreenEarth Framework Sample",
  setCurrentMenu: (currentMenu: string) => {
    set(() => ({
      currentMenu: currentMenu,
    }));
  },
  getMenus: async () => {
    set(() => ({
      loadingMenu: true,
    }));
    try {
      const res = await getMenus();
      if (res.status == 200) {
        set(() => ({
          menus: convertMenu([...res.data.datas.menus]),
        }));
      }
    } finally {
      set(() => ({
        loadingMenu: false,
      }));
    }
  },
  clearMenu: async () => {
    set(() => ({
      menus: [],
    }));
  },
}));

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
const convertMenu = (menus: MenuItem[]) => {
  const temp: any[] = [];
  for (let i = 0; i < menus.length; i++) {
    const menu = menus[i];
    temp.push({
      id: menu.menuId,
      name: menu.menuLabel,
      uri: menu.menuPageUri,
      children: menu.menuChild.length == 0 ? null : convertMenu(menu.menuChild),
    });
  }
  return temp;
};
