/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import {
  Button,
  Flex,
  ScrollView,
  Text,
  TextField,
  View,
} from "@aws-amplify/ui-react";
import HeaderDetailItemFormComponent from "./HeaderDetailItemFormComponent";
import { SyntheticEvent } from "react";

interface Props {
  onSubmit: () => void;
  onItemAdd: () => void;
  items: any[];
  onDelete: (index: number) => void;
  onClose: () => void;
  form: any;
  onFormChange: (e: SyntheticEvent) => void;
  isCheckValidation: boolean;
}

export default function HeaderDetailFormComponent(props: Props) {
  const {
    isCheckValidation,
    onSubmit,
    onItemAdd,
    onClose,
    items,
    onDelete,
    form,
    onFormChange,
    ...rest
  } = props;

  return (
    <View
      role="form"
      aria-label="Header Detail Form"
      display="block"
      overflow="hidden"
      position="relative"
      borderRadius="10px"
      backgroundColor="rgba(255,255,255,1)"
      margin="auto 20px"
      padding="20px"
      {...rest}
    >
      <Text fontSize={"20px"} fontWeight={"bold"} marginBottom={"20px"}>
        Header Detail Dialog
      </Text>
      <ScrollView maxHeight={"50vh"} padding={"10px"}>
        <View columnStart="1" columnEnd="-1">
          <TextField
            label="Slip No"
            name="SlipNO"
            placeholder="Slip No"
            shrink="0"
            textAlign="left"
            disabled={true}
            value={form.SlipNO}
            onChange={onFormChange}
          ></TextField>
        </View>
        <View columnStart="1" columnEnd="-1">
          <TextField
            label="Corporate Name"
            name="CorporateNA"
            placeholder="Corporate Name"
            shrink="0"
            textAlign="left"
            value={form.CorporateNA}
            hasError={form.CorporateNA == "" && isCheckValidation}
            errorMessage="Corporate Name is required."
            onChange={onFormChange}
          ></TextField>
        </View>
        <View columnStart="1" columnEnd="-1">
          <TextField
            label="Corporate Name (Japanese)"
            name="CorporateNA_KANA"
            placeholder="Corporate Name (Japanese)"
            shrink="0"
            textAlign="left"
            value={form.CorporateNA_KANA}
            hasError={form.CorporateNA_KANA == "" && isCheckValidation}
            errorMessage="Corporate Name (Japanese) is required."
            onChange={onFormChange}
          ></TextField>
        </View>
        <TextField
          label=""
          name={"ExclusiveFG"}
          value={form.ExclusiveFG}
          onChange={onFormChange}
          placeholder="ExclusiveFG"
          textAlign="left"
          display={"none"}
        ></TextField>
        {form.OrderDetailList ? (
          form.OrderDetailList.map((child: any, index: number) => {
            return (
              <>
                <HeaderDetailItemFormComponent
                  isCheckValidation={isCheckValidation}
                  headerDetailItem={child}
                  onHeaderDetailItemChange={onFormChange}
                  index={index}
                  items={items}
                  title={"Item " + (index + 1)}
                  onDelete={onDelete}
                />
              </>
            );
          })
        ) : (
          <></>
        )}
      </ScrollView>
      <Flex
        direction="row"
        justifyContent="space-between"
        alignItems="flex-end"
        alignContent="flex-start"
        wrap="nowrap"
        gap="1rem"
        padding={"10px"}
      >
        <Button
          role="button"
          aria-label="Add Header Detail Item Button"
          variation="primary"
          colorTheme="info"
          onClick={onItemAdd}
        >
          Add Item
        </Button>
        <Button
          role="button"
          aria-label="Submit Header Detail Item Button"
          variation="primary"
          colorTheme="success"
          onClick={onSubmit}
        >
          Submit
        </Button>
      </Flex>
      <Button
        role="button"
        aria-label="Header Detail Form Close Button"
        width="unset"
        height="unset"
        position="absolute"
        border="0px SOLID rgba(174,179,183,1)"
        borderRadius="4px"
        top="6px"
        right="6px"
        children="X"
        onClick={onClose}
      ></Button>
    </View>
  );
}
