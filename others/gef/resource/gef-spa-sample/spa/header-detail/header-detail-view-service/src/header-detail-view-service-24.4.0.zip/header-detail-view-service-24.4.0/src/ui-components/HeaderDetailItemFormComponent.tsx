/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import {
  Card,
  Divider,
  Flex,
  Grid,
  Icon,
  SelectField,
  TextField,
  View,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";

interface Props {
  isCheckValidation: boolean;
  headerDetailItem: any;
  onHeaderDetailItemChange: (e: SyntheticEvent) => void;
  index: number;
  title: string;
  items: any[];
  onDelete: (index: number) => void;
}

export default function HeaderDetailItemFormComponent(props: Props) {
  const {
    isCheckValidation,
    headerDetailItem,
    index,
    title,
    items,
    onDelete,
    onHeaderDetailItemChange,
  } = props;
  return (
    <Card
      role="form"
      aria-label="Header Detail Form Item"
      columnStart="1"
      columnEnd="-1"
    >
      <Divider marginTop={"20px"} orientation="horizontal" />
      <Grid
        marginTop={"10px"}
        border={"1px"}
        columnGap="0.5rem"
        rowGap="0.5rem"
        templateColumns="0.25fr 1fr 1fr 1fr 1fr 0.25fr"
      >
        <View columnStart="2" columnEnd="-1">
          <b>{title} </b>
        </View>

        <View rowSpan={4} columnStart="1" columnEnd="2">
          <Flex
            gap="0"
            direction="row"
            height="100%"
            justifyContent="center"
            alignItems="center"
            overflow="hidden"
            position="relative"
            padding="0px 0px 0px 0px"
          >
            <input
              type="checkbox"
              role="checkbox"
              aria-label="Detail Item Checkbox"
              name={"OrderDetailList." + index + ".CheckFG"}
              value={headerDetailItem.CheckFG}
              onChange={onHeaderDetailItemChange}
            />
          </Flex>
        </View>
        <View columnStart="2" columnEnd="6">
          <SelectField
            label="Item Code"
            name={"OrderDetailList." + index + ".ItemCD"}
            value={headerDetailItem.ItemCD}
            onChange={onHeaderDetailItemChange}
            textAlign="left"
          >
            {items ? (
              items.map((item: any) => {
                return (
                  <option value={item.cells.ItemCD}>{item.cells.ItemCD}</option>
                );
              })
            ) : (
              <></>
            )}
          </SelectField>
        </View>
        <View rowSpan={4} columnStart="6" columnEnd="-1">
          <Flex
            gap="0"
            direction="row"
            height="100%"
            justifyContent="center"
            alignItems="center"
            overflow="hidden"
            position="relative"
            padding="0px 0px 0px 0px"
          >
            <Icon
              width="19px"
              height="20px"
              viewBox={{ minX: 0, minY: 0, width: 19, height: 20 }}
              paths={[
                {
                  d: "M18.2083 3.6L15.0417 3.6L15.0417 1.6C15.0417 0.7175 14.3316 0 13.4583 0L5.54167 0C4.66836 0 3.95833 0.7175 3.95833 1.6L3.95833 3.6L0.791667 3.6C0.353776 3.6 0 3.9575 0 4.4L0 5.2C0 5.31 0.0890625 5.4 0.197917 5.4L1.69219 5.4L2.30326 18.475C2.34284 19.3275 3.04049 20 3.88411 20L15.1159 20C15.962 20 16.6572 19.33 16.6967 18.475L17.3078 5.4L18.8021 5.4C18.9109 5.4 19 5.31 19 5.2L19 4.4C19 3.9575 18.6462 3.6 18.2083 3.6ZM13.2604 3.6L5.73958 3.6L5.73958 1.8L13.2604 1.8L13.2604 3.6Z",
                  fill: "rgba(189,20,20,1)",
                  fillRule: "nonzero",
                },
              ]}
              display="block"
              shrink="0"
              position="relative"
              id="headerDetailRemoveAction"
              onClick={() => {
                onDelete(index);
              }}
            ></Icon>
          </Flex>
        </View>
        <View columnStart="2" columnEnd="3">
          <TextField
            label="Unit Price"
            type="number"
            name={"OrderDetailList." + index + ".UnitPrice"}
            value={headerDetailItem.UnitPrice}
            hasError={
              (headerDetailItem.UnitPrice == "" ||
                headerDetailItem.UnitPrice <= 0) &&
              isCheckValidation
            }
            errorMessage="Unit Price is required and must be greater than 0."
            onChange={onHeaderDetailItemChange}
            placeholder="Unit Price"
            textAlign="left"
          ></TextField>
        </View>
        <View columnStart="3" columnEnd="4">
          <TextField
            label="Order Quantity"
            type="number"
            name={"OrderDetailList." + index + ".OrderQT"}
            value={headerDetailItem.OrderQT}
            hasError={
              (headerDetailItem.OrderQT == "" ||
                headerDetailItem.OrderQT <= 0) &&
              isCheckValidation
            }
            errorMessage="Order Quantity is required and must be greater than 0."
            onChange={onHeaderDetailItemChange}
            placeholder="Order Quantity"
            textAlign="left"
          ></TextField>
        </View>
        <View columnStart="4" columnEnd="6">
          <TextField
            label="Total Amount"
            disabled={true}
            name={"OrderDetailList." + index + ".OrderAT"}
            value={
              (headerDetailItem.OrderQT ? headerDetailItem.OrderQT : 0) *
              (headerDetailItem.UnitPrice ? headerDetailItem.UnitPrice : 0)
            }
            onChange={onHeaderDetailItemChange}
            placeholder="Total Amount"
            textAlign="left"
          ></TextField>
        </View>
        <View columnStart="2" columnEnd="3">
          <SelectField
            label="Inspection?"
            name={"OrderDetailList." + index + ".InspectionFG"}
            value={headerDetailItem.InspectionFG}
            onChange={onHeaderDetailItemChange}
            textAlign="left"
          >
            <option value="0">No</option>
            <option value="1">Yes</option>
          </SelectField>
        </View>
        <View columnStart="3" columnEnd="4">
          <SelectField
            label="Stock?"
            name={"OrderDetailList." + index + ".StockFG"}
            value={headerDetailItem.StockFG}
            onChange={onHeaderDetailItemChange}
            textAlign="left"
          >
            <option value="0">No</option>
            <option value="1">Yes</option>
          </SelectField>
        </View>
        <View columnStart="4" columnEnd="6">
          <TextField
            label="Remark"
            name={"OrderDetailList." + index + ".Remark"}
            value={headerDetailItem.Remark}
            onChange={onHeaderDetailItemChange}
            placeholder="Remark"
            textAlign="left"
          ></TextField>
        </View>
        <TextField
          label=""
          name={"OrderDetailList." + index + ".ExclusiveFG"}
          value={headerDetailItem.ExclusiveFG}
          onChange={onHeaderDetailItemChange}
          placeholder="ExclusiveFG"
          textAlign="left"
          display={"none"}
        ></TextField>
        <TextField
          label=""
          name={"OrderDetailList." + index + ".DetailID"}
          value={headerDetailItem.DetailID}
          onChange={onHeaderDetailItemChange}
          placeholder="DetailID"
          textAlign="left"
          display={"none"}
        ></TextField>
        <TextField
          label=""
          name={"OrderDetailList." + index + ".DetailNo"}
          value={headerDetailItem.DetailNo}
          onChange={onHeaderDetailItemChange}
          placeholder="DetailNo"
          textAlign="left"
          display={"none"}
        ></TextField>
      </Grid>
    </Card>
  );
}
