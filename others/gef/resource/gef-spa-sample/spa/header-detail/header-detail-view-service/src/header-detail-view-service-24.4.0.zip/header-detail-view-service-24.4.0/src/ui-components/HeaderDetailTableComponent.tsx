/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import {
  Button,
  Pagination,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@aws-amplify/ui-react";

interface Props {
  onEdit: (slipNo: string) => void;
  onDelete: (slipNo: string) => void;
  currentPageIndex: number;
  totalSizePerPage: number;
  totalData: number;
  datas: any[];
  onChange: (startIndex: number, currentPageIndex: number) => void;
}

export default function HeaderDetailTableComponent(props: Props) {
  const {
    onEdit,
    onDelete,
    totalSizePerPage,
    datas,
    onChange,
    totalData,
    currentPageIndex,
  } = props;
  const totalPages = Math.ceil(
    (totalData ? totalData : 0) / (totalSizePerPage ? totalSizePerPage : 5),
  );
  const handleNextPage = () => {
    const currentPageIndexTemp = currentPageIndex + 1;
    onChange(currentPageIndexTemp * totalSizePerPage, currentPageIndexTemp);
  };

  const handlePreviousPage = () => {
    const currentPageIndexTemp = currentPageIndex - 1;
    onChange(currentPageIndexTemp * totalSizePerPage, currentPageIndexTemp);
  };

  const handleOnChange = (newPageIndex: any) => {
    const currentPageIndexTemp = newPageIndex;
    onChange(currentPageIndexTemp * totalSizePerPage, currentPageIndexTemp);
  };

  return (
    <>
      <Table backgroundColor={"rgb(255,255,255)"}>
        <TableHead>
          <TableRow>
            <TableCell as="th">Slip No</TableCell>
            <TableCell as="th">Corporate Name</TableCell>
            <TableCell as="th">Corporate Name(Japanese)</TableCell>
            <TableCell as="th">Updated Person</TableCell>
            <TableCell as="th">Update</TableCell>
            <TableCell as="th">Delete</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {datas ? (
            datas.map((data: any) => (
              <TableRow>
                <TableCell>{data.cells.SlipNO}</TableCell>
                <TableCell>{data.cells.CorporateNA}</TableCell>
                <TableCell>{data.cells.CorporateNA_KANA}</TableCell>
                <TableCell>{data.cells.UpdatedPerson}</TableCell>
                <TableCell>
                  {
                    <Button
                      role="button"
                      aria-label="Header Detail Edit Button"
                      variation="primary"
                      colorTheme="info"
                      onClick={() => {
                        onEdit(data.cells.SlipNO);
                      }}
                    >
                      Update
                    </Button>
                  }
                </TableCell>
                <TableCell>
                  {
                    <Button
                      role="button"
                      aria-label="Header Detail Delete Button"
                      variation="primary"
                      colorTheme="error"
                      onClick={() => {
                        onDelete(data.cells);
                      }}
                    >
                      Delete
                    </Button>
                  }
                </TableCell>
              </TableRow>
            ))
          ) : (
            <></>
          )}
        </TableBody>
      </Table>
      <Pagination
        role="navigation"
        aria-label="Header Detail Pagination"
        currentPage={currentPageIndex}
        totalPages={totalPages}
        onNext={handleNextPage}
        onPrevious={handlePreviousPage}
        onChange={handleOnChange}
      />{" "}
      <b>
        {"(" +
          (currentPageIndex * totalSizePerPage - totalSizePerPage + 1) +
          " ~ " +
          (currentPageIndex * totalSizePerPage -
            totalSizePerPage +
            1 +
            datas.length -
            1) +
          ") of " +
          totalData +
          " Rows"}{" "}
      </b>
    </>
  );
}
