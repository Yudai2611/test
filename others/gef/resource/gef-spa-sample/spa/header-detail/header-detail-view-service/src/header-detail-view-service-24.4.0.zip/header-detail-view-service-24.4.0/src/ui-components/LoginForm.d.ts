/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import {
  ButtonProps,
  FlexProps,
  PasswordFieldProps,
  TextFieldProps,
  TextProps,
} from "@aws-amplify/ui-react";
import { SyntheticEvent } from "react";
export declare type EscapeHatchProps = {
  [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
  [key: string]: string;
};
export declare type Variant = {
  variantValues: VariantValues;
  overrides: EscapeHatchProps;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> &
  React.DOMAttributes<HTMLDivElement>;
export declare type LoginFormOverridesProps = {
  LoginForm?: PrimitiveOverrideProps<FlexProps>;
  "Frame 1"?: PrimitiveOverrideProps<FlexProps>;
  "GreenEarth Framework SPA Sample"?: PrimitiveOverrideProps<TextProps>;
  TextField?: PrimitiveOverrideProps<TextFieldProps>;
  PasswordField?: PrimitiveOverrideProps<PasswordFieldProps>;
  "Login is failed!"?: PrimitiveOverrideProps<TextProps>;
  Button39111169?: PrimitiveOverrideProps<ButtonProps>;
  "sign up"?: PrimitiveOverrideProps<FlexProps>;
  "Don't have an account?"?: PrimitiveOverrideProps<TextProps>;
  Button39111173?: PrimitiveOverrideProps<ButtonProps>;
} & EscapeHatchProps;
export declare type LoginFormProps = React.PropsWithChildren<
  Partial<FlexProps> & {
    onLogin?: (event: SyntheticEvent) => void;
    onRegister?: (event: SyntheticEvent) => void;
    onChangeCompanyCode?: (event: SyntheticEvent) => void;
    onChangeUsername?: (event: SyntheticEvent) => void;
    onChangePassword?: (event: SyntheticEvent) => void;
    companyCode?: string;
    username?: string;
    password?: string;
    companyCodeHasError?: boolean;
    usernameHasError?: boolean;
    passwordHasError?: boolean;
    usernameErrorMessage?: string;
    passwordErrorMessage?: string;
    isLoginFailed?: boolean;
  } & {
    overrides?: LoginFormOverridesProps | undefined | null;
  }
>;
export default function LoginForm(props: LoginFormProps): React.ReactElement;
