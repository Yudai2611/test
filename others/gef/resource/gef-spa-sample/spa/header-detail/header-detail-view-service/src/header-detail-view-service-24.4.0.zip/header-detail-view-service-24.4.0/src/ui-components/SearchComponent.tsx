/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import * as React from "react";
import { SearchField } from "@aws-amplify/ui-react";

interface Props {
  keyword: string;
  label: string;
  placeholder: string;
  onClear: () => void;
  onKeywordChange: (event: React.SyntheticEvent) => void;
}

export default function SearchComponent(props: Props) {
  const { keyword, label, placeholder, onKeywordChange, onClear } = props;

  return (
    <>
      <SearchField
        width="480px"
        height="unset"
        label={label}
        placeholder={placeholder}
        textAlign="left"
        value={keyword}
        onChange={onKeywordChange}
        onClear={onClear}
      ></SearchField>
    </>
  );
}
