/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const ENV = {
  BASE_URI: import.meta.env.VITE_BASE_URI,
  CSRF_TOKEN_KEY: import.meta.env.VITE_SESSION_STORAGE_CSRF_TOKEN_KEY,
  LOGGED_IN_USER_KEY: import.meta.env.VITE_SESSION_STORAGE_LOGGED_IN_USER_KEY,
};
