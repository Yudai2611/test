/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { SyntheticEvent } from "react";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const getFullNameFirstChar = (fullName: string): string => {
  return fullName[0];
};

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const onChange = (
  e: SyntheticEvent,
  form: any,
  setForm: any,
  childrenKey: string,
) => {
  const formTemp = { ...form };
  if ((e.currentTarget as HTMLInputElement).name!.includes(".")) {
    const key = (e.currentTarget as HTMLInputElement).name!.split(".");
    const index = key[1];
    const childKey = key[2];
    formTemp[childrenKey][index][childKey] = (
      e.currentTarget as HTMLInputElement
    ).value!;
  } else {
    formTemp[(e.currentTarget as HTMLInputElement).name!] = (
      e.currentTarget as HTMLInputElement
    ).value!;
  }
  setForm({ ...formTemp });
};
