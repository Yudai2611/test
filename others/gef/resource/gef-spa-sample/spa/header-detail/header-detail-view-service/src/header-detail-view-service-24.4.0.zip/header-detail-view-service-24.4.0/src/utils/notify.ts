/* Copyright 2024 Kyocera Communication Systems Co., Ltd All rights reserved.*/

import { toast } from "react-toastify";

/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const notifySuccess = (message: string) => toast.success(message);
/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const notifyError = (message: string) => toast.error(message);
/**
 *
 * @create 2024/04/30
 * @author dhiaz chebastian
 * @since 24.4.0
 */
export const notifyInfo = (message: string) => toast.info(message);
